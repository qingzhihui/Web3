import React from 'react'

const SeaMane = () => {
  return (
    <div>秒杀</div>
  )
}

export default SeaMane