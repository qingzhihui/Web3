type Fishs = {
  name: string;
  swin: () => void;
};

type Birds = {
  name: string;
  fly: () => void;
};

function isFish(pet: Fishs | Birds): pet is Fishs {
  //true就是Fishs false就是Birds
  return (pet as Fishs).swin !== undefined;
}
function getSmallPet(): Fishs | Birds {
  let fish: Fishs = {
    name: "sharkey",
    swin: () => {},
  };
  let bird: Birds = {
    name: "sparrow",
    fly: () => {},
  };
  return true ? bird : fish;
}
console.log(getSmallPet());


let pet = getSmallPet();
if (isFish(pet)) {
  pet.swin();
} else {
  pet.fly();
}
console.log(pet);


const zoo: (Fishs | Birds)[] = [getSmallPet(), getSmallPet(), getSmallPet()];
const underWater1: Fishs[] = zoo.filter(isFish);
const underWater2: Fishs[] = zoo.filter(isFish) as Fishs[];

const underWater3: Fishs[] = zoo.filter((pet): pet is Fishs => {
  if (pet.name === "frog") {
    return false;
  }
  return isFish(pet);
});
console.log(underWater3);

