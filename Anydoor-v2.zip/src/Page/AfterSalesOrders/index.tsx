import {
  Button,
  Form, Modal,
  Radio,
  Select,
  Space,
  Table
} from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { AlignCenterOutlined, DollarOutlined } from "@ant-design/icons";
import { createRef, useState } from "react";

// 售后订单界面
const AfterSalesOrders = () => {
  const FormRef = createRef<any>();
  const [isReviseTableData, setReviseTableData] = useState(false);
  interface DataType {
    key: React.Key;
    orderNumber: string; //订单号
    serviceOrderNumber: string; //服务单号
    applicationTime: string; //申请时间
    productInformation: string; // 商品信息
    realTimeAmount: string; // 实付金额
    serviceType: string; // 服务类型
    status: string; // 订单状态
    paymentMethod: string; //支付方式
  }
  const data: DataType[] = [
    {
      key: 1,
      orderNumber: "111654947818",
      serviceOrderNumber: "微信用户",
      applicationTime: "2023-01-01",
      productInformation: "任意门礼品",
      realTimeAmount: "899.00",
      serviceType: "仅退款",
      status: "已取消",
      paymentMethod: "信用卡支付",
    },
  ];
  const columns: ColumnsType<DataType> = [
    {
      title: "订单号",
      dataIndex: "orderNumber",
      width: 120,
    },
    {
      title: "服务单号",
      dataIndex: "serviceOrderNumber",
      width: 120,
    },
    {
      title: "申请时间",
      dataIndex: "applicationTime",
      width: 120,
    },
    {
      title: "商品信息",
      dataIndex: "productInformation",
      width: 120,
    },
    {
      title: "实付金额",
      width: 100,
      dataIndex: "realTimeAmount",
    },
    {
      title: "服务类型",
      // width:120,
      dataIndex: "serviceType",
    },
    {
      title: "订单状态",
      dataIndex: "status",
      render: (_text, record) => (
        <Space size="middle">
          <span className="afterSales_status">{_text}</span>
        </Space>
      ),
    },
    {
      title: "支付方式",
      dataIndex: "paymentMethod",
      render: (_text, record) => (
        <Space size="middle">
          <span className="afterSales_backcolor">{_text}</span>
        </Space>
      ),
    },

    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="afterSales_memberCursor" onClick={lookover(record)}>
            {/* <FormOutlined /> */}
            <AlignCenterOutlined />
          </span>
          <span
            className="afterSales_memberCursor"
            onClick={drawbackBtn(record)}
          >
            <DollarOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 头部下拉选择框-内容
  const options1 = [
    {
      value: "1",
      label: "退货",
    },
    {
      value: "2",
      label: "xxx",
    },
  ];

  // 头部下拉选择框-内容---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };

  // 退款下拉选择框-内容
  const options2 = [
    {
      value: "1",
      label: "按支付方式原路退回",
    },
    {
      value: "2",
      label: "转银行卡退回",
    },
  ];

  // 退款下拉选择框-内容---选中内容
  const handleChange2 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };
  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 查看
  const lookover = (record: any) => {
    return () => {
      console.log("点击了查看");
      console.log(record.key);
    };
  };
  // 退款
  const drawbackBtn = (record: any) => {
    return () => {
      console.log("点击了退款");
      console.log(record.key);
      setReviseTableData(true);
    };
  };

  //  修改-提交按钮
  const onReviseSubmitBtn = (values: any) => {
    console.log("修改提交的数据", values);
    // 清空
    FormRef.current.resetFields();
  };
  // 修改表格数据--关闭
  const ReviseTableDataClose = () => {
    setReviseTableData(false);
  };

  return (
    <div className="afterSales_Box">
      <div className="afterSales_headerBox">
        <div className="afterSales_headerBox_thread"></div>
        <div className="afterSales_headerBox_Tit">
          &nbsp;&nbsp;&nbsp; 售后订单
        </div>
        <div className="afterSales_Add_moban">
          <div className="afterSales_seekBtn" onClick={adminSearch}>
            <Select
              labelInValue
              defaultValue={{ value: "1", label: "退货" }}
              style={{ width: 120 }}
              onChange={handleChange1}
              options={options1}
            />
          </div>
        </div>
      </div>

      <div className="afterSales_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
        {/* 修改 */}
        <Modal
          className="afterSales_dialogBox"
          footer={[null]}
          open={isReviseTableData}
          onCancel={ReviseTableDataClose}
        >
          <div className="afterSales_headerBox">
            <div className="afterSales_headerBox_thread"></div>
            <div className="afterSales_headerBox_Tit">
              &nbsp;&nbsp;&nbsp; 退款
            </div>
          </div>
          <div className="afterSales_tableBox">
            <Form
              name="basic"
              ref={FormRef}
              labelCol={{ span: 7 }}
              wrapperCol={{ span: 16 }}
              style={{ maxWidth: 700 }}
              initialValues={{ remember: true }}
              onFinish={onReviseSubmitBtn}
              autoComplete="off"
            >
              <Form.Item label="金额退回至" name="billingMethod">
                <Select
                  labelInValue
                  defaultValue={{ value: "1", label: "按支付方式原路退回" }}
                  // style={{ width: 120 }}
                  onChange={handleChange2}
                  options={options2}
                />
              </Form.Item>

              <Form.Item label="状态" name="billingMethod">
                <Radio.Group>
                  <Radio value="1"> 同意 </Radio>
                  <Radio value="2"> 拒绝 </Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                <Button
                  className="afterSales_btn"
                  size="middle"
                  type="primary"
                  htmlType="submit"
                >
                  提交
                </Button>
              </Form.Item>
            </Form>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default AfterSalesOrders;
