// pages/Reports/Reports.js
import api from '../../config/api'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    radio: '0',
    message3: "",
    message4: "",
    show3: false,
    listKuData: [],
    arrLIne: [],
    tid: "",
    zid: ""
  },
  onClickLeft() {
    wx.navigateBack({
      url: '../Hisments/Hisments',
    })
  },
  onClindex() {
    getApp().globalData.is_first_login=1,
      wx.switchTab({
        url: '../index/index',
      })
  },
  onChange(event) {
    if ((event.detail == 2)) {
      setTimeout(() => {
        this.setData({
          radio: event.detail,
          dinping: true,
        });
      }, 300)
    } else {
      setTimeout(() => {
        this.setData({
          radio: event.detail,
          dinping: false,
        });
      }, 300)
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    api._get(`ums/umsEvidence/selectReportInfo/${options.id}/${options.tid}/${options.zid}`).then(res => {
      const arrle = res.data.slice(-1)
      this.setData({
        listKuData: res.data,
        arrLIne: arrle,
        zid: options.zid,
        tid: options.tid
      })
    }).catch(e => {
      console.log(e);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  },
  Anlishow(e) {
    api._get(`ums/umsEvidence/selectEvidenceInfo/${this.data.zid}/${e.currentTarget.dataset.id}/${this.data.tid}`).then(res => {
      this.setData({
        message3: res.data[0].content
      })
    }).catch(e => {
      console.log(e);
    })
    this.setData({
      show3: true
    });
  },
  onClose3() {
    this.setData({
      show3: false
    });
  }
})