// pages/FlightFilin/FlightFilin.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    activeNames: ['0'],
    columns: ['杭州', '宁波', '温州', '嘉兴', '湖州'],
    show: false,
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  addDetailsShow(){
    wx.navigateTo({
      url: '../Addwines/Addwines'
    })
  },
  SelectOncluck(){
    wx.navigateTo({
      url:'../FlightPayme/FlightPayme'
    })
  },
  
  PlaceOnChange(event: any) {
    this.setData({
      activeNames: event.detail,
    });
  },
  onChange(event: any) {
    const { picker, value, index } = event.detail;
    console.log(picker, value, index);
    
  },
  showPopup() {
    this.setData({ show: true });
  },

  onClose() {
    this.setData({ show: false });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})