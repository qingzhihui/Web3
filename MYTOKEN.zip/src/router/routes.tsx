import React from "react";
import { RouteObject } from "react-router-dom";
const HomeComponent = React.lazy(() => import("../view/Home"));
const FarmComponent = React.lazy(() => import("../view/Farm"));
const InvitComponent = React.lazy(() => import("../view/Invit"));

const routes: RouteObject[] = [
  {
    path: "/",
    element: <HomeComponent />,
    children: [],
  },
  {
    path: "/Farm",
    element: <FarmComponent />,
  },
  {
    path: "/Invit",
    element: <InvitComponent />,
  },
];

export default routes;
