import {
  Button,
  Form,
  Input,
  InputNumber,
  Modal,
  Select,
  SelectProps,
  Space,
  Table,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { DeleteOutlined, FormOutlined } from "@ant-design/icons";
import { useState } from "react";

// 酒店采集管理界面
const HotelGatherManage = () => {
  const [isaddAdmin, setUpdajx] = useState(false);
  const [isaddAdmin2, setUpdajx2] = useState(false);
  interface DataType {
    key: string;
    taskName: string; //任务名称
    queryKeywords: string; //查询关键字
    executionCycle: string; //执行周期
    addTime: string; //添加时间
    hotelNumber: number; //酒店数量
  }
  const data: DataType[] = [
    {
      key: "1",
      taskName: "采集任务",
      queryKeywords: "TX,Hotel",
      executionCycle: "每周6|6时30分",
      addTime: "2023-01-01",
      hotelNumber: 28,
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "任务名称",
      dataIndex: "taskName",
      key: "taskName",
    },
    {
      title: "查询关键字",
      dataIndex: "queryKeywords",
      key: "queryKeywords",
    },
    {
      title: "执行周期",
      dataIndex: "executionCycle",
      key: "executionCycle",
    },
    {
      title: "添加时间",
      dataIndex: "addTime",
      key: "addTime",
    },
    {
      title: "酒店数量",
      dataIndex: "hotelNumber",
      key: "hotelNumber",
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <a
            onClick={uploadus(record)}
            className="Gather_publicStyleA"
            href="#"
          >
            <span>
              <FormOutlined />
            </span>
          </a>
          <a
            onClick={deleteus(record)}
            className="Gather_publicStyleA"
            href="#"
          >
            <span>
              <DeleteOutlined />
            </span>
          </a>
        </Space>
      ),
    },
  ];



  const onChange1xg = (value: any) => {
    console.log("输入的“时”：", value);
  };
  const onChange2xg = (value: any) => {
    console.log("输入的“分”：", value);
  };

  const options2xg: SelectProps["options"] = [];


  const handleChange2xg = (value: string) => {
    console.log(`selected ${value}`);
  };

  // 修改-星期选择-内容
  const options1xg = [
    {
      value: "每周一",
      label: "每周一",
    },
    {
      value: "每周二",
      label: "每周二",
    },
    {
      value: "每周三",
      label: "每周三",
    },
    {
      value: "每周四",
      label: "每周四",
    },
    {
      value: "每周五",
      label: "每周五",
    },
    {
      value: "每周六",
      label: "每周六",
    },
    {
      value: "每周天",
      label: "每周天",
    },
  ];

  // 修改-星期选择---选中内容
  const handleChange1xg = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };


  const onChange1 = (value: any) => {
    console.log("输入的“时”：", value);
  };
  const onChange2 = (value: any) => {
    console.log("输入的“分”：", value);
  };

  const options2: SelectProps["options"] = [];


  const handleChange2 = (value: string) => {
    console.log(`selected ${value}`);
  };

  // 添加-星期选择-内容
  const options1 = [
    {
      value: "每周一",
      label: "每周一",
    },
    {
      value: "每周二",
      label: "每周二",
    },
    {
      value: "每周三",
      label: "每周三",
    },
    {
      value: "每周四",
      label: "每周四",
    },
    {
      value: "每周五",
      label: "每周五",
    },
    {
      value: "每周六",
      label: "每周六",
    },
    {
      value: "每周天",
      label: "每周天",
    },
  ];

  // 添加-星期选择---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };

  //  添加-提交按钮
  const onAddAssignmentBtn = (values: any) => {
    console.log("提交的数据", values);
  };

  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 修改
  const uploadus = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record.key);
      setUpdajx2(true);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };
  // 点击X关闭
  const handleCancel = () => {
    setUpdajx(false);
    setUpdajx2(false);
  };

  // 点击新增
  const addAssignment = () => {
    console.log("点击了新增管理员");
    setUpdajx(true);
  };
  return (
    <div className="Gather_Box">
      <div className="Gather_headerBox">
        <div className="Gather_headerBox_thread"></div>
        <div className="Gather_headerBox_Tit">
          &nbsp;&nbsp;&nbsp; 酒店采集管理
        </div>
        <div className="Gather_Add_moban">
          <div className="Gather_usernameInpuit">
            <div className="Gather_publicStyleTit">名称：</div>
            <div className="Gather_publicStyleIpt">
              <Input placeholder="请输入名称/查询关键字" />
            </div>
          </div>
          <a href="#">
            <div className="Gather_seekBtn" onClick={adminSearch}>
              查找
            </div>
          </a>

          <div className="Gather_addAdminBtn" onClick={addAssignment}>
            添加
          </div>
          {/* 添加酒店采集任务 */}
          <Modal
            className="Gather_addAdmin"
            footer={[null]}
            open={isaddAdmin}
            onCancel={handleCancel}
          >
            <div className="Gather_headerBox">
              <div className="Gather_headerBox_thread"></div>
              <div className="Gather_headerBox_Tit">
                &nbsp;&nbsp;&nbsp;添加酒店采集任务
              </div>
            </div>
            <div className="Gather_addAdmin_Box">
              <Form
                name="basic"
                labelCol={{ span: 6 }}
                wrapperCol={{ span: 18 }}
                style={{ maxWidth: 600 }}
                initialValues={{ remember: true }}
                onFinish={onAddAssignmentBtn}
                autoComplete="off"
              >
                <Form.Item label="任务名称" name="taskname">
                  <Input placeholder="请填写任务名称" />
                </Form.Item>
                <Form.Item label="AiD" name="AiD">
                  <Input
                    defaultValue="zk+URL+YBGvmFPwZOGKQ=="
                    placeholder="请输入姓名"
                  />
                </Form.Item>
                <Form.Item label="酒店查询关键字" name="queryKeywords">
                  <Select
                    mode="tags"
                    style={{ width: "100%" }}
                    placeholder="Tags Mode"
                    onChange={handleChange2}
                    options={options2}
                  />
                </Form.Item>
                <Form.Item label="执行周期" name="executionCycle">
                  <div className="ExecutionCycle">
                    <div>
                      <Select
                        labelInValue
                        style={{ width: 120 }}
                        onChange={handleChange1}
                        options={options1}
                      />
                    </div>
                    <div>
                      <InputNumber min={1} max={24} onChange={onChange1} />时
                    </div>
                    <div>
                      <InputNumber min={1} max={60} onChange={onChange2} />分
                    </div>
                  </div>
                </Form.Item>
                <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                  <Button
                    className="Gather_btn"
                    size="middle"
                    type="primary"
                    htmlType="submit"
                  >
                    提交
                  </Button>
                </Form.Item>
              </Form>
            </div>
          </Modal>
        </div>
      </div>

      <div className="Gather_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
        {/* 修改 */}
        <Modal
            className="Gather_addAdmin"
            footer={[null]}
            open={isaddAdmin2}
            onCancel={handleCancel}
          >
            <div className="Gather_headerBox">
              <div className="Gather_headerBox_thread"></div>
              <div className="Gather_headerBox_Tit">
                &nbsp;&nbsp;&nbsp;添加酒店采集任务
              </div>
            </div>
            <div className="Gather_addAdmin_Box">
              <Form
                name="basic"
                labelCol={{ span: 6 }}
                wrapperCol={{ span: 18 }}
                style={{ maxWidth: 600 }}
                initialValues={{ remember: true }}
                onFinish={onAddAssignmentBtn}
                autoComplete="off"
              >
                <Form.Item label="任务名称" name="taskname">
                  <Input placeholder="请填写任务名称" />
                </Form.Item>
                <Form.Item label="AiD" name="AiD">
                  <Input
                    defaultValue="zk+URL+YBGvmFPwZOGKQ=="
                    placeholder="请输入姓名"
                  />
                </Form.Item>
                <Form.Item label="酒店查询关键字" name="queryKeywords">
                  <Select
                    mode="tags"
                    style={{ width: "100%" }}
                    placeholder="Tags Mode"
                    onChange={handleChange2xg}
                    options={options2xg}
                  />
                </Form.Item>
                <Form.Item label="执行周期" name="executionCycle">
                  <div className="ExecutionCycle">
                    <div>
                      <Select
                        labelInValue
                        style={{ width: 120 }}
                        onChange={handleChange1xg}
                        options={options1xg}
                      />
                    </div>
                    <div>
                      <InputNumber min={1} max={24} onChange={onChange1xg} />时
                    </div>
                    <div>
                      <InputNumber min={1} max={60} onChange={onChange2xg} />分
                    </div>
                  </div>
                </Form.Item>
                <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                  <Button
                    className="Gather_btn"
                    size="middle"
                    type="primary"
                    htmlType="submit"
                  >
                    提交
                  </Button>
                </Form.Item>
              </Form>
            </div>
          </Modal>
      </div>
    </div>
  );
};

export default HotelGatherManage;
