import React, { useState, useEffect } from "react";
import "./index.scss";
import { Input } from "antd";
import {
  AirPrcoABI,
  AirPrcoAddress,
  CreateAidropeProps,
  URlDataProps,
} from "../../hooks/Airprcopy";
import { InstancedContract, ObtainAddress } from "../../hooks/config";
import { useHistory, useLocation } from "react-router-dom";
import ButtonLoading from "../../components/ButtonLoading";
import { useTranslation, Trans } from "react-i18next";
const { TextArea } = Input;
declare const window: Window & { ethereum: any };
const CreateAirece: React.FC = (props: any) => {
  let history = useHistory();
  const { state } = useLocation<any>();
  const [userLine, setUserLine] = useState<string>("");
  const [userInputValue, setUserInputValue] = useState<CreateAidropeProps>({});
  const [BuiotnShow, setBuiotnShow] = useState<boolean>(false);
  const [URlData, setURlData] = useState<URlDataProps>({});
  const [loading, setLoading] = useState<boolean>(false);
  const { t } = useTranslation();

  const NextOnCLikc = async () => {
    try {
      setLoading(true);
      const Contract = InstancedContract(AirPrcoAddress, AirPrcoABI) as any;
      const { address } = await ObtainAddress() as any;
      const create = await Contract.create(
        address,
        userLine,
        `${userInputValue.Title},${userInputValue.LogoURL},${userInputValue.Website},${userInputValue.Facebook},${userInputValue.Twitter},${userInputValue.Github},${userInputValue.Telegram},${userInputValue.Instagram},${userInputValue.Discord},${userInputValue.Reddit},${userInputValue.Description}`
      );
      await create.wait();
      setLoading(false);
    } catch (error) {
      setLoading(false);
    }
  };
  const BackOnClick = () => {
    history.push({
      pathname: "/Airdrop",
      state,
    });
  };
  useEffect(() => { }, [URlData]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          const { inputValue } = state.inputValue;
          setUserLine(inputValue);
        }
      }
    }

  }, []);
  return (
    <div className="CreateAirdrop">
      <div className="CreateAirdrop_countent">
        <div className="title">{`${t("Create New Launchpad")}`}</div>
        <div className="CreateAirdrop_table">
          <div className="attention">(*) {`${t("is required field.")}`}</div>
          <div className="titleinput">
            <div className="titleipt">{`${t("Airdrop Title")}`}</div>
            <div className="inputs">
              <Input
                placeholder={`${t("Ex: Join my mayasale airdrop")}`}
                bordered={false}
                value={userInputValue.Title || ""}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  setUserInputValue((olddata: any) => {
                    return {
                      ...olddata,
                      Title: e.target.value,
                    };
                  });
                }}
              />
            </div>
          </div>
          <div className="logoweinput">
            <div className="urlinput">
              <div className="titlelo">
                {`${t("Logo URL")}`} <span>*</span>
              </div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://...")}`}
                  bordered={false}
                  value={userInputValue.LogoURL || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        LogoURL: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon99.png")}
                      alt=""
                    />
                  }
                />
              </div>
              <div className="lourl">
                {`${t(
                  "URL must end with a supported image extension png, jpg, jpeg or gif. You can upload your image at"
                )}`}{" "}
                <a href="">https://images.youwant.io/</a>
              </div>
            </div>
            <div className="weinput">
              <div className="titlewe">
                {`${t("Website")}`} <span>*</span>
              </div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://...")}`}
                  bordered={false}
                  value={userInputValue.Website || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Website: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon22.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Facebook</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://facebook.com/...")}`}
                  bordered={false}
                  value={userInputValue.Facebook || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Facebook: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon88.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Twitter</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://twitter.com/...")}`}
                  bordered={false}
                  value={userInputValue.Twitter || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Twitter: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon66.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Github</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://github.com/...")}`}
                  bordered={false}
                  value={userInputValue.Github || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Github: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon11.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Telegram</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://t.me/...")}`}
                  bordered={false}
                  value={userInputValue.Telegram || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Telegram: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon55.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Instagram</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://instagram.com/...")}`}
                  bordered={false}
                  value={userInputValue.Instagram || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Instagram: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon33.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Discord</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://t.me/...")}`}
                  bordered={false}
                  value={userInputValue.Discord || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Discord: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon77.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
          </div>
          <div className="redditinputs">
            <div className="titlere">Reddit</div>
            <div className="inputs">
              <Input
                placeholder={`${t("Ex: https://reddit.com/...")}`}
                bordered={false}
                value={userInputValue.Reddit || ""}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  setUserInputValue((olddata: any) => {
                    return {
                      ...olddata,
                      Reddit: e.target.value,
                    };
                  });
                }}
                prefix={
                  <img src={require("../../assets/image/icon44.png")} alt="" />
                }
              />
            </div>
          </div>
          <div className="descriptiontext">
            <div className="titlede">{`${t("Description")}`}</div>
            <div className="inputstext">
              <TextArea
                placeholder={`${t("Ex: This is the best project...")}`}
                allowClear
                value={userInputValue.Description || ""}
                onChange={(e) => {
                  setUserInputValue((olddata: any) => {
                    return {
                      ...olddata,
                      Description: e.target.value,
                    };
                  });
                }}
              />
            </div>
          </div>
          <div className="buts">
            <button
              className="back"
              onClick={() => {
                BackOnClick();
              }}
            >{`${t("Back")}`}</button>
            <button
              className="createbut diancli"
              onClick={() => {
                NextOnCLikc();
              }}
            >
              {loading ? <ButtonLoading /> : ""}
              {`${t("Create New Airdrop")}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default CreateAirece;
