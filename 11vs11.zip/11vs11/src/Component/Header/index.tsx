import $ from "jquery";
import {useEffect, useState} from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

import "./index.scss";
import logo from "./img/logo.png";
import img1 from "./img/1.png";
import img2 from "./img/2.png";
import img3 from "./img/3.png";
import img4 from "./img/4.png";
import mathloge from "./img/maoti.png";
import jiantouxia from "./img/xiangxia.png";
import tuichu from "./img/jinru.png";
import walletIcon from "../../assets/img/svg/wallet.svg";
import { RootStateType } from "../../redux/store";
import useWeb3Connector from "../../hooks/web3Connector";
import { conciseAddress } from "../../helpers/utilities";
import lang from "./img/lang.png"
import {useTranslation} from "react-i18next";
import i18n from "../../language/config.js"

export default function Header(props: {routes: any[]}) {
  const t = useTranslation()
  const web3Slice = useSelector((state: RootStateType) => state.web3Slice);
  const { onConnect, onDisconnect } = useWeb3Connector();
  const [liset, setliset] = useState(false);

  const { account } = web3Slice;

  function show() {
    $("#header .menu-box, .menu-bg").addClass("active");
  }
  function close() {
    $("#header .menu-box, .menu-bg").removeClass("active");
  }
  const sibsShow = () => {
    setliset(false);
  };
  const nuslShow = () => {
    setliset(true);
  };
  function changeLang(str: string) {
    i18n.changeLanguage(str)
    $(".lang-list, .lang-mask").fadeOut()
  }
  return (
    <div id="header">
      <div className="content-box content">
        <div className="logo">
          <img src={logo} alt="" />
        </div>
        <img className="menu-btn" src="/img/menu.png" onClick={show} />
        <div className="menu-bg" onClick={close} />
        <div className="menu-box">
          <img className="close" src="/img/close.png" alt="" onClick={close} />
          <div className="menus">
            {props.routes.map((item, key) => {
              return (
                <Link className="menu-item" key={key} to={item.path}>
                  {item.name}
                </Link>
              );
            })}
          </div>
          <div className="fbw">
            <a href="https://bscscan.com/address/0x86B4830fC5CE77B1Bf1D9d7F5309e359f4884588/"
              target="_blank">Buy $FBW</a>
          </div>
          <div className="icon-list">
            <a
              href="https://t.me/FBW1_NFT"
              target="_blank"
              className="icon-item"
            >
              <img src={img1} alt="Telegram" />
            </a>
            <a
              href="https://twitter.com/footballworld_V"
              target="_blank"
              className="icon-item"
            >
              <img src={img3} alt="Twitter" />
            </a>
            <a
              href="https://docs.footballworldnft.com/"
              target="_blank"
              className="icon-item"
            >
              <img src={img4} alt="Document" />
            </a>
          </div>
          <div className="lang">
            <img src={lang} alt="" onClick={() => {
              $(".lang-list, .lang-mask").fadeIn()
            }}/>
            <div
              className="lang-mask"
              style={{display: "none"}}
               onClick={() => {
                 $(".lang-list, .lang-mask").fadeOut()
               }}
            />
            <div className="lang-list" style={{display: "none"}}>
              <div className="lang-item" onClick={() => changeLang("cn")}>中文</div>
              <div className="lang-item" onClick={() => changeLang("en")}>English</div>
            </div>
          </div>
          {account ? (
            <div className="connected">
              <div className="connect">
                <img src={walletIcon} className="walletIcon" alt="" />
                <div className="lisdnm">
                  <span>{conciseAddress(account)}</span>
                  <img src={jiantouxia} alt="" />
                </div>
                <div className="wndfiasng" onClick={onDisconnect}>
                  <div className="nusblie">
                    <img src={tuichu} alt="" />
                    <span>Disconnect</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <button onClick={nuslShow} className="connect">
              Connect Wallet
            </button>
          )}
        </div>
      </div>
      {!account && liset ? (
        <div className="sbsine">
          <div className="dtobsli" onClick={sibsShow}></div>
          <div className="heyuenli">
            <div className="lisnei">
              <img src={logo} alt="" />
              <span>Please select your wallet</span>
            </div>
            <div className="lisngba">
              <div className="litem" onClick={onConnect}>
                <img src={mathloge} alt="" />
                <div className="nsurto">
                  <span>MetaMask</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </div>
  );
}
