import _ from 'C:/Users/AnyDoorTrip-05/Desktop/Lisersn/node_modules/umi/node_modules/regenerator-runtime/runtime.js';
export default _;
export * from 'C:/Users/AnyDoorTrip-05/Desktop/Lisersn/node_modules/umi/node_modules/regenerator-runtime/runtime.js';
