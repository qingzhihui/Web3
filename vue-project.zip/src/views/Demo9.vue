<template>
  <div>
    <div :class="{ active: isActive }">123</div>
    <div class="static" :class="{ active: isActive, 'text-danger': hasError }">456</div>
    <div :class="classObject">789</div>
  </div>
</template>
<script lang="ts">
import { ref, reactive } from 'vue'
export default {
  setup() {
    const isActive = ref(true);
    const hasError = ref(false);
    const error = ref(null)
    return {
      isActive, hasError, error
    }
  },
  computed: {
    classObject() {
      return {
        active: this.isActive && !this.error,
        'text-danger': this.error && this.error.type === 'fatal'
      }
    }
  }
}
</script>
<style scoped>
.text-danger {
  color: aqua;
}

.active {
  color: red;
}
</style>