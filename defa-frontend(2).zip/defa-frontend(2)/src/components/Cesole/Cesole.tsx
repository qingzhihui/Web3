import React, { useEffect, useCallback, useState, useMemo, useRef } from 'react'
import { useTranslation } from 'contexts/Localization'
import no from '../../style/no.svg'
const Cesole = (props: any) => {
  const { t } = useTranslation()
  return (
    <div className="snueLIse">
      <div className="snueLIsevlog">
        <div className="imgls2"></div>
      </div>
      <div className="snueLIsenoe">{t(props.name)}</div>
    </div>
  )
}
export default Cesole
