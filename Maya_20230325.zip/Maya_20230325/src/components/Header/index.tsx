import React, { useState, useEffect } from "react";
import { CaretDownOutlined } from "@ant-design/icons";
import { getItem, MenuItem } from "../../hooks/config";
import { useHistory } from "react-router-dom";
import Connectwallet from "../../components/Connectwallet";
import International from "../../components/International";
import { useTranslation, Trans } from "react-i18next";
import { Button, Dropdown, Menu, Space, MenuProps, Drawer } from "antd";
import { ethers } from "ethers";
import { Web3Button, Web3Modal } from "@web3modal/react";
import "./index.scss";
import {
  EthereumClient,
  modalConnectors,
  walletConnectProvider,
} from "@web3modal/ethereum";
import { configureChains, createClient, WagmiConfig } from "wagmi";
import { arbitrum, mainnet, polygon , goerli} from "wagmi/chains";
declare const window: Window & { ethereum: any };
const ches = {
  key: "1",
  name: "BNB",
};

const Cwallet = (posps: any) => {
  const { t } = useTranslation();
  const [network, setNetwork] = useState(ches);
  const [open, setOpen] = useState(false);
  const [collNum, setcollNum] = useState("");
  const [collapsed, setCollapsed] = useState(false);
  const history = useHistory();

  const showDrawer = () => {
    setOpen(true);
  };


  // Wagmi client
  const chains = [arbitrum, mainnet, polygon, goerli];
  const { provider } = configureChains(chains, [
    walletConnectProvider({ projectId: "b98a412bd29c5618fe10c37180fa6813" }),
  ]);
  const wagmiClient = createClient({
    autoConnect: true,
    connectors: modalConnectors({
      projectId: "b98a412bd29c5618fe10c37180fa6813",
      version: "2", // or "2"
      appName: "web3Modal",
      chains,
    }),
    provider,
  });
  const ethereumClient = new EthereumClient(wagmiClient, chains);

  const items: MenuItem[] = [
    getItem(
      "Home",
      "/Home",
      <img
        className="piooen"
        src={
          collNum === "/Home"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome1.png")
        }
      />
    ),
    getItem(
      "Launchpads",
      "sub1",
      <img
        className="piooen"
        src={
          collNum === "/Lauchpad" || collNum === "/Presale"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome2.png")
        }
      />,
      [getItem("Create", "/Lauchpad"), getItem("Launchpad list", "/Presale")]
    ),
    getItem(
      "Private Sale",
      "sub2",
      <img
        className="piooen"
        src={
          collNum === "/Sale" || collNum === "/PrivateSale"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome3.png")
        }
      />,
      [
        getItem("Create Private Sale", "/Sale"),
        getItem("Private Sale List", "/PrivateSale"),
      ]
    ),
    getItem(
      "MAYAlock",
      "sub3",
      <img
        className="piooen"
        src={
          collNum === "/Lock" ||
          collNum === "/Token" ||
          collNum === "/Liquidity"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome4.png")
        }
      />,
      [
        getItem("Create Lock", "/Lock"),
        getItem("Token", "/Token"),
        getItem("Liquidity", "/Liquidity"),
      ]
    ),
    getItem(
      "Airdrop",
      "/Airdrop",
      <img
        className="piooen"
        src={
          collNum === "/Airdrop"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome5.png")
        }
      />
    ),
    getItem(
      "leaderboard",
      "/Leaderboard",
      <img
        className="piooen"
        src={
          collNum === "/Leaderboard"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome6.png")
        }
      />
    ),
    getItem(
      "Anti-Bot",
      "/AntiBot",
      <img
        className="piooen"
        src={
          collNum === "/AntiBot"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome7.png")
        }
      />
    ),
    getItem(
      "Multi Sender",
      "/MultiSender",
      <img
        className="piooen"
        src={
          collNum === "/MultiSender"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome8.png")
        }
      />
    ),
  ];

  const onClose = () => {
    setOpen(false);
  };
  const Buseir: any = [
    {
      key: "1",
      label: <div className="wereiku">BNB</div>,
    },
    {
      key: "2",
      label: <div className="wereiku">USDT</div>,
    },
  ];
  const handleClick = (value: any) => {};
  const onClick: MenuProps["onClick"] = ({ key }) => {
    Buseir.map((item: any) => {
      if (item.key == key) {
        setNetwork({
          key: key,
          name: item.label.props.children,
        });
        localStorage.setItem("Network", key);
        handleClick(key);
      }
    });
  };
  const onOpenChange = (e: any) => {
    setcollNum(e.key);
    history.push(e.key);
  };

  const menu = <Menu onClick={onClick} items={Buseir} />;
  useEffect(() => {
  }, []);
  return (
    <div className="Cwallet">
      <div className="bproin_pro">
        <div
          className="bproin"
          onClick={() => {
            showDrawer();
          }}
        ></div>
      </div>
      <International />
      <div className="Cwallet_poseItem">
        <div className="poseNetwork">
          <div className="Bsyeuine">
            <Dropdown overlay={menu}>
              <Button onClick={(e) => e.preventDefault()}>
                <Space>
                  <div className="slueipoi">
                    <div className="slueipoimge">
                      <img
                        src={require("../../assets/image/loge.png")}
                        // src={require(`../../assets/${
                        //   (network as any).key == "1" ? "0x56.png" : "0x1.png"
                        // }`)}
                        alt=""
                      />
                    </div>
                    {(network as any).key == "1" ? (
                      <div className="werei">{(network as any).name}</div>
                    ) : (
                      <div className="werei2">{(network as any).name}</div>
                    )}
                  </div>
                  <CaretDownOutlined />
                </Space>
              </Button>
            </Dropdown>
          </div>
        </div>
      </div>
      <Connectwallet />
      {/* <WagmiConfig client={wagmiClient}>
        <Web3Button />
      </WagmiConfig>
      <Web3Modal
        projectId="b98a412bd29c5618fe10c37180fa6813"
        ethereumClient={ethereumClient}
      /> */}
      <Drawer
        title={
          <div
            className="zhedier"
            onClick={() => {
              onClose();
            }}
          >
            <img
              src={require("../../assets/image/tabler_indent-decrease.png")}
              alt=""
            />
          </div>
        }
        placement="left"
        onClose={onClose}
        width={180}
        open={open}
      >
        <div className="buloge">
          {collapsed ? (
            <img
              className="imgl1"
              src={require("../../assets/image/loge.png")}
              alt=""
            />
          ) : (
            <img
              className="imgl2"
              // src={require("../../assets/image/HeaderLoge.png")}
              src={require("../../assets/image/HeaderLogo.png")}
              alt=""
            />
          )}
        </div>
        <Menu
          defaultSelectedKeys={["1"]}
          mode="inline"
          theme="light"
          inlineCollapsed={collapsed}
          onClick={onOpenChange}
          items={items}
        />
        <div
          className={[`Heaer_footer ${collapsed ? "acuiotForet" : ""}`].join(
            ""
          )}
        >
          {/* <div className="Guoeni">
            <div className="Guoeni_img">
              <img src={require("../../assets/image/gng.png")} alt="" />
            </div>
            <div className="Guoeni_coldr">English</div>
          </div> */}
          <International />
          <div className="Guodibu">
            <div className="guodimg">
              <img
                src={require("../../assets/image/Telegram-Negative2.png")}
                alt=""
              />
            </div>
            <div className="guodimg">
              <img
                src={require("../../assets/image/Telegram-Negative1.png")}
                alt=""
              />
            </div>
            <div className="guodimg">
              <img
                src={require("../../assets/image/Telegram-Negative3.png")}
                alt=""
              />
            </div>
          </div>
        </div>
      </Drawer>
    </div>
  );
};

export default Cwallet;
