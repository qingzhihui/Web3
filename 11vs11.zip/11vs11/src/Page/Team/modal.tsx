import {Ref, useImperativeHandle, useState, forwardRef} from "react";
import $ from "jquery"

const Modal = forwardRef((props: {}, ref) => {
  const [title, setTitle] = useState("")
  const [h2, setH2] = useState("")
  const [text, setText] = useState("")

  function open(title: string, h2:string, text: string) {
    setTitle(title)
    setH2(h2)
    setText(text)
    $("#team-modal").fadeIn()
  }

  useImperativeHandle(ref, () => {
    return {
      open: open
    }
  })

  function close() {
    $("#team-modal").fadeOut()
  }

  return (
    <div id="team-modal">
      <div className="close-btn" onClick={close}>X</div>
      <h1>{title}</h1>
      <h2>{h2}</h2>
      <div className="text">
        {text}
      </div>
    </div>
  )
})

export default Modal