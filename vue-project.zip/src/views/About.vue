<template>
    <div class="home">
        <span> 有开始循环了-开端 </span>
        <test-com ref="testcomRef"></test-com>
        <button @click="getSonHander">获取子组件中的数据</button>
    </div>
</template>
<script lang="ts" setup>
import TestCom from "../components/Test2Com.vue"
import { ref, reactive } from 'vue'
const testcomRef = ref()
const getSonHander = () => {
    console.log('获取子组件中的性别', testcomRef.value.sex);
    console.log('获取子组件中的其他信息', testcomRef.value.info);
}
const state = reactive({
    color: 'red'
})
</script>
<style scoped>
span {
    /* 使用v-bind绑定state中的变量 */
    color: v-bind('state.color');
}
</style>