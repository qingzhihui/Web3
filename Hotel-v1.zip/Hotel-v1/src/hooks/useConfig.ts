export interface useMenu {
  key: string;
  label: string;
}
