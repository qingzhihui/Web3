<template>
  <button @click="increment" id="counter">{{ count }}</button>
</template>
<script lang="ts">
import { ref, nextTick } from 'vue'
export default {

  setup() {
    const count = ref(0)
    return {
      count
    }
  },
  methods: {
    async increment() {
      this.count++;
      console.log(document.getElementById('counter')?.textContent)
      await nextTick()
      console.log(document.getElementById('counter')?.textContent)
    }
  },
  mounted() {
    // this.increment()
  }
}
</script>
<style scoped></style>