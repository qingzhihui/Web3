export interface websiteError{
    LogoUrl?:boolean,
    Website?:boolean,
    Facebook?:boolean,
    Twitter?:boolean,
    Github?:boolean,
    Telegram?:boolean,
    Instagram?:boolean,
    Discord?:boolean,
    Youtube?:boolean,
    Reddit?:boolean
}