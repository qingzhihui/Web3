import { differenceInterval } from "../../config/config";
import { formatTime } from "../../utils/util";

// components/TimeConter/TimeConter.ts
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    msg: '我是子组件的值',
    showPopup: false,
    formatter(day: any) {
      const month = day.date.getMonth() + 1;
      const date = day.date.getDate();
      if (month === 5) {
        if (date === 1) {
          day.topInfo = '劳动节';
        } else if (date === 4) {
          day.topInfo = '五四青年节';
        } else if (date === 11) {
          day.text = '今天';
        }
      }
      if (day.type === 'start') {
        day.bottomInfo = '入住';
      } else if (day.type === 'end') {
        day.bottomInfo = '离店';
      }
      return day;
    },
    default: [],
    CalendarData: [],
    decideData: [],
    TimeUoer: "",
    TimeEoer: "",
    weekdayUoer: "",
    weekdayEoer: "",
    Nuier: 0,
    stepperValue: 2,
    roomNumer: 1
  },

  /**
   * 组件的方法列表
   */
  methods: {
    showPopup() {
      this.setData({ showPopup: true });
    },
    onClose() {
      this.setData({ show: false });
    },
    onDisplay() {
      this.setData({ showPopup: true });
    },
    showPopuPonClose() {
      this.setData({ showPopup: false });
    },
    onChange(event: any) {
      this.setData({
        stepperValue: event.detail
      })
    },
    RoonChange(event: any) {
      this.setData({
        roomNumer: event.detail
      })
    },
    formatDate(date: any) {
      date = new Date(date);
      return `${date.getMonth() + 1}/${date.getDate()}`;
    },
    onConfirm() {
      if (this.data.decideData.length === 0) {
        this.triggerEvent('send', {
          date: this.data.CalendarData,
          stepper: this.data.stepperValue,
          roomNumer: this.data.roomNumer
        })
      } else {
        this.triggerEvent('send', {
          date: [
            formatTime(new Date(this.data.decideData[0])),
            formatTime(new Date(this.data.decideData[1]))
          ],
          stepper: this.data.stepperValue,
          roomNumer: this.data.roomNumer
        })
      }
      this.setData({
        showPopup: false
      })
    },
    onSelect(e: any) {
      const Decidata: any = [Date.parse(e.detail[0]),
      Date.parse(e.detail[1])]
      const perdate = differenceInterval(Decidata[0], Decidata[1]);
      this.setData({
        decideData: Decidata,
        TimeUoer: formatTime(new Date(Decidata[0])),
        TimeEoer: formatTime(new Date(Decidata[1])),
        Nuier: perdate,
        weekdayUoer: this.getWeekByDate(Decidata[0]),
        weekdayEoer: this.getWeekByDate(Decidata[1]),
      })
    },
    getWeekByDate(dates: any) {
      let show_day = new Array('周日', '周一', '周二', '周三', '周四', '周五', '周六');
      let date = new Date(dates);
      date.setDate(date.getDate());
      let day = date.getDay();
      return show_day[day];
    },
    getFirstWeek(ent: any) {
      var timeValue: any = [
        Date.parse(ent.startTime),
        Date.parse(ent.EndTime)
      ];
      const StarTimeItem = formatTime(new Date(ent.startTime));
      const JTimeDate = formatTime(new Date(ent.EndTime));
      const perdate = differenceInterval(ent.startTime, ent.EndTime);
      const Calendar: any = [formatTime(new Date(ent.startTime)), formatTime(new Date(ent.EndTime))]
      this.setData({
        default: timeValue,
        Nuier: perdate,
        TimeUoer: StarTimeItem,
        TimeEoer: JTimeDate,
        CalendarData: Calendar,
        weekdayUoer: this.getWeekByDate(StarTimeItem),
        weekdayEoer: this.getWeekByDate(JTimeDate),
        stepperValue: ent.stepperProps,
        roomNumer: ent.roomNumer
      })
    },
  },


  attached: function () {
    var time = new Date()
    const JTimeDate = formatTime(new Date(time.setDate(time.getDate() + 1)))
    var timestamp = Date.parse(new Date().toString())
    const StarTimeItem = formatTime(new Date(timestamp))
    const TriemDate: any = [time.setDate(time.getDate() - 1), timestamp]
    const Calendar: any = [StarTimeItem, JTimeDate]
    const perdate = differenceInterval(StarTimeItem, JTimeDate);
    this.setData({
      default: TriemDate,
      CalendarData: Calendar,
      TimeUoer: StarTimeItem,
      TimeEoer: JTimeDate,
      Nuier: perdate,
      weekdayUoer: this.getWeekByDate(StarTimeItem),
      weekdayEoer: this.getWeekByDate(JTimeDate),
    })
  }
})
