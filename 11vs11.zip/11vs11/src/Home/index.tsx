import "./index.scss"
import Hd from "../Component/Hd";
import {useNavigate} from "react-router-dom";
import $ from "jquery"
import {useEffect} from "react";
import {useTranslation} from "react-i18next";

export default function Home() {
  const navigate = useNavigate()
  const {t} = useTranslation()
  function jump() {
    navigate("/game/referral")
  }

  useEffect(() => {
    console.log(window?.hideModal)
    if (!window?.hideModal) {
      $(".home-modal").fadeIn()
      window.hideModal = true
    }
  }, [])

  function close() {
    $(".home-modal").fadeOut()
  }
  return (
    <div id="home">
      <div className="item">
        <div className="left">
          <h2>{t("home.NFT Limited Offer")}</h2>
          <h1>{t("home.The first batch of 3000 blind boxes is priced at 0.25 BNB")}</h1>
          <h3>{t("home.( The remaining 7000 blind boxes will be sold at the original price of 0.5 BNB )")}</h3>
          <div className="btn-list">
            <div className="btn" onClick={() => jump()}>{t("home.BuyNow")}</div>
            <a className="btn text" href="https://t.me/FBW1_NFT" target="_blank">{t("home.Join Community")}</a>
          </div>
        </div>
        <div className="right">
          <Hd/>
        </div>
      </div>
      <div className="home-modal" style={{display: "none"}}>
        <div className="close-btn" onClick={close}>X</div>
        <div className="title">
          About FootBall World
        </div>
        <div className="content">
          <iframe src="https://www.youtube.com/embed/yA9t97BXtCg" title="YouTube video player"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen/>
        </div>
      </div>
    </div>
  )
}