import React from "react";
import "./index.scss";

const Details = () => {
  return (
    <div className="details">
      <div className="details_nreo">
        <div className="details_nreo_item">
          <div className="prio_item1">
            <div className="prio_item1_nroe">
              <div className="item1_nroe_image">
                <img src={require("@/assets/image/IMAGE-15.png")} alt="" />
              </div>
              <div className="item1_nroe_tieli">
                <div className="nroe_tieli_titer">Aman at Summer Palace</div>
                <div className="nroe_tieli_peoui">King bed room</div>
                <div className="nroe_tieli_fonter">
                  <div className="tieli_fonter_img">
                    <img
                      src={require("@/assets/image/material-symbols_bed-outline.png")}
                      alt=""
                    />
                  </div>
                  <div>1 queen bed (1.8m wide)</div>
                </div>
                <div className="nroe_tieli_fonter">
                  <div className="tieli_fonter_img">
                    <img
                      src={require("@/assets/image/icon-park-outline_people.png")}
                      alt=""
                    />
                  </div>
                  <div>Sleeps two people</div>
                </div>
                <div className="nroe_tieli_fonter">
                  <div className="tieli_fonter_img">
                    <img
                      src={require("@/assets/image/tabler_map-pin.png")}
                      alt=""
                    />
                  </div>
                  <div>1 Gongmenqian Street, China</div>
                </div>
                <div className="nroe_tieli_fonter">
                  <div className="tieli_fonter_img">
                    <img
                      src={require("@/assets/image/icon-park-outline_phone-telephone.png")}
                      alt=""
                    />
                  </div>
                  <div>0756-2486236</div>
                </div>
              </div>
              <div className="item1_nroe_forme">
                <div className="nroe_forme_imga">
                  <img src={require("@/assets/image/AM1.png")} alt="" />
                </div>
                <div className="nroe_forme_tiul">Confirmation code </div>
                <div className="nroe_forme_rpein">#195 123 489</div>
              </div>
            </div>
            <div className="prio_item1_form">
              <div className="item1_form_leubr">
                <div className="form_leubr_img">
                  <img
                    src={require("@/assets/image/ph_calendar-blank.png")}
                    alt=""
                  />
                </div>
                <div className="form_leubr_tile">Friday, December 9</div>
                <div className="form_leubr_xuing"></div>
                <div className="form_leubr_tile">Saturday, December 10</div>
              </div>
              <div className="item1_form_leubr2">
                <div className="form_leubr_img">
                  <img
                    src={require("@/assets/image/icon-park-outline_building-four.png")}
                    alt=""
                  />
                </div>
                <div className="form_leubr_tile">1</div>
                <div className="form_leubr_tile2">room</div>
              </div>
            </div>
          </div>
          <div className="prio_item2">
            <div className="prio_item2_titlei">Guest Information</div>
            <div className="prio_item2_nrio">
              The name of the guest must be exactly the same as the valid ID
              used at check-in.
            </div>
            <div className="prio_item2_fort">
              <div className="lfntrt">Last name: Zhang</div>
              <div className="rebnut">First & middle name: san</div>
            </div>
            <div className="prio_item2_fort">
              <div className="lfntrt">Email: 2114658411521@gmail.com</div>
              <div className="rebnut">Mobile phone: 13754563215</div>
            </div>
          </div>
          <div className="prio_item3">
            <div className="prio_item3_title">
              <div className="item3_title_nro">Price Details</div>
              <div className="item3_title_fonr">Total $ 4,000</div>
            </div>
            <div className="prio_item3_nro">
              <div className="item3_nro_leibt">
                <div className="pricue1">1 room x 1 night</div>
                <div className="pricue2">$ 3650</div>
              </div>
              <div className="item3_nro_ruike">
                <button>already paid</button>
              </div>
            </div>
            <div className="prio_item3_nro">
              <div className="item3_nro_leibt">
                <div className="pricue1">Taxes and Surcharges</div>
                <div className="pricue2">$ 350</div>
              </div>
              <div className="item3_nro_ruike">
                <img src={require('../../assets/image/poek.png')} alt=""  />
                <div>WeChat Pay</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Details;
