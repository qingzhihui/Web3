interface SomeType {
  readonly prop: string;
}

function doSomething(obj: SomeType) {
  console.log(obj.prop);
  // obj.prop = 'hello'
}

interface Home {
  readonly resident: {
    name: string;
    age: number;
  };
}

function visitForBirthday(home: Home) {
  console.log(home.resident.name);
  home.resident.age++;
}

function eivct(home: Home) {
  // home.resident = {
  //     name:'Felix',
  //     age:18
  // }
}

// b别名

interface Persons {
  name: string;
  age: number;
}
interface ReandonlyPerson {
  readonly name: string;
  readonly age: number;
}

let writtablePeson: Persons = {
  name: "123",
  age: 1,
};

let readonlyPerson: ReandonlyPerson = writtablePeson;

console.log(readonlyPerson.age);
writtablePeson.age++;
console.log(readonlyPerson.age);
