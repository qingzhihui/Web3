import React, { useEffect, useState } from "react";
import "./index.scss";
import { ethers } from "ethers";
import Header from "../../components/Header";
import Heues from "../../components/Heues";
import {
  CopyOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
} from "@ant-design/icons";
import { useTranslation } from "react-i18next";
import {
  Invitation_ADDRESS,
  Invitation_ABI,
} from "../../redux/Contract/InvitationContract";
import copy from "copy-to-clipboard";
import gife from "../../assets/image/pro.gif";
import { Meta_ADDRESS, Meta_ABI } from "../../redux/Contract/MetaContract";
import { Modal } from "antd";
declare const window: Window & { ethereum: any };

const Inveta = () => {
  const [Account, setAccount] = useState("暂无钱包地址");
  const [WalletAccount, setWalletAccount] = useState("");
  const [beinping, setBeinping] = useState([]);
  const [beinum, setBeinum] = useState("");
  const [reward, setReward] = useState("");
  const [wenzhineg, setWenzhineg] = useState("");
  const [wenzhineg2, setWenzhineg2] = useState("");
  const [wenzhineg3, setWenzhineg3] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalOpen2, setIsModalOpen2] = useState(false);
  const [isModalOpen3, setIsModalOpen3] = useState(false);
  const { t } = useTranslation();

  const BindeShower = async (signer: any) => {
    const address = await signer.getAddress();
    const InvitationContract = new ethers.Contract(
      Invitation_ADDRESS,
      Invitation_ABI,
      signer
    );
    const MetaContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
    const refferalReward = await MetaContract.getMyPendingRefferalReward(
      address
    );
    setReward(refferalReward.toString());
    const myInviter = await InvitationContract.getFirstGenerationWallet(
      address
    );
    setAccount(myInviter);
    const myInvitees = await InvitationContract.getInvitees(address);
    setBeinping(myInvitees);
    const myInviteNum = await InvitationContract.getInviteNum(address);
    setBeinum(myInviteNum.toString());
  };
  const Poshselser = () => {
    const addr = localStorage.getItem("Meat_addr");
    if (addr !== null && addr !== undefined) {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      setWalletAccount(addr);
      BindeShower(signer);
    } else {
      setWalletAccount("");
    }
  };
  const AddreCoPy = (addr: string) => {
    copy(addr);
  };
  const RewardClikc = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const MetaContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const receive = await MetaContract.receiveReferralRewards();
      setWenzhineg(`${t("Is Receiving...")}`);
      setIsModalOpen(true);
      await receive.wait();
      setIsModalOpen(false);
      setWenzhineg2(`${t("Successfully received")}`);
      setIsModalOpen2(true);
      setTimeout(() => {
        setIsModalOpen2(false);
      }, 2000);
    } catch (error) {
      const BugLoader = JSON.parse(JSON.stringify(error)).error.data.message;
      setWenzhineg3(`${t(BugLoader)}`);
      setIsModalOpen3(true);
      setTimeout(() => {
        setIsModalOpen3(false);
      }, 2000);
    }
  };
  useEffect(() => {
    Poshselser();
  }, []);
  useEffect(() => {
    (window as any).ethereum.on(
      "accountsChanged",
      async function (accounts: any) {
        localStorage.setItem("Meat_addr", accounts[0]);
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        setWalletAccount(accounts[0]);
        BindeShower(signer);
      }
    );
  }, [WalletAccount]);

  return (
    <div className="Inveta">
      <Header MsgIndex="4" />
      <div className="spidried">
        <div className="Yaoqing">
          <div className="speusie_title">
            {`${t("Invitation information")}`}{" "}
          </div>
          <div className="sueisneut">
            <div> {`${t("My superior wallet")}`}：</div>
            <div className="addresInout">
              <div className="sperjsier">
                {Account == "0x0000000000000000000000000000000000000000"
                  ? `${t("No superior wallet")}`
                  : Account}
                {/* {Account.substring(0, 4) + "..." + Account.substring(38, 42)} */}
              </div>
              <div
                className="Febszlu_posiue"
                onClick={() => {
                  AddreCoPy(Account);
                }}
              >
                <CopyOutlined className="copyt" />
              </div>
            </div>
          </div>
          <div className="sueisneut3">
            <div className="yaoqers">
              {`${t("Number of people I invited")}`}：{beinum || 0}
            </div>
            <div className="yaoqers2">
              <div>
                {`${t("My referral reward")}`}：{reward || 0}
              </div>
              {reward === "0" ? (
                <div className="pserobutbnHide">
                  <button disabled>{`${t("receive")}`}</button>
                </div>
              ) : (
                <div className="pserobutbn">
                  <button
                    onClick={() => {
                      RewardClikc();
                    }}
                  >
                    {`${t("receive")}`}
                  </button>
                </div>
              )}
            </div>
          </div>
          <div className="sueisneut2">
            <div className="trioeuis">{`${t("My subordinate wallet")}`}：</div>
            <div className="addresnro">
              {beinping.length === 0 ? (
                <div className="alsernr">{`${t("No subordinate wallet")}`}</div>
              ) : (
                <>
                  {beinping.map((item: any, index: any) => (
                    <div className="addresnro_item" key={index}>
                      <div>
                        {item.substring(0, 4) + "..." + item.substring(34, 42)}
                      </div>
                      <div
                        className="Febszlu_posiue"
                        onClick={() => {
                          AddreCoPy(item);
                        }}
                      >
                        <CopyOutlined className="copyt" />
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      <Heues burl="/Inveta" />
      <Modal
        title=" "
        centered
        bodyStyle={{
          height: "230px",
          padding: 10,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        open={isModalOpen}
        footer={null}
        width={400}
      >
        <div className="Malnro">
          <div className="xgirm">
            <img src={gife} alt="" />
          </div>
          <div className="shorpise">{wenzhineg}</div>
        </div>
      </Modal>
      <Modal
        title=" "
        centered
        bodyStyle={{
          height: "230px",
          padding: 20,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        open={isModalOpen2}
        footer={null}
        width={400}
      >
        <div className="Malnro">
          <div className="xgirm2">
            <CheckCircleOutlined style={{ color: "#ffff", fontSize: "50px" }} />
          </div>
          <div className="shorpise">{wenzhineg2}</div>
        </div>
      </Modal>
      <Modal
        title=" "
        centered
        bodyStyle={{
          height: "230px",
          padding: 20,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        open={isModalOpen3}
        footer={null}
        width={400}
      >
        <div className="Malnro">
          <div className="xgirm2">
            <CloseCircleOutlined style={{ color: "#ffff", fontSize: "50px" }} />
          </div>
          <div className="shorpise">{wenzhineg3}</div>
        </div>
      </Modal>
    </div>
  );
};
export default Inveta;
