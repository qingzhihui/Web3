import React, { useState } from "react";
import "./index.scss";
import Header from "../../components/Header";
import kig from "../../assets/kig.png";
import { DownOutlined } from "@ant-design/icons";
import x1 from "../../assets/x1.png";
import x2 from "../../assets/x2.png";
import x3 from "../../assets/x3.png";
import x4 from "../../assets/x4.png";
import Heues from "../../components/Heues";

function BesRank() {
  return (
    <div className="Rank">
      <div className="mintite">
        <Header />
      </div>
      <div className="cbsieb">
        <div className="RankNero">
          <div className="nrolsie">
            <div className="bdine">
              <div className="disblos">
                <div className="dis_titenr">
                  <div className="titenr_img">
                    <img src={x1} alt="" />
                  </div>
                  <div className="titenr_ns">0xasa1512</div>
                  <div className="titenr_ns">Number of cards owned</div>
                  <div className="titenr_ns">Number</div>
                </div>
              </div>
              <div className="disblos2">
                <div className="dis_titenr">
                  <div className="titenr_img">
                    <img src={x2} alt="" />
                  </div>
                  <div className="titenr_ns">0xasa1512</div>
                  <div className="titenr_ns">Number of cards owned</div>
                  <div className="titenr_ns">Number</div>
                </div>
              </div>
              <div className="disblos3">
                <div className="dis_titenr">
                  <div className="titenr_img">
                    <img src={x3} alt="" />
                  </div>
                  <div className="titenr_ns">0xasa1512</div>
                  <div className="titenr_ns">Number of cards owned</div>
                  <div className="titenr_ns">Number</div>
                </div>
              </div>
              <div className="disblos4">
                <div className="dis_titenr">
                  <div className="titenr_img">
                    <img src={x4} alt="" />
                  </div>
                  <div className="titenr_ns">0xasa1512</div>
                  <div className="titenr_ns">Number of cards owned</div>
                  <div className="titenr_ns">Number</div>
                </div>
              </div>
            </div>
          </div>
          <div className="rnuis"></div>
        </div>
      </div>
      <Heues burl="/Rank" />
    </div>
  );
}

export default BesRank;
