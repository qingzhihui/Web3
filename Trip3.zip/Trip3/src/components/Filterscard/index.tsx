import React from 'react'
import './index.scss'

export default function index() {
  return (
    <div className='fiterscard'>
      <div className='cardleft'>
        <img src={require('@/assets/image/IMAGE9.png')} alt="" />
        <div>China Southern Airlines</div>
      </div>
      <div className='cardmiddle'>
        <div className='middletime'>
          <div className='time'>13:30</div>
          <div className='tnumber'>PEK T3</div>
        </div>
        <div className='middleline'>
          <div className='hous'>11h 10m</div>
          <div className='line'></div>
          <div className='hous'>Direct</div>
        </div>
        <div className='middletime'>
          <div className='time'>13:30</div>
          <div className='tnumber'>PEK T3</div>
        </div>
      </div>
      <div className='cardright'>
        <div>$ 5,480</div>
        <button>Select</button>
      </div>
    </div>
  )
}
