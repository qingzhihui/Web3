import React, { ReactElement, ReactNode } from "react";

interface IndexProps {
  items: any;
  render: any;
}
const Index = ({ items, render }: IndexProps) => {
  const List = <ListItem extends {}>({
    items,
    render,
  }: {
    items: ListItem[];
    render: (item: ListItem) => ReactNode;
  }) => {
    return (
      <ul>
        {items.map((item, index) => (
          <li key={index}>{render(item)}</li>
        ))}
      </ul>
    );
  };

  return (
    <div>
      <List items={items} render={render} />
    </div>
  );
};

export default Index;
