import { NextPage } from "next";
import Router from "next/router";
import routes from "./router/router";
import { useRouter } from "next/router";
import Link from "next/link";

const IndexPage: NextPage = () => {
  // 事件跳转
  // const handleNavigate = () => {
  //   Router.push({
  //     pathname: "/about",
  //     query: { name: "123" },
  //   });
  // };
  const router = useRouter();
  const { message, name } = router.query;
  return (
    <div>
      <p>欢迎进入瞎搞测试Demo系统!</p>
      <p>你好：{name}</p>
      <p>状态：{message}</p>
      {/* <button onClick={handleNavigate}>Go to about page</button> */}
      <nav>
        {routes.map((route) => (
          <div className="routeItem" key={route.path}>
            <Link href={route.path}>
              <span>{route.name}</span>
            </Link>
          </div>
        ))}
      </nav>
    </div>
  );
};

export default IndexPage;
