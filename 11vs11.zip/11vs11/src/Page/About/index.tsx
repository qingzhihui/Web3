import "./index.scss"
import {Swiper, SwiperSlide} from "swiper/react";
import {Autoplay, EffectCards, FreeMode, Navigation} from "swiper";
import "swiper/css"
import 'swiper/css/effect-cards';
import {useNavigate} from "react-router-dom";
import {useTranslation} from "react-i18next";

const NFTS = [
  "Alexander Frei_R.png",
  "Alexander Frei_SR.png",
  "Alexander Frei_SSR.png",
  "Alisson Becker_R.png",
  "Alisson Becker_SR.png",
  "Alisson Becker_SSR.png",
  "Diego Simeone_R.png",
  "Diego Simeone_SR.png",
  "Diego Simeone_SSR.png",
  "Dusan Basta_R.png",
  "Dusan Basta_SR.png",
  "Dusan Basta_SSR.png",
  "Franco Baresi_R.png",
  "Franco Baresi_SR.png",
  "Franco Baresi_SSR.png",
  "Frank Rijkaard_R.png",
  "Frank Rijkaard_SR.png",
  "Frank Rijkaard_SSR.png",
  "Hakan Yakin_R.png",
  "Hakan Yakin_SR.png",
  "Hakan Yakin_SSR.png",
  "Jan Koller_R.png",
  "Jan Koller_SR.png",
  "Jan Koller_SSR.png",
  "Julen Guerrero_R.png",
  "Julen Guerrero_SR.png",
  "Julen Guerrero_SSR.png",
  "Luca Toni_R.png",
  "Luca Toni_SR.png",
  "Luca Toni_SSR.png",
  "Philipp Lahm_R.png",
  "Philipp Lahm_SR.png",
  "Philipp Lahm_SSR.png"
].map(item => {
  return "/newImg/NFT/" + item
})

const SRS = [
  "/newImg/SR/R (2).png",
  "/newImg/SR/SR (2).png",
  "/newImg/SR/SSR (2).png"
]

const clubs = [
  "CD Leganes.png",
  "Deportivo Alaves.png",
  "Eintracht Frankfurt.png",
  "FC Eindhoven.png",
  "Fortuna Dusseldorf.png",
  "Levante UD.png",
  "Nimes Olympique.png",
  "Paris Saint-Germain.png",
  "Real Valladolid.png",
  "Stade de Reims.png",
].map(item => {
  return "/newImg/club/" + item
})

const equipments = [
  "/newImg/equipment/Card_1.png",
  "/newImg/equipment/Card_11.png",
  "/newImg/equipment/Card_111.png",
  "/newImg/equipment/Card_1111.png",
  "/newImg/equipment/Card_11111.png",
  "/newImg/equipment/Card_2.png",
  "/newImg/equipment/Card_22.png",
  "/newImg/equipment/Card_222.png",
  "/newImg/equipment/Card_2222.png",
  "/newImg/equipment/Card_22222.png",
  "/newImg/equipment/Card_3.png",
  "/newImg/equipment/Card_33.png",
  "/newImg/equipment/Card_333.png",
  "/newImg/equipment/Card_3333.png",
  "/newImg/equipment/Card_33333.png",
  "/newImg/equipment/Card_4.png",
  "/newImg/equipment/Card_44.png",
  "/newImg/equipment/Card_444.png",
  "/newImg/equipment/Card_4444.png",
  "/newImg/equipment/Card_44444.png",
  "/newImg/equipment/Card_5.png",
  "/newImg/equipment/Card_55.png",
  "/newImg/equipment/Card_555.png",
  "/newImg/equipment/Card_5555.png",
  "/newImg/equipment/Card_55555.png"
]

const es = [
  "/newImg/e/Equipment Fragments.png",
  "/newImg/e/player fragments.png"
]

export default function About() {
  const {t} = useTranslation()
  const navigate = useNavigate()
  function jump() {
    navigate("/game/get-your-player")
  }

  return (
    <div id="role">
      <div className="top-hd">
        <img className="pre" src="/img/pre.png" alt=""/>
        <img className="next" src="/img/next.png" alt=""/>
        <Swiper
          modules={[Navigation]}
          navigation={{
            prevEl: ".top-hd .pre",
            nextEl: ".top-hd .next"
          }}
        >
        {
          NFTS.map((item, key) => {
            return (
              <SwiperSlide className="item" key={key}>
                <div className="left">
                  <h1>{t("about.start a career")}</h1>
                  <h2>{t("about.Football World is the first soccer competitive game based on BSC, and was developed by a team led by former Electronic Arts employees.")}</h2>
                  <button onClick={() => jump()}>{t("about.PayNow")}</button>
                </div>
                <div className="right">
                  <img src={item} alt=""/>
                </div>
              </SwiperSlide>
            )
          })
        }
        </Swiper>
      </div>
      <div className="each-hd">
        <div className="left">
          <Swiper
            className="swiper"
            modules={[EffectCards]}
            effect="cards"
            cardsEffect={{
              slideShadows: false
            }}
          >
            {
              SRS.map((item, key) => {
                return (
                  <SwiperSlide key={key}>
                    <div className="item">
                      <img src={item} alt=""/>
                    </div>
                  </SwiperSlide>
                )
              })
            }
          </Swiper>
        </div>
        <div className="right">
          <h1>{t("about.Each player has different career attributes")}</h1>
        </div>
      </div>
      <div className="stadium">
        <h1>{t("about.Choose games of different difficulty according to the player's occupation to start the challenge.")}</h1>
        <div className="list">
          <div className="item">
            <img src="/newImg/stadium/1.png" alt=""/>
          </div>
          <div className="item">
            <img src="/newImg/stadium/2.png" alt=""/>
          </div>
          <div className="item">
            <img src="/newImg/stadium/3.png" alt=""/>
          </div>
          <div className="item">
            <img src="/newImg/stadium/4.png" alt=""/>
          </div>
        </div>
      </div>
      <div className="club">
        <h1>{t("about.Create your own football club and start playing.")}</h1>
        <div className="hd">
          <Swiper
            slidesPerView="auto"
            loop
            speed={800}
            autoplay={{
              delay: 500,
              disableOnInteraction: false,
              waitForTransition: false
            }}
            loopedSlides={14}
            freeMode={{
              enabled: true
            }}
            modules={[FreeMode, Autoplay]}
            loopAdditionalSlides={2}
          >
            {
              [...clubs, ...clubs].map((item, key) => {
                return (
                  <SwiperSlide className="item" key={key}>
                    <img src={item} alt=""/>
                  </SwiperSlide>
                )
              })
            }
          </Swiper>
        </div>
      </div>
      <div className="super">
        <div className="left">
          <div className="text-box">
            <h1>{t("about.super rare player")}</h1>
            <h2>{t("about.Acquire super rare players to strengthen your team")}</h2>
          </div>
          <img src="/newImg/NFT/Diego Simeone_SSR.png" alt=""/>
        </div>
        <div className="right">
          <h1>{t("about.Adjust the formation")}</h1>
          <h2>{t("about.The PVP game system will match teams with similar strength to you, adjust the positions of players, and easily win the game.")}</h2>
          <div className="img-box">
            <div className="item">
              <h3>{t("about.Formation Settings")}</h3>
              <img src="/newImg/super/a.png" alt=""/>
            </div>
            <div className="item">
              <h3>{t("about.Formation Settings")}</h3>
              <img src="/newImg/super/b.png" alt=""/>
            </div>
          </div>
        </div>
      </div>
      <div className="teams">
        <div className="left">
          <img src="/newImg/BUSD.png" alt=""/>
        </div>
        <div className="right">
          <h1>{t("about.The top teams at the end of the season are rewarded")}</h1>
          <h2>{t("about.The top three in the season will share 10,000 BUSD, and the top ten will receive a club badge.")}</h2>
        </div>
      </div>
      <div className="equipment">
        <div className="left">
          <h1>{t("about.Upgrade your gear which will increase your odds of winning ")}</h1>
        </div>
        <div className="right">
          <img className="pre" src="/img/pre.png" alt=""/>
          <img className="next" src="/img/next.png" alt=""/>
          <Swiper
            className="hd"
            modules={[Navigation]}
            navigation={{
              prevEl: ".equipment .pre",
              nextEl: ".equipment .next"
            }}
          >
            {
              equipments.map((item, key) => {
                return (
                  <SwiperSlide className="item" key={key}>
                    <img src={item} alt=""/>
                  </SwiperSlide>
                )
              })
            }
          </Swiper>
        </div>
      </div>
      <div className="market">
        <h1>{t("about.Club player signing transfer market")}</h1>
        <h2>{t("about.Here you can temporarily transfer players to other players' clubs for transfer fees")}</h2>
        <img src="/newImg/M.png" alt=""/>
      </div>
      <div className="last">
        <div className="left">
          <h1>{t("about.Player fragments and equipment fragments are very critical props in the game")}</h1>
        </div>
        <div className="right">
          <img className="pre" src="/img/pre.png" alt=""/>
          <img className="next" src="/img/next.png" alt=""/>
          <Swiper
            className="hd"
            modules={[Navigation, Autoplay]}
            loop
            autoplay={{
              delay: 1200
            }}
            navigation={{
              prevEl: ".last .pre",
              nextEl: ".last .next"
            }}
          >
            {
              es.map((item, key) => {
                return (
                  <SwiperSlide key={key} className="item">
                    <img src={item} alt=""/>
                  </SwiperSlide>
                )
              })
            }
          </Swiper>
        </div>
      </div>
    </div>
  )
}