import React, { Component, useEffect, useState } from "react";
import "./index.scss";
import { useHistory } from "react-router-dom";
import { Drawer, Dropdown, Menu } from "antd";
import type { MenuProps } from "antd";
import { ethers } from "ethers";
import type { DrawerProps } from "antd/es/drawer";
import NodeWalletConnect from "@walletconnect/node";
import WalletConnectQRCodeModal from "@walletconnect/qrcode-modal";
import { CloseCircleOutlined, ExportOutlined } from "@ant-design/icons";
import LOGO_10_1 from "../../../src/assets/image/LOGO_10_1.png";
import collection from "../../../src/assets/image/collection.png";
import HeaderHomeImage from "../../assets/image/home.png";
import HeaderAboutUsImage from "../../assets/image/aboutus.png";
import HeaderGameImage from "../../assets/image/game.png";
import HeaderRoadmapImage from "../../assets/image/roadmap.png";
import HeaderIDOImage from "../../assets/image/ido.png";

declare const window: Window & { ethereum: any };

function Index() {
  let history = useHistory();
  const [address, setWalletAccount] = useState("");
  const [isConnectWallet, setisConnectWallet] = useState(false);
  const [showDrawer, setShowDrawer] = useState(false);
  // 设置弹窗弹窗方向
  const [placement, setPlacement] = useState<DrawerProps["placement"]>("right");

  const Mespuser = [
    {
      label: (
        <div className="pserivkie">
          <div className="pserivkie_title"> Disconnect</div>
          <div className="pserivkie_loger">
            {" "}
            <ExportOutlined style={{ fontSize: "16px" }} />
          </div>
        </div>
      ),
      key: "1",
    },
  ];
  const Pisier = [
    {
      name: "HOME",
      url: "/Home",
    },
    {
      name: "ABOUTUS",
      url: "/About",
    },
    {
      name: "ROADMAP",
      url: "/Raod",
    },
    {
      name: "IDO",
      url: "/IDO",
    },
    {
      name: "GAME",
      url: "/Court",
    },
  ];

  const headerList = [
    {
      name: "HOME",
      url: "/Home",
      image: HeaderHomeImage,
    },
    {
      name: "ABOUTUS",
      url: "/About",
      image: HeaderAboutUsImage,
    },
    {
      name: "RAODMAP",
      url: "/Raod",
      image: HeaderRoadmapImage,
    },
    {
      name: "IDO",
      url: "/IDO",
      image: HeaderIDOImage,
    },
    {
      name: "GAME",
      url: "/Court",
      image: HeaderGameImage,
    },
  ];

  // 路由跳转
  const routerPush = (url: any) => {
    console.log(history);
    console.log(history.location.pathname);
    if (url === "/About") {
      let anchorElement = document.getElementById("Anchor");
      if (anchorElement) {
        anchorElement.scrollIntoView({ block: "start", behavior: "smooth" });
      }
    } else {
      history.push(url);
    }
  };
  const MetaMaskConnect = async () => {
    try {
      const { ethereum } = window;
      if (!ethereum) {
        alert("Get MetaMask!");
        return;
      }
      const accounts = await ethereum.request({
        method: "eth_requestAccounts",
      });
      if (accounts[0]) {
        localStorage.setItem("Cone_addr", accounts[0]);
        setWalletAccount(accounts[0]);
        setisConnectWallet(false);
      }
    } catch (error) {
      console.log(error);
    }
  };
  const WalletConnectClick = () => {
    try {
      const walletConnector = new NodeWalletConnect(
        {
          bridge: "https://bridge.walletconnect.org", // Required
        },
        {
          clientMeta: {
            description: "WalletConnect NodeJS Client",
            url: "https://nodejs.org/en/",
            icons: ["https://nodejs.org/static/images/logo.svg"],
            name: "WalletConnect",
          },
        }
      );
      if (!walletConnector.connected) {
        walletConnector.createSession().then(() => {
          const uri = walletConnector.uri;
          WalletConnectQRCodeModal.open(uri, () => {
            console.log("QR Code Modal closed");
          });
        });
      }
      walletConnector.on("connect", (error: any, payload: any) => {
        if (error) {
          throw error;
        }
        WalletConnectQRCodeModal.close();
        const { accounts, chainId } = payload.params[0];
        console.log("链ID ", chainId);
        let myeth = accounts[0];
        localStorage.setItem("Meat_addr", myeth);
      });
    } catch (ex) {
      console.log(ex);
    }
  };
  // 切换网络
  const MetamShow = async () => {
    const provider = window.ethereum;
    const chainId = await provider.request({ method: "eth_chainId" });
    const binanceTestChainId = "0x61";
    if (chainId === binanceTestChainId) {
      MetaMaskConnect();
    } else {
      try {
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: binanceTestChainId }],
        });
        console.log(
          "You have succefully switched to Binance Smart Chain Testnet"
        );
        MetaMaskConnect();
      } catch (switchError: any) {
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [
                {
                  chainId: "0x61",
                  chainName: "Binance Smart Chain Testnet",
                  nativeCurrency: {
                    name: "Binance Test Coin",
                    symbol: "tBNB",
                    decimals: 18,
                  },
                  blockExplorerUrls: ["https://testnet.bscscan.com"],
                  rpcUrls: ["https://data-seed-prebsc-1-s1.binance.org:8545"],
                },
              ],
            });
          } catch (addError) {
            console.error(addError);
          }
        }
        console.log("Failed to switch to the network");
      }
    }
  };
  // 关闭抽屉弹窗
  const closeDrawer = () => {
    setShowDrawer(false);
  };

  const openDrawer = () => {
    setShowDrawer(true);
  };
  const handleMenuClickPuier: MenuProps["onClick"] = (e) => {
    if (e.key == "1") {
      setWalletAccount("");
      window.localStorage.clear();
    }
  };
  const menuPuier = <Menu onClick={handleMenuClickPuier} items={Mespuser} />;

  useEffect(() => {
    const addr = localStorage.getItem("Cone_addr");
    if (addr !== null && addr !== undefined) {
      setWalletAccount(addr);
    } else {
      MetamShow();
    }
  }, []);
  return (
    <>
      <div className="home-header">
        <div className="imgs">
          <img src={LOGO_10_1} alt="" />
        </div>
        <div className="home-navigation">
          {Pisier.map((item: any, index: any) => (
            <div
              key={index}
              onClick={() => {
                routerPush(item.url);
              }}
            >
              {item.name}
            </div>
          ))}
        </div>
        <div className="home-share">
          <div className="Game_Buton">
            {address === "" ? (
              <button
                onClick={() => {
                  setisConnectWallet(true);
                }}
              >
                Connect Wallet
              </button>
            ) : (
              <Dropdown
                overlay={menuPuier}
                placement="bottomRight"
                arrow={{ pointAtCenter: true }}
              >
                <div className="addresbue">
                  {address.substring(0, 4) + "..." + address.substring(38, 42)}
                </div>
              </Dropdown>
            )}
          </div>
          <div
            className="snuieng"
            onClick={() => {
              openDrawer();
            }}
          >
            <img src={collection} alt="" />
          </div>
        </div>

        <Drawer
          placement={placement}
          width={165}
          footerStyle={{ display: "none" }}
          onClose={closeDrawer}
          maskStyle={{ background: "transparent !important" }}
          open={showDrawer}
          extra={
            <div className="Drawer">
              <div>
                {headerList.map((item: any, index: any) => (
                  <div
                    className="DrawerItem"
                    key={index}
                    onClick={() => {
                      routerPush(item.url);
                    }}
                  >
                    <img src={item.image} alt="" className="drawer-item-img" />
                    <div className="drawer-item-name">{item.name}</div>
                  </div>
                ))}
              </div>
            </div>
          }
        ></Drawer>
      </div>
      {/* 连接钱包 */}
      {isConnectWallet ? (
        <div className="pserHuise">
          <div
            className="pserzhes"
            onClick={() => {
              setisConnectWallet(false);
            }}
          ></div>
          <div className="pserNrokuis">
            <div className="pserNrokuis_title">
              <div>Connect Wallet</div>
              <div
                className="cposien"
                onClick={() => {
                  setisConnectWallet(false);
                }}
              >
                <CloseCircleOutlined
                  style={{
                    fontSize: "30px",
                  }}
                />
              </div>
            </div>
            <div className="pserNrokuis_nrip">
              <div className="pserNrokuis_nrip_left">
                <div className="nusiepser">
                  <img src={require("../../assets/image/nmsie.gif")} alt="" />
                  <div className="scponst">
                    Connect your Wallet to log in to the website
                  </div>
                </div>
              </div>
              <div className="pserNrokuis_nrip_reft">
                <div
                  className="nrip_reft_item"
                  onClick={() => {
                    MetamShow();
                  }}
                >
                  <img src={require("../../assets/image/mar.png")} alt="" />
                  <div>MetaMask</div>
                </div>
                <div
                  className="nrip_reft_item"
                  onClick={() => {
                    WalletConnectClick();
                  }}
                >
                  <img src={require("../../assets/image/war.png")} alt="" />
                  <div>WalletConnect</div>
                </div>
                <div
                  className="nrip_reft_item"
                  onClick={() => {
                    MetaMaskConnect();
                  }}
                >
                  <img src={require("../../assets/image/tar.png")} alt="" />
                  <div>TokenPocket</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  );
}

export default Index;
