import React, { useEffect } from "react";
import { useMoralis } from "react-moralis";
import Header from "../../components/Header";
import "./index.scss";
import Heues from "../../components/Heues";

function BesAbout() {
  return (
    <div className="bisntl">
      <Header />
      <div className="dbeili">
        <div className="nueviel">
          <div className="titlei1"></div>
        </div>
        <div className="bsuedibu">
          <div className="dibuItem">
            <div className="ditem1">
              <span>PRIVACY POLICY</span>
            </div>
            <div className="ditem2">
              <span>TERMS OF SERVICE</span>
            </div>
          </div>
          <div className="dibuItem">
            <div  className="ditem3">
              <span>Copyright @ 2022 PONZOPAY.AII rights reserved.</span>
            </div>
          </div>
        </div>
      </div>
      <Heues burl="/About" />
    </div>
  );
}
export default BesAbout;
