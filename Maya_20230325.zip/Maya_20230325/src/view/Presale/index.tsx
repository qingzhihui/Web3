import React, { useEffect, useState, useTransition } from "react";
import "./index.scss";
import "./mobile.scss";
import PresalesContainer from "../../components/PresalesContainer/index";
import {
  getPoolArrayLength,
  getPoolsGetdata,
  SaleDataPienSers,
} from "../../hooks/Presale";
import { Empty } from 'antd';
import { PrivateSalePropsType } from "../../hooks/PrivateSale";

import Loading from "../../components/Loading";
import { useTranslation } from "react-i18next";
declare const window: Window & { ethereum: any };
const Presale: React.FC = () => {
  const [PriveList, setPriveList] = useState<PrivateSalePropsType[]>([]);
  const [presalesloading, setPresalesLoading] = useState<boolean>(false);
  const [isePending, setTransition] = useTransition();

  const { t } = useTranslation();
  const CurrencyContainerShow = async () => {
    try {
      setPresalesLoading(true);
      Promise.all([getPoolArrayLength(), getPoolsGetdata()])
        .then(async (resolve) => {
          const getPrivateListData = await SaleDataPienSers(
            resolve[0],
            resolve[1]
          );
          setTransition(() => {
            setPriveList((DataListItem: PrivateSalePropsType[]) => {
              setPresalesLoading(false);
              return (DataListItem = getPrivateListData);
            });
          });
        })
        .catch((error) => {
          setPresalesLoading(false);
        });
    } catch (error) {
      setPresalesLoading(false);
    }
  };
  useEffect(() => { }, [PriveList]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        CurrencyContainerShow();
      }
    }

  }, []);
  return (
    <div className="presale">
      <div className="presale-content">
        <div className="presale-title">{`${t("Current Presales")}`}</div>
        {presalesloading ? (
          <div className="presale-loading">
            <Loading></Loading>
          </div>
        ) : (
          <>
            {PriveList.length > 0 ? (
              <PresalesContainer tokenlist={PriveList} />
            ) : (
              <Empty description={false} />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Presale;
