import { Image, Input, Select, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { DollarOutlined, AlignCenterOutlined } from "@ant-design/icons";

// 商城订单界面
const MallOrder = () => {
  interface DataType {
    key: React.Key;
    orderNumber: string; //订单号
    userNick: string; //用户昵称
    userImg: string; //用户头像
    productInformation:string // 商品信息
    realTimeAmount: string // 实时金额
    orderTime: string // 下单时间
    harvestAddress: string //收获地址
    deputy:string // 代理
    status:string // 订单状态
  }
  const data: DataType[] = [
    {
      key: 1,
      orderNumber: "111654947818",
      userNick: "微信用户",
      userImg: "https://img1.baidu.com/it/u=1984993866,886139931&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1679763600&t=f96448b65970f307ebe451847a2a0315",
      productInformation: "任意门礼品",
      realTimeAmount: "899.00",
      orderTime:"2023-01-01",
      harvestAddress: "海南省三亚市吉阳区12号",
      deputy: "IT长旅",
      status: "已取消",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "序号",
      width: 80,
      render: (_, record,index) => (
        <Space size="middle">
          <span>{index+1}</span>
        </Space>
      ),
    },
    {
      title: "订单号",
      dataIndex: "orderNumber",
      width: 120,
    },
    {
      title: "用户昵称",
      dataIndex: "userNick",
      width: 120,
    },
    {
      title: "用户头像",
      width: 80,
      render: (_, record) => (
        <Space size="middle">
          <Image width={60} height={50} src={record.userImg} />
        </Space>
      ),
    },

    {
      title: "商品信息",
      dataIndex: "productInformation",
      width: 120,
    },
    {
      title: "实时金额",
      width: 100,
      dataIndex: "realTimeAmount",
    },
    {
      title: "下单时间",
      // width:120,
      dataIndex: "orderTime",
    },
    {
      title: "收获地址",
      // width:120,
      dataIndex: "harvestAddress",
    },

    {
      title: "代理",
      dataIndex: "deputy",
      render: (_text, record) => (
        <Space size="middle">
         <span className="MallOrder_backcolor">{_text}</span>
        </Space>
      ),
    },

    {
      title: "订单状态",
      dataIndex: "status",
      render: (_text, record) => (
        <Space size="middle">
         <span className="MallOrder_status">{_text}</span>
        </Space>
      ),
    },
 
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="MallOrder_memberCursor" onClick={lookover(record)}>
            {/* <FormOutlined /> */}
            <AlignCenterOutlined />
          </span>
          <span className="MallOrder_memberCursor" onClick={drawbackBtn(record)}>
            <DollarOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 头部下拉选择框-内容
  const options1 = [
    {
      value: "1",
      label: "全部",
    },
    {
      value: "2",
      label: "部分",
    },
  ];

  // 头部下拉选择框-内容---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };
  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 查看
  const lookover = (record: any) => {
    return () => {
      console.log("点击了查看");
      console.log(record.key);
    };
  };
  // 退款
  const drawbackBtn = (record: any) => {
    return () => {
      console.log("点击了退款");
      console.log(record.key);
    };
  };

  return (
    <div className="MallOrder_Box">
      <div className="MallOrder_headerBox">
        <div className="MallOrder_headerBox_thread"></div>
        <div className="MallOrder_headerBox_Tit">&nbsp;&nbsp;&nbsp; 商城订单</div>
        <div className="MallOrder_Add_moban">
          <div className="MallOrder_seekBtn" onClick={adminSearch}>
            <Select
              labelInValue
              defaultValue={{ value: "1", label: "全部" }}
              style={{ width: 120 }}
              onChange={handleChange1}
              options={options1}
            />
          </div>
        </div>
      </div>

      <div className="MallOrder_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default MallOrder;
