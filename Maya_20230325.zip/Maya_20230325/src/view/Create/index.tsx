import React, { useEffect } from "react";
import "./index.scss";
import { useTranslation, Trans } from "react-i18next";
const Create = (props: any) => {
  const { t } = useTranslation();
  useEffect(() => {
  });
  return (
    <div className="created">
      <div className="card">
        <div className="title">{`${t("Your token was created!")}`}</div>
        <div className="data">
          <div className="datefirst">{`${t("Name")}`}</div>
          <div className="datetwo">YTT</div>
        </div>
        <div className="data">
          <div className="datefirst">{`${t("Symbol")}`}</div>
          <div className="datetwo">YTT</div>
        </div>
        <div className="data">
          <div className="datefirst">{`${t("Total supply")}`}</div>
          <div className="datetwo">100,000,000</div>
        </div>
        <div className="data">
          <div className="datefirst">{`${t("Address")}`}</div>
          <div className="datetwo">
            0xff29B0A58b43fD4e8B3728Dc59dB87CC3eBb9c92
          </div>
        </div>
        <div className="data">
          <div className="datefirst">{`${t("Address")}`}</div>
          <div className="datetwo">
            0xff29B0A58b43fD4e8B3728Dc59dB87CC3eBb9c92
          </div>
        </div>
        <div className="data">
          <div className="datefirst">{`${t("Address")}`}</div>
          <div className="datetwo">
            0xff29B0A58b43fD4e8B3728Dc59dB87CC3eBb9c92
          </div>
        </div>
        <div className="buttons">
          <button className="dianji">{`${t("View transaction")}`}</button>
          <button className="dianji">{`${t("Copy address")}`}</button>
          <button className="dianji butt">{`${t("Create launchpad")}`}</button>
          <button className="dianji butt">{`${t("Create Fairlaunch")}`}</button>
        </div>
      </div>
      <div className="disclaimer">
        {`${t("Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published.")}`}
      </div>
    </div>
  );
};
export default Create;
