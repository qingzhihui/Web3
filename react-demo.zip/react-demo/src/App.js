import logo from "./logo.svg";
import "./App.css";
import { Button, Container, Row, Col } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { ethers } from "ethers";
import Web3Modal from "web3modal";
import React, { useState, useEffect } from "react";

// web3Modal初始化
const web3Modal = new Web3Modal({
  // 主网（以真钱去做互动的）、测试网（可以拿假钱去做互动）
  network: "https://testnets.opensea.io/", // 想要连的区块链是（主网 / 测试网） //https://testnets.io/
  providerOptions: {}, // 额外设置
});

const contractAddr = "0x925ec768b9064a19d0e66214f16f706cc0bcec7c";
const abi = [
  {
    inputs: [
      {
        internalType: "string",
        name: "_greeting",
        type: "string",
      },
    ],
    stateMutability: "nonpayable",
    type: "constructor",
  },
  {
    inputs: [],
    name: "greet",
    outputs: [
      {
        internalType: "string",
        name: "",
        type: "string",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "_greeting",
        type: "string",
      },
    ],
    name: "setGreeting",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
];

function App() {
  // 连接钱包取得address和 balance
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState("");
  const [ens, setEns] = useState("");
  const [userInput, setUserInput] = useState("");
  const [msg, setMsg] = useState("");
  const [contract, setContract] = useState({});

  // 取前四个后四个（简化）
  const shortenAddr = (addr) => addr.slice(0, 4) + "..." + addr.slice(-4);

  async function init() {
    // 连接上钱包之后instance储存我们钱包相关的连接资讯
    const instance = await web3Modal.connect();
    const provider = new ethers.providers.Web3Provider(instance);
    // 签署协议
    const signer = provider.getSigner();
    console.log(signer);

    // 取到用户的区块域信息
    const addr = await signer.getAddress();
    console.log(addr);
    setAddress(addr); // 加到setAddress中

    // 取到用户的余额
    const bal = await provider.getBalance(addr);
    // 转换解析余额并且加到setBalance中
    setBalance(ethers.utils.formatEther(bal));
    console.log(ethers.utils.formatEther(bal));

    // 初始化合约
    const _contract = new ethers.Contract(contractAddr, abi, signer);
    setContract(_contract);
    window.contract = _contract;

    setEns(await provider.lookupAddress(addr));

  }
  async function getMessage() {
    console.log(contract);
    // 获取greet
    const _msg = await contract.greet();
    setMsg(_msg);
    console.log(_msg);
  }
  async function setMessage(msg) {
    //呼叫contract上面的setGreeting
    await contract.setGreeting(msg);
    //  await getMessage();
  }

  // useEffect(() => {
  //   init();
  // }, []);
  return (
    <div className="App">
      <Container className="mt-5">
        <Row>
          <Col>
            <h3>
              hello {shortenAddr(address)}, {ens}, you have {balance} Ethers.
            </h3>
          </Col>
        </Row>
        <Row>
          <Col>
            <h3>Greet：{msg}</h3>
          </Col>
        </Row>
        <Row className="mt-5">
          <Col>
            <h3>current user input：{userInput}</h3>
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
            />
            <Button
              onClick={() => {
                setMessage(userInput);
              }}
            >
              {" "}
              SetMessage
            </Button>
          </Col>
        </Row>
        <Row>
          <Col>
            <Button
              onClick={() => {
                getMessage();
              }}
            >
              {" "}
              GetMessage
            </Button>
          </Col>
        </Row>
        <Row className="mt-5">
          <Col>
            <Button
              onClick={() => {
                init();
              }}
            >
              Connect wallet
            </Button>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default App;
