import React, { useEffect, useState, useMemo } from "react";
import { unstable_batchedUpdates } from "react-dom";

// 批量更新

const getUserData = () => fetch("/user.json").then((resp) => resp.json());

const Index6 = () => {
  // const [name, setName] = useState<any>({});
  // const [roles, setRoles] = useState<any>();

  const [info, setInfo] = useState({
    name: "",
    roles: [],
  });
  const roleList = useMemo(
    () => Object.keys(info.roles).filter((k: any) => info.roles[k]),
    [info.roles]
  );
  // const [roleList, setRoleList] = useState<any>();

  // useEffect(() => {
  //   console.log(`useEffect ${name} ${roles}`);
  //   if (name && roles) {
  //     //  ?? {}
  //     setRoleList(Object.keys(roles).filter((k) => roles[k]));
  //   }
  // }, [name, roles]);

  // useEffect(() => {
  //   setRoleList(Object.keys(info.roles).filter((k: any) => info.roles[k]));
  // }, [info.roles]);

  const onLoadUser = async () => {
    const data = await getUserData();
    setInfo(data);
    // 同步更新
    // unstable_batchedUpdates(() => {
    // setName(data.name);
    // setRoles(data.roles);
    // });
  };

  // const onLoadUser = () => {
  //   setName("Test User");
  //   setRoles({
  //     editon: true,
  //   });
  // };

  return (
    <div>
      <div>Name:{JSON.stringify(info.name)}</div>
      <div>Roles:{JSON.stringify(info.roles)}</div>
      <div>RoleList:{JSON.stringify(roleList)}</div>
      <button
        onClick={() => {
          onLoadUser();
        }}
      >
        Load User
      </button>
    </div>
  );
};
export default Index6;
