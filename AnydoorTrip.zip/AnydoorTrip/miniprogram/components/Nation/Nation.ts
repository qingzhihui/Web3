import api from '../../config/axios'
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    title: {
      type: String,
      value: ""
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    Picker: false,
    pickerValue: "",
    columns: [],
    state: 1
  },

  /**
   * 组件的方法列表
   */
  methods: {
    PickerBtone(e: any) {
      this.setData({
        Picker: true,
        state: e
      });
    },
    PickerClose() {
      this.setData({ Picker: false });
    },
    PrikerNuButon() {
      this.setData({ Picker: false });
      var piceValue: any = this.data.pickerValue;
      if (piceValue === "") {
        piceValue = this.data.columns[0]
      }
      if (this.data.state === 1) {
        this.triggerEvent('Nation', piceValue)
      } else {
        this.triggerEvent('linDate', piceValue)
      }
    },
    PickeronChange(event: any) {
      const { picker, value, index } = event.detail;
      this.setData({
        pickerValue: value,
      })
    },
  },
  attached: function () {
    api._get('other/phone_country_code').then(res => {
      const columData: any = [];
      res.data.map((item: any) => {
        columData.push(item.chiName)
      })
      this.setData({
        columns: columData
      })
    }).catch(event => {
      console.log(event);
    })
  }
})
