import {
  chat_url
} from "./config";
export const text_request = async (history) => {
  let context = text_handle(history);
  let resoult = await new Promise((resolve, reject) => {
    wx.request({
      url: chat_url,
      method: "POST",
      header: {
        // Cookie: wx.getStorageSync("Cookie")
        "Cookie": "sessionid=5ty4sbr27xrpwrmsyc3kf3kd7cackdz2;"
      },
      data: {
        context: context
      },
      success: res => {
        resolve(res)
      },
      fail: err => {
        reject(err)
      }
    });
  });
  if (resoult.statusCode === 401) {
    wx.setStorageSync("is_login", false);
    wx.navigateTo({
      url: "/pages/index/index"
    });
    return false;
  } else if (resoult.statusCode === 200) {
    return resoult.data.data.text;
  } else {
    return false;
  }
};

const text_handle = (history) => {
  let content = ""
  history.forEach(element => {
    if (element.location === "left") {
      content += `AI:${element.content};\n`
    } else {
      content += `ME:${element.content};\n`
    }
  });
  return content + `AI:`
}