import { useEffect, useState } from "react";
import { CopyOutlined, CheckCircleOutlined } from "@ant-design/icons";
import { useTranslation } from "react-i18next";
import "./index.scss";
import "./mobile.scss";
import copy from "copy-to-clipboard";
import { InstancedContract, ObtainAddress } from "../../hooks/config";
import { INVITE_ABI, INVITE_ADDR } from "../../config/abi/inviteContract";
import { wagmiState } from "../../hooks/farm";
const MINUTE_MS = 5000;

const Invit = () => {
  const { t } = useTranslation();
  const [value, setValue] = useState("");
  const [addData, setaddData] = useState([]);
  const [subAddrNum, setSubAddrNum] = useState<string>("0");
  const [copyState, setCopyState] = useState(false);
  const [WalletAccount, setWalletAccount] = useState("");

  const useInvitShoe = async () => {
    const NVIContract: any = InstancedContract(INVITE_ADDR, INVITE_ABI);
    const UserAddress = await ObtainAddress();
    const getUserReferrer = await NVIContract.getUserReferrer(UserAddress?.address);
    const getUserTotalSubardinatesNumber = await NVIContract.getUserTotalSubardinatesNumber(UserAddress?.address);
    setSubAddrNum(getUserTotalSubardinatesNumber.toString());
    const userTotalSubardinates = await NVIContract.getUserTotalSubardinates(UserAddress?.address);
    const AddressData: any = [];
    for (let index = 0; index < Number(getUserTotalSubardinatesNumber.toString()); index++) {
      AddressData.push(userTotalSubardinates[index]);
    }
    setValue((state) => {
      if (getUserReferrer !== "0x0000000000000000000000000000000000000000") {
        return (state = getUserReferrer);
      } else {
        return (state = "");
      }
    });
    setaddData((state) => {
      return (state = AddressData);
    });
  };
  const NroiConClick = () => {
    copy(value);
    setCopyState(true);
    setTimeout(() => {
      setCopyState(false);
    }, 1000)
  };
  useEffect(() => {
    (window as any).ethereum.on(
      "accountsChanged",
      async function (accounts: any) {
        localStorage.setItem("Meat_addr", accounts[0]);
        setWalletAccount(accounts[0]);
        if (wagmiState()) {
          useInvitShoe()
        }
      }
    );
  }, [WalletAccount]);
  useEffect(() => {
    useInvitShoe();
  }, [value, copyState]);
  return (
    <div className="Invit">
      <div className="InvitComponent">
        <div className="InvitComponentFunsei">
          <div className="InvitComponentItem">
            <div className="InvitComponentItemTitle">
              <span> {`${t("Invitation information")}`}</span>
            </div>
            <div className="InvitComponentItemVnri">
              <div className="ItemVnriNrol">
                <div className="ItemVnriNrolTitle">
                  <div className="ItemVnriNrolper">{`${t(
                    "My superior wallet"
                  )}`}</div>
                  <div className="ItemVnriNroInput">
                    <input
                      type="text"
                      disabled
                      value={value}
                      placeholder={`${t("No superior wallet")}`}
                    />
                    {value === "" ? (
                      <></>
                    ) : (
                      <>
                        <div className="ItemVnriNroiCon">
                          <button
                            onClick={() => {
                              NroiConClick();
                            }}
                          >
                            {copyState ? (
                              <CheckCircleOutlined
                                style={{ fontSize: 20, color: "#FFF" }}
                              />
                            ) : (
                              <CopyOutlined
                                style={{ fontSize: 20, color: "#FFF" }}
                              />
                            )}
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
                <div className="ItemVnriFles">
                  {`${t("Number of people I invited")}`}: {subAddrNum}
                </div>
                <div className="ItemVnriDilue">
                  <div className="ItemVnriDilueTitle">
                    {`${t("My subordinate wallet")}`}
                  </div>
                  <div className="ItemVnriDilueNrole">
                    {addData.length === 0 ? (
                      <div className="NdateShw">
                        {`${t("No subordinate wallet")}`}
                      </div>
                    ) : (
                      <>
                        {addData.map((item: any, index: number) => (
                          <div className="ItemVnriDilueNroleItem" key={index}>
                            {item}
                          </div>
                        ))}
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Invit;
