import React, { createContext, useContext, useState } from 'react';

interface ThemeContextType {
  theme: string;
  setTheme: React.Dispatch<React.SetStateAction<string>>;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: '',
  setTheme: () => {},
});

const Index = () => {
  const [theme, setTheme] = useState('light');

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <div>
        <h1>Theme: {theme}</h1>
        <Child />
      </div>
    </ThemeContext.Provider>
  );
};

const Child = () => {
  const { theme, setTheme } = useContext(ThemeContext);
  const handleClick = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
  };

  return (
    <div>
      <button onClick={handleClick}>Toggle Theme</button>
    </div>
  );
};

export default Index;