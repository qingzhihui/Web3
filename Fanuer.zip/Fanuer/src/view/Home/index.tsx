import React from "react";
import axios from "axios";
import { ches } from "@/utils/pro";
import { useEffect } from "react";

function Home() {
  const [state, setState] = useImmer({
    people: [
      {
        name: "马云",
        englishName: "Jack Ma",
      },
      {
        name: "马化腾",
        englishName: "Pony Ma",
      },
      {
        name: "李彦宏",
        englishName: "Robin Li",
      },
    ],
  });
  const ches = async () => {
    const wbd = {
      address: "0x549e18AD92a46EF7567F1f3E602a40c5834B3F8e",
      password: "123456789",
    };
    let data = new FormData();
    data.append("address", "0x549e18AD92a46EF7567F1f3E602a40c5834B3F8e");
    data.append("password", "123456789");
    const res = await axios.post("https://xksk2s.antswap.vip/login", data);
    console.log(res);
  };
  useEffect(() => {
    ches();
  }, []);
  return (
    <div>
      Home
      <button
        onClick={() => {
          ches();
        }}
      >
        ches
      </button>
      <img src={require("@/assets/Antibot-cat.png")} alt="" />
    </div>
  );
}

export default Home;
function useImmer(arg0: { people: { name: string; englishName: string; }[]; }): [any, any] {
  throw new Error("Function not implemented.");
}

