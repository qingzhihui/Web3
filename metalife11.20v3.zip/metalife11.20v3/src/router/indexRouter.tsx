import React, { Component, Suspense } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Home from "../view/Home";
import NFT from "../view/NFT";
import Market from "../view/Market";
import Farm from "../view/Farm";
import Inveta from "../view/Inveta";
import Loading from "../components/Loading";

class indexRouter extends Component {
  render() {
    return (
      <Suspense fallback={<Loading />}>
        <Router>
          <Switch>
            <Route path="/HOME" component={Home} />
            <Route path="/NFT" component={NFT} />
            <Route path="/MARKET" component={Market} />
            <Route path="/FARM" component={Farm} />
            <Route path="/Inveta" component={Inveta} />
            <Redirect from="/" to="/HOME" />
          </Switch>
        </Router>
      </Suspense>
    );
  }
}

export default indexRouter;
