import { GeneratorTokenError } from "../hooks/Errorhandle";

const GeneratorTokenErrorInitState: GeneratorTokenError = {
    NameBlankError: false,
    NameCharactersError: false,
    SymbolBlankError: false,
    SymbolCharactersError: false,
    TotalSupplyBlankError: false,
    TotalSupplyAmountError: false,
    YieldBlankError: false,
    YieldMinError: false,
    YieldMaxError: false,
    LiquidityBlankError: false,
    LiquidityMinError: false,
    LiquidityMaxError: false,
    AddressBlankError: false,
    AddressInvalidError: false,
    PercentBlankError: false,
    PercentMinError: false,
    PercentMaxError: false,
    FeeOverError: false,
};

export {
    GeneratorTokenErrorInitState
};