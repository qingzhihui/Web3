import React from 'react'
import './index.scss'
import { Checkbox, Col, Row, Input } from 'antd';
import type { CheckboxValueType } from 'antd/es/checkbox/Group';
import Exceptionalcard from '@/components/Exceptional_card'

export default function index() {
  const onChange = (checkedValues: CheckboxValueType[]) => {
    console.log('checked = ', checkedValues);
  };
  return (
    <div className='search'>
      <div className='aldult'>
        <div className='aldult_left'>
          <Input placeholder="Bei jing" bordered={false} />
        </div>
        <div className='aldult_right'>
          <div className='addition'>
            <img src={require('@/assets/image/user.png')} alt="" />
            <div className='name'>aldult</div>
            <div className='add'>
              <button>-</button>
              <div>0</div>
              <button>+</button>
            </div>
          </div>
          <div className='dates'>
            <img src={require('@/assets/image/ph.png')} alt="" />
            <div className='dates_left'>Friday, December 9</div>
            <div className='line'></div>
            <div className='dates_right'>Saturday, December 10</div>
          </div>
        </div>
      </div>
      <div className='choose'>
        <div className='choos'>
          <Checkbox.Group style={{ width: '85%' }} onChange={onChange}>
            <Row>
              <Col span={6}>
                <Checkbox value="Clean Filters">Clean Filters</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Accor">Accor</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="AMAN">AMAN</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="BVLGARI">BVLGARI</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Four Seasons">Four Seasons</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Hilton">Hilton</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="HYATT">HYATT</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="IHG">IHG</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Kempinski">Kempinski</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Langham">Langham</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Leading">Leading</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Marriott">Marriott</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Peninsula">Peninsula</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Rosewood">Rosewood</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Shangri-la">Shangri-la</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Small Luxury Hotels">Small Luxury Hotels</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="The House">The House</Checkbox>
              </Col>
              <Col span={6}>
                <Checkbox value="Others">Others</Checkbox>
              </Col>
            </Row>
          </Checkbox.Group>
        </div>
        <div className='but'>search</div>
      </div>
      <div className='exceptional'>
        <div className='title'>34 exceptional hotels</div>
        <Exceptionalcard />
        <Exceptionalcard />
        <Exceptionalcard />
        <Exceptionalcard />
        <Exceptionalcard />
      </div>
    </div>
  )
}
