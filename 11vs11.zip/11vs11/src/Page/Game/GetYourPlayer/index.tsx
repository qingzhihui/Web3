import axios from "axios";
import { useEffect, useState } from "react";
import { useGetWeb3 } from "../../../hooks/useGetWeb3";
import { useQuery } from "../../../hooks/useQuery";
import "./index.scss";
import img1 from "./CardPackItem_50.png";
import { ethers } from "ethers";
import Modal from "./modal";
import moment from "moment-timezone";
import { useTranslation } from "react-i18next";

import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../../../redux/Contract/SmartContract";

const duration = moment.duration(
  moment("2022-04-27 20:00")
    .tz("Asia/Shanghai")
    .diff(moment().tz("Asia/Shanghai"))
);

export default function GetYourPlayer() {
  const query = useQuery();
  const { account, instance } = useGetWeb3();
  const [inputValue, setInputValue] = useState("1");

  const [status, setStatus] = useState<
    "loading" | "success" | "error" | "close"
  >("close");

  const [errMessage, setErrMessage] = useState("");
  useEffect(() => {
    const referralLink = query.get("referralLink");
    let isons = referralLink;
    if (referralLink !== null) {
      sessionStorage.setItem("keyRral", JSON.stringify(isons));
    } else {
      sessionStorage.setItem("keyRral", "");
    }
  }, [query, account]);

  function getRandomInt(min: any, max: any) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  const { t } = useTranslation();

  async function buy() {
    if (account) {
      console.log(account);
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const instances = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      );
      const totalSupply = await instances.totalSupply();
      const getPrice = await instances.calculatePrice(totalSupply, inputValue);
      setStatus("loading");
      try {
        const options = { value: getPrice };
        const tx = await instances.mint(20, { value: getPrice });
        await tx.wait();
        setStatus("success");
      } catch (e: any) {
        setErrMessage(e.message);
        setStatus("error");
      }
    } else {
      alert("Please Connect Wallet!");
    }
  }

  const [time, setTime] = useState({
    day: 0,
    minute: 0,
    hour: 0,
    second: 0,
    allS: 0,
  });

  function refreshAllTime() {
    setTime({
      day: duration.days(),
      minute: duration.minutes(),
      hour: duration.hours(),
      second: duration.seconds(),
      allS: duration.asSeconds() < 0 ? 0 : duration.asSeconds(),
    });
  }

  useEffect(() => {
    refreshAllTime();
    let interval = setInterval(() => {
      duration.subtract(1, "seconds");
      refreshAllTime();
      if (duration.asSeconds() <= 0) {
        clearInterval(interval);
      }
    }, 1000);
  }, []);

  const [buyNumSelect, setBuyNumSelect] = useState("1");

  return (
    <div id="GetYourPlayer">
      <h1>{t("game.Get Your Player Now")}</h1>
      {time.allS > 0 ? (
        <div className="time-box">
          <div className="title">COMING SOON</div>
          <div className="times">
            <div className="time-item">
              <div className="num">{time.day}</div>
              <div className="name">DAY</div>
            </div>
            <div className="time-item">
              <div className="num">{time.hour}</div>
              <div className="name">HOUR</div>
            </div>
            <div className="time-item">
              <div className="num">{time.minute}</div>
              <div className="name">MINUTE</div>
            </div>
            <div className="time-item">
              <div className="num">{time.second}</div>
              <div className="name">SECOND</div>
            </div>
          </div>
        </div>
      ) : (
        <>
          <img src={img1} alt="" />
          <div className="select-num">
            <div
              className={`select-item ${buyNumSelect === "1" ? "active" : ""}`}
              onClick={() => {
                setBuyNumSelect("1");
                setInputValue("1");
              }}
            >
              1
            </div>
            <div
              className={`select-item ${buyNumSelect === "5" ? "active" : ""}`}
              onClick={() => {
                setBuyNumSelect("5");
                setInputValue("5");
              }}
            >
              5
            </div>
            <div
              className={`select-item ${buyNumSelect === "10" ? "active" : ""}`}
              onClick={() => {
                setBuyNumSelect("10");
                setInputValue("10");
              }}
            >
              10
            </div>
            <div
              className={`select-item ${
                buyNumSelect === "custom" ? "active" : ""
              }`}
              onClick={() => setBuyNumSelect("custom")}
            >
              {t("game.custom")}
            </div>
          </div>
          {buyNumSelect === "custom" ? (
            <div className="inpusbs">
              <input
                type="text"
                placeholder="Enter quantity"
                value={inputValue}
                onChange={(e) => {
                  setInputValue(e.target.value);
                }}
              />
            </div>
          ) : null}
          <button className="common-btn" onClick={buy}>
            {t("game.Buy NOW")}
          </button>
        </>
      )}
      {/*<button className="common-btn">Merge UR Player</button>*/}
      {/*<button className="btn">NFB Redeem</button>*/}
      <Modal errMessage={errMessage} status={status} setStatus={setStatus} />
    </div>
  );
}
