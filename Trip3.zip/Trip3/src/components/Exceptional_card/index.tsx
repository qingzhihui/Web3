import React from 'react'
import './index.scss'

export default function index() {
  return (
    <div className='exceptionalcard'>
      <img src={require('@/assets/image/room.png')} alt="" className='imgs' />
      <div className='cardright'>
        <div className='info'>
          <div className='palace'>Aman at Summer Palace</div>
          <div className='popover'>
            <div className='one'>Tasty</div>
            <div className='two'>Business</div>
            <div className='three'>City ​​View</div>
          </div>
          <div className='imgss'>
            <img src={require('@/assets/image/iconoir.png')} alt="" />
            <img src={require('@/assets/image/healthicons.png')} alt="" />
            <img src={require('@/assets/image/ic.png')} alt="" />
            <img src={require('@/assets/image/bi.png')} alt="" />
            <img src={require('@/assets/image/grommet.png')} alt="" />
            <img src={require('@/assets/image/fluen22.png')} alt="" />
          </div>
          <div className='money'>$4,000 / night</div>
        </div>
        <div className='button'>
          <img src={require('@/assets/image/am.png')} alt="" />
          <button>Book Now</button>
        </div>
      </div>
    </div>
  )
}
