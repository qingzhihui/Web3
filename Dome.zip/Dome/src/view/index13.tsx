import React, { useCallback, useState } from "react";

function MyComponent() {
  const [count, setCount] = useState(0);
  const [ches, setChes] = useState(0);

  const handleClick = useCallback(() => {
    // 使用 count 进行处理
    console.log(count);
    setChes((state) => state + 1);
  }, [count]); // count 作为依赖

  return (
    <div>
      <p>Count: {count}</p>
      <p>ches: {ches}</p>
      <button onClick={handleClick}>Click me</button>
    </div>
  );
}

export default MyComponent;
