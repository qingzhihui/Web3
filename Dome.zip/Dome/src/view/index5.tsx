import React, { useState, memo, useMemo, useCallback } from "react";

// Mastering React Memo(备忘录)

function Swatch({ params, onClick }: any) {
  console.log(`Swatch ${params.color}`);
  return (
    <div
      style={{ margin: 2, width: 75, height: 75, background: params.color }}
      onClick={onClick}
    ></div>
  );
}
// memo是一个高阶组件，所以你给他一个组件，他包装他并且创建另一个组件，在这种情况下，他被称为备忘录样本

// 这里为备忘录提供第二个函数，第二个函数告诉备忘录是否重新渲染，然后你得到给定之前的props和下一个props做比较
// 你所做的基本上是说如果之前的提示等于下一个props那么就返回true， 我们可以看到我们的记忆保持因为，
// 现在我们正在查看对象的内部并再次对这两个字符串进行原始比较
// const MemoedSwatch = memo(Swatch, (prevProps, nextProps) => {
//   return prevProps.params.color === nextProps.params.color;
// });
const MemoedSwatch = memo(Swatch);

const Index = () => {
  const [color, setColor] = useState("red");
  const [appRebderIndex, setAppRebderIndex] = useState(0);
  console.log(`App rendered ${appRebderIndex}`);

  // 和with使用备忘录我们可以有效的做同样的事情所以通过使用备忘录创建一个新的参数
  // 他会返回一个具有颜色的对象并且只有在颜色改变时才会重新运行现在让我们将参数发送到参数上
  // 然后我们再次渲染应用程序并冷却我们的memoization持有的原因是当这个依赖数组没有改变时，memo的作用
  // 是返回给你与之前完全相同的结果，在这种情况下是完全相同的对象引用，这对于数组来说非常重要， 如果
  // 有引用完整性，那么你想要返回完全相同的的引用的对象包括备忘录函数还包括依赖数组

  // 所以我们经常遇到一个问题是我们应该使用一个用过的备忘录吗
  // const value = useMemo(() => number1 + number2, [number1, number2]);
  // 他取决于输出和你作为输入带来的东西所以在这种情况下我们正在生成一个新数字所以
  // 我们采用两个数字我们只是生成一个新的数字并且当该数字发生变化时我们会改变所以,实际上是
  // useMemo 的一个糟糕案例,你真正应该做的只是把这个计算直接放在哪里,所以为什么这是一个原始值和一个原始
  // 值,一个数字,一个布尔值或一个字符串总是要比较value 所以没有从这个使用备忘录中获得任何价值,
  // 你只是付出了性能开销来查看这个依赖,数组并运行这个函数并缓存结果
  // const value =  number1 + number2;

  // 对于字符串来说类似的东西所以我们正在创建这里的字符串我们在第一次最后一次更改时更改字符串,
  // 我们正在为此创建一个原始值
  // const value = useMemo(()=>{
  //   `${first} ${last}`,
  //   [first,last]
  // })
  // 实际上你应该做的只是再次将其放入行中
  // const value = `${first} ${last}`

  // 我们使用reduce对一堆数字求和,我们采用累计器,我们添加这里的值,我们从0开始,这会给
  // 我们这个数组中所有数字的总和,将数字作为我们的输入,我们再次创建原始值我们在这里
  // 做缓存是可以的,因为我们不 不知道这个数字有多大,所以在这种情况下,他实际只是一个潜在的性能
  // 优化,所以我们只是确保我们只是在数字发生变化的时候才实际计算这个值,这意味着
  // 每次我们重新渲染 我们不会一遍又一遍的运行这个reduce所以这是对used memo的一个还好的使用,
  // const value = useMemo(()=>numbers.reduce(a,v)=>a+var,0),[numbers]);

  // 在这种情况 used mome 的一个很好的使用 在这种情况下我们返回一个数组,我们总是建议在返回数组
  // 或对象时使用use memo 我们通过当前数字并将他们映射乘100来创建改数组然后我们对数字有依赖性
  // 所以这是一个可靠的的使用备忘录,我们正在返回一个重要的数组并且我们正在做一些事情,可能会很复杂,
  // 我们会受到性能影响.
  // const multipliedValues = useMemo(()=>numbers.map(v = v*100),[numbers]);

  // 这里是used memo 的另一个很好的用途,所以你再次创建一个person对象,在创建数组或对象时使用memo很好,
  // 在这种情况下我们 你只是通过创建一个全名及名字和姓氏的副本来创建一个新人,然后你的依赖数组很好
  // 所以这里又是一个很好的用例，因为你在创建一个对象，并且你想保持引用完整性
  // const person = useMemo(
  //   () => ({
  //     first,
  //     last,
  //     full: `${first} ${last}`,
  //   }),
  //   [first, last]
  // );

  const params = useMemo(() => ({ color }), [color]);

  const onClick = useCallback(() => {}, []);

  return (
    <div>
      <div>
        <button onClick={() => setAppRebderIndex(appRebderIndex + 1)}>
          Re-Render App
        </button>
        <button onClick={() => setColor(color === "red" ? "blue" : "red")}>
          Change Color
        </button>
      </div>
      <div>
        {/* <MemoedSwatch params={{ color }} /> */}
        <MemoedSwatch params={params} onClick={onClick} />
      </div>
    </div>
  );
};

export default Index;
