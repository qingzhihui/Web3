import React from "react";
import { Empty } from "antd";
import "./index.scss";

const NoPasen = () => {
  return (
    <div className="noPasen">
      <Empty
        description="暂无此页面"
        imageStyle={{ width: 300, height: 300 }}
      />
    </div>
  );
};

export default NoPasen;
