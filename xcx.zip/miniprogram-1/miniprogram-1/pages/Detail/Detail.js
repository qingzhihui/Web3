import api from '../../config/api'
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    start: 0,
    current: 0,
    startTouch: '',
    startNum: '0',
    //其中的 视频url(videoUrl) 封面url(videoImageUrl) 头像url(headUrl) 的话大家自己填上就行
    videoList: [],
    touch: false,
    touchStartTime: 0, //触摸开始时间
    touchEndTime: 0, // 触摸结束时间
    touchEbutn: "下一题",



    // 数据
    radio: '0',
    activeNames: ['0'],
    activeNames2: ['0'],
    show2: false,
    show3: false,
    show4: false,
    shistate: 0,

    // 案例笔记
    anid: "",
    value: "",
    message4: "",
    Chadata: [],

    // 佐证
    // 一级
    questionnaireId: 1,
    // 二级
    uestionnaireTwoId: "",
    // 选项id
    optionTableId: "",
    // 佐证内容
    message: "",
    // 用户id
    // adminId: 84,
    // 题目id
    subjectId: "",
    // 添加的id
    musid: "",
    // 展示用户信息
    Beinlist: {},
    // 用户数据
    anBine: {},
    // 问卷ID
    Qusersid: "",
    // 团队ID
    TeamId: "",
    lustr: false,
    BueleList: [],
    beinse: 0,
    Dvalue: "",
    touchShow: true,
    beishow: false,
    //是否触发提交问卷操作 默认不触发
    isSubmint: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var listTem = that.data.videoList;
    for (var i = 0; i < listTem.length; i++) {
      var arr = (listTem[i].quickProjectWorkerTagName).split(',')
      listTem[i].tagnamesArr = arr;
    }
    const adingList = wx.getStorageSync('admin')
    this.setData({
      anBine: adingList,
      Qusersid: options.qusersid,
      TeamId: options.teamId,
      Dvalue: options.quarter
    })

    // 是否到做题时间
    api._get(`ums/umsQuestionnaireHistory/selectCheck/${options.qusersid}`).then(res => {
      console.log(res);
      if (res.data == 1) {
        this.setData({
          beishow: false
        })
      } else {
        this.setData({
          beishow: true
        })
        Toast.fail('还未到做题时间！');
      }
    }).catch(e => {
      console.log(e);
    })


    // 查询所以题目
    api._get(`ums/umsQuestionnaire/questionnaireList?param=3&id=${options.qusersid}&flag=1&teamId=${options.teamId}&userId=${adingList.userId}`).then(res => {
      console.log(res);
      const Buele = [];
      res.data[0].umsOptionTables.map((msg) => {
        if (msg.identification == true) {
          Buele.push(msg.score);
        }
      })
      that.setData({
        videoList: res.data,
        BueleList: Buele
      })
      const bueid = res.data[this.data.current].id;
      const Buelesube = [];
      res.data[this.data.current].umsOptionTables.map((msg) => {
        if (msg.identification == true) {
          Buelesube.push(msg.score);
        }
      })
      api._get(`ums/umsEvidence/selectEvidence/${options.teamId}/${bueid}/${options.userId}/${0}`).then(res => {
        if (res.data == null) {
          this.setData({
            radio: '0',
            message: "",
            anid: "",
            value: "",
            message4: "",
            BueleList: Buelesube,
            beinse: 0
          })
        } else {
          this.setData({
            radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
            message: res.data.content,
            musid: res.data.id,
            BueleList: Buelesube,
            message4: "",
            anid: "",
            value: "",
            beinse: 1
          })
        }
      }).catch(e => {
        console.log(e);
      })
    }).catch(e => {
      console.log(e);
    })
    // 展示用户信息
    api._get(`ums/umsQuestionnaire/getUserAssessmentInformation/${options.xiaID}/${options.qusersid}/${options.teamId}`).then(res => {
      this.setData({
        Beinlist: res.data
      })
    }).catch(e => {
      console.log(e);
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.videoContext = wx.createVideoContext('videoplayer');
    this.setData({
      updateState: true
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  // 下面主要模仿滑动事件
  touchstart: function (e) {
    this.setData({
      touchStartTime: e.timeStamp,
      showGuide: false
    })
    let startTouch = e.changedTouches[0]
    this.setData({
      startTouch: startTouch,
      touch: false
    })
  },
  touchmove: function (e) {
    let Y = e.changedTouches[0].pageY - this.data.startTouch.pageY;
  },
  touchend: function (e) {
    this.setData({
      touchEndTime: e.timeStamp
    })
    this.getDirect(this.data.startTouch, e.changedTouches[0]);
  },
  touchcancel: function (e) {
    this.getDirect(this.data.startTouch, e.changedTouches[0])
  },
  // 计算滑动方向
  getDirect: function (start, end) {
    var X = end.pageX - start.pageX,
      Y = end.pageY - start.pageY;
    if (Math.abs(X) > Math.abs(Y) && X > 0) {} else if (Math.abs(X) > Math.abs(Y) && X < 0) {} else if (Math.abs(Y) > Math.abs(X) && Y > 40) {
      if (this.data.current > 0) {
        this.setData({
          touch: true,
          transitionOver: false
        })
        this.pre()
      } else {
        this.setData({
          current: 0
        })
      }
    } else if (Math.abs(Y) > Math.abs(X) && Y < -40) {
      if (this.data.current < this.data.videoList.length - 2) {
        this.setData({
          touch: true
        })
        this.next()
      } else {
        this.setData({
          current: this.data.videoList.length - 1
        })
        var startNum = parseInt(this.data.startNum) + 5;
        const Buele = [];
        this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
          if (msg.identification == true) {
            Buele.push(msg.score);
          }
        })
        setTimeout(() => {
          const bueid = this.data.videoList[this.data.current].id;
          console.log(bueid);
          api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.anBine.userId}/${0}`).then(res => {
            console.log(res);
            const Buele = [];
            this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
              if (msg.identification == true) {
                Buele.push(msg.score);
              }
            })
            this.setData({
              BueleList: Buele,
            })
            this.setData({
              radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
              message: res.data.content,
              musid: res.data.id,
              beinse: 1
            })
          }).catch(e => {
            console.log(e);

          })
        }, 500)
        this.setData({
          startNum: startNum,
          touchEbutn: "到低了",
          message: "",
          beinse: 0,
          BueleList: Buele,
          touchShow: false
        })
      }
    }
  },

  // 播放上一个
  pre: function () {
    this.setData({
      current: this.data.current - 1,
      touchEbutn: "下一题",
      touchShow: true
    })
    setTimeout(() => {
      const bueid = this.data.videoList[this.data.current].id;
      console.log(bueid);
      api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.anBine.userId}/${0}`).then(res => {
        console.log(res);
        const Buele = [];
        this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
          if (msg.identification == true) {
            Buele.push(msg.score);
          }
        })
        this.setData({
          BueleList: Buele,
        })
        this.setData({
          radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
          message: res.data.content,
          musid: res.data.id,
          beinse: 1,
        })
      }).catch(e => {
        console.log(e);
      })
    }, 500)
  },
  // 播放下一个
  next: function () {
    this.setData({
      current: this.data.current + 1,
    })
    const Buele = [];
    this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
      if (msg.identification == true) {
        Buele.push(msg.score);
      }
    })
    const bueid = this.data.videoList[this.data.current].id;
    api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.anBine.userId}/${0}`).then(res => {
      if (res.data == null) {
        this.setData({
          radio: '0',
          message: "",
          anid: "",
          value: "",
          message4: "",
          BueleList: Buele,
          beinse: 0
        })
      } else {
        this.setData({
          radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
          message: res.data.content,
          musid: res.data.id,
          BueleList: Buele,
          message4: "",
          anid: "",
          value: "",
          beinse: 1
        })
      }
    }).catch(e => {
      console.log(e);
    })
  },

  // 下一题提交
  snsdkue(param) {
    this.setData({
      touch: true,
    })
    if (this.data.beinse == 1) {
      this.next()
    } else {
      if (this.data.radio !== '0') {
        const LInse = {
          questionnaireId: this.data.Qusersid,
          questionnaireTwoId: this.data.uestionnaireTwoId,
          optionTableId: this.data.optionTableId,
          content: this.data.message,
          adminId: this.data.anBine.userId,
          subjectId: this.data.subjectId,
          target: 0,
          teamId: this.data.TeamId
        }
        // 判断该题是不是需要作证的，如果需要就要判断内容是否为空
        const arr = param.currentTarget.dataset.index
        let value = this.data.radio.split(',')[0]
        let status = false;
        arr.map(m => {
          if (m == value) {
            status = true
          }
        })
        if (status) {
          if (LInse.content == '' || LInse.content == null) {
            Toast.fail('该题必须输入作证内容');
            return;
          }
        }
        api._post('ums/umsEvidence/addEvidenceOwn', LInse).then(res => {
          console.log(res)
          if (res.data.submissionStatus == 1) {
            var pages = getCurrentPages();
            var beforePage = pages[pages.length - 2];
            wx.navigateBack({
              url: `../Descrion/Descrion?id=${this.data.Qusersid}&quarter=${this.data.Dvalue}`,
              success: function () {
                beforePage.GetAddressList();
              }
            })
          }
        }).catch(e => {
          console.log(e)
        })
        if (this.data.current < this.data.videoList.length - 2) {
          this.next()
        } else {
          this.setData({
            current: this.data.videoList.length - 1
          })
          setTimeout(() => {
            const bueid = this.data.videoList[this.data.current].id;
            api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.anBine.userId}/${0}`).then(res => {
              const Buele = [];
              this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
                if (msg.identification == true) {
                  Buele.push(msg.score);
                }
              })
              this.setData({
                BueleList: Buele,
              })
              this.setData({
                radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
                message: res.data.content,
                musid: res.data.id,
                beinse: 1
              })
            }).catch(e => {
              console.log(e);
            })
          }, 500)
          var startNum = parseInt(this.data.startNum) + 5;
          this.setData({
            startNum: startNum,
            touchEbutn: "到低了",
            message: "",
            touchShow: false
          })
        }
      } else {
        if (this.data.current < this.data.videoList.length - 2) {
          this.next()
        } else {
          this.setData({
            current: this.data.videoList.length - 1
          })
          setTimeout(() => {
            const bueid = this.data.videoList[this.data.current].id;
            api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.anBine.userId}/${0}`).then(res => {
              const Buele = [];
              this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
                if (msg.identification == true) {
                  Buele.push(msg.score);
                }
              })
              this.setData({
                BueleList: Buele,
              })
              this.setData({
                radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
                message: res.data.content,
                musid: res.data.id,
                beinse: 1
              })
            }).catch(e => {
              console.log(e);
            })
          }, 500)
          var startNum = parseInt(this.data.startNum) + 5;
          this.setData({
            startNum: startNum,
            touchEbutn: "到低了",
            message: "",
            touchShow: false
          })
        }
      }
    }
  },


  // 佐证
  onChange(event) {
    this.setData({
      uestionnaireTwoId: event.currentTarget.dataset.item,
      subjectId: event.currentTarget.dataset.id,
    })
    this.data.videoList.map((item) => {
      if (item.id == event.currentTarget.dataset.id) {
        item.umsOptionTables.map((msg) => {
          if (msg.id == parseInt(event.detail.split(',')[1])) {
            this.setData({
              optionTableId: event.detail.split(',')[1]
            })
            if (msg.identification == true) {
              console.log(event.detail.split(',')[0]);

              setTimeout(() => {
                this.setData({
                  radio: event.detail,
                  show2: true,
                });
              }, 100)
            } else {
              this.setData({
                radio: event.detail.split(',')[0],
                show2: false,
              });
            }
          }
        })
      }
    })
  },
  onChange2(event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  onClickLeft() {
    var pages = getCurrentPages();
    var beforePage = pages[pages.length - 2];
    wx.navigateBack({
      url: `../Descrion/Descrion?id=${this.data.Qusersid}&quarter=${this.data.Dvalue}&touch=${'false'}`,
      success: function () {
        beforePage.GetAddressList();
      }
    })
  },
  // 提交问卷按钮点击操作
  snTindex(param) {
    if (this.data.beishow == false) {
      if (this.data.radio !== '0') {
        const LInse = {
          questionnaireId: this.data.Qusersid,
          questionnaireTwoId: this.data.uestionnaireTwoId,
          optionTableId: this.data.optionTableId,
          content: this.data.message,
          adminId: this.data.anBine.userId,
          subjectId: this.data.subjectId,
          target: 0,
          teamId: this.data.TeamId
        }
        // 判断该题是不是需要作证的，如果需要就要判断内容是否为空
        const arr = param.currentTarget.dataset.index
        let value = this.data.radio.split(',')[0]
        let status = false;
        arr.map(m => {
          if (m == value) {
            status = true
          }
        })
        if (status) {
          if (LInse.content == '' || LInse.content == null) {
            Toast.fail('该题必须输入作证内容');
            return;
          }
        }
        api._post('ums/umsEvidence/addEvidenceOwn', LInse).then(res => {
          console.log(res)
          let status = true;
          if (res.data.submissionStatus != 1) {
            Toast.fail('有待完成的题目');
            status = false;
          }
          this.setData({
            beinse: 1
          })
          //可以提交
          if (status) {
            var pages = getCurrentPages();
            var beforePage = pages[pages.length - 2];
            wx.navigateBack({
              url: `../Descrion/Descrion?id=${this.data.Qusersid}&quarter=${this.data.Dvalue}`,
              success: function () {
                beforePage.GetAddressList();
              }
            })
          }
          //不可以提交 存在没有昨晚的题目
          else {
            Toast.fail('有待完成题目');
            api._get(`ums/umsEvidence/checkSubject/${this.data.Qusersid}/${this.data.anBine.userId}/${this.data.TeamId}/${1}`).then(res => {
              this.data.videoList.map((item) => {
                if (item.id == res.data[0].subjectId) {
                  this.setData({
                    current: this.data.videoList.indexOf(item),
                    beinse: 0,
                    message: ""
                  })
                }
              })
            }).catch(e => {
              console.log(e);
            })
          }
        }).catch(e => {
          console.log(e)
        })
      } else {
        Toast.fail('请完成题目再提交！');
      }
    } else {
      Toast.fail('还未到做题时间！');
    }


  },
  onClose2() {
    this.setData({
      show2: false
    });
  },
  onChangeMessage(event) {
    this.setData({
      message: event.detail
    })
  },
  // 添加佐证
  onCloseZuo() {
    if (this.data.message == '') {
      Toast.fail('请输入佐证');
      this.setData({
        show2: true
      });
    } else {
      this.setData({
        show2: false
      });
    }
  },
  slieslCli() {
    this.setData({
      show3: true
    });
  },
  // 案例标题
  AnonChange(event) {
    this.setData({
      value: event.detail
    })
  },
  //  案例内容
  AnonChange2(event) {
    this.setData({
      message4: event.detail
    })
  },
  Anlishow(e) {
    this.setData({
      show3: true,
      anid: e.currentTarget.dataset.id
    });
  },
  onClose3() {
    this.setData({
      show3: false
    });
  },
  // 添加案例
  onClose3Dug() {
    console.log()
    if (this.data.value !== '' && this.data.message4 !== '') {
      console.log(this.data)
      const anList = {
        subjectId: this.data.anid,
        title: this.data.value,
        content: this.data.message4,
        adminId: this.data.anBine.userId
      }
      console.log(anList)
      api._post('ums/umsCaseNotes/addCaseNote', anList).then(res => {
        this.setData({
          message4: "",
          value: ""
        })
      }).catch(e => {
        console.log(e)
      })
    } else {
      Toast.fail('案例标题或内容为空');
    }

  },
  // 查询案例
  Anlshow4(e) {
    this.setData({
      show4: true
    })
    api._get(`ums/umsCaseNotes/selectCaseNoteById/${this.data.anBine.userId}/${e.currentTarget.dataset.id}`).then(res => {
      const biem = [];
      res.data.map((item) => {
        item.createTime = item.createTime.split('T')[0]
        biem.push(item)
      })
      this.setData({
        Chadata: biem
      })
    }).catch(e => {
      console.log(e)
    })
    this.setData({
      show4: true
    })

  },
  onClose4() {
    this.setData({
      show3: false
    });
  },
  onChanges2(event) {
    this.setData({
      activeNames2: event.detail,
    });
  },
  // 引用案例
  Lisbeani() {
    this.data.Chadata.map((item) => {
      this.setData({
        message: item.content
      })
    })
  },
  onShareAppMessage() {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  }
})