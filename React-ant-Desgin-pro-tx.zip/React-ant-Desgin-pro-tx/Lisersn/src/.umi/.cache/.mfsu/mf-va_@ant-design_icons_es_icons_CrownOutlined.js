import _ from '@ant-design/icons/es/icons/CrownOutlined';
export default _;
