import React from 'react'
import './index.scss'

export default function index() {
  return (
    <div className='simpler'>
      <div className='simplertop'>
        <div className='make'>Make your round-the-world journey simpler and faster, and travel worry-free!</div>
        <div className='cards'>
          <div className='card'>
            <div className='img'><img src={require('@/assets/image/Rectangle16.png')} alt="" /></div>
            <div className='count'>Tourist visa is a kind of visa for going abroad, which is related to…</div>
            <button>check the details -＞</button>
          </div>
          <div className='card'>
            <div className='img'><img src={require('@/assets/image/Rectangle16.png')} alt="" /></div>
            <div className='count'>Tourist visa is a kind of visa for going abroad, which is related to…</div>
            <button>check the details -＞</button>
          </div>
          <div className='card'>
            <div className='img'><img src={require('@/assets/image/Rectangle16.png')} alt="" /></div>
            <div className='count'>Tourist visa is a kind of visa for going abroad, which is related to…</div>
            <button>check the details -＞</button>
          </div>
          <div className='card'>
            <div className='img'><img src={require('@/assets/image/Rectangle16.png')} alt="" /></div>
            <div className='count'>Tourist visa is a kind of visa for going abroad, which is related to…</div>
            <button>check the details -＞</button>
          </div>
        </div>
      </div>
      <div className='simplermiddle'>
        <div className='top'>
          <div className='left'>
            <div className='more'>More than 10 years</div>
            <div className='professional'>of professional team is worthy of your trust</div>
            <div className='countries'>180+ countries travel/study abroad/immigrate/visit relatives/friends/business/visit/work/foreigners come to China/in China</div>
            <div className='helped'>For the last 10 years, We have helped students, business persons, tourists, clients with medical needs to acquire.visas. Besides, we also help with other family based, employment based & investment based Immigration.</div>
          </div>
          <div><img src={require('@/assets/image/Rectangle18.png')} alt="" /></div>
        </div>
        <div className='buttom'>
          <div className='butcard'>
            <div className='number'>4K+</div>
            <div className='counts'>Happy Clients & Students</div>
          </div>
          <div className='butcard'>
            <div className='number'>4K+</div>
            <div className='counts'>Happy Clients & Students</div>
          </div>
          <div className='butcard'>
            <div className='number'>4K+</div>
            <div className='counts'>Happy Clients & Students</div>
          </div>
          <div className='butcard'>
            <div className='number'>4K+</div>
            <div className='counts'>Happy Clients & Students</div>
          </div>
        </div>
      </div>
      <div className='simplerbuttom'>
        <div className='tiile'>Visa country</div>
        <div className='imgstop'>
          <div className='imgs'>
          </div>
        </div>
        <div className='line'></div>
        <div className='imgsbuttom'>
          <div className='imgs'></div>
        </div>
        <div className='world'>"The world is not for seeing It's for walking Go further To get closer to it "</div>
        <button>Apply for a visa now</button>
      </div>
    </div>
  )
}
