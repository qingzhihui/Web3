<template>
  <ul class="list">
    <li class="list-item">1</li>
    <li class="list-item">2</li>
    <li class="list-item">3</li>
    <li class="list-item">4</li>
  </ul>
  <button>复制一份</button>
</template>

<script setup>
var list = document.getElementsByClassName('list')[0];
var listItems = document.querySelectorAll('.list-item');
var btn = document.getElementsByTagName('button')[0];
btn.onclick = function () {
  for (var i = 0; i < listItems.length; i++) {
    var clomed = listItems[i].cloneNode(true);
    list.appendChild(clomed)
  }
}
</script>

<style>

</style>
