// pages/ches/ches.ts
import api from '../../config/axios'
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    totalFee: "",
    motto: 'Hello World',
    userInfo: {},
    openId: ""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },
  bindKeyInput: function (e: any) {
    console.log(e.detail.value.trim())
    this.setData({
      totalFee: e.detail.value.trim()
    })
  },

  pay() {
    api._get(`https://o35683h427.zicp.fun/pay/odrenpay?orderNo=${56425}`).then(res => {
      const data = res.data;
      wx.requestPayment({
        'timeStamp': String(data.timeStamp),
        'nonceStr': data.nonceStr,
        'package': data.package,
        'signType': data.signType,
        'paySign': data.paySign,
        'success': function (res) {
          console.log('success', res);
          wx.showToast({ icon: 'success', title: '支付成功' })
        }, 'fail': function (res) {
          console.log('pay fail', res)
          wx.showToast({ icon: 'none', title: '支付失败' })
        },
        'complete': function (res) {
          console.log('pay complete', res)
        }
      })
    }).catch(e => {
      console.log(e);
    })

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  handleContact(e: any) {
    console.log(e.detail.path)
    console.log(e.detail.query)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})