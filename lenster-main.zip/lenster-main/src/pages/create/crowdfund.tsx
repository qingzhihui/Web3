import Create from '@components/Crowdfund/Create'

export default Create
