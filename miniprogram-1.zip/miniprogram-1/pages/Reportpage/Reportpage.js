// pages/Reports/Reports.js
import api from '../../config/api'
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    radio: '0',
    message3: "",
    message4: "",
    show3: false,
    listKuData: [],
    arrLIne: {},
    tid: "", // 用户编号
    zid: "", // 团队编号
    quid: "", // 问卷编号
    zuh: "请点击确认无异，如不确定，三天后自动确认。",
    bshow: true,
    show: false
  },
  onClickLeft() {
    wx.navigateBack({
      url: '../HienShow/HienShow',
    })
  },
  onChange(event) {
    if ((event.detail == 2)) {
      setTimeout(() => {
        this.setData({
          radio: event.detail,
          dinping: true,
        });
      }, 300)
    } else {
      setTimeout(() => {
        this.setData({
          radio: event.detail,
          dinping: false,
        });
      }, 300)
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  cosbrtuier(id,tid,zid){
    api._get(`ums/umsEvidence/selectReportNewInfo/${id}/${tid}/${zid}`).then(res => {
      this.setData({
        listKuData: res.data,
        zid: zid,
        tid:tid,
        quid: id
      })
      this.getStatus()
      console.log(res);
    }).catch(e => {
      console.log(e);
    })
    api._get(`ums/umsEvidence/selectReport/${id}/${tid}/${zid}`).then(res => {
      this.setData({
        arrLIne: res.data,
      })
    }).catch(e => {
      console.log(e);
    })
  },
  onLoad: function (options) {
    this.cosbrtuier(options.id,options.tid,options.zid);
  },
  zherits(e) {
    api._post('ums/umsObjection/addObjection', {
      adminId: this.data.tid,
      subjectId: e.currentTarget.dataset.id,
      questionnaireId: this.data.quid,
      ownScore: e.currentTarget.dataset.zp,
      heScore: e.currentTarget.dataset.tp,
      teamId: this.data.zid
    }).then(res => {
      this.cosbrtuier(this.data.quid,this.data.tid,this.data.zid);
    }).catch(e => {
      console.log(e);
    })
  },
  Pksierits(e) {
    api._delete(`ums/umsObjection/delObjection/${this.data.tid}/${e.currentTarget.dataset.id}`).then(res => {
      this.cosbrtuier(this.data.quid,this.data.tid,this.data.zid);
    }).catch(e => {
      console.log(e);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  // 获取报告是否已归档
  getStatus() {
    // tid: "", // 用户编号
    // zid: "", // 团队编号
    // quid: "", // 问卷编号
    api._get(`ums/umsSubmission/selectSubmissionStatus/${this.data.quid}/${this.data.tid}/${this.data.zid}`).then(res => {
      console.log(res)
  
        if(res.data.status == true){
          this.setData({
            zuh: '已归档',
            bshow: false
          })
        }else{
          this.setData({
            zuh: `${res.data.unitValue}自动确认。`,
            bshow: true
          })
        }
    }).catch(e => {
      console.log(e);
    })
  },

  submint() {
    this.setData({
      show: true
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  },
  Anlishow(e) {
    api._get(`ums/umsEvidence/selectEvidenceInfo/${this.data.zid}/${e.currentTarget.dataset.id}/${this.data.tid}`).then(res => {
      this.setData({
        message3: res.data[0].content
      })
    }).catch(e => {
      console.log(e);
    })
    this.setData({
      show3: true
    });
  },
  onClose3() {
    this.setData({
      show3: false
    });
  },
  onConfirm() {
    const adminInfo = wx.getStorageSync('admin')
    api._put(`ums/umsSubmission/updSubmission/${this.data.quid}/${adminInfo.userId}/${this.data.zid}`).then(res => {
      if (res.code == 500) {
        Toast.fail(res.message);
      } else {
        this.getStatus()
      }
    })
  },
  onClose() {
    this.setData({
      show: false
    })
  }
})