<template>

</template>

<script setup>
var str = '100000000000'

//前瞻位
// /(?=(\d{3})+$)/g
// var str = '10000000000'
//10,000,000,000
// const strine = str.replace(/(?=(\d{3})+$)/g, ',');
// console.log(strine)

const strine2 = str.replace(/(?=\B(\d{3})+$)/g, ',');
console.log(strine2)

// /[a-zA-Z](?=\d)/g
</script>

<style>

</style>
