export const apps = [
  {
    id: 'lenster',
    name: 'Lenster',
    logo: 'lenster.svg'
  },
  {
    id: 'phaver',
    name: 'Phaver',
    logo: 'phaver.jpeg'
  },
  {
    id: 'refract',
    name: 'Refract',
    logo: 'refract.jpeg'
  },
  {
    id: 'iris',
    name: 'iris',
    logo: 'iris.png'
  },
  {
    id: 'teaparty',
    name: 'TeaParty',
    logo: 'teaparty.png'
  },
  {
    id: 'lenstube',
    name: 'Lenstube',
    logo: 'lenstube.svg'
  }
]
