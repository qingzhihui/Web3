import api from '../../config/api'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    HisList: [],
    activeNames: ['0'],
    Buelbei: "请选择团队",
    Tbuel: [],
    Lid: "",
    qusersid: ""
  },
  onClickLeft() {
    wx.switchTab({
      url: '../mssage/mssage',
    })
  },
  onHeltail(e) {
    wx.navigateTo({
      url: `../HistDeta/HistDeta?id=${e.currentTarget.id}&qusersid=${this.data.qusersid}&tduid=${this.data.Lid}`,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var that = this;
    const adingList = wx.getStorageSync('admin')
    api._get(`ums/umsTeam/selectUmsTeamList/${adingList.userId}`).then(res => {
      console.log(res);
      that.setData({
        Tbuel: res.data,
        qusersid: options.id
      })
    })
  },
  onChange(event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  onBulenu(e) {
    var that = this;
    api._get(`ums/umsQuestionnaire/selectStatus/${this.data.qusersid}/${e.currentTarget.dataset.id}`).then(res => {
      that.setData({
        HisList: res.data,
        Lid: e.currentTarget.dataset.id,
        Buelbei:e.currentTarget.dataset.name,
        activeNames:['0']
      })
    }).catch(e => {
      console.log(e);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  }
})