import { Button, Checkbox, Form, Input, Select } from "antd";
import "./index.css";

// 分销基础配置界面
const DistributionBasePz = () => {
  const onFinish = (values: any) => {
    console.log("提交内容:", values);
  };

  // 下拉选择框--分销层级--内容
  const options1 = [
    {
      value: "1",
      label: "一级",
    },
    {
      value: "2",
      label: "二级",
    },
    {
      value: "3",
      label: "三级",
    },
  ];

  // 下拉选择-分销层级---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log("选中内容", value);
  };

  // 下拉选择框--成为下线的条件--内容
  const options2 = [
    {
      value: "1",
      label: "首次点击",
    },
    {
      value: "2",
      label: "首次下单",
    },
    {
      value: "3",
      label: "首次付款",
    },
  ];

  // 下拉选择-成为下线的条件---选中内容
  const handleChange2 = (value: { value: string; label: React.ReactNode }) => {
    console.log("选中内容", value);
  };
  // 下拉选择框--申请条件--内容
  const options3 = [
    {
      value: "1",
      label: "申请填表审核",
    },
    {
      value: "2",
      label: "申请无需填表审核",
    },
    {
      value: "3",
      label: "无条件通过",
    },
  ];

  // 下拉选择-申请条件---选中内容
  const handleChange3 = (value: { value: string; label: React.ReactNode }) => {
    console.log("选中内容", value);
  };
  // 下拉选择框--佣金设置--内容
  const options4 = [
    {
      value: "1",
      label: "申请填表审核",
    },
    {
      value: "2",
      label: "申请无需填表审核",
    },
    {
      value: "3",
      label: "无条件通过",
    },
  ];

  // 下拉选择-佣金设置---选中内容
  const handleChange4 = (value: { value: string; label: React.ReactNode }) => {
    console.log("选中内容", value);
  };
  // 下拉选择框--提现方式--内容
  const options5 = [
    {
      value: "1",
      label: "银行卡",
    },
    {
      value: "2",
      label: "余额",
    },
  ];

  // 下拉选择-提现方式---选中内容
  const handleChange5 = (value: { value: string; label: React.ReactNode }) => {
    console.log("选中内容", value);
  };

  return (
    <div className="fxjcpz_Box">
      <div className="fxjcpz_headerBox">
        <div className="fxjcpz_headerBox_thread"></div>
        <div className="fxtx_headerBox_Tit">
          &nbsp;&nbsp;&nbsp; 分销基础配置
        </div>
      </div>

      <div className="fxjcpz_tableBox">
        <Form
          name="basic"
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 15 }}
          style={{ maxWidth: 600 }}
          initialValues={{ remember: true }}
          onFinish={onFinish}
          autoComplete="off"
        >
          <Form.Item label="分销层级" name="title">
            <Select
              className="fxjcpz_select"
              placeholder="请选择"
              labelInValue
              style={{ width: 120 }}
              onChange={handleChange1}
              options={options1}
            />
          </Form.Item>
          <Form.Item label="成为下线的条件" name="condition">
            <Select
              className="fxjcpz_select"
              placeholder="请选择"
              labelInValue
              style={{ width: 120 }}
              onChange={handleChange2}
              options={options2}
            />
          </Form.Item>
          <Form.Item label="申请条件" name="applyFor">
            <Select
              className="fxjcpz_select"
              placeholder="请选择"
              labelInValue
              style={{ width: 120 }}
              onChange={handleChange3}
              options={options3}
            />
          </Form.Item>
          <Form.Item label="佣金设置" name="commissionSettings">
            <Select
              className="fxjcpz_select"
              placeholder="请选择"
              labelInValue
              style={{ width: 120 }}
              onChange={handleChange4}
              options={options4}
            />
          </Form.Item>
          <Form.Item label="提现方式" name="withdrawalMethod">
            <Select
              className="fxjcpz_select"
              placeholder="请选择"
              labelInValue
              style={{ width: 120 }}
              onChange={handleChange5}
              options={options5}
            />
          </Form.Item>

          <Form.Item label="起提额度" name="withdrawalLimit">
            <Input placeholder="请输入起提额度" />
          </Form.Item>
          <Form.Item label="手续费" name="serviceCharge">
            <Input placeholder="请设置手续费" />
          </Form.Item>
          <Form.Item label="分销介绍" name="distributionIntroduction">
            <Input placeholder="请输入分销介绍" />
          </Form.Item>
          <Form.Item label="界面背景" name="pageBackground">
            <Input placeholder="请输入界面背景" />
          </Form.Item>
          <Form.Item label="分销协议" name="fxAgreeOn">
            <Input placeholder="请输入分销协议" />
          </Form.Item>
          <Form.Item wrapperCol={{ offset: 12, span: 12 }}>
            <Button
              className="fxjcpz_btn"
              size="middle"
              type="primary"
              htmlType="submit"
            >
              提交
            </Button>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};

export default DistributionBasePz;
