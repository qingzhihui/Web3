import React, { useState, useEffect } from "react";
import loges from "../../assets/image/loge2.png";
import { useNavigate } from "react-router-dom";
import { Drawer } from "antd";
import { SelectOutlined } from "@ant-design/icons";
import { MenuList, RouterItem, RouterProps } from "../../hooks/config";
const LanguaGeswit = React.lazy(() => import("../LanguaGeswit"));
const ConnectWallet = React.lazy(() => import("../ConnectWallet"));

import icround from "../../assets/image/ic_round-menu-open2.png";
import icroundBox from "../../assets/image/ic_round-menu-open.png";
import "./index.scss";
import { useTranslation } from "react-i18next";

// e: React.ChangeEvent<HTMLInputElement>
interface Props {
  url?: string;
}
const HotnaviGation: React.FC<Props> = ({ url }) => {
  const { t } = useTranslation();
  const [HeaderState, setHeaderState] = useState<number | undefined>(0);
  const [open, setOpen] = useState(false);
  const [urler, setUrler] = useState<any>("");
  const navigate = useNavigate();
  const RouterUrlonCluck = (url: string | any, key: number | undefined) => {
    setHeaderState(key);
    navigate(url);
  };
  const WalletMemoer = React.memo(() => {
    return <ConnectWallet />;
  });
  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  };
  const Biens = (url: any) => {
    setUrler((stateValue: any) => {
      return (stateValue = url);
    });
    navigate(url);
    setOpen(false);
  };
  useEffect(() => {
    setUrler((state: any) => {
      return (state = url);
    });
    RouterItem.map((item: any) => {
      if (item.url === url) {
        setHeaderState(item.key);
      }
    });
  }, [HeaderState]);
  return (
    <div className="Headeer" id="demo">
      <div className="HeaderComponent">
        <div className="HeaderIcones">
          <img src={loges} alt="" className="logimg" />
        </div>
        <div className="HeaderIcoloe">
          <button onClick={() => [showDrawer()]}>
            <img src={icround} className="incimgel" />
          </button>
        </div>
        <div className="HeaderItelei">
          {RouterItem.map((item: RouterProps | any, index: number) => (
            <div
              key={index}
              className={`HeaderItem ${
                HeaderState === item.key ? "action" : ""
              }`}
              onClick={() => {
                RouterUrlonCluck(item.url, item.key);
              }}
            >
              {`${t(item.title)}`}
            </div>
          ))}
        </div>
        <div className="HaderButtonGroup">
          <div className="HaderLoser">
            <LanguaGeswit />
          </div>
          <div className="HaderButton">
            <WalletMemoer />
          </div>
        </div>
      </div>
      <Drawer
        placement="left"
        onClose={onClose}
        open={open}
        closeIcon={<img src={icroundBox} className="incimgel" />}
        className="DrawerClass"
        zIndex={100000}
        maskClosable={true}
        width={200}
        extra={<div className="Headerplie">MY TOKEN</div>}
      >
        <div className="DrawerImtel">
          <div className="nrolse">
            {MenuList.map((item, index) => (
              <div
                className={`nritem ${urler === item.url ? "luser" : ""}`}
                key={index}
                onClick={() => Biens(item.url)}
              >
                <img
                  src={urler == item.url ? item.imgurl : item.image}
                  alt=""
                />
                <div>{`${t(item.title)}`}</div>
              </div>
            ))}
          </div>
          <div className="fuinesoe">
            <div className="fuinesoeTitle">
              <span> {`${t("Contact Us")}`}</span>
            </div>
            <div className="fuinesoeNrol">
              <div className="fuinesoeNrolItem">
              {`${t("Website")}`}：
                <a
                  href="https://my-token.net/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  my-token.net
                </a>
              </div>
              <div className="fuinesoeNrolItem">TG：</div>
              <div className="fuinesoeNrolItem">
                {`${t("Telegraph group")}`}：
              </div>
              <div className="fuinesoeNrolItem">Twitter：</div>
            </div>
          </div>
          <div className="fuoniens">
            <div className="fuoniensImage">
              <img src={loges} alt="" className="logimg" />
            </div>
          </div>
        </div>
      </Drawer>
    </div>
  );
};

export default HotnaviGation;
