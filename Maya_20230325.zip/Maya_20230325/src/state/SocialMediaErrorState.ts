import { SocialMediaError } from "../hooks/Errorhandle";

const SocialMediaErrorState: SocialMediaError = {
    LogoUrl: false,
    Website: false,
    Facebook: false,
    Twitter: false,
    Github: false,
    Telegram: false,
    Instagram: false,
    Discord: false,
    Youtube: false,
    Reddit: false
};

export {
    SocialMediaErrorState
};