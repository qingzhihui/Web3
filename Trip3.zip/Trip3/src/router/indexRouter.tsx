import { HashRouter, Route, Switch, Redirect } from "react-router-dom";
import App from "@/App";
import Home from "@/view/Home";
import Admin from "@/view/Admin";
import Reserve from "@/view/Reserve";
import Visa from "@/view/Visa";
import Flights from "@/view/Flights";
import Hotel from "@/view/Hotel";
import Tickets from "@/view/Tickets";
import Details from "@/view/Details";
import Discovery from "@/view/Discovery";
import Flidetails from "@/view/Flidetails";
import MeRese from '@/view/MeRese'
import HotDetails from '@/view/HotDetails'
import Room from '@/view/Room'
import Search from '@/view/Search'
import Filters from '@/view/Filters'
import Evening from '@/view/Evening'
import Countrydestination from '@/view/Countrydestination'
import Simpler from '@/view/Simpler'
import Register from '@/view/Register'

export default function Router() {
  return (
    <HashRouter>
      <App>
        <Route
          path="/"
          render={() => (
            <Admin>
              <Switch>
                <Route path="/Home" component={Home} />
                <Route path="/Visa" component={Visa} />
                <Route path="/Flights" component={Flights} />
                <Route path="/Hotel" component={Hotel} />
                <Route path="/Tickets" component={Tickets} />
                <Route path="/Discovery" component={Discovery} />
                <Route path="/Reserve" component={Reserve} />
                <Route path="/Details" component={Details} />
                <Route path="/Flidetails" component={Flidetails} />
                <Route path="/MeRese" component={MeRese} />
                <Route path="/HotDetails" component={HotDetails} />
                <Route path="/Room" component={Room} />
                <Route path="/Search" component={Search} />
                <Route path="/Filters" component={Filters} />
                <Route path="/Evening" component={Evening} />
                <Route path="/Countrydestination" component={Countrydestination} />
                <Route path="/Simpler" component={Simpler} />
                <Route path="/Register" component={Register} />
                <Redirect from="/" to="/Simpler" />
              </Switch>
            </Admin>
          )}
        />
      </App>
    </HashRouter>
  );
}
