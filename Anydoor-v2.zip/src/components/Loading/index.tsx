import React from "react";
import "./index.scss";
import { UndoOutlined } from "@ant-design/icons";

const Loading = () => {
  return (
    <div className="loadingBuo">
      <div className="loadingBuoDaive">
        <div><UndoOutlined spin style={{ fontSize: 20, color: "#3296FA" }} /></div>
        <span>加载中...</span>
      </div>
    </div>
  );
};

export default Loading;
