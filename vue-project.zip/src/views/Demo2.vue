<template>
    <button>{{ msg }}</button>
</template>
<script setup lang="ts">
// const props = defineProps({
//     foo: String
// })
// 接口设置，给props定义类型
export interface Props {
    msg?: string
    labels?: string[]
}

// props 设置默认值
withDefaults(defineProps<Props>(), {
    msg: 'hello',
    labels: () => ['one', 'two']
})
// 触发事件
const emit = defineEmits(['change', 'delete'])
emit('change')
</script>
<style scoped></style>