import React from "react";
import "./index.scss";

const Planelist = () => {
  return (
    <div className="Planelist">
      <div className="Planelist_item1">
        <img className="psuieng_image" src={require("@/assets/image/prlan.png")} alt="" />
        <div className="Planelist_item1_priobu">
          <div className="Planelist_item1_image">
            <img src={require("@/assets/image/aircraft_arr.png")} alt="" />
          </div>
          <div className="Planelist_item1_title">
            <div className="Planelist_item1_text">Beijing</div>
            <div className="Planelist_item1_border"></div>
            <div className="Planelist_item1_text">Beijing</div>
          </div>
        </div>
      </div>
      <div className="priobu_cender">
        <div className="priobu_cender_now">
          <div className="priobu_cender_image">
            <img src={require("@/assets/image/tilo.png")} alt="" />
          </div>
          <div className="priobu_cender_title">Air China</div>
        </div>
        <div className="priobu_cender_two">
          <div className="cender_two_nroe">
            <div className="cender_two_title">13:30</div>
            <div className="cender_two_nuke">PEK T3</div>
          </div>
          <div className="cender_two_border">
            <div className="two_border_title">11h 10m</div>
            <div className="two_border">
              <div className="two_border_lent"></div>
              <div className="two_border_cned"></div>
              <div className="two_border_lent"></div>
            </div>
            <div className="two_border_title">Direct</div>
          </div>
          <div className="cender_two_nroe">
            <div className="cender_two_title">17:40</div>
            <div className="cender_two_nuke">CDG T2E</div>
          </div>
        </div>
      </div>
      <div className="speubsei_porbtn">
        <button>Details</button>
      </div>
    </div>
  );
};

export default Planelist;
