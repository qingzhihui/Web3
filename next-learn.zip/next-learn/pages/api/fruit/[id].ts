import { NextApiRequest, NextApiResponse } from "next";

interface Fruit {
  name: string;
}
export default function fruit(
  req: NextApiRequest,
  res: NextApiResponse<Fruit>
) {
  res.status(200).json({
    name: "水果" + req.query.id,
  });
}
