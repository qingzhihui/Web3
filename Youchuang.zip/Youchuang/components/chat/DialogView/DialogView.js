// components/chat/dialogue/dialogue.ts
Component({

  options: {
    multipleSlots: true // 在组件定义时的选项中启用多 slot 支持
  },
  /**
   * 监听器
  */
  observers: {
  },

  /**
   * 组件的属性列表
   */
  properties: {
    dataList: {
      type: Array,
      observer: "dataListUpdate"
    },
    height: {
      type: String
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    
  }
})
