export interface AddDetailsProps {
  key?: number;
  value?: string;
  type?: string;
}
export interface AddcertProps {
  key?: number;
  title?: string;
  certent?: string;
  certdata?: string;
  type?: string;
}

const cellValueData: AddDetailsProps[] = [
  {
    key: 1,
    value: "港澳通行证",
    type:"4"
  },
  {
    key: 2,
    value: "户口簿",
    type:"2"
  },
  {
    key: 3,
    value: "护照",
    type:"3"
  },
  {
    key: 4,
    value: "身份证",
    type:"1"
  }
]
export {
  cellValueData
}