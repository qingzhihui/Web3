// // 你好 世界
// console.log('Hello world');

function greet(person: string, data: Date) {
  console.log(`Hello ${person},today is ${data}.`);
}

greet("小fnag", new Date());

// let msg = 'hello there!'
// msg = 'hello world'
// msg = 100