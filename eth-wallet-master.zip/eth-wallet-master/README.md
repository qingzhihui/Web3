# ETH钱包批量生成助手-可断网离线执行

```
本项目采用vue编写,利用ethers.js官方工具批量生成.生成过程无需联网,支持批量生成,批量导出,此代码仅前端实现,没有与后端交互,请放心使用. ethers.js 对比使用 web3.js 代码量更少，接口也更简洁，推荐优先使用 ethers.js 。不懂的可以百度了解一下,作者也在努力学习中.......
```

## 1. 安装依赖

```
npm install
```

## 2. 运行项目

```
npm run serve
```



ethers.js文档链接:https://learnblockchain.cn/docs/ethers.js/
