import React from 'react';

const Index = () => {
  return <>user index</>;
};
export default Index;
