import React, { useEffect, useState } from "react";
import "./IDO.scss";
import { ethers } from "ethers";
import Header from "../../components/Header";
import { IDO_ADDRESS, IDO_ABI } from "../../redux/Contract/IDoContract";
import { token_ABI } from "../../redux/Contract/tokenContract";
import OrderPopup from "../../components/OrderPopup";
import {
  CloseCircleOutlined,
  RedoOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";
declare const window: Window & { ethereum: any };
function IDO() {
  const [usern, setUsern] = useState(false);
  const [address, setWalletAccount] = useState("");
  const [input1, setInput1] = useState("");
  const [input2, setInput2] = useState("0");
  const [pioshow, serPioshow] = useState(true);
  const [poisObje, setpoisObje] = useState({});
  const [isTimese, setisTimese] = useState(false);
  const [oreTime, setoreTime] = useState({
    gontime: "",
    oreTime: 1,
  });
  const IDoShow = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const adres = await signer.getAddress();
    const IDoContract = new ethers.Contract(IDO_ADDRESS, IDO_ABI, signer);
    const purchaseTokenAddress = await IDoContract.purchaseToken();
    const purchaseTokenContract = new ethers.Contract(
      purchaseTokenAddress,
      token_ABI,
      signer
    );
    const allowance = await purchaseTokenContract.allowance(adres, IDO_ADDRESS);
    const cycle = await IDoContract.cycle();
    const cycleNum = await IDoContract.cycleNum();
    const unlockPercent = await IDoContract.unlockPercent();
    const ido = await IDoContract.ido();
    const purchaseToken = await IDoContract.purchaseToken();
    const price = await IDoContract.price();
    const purchaseCap = await IDoContract.purchaseCap();
    const priceNum = ethers.utils.formatUnits(price.toString(), 18);
    const purchaNum = ethers.utils.formatUnits(purchaseCap.toString(), 18);
    const perlmse = {
      cycle: cycle.toString(),
      cycleNum: cycleNum.toString(),
      unlockPercent: unlockPercent.toString(),
      ido: ido.toString(),
      purchaseToken: purchaseToken.toString(),
      price: priceNum,
      purchaseCap: purchaNum,
    };
    setpoisObje(perlmse);
    if (allowance.toString() === "0") {
      serPioshow(true);
    } else {
      serPioshow(false);
    }
  };
  const handeIDopser = async (value: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const IDoContract = new ethers.Contract(IDO_ADDRESS, IDO_ABI, signer);
    const price = await IDoContract.price();
    const priceNum = ethers.utils.formatUnits(price.toString(), 18);
    const inpire = Number(value) * Number(priceNum);
    setInput2(inpire.toString());
  };
  const SpendInput = (e: any) => {
    setInput1(e.target.value);
    handeIDopser(e.target.value);
  };
  const getInput = (e: any) => {
    setInput1(e.target.value);
  };
  const BuyonClick = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const IDoContract = new ethers.Contract(IDO_ADDRESS, IDO_ABI, signer);
      const amouninput = ethers.utils.parseEther(input2);
      const purchase = await IDoContract.purchase(amouninput.toString());
      setoreTime({ gontime: "兑换中", oreTime: 1 });
      setisTimese(true);
      await purchase.wait();
      setoreTime({ gontime: "兑换成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "兑换失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const handOnApler = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const IDoContract = new ethers.Contract(IDO_ADDRESS, IDO_ABI, signer);
      const purchaseTokenAddress = await IDoContract.purchaseToken();
      const purchaseTokenContract = new ethers.Contract(
        purchaseTokenAddress,
        token_ABI,
        signer
      );
      const approve = await purchaseTokenContract.approve(
        IDO_ADDRESS,
        ethers.constants.MaxUint256
      );
      setoreTime({ gontime: "授权中", oreTime: 1 });
      setisTimese(true);
      await approve.wait();
      serPioshow(false);
      setoreTime({ gontime: "授权成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "授权失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const showHide2 = () => {
    setisTimese(false);
  };
  useEffect(() => {
    const address = localStorage.getItem("Cone_addr");
    if (address !== null && address !== undefined) {
      setWalletAccount(address);
      IDoShow();
    } else {
      setWalletAccount("");
    }
  }, []);
  return (
    <>
      <div className="IDondr">
        <Header />
        <div id="IDO">
          <div className="ido-main">
            <div className="ido-main-left">
              <div className="ido-main-left-top">
                <div className="ido-l-info-top">
                  <div className="token-logo"></div>
                  <div className="token-title">GOALIE CLUB TOKEN</div>
                </div>
                <div className="ido-l-info-middle">
                  <div className="progress">
                    <div>513.8578 USDT / 800 USDT</div>
                  </div>
                </div>
                <div className="ido-l-info-bottom">
                  <div className="ido-l-info-bottom-l">
                    <p>GLC Contract</p>
                    <span>0xe3D...0b2C</span>
                  </div>
                  <div className="ido-l-info-bottom-r">
                    <p>Time Remaining</p>
                    <span>0d 0h 0m 0s</span>
                  </div>
                </div>
              </div>
              <div className="ido-main-left-bottom">
                <div className="ido-main-l-b-title">GLC Tokenomics</div>
                <div className="ido-main-l-b-sub">Lock-up Contract</div>
                <div className="ido-main-l-b-address">
                  {" "}
                  {IDO_ADDRESS.substring(0, 4) +
                    "..." +
                    IDO_ADDRESS.substring(38, 42)}
                </div>
                <ul className="ido-main-l-b-info">
                  <li className="ido-main-l-b-info-item">
                    <i className="ido-main-l-b-info-item-left"></i>
                    <p className="ido-main-l-b-info-item-middle">Total:</p>
                    <span className="ido-main-l-b-info-item-right">
                      {(poisObje as any).cycle}
                    </span>
                  </li>
                  <li className="ido-main-l-b-info-item">
                    <i className="ido-main-l-b-info-item-left"></i>
                    <p className="ido-main-l-b-info-item-middle">IDO: 5%</p>
                    <span className="ido-main-l-b-info-item-right">
                      {/* (Unlock 30% per month) */}
                      {(poisObje as any).cycleNum}
                    </span>
                  </li>
                  <li className="ido-main-l-b-info-item">
                    <i className="ido-main-l-b-info-item-left"></i>
                    <p className="ido-main-l-b-info-item-middle">
                      Liquidity Pool: 9.00%
                    </p>
                    <span className="ido-main-l-b-info-item-right">
                      {/* (Lock 2 Year) */}
                      {(poisObje as any).unlockPercent}
                    </span>
                  </li>
                  <li className="ido-main-l-b-info-item">
                    <i className="ido-main-l-b-info-item-left"></i>
                    <p className="ido-main-l-b-info-item-middle">
                      Marketing: 15%
                    </p>
                    <span className="ido-main-l-b-info-item-right">
                      {/* (First 30%, then unlock 30%, 20%, 20% per month) */}
                      {(poisObje as any).ido}
                    </span>
                  </li>
                  <li className="ido-main-l-b-info-item">
                    <i className="ido-main-l-b-info-item-left"></i>
                    <p className="ido-main-l-b-info-item-middle">
                      Game Reward: 56%
                    </p>
                    <span className="ido-main-l-b-info-item-right">(Lock)</span>
                  </li>
                  <li className="ido-main-l-b-info-item">
                    <i className="ido-main-l-b-info-item-left"></i>
                    <p className="ido-main-l-b-info-item-middle">Team: 15%</p>
                    <span className="ido-main-l-b-info-item-right">
                      {/* (Lock 1 Year) */}
                      {(poisObje as any).purchaseToken}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="ido-main-right">
              <div className="ido-m-r-presale">
                <div className="presale-title">Presale</div>
                <div className="presale-main">
                  <div className="presale-main-input1">
                    <div className="presale-input">
                      <span className="presale-inpue-table">Spend</span>
                      <input
                        type="text"
                        value={input1}
                        placeholder="请输入"
                        onChange={(e: any) => {
                          SpendInput(e);
                        }}
                      />
                      <span className="presale-inpue-type">USDT</span>
                    </div>
                    <div className="presale-max">Max</div>
                  </div>
                  <p>Min:0.1USDT, Max:3USDT</p>
                  <div className="presale-main-input1">
                    <div className="presale-input">
                      <span className="presale-inpue-table">Get</span>
                      <input
                        type="text"
                        value={input2}
                        placeholder="请输入"
                        onChange={(e: any) => {
                          getInput(e);
                        }}
                      />
                      <span className="presale-inpue-type">GLC</span>
                    </div>
                  </div>
                  {pioshow ? (
                    <button
                      className="presale-btn"
                      onClick={() => {
                        handOnApler();
                      }}
                    >
                      授权
                    </button>
                  ) : (
                    <button
                      className="presale-btn"
                      onClick={() => {
                        BuyonClick();
                      }}
                    >
                      BUY
                    </button>
                  )}
                </div>
              </div>
              <div className="ido-m-r-claim">
                <div className="claim-title">Claim GLC Token</div>
                <div className="claim-tab-1">Contribution: 0 GLC (= 0 USDT)</div>
                <div
                  className="claim-tab-2"
                  onClick={() => {
                    setUsern(true);
                  }}
                >
                  My Orders
                </div>
                <div className="claim-fb"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {usern ? (
        <div className="Psioeneis">
          <div className="ensiei">
            <div
              className="nusienzzc"
              onClick={() => {
                setUsern(false);
              }}
            ></div>
          </div>
          <div className="sliuoent">
            <OrderPopup />
          </div>
        </div>
      ) : (
        ""
      )}
      {/* 提示 */}
      {isTimese ? (
        <div className="pserExbuse">
          <div className="pserzhes"></div>
          <div className="pserTise">
            <div className="pserExchange_nro">
              <div className="nriopsr">
                <div className="logding">
                  {(oreTime as any).oreTime === 1 ? (
                    <RedoOutlined spin className="Luiisnr" />
                  ) : (oreTime as any).oreTime === 2 ? (
                    <CheckCircleOutlined className="Luiisnr" />
                  ) : (
                    <CloseCircleOutlined className="Luiisnr" />
                  )}
                </div>
                <div className="Ptimeb">{(oreTime as any).gontime}</div>
              </div>
              <div
                className="gbuiengkum"
                onClick={() => {
                  showHide2();
                }}
              >
                <CloseCircleOutlined
                  style={{
                    color: "#ffff",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  );
}

export default IDO;
