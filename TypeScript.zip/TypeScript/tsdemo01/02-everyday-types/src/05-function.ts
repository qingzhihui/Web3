// 参数类型注释
function greet(name: string) {
  console.log("Hello," + name.toUpperCase() + "!!");
}
// toUpperCase转成大写
greet("Felixlu");

// 返回值类型注释(会自动推断)
function getFavoriteNumber(): number {
  return 26;
}

const names = ["小区", "小王", "小吴"];
// 上下文类型
names.forEach(function (s) {
  console.log(s.toUpperCase());
});

names.forEach((s) => {
  console.log(s.toUpperCase());
});
