<template>
  <div class="container">
    <div class="carousel">
      <div class="item">
        <a href="">
          <img src="../assets/img1.jpg" alt="">
        </a>
      </div>
      <div class="item">
        <a href="">
          <img src="../assets/img2.jpg" alt="">
        </a>
      </div>
      <div class="item">
        <a href="">
          <img src="../assets/img1.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="indicator">
      <span class="active"></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>
</template>

<script setup lang="ts">
var dome = {
  careousel: document.querySelector('.carousel'),
  indicators: document.querySelectorAll('.indicator span')
}

//移动轮播图到几个
function moveTo (index) {
  dome.careousel.style.transform = `translateX(-${index}%)`
//  去除当前选中的指示器
  var active = document.querySelector('.indicator span.active');
  active.classList.remove('active')
//   重新设置选中的指示器
  doms.indicators[index].classList.add('active');
  dome.indicators.forEach(function (item, i) {
    item.onclick = function () {
      moveTo(i);
    }
  })
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.container {
  width: 500px;
  height: 300px;
  margin: 10px auto;
  overflow: hidden;
  position: relative;
}

.container .carousel img {
  width: 500px;
  height: 300px;
}

.carousel {
  width: 100%;
  height: 100%;
  display: flex;
  transition: 0.5s;
}

.indicator {
  position: absolute;
  bottom: 10px;
  display: flex;
  left: 50%;
  transform: translateX(-50%);
}

.indicator span {
  width: 20px;
  height: 20px;
  border: 2px solid #ccc;
  border-radius: 50%;
}

.indicator span.active {
  background: #fff;
  border-color: #fff;
}

</style>
