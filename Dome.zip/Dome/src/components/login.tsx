import React from "react";
import { Text } from "@mantine/core";
import { useQuery } from "react-query";
import useSWR from "swr";

const fetchLogin = () => fetch("/login.json").then((resp) => resp.json());
const fetchUser = (id: any) => fetch(`/${id}.json`).then((resp) => resp.json());

const login = async () => {
  const loginResp = await fetchLogin();
  return await fetchUser(loginResp.id);
};

function Login() {
  // SWR
  const { data: user } = useSWR("login", login);
  // Query
  //   const { data: user } = useQuery("login", login);
  //   const { data: user } = useQuery("user", () => fetchUser(login?.id), {
  //     enabled: login?.id !== undefined,
  //   });
  return <Text>{JSON.stringify(user)}</Text>;
}

export default Login;
