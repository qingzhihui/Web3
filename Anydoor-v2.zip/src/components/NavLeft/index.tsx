import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { RouterConfig, RouterConfigProps } from "../../config/config";
import "./index.scss";

const NavLeft = () => {
  const navigate = useNavigate();
  const [navAction, setnavAction] = useState(0);

  const NavLeftItemoNClick = (data: any) => {
    setnavAction((state: number) => {
      return (state = data.key);
    });
    navigate(`${data.url}`, { state: { id: data.key, url: data.url } });
  };
  return (
    <div className="NavLeftComenser">
      <div className="NavLefInsees">
        <div className="NavLeftTitle">
          <span className="text-gradient">ANYDOOR TPIP</span>
        </div>
        <div className="NavLeftItemLide">
          <div className="NavLeftItemLideData">
            {RouterConfig.map((item: RouterConfigProps, index: number) => (
              <div
                className="NavLeftItemLideData_item"
                key={index}
                onClick={() => {
                  NavLeftItemoNClick(item);
                }}
              >
                <div
                  className={`deData_itemNrole ${
                    navAction === item.key ? "aciton" : ""
                  }`}
                >
                  <img
                    src={`${navAction === item.key ? item.icons : item.icon}`}
                    alt=""
                  />
                  <span>{item.title}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NavLeft;
