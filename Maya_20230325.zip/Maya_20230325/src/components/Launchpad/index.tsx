import React, { useState, useEffect } from "react";
import { Radio, Space, Modal } from "antd";
import type { RadioChangeEvent } from "antd";
import "../../styles/index.css";
import { useHistory, useLocation } from "react-router-dom";
import "../../styles/mobile.css";
import AntiBotToken from "../AntiBotToken";
import { useTranslation } from "react-i18next";
import ButtonLoading from "../../components/ButtonLoading";
import {
  allowance,
  FormatUnitsConver,
  InstancedContract,
  Lineg,
  TokenNameDecimals,
} from "../../hooks/config";
import { BigNumber, ethers } from "ethers";
import { WBENJson } from "../../config/abi/wbenjson";
import { LaunchPadFactoryAddress, LaunchPadFactoryABI, LaunchpadProps } from "../../hooks/launchpad";
import { isAddress } from '../../utils/address'
import InputError from '../../components/InputError'
import { CreateLaunchpadError } from "../../hooks/Errorhandle";
import { EVM } from "evm";
import { LaunchpadValueInitState } from "../../state/LaunchpadValueState";

declare const window: Window & { ethereum: any };

interface Props {
  state: boolean;
}

const Launchpad: React.FC<Props> = () => {
  const { t } = useTranslation();
  let history = useHistory();
  const { state } = useLocation<any>();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [ULieng, setULieng] = useState<Lineg>({});
  const [NameShow, setNameShow] = useState(false);
  const [approveloading, setApproveLoading] = useState<boolean>(false);
  const [showApproveBtn, setShowApproveBtn] = useState(false);
  const [flatFeeShow, setFlatFeeShow] = useState("");
  const [LauchpadList, setLauchpadList] = useState<LaunchpadProps>(LaunchpadValueInitState);
  const [createLaunchpadError, setCreateLaunchpadError] = useState<CreateLaunchpadError>({
    TokenAddressBlankError: false,
    TokenAddressInvalidError: false,
  })
  const setError = (key: string, value: boolean) => {
    setCreateLaunchpadError((olddata: CreateLaunchpadError) => {
      return {
        ...olddata,
        [key]: value
      }
    })
  }
  const CanNext = () => {
    if (!createLaunchpadError.TokenAddressBlankError
      && !createLaunchpadError.TokenAddressInvalidError
      && LauchpadList.inputValue
      && LauchpadList.IcoTokenSymbol
      && LauchpadList.IcoTokenDecimals
    ) {
      return true
    } else {
      return false
    }
  }
  const ChangeCurrency = (e: RadioChangeEvent) => {
    setLauchpadList((olddata: LaunchpadProps) => {
      return {
        ...olddata,
        Radiovalue: e.target.value,
      };
    });
  };
  const ChangeFeeOptions = (e: RadioChangeEvent) => {
    setLauchpadList((olddata: LaunchpadProps) => {
      return {
        ...olddata,
        FeeOptions: e.target.value,
      };
    });
  };
  const ChangeListingOptions = (e: RadioChangeEvent) => {
    setLauchpadList((olddata: LaunchpadProps) => {
      return {
        ...olddata,
        ListingOptions: e.target.value,
      };
    });
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const CreateTokenOnCLick = () => {
    setIsModalOpen(true);
  };
  const onClick = async (value: any) => {
    setLauchpadList((olddata: LaunchpadProps) => {
      return {
        ...olddata,
        inputValue: value,
      };
    });
    const Uline = await TokenNameDecimals(value);
    setULieng((ULiengprevState: Lineg) => {
      return (ULiengprevState = Uline);
    });
    setNameShow((NameShowprevState: boolean) => {
      return (NameShowprevState = true);
    });
    setIsModalOpen(false);
  };
  const TokenAddressValueChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      setLauchpadList((olddata: LaunchpadProps) => {
        if (e.target.value === "") {
          setError("TokenAddressBlankError", true)
        } else {
          setError("TokenAddressBlankError", false)
        }
        if (!isAddress(e.target.value) && e.target.value) {
          setError("TokenAddressInvalidError", true)
        } else {
          setError("TokenAddressInvalidError", false)
        }
        return {
          ...olddata,
          inputValue: e.target.value,
        };
      });
      isVaildAddressOrNot(e.target.value);
    }
  };
  const TokenAddressBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === "") {
        setError("TokenAddressBlankError", true)
      } else {
        setError("TokenAddressBlankError", false)
      }
      if (!isAddress(e.target.value) && e.target.value) {
        setError("TokenAddressInvalidError", true)
      } else {
        setError("TokenAddressInvalidError", false)
      }
      isVaildAddressOrNot(e.target.value);
    }
  }
  const isVaildAddressOrNot = async (address: any) => {
    if (address !== undefined && address !== '') {
      if (ethers.utils.isAddress(address)) {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        let code = await provider.getCode(address);
        const evm = new EVM(code);
        const getFunctions = evm.getFunctions();
        if (getFunctions.includes("balanceOf(address)")
          && getFunctions.includes("totalSupply()")
          && getFunctions.includes("transfer(address,uint256)")
          && getFunctions.includes("transferFrom(address,address,uint256)")
          && getFunctions.includes("approve(address,uint256)")
          && getFunctions.includes("allowance(address,address)")) {
          const Uline = await TokenNameDecimals(address);
          setULieng((ULiengprevState: Lineg) => {
            return (ULiengprevState = Uline);
          });
          setLauchpadList((olddata: LaunchpadProps) => {
            return {
              ...olddata,
              IcoTokenSymbol: Uline.symbol,
              IcoTokenDecimals: Number(Uline.decimals),
            };
          })
          setNameShow((NameShowprevState: boolean) => {
            return (NameShowprevState = true);
          });
          allowanceFunc(address);
        } else {
          setNameShow((NameShowprevState: boolean) => {
            return (NameShowprevState = false);
          });
        }
      } else {
        setNameShow((NameShowprevState: boolean) => {
          return (NameShowprevState = false);
        });
      }
    } else {
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = false);
      });
    }
  };
  const NextOnClick = async () => {
    if (state != undefined) {
      if (state.inputValue != undefined) {
        history.push({
          pathname: "/WhiteList",
          state: LauchpadList,
        });
      } else {
        history.push({
          pathname: "/WhiteList",
          state: state,
        });
      }
    } else {
      history.push({
        pathname: "/WhiteList",
        state: LauchpadList,
      });
    }
  };
  const ApproveOnClick = async () => {
    try {
      setApproveLoading(true);
      const Contract = InstancedContract(LauchpadList.inputValue, WBENJson) as any;
      const MaxUint256: BigNumber = (BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"));
      const approve = await Contract.approve(
        LaunchPadFactoryAddress,
        MaxUint256
      );
      await approve.wait();
      setApproveLoading(false);
      setShowApproveBtn((pproveShowprevState: any) => {
        return (pproveShowprevState = true);
      });
    } catch (error) {
      setApproveLoading(false);
    }
  };
  const allowanceFunc = async (address: any) => {
    const allowanceVal = await allowance(
      address,
      LaunchPadFactoryAddress
    );
    const MaxUint256: BigNumber = (BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"));
    if (allowanceVal.eq(MaxUint256)) {
      setShowApproveBtn((showApproveBtnState: any) => {
        return (showApproveBtnState = true);
      });
    } else {
      setShowApproveBtn((showApproveBtnState: any) => {
        return (showApproveBtnState = false);
      });
    }
  };
  const getCreateNewLaunchpadFee = async () => {
    const LaunchPadFactoryContract = InstancedContract(LaunchPadFactoryAddress, LaunchPadFactoryABI) as any;
    const flatFee = await LaunchPadFactoryContract.flatFee();
    setFlatFeeShow(FormatUnitsConver(flatFee, 18))
  }
  useEffect(() => {
    getCreateNewLaunchpadFee();
    if (state !== undefined) {
      if (state.inputValue !== undefined) {
        setLauchpadList((stateDate: LaunchpadProps) => {
          return (stateDate = state);
        });
        allowanceFunc(state.inputValue);
        isVaildAddressOrNot(state.inputValue);
      } else if (state.PoleieData !== undefined) {
        setLauchpadList((stateDate: LaunchpadProps) => {
          return (stateDate = state.PoleieData);
        });
        allowanceFunc(state.PoleieData.inputValue);
        isVaildAddressOrNot(state.PoleieData.inputValue);
      } else {
        setLauchpadList((stateDate: LaunchpadProps) => {
          return (stateDate = state.data.PoleieData);
        });
        allowanceFunc(state.data.PoleieData.inputValue);
        isVaildAddressOrNot(state.data.PoleieData.inputValue);
      }
      getCreateNewLaunchpadFee();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);
  return (
    <div className="create">
      <div className="create-title">{`${t("Create launchpad")}`}</div>
      <div className="require-title">(*){`${t("is required field.")}`}</div>
      <div className="addressbtn">
        <div className="token-addr">
          {`${t("Token address")}`} <span style={{ color: "#F95192" }}> *</span>
        </div>
        <button
          className="create-btn"
          onClick={() => {
            CreateTokenOnCLick();
          }}
        >
          {`${t("Create token")}`}
        </button>
      </div>
      <input
        placeholder={`${t("Ex: 0x....")}`}
        className="addrInput"
        value={(LauchpadList.inputValue as any) || ""}
        style={{ borderColor: createLaunchpadError.TokenAddressBlankError || createLaunchpadError.TokenAddressInvalidError ? '#f14668' : '' }}
        onChange={(e) => {
          TokenAddressValueChange(e);
        }}
        onBlur={(e) => {
          TokenAddressBlurChange(e);
        }}
      />
      {createLaunchpadError.TokenAddressBlankError ? <InputError title="Token address cannot be blank" /> : ''}
      {createLaunchpadError.TokenAddressInvalidError ? <InputError title="Invalid token address" /> : ''}
      {NameShow === true ? (
        <div className="peilsiens">
          <div className="peilsiens_item">
            <div>{`${t("Name")}`}</div>
            <div>{ULieng.name}</div>
          </div>
          <div className="peilsiens_item">
            <div>{`${t("Symbol")}`}</div>
            <div>{ULieng.symbol}</div>
          </div>
          <div className="peilsiens_item">
            <div>{`${t("Decimals")}`}</div>
            <div>{ULieng.decimals}</div>
          </div>
        </div>
      ) : (
        ""
      )}
      <div className="create-fee">{`${t("Pool creation fee")}`}: {flatFeeShow || 0} BNB</div>
      <div className="currency-text">{`${t("Currency")}`}</div>
      <Radio.Group onChange={ChangeCurrency} value={LauchpadList.Radiovalue}>
        <Space direction="vertical">
          <Radio value={"0x0000000000000000000000000000000000000000"}>
            BNB
          </Radio>
          <Radio value={"0xF03E0Fc04757184ff64A58385d5553F661878f1A"}>
            BUSD
          </Radio>
          <Radio value={"0xF03E0Fc04757184ff64A58385d5553F661878f1B"}>
            USDT
          </Radio>
          <Radio value={"0xF03E0Fc04757184ff64A58385d5553F661878f1C"}>
            USDC
          </Radio>
        </Space>
      </Radio.Group>
      <div className="paywith-text">
        {`${t("Users will pay with")}`}{" "}
        {LauchpadList.Radiovalue ===
          "0x0000000000000000000000000000000000000000"
          ? "BNB"
          : LauchpadList.Radiovalue ===
            "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
            ? "BUSD"
            : LauchpadList.Radiovalue ===
              "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
              ? "USDT"
              : LauchpadList.Radiovalue ===
                "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                ? "USDC"
                : ""}{" "}
        {`${t("for your token")}`}
      </div>
      <div className="fee-option">{`${t("Fee Options")}`}</div>
      <Radio.Group onChange={ChangeFeeOptions} value={LauchpadList.FeeOptions}>
        <Space direction="vertical">
          <Radio value={"500,0"}>
            5%{" "}
            {LauchpadList.Radiovalue ===
              "0x0000000000000000000000000000000000000000"
              ? "BNB"
              : LauchpadList.Radiovalue ===
                "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                ? "BUSD"
                : LauchpadList.Radiovalue ===
                  "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                  ? "USDT"
                  : LauchpadList.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                    ? "USDC"
                    : ""}
            {`${t("raised only")}`}{" "}
            <span style={{ color: "#3298DC" }}>{`${t("(Recommended)")}`}</span>
          </Radio>
          <Radio value={"200,200"}>
            2%{" "}
            {LauchpadList.Radiovalue ===
              "0x0000000000000000000000000000000000000000"
              ? "BNB"
              : LauchpadList.Radiovalue ===
                "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                ? "BUSD"
                : LauchpadList.Radiovalue ===
                  "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                  ? "USDT"
                  : LauchpadList.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                    ? "USDC"
                    : ""}{" "}
            {`${t("raised + 2% token sold")}`}
          </Radio>
        </Space>
      </Radio.Group>
      <div className="listing-option">{`${t("Listing Options")}`}</div>
      <Radio.Group onChange={ChangeListingOptions} value={LauchpadList.ListingOptions}>
        <Space direction="vertical">
          <Radio value={true}>{`${t("Auto Listing")}`}</Radio>
          <Radio value={false}>{`${t("Manual listing")}`}</Radio>
        </Space>
      </Radio.Group>
      {LauchpadList.inputValue !== "" ? (<div className="tip-yellowRectangle">
        {`${t("Make sure the token has 'Exclude transfer fee' function if it has transfer fees.")}`}
      </div>) : ""
      }
      {LauchpadList.Radiovalue !== "0x0000000000000000000000000000000000000000" ? (<div className="tip-yellowRectangle">
        {`${t("Do not use this currency for auto liquidity tokens, or tokens that depend on WETH pair. It will lead to error when finalizing the pool or transfering the tokens (for example Liquidity Generator Token, BabyToken, Buyback Baby Token). Contact Mayasale for more information.")}`}<br />
      </div>
      ) : ""}
      {LauchpadList.ListingOptions ? (<div className="tip-yellowRectangle">
        {`${t("For auto listing, after you finalize the pool your token will be auto listed on DEX.")}`}
      </div>) : (<div className="tip-yellowRectangle">
        {`${t("For manual listing, MayaSale won't charge tokens for liquidity.You may withdraw BNB after the pool ends then do DEX listing yourself")}`}<br />
      </div>)
      }
      {CanNext() && showApproveBtn ? (
        <button
          className="nextbtn"
          onClick={() => {
            NextOnClick();
          }}
        >
          {`${t("Next")}`}
        </button>)
        :
        !CanNext() && !showApproveBtn ? (
          <button
            className="nextbtn"
            style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
          >
            {`${t("Next")}`}
          </button>)
          :
          CanNext() && !showApproveBtn ? (
            <button
              className="nextbtn"
              onClick={() => {
                ApproveOnClick();
              }}
            >
              {approveloading ? <ButtonLoading /> : ''}{`${t("Approve")}`}
            </button>)
            : (
              <button
                className="nextbtn"
                style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
              >
                {`${t("Next")}`}
              </button>
            )
      }

      <Modal
        title={`${t("Create token")}`}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={null}
      >
        <div className="Basic_Model">
          <AntiBotToken Createclick={onClick} />
        </div>
      </Modal>
    </div >
  );
};

export default Launchpad;
