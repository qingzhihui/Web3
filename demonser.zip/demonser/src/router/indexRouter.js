import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Abure from "../view/Abure";
import Home from "../view/Home";
import First from "../view/Firstu";
import Mintu from "../view/Mintu";
import Nulis from '../view/Nulis'
export default class indexRouter extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/home" component={Abure} />
          <Route path="/index" component={Home} />
          <Route path="/about" component={First} />
          <Route path="/mint" component={Mintu} />
          <Route path="/MyNFTs" component={Nulis} />
          <Redirect from="/" to="/home" />
        </Switch>
      </Router>
    );
  }
}
