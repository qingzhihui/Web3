interface Props {
  count: number;
}
const Child = ({ count }: Props) => {
  return (
    <div>
      <h2>Child Component</h2>
      <p>Count: {count}</p>
    </div>
  );
};

export default Child;
