import React, { useState, useEffect } from "react";
import { Input, RadioChangeEvent, Upload, Radio, Space, message } from "antd";
import type { UploadProps } from "antd";
import { ethers } from "ethers";
import * as XLSX from "xlsx";
import { useHistory } from "react-router-dom";
import { BigNumber } from "@ethersproject/bignumber";
import { RedoOutlined, UploadOutlined } from "@ant-design/icons";
import MultiSenderheader from "../../components/MultiSenderheader";
import {
  InstancedContract,
  DigitalConversion,
  ObtainAddress,
  allowance,
  TokenNameDecimals,
  Lineg,
} from "../../hooks/config";
import {
  MultiSenderAddress,
  IAdmin,
  Quantitgroup,
  TotalCalculation,
} from "../../hooks/MultiSender";
import { WBENJson } from "../../config/abi/wbenjson";
import Group from "../../assets/image/Group.png";
import gobed from "../../assets/image/gobed.png";
import "./index.scss";
import { useTranslation, Trans } from "react-i18next";
import copy from "copy-to-clipboard";
import { isAddress } from '../../utils/address'
import InputError from '../../components/InputError'
import ButtonLoading from "../../components/ButtonLoading";
const { TextArea } = Input;

const MultiSender: React.FC = () => {
  let history = useHistory();
  const { t } = useTranslation();
  const [TokenAddress, setTokenAddress] = useState<string>("");
  const [textarea, seTtextarea] = useState<string>("");
  const [Lisbn, setLisbn] = useState<any>("");
  const [ApproveShow, setApproveShow] = useState<boolean>(false);
  const [TokenGrouo, setTokenGrouo] = useState<boolean>(false);
  const [value, setValue] = useState<number>(1);
  const [Total, setTotal] = useState<string>("");
  const [ULieng, setULieng] = useState<Lineg>({
    name: "",
    symbol: "",
    decimals: "",
    balanceOf: "",
  });
  const [ecimals, setEcimals] = useState<boolean>(false);
  const [multiSenderAddress, setMultiSenderAddress] = useState<string>(MultiSenderAddress)
  const [errorshow, isErrorShow] = useState<boolean>(false)
  const [loading, setLoading] = useState<boolean>(false)

  const RadionChange = (e: RadioChangeEvent) => {
    setValue(e.target.value);
  };
  const handtextareaChange = (e: any) => {
    seTtextarea(e.target.value);
  };
  const onKeyPress = (e: any) => {
    if (e.keyCode === 13 && e.shiftKey) {
      e.preventDefault();
      addNewLineToTextArea();
    }
  };
  const onGetLines = () => {
    var tmpArl = (document.querySelector("#test") as HTMLInputElement).value;
    const tmpList = tmpArl.split(/\r*\n/);
    let List: IAdmin[] = [];
    for (let index = 0; index < tmpList.length; index++) {
      List.push({
        id: index + 1,
      });
    }
  };
  const addNewLineToTextArea = () => {
    let textar = textarea + "\r\n";
    seTtextarea(textar);
  };
  const UpdateCurrentWallet = async () => {
    var VaList = textarea.split(/\r*\n/);
    const newDataList = VaList.filter((item: any) => item !== "");
    const { balance } = await ObtainAddress() as any;
    history.push({
      pathname: "/Comfrimation",
      state: {
        btenshow: 1,
        dotData: newDataList,
        symbol: ULieng.symbol as any,
        balance: ethers.utils.formatUnits(balance),
      },
    });
  };
  const props: UploadProps = {
    accept: ".csv,.xls,.xlsx,application/vnd.ms-excel",
    beforeUpload: (file) => {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const workbook = XLSX.read(e.target.result, {
          type: "binary",
        });
        const first_worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonArr = XLSX.utils.sheet_to_json(first_worksheet, {
          header: 1,
        });
        handleImpotedJson(jsonArr, file);
      };
      reader.readAsBinaryString(file);
      return false;
    },
    onRemove: () => {
      seTtextarea("");
    },
  };
  const textareaPlaceholder = `Insert allocation: separate with breaks line. By format: address,amount or address amount
  Ex:
  0x0000000000000000000000000000000000001000   13.45
  0x0000000000000000000000000000000000001000   1.049
  0x0000000000000000000000000000000000001000   1`
  const handleImpotedJson = (jsonArr: any, file: any) => {
    const { TextareaList, QuantityArray } = TotalCalculation(jsonArr);
    setTotal((TotalprevState: any) => {
      return (TotalprevState = parseFloat(Quantitgroup(QuantityArray).toPrecision(12)).toString());
    });
    setLisbn((LisbnprevState: any) => {
      return (LisbnprevState = [TextareaList, QuantityArray]);
    });
    seTtextarea((TtextareaprevState: any) => {
      return (TtextareaprevState = TextareaList.join(""));
    });
  };
  const ApproveCurrentWallet = async () => {
    try {
      setLoading(true);
      const Contract = InstancedContract(TokenAddress, WBENJson) as any;
      const decimals = await Contract.decimals();
      var AuthorizedQuantity: any = undefined;
      const MaxUint256: BigNumber = (BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"));
      if (value === 1) {
        AuthorizedQuantity = MaxUint256;
      } else {
        AuthorizedQuantity = DigitalConversion(Total, decimals);
      }
      const approve = await Contract.approve(
        MultiSenderAddress,
        AuthorizedQuantity
      );
      await approve.wait();
      setLoading(false);
      setTokenGrouo((TokenGrouoprevState: any) => {
        return (TokenGrouoprevState = false);
      });
      setApproveShow((pproveShowprevState: any) => {
        return (pproveShowprevState = true);
      });
    } catch (error) {
      setLoading(false);
    }
  };
  const TokenAddressonChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setTokenAddress(e.target.value);
    if (ethers.utils.isAddress(e.target.value)) {
      const allowanceParameter = await allowance(
        e.target.value,
        MultiSenderAddress
      );
      const MaxUint256: BigNumber = BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
      if (allowanceParameter.eq(MaxUint256)) {
        setApproveShow((pproveShowprevState: any) => {
          return (pproveShowprevState = true);
        });
        setTokenGrouo(false);
      } else {
        setApproveShow((pproveShowprevState: any) => {
          return (pproveShowprevState = false);
        });
        setTokenGrouo(true);
      }
      setEcimals(true);
      const Uline = await TokenNameDecimals(e.target.value);
      setULieng((ULiengprevState: Lineg) => {
        return (ULiengprevState = Uline);
      });
    } else {
      setTokenGrouo(false);
    }
  };
  const TokengCurrentWallet = async () => {
    var VaList = textarea.split(/\r*\n/);
    const newDataList = VaList.filter((item: any) => item !== "");
    const { address } = await ObtainAddress() as any;
    const balance = await (InstancedContract(TokenAddress, WBENJson) as any).balanceOf(
      address
    );
    history.push({
      pathname: "/Comfrimation",
      state: {
        btenshow: 2,
        address: TokenAddress,
        dotData: newDataList,
        symbol: ULieng.symbol as any,
        decimals: ULieng.decimals,
        balance: ethers.utils.formatUnits(balance, ULieng.decimals),
      },
    });
  };
  // 复制地址
  const copyAddr = (addr: string) => {
    copy(addr)
    successTip("Copy Successfully")
  }
  // 提示复制成功
  const successTip = (tip: string) => {
    message.success(`${t(tip)}`);
  };
  const TokenInformation = () => {
    return (
      <div className="allowspinue">
        <div className="allowspinue_item">
          <div>{`${t("Name")}`}</div>
          <div>{(ULieng.name as string) || <RedoOutlined spin />}</div>
        </div>
        <div className="allowspinue_item">
          <div>{`${t("Symbol")}`}</div>
          <div>{(ULieng.symbol as string) || <RedoOutlined spin />}</div>
        </div>
        <div className="allowspinue_item">
          <div>{`${t("Decimals")}`}</div>
          <div>{(ULieng.decimals as string) || <RedoOutlined spin />}</div>
        </div>
        <div className="allowspinue_item">
          <div>{`${t("Balance")}`}</div>
          <div>{Number(ULieng.balanceOf as string) || <RedoOutlined spin />}</div>
        </div>
      </div>
    );
  };
  useEffect(() => { }, [ApproveShow, TokenGrouo, MultiSenderAddress])
  return (
    <div className="MultiSender">
      <div className="MultiSender_content">
        {/* 移动端显示 */}
        <div className="disclaimer Mobiledisclaimer">
          {`${t("Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published.")}`}
        </div>
        <MultiSenderheader setp={1} />
        <div className="MultiSender_middle">
          <div className="middle_content">
            <div className="address_title">{`${t("Token address")}`}</div>
            <div className="input" style={{ borderColor: errorshow ? '#f14668' : '' }}>
              <input
                type="text"
                value={TokenAddress}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  TokenAddressonChange(e);
                }}
                placeholder={`${t("Ex: 0x....")}`}
              />
            </div>
            {errorshow ? <InputError title="Invalid address" /> : ''}
            <div className="allows">
              {`${t("Maya Multi-sender allows you to send ERC20 token in batch by easiest way. You can enter token address to send specific token or leave it blank to send chain token such as BNB....")}`}
            </div>
            {ecimals === true ? <TokenInformation /> : ""}
            <div className="allocation">{`${t("Allocations")}`}</div>
            <div className="insert">
              <div className="input">
                <TextArea
                  rows={4}
                  id="test"
                  allowClear={true}
                  bordered={false}
                  value={textarea}
                  placeholder={`${t(textareaPlaceholder)}`}
                  onChange={handtextareaChange}
                  autoSize={{ minRows: 3, maxRows: 18 }}
                  onKeyDown={onKeyPress}
                  onBlur={onGetLines}
                />
              </div>
            </div>
            <div className="buttons">
              <Upload {...props} progress={{ strokeWidth: 2, showInfo: false }}>
                <button>
                  {" "}
                  <UploadOutlined />
                  {`${t("Or choose from Excel file")}`}
                </button>
              </Upload>
              <div className="sample">{`${t("Sample Excel file")}`}</div>
            </div>
            {TokenGrouo === true ? (
              <>
                <div className="buttons">{`${t("Amount to approve")}`}</div>
                <div className="slineuse">
                  <Radio.Group onChange={RadionChange} value={value} >
                    <Space direction="vertical">
                      <Radio value={1}>{`${t("Unlimited amount")}`}</Radio>
                      <Radio value={2}>{`${t("Exact amount")}`}{Number(Total) > 0 ? `(${Number(Total)}${" "}${ULieng.symbol})` : ""}</Radio>
                    </Space>
                  </Radio.Group>
                </div>
              </>
            ) : (
              ""
            )}

            <div className="exclude">
              <div className="exclude-right">
                <div className="pexclude">{`${t("Please exclude")}`}</div>
                <div className="address">{multiSenderAddress}</div>
                <span className="imgs" onClick={() => { copyAddr(multiSenderAddress) }}>
                  <img src={Group} alt="" />
                </span>
              </div>
              <div className="fees">
                {`${t("from fees, rewards, max tx amount to start sending tokens.")}`}
              </div>
            </div>
            {TokenAddress === "" ?
              (
                <>
                  {Lisbn !== "" ?
                    <button
                      className="next"
                      onClick={() => {
                        UpdateCurrentWallet();
                      }}
                    >
                      {`${t("Next")}`}
                    </button>
                    :
                    <button
                      className="next"
                      style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
                    >
                      {`${t("Next")}`}
                    </button>}
                </>
              )
              :
              (
                <>
                  {ApproveShow === false ?
                    (
                      <button
                        className="next"
                        onClick={() => {
                          ApproveCurrentWallet();
                        }}
                      >
                        {loading ? <ButtonLoading /> : ''}{`${t("Approve")}`}
                      </button>
                    )
                    :
                    (
                      <button
                        className="next"
                        onClick={() => {
                          TokengCurrentWallet();
                        }}
                      >
                        {`${t("Next")}`}
                      </button>
                    )}
                </>
              )}
          </div>
        </div>
        <div className="gpbed">
          <img src={gobed} alt="" />
        </div>
        {/* PC端显示 */}
        <div className="disclaimer PCdisclaimer">
          {`${t("Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published.")}`}
        </div>
      </div>
    </div>
  );
};
export default MultiSender;
