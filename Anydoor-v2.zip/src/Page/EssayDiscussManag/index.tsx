import {
    DeleteOutlined, FormOutlined
} from '@ant-design/icons';
import { DatePicker, DatePickerProps, Space, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import "./index.css";

import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';

dayjs.extend(customParseFormat);


// 文章评论管理界面
const EssayDiscussManag = () => {


    interface DataType {
        key: number;
        discussCont: string;
        userNickname: string;
        discussTime: string;
    }

    const data: DataType[] = [
        {
            key: 1,
            discussCont: '这个环节是真的舒适',
            userNickname: "小飞侠",
            discussTime: "2023-03-01",
        },
    ];
    const columns: ColumnsType<DataType> = [
        {
            title: '评论内容',
            dataIndex: 'discussCont',
        },
        {
            title: '用户昵称',
            dataIndex: 'userNickname',
            width: 150,
        },
        {
            title: '评论时间',
            dataIndex: 'discussTime',
            width: 150,
        },
        {
            title: '操作',
            key: 'action',
            width: 150,
            render: (_, record) => (
                <Space size="middle">
                    <span className='discuss_Cursor' onClick={uploadus(record)}><FormOutlined /></span>
                    <span className='discuss_Cursor' onClick={deleteus(record)}><DeleteOutlined /></span>
                </Space>
            ),
        },
    ];

    // 选中时间
    const onChange: DatePickerProps['onChange'] = (date, dateString) => {
        console.log("选中的时间",date, dateString);
      };

    // 修改
    const uploadus = (record: any) => {
        return () => {
            console.log("点击了修改");
            console.log(record.key);
        }
    }
    // 删除
    const deleteus = (record: any) => {
        return () => {
            console.log("点击了删除");
            console.log(record.key);
        }
    }

    return (
        <div className='discuss_Box'>
            <div className='discuss_headerBox'>
                <div className='discuss_headerBox_thread'></div>
                <div className='discuss_headerBox_Tit'>&nbsp;&nbsp;&nbsp; 文章评论管理</div>
                <div className='discuss_time'>
                    <div className='discuss_xztimetit'>时间：</div>
                    <div className='discuss_xztime'>
                        <DatePicker placeholder='请选择时间' onChange={onChange} />
                    </div>
                </div>
            </div>

            <div className='discuss_tableBox'>
                <Table columns={columns} dataSource={data} />
            </div>
        </div>
    )
}

export default EssayDiscussManag;