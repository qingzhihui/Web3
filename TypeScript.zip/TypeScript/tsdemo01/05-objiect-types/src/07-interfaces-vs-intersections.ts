// 类型的合并可以使用interface
// interface Sister {
//   name: string;
// }
// interface Sister {
//   age: number;
// }

// const sister1: Sister = {
//   name: "sisterA",
//   age: 20,
// };


// 类型别名（避免类型重名）
// 1.类型别名不能同名
type Sister ={
    name:string

}
// type Sister={

// }