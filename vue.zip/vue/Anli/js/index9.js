// 动态化模板
const user = {
    name: 'deng',
    age: 28
}
// const hi = 'my name is ' + user.name + ', I m' + user.age;
const hi = tag`my name is ${user.name} I m' ${user.age}`;


function tag() {
    console.log(arguments);
    return 'abc'
}

console.log(hi)


//随机颜色
var a = document.createElement('a');
document.body.append(a);
var height = 100;
var config = {
    text: '抖音',
    url: 'https://www.douyin.com'
}
a.style.color = getRandomColor();
a.style.backgroundColor = getRandomColor();
a.style.height = height + 'px';
a.style.lineHeight = height + 'px';
a.style.fontSize = height / 4 + 'px';
a.href = config.url;
a.target = '_blank';
a.title = config.text;
a.textContent = "跳转到：" + config.text;


a.styles`
 color:${getRandomColor()};
 background:${getRandomColor()};
 height:${height}px;
 line-height:${height}px
 font-size:${height / 4}
`.props`
    href:${config.url};
    target:_blank;
    title:${config.text}
 `.content`跳转到：${config.text};`;


(() => {
    function generateString() {

    }

    HTMLElement.prototype.styles = function () {
        const styles = getComputedStyle(arguments);
        let curStyle = this.getAttribute('style');
        if (curStyle) {
            curStyle += styles;
        } else {
            curStyle = styles;
        }
        this.style = curStyle;
        return this;
    };
    HTMLElement.prototype.props = function () {
        const propString = generateString(arguments);
        propString
            .split('\n')
            .map((it) => {
                const parts = it.trim().split(':');
                const key = parts[0].trim();
                let value = parts.slice(1).join(':').trim();
                if (value.indexOf(':') === value.length - 1) {
                    value = value.substring(0, value.length - 1);
                }
                return [key, value];
            }).forEach(([k, v]) => {
            if (!k) {
                return;
            } else {
                this[k] = v;
            }
        })
        return this;

    };
    HTMLElement.prototype.content = function () {

    };
})();