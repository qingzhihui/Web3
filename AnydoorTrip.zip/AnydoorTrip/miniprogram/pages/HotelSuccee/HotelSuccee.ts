// pages/HotelSuccee/HotelSuccee.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    checked: true,
    DuisData: {},
    mealPlan:{}
  },
  /**
 * 生命周期函数--监听页面加载
 */
  onLoad(options: any) {
    if (options.item !== undefined) {
      const Nuei = JSON.parse(options.item);
      this.setData({
        DuisData: Nuei,
        mealPlan:JSON.parse(Nuei.mealPlan)
      })
      console.log(JSON.parse(Nuei.mealPlan));
    }
  },
  CheckboxonChange(event: any) {
    this.setData({
      checked: event.detail,
    });
  },
  InpserShow() {
    wx.switchTab({
      url: '../Index/Index',
    })
  },
  OrderAmanilsShow() {

    
    const DuisItem: any = this.data.DuisData;
    console.log(DuisItem);
    wx.navigateTo({
      url: `../OrderAmanils/OrderAmanils?id=${DuisItem.id}`
    })
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})