function combine<Type>(arr1: Type[], arr2: Type[]): Type[] {
  return arr1.concat(arr2);
}

const arr = combine<string | number>(["string", "objie", "boolean"], [1, 2, 3]);

console.log(arr);
