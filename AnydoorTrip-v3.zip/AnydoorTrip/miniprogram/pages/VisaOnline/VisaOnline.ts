import api from '../../config/axios'
import { formatTime } from "../../utils/util";


const options = [
  {
    text: '中国',
    value: '330000',
    children: [{
      text: '广西省', value: '330100',
      children: [{ text: '桂林市', value: '330101' }],
    }],
  },
  {
    text: '泰国',
    value: '320000',
    children: [{
      text: 'SLUI', value: '320100',
      children: [{ text: 'BAISE', value: '330101' }],
    }],
  },
];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Birthday: false,
    issueData: false,
    becomData: false,
    minDate: new Date(1949, 10, 1).getTime(),
    formatter(type: any, value: any) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    currentDate: new Date().getTime(),
    issuecurrentDate: new Date().getTime(),
    becomcurrentDate: new Date().getTime(),
    optionsData: options,
    // 数据
    radio: 'male',
    radioStatus: '1',
    WhetheRadio: "1",
    HaveRadio: "1",
    TypeRiose: "1",
    BirthdayDate: "",
    issueDataValue: "",
    becomDataValue: "",
    pickerValue: "",
    prckerInput: "",
    fieldValue: '',
    Essentia: {
      surname: "",
      famname: "",
      engName: "",
      Beborn: "",
      radio: ""
    },
    certInput: "",
    issueValue: "",
    MechanismValue: ""
  },

  onLoad(options) {


  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  PickerOnclie() {
    var childEle = this.selectComponent('#nation');
    childEle.PickerBtone(1);
  },
  lineInptData() {
    var childEle = this.selectComponent('#nation');
    childEle.PickerBtone(2);
  },

  TimeOnclick() {
    var childEle = this.selectComponent('#Thres');
    childEle.showPopup();
  },
  Three(e: any) {
    this.setData({
      fieldValue: e.detail
    })
  },
  Nation(e: any) {
    this.setData({
      pickerValue: e.detail
    })
  },
  linDate(e: any) {
    console.log(e);
    const Meachan: any = e.detail + '大使馆'
    this.setData({
      issueValue: e.detail,
      MechanismValue:Meachan
    })
  },
  SurnameOnCheng(e: any) {
    const Data: any = this.data.Essentia;
    Data.surname = e.detail.value;
    this.setData({
      Essentia: Data
    })
  },
  FarnameOnCheng(e: any) {
    const Data: any = this.data.Essentia;
    Data.famname = e.detail.value;
    this.setData({
      Essentia: Data
    })
  },
  engNameOnCheng(e: any) {
    const Data: any = this.data.Essentia;
    Data.engName = e.detail.value;
    this.setData({
      Essentia: Data
    })
  },

  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  SubmitOnClikc() {
    // 基本信息
    console.log(this.data.Essentia);
    // 出生地
    console.log(this.data.fieldValue);
    // 婚姻状况
    console.log(this.data.radioStatus);
    // 国籍和永久居留
    console.log(this.data.pickerValue);
    console.log(this.data.prckerInput);
    console.log(this.data.WhetheRadio);
    console.log(this.data.HaveRadio);
    // 护照信息
    console.log(this.data.certInput);
    console.log(this.data.issueDataValue)
    console.log(this.data.becomDataValue)
    // wx.switchTab({
    //   url: '../Index/Index',
    // })
  },
  pickerInputOncheng(e: any) {
    this.setData({
      prckerInput: e.detail.value
    })
  },
  certInputOnCheng(e: any) {
    this.setData({
      certInput: e.detail.value
    })
  },
  issueDataShow() {
    this.setData({
      issueData: true
    })
  },
  becomDataShow() {
    this.setData({
      becomData: true
    })
  },
  StatusOnChange(event: any) {
    this.setData({
      radioStatus: event.detail,
    });
  },
  WhetherOnChange(event: any) {
    this.setData({
      WhetheRadio: event.detail,
    });
  },
  BirthdayClose() {
    this.setData({ Birthday: false });
  },
  issueDataClose() {
    this.setData({ issueData: false });
  },
  becomDataClose() {
    this.setData({ becomData: false });
  },

  BirthdayConfirm() {
    const CloseData = formatTime(new Date(this.data.currentDate))
    const Data: any = this.data.Essentia;
    Data.Beborn = CloseData;
    this.setData({
      Essentia: Data,
      BirthdayDate: CloseData,
      Birthday: false
    })
  },

  issueDataConfirm() {
    const CloseData = formatTime(new Date(this.data.issuecurrentDate))
    this.setData({
      issueDataValue: CloseData,
      issueData: false
    })
  },
  becomDataConfirm() {
    const CloseData = formatTime(new Date(this.data.becomcurrentDate))
    this.setData({
      becomDataValue: CloseData,
      becomData: false
    })
  },
  DateShow() {
    this.setData({ Birthday: true });
  },
  HaveOnChange(event: any) {
    this.setData({
      HaveRadio: event.detail,
    });
  },
  BirthdayInput(event: any) {
    this.setData({
      currentDate: event.detail,
    });
  },
  issueDataInput(event: any) {
    this.setData({
      issuecurrentDate: event.detail,
    });
  },
  becomDataInput(event: any) {
    this.setData({
      becomcurrentDate: event.detail,
    });
  },
  TypeOnChange(event: any) {
    this.setData({
      TypeRiose: event.detail,
    });
  },
  onChange(event: any) {
    const Data: any = this.data.Essentia;
    Data.radio = event.detail;
    this.setData({
      radio: event.detail,
      Essentia: Data
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})