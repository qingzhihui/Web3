import React, { useState, useRef, useEffect } from 'react'
import './index.scss'
import type { RadioChangeEvent } from 'antd';
import { Input, Radio, Space } from 'antd';
import { LeftOutlined, RightOutlined } from '@ant-design/icons';
import Filterscard from '@/components/Filterscard'

export default function Index() {
  const [value1, setValue1] = useState(1);
  const [value2, setValue2] = useState(1);
  const [value3, setValue3] = useState(1);
  const [select, setSelect] = useState(1);

  const onChange_1 = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue1(e.target.value);
  };
  const onChange_2 = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue2(e.target.value);
  };
  const onChange_3 = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue3(e.target.value);
  };
  return (
    <div className='filters'>
      <div className='filters_city'>
        <div className='city'>
          <div className='citytop'>
            <img src={require('@/assets/image/tablerbrand.png')} alt="" className='brand' />
            <span className='one'>departure city</span>
            <span className='two'>Bei jing</span>
            <div className='imgs'><img src={require('@/assets/image/group70.png')} alt="" /></div>
          </div>
          <div className='citybuttom'>
            <img src={require('@/assets/image/tablermap.png')} alt="" />
            <span className='one'>arrival city</span>
            <span className='two'>Paris</span>
          </div>
        </div>
        <div className='city_add'>
          <img src={require('@/assets/image/user.png')} alt="" />
          <div className='addright'>
            <div className='addkit'>
              <span>aldult</span>
              <div className='computer'>
                <div>-</div>
                <div>0</div>
                <div>+</div>
              </div>
            </div>
            <div className='addkit'>
              <span>child</span>
              <div className='computer'>
                <div>-</div>
                <div>0</div>
                <div>+</div>
              </div>
            </div>
          </div>
        </div>
        <div className='city_selset'>
          <img src={require('@/assets/image/tablerarmchair.png')} alt="" />
          <div className='sele'>
            <Radio.Group onChange={onChange_1} value={value1}>
              <Space direction="vertical">
                <Radio value={1}>first class</Radio>
                <Radio value={2}>business class</Radio>
                <Radio value={3}>economy class</Radio>
              </Space>
            </Radio.Group>
          </div>
        </div>
        <div className='city_butt'>
          <div className='buts'>
            <div className={select === 1 ? 'selediv' : ''} onClick={() => { setSelect(1) }}>One-way</div>
            <div className={select === 2 ? 'selediv' : ''} onClick={() => { setSelect(2) }}>Round-trip</div>
          </div>
          <button className='button'>Inquire</button>
        </div>
      </div>
      <div className='filters_dates'>
        <div className='dates_left'>
          <img src={require('@/assets/image/ph.png')} alt="" />
          <div>Wed, Dec 13,2022</div>
        </div>
        <div className='dates_right'>
          <div><LeftOutlined style={{ fontSize: '20px' }} /></div>
          <div className='week weeksele'>
            <div>Monday, December 12</div>
            <div className='weekmoney'>$4,223</div>
          </div>
          <div className='week'>
            <div>Monday, December 12</div>
            <div className='weekmoney'>$4,223</div>
          </div>
          <div className='week'>
            <div>Monday, December 12</div>
            <div className='weekmoney'>$4,223</div>
          </div>
          <div className='week'>
            <div>Monday, December 12</div>
            <div className='weekmoney'>$4,223</div>
          </div>
          <div><RightOutlined style={{ fontSize: '20px' }} /></div>
        </div>
      </div>
      <div className='filters_address'>
        <div className='address_left'>
          <div className='addtop'>
            <div className='filt'>Filters</div>
            <div className='recommended'>Recommended Filters</div>
            <Radio.Group onChange={onChange_2} value={value2}>
              <Space direction="vertical">
                <Radio value={1}>Includes checked baggage</Radio>
                <Radio value={2}>Includes carry-on baggage</Radio>
                <Radio value={3}>Flights with student tickets available</Radio>
                <Radio value={4}>Only display flights with the Flexibooking tag</Radio>
              </Space>
            </Radio.Group>
          </div>
          <div className='addbuttom'>
            <div className='stops'>
              <div className='tiitlebut'>Stops</div>
              <Radio.Group onChange={onChange_3} value={value3}>
                <Space direction="vertical">
                  <Radio value={1}>Option A</Radio>
                  <Radio value={2}>Option B</Radio>
                  <Radio value={3}>Option C</Radio>
                </Space>
              </Radio.Group>
              <div className='count'>
                <div className='stopover'>Stopover Duration</div>
                <div className='miao'>0h 0m - 27h 36m</div>
              </div>
              <div className='lines'>
                <div className='yuan1'></div>
                <div className='line'></div>
                <div className='yuan2'></div>
              </div>
              <Radio>Hide overnight stopovers</Radio>
            </div>
            <div className='airline'>22</div>
            <div className='times'>33</div>
            <div className='duration'>44</div>
            <div className='airport'>55</div>
          </div>
        </div>
        <div className='address_right'>
          <Filterscard />
          <Filterscard />
          <Filterscard />
          <Filterscard />
          <Filterscard />
          <Filterscard />
          <Filterscard />
          <div className='book'>Book Beijing to Paris Flights on Anydoor Trip</div>
          <div className='first'>First | Business class | Economy class | Nonstop</div>
        </div>
      </div>
    </div>
  )
}
