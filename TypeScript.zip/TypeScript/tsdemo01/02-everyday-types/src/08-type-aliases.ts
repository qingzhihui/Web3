type Point = {
  x: number;
  y: number;
};

function printCoord2(pt: Point) {}
printCoord({
  x: 100,
  y: 200,
});

type ID = number | string;
function printId2(id: ID) {}
printId2(100);
printId2("hello");



type UserInputSanitizedString = string;
function sanitizedInput(str: string): UserInputSanitizedString {
  return str.slice(0, 2);
}

let userInput = sanitizedInput('hello');
userInput = 'new Input'