/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  webpack: (config) => {
    config.resolve.fallback = { fs: false, crypto: false };
    config.resolve.alias = {
      ...config.resolve.alias,
      unfetch$: "unfetch/dist/unfetch.umd.js",
    };
    return config;
  },
};

module.exports = nextConfig;
