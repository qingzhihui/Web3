import api from '../../config/axios'
import { differenceInterval, getWeekByDate, LogeStateJudge } from '../../config/config';
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    state: false,
    id: '',
    Detailedlist: {},
    rate: "",
    startTime: "",
    EndTime: "",
    cardCur: 0,
    conurLength: 1,
    people: "1",
    quanti: "",//房间数量
    swiperList: [],
    RootDate: [],
    uselr: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/room.png',
    msgId: undefined,
    interval: '',
    logeinState: false,
    LoginTitle: "预订",
    loading: false,
    weekdayUoer: "",
    weekdayEoer: "",
    // 评论状态
    evaluate: false,
    comment: [],
    conurEgn: 0,
    sourceId: ""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options: any) {
    api._get(`hotel/${options.id}`).then(res => {
      var childEle = this.selectComponent('#childEle');
      const intervalDate: any = differenceInterval(options.startTime, options.EndTime);
      this.setData({
        interval: intervalDate,
        Detailedlist: res.data,
        swiperList: JSON.parse(res.data.hotelImages),
        id: options.id,
        startTime: options.startTime,
        EndTime: options.EndTime,
        people: childEle.data.stepperValue,
        loading: true,
        quanti: options.roomNumer,
        weekdayUoer: getWeekByDate(options.startTime),
        weekdayEoer: getWeekByDate(options.EndTime),
        conurEgn: JSON.parse(res.data.hotelImages).length,
        sourceId: res.data.sourceId
      })
      setTimeout(() => {
        this.guestRoom()
      }, 1000)
    }).catch(e => {
      console.log(e);
    })
    this.setData({
      logeinState: LogeStateJudge()
    })
  },
  LoginStateButton(event: any) {
    console.log(event);
    
    this.setData({
      logeinState: event
    })
    if (event === false) {
      Toast.success('登录成功');
    } else {
      Toast.fail('登录失败');
    }
  },
  MineTitleLongeiu() {
    wx.navigateTo({
      url: '../logines/logines'
    })
  },
  guestRoom() {
    const data: any = this.data.Detailedlist
    const item = {
      checkIn: this.data.startTime,
      checkOut: this.data.EndTime,
      numberOfRooms: this.data.quanti,
      numberOfAdults: this.data.people,
      hotelId: data.id,
      sourceId: data.sourceId
    }
    api._post('room-list', item).then(res => {
      const HoleData: any = []
      res.data.map((item: any) => {
        if (item.roomPlanList[0] !== undefined) {
          const data = { ...item, Sole: item.roomPlanList[0] }
          HoleData.push(data)
        } else {
          HoleData.push(item)
        }
      })
      this.setData({
        loading: false,
        RootDate: HoleData
      })
    }).catch(e => {
      console.log(e);
    })
  },
  HotelAlbumShow() {
    wx.navigateTo({
      url: `../HotelAlbum/HotelAlbum?id=${this.data.id}`
    })
  },
  send(e: any) {
    const intervalDate: any = differenceInterval(e.detail.date[0], e.detail.date[1])
    this.setData({
      startTime: e.detail.date[0],
      EndTime: e.detail.date[1],
      people: e.detail.stepper,
      quanti: e.detail.roomNumer,
      RootDate: [],
      loading: true,
      interval: intervalDate,
      weekdayUoer: getWeekByDate(e.detail.date[0]),
      weekdayEoer: getWeekByDate(e.detail.date[1]),
    })
    setTimeout(() => {
      this.guestRoom()
    }, 1000)
  },
  TimeOnclick() {
    var childEle = this.selectComponent('#childEle');
    childEle.showPopup();
    childEle.getFirstWeek({
      startTime: this.data.startTime,
      EndTime: this.data.EndTime,
      nuerlin: this.data.interval,
      stepperProps: this.data.people,
      roomNumer: this.data.quanti
    })
  },
  cardSwiper(e: any) {
    this.setData({
      cardCur: e.detail.current,
      conurLength: e.detail.current + 1
    })
  },
  SelectBInd(e: any) {
    this.setData({
      rate: e.detail.Tere
    });
    if (e.detail.state === true) {
      this.guestRoom()
    }
  },

  IconOnclick(event: any) {
    this.setData({
      msgId: event.currentTarget.dataset.msg,
      state: !this.data.state,
    });
  },

  HotelReservationShow(event: any) {
    if (this.data.logeinState !== true) {
      const layName: any = this.data.Detailedlist;
      const propsData = event.currentTarget.dataset;
      const PropsTransmit = JSON.stringify({
        check_in: this.data.startTime,
        check_out: this.data.EndTime,
        hotel_id: this.data.id,
        interval: this.data.interval,
        number_of_adults: this.data.people,
        plan_type: layName.hotelNameCn,
        IMage: propsData.imag,
        mealplan: propsData.mealplan,
        currency: this.data.rate,
        number_of_rooms: this.data.quanti,
        id: propsData.id,
        tax: propsData.tax,
        totalPrice: propsData.totalprice,
        basePrice: propsData.baseprice,
        sourceId: this.data.sourceId,
        plantype: propsData.plantype,
        source: propsData.source
      })
      wx.navigateTo({
        url: `../HotelReservation/HotelReservation?prosTken=${PropsTransmit}`
      })
    }
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})