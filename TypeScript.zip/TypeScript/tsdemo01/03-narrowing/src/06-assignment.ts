let x = Math.random() < 0.5 ? 10 : "hello world";

// let x: number
x = 1
console.log(x);

// let x: string
x = 'goodbye'
console.log(x);