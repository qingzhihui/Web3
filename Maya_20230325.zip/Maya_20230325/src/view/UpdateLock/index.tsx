/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState } from 'react'
import './index.scss'
import { FormOutlined } from '@ant-design/icons';
import { useTranslation, Trans } from "react-i18next";
export default function index() {

    const [updateInput,setUpdateInput] = useState<string>('')

    const Update = () => {
        alert(`updateInput -> ${updateInput}`)
    }

    const { t } = useTranslation();

    return (
        <div className='UpdateLock'>
            <div className='update-lock'>
                <div className='updatelock-tableItem updatalock-title'>{`${t("Update your lock")}`}</div>
                <div className='certik'>
                    <div className='certik-title'>{`${t("mayasale isaudited by Certik")}`}:: <span className='certikUrl'>https://leaderboard.certik.io/projects/mayasale</span></div>
                </div>
                <div className='updatelock-tableItem'>
                    <div className='tableItem-text'>
                        <span className='tableItem-title'>{`${t("Token Address")}`}</span>
                        <span className='tableItem-name TokenAddress'>0x3edaF837469b2A46CBD835483e723AdaDdb15F58 <FormOutlined /></span>
                    </div>
                    <div className='tableItem-line' />
                </div>
                <div className='updatelock-tableItem'>
                    <div className='tableItem-text'>
                        <span className='tableItem-title'>{`${t("Token Name")}`}</span>
                        <span className='tableItem-name TokenName'>TeTher Token</span>
                    </div>
                    <div className='tableItem-line' />
                </div>
                <div className='updatelock-tableItem'>
                    <div className='tableItem-text'>
                        <span className='tableItem-title'>{`${t("Symbol")}`}</span>
                        <span className='tableItem-title'>USDT</span>
                    </div>
                    <div className='tableItem-line' />

                </div>
                <div className='updatelock-tableItem'>
                    <div className='tableItem-text'>
                        <span className='tableItem-title'>{`${t("Decimals")}`}</span>
                        <span className='tableItem-title'>18</span>
                    </div>
                    <div className='tableItem-line' />
                </div>
                <div className='updatelock-tableItem'>
                    <div className='tableItem-text'>
                        <span className='tableItem-title'>{`${t("Balance")}`}</span>
                        <span className='tableItem-title'>656518646498498549</span>
                    </div>
                    <div className='tableItem-line' />
                </div>
                <div className='updatelock-tableItem amexInput-title'>Title{`${t("")}`}</div>
                <div className='updatelock-tableItem lockInput'>
                    <input className='lock-input' value={updateInput} onChange={(e) => { setUpdateInput(e.target.value) }} />
                </div>
                <div className='update-bottom'>
                    <button onClick={() => { Update() }}>{`${t("update")}`}</button>
                </div>
            </div>
        </div>
    )
}
