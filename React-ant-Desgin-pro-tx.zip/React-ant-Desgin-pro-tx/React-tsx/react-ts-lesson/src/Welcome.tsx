import React, { Children, Fragment } from "react";

// 函数的定义及父子传递参数，接收参数时的约束
interface IProps {
  msg: string;
  //   react 节点
  children?: React.ReactNode;
}
// Welcome({ msg }: { msg?: any })
function Welcome({ msg, children }: IProps) {
  return (
    <div>
      {msg}
      <br />
      {children}
    </div>
  );
}

export const Welcome1: React.FC<IProps> = (props: IProps) => {
  // <Fragment>
  // </Fragment>
  return (
    <>
      Welcome1
      {props.msg}
      <br />
      {props.children}
    </>
  );
};

export default Welcome;
