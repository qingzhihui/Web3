<template>
<button @click="count++">{{ count }}</button>
</template>
<script lang="ts">
import { ref } from 'vue'

export default {
    props: {
    title: String,
    default: Boolean
  },
  setup(props, context) {
    const count = ref(0)
    // 使用props中的值
    console.log(props.title)
    // emit 事件
    context.emit('事件命')
 
    // 返回值会暴露给模板和其他的选项式 API 钩子
    return {
      count
    }
  },
 
  mounted() {
    console.log(this.count) // 0
  }
}
</script>
<style scoped></style>