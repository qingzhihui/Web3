﻿export default [
  {
    path: '/welcome',
    name: 'welcome',
    icon: 'smile',
    component: '@/pages/Welcome/index',
  },
  {
    path: '/admin',
    name: 'admin',
    icon: 'crown',
    access: 'canAdmin',
    routes: [
      {
        path: '/admin/sub-page',
        name: 'sub-page',
        icon: 'smile',
        component: './Welcome',
      },
      {
        component: './404',
      },
    ],
  },
  {
    name: 'Generate Wallet',
    icon: 'table',
    path: '/TableList',
    component: './TableList',
  },
  {
    name: 'Batch transfer',
    icon: 'table',
    path: '/carry',
    routes: [
      {
        path: '/carry/TransLink',
        name: 'Batch transfer to Token',
        icon: 'table',
        component: './TransLink',
      },
      {
        path: '/carry/Children',
        name: 'Batch transfer to Ether  (BNB)',
        icon: 'table',
        component: './Children',
      },
    ],
  },
  {
    name: 'Generate Wallet',
    icon: 'table',
    path: '/multiac',
    component: './Multiac',
  },
  {
    path: '/carry/Tramajor',
    component: './Tramajor',
  },
  {
    path: '/carry/ChilLink',
    component: './ChilLink',
  },
  {
    path: '/',
    redirect: '/welcome',
  },
  {
    component: './404',
  },
];
