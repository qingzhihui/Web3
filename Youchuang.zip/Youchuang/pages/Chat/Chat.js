import { text_request } from "../../utils/text_request"
import { portrait } from "../../utils/config"

Page({
  /**
   * 页面的初始数据
   */
  data: {
    topBarHeight: 0,
    operationBox: 0,
    keyboardHeight: 0,
    dataList: [],
    flag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    this.getDialogHeight();
    this.flush("友创创已经接入了ChatGPT，你可以问我任何问题哦！", "left", portrait);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {


  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: "友创照耀未来 万物皆可AI",
      imageUrl: "/static/shap5.png",
      path: "/pages/index/index"
    }
  },

  /**
   * 获取对话框的高度
  */
  getDialogHeight() {
    let self = this;
    const query1 = this.createSelectorQuery();
    query1.select(".top-bar").boundingClientRect();
    query1.exec(function (res) {
      self.setData({
        topBarHeight: res[0].height
      });
    });
    const query2 = this.createSelectorQuery();
    query2.select(".operation-box").boundingClientRect();
    query2.exec(function (res) {
      self.setData({
        operationBox: res[0].height
      });
    });
  },

  /**
   * 刷新数据
  */
  flush(item, location, images= null) {
    let dataList = this.data.dataList;
    dataList.push({
      location: location,
      time: Date.now(),
      content: item,
      images: images
    })
    this.setData({
      dataList: dataList
    })
  },

  /**
   * 提交事件
  */
  submit(e) {
    this.setData({ flag: true });
    const value = e.detail.value;
    setTimeout(() => { this.flush(value, "right") }, 10);
    setTimeout(() => { this.flush("waiting", "left", portrait) }, 30);
    (async () => {
      const val = await text_request(value);
      this.data.dataList.pop()
      this.setData({ dataList: this.data.dataList })
      if (val === false) {
        this.flush("抱歉因为网络问题请求失败了...", "left", portrait);
      } else {
        this.flush(val.trim(), "left", portrait);
      }
      this.setData({ flag: false });
    })();
    return
  },

  /**
   * 键盘抬起事件
  */
 inpFocus(e) {
    this.setData({ keyboardHeight: e.detail.height });
  },

  /**
   * 键盘收起事件
  */
 inpBlur(e) {
  this.setData({ keyboardHeight: 0 });
}
})