import { Stack, Text } from "@mantine/core";
import React from "react";
import { useQuery } from "react-query";
import useSWR from "swr";

const subscribeToLog = () => {
  let log: any = [];
  let logIndex = 0;
  setInterval(() => {
    log.push(`${logIndex}: ${Date.now()}`);
    logIndex++;
    log = log.slice(-3);
  }, 100);

  return () => log;
};

const logListener = subscribeToLog();

function Logger() {
  // Query
  //   const { data: log } = useQuery("log", logListener, {
  //     refetchInterval: 1000,
  //   });
  //   SWR
  //   const { data } = useSWR("log", logListener, {
  //     refreshInterval: 1000,
  //     dedupingInterval: 1000,
  //   });
  return (
    <Stack>
      <Text>Logger</Text>
      {/* {data?.map((entry: any, index: any) => (
        <Text key={index}>{entry}</Text>
      ))} */}
    </Stack>
  );
}

export default Logger;
