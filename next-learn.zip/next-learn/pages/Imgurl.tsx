import React from "react";
import Image from "next/image";
import Qr from "../public/mayi.png";

function img() {
  return (
    <div>
      <div style={{ width: "100px", height: "100px" }}>
        <Image
          src="/mayi.png"
          alt="Picture of the author"
          width={500}
          height={500}
        />
      </div>
      <Image
        src={Qr}
        alt="Picture of the author"
        // width={500} automatically provided
        // height={500} automatically provided
        // blurDataURL="data:..." automatically provided
        // placeholder="blur" // Optional blur-up while loading
      />
    </div>
  );
}

export default img;
