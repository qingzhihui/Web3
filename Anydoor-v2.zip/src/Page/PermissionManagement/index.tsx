import "./index.css";
import { Tabs } from "antd";
import AdministratorsPage from "./AdministratorsPage"

// 权限管理界面
const PermissionManagement = () => {
  const dataList = [
    {
      label: "角色",
      key: 1,
      children: <div>角色</div>,
    },
    {
      label: "管理员",
      key: 2,
      children: <AdministratorsPage/>,
    },
    {
      label: "角色管理",
      key: 3,
      children: <div>普通用户</div>,
    },
  ];
  return (
    <div className="qxgl_Box">
      <div className="qxgl_headerBox">
        <div className="qxgl_headerBox_thread"></div>
        <div className="qxgl_headerBox_Tit">&nbsp;&nbsp;&nbsp; 权限管理</div>
      </div>

      <div className="qxgl_tableBox">
        <Tabs
          tabPosition="left"
          items={dataList.map((item:any) => {
            return {
              label: item.label,
              key: item.key,
              children: item.children,
            };
          })}
        />
      </div>
    </div>
  );
};

export default PermissionManagement;
