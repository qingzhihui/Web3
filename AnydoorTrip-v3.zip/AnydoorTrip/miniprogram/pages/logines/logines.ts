// pages/logines/logines.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    checked: true,
    encryptedData: "",
    iv: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },
  onChange(event: any) {
    this.setData({
      checked: event.detail,
    });
  },
  login() {
    wx.login();
  },
  getTal(e: any) {
    var that = this;
    let {
      encryptedData,
      iv
    } = e.detail
    wx.login({
      success(result) {
        if (e.detail.errMsg === "getPhoneNumber:ok") {
          let code = result.code
          wx.request({
            url: 'https://sas-myad-login2.anydoortrip.com/wxLogin',
            method: "POST",
            data: {
              code: code,
              encryptedData: encryptedData,
              iv: iv,
              phone_code: e.detail.code
            },
            success: function (res: any) {
              const data = res.data.data;
              const token = res.header.token;
              const dataBuins = { ...data, access_token: token }
              wx.setStorageSync('admin', dataBuins);
              var pages = getCurrentPages();
              var beforePage = pages[pages.length - 2];
              wx.navigateBack({
                delta: -1,
                success: function () {
                  beforePage.LoginStateButton(false);
                }
              })
            },
            fail: function (err) {
              console.log('请求失败', err);
              that.triggerEvent('LoginStateButton', true)
            }
          })
        } else if (e.detail.errMsg === 'getPhoneNumber:fail user deny') {
          wx.showToast({
            title: '您拒绝了授权',
            icon: 'none',
            duration: 2000
          })
          that.triggerEvent('LoginStateButton', true)
        }
      },
      fail(error) {
        console.log(error);
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})