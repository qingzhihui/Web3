import React from "react";
import type { MenuProps } from "antd";
import { BigNumber, ethers } from "ethers";
import {
  IDOCONTRACT_ABI,
  IDOCONTRACT_ADDR,
  PANCAKEROUTER_ABI,
  PANCAKEROUTER_ADDRESS,
  WETHADDRESS,
} from "../config/abi";
import { standardTokenABI } from "../config/standardToken";
import { presaleToken_ADDR } from "../config/presaleToken";

declare const window: Window & { ethereum: any };
export type MenuItem = Required<MenuProps>["items"][number];
export const BUSDAddress = `0xC6b9597a53C8e74F6135c9Ea3606619Fe761D81d`;
export const USDTAddress = `0x4F03B866457f78c51bf4Fb43774DCe45c7d061a3`;
export const BNBAddress = `0x0000000000000000000000000000000000000000`;
export const USDCAddress = `0x1Ddbce6B21F04a2786227029BC8b6f55D1A1cC2A`;

export interface Lineg {
  name?: string;
  symbol?: string;
  decimals?: string;
  balanceOf?: string;
}
const getItem = (
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
  type?: "group",
  router?: string
): MenuItem => {
  return {
    key,
    icon,
    children,
    label,
    type,
    router,
  } as MenuItem;
};

const connecteState = () => {
  const connecteState = localStorage.getItem("wagmi.connected");
  if (connecteState !== null && connecteState !== undefined) {
    return Boolean(connecteState);
  } else {
    return false;
  }
};

const InstancedContract = (address: any, abi: any) => {
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = provider.getSigner();
  const Contract = new ethers.Contract(address, abi, signer);
  return Contract;
};

const ObtainAddress = async () => {
  if (window.ethereum) {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const balance = await signer.getBalance();
    return {
      address,
      balance,
    };
  } else {
    return;
  }
};

const items: MenuProps["items"] = [
  {
    key: "1",
    label: "BUSD BEP20",
  },
  {
    key: "2",
    label: "USDT BEP20",
  },
  {
    key: "3",
    label: "BNB BEP20",
  },
  {
    key: "4",
    label: "USDC BEP20",
  },
];

const MenuUser: any = [
  {
    key: "1",
    label: "BUSD BEP20",
    address: BUSDAddress,
  },
  {
    key: "2",
    label: "USDT BEP20",
    address: USDTAddress,
  },
  {
    key: "3",
    label: "BNB BEP20",
    address: BNBAddress,
  },
  {
    key: "4",
    label: "USDC BEP20",
    address: USDCAddress,
  },
];

const Token0InputValueChange = async (
  value: string,
  selectTokenKey: string
) => {
  if (window.ethereum) {
    const pancakeContract = InstancedContract(
      PANCAKEROUTER_ADDRESS,
      PANCAKEROUTER_ABI
    );
    const busdTokenContract = InstancedContract(BUSDAddress, standardTokenABI);
    const idoContract = InstancedContract(IDOCONTRACT_ADDR, IDOCONTRACT_ABI);
    const icoTokenContract = InstancedContract(
      presaleToken_ADDR,
      standardTokenABI
    );
    const icoTokenDecimals = await icoTokenContract.decimals();
    const busdTokenDecimals = await busdTokenContract.decimals();
    const amountIn = ethers.utils.parseUnits(value, busdTokenDecimals);
    let path = [];
    let amountOut;
    let amountBusdIn;
    let distributionPercentageCal;
    const price = await idoContract.price();
    const VestingManagersCount = await idoContract.getVestingManagersCount();
    const decimalsCal = BigNumber.from(10).pow(icoTokenDecimals);
    const priceCal = BigNumber.from(price.toString());
    const PERCENTAGE_DENOM_CAL = BigNumber.from(10000);
    if (selectTokenKey === "1") {
      amountBusdIn = amountIn;
      for (
        let index = 0;
        index < Number(VestingManagersCount.toString());
        index++
      ) {
        const vestingManagers = await idoContract.getVestingManager(index);
        distributionPercentageCal = BigNumber.from(
          vestingManagers[1].toString()
        );
        const amountBusdInByVestingManager: BigNumber = amountBusdIn
          .mul(distributionPercentageCal)
          .div(PERCENTAGE_DENOM_CAL);
        amountOut = amountBusdInByVestingManager.mul(decimalsCal).div(priceCal);
      }
    } else if (selectTokenKey === "2") {
      path.push(USDTAddress);
      path.push(BUSDAddress);
      const amountsOut = await pancakeContract.getAmountsOut(amountIn, path);
      amountBusdIn = amountsOut[1].toString();
      const amountBusdInCal = BigNumber.from(amountBusdIn);
      for (
        let index = 0;
        index < Number(VestingManagersCount.toString());
        index++
      ) {
        const vestingManagers = await idoContract.getVestingManager(index);
        distributionPercentageCal = BigNumber.from(
          vestingManagers[1].toString()
        );
        const amountBusdInByVestingManager: BigNumber = amountBusdInCal
          .mul(distributionPercentageCal)
          .div(PERCENTAGE_DENOM_CAL);
        amountOut = amountBusdInByVestingManager.mul(decimalsCal).div(priceCal);
      }
    } else if (selectTokenKey === "3") {
      path.push(WETHADDRESS);
      path.push(BUSDAddress);
      const amountsOut = await pancakeContract.getAmountsOut(amountIn, path);
      amountBusdIn = amountsOut[1].toString();
      const amountBusdInCal = BigNumber.from(amountBusdIn);
      for (
        let index = 0;
        index < Number(VestingManagersCount.toString());
        index++
      ) {
        const vestingManagers = await idoContract.getVestingManager(index);
        distributionPercentageCal = BigNumber.from(
          vestingManagers[1].toString()
        );
        const amountBusdInByVestingManager: BigNumber = amountBusdInCal
          .mul(distributionPercentageCal)
          .div(PERCENTAGE_DENOM_CAL);
        amountOut = amountBusdInByVestingManager.mul(decimalsCal).div(priceCal);
      }
    } else if (selectTokenKey === "4") {
      path.push(USDCAddress);
      path.push(BUSDAddress);
      const amountsOut = await pancakeContract.getAmountsOut(amountIn, path);
      amountBusdIn = amountsOut[1].toString();
      const amountBusdInCal = BigNumber.from(amountBusdIn);
      for (
        let index = 0;
        index < Number(VestingManagersCount.toString());
        index++
      ) {
        const vestingManagers = await idoContract.getVestingManager(index);
        distributionPercentageCal = BigNumber.from(
          vestingManagers[1].toString()
        );
        const amountBusdInByVestingManager: BigNumber = amountBusdInCal
          .mul(distributionPercentageCal)
          .div(PERCENTAGE_DENOM_CAL);
        amountOut = amountBusdInByVestingManager.mul(decimalsCal).div(priceCal);
      }
    }
    return {
      amountBusdIn:(amountBusdIn as any).toString(),
      amountOut:ethers.utils.formatUnits(amountOut as any, icoTokenDecimals)
    }
  }
};
const allowance = async (tokenAddress: string, lockAddress: string) => {
  const { address } = await ObtainAddress()  as any;
  const allowance = await (InstancedContract(tokenAddress, standardTokenABI) as any).allowance(
    address,
    lockAddress
  );
  return allowance;
};

const FormatUnitsConver = (amount: any, decimals: any) => {
  const FormatUnitsValue = ethers.utils.formatUnits(amount, decimals);
  return FormatUnitsValue;
};

export {
  getItem,
  InstancedContract,
  ObtainAddress,
  items,
  MenuUser,
  connecteState,
  Token0InputValueChange,
  allowance,
  FormatUnitsConver
};
