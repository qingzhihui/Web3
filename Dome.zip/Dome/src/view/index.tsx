import { useEffect, useState } from "react";

// useEffect双重呼叫；错误还是太棒了？

const BadStopwatch = () => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    console.log('BadStopwatch useEffect');
    setInterval(() => {
      setCount((v) => v + 0.1);
    }, 100);
  }, []);
  return <div>Bad Stopwatch:{count.toFixed(1)}</div>;
};

const GoodStopwatch = () => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setCount((v) => v + 0.1);
    }, 100);
    return () => clearInterval(interval);
  }, []);
  return <div>Good Stopwatch:{count.toFixed(1)}</div>;
};

function Home() {
  return (
    <div
      style={{
        display: "grid",
        gridAutoColumns: "1fr 1fr",
      }}
    >
      <BadStopwatch />
      <GoodStopwatch />
    </div>
  );
}

export default Home;
