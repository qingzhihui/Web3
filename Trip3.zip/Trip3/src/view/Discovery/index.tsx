import React from "react";

const Discovery = () => {
  return <div>Discovery</div>;
};

export default Discovery;
