import { PlusOutlined } from "@ant-design/icons";
import {
  Button,
  Form,
  Input,
  Modal,
  Radio,
  Space,
  Table,
  Upload,
  UploadFile,
  UploadProps,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { DeleteOutlined, FormOutlined } from "@ant-design/icons";
import { RcFile } from "antd/es/upload";
import { useState } from "react";

// 用户管理界面
const UserManage = () => {
  const [isaddAdmin, setUpdajx] = useState(false);
  interface DataType {
    key: string;
    userImgs: string;
    username: string;
    nickname: string;
    phoneNumber: string;
    cipher: string;
    status: string;
    createTime: string;
    role: string;
  }
  const data: DataType[] = [
    {
      key: "1",
      userImgs:
        "https://img1.baidu.com/it/u=1088787692,1934871725&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1679504400&t=8edc57c31a5590ec681749b265672792",
      username: "张三",
      nickname: "测试用户",
      phoneNumber: "13543035444",
      cipher: "xxxx123456",
      status: "正常",
      createTime: "2023-03-08 14:24",
      role: "经理",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "序号",
      dataIndex: "name",
      key: "name",
      render: (_, record, i) => (
        <Space size="middle">
          <div>{i + 1}</div>
        </Space>
      ),
    },
    {
      title: "用户头像",
      dataIndex: "userImgs",
      key: "userImgs",
      render: (_, record, i) => (
        <Space size="middle">
          <div className="us_tabImg">
            <img src={record.userImgs} />
          </div>
        </Space>
      ),
    },
    {
      title: "用户名",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "用户昵称",
      dataIndex: "nickname",
      key: "nickname",
    },
    {
      title: "手机号",
      dataIndex: "phoneNumber",
      key: "phoneNumber",
    },
    {
      title: "密码",
      dataIndex: "cipher",
      key: "cipher",
    },
    {
      title: "状态",
      key: "tags",
      render: (_, record) => (
        <Space size="middle">
          <div className="us_tagsStyle">{record.status}</div>
        </Space>
      ),
    },
    {
      title: "创建时间",
      dataIndex: "createTime",
      key: "createTime",
    },

    {
      title: "职位",
      dataIndex: "role",
      key: "role",
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <a onClick={uploadus(record)} className="publicStyleA" href="#">
            <span>
              <FormOutlined />
            </span>
          </a>
          <a onClick={deleteus(record)} className="publicStyleA" href="#">
            <span>
              <DeleteOutlined />
            </span>
          </a>
        </Space>
      ),
    },
  ];

  //  新增-提交按钮
  const addUserBnt = (values: any) => {
    console.log("提交的数据", values);
  };

  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 修改
  const uploadus = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };
  // 点击X关闭
  const handleCancel = () => {
    setUpdajx(false);
  };

  // 点击新增管理员
  const usAddUser = () => {
    console.log("点击了新增管理员");
    setUpdajx(true);
  };

  const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });

  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewTitle, setPreviewTitle] = useState("");
  const [fileList, setFileList] = useState<UploadFile[]>([]);

  const handleCancel1 = () => setPreviewOpen(false);

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
    setPreviewTitle(
      file.name || file.url!.substring(file.url!.lastIndexOf("/") + 1)
    );
  };

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) =>
    setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );
  return (
    <div className="us_Box">
      <div className="us_headerBox">
        <div className="us_headerBox_thread"></div>
        <div className="us_headerBox_Tit">&nbsp;&nbsp;&nbsp; 用户管理</div>
        <div className="us_Add_moban">
          <div className="us_usernameInpuit">
            <div className="us_publicStyleTit">用户名称：</div>
            <div className="us_publicStyleIpt">
              <Input placeholder="请输入管理员名称" />
            </div>
          </div>
          <div className="us_adminUsernameInpuit">
            <div className="us_publicStyleTit">手机号：</div>
            <div className="us_publicStyleIpt">
              <Input placeholder="请输入管理员账户" />
            </div>
          </div>

          <a href="#">
            <div className="us_seekBtn" onClick={adminSearch}>
              查找
            </div>
          </a>

          <div className="us_addAdminBtn" onClick={usAddUser}>
            新增用户
          </div>
          {/* 新增用户 */}
          <Modal
            className="us_addAdmin"
            footer={[null]}
            open={isaddAdmin}
            onCancel={handleCancel}
          >
            <div className="us_headerBox">
              <div className="us_headerBox_thread"></div>
              <div className="us_headerBox_Tit">&nbsp;&nbsp;&nbsp;添加用户</div>
            </div>
            <div className="us_addAdmin_Box">
              <Form
                name="basic"
                labelCol={{ span: 6 }}
                wrapperCol={{ span: 18 }}
                style={{ maxWidth: 600 }}
                initialValues={{ remember: true }}
                onFinish={addUserBnt}
                autoComplete="off"
              >
                <Form.Item label="用户头像" name="templateCode">
                  <Upload
                    action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                    listType="picture-card"
                    fileList={fileList}
                    onPreview={handlePreview}
                    onChange={handleChange}
                  >
                    {fileList.length >= 1 ? null : uploadButton}
                  </Upload>
                  <Modal
                    open={previewOpen}
                    title={previewTitle}
                    footer={null}
                    onCancel={handleCancel1}
                  >
                    <img
                      alt="example"
                      style={{ width: "100%" }}
                      src={previewImage}
                    />
                  </Modal>
                </Form.Item>
                <Form.Item label="用户名" name="username">
                  <Input placeholder="请输入用户名" />
                </Form.Item>
                <Form.Item label="姓名" name="name">
                  <Input placeholder="请输入姓名" />
                </Form.Item>
                <Form.Item label="用户昵称" name="usernick">
                  <Input placeholder="请输入用户昵称" />
                </Form.Item>
                <Form.Item label="密码" name="password">
                  <Input placeholder="请输入密码" />
                </Form.Item>
                <Form.Item label="手机号" name="phone">
                  <Input placeholder="请输入手机号" />
                </Form.Item>
                <Form.Item label="设置角色" name="setUpRole">
                  <Radio.Group>
                    <Radio value="apple"> 经理 </Radio>
                    <Radio value="pear"> 主管 </Radio>
                    <Radio value="pear"> 前台 </Radio>
                  </Radio.Group>
                </Form.Item>

                <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                  <Button
                    className="us_btn"
                    size="middle"
                    type="primary"
                    htmlType="submit"
                  >
                    提交
                  </Button>
                </Form.Item>
              </Form>
            </div>
          </Modal>
        </div>
      </div>

      <div className="us_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default UserManage;
