// function firstElement(arr: any[]) {
//   return arr[0];
// }
// firstElement(["a", "b", "c"]);

// function firstElement<Type>(arr: Type[]): Type | undefined {
//     return arr[0];
// }

// firstElement(["a", "b", "c"]);
// firstElement([1,2,3]);
// firstElement([])

// firstElement<string>(["a", "b", "c"]);
// firstElement<number>([1,2,3]);
// firstElement<undefined>([])

function map<Input, Output>(
  arr: Input[],
  func: (arg: Input) => Output
): Output[] {
  return arr.map(func);
}

const parsed = map(["1", "2", "3"], (n) => parseInt(n));
