import { ethers } from "ethers";
import { useDispatch } from "react-redux";
import { supportedChainsID } from "../helpers/chains";
import {
  changeAccount,
  changeChainId,
  changeProvider,
} from "../redux/slice/web3";

function useWeb3SubscribeProvider() {
  const dispatch = useDispatch();

  const resetAll = () => {
    dispatch(changeChainId(null));
    dispatch(changeAccount(null));
    dispatch(changeProvider(null));
  };

  const subscribeProvider = async (provider: any) => {
    if (!provider.on) {
      return;
    }

    provider.on("disconnect", () => resetAll());

    provider.on("connect", (info: { chainId: number }) => {
      console.log(info);
    });

    provider.on("accountsChanged", async (accounts: string[]) => {
      dispatch(changeAccount(accounts[0]));
    });
    provider.on("chainChanged", async (chainId: number) => {
      const signer = new ethers.providers.Web3Provider(provider).getSigner();
      const _chainId = await signer.getChainId();
      if (!supportedChainsID.includes(_chainId)) return resetAll();
      dispatch(changeChainId(_chainId));
    });
  };
  return { subscribeProvider, resetAll };
}

export default useWeb3SubscribeProvider;
