import "./index.scss";
import GetYourPlayer from "./GetYourPlayer";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import MyPlayer from "./MyPlayer";
import DailyMining from "./DailyMining";
import Merge from "./Merge";
import PVE from "./PVE";
import OpenChests from "./OpenChests";
import React, { useEffect } from "react";
import Leaderboard from "./Leaderboard";
import Referral from "./Referral";
import Select from "../../Component/Select";
import {useTranslation} from "react-i18next";

export default function Game(props: {children:any[]}) {
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(() => {
    if (location.pathname === "/game") {
      navigate(props.children[0].path);
    }
  }, [location]);

  const {t} = useTranslation()


  return (
    <div id="game">
      <Select
        list={props.children.map((item) => {
          return {
            label: item.name,
            value: item.path,
          };
        })}
        active={location.pathname}
        onChange={(item) => {
          navigate(item.value);
        }}
      />
      <div className="children-list">
        {props.children.map((item, key) => {
          return (
            <NavLink key={key} to={item.path}>
              {item.name}
            </NavLink>
          );
        })}
      </div>
      <div className="views">
        <Outlet />
      </div>
    </div>
  );
}
