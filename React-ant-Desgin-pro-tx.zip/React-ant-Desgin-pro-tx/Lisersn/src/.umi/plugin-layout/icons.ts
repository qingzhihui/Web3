// @ts-nocheck

  import SmileOutlined from '@ant-design/icons/es/icons/SmileOutlined';
import CrownOutlined from '@ant-design/icons/es/icons/CrownOutlined'
  export default {
    SmileOutlined,
CrownOutlined
  }