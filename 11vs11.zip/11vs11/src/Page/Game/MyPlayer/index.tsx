import "./index.scss";
import { useEffect, useState } from "react";
import { useGetWeb3 } from "../../../hooks/useGetWeb3";
import useWeb3Connector from "../../../hooks/web3Connector";
import img1 from "../../../Component/Hd/img/CardPackItem_1.png";
import { couldStartTrivia } from "typescript";
import OpenBox from "./OpenBox";
import Card from "./Card";
import { ethers } from "ethers";
import data from "./data.json";
import { useTranslation } from "react-i18next";
import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../../../redux/Contract/SmartContract";

export default function MyPlayer() {
  const { account, instance, tokenBalance, provider } = useGetWeb3();
  const { onConnect } = useWeb3Connector();

  const [add, setAdd] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<
    "loading" | "close" | "success" | "open" | "error"
  >("close");
  const [tokenId, setTokenId] = useState("");
  const [data, setData] = useState({});

  const [_rarity, setRarity] = useState("");
  const [_speed, setSpeed] = useState("");
  const [_shoot, setShoot] = useState("");
  const [_guard, setGuard] = useState("");
  const [_save, setSave] = useState("");
  const [_lucky, setLucky] = useState("");
  const [_vocation, setVocation] = useState("");

  useEffect(() => {
    onConnect();
  }, [loading]);

  function getRandomInt(min: any, max: any) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  const unBox = async (e: any) => {
    try {
      const tx = await instance.unboxing(e.target.value,{gasLimit:500000});
      await tx.wait();
      setLoading(true);
      setStatus("loading");
      let lastConfirms = -1;
      // @ts-ignore
      async function handler(blockNumber: any) {
        let receipt = await provider.getTransactionReceipt(tx.hash);
        if (receipt == null || receipt.confirmation < lastConfirms) {
          // A re-org; do what you need here
        }
      }
      console.log(data);
      tx.wait(3).then((receipt: any) => {
        // This gets called once there are 3 confirmations
        provider.removeListener("block", handler);
        console.log("receipt", receipt);
        setLoading(false);
      });
    } catch (e: any) {
      setLoading(false);
      if (status === "loading") {
        setStatus("error");
      }
    }
  };
  const acceptData = async (data: any) => {};

  const transfer = async (e: any) => {
    if (ethers.utils.isAddress(add)) {
      const tx = await instance.transferFrom(account, add, e.target.value);
      console.log(tx);
    } else {
      alert("Wallet address incorrect!");
    }
  };

  const { t } = useTranslation();

  return (
    <div id="MyPlayer">
      <OpenBox
        tokenBalance={tokenBalance}
        tokenId={tokenId}
        unBox={unBox}
        status={status}
        setStatus={setStatus}
        loading={loading}
        acceptData={acceptData}
      />
      <div className="no-login">
        {account ? (
          <div className="list">
            {tokenBalance.map((a: any) => {
              // const last = a.image.charAt(a.image.length - 1);

              return (
                <div className="item" key={a.tokenId}>
                  {a.reveal ? (
                    <Card
                      title={a.cName}
                      img={a.image}
                      list={{
                        Properties: a.rarty,
                        Occupation: a.occ,
                        Speed: a.speed,
                        Shoot: a.shoot,
                        Guard: a.guard,
                        Save: a.save,
                        Lucky: a.lucky,
                      }}
                    />
                  ) : (
                    <div className="f-g">
                      <video
                        loop
                        muted
                        autoPlay
                        src="https://metadata.11vs11.club/box.mp4"
                      />

                      {/* <video src={a.image} autoPlay muted loop /> */}
                      {/* <img src={a.image} className="left-img" /> */}
                      <button
                        className="common-btn"
                        onClick={() => {
                          setStatus("open");
                          setTokenId(a.tokenId);
                        }}
                      >
                        {!loading ? t("game.Flip the Card") : "Unboxing"}
                      </button>
                    </div>
                  )}

                  <div className="m-form">
                    <input
                      type="text"
                      placeholder={t("game.Enter Address")}
                      onChange={(event) => setAdd(event.target.value)}
                    />

                    <button
                      className="common-btn"
                      onClick={transfer}
                      value={a.tokenId}
                    >
                      {t("game.Transfer")}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <button className="common-btn" onClick={onConnect}>
            CONNECT
          </button>
        )}
      </div>
    </div>
  );
}
