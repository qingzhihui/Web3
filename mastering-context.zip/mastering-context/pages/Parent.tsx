import { useState } from "react";
import Phild from "./components/Phild";

const Parent = () => {
  const [text, setText] = useState("");

  const handleTextChange = (newText: string) => {
    setText(newText);
  };

  return (
    <>
      <Phild text={text} onTextChange={handleTextChange} />
      <p>Parent Text: {text}</p>
    </>
  );
};

export default Parent;
