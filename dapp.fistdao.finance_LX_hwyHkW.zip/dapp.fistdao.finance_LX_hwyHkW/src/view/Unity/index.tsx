import React, { useEffect, useState } from "react";
import "./index.scss";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import { Button, message, notification, Modal } from "antd";
import Header from "../../components/Header";
import img1 from "../../assets/k6.png";
import img2 from "../../assets/2s.png";
import img3 from "../../assets/3s.png";
import Heues from "../../components/Heues";
import { CheckCircleOutlined, LoadingOutlined } from "@ant-design/icons";
import { Mint_ADDRESS, Mint_ABI } from "../../redux/Contract/mintContract";
import { VOTE_ADDRESS, VOTE_ABI } from "../../redux/Contract/voteContract";
import { wben_ABI } from "../../redux/Contract/wbenjson";
const sroIOaddress = "0x7c30987194657a8a7129b07b06f12b3e9b04856b";
declare const window: Window & { ethereum: any };
const key = "updatable";

const openNotification = (bindValue: any, durn: any, icon: any) => {
  notification.open({
    key,
    message: "提示",
    description: bindValue,
    duration: durn,
    icon: icon,
  });
};

function Index() {
  const [unShow, setunShow] = useState(false);
  const [jg1, setjg1] = useState("");
  const [jg2, setjg2] = useState("");
  const [jg3, setjg3] = useState("");
  const [shengyu1, setshengyu1] = useState("");
  const [shengyu2, setshengyu2] = useState("");
  const [shengyu3, setshengyu3] = useState("");
  const [uning, setUning] = useState("");
  const [unadr, setUnadr] = useState("");
  const [detin, setDetin] = useState([]);
  const [enable, setEnable] = useState(false);
  const [approved, setapproved] = useState("");
  const [wbds1, setwbds1] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isModalVisible2, setIsModalVisible2] = useState(false);
  const [poeti, setPoeti] = useState("");

  const businShow = (img: any, jg: any) => {
    setUning(img);
    setUnadr(jg);
    setunShow(true);
  };

  const PurpleGoldCard = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const mintContract = new ethers.Contract(Mint_ADDRESS, Mint_ABI, signer);
      const purples = await mintContract.purpleGoldCardPrice();
      const mint = await mintContract.mintPurpleGoldCard();
      openNotification(
        "购买中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setunShow(false);
      await mint.wait();
      openNotification(
        "购买成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error: any) {
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification(
          "用户拒绝购买.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
        setunShow(false);
      } else {
        if ((error.data.code = "-32603")) {
          openNotification(
            "余额不足.",
            2,
            <CheckCircleOutlined style={{ color: "#ffc400" }} />
          );
        }
      }
    }
  };
  const shuiegn = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const skoerContract = new ethers.Contract(sroIOaddress, wben_ABI, signer);
    const buaer = await skoerContract.approve(
      Mint_ADDRESS,
      ethers.constants.MaxUint256
    );
    openNotification(
      "授权中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await buaer.wait();
    openNotification(
      "授权成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
    setwbds1(true);
  };
  const BlackGoldCard = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const mintContract = new ethers.Contract(Mint_ADDRESS, Mint_ABI, signer);
      const purples = await mintContract.blackGoldCardPrice();
      const mint = await mintContract.mintBlackGoldCard();
      openNotification(
        "购买中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setunShow(false);
      await mint.wait();
      openNotification(
        "购买成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error: any) {
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification(
          "用户拒绝购买.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
        setunShow(false);
      } else {
        if ((error.data.code = "-32603")) {
          openNotification(
            "余额不足.",
            2,
            <CheckCircleOutlined style={{ color: "#ffc400" }} />
          );
        }
      }
    }
  };
  const WhiteGoldCard = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const mintContract = new ethers.Contract(Mint_ADDRESS, Mint_ABI, signer);
      const purples = await mintContract.whiteGoldCardPrice();
      const mint = await mintContract.mintWhiteGoldCard({
        value: purples.toString(),
      });
      openNotification(
        "购买中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setunShow(false);
      await mint.wait();
      openNotification(
        "购买成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error: any) {
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification(
          "用户拒绝购买.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
        setunShow(false);
      } else {
        if ((error.data.code = "-32603")) {
          openNotification(
            "余额不足.",
            2,
            <CheckCircleOutlined style={{ color: "#ffc400" }} />
          );
        }
      }
    }
  };
  const TingList = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const mintContract = new ethers.Contract(Mint_ADDRESS, Mint_ABI, signer);
    const skoerContract = new ethers.Contract(sroIOaddress, wben_ABI, signer);
    const kdro = await skoerContract.decimals();

    const bsyteug = await skoerContract.allowance(addr, Mint_ADDRESS);
    if (bsyteug > 0) {
      setwbds1(true);
    } else {
      setwbds1(false);
    }

    const snuer1 = await mintContract.blackGoldCardPrice();
    const isuer1 = snuer1 / 10 ** kdro;
    setjg1(isuer1.toString());

    const snuer2 = await mintContract.purpleGoldCardPrice();
    const isuer2 = snuer2 / 10 ** kdro;
    setjg2(isuer2.toString());

    const snuer3 = await mintContract.whiteGoldCardPrice();
    setjg3(ethers.utils.formatEther(snuer3.toString()));

    const Baishe = await mintContract.whiteGoldCardMaxSupply();
    const BaiMin = await mintContract.whiteGoldCardAmount();
    const slier = Number(Baishe.toString()) - Number(BaiMin.toString());
    setshengyu1(String(slier));
    const Zhishe = await mintContract.purpleGoldCardMaxSupply();
    const ZhiMin = await mintContract.purpleGoldCardAmount();
    const zlier = Number(Zhishe.toString()) - Number(ZhiMin.toString());
    setshengyu2(String(zlier));

    const Henshe = await mintContract.blackGoldCardMaxSupply();
    const HenMin = await mintContract.blackGoldCardAmount();
    const hlier = Number(Henshe.toString()) - Number(HenMin.toString());
    setshengyu3(String(hlier));

    const balance = await mintContract.balanceOf(addr);
    const bel = ethers.utils.formatEther(balance);
    const enable = await mintContract.enable();
    if (enable !== false) {
      setEnable(true);
    }
    const nftAmount = new BigNumber(bel)
      .times(new BigNumber(10).pow(18))
      .toString();

    const bsiue = await mintContract.ownedBlackGoldCardAmount(addr);
    const bsiue12 = await mintContract.ownedPurpleGoldCardAmount(addr);
    const lihh = Number(bsiue.toString()) + Number(bsiue12.toString());
    const voteContract = new ethers.Contract(VOTE_ADDRESS, VOTE_ABI, signer);
    const vetipin = await voteContract.getTotalClaimedVotes(addr);
    const sbuein = await voteContract.getTotalVotedVotes(addr);
    const wyhrej = vetipin - sbuein;
    const poeti = parseFloat(ethers.utils.formatEther(wyhrej.toString()));
    setPoeti(String(poeti));
    let tokenBalance: any = [];
    for (let i = 0; i < Number(lihh.toString()); i++) {
      const told = await mintContract.getComunityLeaderNFT(addr);
      const ijjj = Number(told[i].toString());
      // const told = await mintContract.getComunityLeaderNFT();
      const basetokenUri = await mintContract.tokenURI(ijjj.toString());
      const votedv = await voteContract.userData(addr);
      const voteLis = await voteContract.getCLeaderVotes(addr);

      const suwie = parseFloat(ethers.utils.formatEther(voteLis.toString()));
      await fetch(basetokenUri)
        .then((response) => response.json())
        .then((data) => {
          const uri = "https://ipfs.youwant.io/ipfs/" + data.image.slice(7);
          tokenBalance.push({
            tokenid: Number(ijjj.toString()),
            url: uri,
            suol: votedv.totalVotedVotes.toString(),
            arrdes: addr,
            suwie: suwie,
          });
        });
    }
    setDetin(tokenBalance);
  };
  const OnBuser = async (address: any) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const voteContract = new ethers.Contract(VOTE_ADDRESS, VOTE_ABI, signer);
      const ntract = await voteContract.vote(address);
      openNotification(
        "投票中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setIsModalVisible(false);
      await ntract.wait();
      openNotification(
        "投票成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error: any) {
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification(
          "用户拒绝投票.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
        setIsModalVisible(false);
      } else {
        if (JSON.parse(JSON.stringify(error)).error.code == -32603) {
          openNotification(
            "你没有多余的票数来投票.",
            2,
            <CheckCircleOutlined style={{ color: "#ffc400" }} />
          );
        }
      }
    }
  };
  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const handleCancel2 = () => {
    setIsModalVisible2(false);
  };
  const Chenuer = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const voteContract = new ethers.Contract(VOTE_ADDRESS, VOTE_ABI, signer);
      const wfee = await voteContract.transferFee();
      const votubnr = await voteContract.withdrawVote({
        value: wfee.toString(),
      });
      openNotification(
        "撤票中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setIsModalVisible2(false);
      await votubnr.wait();
      openNotification(
        "撤票成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error) {
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification(
          "用户拒绝投票.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
        setIsModalVisible2(false);
      } else {
        if (JSON.parse(JSON.stringify(error)).error.code == -32603) {
          openNotification(
            "你还没有投票,无法撤票.",
            2,
            <CheckCircleOutlined style={{ color: "#ffc400" }} />
          );
        }
      }
    }
  };
  const onPlone = () => {
    setIsModalVisible(true);
  };
  const onChesn = async () => {
    setIsModalVisible2(true);
  };

  useEffect(() => {
    const ahsdr = localStorage.getItem("addr");
    if (ahsdr !== null && ahsdr !== undefined) {
      TingList();
    }
    (window as any).ethereum.on(
      "accountsChanged",
      async function (accounts: any) {
        localStorage.setItem("addr", accounts[0]);
        TingList();
      }
    );
    // detin
  }, []);

  return (
    <div className="Rank2">
      <Header />
      <div className="Rankdbi">
        <div className="ranbui">
          <div className="ranbList">
            {enable ? (
              <>
                <div className="busie">
                  <div className="busimg">
                    {/* <img src={img1} alt="" />
                    <div className="bsueran">
                      <div className="bsuLis">限时销售中</div>
                      <div className="bsuLis">仅售 {jg2 || "0.0"} OSKDAO</div>
                      {shengyu2 !== "0" ? (
                        <>
                          {wbds1 ? (
                            <Button
                              onClick={() => {
                                businShow("img1", jg1);
                              }}
                            >
                              购买
                            </Button>
                          ) : (
                            <Button
                              onClick={() => {
                                shuiegn();
                              }}
                            >
                              授权
                            </Button>
                          )}
                        </>
                      ) : (
                        <div className="ssdurn">
                          <Button disabled>售罄</Button>
                        </div>
                      )}
                    </div> */}
                  </div>
                </div>
                <div className="busie">
                  <div className="busimg2">
                    {/* <img src={img2} alt="" />
                    <div className="bsueran">
                      <div className="bsuLis">剩余数量：{shengyu3}</div>
                      <div className="bsuLis">仅售 {jg1 || "0.0"} OSKDAO</div>
                      {shengyu2 !== "0" ? (
                        <>
                          {wbds1 ? (
                            <Button
                              onClick={() => {
                                businShow("img2", jg1);
                              }}
                            >
                              购买
                            </Button>
                          ) : (
                            <Button
                              onClick={() => {
                                shuiegn();
                              }}
                            >
                              授权
                            </Button>
                          )}
                        </>
                      ) : (
                        <div className="ssdurn">
                          <Button disabled>售罄</Button>
                        </div>
                      )}
                    </div> */}

                    <img src={img1} alt="" />
                    <div className="bsueran">
                      <div className="bsuLis">限时销售中</div>
                      <div className="bsuLis">仅售 {jg2 || "0.0"} OSKDAO</div>
                      {shengyu2 !== "0" ? (
                        <>
                          {wbds1 ? (
                            <Button
                              onClick={() => {
                                businShow("img1", jg2);
                              }}
                            >
                              购买
                            </Button>
                          ) : (
                            <Button
                              onClick={() => {
                                shuiegn();
                              }}
                            >
                              授权
                            </Button>
                          )}
                        </>
                      ) : (
                        <div className="ssdurn">
                          <Button disabled>售罄</Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="busie">
                  <div className="busimg">
                    {/* <img src={img3} alt="" />
                    <div className="bsueran">
                      <div className="bsuLis">剩余数量：{shengyu1}</div>
                      <div className="bsuLis">仅售 {jg3 || "0.0"} BNB</div>
                      {shengyu1 !== "0" ? (
                        <Button
                          onClick={() => {
                            businShow("img3", jg3);
                          }}
                        >
                          购买
                        </Button>
                      ) : (
                        <div className="ssdurn">
                          <Button disabled>售罄</Button>
                        </div>
                      )}
                    </div> */}
                  </div>
                </div>
                <div className="basbyue">
                  成为LP股东
                  <div className="wensji">
                    限时开放，限量抢购，唯一身份证明。
                    <div className="bsucolo">
                      这并不只是一张卡牌，他是你在社区元宇宙的唯一身份标识。等到合适的时间，卡牌会翻开，你会得到属于你的人物（名称、属性、稀有度）。
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="byseru">正在加载中,请稍候...</div>
            )}
          </div>
        </div>
        <div className="Nuszerin">
          <div className="Nutitle">
            <div className="kiosei">我的身份标识</div>
            <div className="snuesie">
              我的票数：<span>{poeti}</span>
            </div>
          </div>
          {detin.length !== 0 ? (
            <div className="sbuerid">
              {detin.map((item: any) => (
                <div key={item.tokenid} className="busetList">
                  <div className="buitme">
                    <img src={item.url} alt="" />
                  </div>
                  <div className="tobut">
                    身份编号:
                    <span>{item.tokenid}</span>
                  </div>
                  <div className="tobut2">
                    目前票数:
                    <span>{item.suwie}</span>
                  </div>
                  <div className="btopiao">
                    <Button
                      onClick={() => {
                        onPlone();
                      }}
                    >
                      {item.suol !== "0" ? "加票" : "投票"}
                    </Button>
                    <Button
                      onClick={() => {
                        onChesn();
                      }}
                    >
                      撤票
                    </Button>
                  </div>
                  <Modal
                    title="提示"
                    width={400}
                    visible={isModalVisible}
                    okText="确认"
                    cancelText="取消"
                    centered
                    onOk={() => {
                      OnBuser(item.arrdes);
                    }}
                    onCancel={handleCancel}
                  >
                    <p>注意：请确认是否将您所有的选票投给该社区长？</p>
                  </Modal>
                  <Modal
                    title="提示"
                    width={400}
                    visible={isModalVisible2}
                    okText="确认"
                    cancelText="取消"
                    centered
                    onOk={() => {
                      Chenuer();
                    }}
                    onCancel={handleCancel2}
                  >
                    <p>
                      注意：请确认是否撤销对该社区长的投票,此操作会收取 0.001
                      BNB的数据处理费用.
                    </p>
                  </Modal>
                </div>
              ))}
            </div>
          ) : (
            <div className="nbsuerilk">您这里暂时空空如也！</div>
          )}
        </div>
      </div>
      {unShow ? (
        <div className="psoeiubse">
          <div
            className="prousn"
            onClick={() => {
              setunShow(false);
            }}
          ></div>
          <div className="prinsk">
            <div className="privideo">
              <div className="rpomg">
                <div className="rpomg_img">
                  {/* {uning == "img1" ? (
                    <img src={img1} alt="" />
                  ) : uning == "img2" ? (
                    <img src={img2} alt="" />
                  ) : (
                    <img src={img3} alt="" />
                  )} */}
                  {uning == "img1" ? (
                    <img src={img1} alt="" />
                  ) : (
                    <img src={img2} alt="" />
                  )}
                </div>
                <div className="sbueing">
                  请确认是否要以 [ {unadr} OSKDAO] 的价格购买尊贵的【{" "}
                  {uning == "img1" ? "股东分红卡" : "UItimates"} 】身份标识？
                  {/* // : uning == "img2"
                    // ? "Ultimates"
                    // : "Quality"}{" "} */}
                </div>
                <div className="suvibut">
                  <Button
                    onClick={() => {
                      setunShow(false);
                    }}
                  >
                    取消
                  </Button>
                  <Button
                    onClick={() => {
                      {
                        uning == "img1" ? PurpleGoldCard() : BlackGoldCard();
                        // : uning == "img2"
                        // ? BlackGoldCard()
                        // : WhiteGoldCard();
                      }
                    }}
                  >
                    确认
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      <Heues />
    </div>
  );
}

export default Index;
