import React, { Component } from "react";
import "./index.scss";

import tox1 from "../../assets/1_14.png";
import tox2 from "../../assets/1_15.png";
import tox3 from "../../assets/1_16.png";
import tox4 from "../../assets/1_19.png";
import tox5 from "../../assets/1_20.png";
import tox6 from "../../assets/1_23.png";
import tox7 from "../../assets/1_27.png";
import tox8 from "../../assets/1_28.png";
import tox9 from "../../assets/1_29.png";

import usbe from "../../assets/2.png";
import usbe2 from "../../assets/49.png";
import usbe3 from "../../assets/Frame 4.png";
import Artist from "../../assets/EmoerArtist.png";
import Founder from "../../assets/EmoerFounder.png";
import Developer from "../../assets/EmoerDeveloper.png";
import jto from '../../assets/jto.png'

export default class index extends Component {
  render() {
    return (
      <div className="exhlun">
        <div className="ruinsdlist" id='activity4'>
          <div className="Luen_title">
            <div className="sluines">
              <span>EXHIBIT</span>
              <div className="lihr"></div>
            </div>
          </div>
          <div className="rtuleunisn">
            <div className="rtuleun">
              <div className="lenitm">
                <img src={tox1} />
              </div>
              <div className="lenitm">
                <img src={tox2} />
              </div>
              <div className="lenitm">
                <img src={tox3} />
              </div>
            </div>
            <div className="rtuleun">
              <div className="lenitm">
                <img src={tox4} />
              </div>
              <div className="lenitm">
                <img src={tox5} />
              </div>
              <div className="lenitm">
                <img src={tox6} />
              </div>
            </div>
            <div className="rtuleun">
              <div className="lenitm">
                <img src={tox7} />
              </div>
              <div className="lenitm">
                <img src={tox8} />
              </div>
              <div className="lenitm">
                <img src={tox9} />
              </div>
            </div>
          </div>
          <div className="sliense">
            Based on the original CryptoPunks concept, there are 15,000 unique
            combinations.
            <br /> ShibaPunk holders are rewarded with regular community
            airdrops and rewards.
            <br />
            <br /> <br />
            Hit the button below to mint your ShibaPunk now.
            <div className="lsubebut">
              <button>MINT NOW!</button>
            </div>
          </div>
        </div>
        <div className="sliebndm" id='activity5'>
          <div className="Luen_title">
            <div className="sluines">
              <span>TEAM</span>
              <div className="lihr"></div>
            </div>
          </div>
          <div className="slieb_nro">
            <div className="slieb_item">
              <div className="slieb_item_img">
                <img src={usbe} />
              </div>
              <div className="slieb_item_tile">
                <span>CIyde Moon</span>
              </div>
              <div className="slieb_item_tbiu">
                <img src={Artist} />
              </div>
            </div>
            <div className="slieb_item">
              <div className="slieb_item_img">
                <img src={usbe2} />
              </div>
              <div className="slieb_item_tile">
                <span>CIyde Moon</span>
              </div>
              <div className="slieb_item_tbiu">
                <img src={Founder} />
              </div>
            </div>
            <div className="slieb_item">
              <div className="slieb_item_img">
                <img src={usbe3} />
              </div>
              <div className="slieb_item_tile">
                <span>CIyde Moon</span>
              </div>
              <div className="slieb_item_tbiu">
                <img src={Developer} />
              </div>
            </div>
          </div>
        </div>
        <div className="dibulib">
          <div className="Luen_title">
            <div className="sluines">
              <span>EAQ</span>
              <div className="lihr"></div>
            </div>
          </div>
          <div className="disList">
            <div className="dislink">
              <div className="disl_item">
                  <span>What is a NFT?</span>
                  <div className="ksto">
                     <img src={jto} />
                  </div>
              </div>
              <div className="disl_item">
                  <span>What is a MetaMask?</span>
                  <div className="ksto">
                     <img src={jto} />
                  </div>
              </div>
              <div className="disl_item">
                  <span>When is launch and how much will mint cost?</span>
                  <div className="ksto">
                     <img src={jto} />
                  </div>
              </div>
              <div className="disl_item">
                  <span>Buying NFT for the first time?</span>
                  <div className="ksto">
                     <img src={jto} />
                  </div>
              </div>
              <div className="disl_item">
                  <span>How will you market the Unapologetic Apes NFT?</span>
                  <div className="ksto">
                     <img src={jto} />
                  </div>
              </div>
              <div className="disl_item">
                  <span>Where can I see my Unapologetic Ape after purchase?</span>
                  <div className="ksto">
                     <img src={jto} />
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
