import api from '../../config/axios'
import { differenceInterval } from '../../config/config';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    checked: true,
    id: "",
    mealPlan: {},
    orderUser: {},
    burUrl: "https://travelport.leonardocontentcloud.com/imageRepo/7/0/132/560/122/ZUHZH_6670713001_M.jpg"
  },
  /**
 * 生命周期函数--监听页面加载
 */
  onLoad(options: any) {
    this.setData({
      id: options.id
    })
    api._get(`user/order/${options.id}`).then(res => {
      const dater = differenceInterval(res.data.inTime, res.data.outTime);
      this.setData({
        orderUser: { ...res.data, dater: dater },
        mealPlan: JSON.parse(res.data.mealPlan)
      })
    }).catch(event => {
      console.log(event);
    })
  },
  CheckboxonChange(event: any) {
    this.setData({
      checked: event.detail,
    });
  },
  SelectOncluck() {
    var pages = getCurrentPages();
    var beforePage = pages[pages.length - 2];
    api._put(`user/order/${this.data.id}`).then(res => {
      wx.switchTab({
        url: '../Order/Order',
        success: function () {
          beforePage.OrderDataSgholebe();
        }
      })
    }).catch(event => {
      console.log(event);
    })
  },
  SelectRefund() {
    console.log('123');
  },
  TobePaidOnClick() {
    console.log('123');
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})