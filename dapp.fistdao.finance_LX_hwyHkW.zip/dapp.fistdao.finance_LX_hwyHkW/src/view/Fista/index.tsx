import React, { useEffect, useState } from "react";
import "./index.scss";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import { Button, message, notification } from "antd";
import Header from "../../components/Header";
import img1 from "../../assets/4s.png";
import img3 from "../../assets/k7.png";
import Heues from "../../components/Heues";
import imgbe from "../../assets/jnbi.jpg";
import { CheckCircleOutlined, LoadingOutlined } from "@ant-design/icons";
import {
  oskNFTContract_ADDRESS,
  oskNFTContract_ABI,
} from "../../redux/Contract/oskNFTContract";
import { wben_ABI } from "../../redux/Contract/wbenjson";
declare const window: Window & { ethereum: any };
const key = "updatable";
const sroIOaddress = "0x7c30987194657a8a7129b07b06f12b3e9b04856b";

const openNotification = (bindValue: any, durn: any, icon: any) => {
  notification.open({
    key,
    message: "提示",
    description: bindValue,
    duration: durn,
    icon: icon,
  });
};

function Index() {
  const [unShow, setunShow] = useState(false);
  const [unShow2, setunShow2] = useState(false);
  const [jg1, setjg1] = useState("");
  const [jg2, setjg2] = useState("");
  const [jg3, setjg3] = useState("");
  const [shengyu1, setshengyu1] = useState("");
  const [shengyu2, setshengyu2] = useState("");
  const [shengyu3, setshengyu3] = useState("");
  const [uning, setUning] = useState("");
  const [unadr, setUnadr] = useState("");
  const [detin, setDetin] = useState([]);
  const [enable, setEnable] = useState(false);
  const [showBine, setShowBine] = useState(false);

  const businShow = (img: any, jg: any) => {
    setUning(img);
    setUnadr(jg);
    setunShow(true);
  };

  const BShoQun = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const skoerContract = new ethers.Contract(sroIOaddress, wben_ABI, signer);
    const buaer = await skoerContract.approve(
      oskNFTContract_ADDRESS,
      ethers.constants.MaxUint256
    );
    openNotification(
      "授权中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await buaer.wait();
    openNotification(
      "授权成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
    setShowBine(true);
  };
  const PurpleGoldCard = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const mintContract = new ethers.Contract(
        oskNFTContract_ADDRESS,
        oskNFTContract_ABI,
        signer
      );
      const mint = await mintContract.mintPurpleGoldCard();
      openNotification(
        "购买中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setunShow(false);
      await mint.wait();
      openNotification(
        "购买成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error: any) {
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification(
          "用户拒绝购买.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
        setunShow(false);
      } else {
        if ((error.data.code = "-32603")) {
          openNotification(
            "余额不足.",
            2,
            <CheckCircleOutlined style={{ color: "#ffc400" }} />
          );
        }
      }
    }
  };
  const WhiteGoldCard = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const mintContract = new ethers.Contract(
        oskNFTContract_ADDRESS,
        oskNFTContract_ABI,
        signer
      );
      const mint = await mintContract.mintWhiteGoldCard();
      openNotification(
        "购买中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setunShow(false);
      await mint.wait();
      openNotification(
        "购买成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error: any) {
      console.log(error);
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification(
          "用户拒绝购买.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
        setunShow(false);
      } else {
        if ((error.data.code = "-32603")) {
          openNotification(
            "余额不足.",
            2,
            <CheckCircleOutlined style={{ color: "#ffc400" }} />
          );
        }
      }
    }
  };

  const TingList = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const mintContract = new ethers.Contract(
      oskNFTContract_ADDRESS,
      oskNFTContract_ABI,
      signer
    );
    const skoerContract = new ethers.Contract(sroIOaddress, wben_ABI, signer);
    const kdro = await skoerContract.decimals();

    const snuer2 = await mintContract.purpleGoldCardPrice();
    const isuer1 = snuer2 / 10 ** kdro;
    setjg2(isuer1.toString());

    const snuer3 = await mintContract.whiteGoldCardPrice();
    const isuer2 = snuer3 / 10 ** kdro;
    setjg3(isuer2.toString());

    const shobuton = await skoerContract.allowance(
      addr,
      oskNFTContract_ADDRESS
    );
    if (shobuton > 0) {
      setShowBine(true);
    } else {
      setShowBine(false);
    }
    const Baishe = await mintContract.whiteGoldCardMaxSupply();
    const BaiMin = await mintContract.whiteGoldCardAmount();
    const slier = Number(Baishe.toString()) - Number(BaiMin.toString());
    setshengyu1(String(slier));

    const Zhishe = await mintContract.purpleGoldCardMaxSupply();
    const ZhiMin = await mintContract.purpleGoldCardAmount();
    const zlier = Number(Zhishe.toString()) - Number(ZhiMin.toString());
    setshengyu2(String(zlier));

    const balance = await mintContract.balanceOf(addr);
    const bel = ethers.utils.formatEther(balance);
    const enable = await mintContract.enable();
    if (enable !== false) {
      setEnable(true);
    }
    const nftAmount = new BigNumber(bel)
      .times(new BigNumber(10).pow(18))
      .toString();

    const hhhj = await mintContract.ownedWhiteGoldCardAmount(addr);
    

    let tokenBalance: any = [];
    for (let i = 0; i < Number(hhhj.toString()); i++) {
      const told = await mintContract.getShareholderNFT(addr);
      const htjh = Number(told[i].toString());
      const basetokenUri = await mintContract.tokenURI(htjh.toString());
      await fetch(basetokenUri)
        .then((response) => response.json())
        .then((data) => {
          const uri = "https://ipfs.youwant.io/ipfs/" + data.image.slice(7);
          tokenBalance.push({
            tokenid: Number(htjh.toString()),
            url: uri,
          });
        });
    }
    // const chese = tokenBalance.filter((item:any)=>{

    // })
    setDetin(tokenBalance);
  };

  useEffect(() => {
    const ahsdr = localStorage.getItem("addr");
    if (ahsdr !== null && ahsdr !== undefined) {
      TingList();
    }
    (window as any).ethereum.on(
      "accountsChanged",
      async function (accounts: any) {
        localStorage.setItem("addr", accounts[0]);
        TingList();
      }
    );
    // detin
  }, []);

  return (
    <div className="Rank3">
      <Header />
      <div className="Rankdbi">
        <div className="ranbui">
          <div className="ranbList">
            {enable ? (
              <>
                {/* <div className="busie">
                  <div className="busimg">
                    <img src={img1} alt="" />
                    <div className="bsueran">
                      <div className="bsuLis">剩余数量：{shengyu2}</div>
                      <div className="bsuLis">仅售 {jg2 || "0.0"} OSKDAO</div>
                      {shengyu2 !== "0" ? (
                        <div className="buitn">
                          {showBine ? (
                            <>
                              <Button
                                className="Blooer"
                                onClick={() => {
                                  setunShow2(true);
                                }}
                              >
                                详情
                              </Button>
                              <Button
                                onClick={() => {
                                  businShow("img1", jg2);
                                }}
                              >
                                购买
                              </Button>
                            </>
                          ) : (
                            <Button
                              onClick={() => {
                                BShoQun();
                              }}
                            >
                              授权
                            </Button>
                          )}
                        </div>
                      ) : (
                        <div className="ssdurn">
                          <Button disabled>售罄</Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div> */}
                {/* <div className="busie">
                  <div className="busimg2">
                    <img src={img2} alt="" />
                    <div className="bsueran">
                      <div className="bsuLis">剩余数量：{shengyu3}</div>
                      <div className="bsuLis">仅售 {jg1 || "0.0"} BNB</div>
                      {shengyu2 !== "0" ? (
                        <Button
                          onClick={() => {
                            businShow("img2", jg1);
                          }}
                        >
                          购买
                        </Button>
                      ) : (
                        <div className="ssdurn">
                          <Button disabled>售罄</Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div> */}
                <div className="busie">
                  <div className="busimg">
                    <img src={img3} alt="" />
                    <div className="bsueran">
                      <div className="bsuLis">剩余数量：{shengyu1}</div>
                      <div className="bsuLis">仅售 {jg3 || "0.0"} OSKDAO</div>
                      {shengyu1 !== "0" ? (
                        <div className="buitn">
                          {showBine ? (
                            <>
                              <Button
                                className="Blooer"
                                onClick={() => {
                                  setunShow2(true);
                                }}
                              >
                                详情
                              </Button>
                              <Button
                                onClick={() => {
                                  businShow("img3", jg3);
                                }}
                              >
                                购买
                              </Button>
                            </>
                          ) : (
                            <Button
                              onClick={() => {
                                BShoQun();
                              }}
                            >
                              授权
                            </Button>
                          )}
                        </div>
                      ) : (
                        <div className="ssdurn">
                          <Button disabled>售罄</Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="basbyue">
                  OSKDAO 质押股东分红
                  <div className="wensji">
                    <div className="bsucolo">
                      这并不只是一张卡牌，它是您身为OSKDAO股东的身份证明。等到合适的时间，卡牌会翻开，您会得到一份VIP礼包（名称、属性、稀有度）。
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="byseru">正在加载中,请稍候...</div>
            )}
          </div>
        </div>
        <div className="Nuszerin">
          <div className="Nutitle">
            <div className="kiosei">股东身份卡</div>
          </div>
          {detin.length !== 0 ? (
            <div className="sbuerid">
              {detin.map((item: any) => (
                <div key={item.tokenid} className="busetList">
                  <div className="buitme">
                    <img src={item.url} alt="" />
                  </div>
                  <div className="tobut">
                    身份编号:
                    <span>VIP-{item.tokenid}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="nbsuerilk">您这里暂时空空如也！</div>
          )}
        </div>
      </div>
      {unShow ? (
        <div className="psoeiubse">
          <div
            className="prousn"
            onClick={() => {
              setunShow(false);
            }}
          ></div>
          <div className="prinsk">
            <div className="privideo">
              <div className="rpomg">
                <div className="rpomg_img">
                  {uning == "img1" ? (
                    <img src={img1} alt="" />
                  ) : (
                    <img src={img3} alt="" />
                  )}
                </div>
                <div className="sbueing">
                  请确认是否要以 [{unadr}] OSK的价格购买尊贵的【{" "}
                  {uning == "img1" ? "股东分红卡" : "质押分红卡"}{" "}
                  】股东身份？
                </div>
                <div className="suvibut">
                  <Button
                    onClick={() => {
                      setunShow(false);
                    }}
                  >
                    取消
                  </Button>
                  <Button
                    onClick={() => {
                      {
                        uning == "img1" ? PurpleGoldCard() : WhiteGoldCard();
                      }
                    }}
                  >
                    确认
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      {unShow2 ? (
        <div className="psoeiubse2">
          <div
            className="prousn"
            onClick={() => {
              setunShow2(false);
            }}
          ></div>
          <div className="prinsk">
            <div className="privideo">
              <div className="rpomg">
                <div className="nsimgs">
                  <img src={imgbe} alt="" />
                </div>
              </div>
            </div>
            <div
              className="busierui"
              onClick={() => {
                setunShow2(false);
              }}
            >
              x
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      <Heues />
    </div>
  );
}

export default Index;
