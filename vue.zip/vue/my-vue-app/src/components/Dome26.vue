<template>
</template>

<script setup>

//边框以内的尺寸，四舍五入的整数
// 根元素 .clientWidth :视口宽度（不含滚动条）
// 根元素 .clientHeight :视口高度（不含滚动条）

// 布局尺寸，四舍五入的整数（包含边框滚动条的整数）
//offsetHeight
//offsetWidth

//scrollwidth,scrollHeight
// scrollXXX 含内边距，不需要滚动时等同于clientXXX

// getBoundingClientRect()
// 最小矩形尺寸，含小数
// var rect = dom.getBoundingClientRect();
//rect.width rect.height
</script>

<style>
</style>
