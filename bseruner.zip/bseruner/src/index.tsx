import React from "react";
import ReactDOM from "react-dom/client";
import "antd/dist/antd.min.css";
import "./index.css";
import App from "./App";
import { MoralisProvider } from "react-moralis";

const APP_ID = "v0qhVDOAl5QgcVztdxEFcAAyAT6IuR5TkH3gV2Wp";
const SERVER_URL = "https://q8szvzclrl83.usemoralis.com:2053/server";
const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);
root.render(
  <React.StrictMode>
    <MoralisProvider appId={APP_ID} serverUrl={SERVER_URL}>
      <App />
    </MoralisProvider>
  </React.StrictMode>
);
