let arr: number[] = [1,2,3]
// arr = ['a'] //错误

let arr2: Array<number> =  [1,2,3]
//arr2 = ['a'] //错误

let arr3: Array<string> =  ['5','3','1']
//arr2 = [1] //错误