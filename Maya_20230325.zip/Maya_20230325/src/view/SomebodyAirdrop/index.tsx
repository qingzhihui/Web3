import React, { useEffect, useState } from "react";
import "./index.scss";
import { EditOutlined, KeyOutlined } from "@ant-design/icons";
import { Progress, Input, Modal, Radio, DatePicker, Space } from "antd";
import type { RadioChangeEvent } from "antd";
import { useHistory, useLocation } from "react-router-dom";
import {
  AirDropABI,
  AirDropProps,
  getAlloDataProps,
  InputVlueProps,
  StartProps,
} from "../../hooks/SomebodyAirdrop";
import { useTranslation } from "react-i18next";
import ButtonLoading from '../../components/ButtonLoading'
import { WBENJson } from "../../config/abi/wbenjson";
import { BigNumber } from "@ethersproject/bignumber";
import type { DatePickerProps, RangePickerProps } from "antd/es/date-picker";
import {
  allowance,
  convertLocalDateToUTCIgnoringTimezone,
  FormatUnitsConver,
  InstancedContract,
  ObtainAddress,
  TimestampToTime,
  TokenNameDecimals,
} from "../../hooks/config";
import { TextareaData } from "../../hooks/MultiSender";
import { toStringValue } from "../../hooks/Token";
import moment from "moment";
import { CycleBpsConversion, CycleConversion } from "../../hooks/LockRecordInfo";
import { MinutesConversion, PercentConversion } from "../../hooks/Createlock";

declare const window: Window & { ethereum: any };

const SomebodyAirdrop: React.FC = (props: any) => {
  const { t } = useTranslation();
  let history = useHistory();
  const { state } = useLocation<any>();
  const [cancelAirloading, setCancelAirLoading] = useState<boolean>(false)
  const [data, setData] = useState<AirDropProps>({});
  const [TextArea1, setTextArea1] = useState<string>("");
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [Somedata, setSomedata] = useState<getAlloDataProps[]>([]);
  const [Allocation, setAllocation] = useState<StartProps>({});
  const [isModalOpenSetVesting, setisModalOpenSetVesting] =
    useState<boolean>(false);
  const [isModalOpenSetting, setisModalOpenSetting] = useState<boolean>(false);
  const [InputVlue, setInputVlue] = useState<InputVlueProps>({});
  const [value, setValue] = useState<number>(1);
  const [ApproveShow, setApproveShow] = useState<boolean>(false);
  const [ensureExactAmount, setensureExactAmount] = useState<boolean>(false);
  const [PosintgeDate, setPosintgeDate] = useState<string>("");
  const [datePicker, setDatePicker] = useState<string>("");
  const { TextArea } = Input;
  const [TokenAddress, setTokenAddress] = useState<string>("");
  const [withdrawable, setwithdrawable] = useState("");
  const [airState, setairState] = useState<number>(0);
  const [ownerState, setOwnerState] = useState(false);
  const [someData, setSomeData] = useState<any>({})
  const [removeAllAllocationsloading, setRemoveAllAllocationsLoading] = useState<boolean>(false)
  const [progress, setProgress] = useState<any>();
  const [balanceShow, setBalanceShow] = useState<any>();
  const [disableloading, setDisableLoading] = useState<boolean>(false)
  const [showClaimButton, setShowClaimButton] = useState<boolean>(false);
  const [tgeDate, setgeDate] = useState<number>(0);
  const [tgeDateShow, setgeDateShow] = useState<string>("");
  const [tgeBpsShow, setTgeBpsShow] = useState<number>(0);
  const [cycleShow, setCycleShow] = useState<number>(0);
  const [cycleBpsShow, setCycleBpsShow] = useState<number>(0);
  const [decimalsCal, setDecimalsCal] = useState<number>(0);

  const SomebodyAirdropDataShow = async (data: any) => {
    const AirDropConstaer = InstancedContract(data.AirDropArray, AirDropABI) as any;
    const airDropToken = await AirDropConstaer.airDropToken();
    const Uinsty = await TokenNameDecimals(airDropToken);
    setBalanceShow(Uinsty.balanceOf)
    const totalAllocationTokens = await AirDropConstaer.totalAllocationTokens();
    const allAllocationCount = await AirDropConstaer.allAllocationCount();
    const getAllocations = await AirDropConstaer.getAllocations(
      0,
      allAllocationCount.toString()
    );
    const tgeDate = await AirDropConstaer.tgeDate();
    setgeDate(Number(tgeDate.toString()) * 1000)
    setgeDateShow(TimestampToTime(Number(tgeDate.toString())));
    const tgeBps = await AirDropConstaer.tgeBps();
    setTgeBpsShow(CycleBpsConversion(tgeBps.toString()))
    const cycle = await AirDropConstaer.cycle();
    setCycleShow(CycleConversion(cycle.toString()))
    const cycleBps = await AirDropConstaer.cycleBps();
    setCycleBpsShow(CycleBpsConversion(cycleBps.toString()))
    const airDropState = await AirDropConstaer.airDropState();
    const getAlloData: getAlloDataProps[] = [];
    getAllocations.map((item: any) => {
      getAlloData.push({
        address: item.user,
        amount: FormatUnitsConver(item.amount.toString(), Uinsty.decimals),
      });
    });
    setDecimalsCal(Uinsty.decimals);
    const realtotalAllocationToken = FormatUnitsConver(
      totalAllocationTokens.toString(),
      Uinsty.decimals
    );
    const owner = await AirDropConstaer.owner();
    const { address } = await ObtainAddress() as any;
    if (owner === address) {
      setOwnerState(true);
    } else {
      setOwnerState(false);
    }
    const userClaimedTokens = await AirDropConstaer.userClaimedTokens();
    const realUserClaimedTokens = FormatUnitsConver(userClaimedTokens.toString(), Uinsty.decimals);
    const progress = Number(realUserClaimedTokens) / Number(realtotalAllocationToken) * 100;
    setProgress(progress);
    const allocationInfos = await AirDropConstaer.allocationInfos(address);
    const amount = Number(allocationInfos.amount.toString());
    const withdrawableTokens = await AirDropConstaer.withdrawableTokens(
      address
    );
    setwithdrawable(FormatUnitsConver(withdrawableTokens.toString(), Uinsty.decimals));
    if (amount > 0 && realUserClaimedTokens !== realtotalAllocationToken && Number(withdrawableTokens.toString()) > 0) {
      setShowClaimButton(true);
    }
    const ExactAmount = await AirDropConstaer.ensureExactAmount();
    setensureExactAmount((ExactAmountState: any) => {
      return (ExactAmountState = ExactAmount);
    });
    setAllocation((AllocationprevState: any) => {
      return (AllocationprevState = {
        start: Number(realtotalAllocationToken),
        amount: FormatUnitsConver(allocationInfos.amount.toString(), Uinsty.decimals),
        unlockedAmount: FormatUnitsConver(allocationInfos.unlockedAmount.toString(), Uinsty.decimals),
      });
    });
    let timestamp = Date.now();
    setDatePicker((datePickerprevState: string) => {
      return (datePickerprevState = toStringValue(timestamp / 1000));
    });
    setSomedata((AlloDataprevState: getAlloDataProps[]) => {
      return (AlloDataprevState = getAlloData);
    });
    setData((dataprevState: AirDropProps) => {
      return (dataprevState = {
        AirdropAddress: data.AirDropArray,
        TokenAddress: data.address,
        Name: Uinsty.name,
        Symbol: Uinsty.symbol,
        TotalTokens: realtotalAllocationToken.toString(),
      });
    });
    setairState(Number(airDropState.toString()));
    const allowanceParameter = await allowance(data.address, data.AirDropArray);
    const MaxUint256: BigNumber = BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    if (allowanceParameter.eq(MaxUint256)) {
      setApproveShow(true);
    }
  };

  const handleOk = async () => {
    var tmpArl = (document.querySelector("#test") as HTMLInputElement).value;
    const tmpList = tmpArl.split(/\r*\n/);
    const { QuantityArray, WalletArray } = TextareaData(tmpList, decimalsCal);
    const AirDropConstaer = InstancedContract(
      data.AirdropAddress as string,
      AirDropABI
    ) as any;
    const setAllocations = await AirDropConstaer.setAllocations(
      WalletArray,
      QuantityArray
    );
    setTextArea1("");
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const onChange = (e: RadioChangeEvent) => {
    setValue(e.target.value);
    let timestamp = Date.now();
    if (e.target.value === 1) {
      setDatePicker((datePickerprevState: string) => {
        return (datePickerprevState = toStringValue(parseInt(Number(timestamp / 1000).toString())));
      });
    }
  };
  const handleOkSetVesting = async () => {
    const AirDropConstaer = InstancedContract(
      data.AirdropAddress as string,
      AirDropABI
    ) as any;
    const { SetVesting, TGEpercent, Cyclepercent } = InputVlue;
    const setVesting = await AirDropConstaer.setVesting(
      PercentConversion(SetVesting),
      PercentConversion(TGEpercent),
      MinutesConversion(Cyclepercent)
    );
    await setVesting.wait();
    setisModalOpenSetVesting(false);
  };
  const handleCancelSetVesting = () => {
    setisModalOpenSetVesting(false);
  };
  const handleOkSetting = async () => {
    const AirDropConstaer = InstancedContract(
      data.AirdropAddress as string,
      AirDropABI
    ) as any;
    const startAirDrop = await AirDropConstaer.startAirDrop(
      String(parseInt(datePicker))
    );
    await startAirDrop.wait();
    setisModalOpenSetting(false);
  };
  const handleCancelSetting = () => {
    setisModalOpenSetting(false);
  };
  const onChangeDate = (
    value: DatePickerProps["value"] | RangePickerProps["value"],
    dateString: [string, string] | string
  ) => {
    const UTCIgnoringTimezone = convertLocalDateToUTCIgnoringTimezone(
      new Date(toStringValue(dateString))
    );
    const UTCtransFormation = new Date(
      toStringValue(UTCIgnoringTimezone)
    ).valueOf();
    setDatePicker(toStringValue(UTCtransFormation));
    setPosintgeDate((KewShowValue) => {
      return (KewShowValue = TimestampToTime(
        toStringValue(UTCtransFormation / 1000)
      ));
    });
  };
  const onOk = (
    value: DatePickerProps["value"] | RangePickerProps["value"]
  ) => { };
  const removeAllAllocationsOnClick = async () => {
    setRemoveAllAllocationsLoading(true)
    try {
      const AirDropConstaer = InstancedContract(
        data.AirdropAddress as string,
        AirDropABI
      ) as any;
      const removeAllAllocations = await AirDropConstaer.removeAllAllocations();
      await removeAllAllocations.wait()
      setRemoveAllAllocationsLoading(false)
    } catch (error) {
      setRemoveAllAllocationsLoading(false)
    }
  };
  const TextAreaonChangeAdd = (e: any) => {
    setTextArea1(e.target.value);
  };
  const setEnsureExactAmountOnClick = async (bool: boolean) => {
    setDisableLoading(true)
    try {
      const AirDropConstaer = InstancedContract(
        data.AirdropAddress as string,
        AirDropABI
      ) as any;
      const setEnsureExactAmount = await AirDropConstaer.setEnsureExactAmount(
        bool
      );
      await setEnsureExactAmount.wait()
      setDisableLoading(false)
    } catch (error) {
      setDisableLoading(false)
    }

  };
  const ClaimOnClick = async () => {
    const AirDropConstaer = InstancedContract(
      data.AirdropAddress as string,
      AirDropABI
    ) as any;
    const claim = await AirDropConstaer.claim();
  };
  const cancelAirdropOnClick = async () => {
    setCancelAirLoading(true)
    try {
      const AirDropConstaer = InstancedContract(
        data.AirdropAddress as string,
        AirDropABI
      ) as any;
      const cancelAirdrop = await AirDropConstaer.cancelAirdrop();
      await cancelAirdrop.wait()
      setCancelAirLoading(false)
    } catch (error) {
      setCancelAirLoading(false)
    }
  };
  const ApproveSetting = async () => {
    const Contract = InstancedContract(data.TokenAddress as string, WBENJson) as any;
    const MaxUint256: BigNumber = (BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"));
    const approve = await Contract.approve(
      data.AirdropAddress,
      MaxUint256
    );
    await approve.wait();
    setApproveShow((pproveShowprevState: any) => {
      return (pproveShowprevState = true);
    });
  };
  const oneditUpdataOnclick = () => {
    history.push({
      pathname: "/CreateUpdata",
      state: {
        urlName: "SomebodyAirdrop",
        editUpdata: data,
        AirDropArray: TokenAddress,
      },
    });
  };

  useEffect(() => {
  }, [data, TokenAddress, progress, showClaimButton]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          if (state.data != undefined) {
            SomebodyAirdropDataShow(state.data);
            setTokenAddress((paStast: string) => {
              return (paStast = state.data.AirDropArray);
            });
          } else {
            const { AirDropArray } = state;
            const address = state.editUpdata.TokenAddress;
            SomebodyAirdropDataShow({ ...state.editUpdata, AirDropArray, address });
            setTokenAddress((paStast: string) => {
              return (paStast = state.AirDropArray);
            });
          }
        }
      }
    }
    if (props.location.state.data) {
      setSomeData(props.location.state.data)
    }
  }, []);
  return (
    <div className="SomebodyAirdrop">
      <div className="Somebody_introduce">
        <div className="introduce_left">
          <div className="name_title">
            <div className="nameimgs">
              <div className="heaimgs">
                <img src={require("../../assets/image/Frame.png")} alt="" />
              </div>
              <div>
                <div className="name">{`${t("Airdrop")}`}</div>
                <div className="imgs">
                  <img src={require("../../assets/image/icon1.png")} alt="" />
                  <img src={require("../../assets/image/icon2.png")} alt="" />
                  <img src={require("../../assets/image/icon3.png")} alt="" />
                  <img src={require("../../assets/image/icon4.png")} alt="" />
                  <img src={require("../../assets/image/icon5.png")} alt="" />
                  <img src={require("../../assets/image/icon6.png")} alt="" />
                  <img src={require("../../assets/image/icon7.png")} alt="" />
                  <img src={require("../../assets/image/icon8.png")} alt="" />
                </div>
              </div>
            </div>
            <div className="keystxt">
              <div className="key">
                <KeyOutlined />
              </div>
              <div
                className="edit"
                onClick={() => {
                  oneditUpdataOnclick();
                }}
              >
                <EditOutlined style={{ color: "#f95192" }} />
              </div>
            </div>
            {
              Number(someData.userClaimedTokens) === Number(someData.totalAllocationTokens) && Number(someData.userClaimedTokens) > 0 && Number(someData.totalAllocationTokens) > 0 ? (
                <button className="currency-button cancelbtn">
                  <div className="cancelRound" />
                  {`${t("Ended")}`}
                </button>
              ) : someData.status === "1" && Number(someData.userClaimedTokens) < Number(someData.totalAllocationTokens) ? (
                <button className="currency-button savebtn">
                  <div className="saveRound" />
                  {`${t("Live")}`}
                </button>
              ) : someData.status === "2" ? (
                <button className="currency-button cancelbtn">
                  <div className="cancelRound" />
                  {`${t("Canceled")}`}
                </button>
              ) : (<button className="currency-button comingbtn">
                <div className="comingRound" />
                {`${t("Upcoming")}`}
              </button>)
            }
          </div>
          <div className="txts">
            <div className="txtcount">
              <div className="titletxt">{`${t("Airdrop Address")}`}</div>
              <div className="date">{data.AirdropAddress as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Token Address")}`}</div>
              <div className="date">{data.TokenAddress as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Token Name")}`}</div>
              <div className="dateus">{data.Name as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Token Symbol")}`}</div>
              <div className="datet">{data.Symbol as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Total Tokens")}`}</div>
              <div className="datet">{Number(data.TotalTokens as string)}{" "}{data.Symbol as string}</div>
            </div>
            {
              airState === 1 ? (
                <>
                  <div className="txtcount">
                    <div className="titletxt">{`${t("TGE Release Percent")}`}</div>
                    <div className="datet">{tgeBpsShow}%</div>
                  </div>
                  <div className="txtcount">
                    <div className="titletxt">{`${t("Cycle")}`}</div>
                    <div className="datet">{cycleShow}{" "}{`${t("minutes")}`}</div>
                  </div>
                  <div className="txtcount">
                    <div className="titletxt">{`${t("Cycle Release Percent")}`}</div>
                    <div className="datet">{cycleBpsShow}%</div>
                  </div>
                </>) : ("")
            }
          </div>
        </div>
        <div className="introduce_right">
          <div className="intitle">
            {someData.totalAllocationTokens === someData.userClaimedTokens && someData.totalAllocationTokens > 0 && someData.userClaimedTokens > 0 ?
              `${t("Airdrop has been ended")}`
              : someData.status === "0" ?
                `${t("Waiting for airdrop start")}`
                : (someData.status === "1" && someData.userClaimedTokens < someData.totalAllocationTokens && Date.now() > tgeDate) ?
                  `${t("Airdrop is live now")}`
                  : someData.status === "2" ?
                    `${t("Airdrop has been cancelled")}`
                    : ''
            }
          </div>
          <div className="progress">
            <Progress percent={progress} showInfo={false} />
            <div className="progress_itmel">
              <div>0</div>
              <div>{Allocation.start as number}{" "}{data.Symbol as string}</div>
            </div>
          </div>
          <div className="nalistpsei">
            {
              showClaimButton ? <button
                className="nalist_butne"
                onClick={() => {
                  ClaimOnClick();
                }}
              >
                {`${t("Claim")}`} {Number(withdrawable) > 0 ? `(${Number(withdrawable)})` : ""}
              </button> : ("")
            }
          </div>
          {
            airState === 1 ? (
              <>
                <div className="nalist">
                  <div>{`${t("Start Time")}`}</div>
                  <div>{tgeDateShow}</div>
                </div></>)
              :
              ("")
          }
          <div className="nalist">
            <div>{`${t("Your Allocation")}`}</div>
            <div>{Number(Allocation.amount as string)}{" "}{data.Symbol as string}</div>
          </div>
          <div className="nalist">
            <div>{`${t("Your Claimed")}`}</div>
            <div>{Number(Allocation.unlockedAmount as string)}{" "}{data.Symbol as string}</div>
          </div>
        </div>
      </div>
      <div className="Somebody_allocations">
        <div className="allocations">
          <div className="altitle">{`${t("Allocations")}`}</div>
          {Somedata.map((item: getAlloDataProps, index: number) => (
            <div className="datatext" key={index}>
              <div className="one">{item.address}</div>
              <div className="ddateus">{Number(item.amount)}{" "}{data.Symbol as string}</div>
            </div>
          ))}
        </div>
        {ownerState ? (
          <div className="ownerzone">
            <div className="owntitle">{`${t("Owner Zone")}`}</div>
            <div className="warmreminder">
              <div className="warm">
                {`${t(
                  "Please don't start the airdrop before you finalize the presale pool."
                )}`}
              </div>
              <div className="warm">
                {`${t(
                  "You must exclude fees, dividens, max tx for airdrop address to start the airdrop."
                )}`}
              </div>
              {airState !== 0 ? (
                ""
              ) : (
                <>
                  <button
                    onClick={() => {
                      setisModalOpenSetting(true);
                    }}
                  >
                    {`${t("Start Airdrop")}`}
                  </button>
                  <button
                    onClick={() => {
                      cancelAirdropOnClick();
                    }}
                  >
                    {cancelAirloading ? <>{`${t("Cancel Airdrop")}`}<ButtonLoading /></> : `${t("Cancel Airdrop")}`}
                  </button>
                </>
              )}
            </div>
            <div className="action">
              <div className="actitle">{`${t("Allocation Actions")}`}</div>
              {airState !== 0 ? (
                ""
              ) : (
                <>
                  <button
                    onClick={() => {
                      setIsModalOpen(true);
                    }}
                  >
                    {`${t("Set Allocations")}`}
                  </button>
                  <button
                    onClick={() => {
                      setisModalOpenSetVesting(true);
                    }}
                  >
                    {`${t("Set Vesting")}`}
                  </button>
                  <button
                    onClick={() => {
                      removeAllAllocationsOnClick();
                    }}
                  >
                    {removeAllAllocationsloading ? <>{`${t("Remove All Allocations")}`}<ButtonLoading /> </> : `${t("Remove All Allocations")}`}
                  </button>
                  {ensureExactAmount ? (
                    <button
                      onClick={() => {
                        setEnsureExactAmountOnClick(false);
                      }}
                    >
                      {disableloading ? <>{`${t("Disable Exact Amount")}`}{" "} <ButtonLoading /></> : `${t("Disable Exact Amount")}`}
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setEnsureExactAmountOnClick(true);
                      }}
                    >
                      {disableloading ? <>{`${t("Enable Exact Amount")}`}{" "} <ButtonLoading /></> : `${t("Enable Exact Amount")}`}
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
      <Modal
        title={`${t("Set Allocation")}`}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <div>
          {/* <div className="useTile">User</div> */}
          <TextArea
            rows={4}
            id="test"
            autoSize={{ minRows: 10, maxRows: 6 }}
            placeholder={`${t(
              "Insert address: separate with breaks line.Ex: 0x34E7f6A4d0BB1fa7aFe548582c47Df337FC337E6 0xd8Ebc66f0E3D638156D6F5eFAe9f43B1eBc113B1 0x968136BB860D9534aF1563a7c7BdDa02B1A979C2"
            )}`}
            value={TextArea1}
            onChange={(e: any) => {
              TextAreaonChangeAdd(e);
            }}
          />
        </div>
      </Modal>
      <Modal
        title={`${t("Set Vesting")}`}
        open={isModalOpenSetVesting}
        onOk={handleOkSetVesting}
        onCancel={handleCancelSetVesting}
      >
        <div className="">
          <div>{`${t("TGE release percent")}`}(%)</div>
          <div>
            <Input
              type="text"
              value={InputVlue.SetVesting || ""}
              onChange={(e) => {
                setInputVlue((olddata: any) => {
                  return {
                    ...olddata,
                    SetVesting: e.target.value,
                  };
                });
              }}
            />
          </div>
          <div>{`${t("Cycle release percent")}`}(%)</div>
          <div>
            <Input
              type="text"
              value={InputVlue.TGEpercent || ""}
              onChange={(e) => {
                setInputVlue((olddata: any) => {
                  return {
                    ...olddata,
                    TGEpercent: e.target.value,
                  };
                });
              }}
            />
          </div>
          <div>{`${t("Cycle (minutes)")}`}</div>
          <div>
            <Input
              type="text"
              value={InputVlue.Cyclepercent || ""}
              onChange={(e) => {
                setInputVlue((olddata: any) => {
                  return {
                    ...olddata,
                    Cyclepercent: e.target.value,
                  };
                });
              }}
            />
          </div>
        </div>
      </Modal>
      <Modal
        title={`${t("Setting time to start")}`}
        open={isModalOpenSetting}
        onOk={handleOkSetting}
        onCancel={handleCancelSetting}
        footer={null}
      >
        {" "}
        <Radio.Group onChange={onChange} value={value}>
          <Radio value={1}>{`${t("Start now")}`}</Radio>
          <Radio value={2}>{`${t("Start with specific time")}`}</Radio>
        </Radio.Group>
        {value === 1 ? (
          ""
        ) : (
          <div className="raiodnlike_input">
            <div>{`${t("Start time")}`}</div>
            <div className="raiodnlike_input_div">
              <Space direction="vertical" size={12}>
                <DatePicker
                  showTime
                  onChange={onChangeDate}
                  onOk={onOk}
                  value={PosintgeDate === "" ? moment() : moment(PosintgeDate)}
                />
              </Space>
            </div>
          </div>
        )}
        <div className="raiodnlike">
          <div className="raiodnlike_title">
            {`${t("You need atleast")}`} {Number(data.TotalTokens)} {data.Symbol as string} {`${t("to start airdrop.")}`} {`${t("Your balance:")}`} {Number(balanceShow)} {data.Symbol as string}
          </div>
          <div className="raiodnlike_button">
            {ApproveShow === false ? (
              <button
                onClick={() => {
                  ApproveSetting();
                }}
              >
                {`${t("Approve")}`}
              </button>
            ) : (
              <button
                onClick={() => {
                  handleOkSetting();
                }}
              >
                {`${t("Start now")}`}
              </button>
            )}
          </div>
        </div>
      </Modal>
    </div>
  );
};
export default SomebodyAirdrop;
