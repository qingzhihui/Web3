import React, { useState, useEffect } from "react";
import "./index.scss";
import { Table } from "antd";
import { useHistory } from "react-router-dom";
import type { ColumnsType } from "antd/es/table";
import group4 from "../../assets/image/Group4.png";
import Frame from "../../assets/image/Frame.png";
import Loading from '../../components/Loading'
import { DataType, getCumulativeData, normalLocksForUser } from "./tokenLock";
import { useTranslation, Trans } from "react-i18next";
declare const window: Window & { ethereum: any };

const paginationProps = {
  showSizeChanger: true,
  showQuickJumper: true,
  pageSize: 6,
};
const Index: React.FC = () => {
  let history = useHistory();
  const { t } = useTranslation();
  const [allandlockstyle, setAllandlockstyle] = useState("All");
  const [alloading, setAllLoading] = useState<boolean>(false)
  const [myloading, setMyLoading] = useState<boolean>(false)
  const [data, setData] = useState<DataType[]>([]);
  const [ForUserData, setForUserData] = useState<DataType[]>([]);

  const allandlock = (page: string) => {
    setAllandlockstyle(page);
  };

  const getCumulativeNormalTokenLockInfo = async () => {
    try {
      const TokenLockData = await getCumulativeData();
      setTimeout(() => {
        let _OwnedItem = JSON.parse(JSON.stringify(TokenLockData));
        setData((a: any) => {
          setAllLoading(false)
          return _OwnedItem.length === 0 ? a : _OwnedItem;
        });
      }, 1000);
    } catch (error) {
      setAllLoading(false)
    }
  };

  const normalLocksForUserTokenLockInfo = async () => {
    try {
      const TokenLockData = await normalLocksForUser();
      setTimeout(() => {
        let _OwnedItem = JSON.parse(JSON.stringify(TokenLockData));
        setForUserData((a: any) => {
          setMyLoading(false)
          return _OwnedItem.length === 0 ? a : _OwnedItem;
        });
      }, 1000);
    } catch (error) {
      setMyLoading(false)
    }
  };

  const columns: ColumnsType<DataType> = [
    {
      title: `${t("Token")}`,
      dataIndex: "token",
      render: (item) => (
        <div className="information">
          <img src={Frame} alt="" />
          <div className="infviose">
            <div className="name">{item.name}</div>
            <div className="titless">{item.symbol}</div>
          </div>
        </div>
      ),
    },
    {
      title: `${t("Amount")}`,
      dataIndex: "amount",
    },
    {
      title: `${t("Action")}`,
      key: "action",
      render: (_, record) => (
        <button
          className="view"
          onClick={() => {
            ActionViewOnClick(record);
          }}
        >
          {`${t("View")}`}
        </button>
      ),
    },
  ];
  
  const ActionViewOnClick = (data: any) => {
    history.push({
      pathname: "/LockRecordInfo",
      state: {
        TokenList: data.token,
        amount: data.amount,
        item: data
      },
    });
  };
  useEffect(() => { }, [data, ForUserData]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        setAllLoading(true)
        setMyLoading(true)
        getCumulativeNormalTokenLockInfo();
        normalLocksForUserTokenLockInfo();
      }
    }
  }, []);
  return (
    <div className="Liquidity2">
      <div className="Liquidity_countent">
        <div className="search">
          <input
            type="text"
            placeholder={`${t("Search by token addess or lp token address...")}`} />
        </div>
        <div className="allandlock">
          <div
            className={`all ${allandlockstyle === "All" ? "selected" : null}`}
            onClick={() => {
              allandlock("All");
            }}
          >
            {`${t("All")}`}
          </div>
          <div
            className={`lock ${allandlockstyle === "lock" ? "selected" : null}`}
            onClick={() => {
              allandlock("lock");
            }}
          >
            {`${t("My lock")}`}
          </div>
        </div>
        {
          allandlockstyle === "All" ?
            <Table
              columns={columns}
              loading={data.length === 0 ? true : false}
              dataSource={data}
              size="middle"
              pagination={paginationProps}
            />
            // <>
            //   {alloading ? <Loading /> : (
            //     <Table
            //       columns={columns}
            //       loading={data.length === 0 ? true : false}
            //       dataSource={data}
            //       size="middle"
            //       pagination={paginationProps}
            //     />
            //   )}
            // </>
            :
            <>
              {/* {myloading ? <Loading /> : (
                <Table
                  columns={columns}
                  loading={ForUserData.length === 0 ? true : false}
                  dataSource={ForUserData}
                  size="middle"
                  pagination={paginationProps}
                />
              )} */}
              <Table
                columns={columns}
                loading={ForUserData.length === 0 ? true : false}
                dataSource={ForUserData}
                size="middle"
                pagination={paginationProps}
              />
            </>
        }
      </div>

      <div className="imgs">
        <img src={group4} alt="" />
      </div>
    </div>
  );
};
export default Index;
