import React from "react";
import BigNumber from "bignumber.js";

export interface homedataProps {
  clausePopupIsShow?: boolean;
  clausePopupTitle?: string;
  linkIsGenerate?: boolean;
  generateLink?: string;
  isLogin?: boolean;
  walletAddr?: string;
  MAYABalance?: string;
  MAYASold?: string;
  MAYASymbol?: string;
  MAYAPrice?: string;
  minAmountFormat?: string;
  maxAmountFormat?: string;
  Token0Input?: string;
  Token1Input?: string;
  selectTokenKey?: string;
}

export const DeaultData: homedataProps = {
  clausePopupIsShow: false,
  clausePopupTitle: "",
  linkIsGenerate: false,
  generateLink: "",
  isLogin: false,
  walletAddr: "",
  MAYABalance: "",
  MAYASold: "0",
  selectTokenKey: "1",
};

const DigitalConversion = (parameter: any, numerical: any) => {
  const DigitalValue = new BigNumber(parameter)
    .times(new BigNumber(10).pow(numerical))
    .toFixed();
  return DigitalValue;
};

export {
    DigitalConversion
}