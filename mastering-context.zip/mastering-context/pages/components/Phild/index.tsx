import { useState } from "react";

type Props = {
  text: string;
  onTextChange: (newText: string) => void;
};

const Child = ({ text, onTextChange }: Props) => {
  const [inputText, setInputText] = useState("");

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(event.target.value);
  };

  const handleButtonClick = () => {
    onTextChange(inputText);
    setInputText("");
  };

  return (
    <>
      <input type="text" value={inputText} onChange={handleInputChange} />
      <button onClick={handleButtonClick}>Update Parent Text</button>
      <p>Child Text: {text}</p>
    </>
  );
};

export default Child;
