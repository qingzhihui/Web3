// React Query和SWR的五大妙招
//  yarn add @mantine/core @mantine/hooks @emotion/react
// yarn add react-query
import React from "react";
import { Container, Stack, Title } from "@mantine/core";
import { QueryClientProvider } from "react-query";
import client from "@/hooks/client";
import Login from "../components/login";
import Stopwatch from "@/components/Stopwatch";
import Logger from "@/components/logger";
import GPS from "@/components/GPS";
import GlobalState from "@/components/GlobalState";

const Index = () => {
  return (
    <Container>
      <Stack>
        <Title>Login</Title>
        <Login />
        <Title>Stopwatch</Title>
        <Stopwatch />
        <Title>Logger</Title>
        <Logger />
        <Title>GPS</Title>
        <GPS />
        <Title>GlobalSt</Title>
        <GlobalState />
      </Stack>
    </Container>
  );
};
function WrappedApp() {
  return (
    <QueryClientProvider client={client}>
      <Index />
    </QueryClientProvider>
  );
}

export default WrappedApp;
