import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Farm from "../view/Farm";
import Rank from "../view/Rank";
import Vote from "../view/Vote";
import Othe from "../view/Othe";
import Unity from "../view/Unity";
import Fista from "../view/Fista";
import Facto from "../view/Facto";

class IndexRouter extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/Farm" component={Farm} />
          <Route path="/Rank" component={Rank} />
          <Route path="/Vote" component={Vote} />
          <Route path="/Facto" component={Facto} />
          <Route path="/Othe" component={Othe} />
          <Route path="/Unity" component={Unity} />
          <Route path="/Fista" component={Fista} />
          <Redirect from="/" to="/Farm" />
        </Switch>
      </Router>
    );
  }
}

export default IndexRouter;
