import { useRef } from "react";
import { Text } from "@mantine/core";
import { useQuery } from "react-query";
import useSWR from "swr";

function createStopwatch() {
  const startTime = Date.now();
  return () => {
    return Math.round((Date.now() - startTime) / 1000);
  };
}
const Stopwatch = () => {
  // Query
  //   const timerRef = useRef(createStopwatch());
  //   const { data: time } = useQuery<any>("time", timerRef.current, {
  //     refetchInterval: 100,
  //   });
  // SWR
//   const stopwatchRef = useRef(createStopwatch());
//   const { data } = useSWR("stopwatch", stopwatchRef.current, {
//     refreshInterval: 100,
//     dedupingInterval: 100,
//   });
  return <Text>Time {0}</Text>;
};

export default Stopwatch;
