import React, { useEffect, useState, useMemo } from "react";

// Mastering React's useEffect
import { depCompar, useFetch } from "@/hooks/useFetch";

// 实现效果
// 1.总是指定一个依赖项数组，即使他是空的
// 2.查看依赖项数组中的每一项，如果他是一个字符串，一个数字或者一个布尔值，
// 一个原始值，如果他是一个函数，一个对象，一个数组，那么他可能没问题，那么你需要确保
//  你做一些像这个回调图类似的事情来确保你做的正确的方式

const useStopwatch = () => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setCount((prev) => prev + 1);
    }, 1000);
    return () => {
      clearInterval(interval);
    };
  }, []);
  return count;
};

const Index2 = () => {
  const [url, setUrl] = useState<any>(null);
  // 解决方法
  // const myOpeions = useMemo(() => ({ url }), [url]);
  // 1.创建了一个新的对象，然后将其传递给使用fetch
  const { data } = useFetch({
    url,
    onSuccess: () => {
      console.log("success");
    },
  });

  const count = useStopwatch();

  console.log("App render");

  useEffect(() => {
    // const personName = "jane";
    // const obj = { a: 1 };
    // const objRefCopy = obj;
    // console.log(depCompar([], []));
    // console.log(depCompar([], [1]));
    // console.log(depCompar([1], [1]));
    // console.log(depCompar([false], [1]));
    // console.log(depCompar([objRefCopy], [{ a: 1 }]));
    // console.log(depCompar([personName], [personName]));
  }, []);

  return (
    <div>
      <div>Hello</div>
      <div>Count：{count}</div>
      <div>{JSON.stringify(data)}</div>
      <button
        onClick={() => {
          setUrl("/jack.json");
        }}
      >
        Kack
      </button>
      <button
        onClick={() => {
          setUrl("/sally.json");
        }}
      >
        Sally
      </button>
    </div>
  );
};

export default Index2;
