import { useState, useCallback } from "react";
import { createContext, useContextSelector } from "use-context-selector";

const useStore = () => {
  const [user, setUser] = useState("");
  const [cartCount, setCartCount] = useState(0);
  return {
    user,
    cartCount,
    login: useCallback(() => setUser("Jack"), []),
    logout: useCallback(() => setUser(""), []),
    addToCart: useCallback(() => setCartCount((evt) => evt + 1), []),
  };
};

export const StoreContext = createContext<null | any>(null);
export const useLogin = () =>
  useContextSelector(StoreContext, (state) => state.login);
export const useLogout = () =>
  useContextSelector(StoreContext, (state) => state.logout);
export const useAddToCart = () =>
  useContextSelector(StoreContext, (state) => state.addToCart);
export const useUser = () =>
  useContextSelector(StoreContext, (state) => state.user);
export const useCartCount = () =>
  useContextSelector(StoreContext, (state) => state.cartCount);

export default useStore;
