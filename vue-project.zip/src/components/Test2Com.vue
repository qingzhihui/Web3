<template>
    <div>
        <h2> 你好-我是black-郭</h2>
        <p>性别:{{ sex }}</p>
        <p>其他信息:{{ info }}</p>
    </div>
</template>

<script lang="ts" setup>
import { reactive, ref, defineExpose } from "vue";
let sex = ref('男')
let info = reactive({
    like: '喜欢李一一',
    age: 27
})
// 将组件中的属性暴露出去，这样父组件可以获取
defineExpose({
    sex,
    info
})
</script>