import React from "react";
import './index.scss'
import { ReloadOutlined } from "@ant-design/icons";

const Loading = () => {
  return <div className="LoadingPiuien">
     <ReloadOutlined spin style={{ fontSize: "40px", color: "#ffff" }} />
  </div>;
};

Loading.propTypes = {};

export default Loading;
