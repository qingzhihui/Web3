import Web3 from "web3";
import { Meta_ADDRESS, Meta_ABI } from "../../redux/Contract/MetaContract";
declare const window: Window & { ethereum: any };
let selectedAccount: any;
let nftContract: any;
let isInitialized = false;
const ABIContract: any = { Meta_ABI, Meta_ADDRESS };

const init = async () => {
  let provider = window.ethereum;
  if (typeof provider !== "undefined") {
    provider
      .request({ method: "eth_requestAccounts" })
      .then((accounts: any) => {
        selectedAccount = accounts[0];
        console.log(`Selected account is ${selectedAccount}`);
      })
      .catch((err: any) => {
        console.log(err);
        return;
      });
    window.ethereum.on("accountsChanged", function (accounts: any) {
      selectedAccount = accounts[0];
      console.log(`Selected account changed to ${selectedAccount}`);
    });
  }
  const web3 = new Web3(provider);
  const networkId = await web3.eth.net.getId();
  nftContract = new web3.eth.Contract(
    ABIContract.Meta_ABI,
    ABIContract.Meta_ADDRESS
  );
  isInitialized = true;
};
const LpdateShow = async () => {
  if (!isInitialized) {
    await init();
  }
  return await nftContract.methods
    .depositAmount(0, selectedAccount)
    // .send({ from: selectedAccount });
    .call()
    .then((res: any) => {
      return res;
    });
};

export { init, LpdateShow };
