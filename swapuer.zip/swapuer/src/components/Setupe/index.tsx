import React from "react";

function Setupe() {
  return <div>设置</div>;
}

export default Setupe;
