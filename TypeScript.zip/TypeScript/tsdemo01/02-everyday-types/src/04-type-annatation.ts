let myName: string = "felixlu";

let myName2 :string = "hello";

// 错误（Ts不支持）
// int x = 0

let myName3 = "felixlu";

// 错误
// myName3 = 100