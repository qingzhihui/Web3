import CreatelockABI from "../config/abi/Createlock.json";
const CreatelockAddress = "0x73A9811Be29FFD3bF7F708871B0ED3dfa188e6Ff";

export interface lockProps {
  TokenAddress?: string;
  Title?: string;
  Amount?: string;
  LocDate?: string;
  Owner?: string;
  Percent?: string;
  Minutes?: string;
  Release?: string;
}

export interface SaleProps {
  title?: string;
  method?: string;
  softcap?: string;
  hardcap?: string;
  minbuy?: string;
  maxbuy?: string;
  fundtge?: string;
  fundcycle?: string;
  releasecycle?: string;
  start?: string;
  end?: string;
  website?: string;
}

const MinutesConversion = (parameter: any) => {
  const MinutesValue = Number(parameter) * 60;
  return MinutesValue;
};
const PercentConversion = (parameter: any) => {
  const PercentValue = Number(parameter) * 100;
  return PercentValue;
};



export {
  CreatelockABI,
  CreatelockAddress,
  MinutesConversion,
  PercentConversion,
};
