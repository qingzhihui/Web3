import { AppstoreOutlined, DeleteOutlined, FormOutlined, LinkOutlined } from '@ant-design/icons';
import { Image, Space, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import "./index.css";


// 酒店列表界面
const HotelList = () => {

    interface DataType {
        key: number;
        hotelType: string; // 酒店类型
        hotelId: number; // 酒店id
        hotelName: string;    // 酒店名称
        hotelThumbnail: string; // 缩略图
        hotelAddress: string; // 酒店地址
        hotelAddTime: string; // 添加时间
        addPerson: string;    // 添加人
    }

    const data: DataType[] = [
        {
            key: 1,
            hotelType: 'xxx酒店1',
            hotelId: 1033,
            hotelName: '珠海xxx酒店',
            hotelThumbnail: "https://img2.baidu.com/it/u=355673106,1614830790&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1679590800&t=3abbc6c0f32f549d4b3be4fb4da01b34",
            hotelAddress: '珠海香洲区吉大xxx',
            hotelAddTime: '2023-01-01',
            addPerson: '李四',

        },
    ];

    const columns: ColumnsType<DataType> = [
        {
            title: '酒店类型',
            dataIndex: 'hotelType',
            width: 200,
        },
        {
            title: '酒店id',
            dataIndex: 'hotelId',
            width: 200,
        },
        {
            title: '酒店名称',
            dataIndex: 'hotelName',
            width: 200,
        },
        {
            title: '缩略图',
            width: 200,
            render: (_, record) => (
                <Space size="middle">
                    <Image width={60} height={50} src={record.hotelThumbnail} />
                </Space>
            ),
        },
        {
            title: '酒店地址',
            dataIndex: 'hotelAddress',
            width: 200,
        },
        {
            title: '添加时间',
            dataIndex: 'hotelAddTime',
            width: 200,
        },
        {
            title: '添加人',
            dataIndex: 'addPerson',
            width: 200,
        },
        {
            title: '操作',
            key: 'action',
            // width: 200,
            render: (_, record) => (
                <Space size="middle">
                    <span className='HotelList_btnback'>管理</span>
                    <span className='HotelList_publicCursor' ><AppstoreOutlined /></span>
                    <span className='HotelList_publicCursor' ><LinkOutlined /></span>
                    <span className='HotelList_publicCursor' onClick={uploadus(record)}><FormOutlined /></span>
                    <span className='HotelList_publicCursor' onClick={deleteus(record)}><DeleteOutlined /></span>
                </Space>
            ),
        },
    ];

    // 修改
    const uploadus = (record: any) => {
        return () => {
            console.log("点击了修改");
            console.log(record.key);
        }
    }
    // 删除
    const deleteus = (record: any) => {
        return () => {
            console.log("点击了删除");
            console.log(record.key);
        }
    }

    return (
        <div className='HotelList_Box'>
            <div className='HotelList_headerBox'>
                <div className='HotelList_headerBox_thread'></div>
                <div className='HotelList_headerBox_Tit'>&nbsp;&nbsp;&nbsp; 酒店列表</div>
            </div>

            <div className='HotelList_tableBox'>
                <Table columns={columns} dataSource={data} />
            </div>
        </div>
    )
}

export default HotelList;