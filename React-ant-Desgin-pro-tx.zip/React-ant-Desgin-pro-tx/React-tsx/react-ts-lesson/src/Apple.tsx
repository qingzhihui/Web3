import React from "react";
import withPermission from "./withPermission";
function Apple() {
  return <h1>apple</h1>;
}

// export default withPermission(Apple);
export default withPermission(Apple);
