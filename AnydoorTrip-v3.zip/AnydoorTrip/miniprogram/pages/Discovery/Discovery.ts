// pages/Discovery/Discovery.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgWidth: 0, imgHeight: 0,
    note: [
      {
        title: '案例名称',
        url: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/MineYe.png',
      },
      {
        title: '你所不知道的红酒知识',
        url: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/NewYork.png',
      },
      {
        title: '红酒知识',
        url: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/Paris.png',
      },
      {
        title: '案例名称',
        url: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/reasertop.png',
      },
      {
        title: '案例名称',
        url: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/AustraliaImg.png'
      },

      {
        title: '案例名称',
        url: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/BrazilImg.png'
      },
      {
        title: '案例名称',
        url: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/evaluimg.png'
      },
      {
        title: '案例名称',
        url: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/Bali.png'
      }
    ]
  },
  onNavBar(){
    wx.navigateTo({
      url: '../PulDisco/PulDisco'
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },
  onFindDetaileShow(){
    wx.navigateTo({
      url: '../FindDetaile/FindDetaile'
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})