import React, { useEffect, useState } from "react";
import styles from "./index.module.css";
import { ethers } from "ethers";
import Greeter from "../../artifacts/contracts/Greeter.sol/Greeter.json";
import "./index.scss";
import loges from "../../assets/1_03.png";
import lieb from "../../assets/lieb.png";
import toxing from "../../assets/49.png";
import maoti from "../../assets/maoti.png";

function Headerdev() {
  const [contract, setContract] = useState();
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState("");
  const [display, setdisplay] = useState(false);

  const sliensds = () => {
    setdisplay(true);
  };

  // 连接钱包
  const initConnection = async () => {
    if (typeof window.ethereum !== "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      setContract(
        new ethers.Contract(
          "0x5FbDB2315678afecb367f032d93F642f64180aa3",
          Greeter.abi,
          signer
        )
      );
      // 获取区块链信息
      const addr = await signer.getAddress();
      setAddress(addr);
      console.log(addr);
      // 取到用户的余额
      const bal = await provider.getBalance(addr);
      // 转换解析余额并且加到setBalance中
      setBalance(ethers.utils.formatEther(bal));
      console.log(ethers.utils.formatEther(bal));
      setTimeout(() => {
        setdisplay(false);
      }, 1000);
      console.log("You have connected your wallet");
    } else {
      console.log("Please install metamask.");
    }
  };
  const Showlu = () => {
    setdisplay(false);
  };
  const scrollToAnchor = (anchorName) => {
    if (anchorName) {
      // 找到锚点
      let anchorElement = document.getElementById(anchorName);
      // 如果对应id的锚点存在，就跳转到锚点
      if (anchorElement) {
        anchorElement.scrollIntoView({ block: "start", behavior: "smooth" });
      }
    }
  };
  useEffect(() => {});
  return (
    <div className="Header">
      <div className="iteus">
        <div className="iteusloge">
          <img src={loges} />
          <div className="lisbeiu">
            <img src={lieb} />
          </div>
        </div>
        <div className="iteusnre">
          <div className="itbtn">
            <button>
              <span>Home</span>
            </button>
          </div>
          <div className="itbtn">
            <button onClick={() => scrollToAnchor("activity1")}>About</button>
          </div>
          <div className="itbtn">
            <button onClick={() => scrollToAnchor("activity2")}>Society Benefits</button>
          </div>
          <div className="itbtn">
            <button onClick={() => scrollToAnchor("activity3")}>Roadmap</button>
          </div>
          <div className="itbtn">
            <button onClick={() => scrollToAnchor("activity4")}>Exhibit</button>
          </div>
          <div className="itbtn">
            <button onClick={() => scrollToAnchor("activity5")}>Faq</button>
          </div>
        </div>
        <div className="iteusfelo">
          {address == "" ? (
            <div className="itbtnns">
              <button onClick={() => sliensds()}>CONNECT WALLET</button>
            </div>
          ) : (
            <div className="itbtnns">
              <div className="itbtnro">
                <div className="itbtnroimg">
                  <img src={toxing} />
                </div>
                <div className="itbtnrotuil">
                  <span>
                    {address.substring(0, 4) +
                      "..." +
                      address.substring(38, 42)}
                  </span>
                </div>
                <div className="itbtnrokul">
                  <span>SIGN OUT</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      {display ? (
        <div className="dabuos">
          <div className="sinuyse" onClick={() => Showlu()}></div>
          <div className="siebsi">
            <div className="lsiens">
              <img src={loges} />
            </div>
            <div className="lsibki">
              <div className="slienus" onClick={() => initConnection()}>
                <div className="stilo">
                  <img src={maoti} />
                </div>
                <div className="stilotil">
                  <span>MetaMask</span>
                </div>
                <div className="stilonr">
                  <span>Connect to your MetaMask Wallet</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </div>
  );
}
export default Headerdev;
