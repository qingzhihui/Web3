import "./index.scss"
export default function OpenChests() {
  return (
    <>
      <div style={{
        marginTop: "25px",
        display: "flex",
        justifyContent: "center"
      }}>
        <button className="common-btn">COMMING SOON</button>
      </div>
      <div id="OpenChests">
        <h1 style={{display: "none"}}>KEY available: 0</h1>
        <div style={{display: "none"}} className="list">
          <div className="item">
            <img src="/img/0301MILKtokenbox_UI.png" alt=""/>
            <h1>0 Chests</h1>
            <div className="p">
              Description: The chest contains MILK token. You can randomly get 10,000 - 500,000 tokens from each chest you open.
              <br/>
              Keys consumed: 10 KEY
            </div>
            <button className="common-btn">Sold Out</button>
          </div>
          <div className="item">
            <img src="/img/0301MILKtokenbox_UI.png" alt=""/>
            <h1>0 Chests</h1>
            <div className="p">
              Description: The chest contains MILK token. You can randomly get 10,000 - 500,000 tokens from each chest you open.
              <br/>
              Keys consumed: 10 KEY
            </div>
            <button className="common-btn">Sold Out</button>
          </div>
          <div className="item">
            <img src="/img/0301MILKtokenbox_UI.png" alt=""/>
            <h1>0 Chests</h1>
            <div className="p">
              Description: The chest contains MILK token. You can randomly get 10,000 - 500,000 tokens from each chest you open.
              <br/>
              Keys consumed: 10 KEY
            </div>
            <button className="common-btn">Sold Out</button>
          </div>
          <div className="item">
            <img src="/img/0301MILKtokenbox_UI.png" alt=""/>
            <h1>0 Chests</h1>
            <div className="p">
              Description: The chest contains MILK token. You can randomly get 10,000 - 500,000 tokens from each chest you open.
              <br/>
              Keys consumed: 10 KEY
            </div>
            <button className="common-btn">Sold Out</button>
          </div>
        </div>
      </div>
    </>
  )
}