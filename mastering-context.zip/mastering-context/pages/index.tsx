import Image from "next/image";
import { Inter } from "next/font/google";
import Link from "next/link";
import { useState } from "react";

const inter = Inter({ subsets: ["latin"] });

export default function Home() {
  const [id, setId] = useState(2);
  return (
    <div>
      <Link href="/postslink/posts?id=1">
        <span>Post 1</span>
      </Link>
      <Link href={{ pathname: "/postslink/edit", query: { id } }}>
        <span>Post 2</span>
      </Link>
    </div>
  );
}
