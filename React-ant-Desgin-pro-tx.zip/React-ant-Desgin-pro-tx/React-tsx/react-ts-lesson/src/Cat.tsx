import React, { CSSProperties, useState } from "react";
import "./Cat.css";

function Cat() {
  const [myStyle, setMyStyle] = useState<CSSProperties>({
    color: "blue",
    backgroundColor: "aqua",
  });
  const [clsList, setClsList] = useState<string[]>(["cat", "blue"]);
  return (
    <div>
      <div
        onMouseEnter={() => {
          setClsList([...clsList, "big"]);
        }}
        onMouseLeave={() => {
          setClsList([...clsList.filter((t) => t !== "big")]);
        }}
        className={clsList.join(" ")}
        onClick={() => {
          setMyStyle({
            color: "red",
            backgroundColor: "#000",
          });
        }}
        // style={myStyle}
      >
        a cat
      </div>
    </div>
  );
}

export default Cat;
