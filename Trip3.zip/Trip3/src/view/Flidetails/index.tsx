import React from "react";
import "./index.scss";
const Flidetails = () => {
  return (
    <div className="Flidetails">
      <div className="Flidetails_nreo">
        <div className="Flidetails_nreo_item">
          <div className="Flidetails_nre_ewo">
            <div className="Flidetails_nre_tile">
              <div className="Flidet_nre_rouns">
                <div className="Flidetails_nre_pruien">
                  <div>Beijing </div>
                  <div className="xuingper"></div>
                  <div>Paris</div>
                </div>
                <div className="Flidetails_nre_nsueing">
                  1 Adult | All departure/arrival times are in local time
                </div>
              </div>
            </div>
            <div className="Flidetails_nre_Depart">
              <div className="Flidetails_nre_fline">
                <div className="nre_Depart_prto">
                  <div className="Depart_prto_left">
                    <button>Depart</button>
                  </div>
                  <div className="Depart_prto_reft">
                    Wed, December 14 | Beijing Capital International Airport T3
                    - Paris Charles de Gaulle Airport T2E
                  </div>
                </div>
                <div className="nre_Depart_buine">
                  <div className="Depart_buine_left">
                    <div className="buine_left_not1">
                      <div className="buine_not1_image">
                        <img src={require("@/assets/image/tilo.png")} alt="" />
                      </div>
                      <div className="buine_not1_title">
                        <div className="buine_not1_pro1">13:30-17:40</div>
                        <div className="buine_not1_pro2">Air China</div>
                      </div>
                    </div>
                    <div className="buine_left_not2">
                      <div className="buine_not2_image">
                        <img src={require("@/assets/image/sjung.png")} alt="" />
                      </div>
                      <div className="buine_not2_title">11h10m</div>
                    </div>
                    <div className="buine_left_not3">
                      <div className="buine_not3_title">Nonstop</div>
                      <div className="buine_not3_nro">PEK - CDG</div>
                    </div>
                  </div>
                  <div className="Depart_buine_reft">
                    <div className="Depart_buine_image">
                      <img
                        src={require("@/assets/image/tabler_2.png")}
                        alt=""
                      />
                    </div>
                    <div className="Depart_buine_image">
                      <img
                        src={require("@/assets/image/tabler_3.png")}
                        alt=""
                      />
                    </div>
                    <div className="Depart_buine_image">
                      <img
                        src={require("@/assets/image/tabler_1.png")}
                        alt=""
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="nre_Child_buine">
              <div className="Child_buine_nro">
                <div className="Child_buine_itme1">
                  <div className="Child_item_not1">
                    <div className="Child_not1_lei1">Dec 14</div>
                    <div className="Child_not1_lei2">13:30</div>
                    <div className="Child_not1_lei3"></div>
                    <div className="Child_not1_lei4">
                      PEK Beijing Capital International Airport T3
                    </div>
                  </div>
                  <div className="Child_item_not2">
                    <div className="Child_not2_lei1">11h10m</div>
                    <div className="Child_not2_lei2"></div>
                  </div>
                  <div className="Child_item_not1">
                    <div className="Child_not1_lei1">Dec 14</div>
                    <div className="Child_not1_lei2">17:40</div>
                    <div className="Child_not1_lei3"></div>
                    <div className="Child_not1_lei4">
                      CDG Paris Charles de Gaulle Airport T2E
                    </div>
                  </div>
                </div>
                <div className="Child_buine_itme2">
                  <img src={require("@/assets/image/tilo.png")} alt="" />
                  <div className="Child_item2_title">Air China CA933</div>
                </div>
              </div>
            </div>
            <div className="nre_Passengers">
              <div className="nre_Passengers_nro">
                <div className="nre_Passengers_tile">Passengers</div>
                <div className="nre_Passengers_nro1">1. Adult Ticket</div>
                <div className="nre_Passengers_nro2">
                  <div className="nre_Passengers_left">Last name: Zhang</div>
                  <div className="nre_Passengers_reft">Nationality: China</div>
                </div>
                <div className="nre_Passengers_nro2">
                  <div className="nre_Passengers_left">
                    First & middle name: san
                  </div>
                  <div className="nre_Passengers_reft">ID Type: ID card</div>
                </div>
                <div className="nre_Passengers_nro2">
                  <div className="nre_Passengers_left">Gender: man</div>
                  <div className="nre_Passengers_reft">
                    ID number: 445204200112167890
                  </div>
                </div>
                <div className="nre_Passengers_nro2">
                  <div className="nre_Passengers_left">
                    Date of birth: December 16, 2001
                  </div>
                  <div className="nre_Passengers_reft">
                    ID Expiration Date(Optional): December 16, 2029
                  </div>
                </div>
              </div>
            </div>
            <div className="nre_Contact">
              <div className="nre_Contact_item">
                <div className="Contact_item_title">Contact Details</div>
                <div className="Contact_item_nro">
                  <div className="Contact_item_not">
                    Contact name: Zhang san
                  </div>
                  <div className="Contact_item_not">
                    Email: 2114658411521@gmail.com
                  </div>
                  <div className="Contact_item_not">
                    Mobile phone: 13754563215
                  </div>
                </div>
              </div>
            </div>
            <div className="nre_Price">
              <div className="nre_Price_item">
                <div className="nre_Priceitem1">
                  <div className="nre_Priceitem1_title">Price Details</div>
                  <div className="nre_Priceitem1_nro">
                    <div className="Priceitem1_nro_Fare">Fare</div>
                    <div className="Priceitem1_nro_Fare">$ 4460</div>
                  </div>
                  <div className="nre_Priceitem1_nro">
                    <div className="Priceitem1_nro_Fare">Fare</div>
                    <div className="Priceitem1_nro_Fare">$ 4460</div>
                  </div>
                </div>
                <div className="nre_Priceitem2">
                  <div className="nre_Priceitem2_Total">Total $ 5,480</div>
                  <div className="nre_Priceitem2_bton">
                    <button>already paid</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Flidetails;
