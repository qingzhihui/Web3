import {chat_url} from "./config";
export const text_request = async (val) => {
  let resoult = await new Promise((resolve, reject) => {
    wx.request({
      url: chat_url,
      method: "POST",
      header: { Cookie: wx.getStorageSync("Cookie") },
      data: { context: val },
      success: res => { resolve(res) },
      fail: err => { reject(err) }
    });
  });
  if (resoult.statusCode === 401) {
    wx.setStorageSync("is_login", false);
    wx.navigateTo({ url: "/pages/index/index" });
    return false;
  } else if (resoult.statusCode === 200) {
    return resoult.data.data.text;
  } else {
    return false;
  }
}