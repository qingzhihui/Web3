import React, { Component } from 'react';
import "./index.css"
import { Button, Checkbox, Form, Input } from 'antd';

// 消息通知界面
class Messagenotification extends Component {
    submitData = (values: any) => {
        console.log("提交的内容",values)
    };

    onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };
    render() {
        return (
            <div className='xx_Box'>
                <div className='xx_headerBox'>
                    <div className='xx_headerBox_thread'></div>
                    <div className='xx_headerBox_Tit'>&nbsp;&nbsp;&nbsp;短信配置</div>
                </div>
                <div className='xx_inputBox'>
                    <Form
                        name="basic"
                        labelCol={{ span: 5 }}
                        wrapperCol={{ span: 18 }}
                        style={{ maxWidth: 600 }}
                        initialValues={{ remember: true }}
                        onFinish={this.submitData}
                        onFinishFailed={this.onFinishFailed}
                        autoComplete="off"
                    >
                        <Form.Item label="Keyid" name="Keyid">
                            <Input placeholder="请输入Keyid" />
                        </Form.Item>
                        <Form.Item label="KeySecret" name="KeySecret">
                            <Input placeholder="请输入KeySecret!" />
                        </Form.Item>
                        <Form.Item label="短信签名" name="smsSignature">
                            <Input placeholder="请输入短信签名!" />
                        </Form.Item>
                        <Form.Item label="注册验证码" name="registrationVerificationCode">
                            <Input placeholder="请输入短信签名!" />
                        </Form.Item>
                        <Form.Item label="其他验证码" name="otherVerificationCodes">
                            <Input placeholder="请输入其他验证码!" />
                        </Form.Item>
                        <div className='xx_headerBox2'>
                            <div className='xx_headerBox_thread'></div>
                            <div className='xx_headerBox_Tit'>&nbsp;&nbsp;&nbsp;模板消息配置</div>
                        </div>
                        <Form.Item label="注册模板" name="registrationTemplate">
                            <Input placeholder="模板ID!" />
                        </Form.Item>
                        <Form.Item label="示列" name="logonList">
                            <Input placeholder="示列内容!" />
                        </Form.Item>
                        <Form.Item label="订单模板" name="OrderTemplate">
                            <Input placeholder="模板ID!" />
                        </Form.Item>
                        <Form.Item label="示列" name="OrderTemplateList">
                            <Input placeholder="示列内容!" />
                        </Form.Item>
                        <Form.Item label="其他模板" name="orderForGoods">
                            <Input placeholder="模板ID!" />
                        </Form.Item>
                        <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                            <Button className='xx_btn' size="middle" type="primary" htmlType="submit">提交</Button>
                        </Form.Item>
                    </Form>
                </div>
            </div>
        )
    }
}

export default Messagenotification;