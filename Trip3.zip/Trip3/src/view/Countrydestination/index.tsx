import React from 'react'
import './index.scss'

export default function index() {
  return (
    <div className='country_destination'>
      <div className='country_title'>country of destination</div>
      <div className='country_imgs'>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
        <div className='imgs'>
          <div className='topimg'><img src={require('@/assets/image/city.png')} alt="" /></div>
          <div className='buttonimg'>
            <img src={require('@/assets/image/USA.png')} alt="" />
            <div className='introduce'>Switzerland</div>
          </div>
        </div>
      </div>
    </div>
  )
}

