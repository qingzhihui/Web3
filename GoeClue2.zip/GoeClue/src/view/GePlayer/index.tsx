import React, { useEffect, useState } from "react";
import "./index.scss";
import "swiper/css";
import "swiper/css/navigation";
import { Navigation } from "swiper";
import { ethers } from "ethers";
import {
  playerNFT_ADDRESS,
  playerNFT_ABI,
} from "../../redux/Contract/playerNFTContract";
import {
  teamNFT_ADDRESS,
  teamNFT_ABI,
} from "../../redux/Contract/teamNFTContract";
import {
  CloseCircleOutlined,
  RedoOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";
import { token_ABI } from "../../redux/Contract/tokenContract";
import Come from "../../components/Come";
import Trade from "../../components/Trade";
import { useHistory } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import userbox from "../../assets/image/userbox.png";
import player1 from "../../assets/image/player1.png";
import player2 from "../../assets/image/player2.png";
import player3 from "../../assets/image/player3.png";
import player4 from "../../assets/image/player4.png";
import player5 from "../../assets/image/player5.png";
import player6 from "../../assets/image/player6.png";
import player7 from "../../assets/image/player7.png";
import player8 from "../../assets/image/player8.png";
import team1 from "../../assets/image/t1.png";
import team2 from "../../assets/image/t2.png";
import team3 from "../../assets/image/t3.png";
import team4 from "../../assets/image/t4.png";
import team5 from "../../assets/image/t5.png";
import team6 from "../../assets/image/t6.png";

declare const window: Window & { ethereum: any };

const Players = [
  {
    key: "1",
    imgurl: player1,
  },
  {
    key: "2",
    imgurl: player2,
  },
  {
    key: "3",
    imgurl: player3,
  },
  {
    key: "4",
    imgurl: player4,
  },
  {
    key: "5",
    imgurl: player5,
  },
  {
    key: "6",
    imgurl: player6,
  },
  {
    key: "7",
    imgurl: player7,
  },
  {
    key: "8",
    imgurl: player8,
  },
];
const TestLogoArray = [
  {
    id: 1,
    imageUrl: team1,
  },
  {
    id: 2,
    imageUrl: team2,
  },
  {
    id: 3,
    imageUrl: team3,
  },
  {
    id: 4,
    imageUrl: team4,
  },
  {
    id: 5,
    imageUrl: team5,
  },
  {
    id: 6,
    imageUrl: team6,
  },
  {
    id: 7,
    imageUrl: team2,
  },
  {
    id: 8,
    imageUrl: team3,
  },
  {
    id: 9,
    imageUrl: team4,
  },
  {
    id: 10,
    imageUrl: team5,
  },
];

function Index() {
  const [steNume, setsteNume] = useState(1);
  const [ShowBren, setShowBren] = useState(true);
  const [ShowPers, setShowPers] = useState(true);
  const [address, setWalletAccount] = useState("");
  const [piose, setPiose] = useState(1);
  const [isTimese, setisTimese] = useState(false);
  let history = useHistory();
  const [oreTime, setoreTime] = useState({
    gontime: "",
    oreTime: 1,
  });
  const MintonClikc = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const playerNFTContract = new ethers.Contract(
        playerNFT_ADDRESS,
        playerNFT_ABI,
        signer
      );
      const Minte = await playerNFTContract.mint(steNume, { gasLimit: 650000 });
      setoreTime({ gontime: "购买中...", oreTime: 1 });
      setisTimese(true);
      await Minte.wait();
      setShowBren(false);
      setoreTime({ gontime: "购买成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "购买失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const AlperClikc = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const playerNFTContract = new ethers.Contract(
        playerNFT_ADDRESS,
        playerNFT_ABI,
        signer
      );
      const purchaseTokenAddress = await playerNFTContract.purchaseToken();
      const purchaseTokenContract = new ethers.Contract(
        purchaseTokenAddress,
        token_ABI,
        signer
      );
      const approve = await purchaseTokenContract.approve(
        playerNFT_ADDRESS,
        ethers.constants.MaxUint256
      );
      setoreTime({ gontime: "授权中", oreTime: 1 });
      setisTimese(true);
      await approve.wait();
      setShowBren(false);
      setoreTime({ gontime: "授权成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "授权失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const AlperSHow = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const playerNFTContract = new ethers.Contract(
      playerNFT_ADDRESS,
      playerNFT_ABI,
      signer
    );
    const purchaseTokenAddress = await playerNFTContract.purchaseToken();
    const purchaseTokenContract = new ethers.Contract(
      purchaseTokenAddress,
      token_ABI,
      signer
    );
    const allowance = await purchaseTokenContract.allowance(
      address,
      playerNFT_ADDRESS
    );
    if (allowance.toString() === "0") {
      setShowBren(true);
    } else {
      setShowBren(false);
    }
  };
  const PserSHow = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const teamNFTContract = new ethers.Contract(
      teamNFT_ADDRESS,
      teamNFT_ABI,
      signer
    );
    const purchaseTokenAddress = await teamNFTContract.purchaseToken();
    const purchaseTokenContract = new ethers.Contract(
      purchaseTokenAddress,
      token_ABI,
      signer
    );
    const allowance = await purchaseTokenContract.allowance(
      address,
      teamNFT_ADDRESS
    );
    if (allowance.toString() === "0") {
      setShowPers(true);
    } else {
      setShowPers(false);
    }
  };
  const showHide2 = () => {
    setisTimese(false);
  };
  const BuontneAplusier = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const teamNFTContract = new ethers.Contract(
        teamNFT_ADDRESS,
        teamNFT_ABI,
        signer
      );
      const purchaseTokenAddress = await teamNFTContract.purchaseToken();
      const purchaseTokenContract = new ethers.Contract(
        purchaseTokenAddress,
        token_ABI,
        signer
      );
      const approve = await purchaseTokenContract.approve(
        teamNFT_ADDRESS,
        ethers.constants.MaxUint256
      );
      setoreTime({ gontime: "授权中", oreTime: 1 });
      setisTimese(true);
      await approve.wait();
      setShowPers(false);
      setoreTime({ gontime: "授权成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "授权失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const BuonGmeionClick = async (id: any) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const teamNFTContract = new ethers.Contract(
        teamNFT_ADDRESS,
        teamNFT_ABI,
        signer
      );
      const mintTeam = await teamNFTContract.mint(id);
      setoreTime({ gontime: "购买中", oreTime: 1 });
      setisTimese(true);
      await mintTeam.wait();
      setoreTime({ gontime: "购买成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "购买失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };

  const HomeLiper = () => {
    history.push("/HOME");
  };
  const renderTeam = () => {
    return (
      <div className="gp-contain__team">
        {/* <div className="gp__team__title">Buy your team</div> */}
        <ul className="gp__team__items">
          {TestLogoArray.map((item: any, index: any) => (
            <li className="team__items__item" key={index}>
              <div className="team_items_image">
                <img src={item.imageUrl} alt="" />
                {ShowPers ? (
                  <button
                    className="Buontne"
                    onClick={() => {
                      BuontneAplusier();
                    }}
                  >
                    授权
                  </button>
                ) : (
                  <button
                    className="Buontne"
                    onClick={() => {
                      BuonGmeionClick(item.id);
                    }}
                  >
                    购买
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
        {/* <button className="team__btn">Sell my team</button> */}
        <div className="team_desc">
          The total has 4 types of farmer boxes, each level of the farmer box
          can open one farmer with a specific rarity in rate. Don't miss the
          chance to own the farmer have more efficiency and make a great FCC
          reward!{" "}
        </div>
      </div>
    );
  };
  useEffect(() => {
    const address = localStorage.getItem("Cone_addr");
    if (address !== null && address !== undefined) {
      setWalletAccount(address);
      AlperSHow();
      PserSHow();
    } else {
      setWalletAccount("");
    }
  }, [piose, address]);
  return (
    <>
      <div className="GePlayer">
        <div className="GePlayer_lisoer">
          <div className="lisoer_left">
            <div className="lisoer_left_titler">
              <button
                onClick={() => {
                  HomeLiper();
                }}
              >
                返回
              </button>
            </div>
            <div className="lisoer_left_nro">
              <button
                className={[`${piose == 1 ? "butoaciton" : ""}`].join("")}
                onClick={() => {
                  setPiose(1);
                }}
              >
                Player
              </button>
            </div>
            <div className="lisoer_left_nro">
              <button
                className={[`${piose == 2 ? "butoaciton" : ""}`].join("")}
                onClick={() => {
                  setPiose(2);
                }}
              >
                Team
              </button>
            </div>
            <div className="lisoer_left_nro">
              <button
                className={[`${piose == 3 ? "butoaciton" : ""}`].join("")}
                onClick={() => {
                  setPiose(3);
                }}
              >
                Stadium
              </button>
            </div>
            <div className="lisoer_left_nro">
              <button
                className={[`${piose == 4 ? "butoaciton" : ""}`].join("")}
                onClick={() => {
                  setPiose(4);
                }}
              >
                Prop
              </button>
            </div>
            <div className="lisoer_left_nro">
              <button
                className={[`${piose == 5 ? "butoaciton" : ""}`].join("")}
                onClick={() => {
                  setPiose(5);
                }}
              >
                Gacha machine
              </button>
            </div>
            <div className="lisoer_left_nro">
              <button
                className={[`${piose == 6 ? "butoaciton" : ""}`].join("")}
                onClick={() => {
                  setPiose(6);
                }}
              >
                Trade
              </button>
            </div>
          </div>
          <div className="lisoer_reft">
            {piose == 1 ? (
              <div className="lisoer_reft_item">
                <div className="Playernro">
                  <div className="gp-contain__player">
                    {Players.map((p) => (
                      <div className="player__p" key={p.key}>
                        <div className="posuen">
                          <img src={p.imgurl} />
                          <button className="player-buy">购买</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : piose == 2 ? (
              <div className="lisoer_reft_item">{renderTeam()}</div>
            ) : piose == 3 ? (
              <div className="lisoer_reft_item">
                <div className="gp-contain__stadium">
                  <div className="gp-stadium">
                    <Swiper
                      navigation={true}
                      modules={[Navigation]}
                      className="mySwiper"
                    >
                      <SwiperSlide>
                        <div className="gp-stadium__cards">
                          <div className="gp-stadium__card">
                            <div className="cards__title">Black Swans</div>
                            <span className="hr"></span>
                            <img className="bs-img"></img>
                            <div className="nusoer">
                              <p>
                                The first groups of Dark Force on planet are
                                those Swans? They are not the normal ones!! We
                                heard that Black Swan would bring bad lucks and
                                destroy the whole planet’s fatality. Let’s fight
                                against the Black Swans!
                              </p>
                              <p>
                                {" "}
                                Possible Enemies: Young Black Swan, Grown Black
                                Swan, King of Black Swans{" "}
                              </p>
                              <p>Loot Items: MILK, BABY, Keys</p>
                            </div>
                            <div className="card__btns">
                              <button className="card__btns-btn">Buy</button>
                              <button className="card__btns-btn">Lease</button>
                            </div>
                          </div>
                          <div className="gp-stadium__card">
                            <div className="cards__title">Flash Loan</div>
                            <span className="hr"></span>
                            <img className="fl-img"></img>
                            <div className="nusoer">
                              <p>
                                The first groups of Dark Force on planet are
                                those Swans? They are not the normal ones!! We
                                heard that Black Swan would bring bad lucks and
                                destroy the whole planet’s fatality. Let’s fight
                                against the Black Swans!
                              </p>
                              <p>
                                {" "}
                                Possible Enemies: Young Black Swan, Grown Black
                                Swan, King of Black Swans{" "}
                              </p>
                              <p>Loot Items: MILK, BABY, Keys</p>
                            </div>

                            <div className="card__btns">
                              <button className="card__btns-btn">Buy</button>
                              <button className="card__btns-btn">Lease</button>
                            </div>
                          </div>
                        </div>
                      </SwiperSlide>
                      <SwiperSlide>
                        <div className="gp-stadium__cards">
                          <div className="gp-stadium__card">
                            <div className="cards__title">Black Swans</div>
                            <span className="hr"></span>
                            <img className="bs-img"></img>
                            <div className="nusoer">
                              <p>
                                The first groups of Dark Force on planet are
                                those Swans? They are not the normal ones!! We
                                heard that Black Swan would bring bad lucks and
                                destroy the whole planet’s fatality. Let’s fight
                                against the Black Swans!
                              </p>
                              <p>
                                Possible Enemies: Young Black Swan, Grown Black
                                Swan, King of Black Swans{" "}
                              </p>
                              <p>Loot Items: MILK, BABY, Keys</p>
                            </div>

                            <div className="card__btns">
                              <button className="card__btns-btn">Buy</button>
                              <button className="card__btns-btn">Lease</button>
                            </div>
                          </div>
                          <div className="gp-stadium__card">
                            <div className="cards__title">Flash Loan</div>
                            <span className="hr"></span>
                            <img className="fl-img"></img>
                            <div className="nusoer">
                              <p>
                                The first groups of Dark Force on planet are
                                those Swans? They are not the normal ones!! We
                                heard that Black Swan would bring bad lucks and
                                destroy the whole planet’s fatality. Let’s fight
                                against the Black Swans!
                              </p>
                              <p>
                                Possible Enemies: Young Black Swan, Grown Black
                                Swan, King of Black Swans{" "}
                              </p>
                              <p>Loot Items: MILK, BABY, Keys</p>
                            </div>
                            <div className="card__btns">
                              <button className="card__btns-btn">Buy</button>
                              <button className="card__btns-btn">Lease</button>
                            </div>
                          </div>
                        </div>
                      </SwiperSlide>
                    </Swiper>
                  </div>
                </div>
              </div>
            ) : piose == 4 ? (
              <div className="lisoer_reft_item">
                <Come />
              </div>
            ) : piose == 5 ? (
              <div className="lisoer_reft_item">
                <Come />
              </div>
            ) : piose == 6 ? (
              <div className="lisoer_reft_item">
                <Trade />
              </div>
            ) : (
              <div className="lisoer_reft_item">{/* <MInte /> */}</div>
            )}
          </div>
        </div>
      </div>

      {/* 提示 */}
      {isTimese ? (
        <div className="pserExbuse">
          <div className="pserzhes"></div>
          <div className="pserTise">
            <div className="pserExchange_nro">
              <div className="nriopsr">
                <div className="logding">
                  {(oreTime as any).oreTime === 1 ? (
                    <RedoOutlined spin className="Luiisnr" />
                  ) : (oreTime as any).oreTime === 2 ? (
                    <CheckCircleOutlined className="Luiisnr" />
                  ) : (
                    <CloseCircleOutlined className="Luiisnr" />
                  )}
                </div>
                <div className="Ptimeb">{(oreTime as any).gontime}</div>
              </div>
              <div
                className="gbuiengkum"
                onClick={() => {
                  showHide2();
                }}
              >
                <CloseCircleOutlined
                  style={{
                    color: "#ffff",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  );
}

export default Index;
