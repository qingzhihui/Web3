import React, { useState, useEffect } from "react";
import { Menu } from "antd";
import { useHistory } from "react-router-dom";
import { getItem, MenuItem } from "../../hooks/config";
import "./index.scss";
import { useTranslation, Trans } from "react-i18next";
const Header: React.FC = () => {
  const { t } = useTranslation();
  const [collapsed, setCollapsed] = useState(false);
  const [collNum, setcollNum] = useState("");
  const history = useHistory();

  const items: MenuItem[] = [
    getItem(
      `${t("Home")}`,
      "/Home",
      <img
        className="piooen"
        src={
          collNum === "/Home"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome1.png")
        }
      />
    ),
    getItem(
      `${t("Launchpads")}`,
      "sub1",
      <img
        className="piooen"
        src={
          collNum === "/Lauchpad" || collNum === "/Presale"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome2.png")
        }
      />,
      [getItem(`${t("Create")}`, "/Lauchpad"), getItem(`${t("Launchpad list")}`, "/Presale")]
    ),
    getItem(
      `${t("Private Sale")}`,
      "sub2",
      <img
        className="piooen"
        src={
          collNum === "/Sale" || collNum === "/PrivateSale"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome3.png")
        }
      />,
      [
        getItem(`${t("Create Private Sale")}`, "/Sale"),
        getItem(`${t("Private Sale List")}`, "/PrivateSale"),
      ]
    ),
    getItem(
      `${t("MAYAlock")}`,
      "sub3",
      <img
        className="piooen"
        src={
          collNum === "/Lock" ||
          collNum === "/Token" ||
          collNum === "/Liquidity"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome4.png")
        }
      />,
      [
        getItem(`${t("Create Lock")}`, "/Lock"),
        getItem(`${t("Token")}`, "/Token"),
        getItem(`${t("Liquidity")}`, "/Liquidity"),
      ]
    ),
    getItem(
      `${t("Airdrop")}`,
      "/Airdrop",
      <img
        className="piooen"
        src={
          collNum === "/Airdrop"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome5.png")
        }
      />
    ),
    // getItem(
    //   "leaderboard",
    //   "/Leaderboard",
    //   <img
    //     className="piooen"
    //     src={
    //       collNum === "/Leaderboard"
    //         ? require("../../assets/image/Frame1.png")
    //         : require("../../assets/image/ome6.png")
    //     }
    //   />
    // ),
    getItem(
      `${t("Anti-Bot")}`,
      "/AntiBot",
      <img
        className="piooen"
        src={
          collNum === "/AntiBot"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome7.png")
        }
      />
    ),
    getItem(
      `${t("Multi Sender")}`,
      "/MultiSender",
      <img
        className="piooen"
        src={
          collNum === "/MultiSender"
            ? require("../../assets/image/Frame1.png")
            : require("../../assets/image/ome8.png")
        }
      />
    ),
  ];

  const toggleCollapsed = () => {
    setCollapsed(!collapsed);
  };
  const onOpenChange = (e: any) => {
    setcollNum(e.key);
    history.push(e.key);
  };
  useEffect(() => {}, [collNum, collapsed]);

  return (
    <div className={[`Header ${collapsed ? "acuiot" : ""}`].join("")}>
      <div
        className="header_left"
        style={{
          width: `${collapsed ? 230 : 80}`,
          // height: "100%",
          height:"100vh",
          display:"flex",
          flexDirection:"column",
          backgroundColor: "#FFFFFF",
          position: "relative",
          overflowY:"scroll",
        }}
      >
        <div className="Header_buotn">
          <button onClick={toggleCollapsed}>
            {collapsed ? (
              <img
                src={require("../../assets/image/tabler_indent-increase.png")}
                alt=""
              />
            ) : (
              <img
                src={require("../../assets/image/tabler_indent-decrease.png")}
                alt=""
              />
            )}
          </button>
        </div>
        <div className="buloge">
          {collapsed ? (
            <img
              className="imgl1"
              src={require("../../assets/image/loge.png")}
              alt=""
            />
          ) : (
            <img
              className="imgl2"
              // src={require("../../assets/image/HeaderLoge.png")}
              src={require("../../assets/image/HeaderLogo.png")}
              alt=""
            />
          )}
        </div>
        <Menu
          defaultSelectedKeys={["1"]}
          mode="inline"
          theme="light"
          inlineCollapsed={collapsed}
          onClick={onOpenChange}
          items={items}
        />
        <div
          className={[`Heaer_footer ${collapsed ? "acuiotForet" : ""}`].join(
            ""
          )}
        >
          <div className="Guodibu">
            <div className="guodimg">
              <img
                src={require("../../assets/image/Telegram-Negative2.png")}
                alt=""
              />
            </div>
            <div className="guodimg">
              <img
                src={require("../../assets/image/Telegram-Negative1.png")}
                alt=""
              />
            </div>
            <div className="guodimg">
              <img
                src={require("../../assets/image/Telegram-Negative3.png")}
                alt=""
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
