import { FormOutlined } from '@ant-design/icons';
import { Space, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import "./index.css";


// 酒店数据汉化界面
const hotelDataSinicization = () => {

    interface DataType {
        key: number;
        hotelName: string; // 酒店名称
        hotelCode: number; // 酒店代码
        queryKeywords: string; // 查询关键字
        city: string;      // 所在城市
        grade: string;     // 等级
        bePutInStorage: string;// 入库时间
        chineseIdentification: string //汉化标识
        acquisitionStatus: string //采集状态
    }

    const data: DataType[] = [
        {
            key: 1,
            hotelName: 'Hiton Garden Inn Amarillo',
            hotelCode: 4960,
            queryKeywords: '阿玛,bohaung,huangguan',
            city: 'Tokyo, Japan',
            grade: '3.5',
            bePutInStorage: '2023-01-01',
            chineseIdentification:'待汉化',
            acquisitionStatus: '已完成',
        },
    ];

    const columns: ColumnsType<DataType> = [
        {
            title: '酒店名称',
            dataIndex: 'hotelName',
            width: 200,
        },
        {
            title: '酒店代码',
            dataIndex: 'hotelCode',
            width: 120,
        },
        {
            title: '查询关键字',
            dataIndex: 'queryKeywords',
            width: 200,
        },
        {
            title: '所在城市',
            dataIndex: 'city',
            width: 200,
        },
        {
            title: '等级',
            dataIndex: 'grade',
            width: 80,
        },
        {
            title: '入库时间',
            dataIndex: 'bePutInStorage',
            width: 120,
        },
        {
            title: '汉化标识',
            dataIndex:'chineseIdentification',
            width: 120,
            render: (_text, record) => (
                <Space size="middle">
                    <span className='HotelData_publicCursor'>{_text}</span>
                </Space>
            ),
        },
        {
            title: '采集状态',
            dataIndex:'acquisitionStatus',
            width: 120,
            render: (_text, record) => (
                <Space size="middle">
                    <span className='HotelData_publicCursor1'>{_text}</span>
                </Space>
            ),
        },
        {
            title: '操作',
            key: 'action',
            width: 200,
            render: (_, record) => (
                <Space size="middle">
                    <span className='HotelList_publicCursor' onClick={uploadus(record)}><FormOutlined /></span>
                </Space>
            ),
        },
    ];

    // 修改
    const uploadus = (record: any) => {
        return () => {
            console.log("点击了修改");
            console.log(record.key);
        }
    }
    // 删除
    const deleteus = (record: any) => {
        return () => {
            console.log("点击了删除");
            console.log(record.key);
        }
    }

    return (
        <div className='HotelData_Box'>
            <div className='HotelData_headerBox'>
                <div className='HotelData_headerBox_thread'></div>
                <div className='HotelData_headerBox_Tit'>&nbsp;&nbsp;&nbsp; 酒店数据汉化</div>
            </div>

            <div className='HotelData_tableBox'>
                <Table columns={columns} dataSource={data} />
            </div>
        </div>
    )
}

export default hotelDataSinicization;