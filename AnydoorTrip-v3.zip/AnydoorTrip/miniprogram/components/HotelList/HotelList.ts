import api from '../../config/axios'
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    paramHotel: {
      type: Array,
      value: []
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    HiteData: <any>[],
    burUrl: "https://travelport.leonardocontentcloud.com/imageRepo/7/0/132/560/122/ZUHZH_6670713001_M.jpg"
  },

  /**
   * 组件的方法列表
   */
  methods: {
    OrderAmanilsShow(event: any) {
      wx.navigateTo({
        url: `../OrderAmanils/OrderAmanils?id=${event.currentTarget.dataset.id}`
      })
    },
    orderSheng(data: any) {
      this.setData({
        HiteData: data
      })
    }
  },
  attached: function () {
    const Data: any = this.properties.paramHotel
    this.setData({
      HiteData: Data
    })
  }
})
