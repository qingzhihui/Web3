<template>
    <p>Using text interpolation: {{ rawHtml }}</p>
    <p>Using v-html directive: <span v-html="rawHtml"></span></p>
    <div :id="dynamicId">Id</div>
    <button :disabled="isButtonDisabled">Button</button>
    <div v-bind="objectOfAttrs">对象</div>
    <div>
        <span>{{ number + 1 }}</span> /
        <span>{{ isButtonDisabled ? 'YES' : 'NO' }}</span> /
        <span>{{ message.split('').reverse().join('') }}</span> /
        <span :id="`list-${number}`">{{ `list-${number}` }}</span> /
        <span :title="toTitleDate(date)">
            {{ formatDate(date) }}
        </span>
        
        <p v-if="isButtonDisabled">Now you see me</p>

        <a :href="url">跳转</a>

        <div @click="doSomething">点我</div>

        <a style="color:red;" :[attributeName]="url">Link</a>

        <!-- @submit.prevent 修饰符来阻止表单的默认提交行为 -->
        <form @submit.prevent="onSubmit">
            <button type="submit">提交</button>
        </form>
    </div>
</template>
<script lang="ts" setup>
import { ref, reactive } from 'vue'
const rawHtml = ref('<span style="color: red">This should be red.</span>')
const dynamicId = ref('1');
const isButtonDisabled = ref(true)
const objectOfAttrs = reactive({
    id: 'container',
    class: 'wrapper'
})
const message = ref('WBD')
const number = ref(1)
const date = ref("2023-5-6")
const url = ref("https://www.baidu.com/")
const attributeName = ref("href")
const toTitleDate = (data: any) => {
    return `我是标题：${data}`;
}
const formatDate = (data: any) => {
    return `我是内容：${data}`;
}
const doSomething = () => {
    console.log('123');
}
const onSubmit = () => {
    console.log('打印');

}
</script>
<style scoped></style>