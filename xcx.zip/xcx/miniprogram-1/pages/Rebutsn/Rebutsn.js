// pages/Rebutsn/Rebutsn.js
import api from '../../config/api'
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    buList: [],
    activeNames: ['0'],
    activeNames2: ['0'],
    Buelbei: "请选择团队",
    wnebei: '请选择问卷',
    Tbuel: [],
    alusb: [],
    getList: [],
    tuduid: "",
    radio: "0",
    show: false,
    message4: "",
    wunsLis: [],
    bsueshow: false,
    tmuid: "",
    fengli: [],
    subjectId: "",
    quid: "",
    twoid: "",
    target: "",
    grade: "",
    name: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options)
    const token = wx.getStorageSync('admin')
    api._get(`ums/umsTeam/selectUmsTeamList/${token.userId}`).then(res => {
      const Bu = [];
      res.data.map((item) => {
        if (item !== null) {
          Bu.push(item)
        }
      })
      this.setData({
        Tbuel: Bu,
        qusersid: token.userId
      })
      if (options.teamId != null) {
        let tName = "";
        this.data.Tbuel.map(m => {
          if (m.id == options.teamId) {
            tName = m.teamName;
          }
        })
        this.setData({
          activeNames: ['0'],
          Buelbei: tName,
          tuduid: options.teamId,
          grade: options.grade
        })
        api._get(`ums/umsQuestionnaireHistory/selectMessageAndAdmin/${options.teamId}/${token.userId}`).then(res => {
          console.log(res);
          this.setData({
            getList: res.data,
          })

          let qName = "";
          this.data.getList.map(m => {
            if (m.questionnaireId == options.qid) {
              qName = m.name;
            }
          })
          this.setData({
            wnebei: qName,
          })
          // 看下级数据
          if (options.grade == 0) {
            api._get(`ums/umsMessage/selectMessage/${token.userId}/${options.qid}/${options.teamId}`).then(res => {
              this.setData({
                alusb: res.data,
                activeNames2: ['0'],
                active: 1
              })
            }).catch(e => {
              console.log(e);
            })
          }
          // 看上级数据
          else {
            api._get(`ums/umsMessage/selectMessageBig/${token.userId}/${options.teamId}`).then(res => {
              console.log(res);
              this.setData({
                buList: res.data,
                active: 0
              })
            }).catch(e => {
              console.log(e);
            })
          }

          if (res.data.length == 0) {
            this.setData({
              getList: [{
                name: "无驳回问卷"
              }]
            })
          }
        }).catch(e => {
          console.log(e)
        })

      }
    })
  },

  onBulenu(e) {
    const token = wx.getStorageSync('admin')
    this.setData({
      activeNames: ['0'],
      Buelbei: e.currentTarget.dataset.name,
      tuduid: e.currentTarget.dataset.id,
      grade: e.currentTarget.dataset.grade,
      buList: [],
      alusb: []
    })
    api._get(`ums/umsQuestionnaireHistory/selectMessageAndAdmin/${e.currentTarget.dataset.id}/${token.userId}`).then(res => {
      console.log(res);
      this.setData({
        getList: res.data,
      })
      if (res.data.length == 0) {
        this.setData({
          getList: [{
            name: "无驳回问卷"
          }]
        })
      }
    }).catch(e => {
      console.log(e)
    })
  },
  onClose() {
    this.setData({
      show: false
    });
  },

  onWneLisr(e) {

    if (e.currentTarget.dataset.id == '' || e.currentTarget.dataset.id == null) {
      return;
    }
    if (this.data.grade != 0) {
      api._get(`ums/umsMessage/selectMessageBig/${this.data.qusersid}/${this.data.tuduid}`).then(res => {
        console.log(res);
        this.setData({
          buList: res.data,
          active: 0
        })
      }).catch(e => {
        console.log(e);
      })
    } else {
      api._get(`ums/umsMessage/selectMessage/${this.data.qusersid}/${e.currentTarget.dataset.id}/${this.data.tuduid}`).then(res => {
        this.setData({
          alusb: res.data,
          activeNames2: ['0'],
          wnebei: e.currentTarget.dataset.name,
          active: 1
        })
      }).catch(e => {
        console.log(e);
      })
    }
  },
  onChange(event) {

    this.setData({
      activeNames: event.detail,
      wnebei: '请选择问卷'
    });
  },
  onChange2(event) {
    this.setData({
      activeNames2: event.detail
    });
  },
  onChange3(event) {
    this.setData({
      active: event
    })
    // wx.showToast({
    //   title: `切换到标签 ${event.detail.name}`,
    //   icon: 'none',
    // });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },
  onClickLeft() {
    wx.switchTab({
      url: '../mssage/mssage',
    })
  },
  revokebh(e) {
    console.log(e)
    let that = this;
    wx.showModal({
      title: '系统提示',
      content: '是否撤销本题驳回信息',
      success(res) {

        if (res.confirm) {
          console.log('用户点击确定')
          //一级编号
          let questionnaireId = e.currentTarget.dataset.item.questionnaireId;
          let questionnaireTwoId = e.currentTarget.dataset.item.questionnaireTwoId;
          let subjectId = e.currentTarget.dataset.item.subjectId;
          let target = e.currentTarget.dataset.item.target;
          let teamId = e.currentTarget.dataset.item.teamId;
          api._get(`ums/umsMessage/deleteMessage/${questionnaireId}/${questionnaireTwoId}/${subjectId}/${teamId}/${target}`).then(res2 => {
          
            api._get(`ums/umsMessage/selectMessageBig/${that.data.qusersid}/${that.data.tuduid}`).then(res => {
              console.log(res);
              that.setData({
                buList: res.data,
              })
            }).catch(e => {
              console.log(e);
            })
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  onSHuene(e) {
    api._get(`ums/umsMessage/selectOptionInfo/${e.currentTarget.dataset.id}`).then(res => {
      console.log(res);
      const Luseb = [];
      const ulsb = [];
      const fengli = [];
      res.data.map((item) => {
        ulsb.push(item)
        Luseb.push({
          score: item.score,
          identification: item.identification,
          fractionId: item.id
        })
        if (item.identification == 1) {
          fengli.push({
            score: item.score,
            fractionId: item.fractionId
          })
        }
      })
      this.setData({
        wunsLis: [{
          Luseb: Luseb,
          ulsb: ulsb,
        }],
        show: true,
        fengli: fengli,
        subjectId: e.currentTarget.dataset.id,
        quid: e.currentTarget.dataset.quid,
        twoid: e.currentTarget.dataset.twoid,
        target: e.currentTarget.dataset.target,
        name: e.currentTarget.dataset.name
      })
    }).catch(e => {
      console.log(e);
    })
  },
  onChangeradio(event) {
    this.setData({
      radio: event.detail.split(',')[0],
      tmuid: event.detail.split(',')[1],
    })
    this.data.wunsLis[0].Luseb.map((item) => {
      if (item.fractionId == event.detail.split(',')[1]) {
        if (item.identification == 1) {
          this.setData({
            tmuid: event.detail.split(',')[1],
            bsueshow: true,
          })
        } else {
          this.setData({
            bsueshow: false,
          })
        }
      }
    })
  },
  onClosesbue() {
    if (this.data.radio == '0') {
      Toast.fail('请选择分数！');
    } else {
      const token = wx.getStorageSync('admin')
      if (this.data.grade == 0) {
        console.log(this.data.grade);
        const umsEvidence2 = {
          content: this.data.message4,
          subjectId: this.data.subjectId,
          optionTableId: Number(this.data.tmuid),
          questionnaireId: this.data.quid,
          teamId: this.data.tuduid,
          questionnaireTwoId: this.data.twoid,
          target: token.userId,
        }
        api._put('ums/umsEvidence/updEvidenceAdmin', umsEvidence2).then(res => {
          this.showList()
        }).catch(e => {
          console.log(e)
        })
      } else {
        console.log(this.data.grade);
        const umsEvidence = {
          content: this.data.message4,
          subjectId: this.data.subjectId,
          optionTableId: Number(this.data.tmuid),
          questionnaireId: this.data.quid,
          teamId: this.data.tuduid,
          questionnaireTwoId: this.data.twoid,
          adminId: token.userId,
          target: this.data.target,
        }
        api._post('ums/umsEvidence/addEvidenceHeAgain', umsEvidence).then(res => {
          if (res.code == 500) {
            Toast.fail('下级还没有做驳回');
          } else {

            this.showList()
          }
        }).catch(e => {
          console.log(e)
        })
      }

    }

  },
  //  案例内容
  AnonChange2(event) {
    this.setData({
      message4: event.detail
    })
  },
  showList() {

    this.setData({
      show: false,
      bsueshow: false,
      message4: "",
    })
    api._get(`ums/umsMessage/selectMessageBig/${this.data.qusersid}/${this.data.tuduid}`).then(res => {
      console.log(res);
      this.setData({
        buList: res.data,
      })
    }).catch(e => {
      console.log(e);
    })
    api._get(`ums/umsMessage/selectMessage/${this.data.qusersid}/${this.data.quid}/${this.data.tuduid}`).then(res => {
      this.setData({
        alusb: res.data,
      })

    }).catch(e => {
      console.log(e);
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  }
})