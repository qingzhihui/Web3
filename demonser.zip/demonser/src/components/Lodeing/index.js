import React, { Component } from "react";
import "./index.scss";
export default class index extends Component {
  render() {
    return (
      <div className="lsiebsueHome">
        <div className="containerHome">
          <div className="logo">
            <div className="white"></div>
            <div className="orange"></div>
            <div className="red"></div>
          </div>
        </div>
      </div>
    );
  }
}
