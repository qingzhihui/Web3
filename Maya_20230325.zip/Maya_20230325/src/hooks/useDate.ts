import React, { useEffect, useState } from "react";
declare const window: Window & { ethereum: any };

const Orderrecord = async () => {
};

export { Orderrecord };
