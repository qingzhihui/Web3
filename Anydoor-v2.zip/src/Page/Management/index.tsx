const Management = () => {
  return (
    <div>分类管理</div>
  )
}

export default Management