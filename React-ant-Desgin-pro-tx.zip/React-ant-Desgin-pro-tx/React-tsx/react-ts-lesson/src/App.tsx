import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Lee from "./Lee";
import Welcome, { Welcome1 } from "./Welcome";
import Hello from "./Hello";
import Lee2 from "./Lee2";
import User from "./User";
import UserLost from "./UserLost";
import MyForm from "./MyForm";
import AdminList from "./AdminList";
import AdminList2 from "./AdminList2";
import Cat from "./Cat";
import Dog from "./Dog";
import Apple from "./Apple";
import Orange from "./Orange";
function App() {
  return (
    <div className="App">
      {/* <Hello msg="Hello">
        <Lee />
      </Hello>
      <hr />
      <Lee /> */}
      {/* <Welcome msg="welcome" />
      <Welcome1 msg="welcome" />
      <br />
      <Welcome msg="welcome">
        <Welcome1 msg="welcom1222222222222222" />
      </Welcome>
      <Welcome1 msg="welcom1222222222222222">
        <Welcome1 msg="12312222" />
      </Welcome1> */}

      {/* <Lee2 /> */}
      {/* <User /> */}

      {/* <UserLost /> */}
      {/* <MyForm /> */}
      {/* <AdminList /> */}


      
      {/* <AdminList2 /> */}

      {/* <Cat /> */}
      {/* <Dog /> */}
      {/* 权限的判断 */}
      {/* <Apple permission="add" />
      <Apple permission="delete" />
      <Apple permission="updata" /> */}

      <Orange name="orang" />
    </div>
  );
}

export default App;
