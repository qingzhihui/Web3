import React, { useContext, useState } from "react";
import UserContext, { UserState } from "../hooks/store";

function ConsumerComponent() {
  const user = useContext<UserState>(UserContext);
  return (
    <div>
      <div>First:{user.first}</div>
      <div>Last:{user.last}</div>
    </div>
  );
}

const UseContextComponent = () => {
  const [user, UserSet] = useState<UserState>({
    first: "Jane",
    last: "Smith",
  });
  return (
    <UserContext.Provider value={user}>
      <ConsumerComponent />
      <button
        onClick={() => {
          UserSet({
            first: "Josie",
            last: "Wales",
          });
        }}
      >
        Chang context
      </button>
    </UserContext.Provider>
  );
};

export default UseContextComponent;
