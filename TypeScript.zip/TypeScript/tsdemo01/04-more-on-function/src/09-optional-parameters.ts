// 默认值
function f(n:number = 100){
    console.log(n.toFixed());
    console.log(n.toFixed(3));
}
f(123.45);
f();

// 可选值
function f2(n?:number){
    console.log(n); 
}
f2(123.45);
f2();