import React, { useEffect, useState } from "react";
import "./index.css";
import { Orderrecord } from "../../hooks/useAuns";
const useAuns = () => {
  const [useDate, setUseDate] = useState({
    JoinList: [],
    OnestList: [],
    TwostaList: [],
    ThreeaList: [],
  });

  useEffect(() => {
    Orderrecord()
      .then((res: any) => {
        setUseDate({
          JoinList: res[0],
          OnestList: res[1],
          TwostaList: res[2],
          ThreeaList: res[3],
        });
      })
      .catch((err: any) => {
        console.log(err);
      });
  }, []);
  return (
    <div>
      <div className="busieng">
        <div className="psuierni">
          {(useDate as any).JoinList.map((item: any, index: any) => (
            <div key={index} className="pdatiner">
              <div className="puisneur">
                <div>lpToken:{item.lpToken}</div>
                <div>poolType:{item.poolType}</div>
              </div>
              <div className="puisneur">
                <div>pledgee:{item.pledgee}</div>
                <div>depositTime:{item.depositTime}</div>
              </div>
              <div className="puisneur">
                <div>redeemdate:{item.redeemdate}</div>
                <div>redprodate:{item.redprodate}</div>
              </div>
              <div className="puisneur">
                <div>endeemdate:{item.endeemdate}</div>
                <div>endprodate:{item.endprodate}</div>
              </div>
              <div className="puisneur">
                <div>start:{item.start}</div>
                <div>pendingRewad:{item.pendingRewad}</div>
              </div>
              <div className="puisneur">
                <div>pendingDividend:{item.pendingDividend || 0}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default useAuns;
