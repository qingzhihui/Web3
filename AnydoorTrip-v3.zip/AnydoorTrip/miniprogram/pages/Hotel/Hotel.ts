import api from '../../config/axios'
let timer: any;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    SelectDate: [],
    inputShow: "",
    startTime: "",
    EndTime: "",
    roomNumer: "",
    funer: true,
    historData: [],
    HotelData: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      startTime: options.startTime,
      EndTime: options.EndTime,
      roomNumer: options.roomNumer
    })
    const HistorData = wx.getStorageSync('history');
    if (HistorData !== "") {
      this.setData({
        historData: HistorData,
      })
    }
    api._get('hot-hotel').then(res => {
      this.setData({
        HotelData: res.data
      })
    }).catch(e => {
      console.log(e);
    })
  },
  HotelDetailsShow(event: any) {
    wx.navigateTo({
      url: `../HotelDetails/HotelDetails?id=${event.currentTarget.id}&startTime=${this.data.startTime}&EndTime=${this.data.EndTime}&roomNumer=${this.data.roomNumer}`
    })
  },
  HotelData(value: string) {
    const urls = `search-hotel?hotelName=${value}&city=&groupId=&pageSize=20&pageNum=1`
    api._get(urls).then(res => {
      console.log(res);
      if (res.data.length !== 0) {
        this.setData({
          SelectDate: res.data,
          funer: false
        })
      }
    })
  },
  ItemDetails(event: any) {
    const { startTime, EndTime } = this.data
    const { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../HotelDetails/HotelDetails?id=${id}&startTime=${startTime}&EndTime=${EndTime}&roomNumer=${this.data.roomNumer}`
    })
  },
  debounce(event: any) {
    this.setData({
      inputShow: event.detail.value
    })
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (event.detail.value !== "") {
        this.HotelData(event.detail.value);
        this.historYoune(event.detail.value)
      } else {
        this.setData({
          funer: true,
          SelectDate: []
        })
      }
    }, 1000);
  },
  puinserValuein(e: any) {
    this.setData({
      inputShow: e.currentTarget.dataset.item
    })
    this.HotelData(e.currentTarget.dataset.item)
  },

  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  onBinserin() {
    this.setData({
      SelectDate: [],
      inputShow: ""
    })
  },
  historYoune(value: any) {
    if (this.data.historData.length === 0) {
      wx.setStorageSync('history', [value]);
      this.historBuien();
    } else {
      this.data.historData.map((item: string) => {
        if (item !== value) {
          wx.setStorageSync('history', [...this.data.historData, value]);
        } else {
          wx.setStorageSync('history', [...this.data.historData]);
        }
      })
      this.historBuien();
    }
  },
  SearceDelect() {
    wx.removeStorage({
      key: 'history'
    })
    this.historBuien();
  },

  historBuien() {
    const HistorData = wx.getStorageSync('history');
    if (HistorData !== "") {
      this.setData({
        historData: HistorData,
      })
    } else {
      this.setData({
        historData: [],
        SelectDate: [],
        funer: true
      })
    }
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})