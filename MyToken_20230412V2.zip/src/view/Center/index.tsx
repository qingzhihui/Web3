import React from "react";
import "./index.scss";
import { Alert } from "antd";
import { useTranslation } from "react-i18next";
import Marquee from "react-fast-marquee";
import { ExclamationCircleOutlined } from "@ant-design/icons";

const Center = () => {
  const { t } = useTranslation();
  return (
    <div className="Center">
      <div className="CenterComponent">
        <div className="CenterComponentFunsei">
          <div className="CenterComponentItem">
            <div className="CenterComponentItemTitle">
              <span> {`${t("Announcement Center")}`} </span>
            </div>
            <Alert
              banner
              closable={true}
              message={
                <Marquee pauseOnHover gradient={false}>
                  2023年4月，MyToken上线Pancake,启动首期社区建设，启动WeTalk头矿挖矿；
                  2023年10月，上线WeTalk社交软件，启动WeTalk生态挖矿，1-3年完成100000000+活跃用户目标；
                </Marquee>
              }
            />
            <div className="CenterComponentItemVnri">
              <div className="CenterComponentItemText">
                2023年4月，MyToken上线Pancake,启动首期社区建设，启动WeTalk头矿挖矿；
                2023年10月，上线WeTalk社交软件，启动WeTalk生态挖矿，1-3年完成100000000+活跃用户目标；
                2024年上线自主开发的钱包和去中心化交易所；
                2025年上线自主开发的公链，并启动元宇宙商城开发；
                2026年上线元宇宙商城，上线1-3款趣味性链游；
                2027-2032年，用3-5年时间完成元宇宙商城100000000+活跃用户目标。
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Center;
