// 重载函数
function makeDate(timestamp: number): Date;
function makeDate(m: number, d: number, y: number): Date;
// 实现函数
function makeDate(mOrTimestamp: number, d?: number, y?: number): Date {
  if (d !== undefined && y !== undefined) {
    return new Date(y, mOrTimestamp, d);
  }else{
      return new Date(mOrTimestamp);
  }
}

const d1 = makeDate(1234567);
const d2 = makeDate(5,6,7)
const d3 = makeDate(5);