import api from '../../config/api'
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: false,
    show3: false,
    bumen: "开发团队",
    activeNames: ['0'],
    activeNames2: ['0'],
    activeNames3: ['0'],
    activeNamesm:['0'],
    columns: ['2021第一季度', '2021第二季度', '2021第三季度', '2021第四季度', '2021第五季度'],
    Dvalue: '',
    shows: false,
    checked: false,
    qusersid: '',
    // 用户信息
    adminList: {},
    // 所属团队
    tduiList: [],
    // 团队列表
    tduinbs: [],
    // 团队列表标题
    tdutitle: "请选择团队",
    tduId: "",
    // 待评估对象
    densList: [],
    // 评估1人
    dalieNo: {},
    // 考核需知
    Kaocontent: "",
    shgrade: "",
    adminID: "",
    dishow: false,
    pinghua: "开始评价",
    //考核规定文件名
    fileName: '',
    showssbu: false,
    sbuero:0
  },
  onLoad: function (options) {
    var that = this;
    console.log(options);
    that.setData({
      qusersid: options.id,
      Dvalue: options.quarter
    })

    //获取考核规定
    api._get(`ums/umsCheckAndEvaluation/get/${this.data.qusersid}`).then(res => {
      console.log(res.data.fileName);
      that.setData({
        fileName: res.data.fileName,
      })
    }).catch(e => {
      console.log(e);
    })

    const adingList = wx.getStorageSync('admin')
    // 查询团队
    api._get(`admin/selectAdminInfo/${options.id}/${adingList.userId}`).then(res => {
      console.log(res);
      this.setData({
        adminList: res.data,
        adminID: res.data.adminId,
      })
    }).catch(e => {
      console.log(e);
    })
    // 考核标准
    api._get(`ums/umsAssessmentGuidelines/get/${options.id}`).then(res => {
      this.setData({
        Kaocontent: res.data.content
      })
    }).catch(e => {
      console.log(e);
    })
    // 是否确认
    api._get(`ums/umsAssessmentSignature/selectAssessmentSignature/${options.id}/${adingList.userId}`).then(res => {
      console.log(res);
      if (res.data > 0) {
        this.setData({
          shows: false
        })
      } else {
        this.setData({
          shows: true
        })
      }
    }).catch(e => {
      console.log(e);
    })
  },
  GetAddressList() {
    api._get(`ums/UmsUsersTeamsRelation/selectWaitObject/${this.data.tduId}/${this.data.adminList.adminId}/${this.data.qusersid}`).then(res => {
      const BUeu = res.data.filter(item => item.grade !== 1);
      this.setData({
        densList: BUeu
      })
      res.data.map((item) => {
        if (item.adminId == this.data.adminList.adminId) {
          this.setData({
            shgrade: item.grade
          })
        }
      })
    }).catch(e => {
      console.log(e);
    })
    this.setData({
      activeNames: ['1'],
    });
  },
  onClickLeft() {
    wx.switchTab({
      url: '../index/index',
    })
  },
  onClickTdHide() {
    this.setData({
      show: false
    });
  },

  // 待评估对象
  onChange(event) {
    console.log(event.detail);
    if (this.data.tdutitle == '请选择团队') {
      Toast.fail('请先选择团队');
    } else {
      api._get(`ums/UmsUsersTeamsRelation/selectWaitObject/${this.data.tduId}/${this.data.adminList.adminId}/${this.data.qusersid}`).then(res => {
        const BUeu = res.data.filter(item => item.grade !== 1);
        this.setData({
          densList: BUeu
        })
        res.data.map((item) => {
          if (item.adminId == this.data.adminList.adminId) {
            this.setData({
              shgrade: item.grade
            })
          }
        })
      }).catch(e => {
        console.log(e);
      })
      this.setData({
        activeNames: event.detail,
      });
    }

  },
  // 所属团队
  onChange3(event) {
    api._get(`ums/umsTeam/selectTeamName/${this.data.adminID}/${this.data.qusersid}`).then(res => {
      console.log(res);
      this.setData({
        tduiList: res.data,
        activeNames3: event.detail,
      })
    }).catch(e => {
      console.log(e);
    })
  },
  // 团队列表人员
  showPopup(e) {
    this.data.tduiList.map((item) => {
      if (item.teamId == e.currentTarget.dataset.id) {
        this.setData({
          dishow: true,
          tdutitle: item.teamName,
          tduId: item.teamId,
          activeNames3: ['0'],
          activeNames: ['1']
        })
      }
    })
    api._get(`ums/UmsUsersTeamsRelation/selectWaitObject/${this.data.tduId}/${this.data.adminList.adminId}/${this.data.qusersid}`).then(res => {
      const BUeu = res.data.filter(item => item.grade !== 1);
      this.setData({
        densList: BUeu
      })
      res.data.map((item) => {
        if (item.adminId == this.data.adminList.adminId) {
          this.setData({
            shgrade: item.grade
          })
        }
      })
    }).catch(e => {
      console.log(e);
    })
    api._get(`ums/umsTeam/selectTeamById/${e.currentTarget.dataset.id}`).then(res => {
      this.setData({
        tduinbs: res.data,
      })
      console.log(res.data);
    }).catch(e => {
      console.log(e);
    })
  },
  onChangem(event) {
    if (this.data.tdutitle == '请选择团队') {
      Toast.fail('请先选择团队');
    } else {
    this.setData({
      activeNamesm: event.detail,
    })
  }
  },
  // 评估人
  onChange2(event) {
    if (this.data.tdutitle == '请选择团队') {
      Toast.fail('请先选择团队');
    } else {
      api._get(`ums/UmsUsersTeamsRelation/selectWaitObject/${this.data.tduId}/${this.data.adminList.adminId}/${this.data.qusersid}`).then(res => {
        res.data.map((item) => {
          if (item.grade == 1) {
            this.setData({
              dalieNo: item
            })
          }
        })
      }).catch(e => {
        console.log(e);
      })
      this.setData({
        activeNames2: event.detail,
        activeNames: ['0']
      });
    }
  },
  onClose() {
    this.setData({
      show: false
    });
  },
  onClose3() {
    this.setData({
      show3: false
    });
  },
  onInformation(e) {
    var grade = 0;
    this.data.tduinbs.map((item) => {
      if (this.data.adminID == item.adminId) {
        if (item.grade == 1) {
          grade = 1
        } else {
          grade = 0
        }
      }
    })
    if (grade == 1) {
      this.setData({
        show: false
      })
      wx.navigateTo({
        url: `../Infotion/Infotion?id=${e.currentTarget.dataset.id}&qusersid=${this.data.qusersid}&teamId=${this.data.tduId}`
      })
    }
    if (grade == 0 && e.currentTarget.dataset.id == this.data.adminID) {
      this.setData({
        show: false
      })
      wx.navigateTo({
        url: `../Infotion/Infotion?id=${e.currentTarget.dataset.id}&qusersid=${this.data.qusersid}&teamId=${this.data.tduId}`
      })
      if (grade == 0 && e.currentTarget.dataset.id != this.data.adminID) {
        Toast.fail('请选择自己');
      }
    }
  },
  onChangesh(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    // Toast(`当前值：${value}, 当前索引：${index}`);
  },


  // 确认考核需知
  onCofirm() {
    if (this.data.checked == false) {
      this.setData({
        shows: true
      })
    } else {
      const adingList = wx.getStorageSync('admin')
      const Bulei = {
        adminId: adingList.userId,
        questionnaireId: this.data.qusersid
      }
      api._post('ums/umsAssessmentSignature/assessmentSignature', Bulei).then(res => {
        api._get(`admin/isNew/${adingList.userId}`).then(msg => {
          console.log
          if (msg.data == 1) {
            this.setData({
              shows: false,
              showssbu: true,
              sbuero:msg.data
            })
          } else {
            this.setData({
              showssbu: false,
              sbuero:0,
              shows: false,
            })
          }

        }).catch(e => {
          console.log(e);
        })
      }).catch(e => {
        console.log(e);
      })
    }
  },
  onChangebuns(event) {
    wx.setStorageSync('lid', this.data.qusersid)
    this.setData({
      checked: event.detail,
    });
  },
  onunshow() {
    // this.setData({
    //   show: true
    // })
  },

  // 自评
  onDetail: function (e) {
    console.log(e)
    var that = this;
    const adingList = wx.getStorageSync('admin')
    const ksube = {
      adminId: adingList.userId,
      questionnaireId: this.data.qusersid
    }
    if (e.currentTarget.dataset.start == 0) {
      if (adingList.userId == e.currentTarget.dataset.id) {
        wx.navigateTo({
          url: `../Detail/Detail?qusersid=${that.data.qusersid}&teamId=${that.data.tduId}&userId=${that.data.adminID}&xiaID=${e.currentTarget.dataset.id}&quarter=${this.data.Dvalue}`
        })
      } else {
        Toast.fail('请选择自己');
      }

    } else if (e.currentTarget.dataset.start == 1) {
      if (adingList.userId == e.currentTarget.dataset.id) {
        wx.navigateTo({
          url: `../HistDeta/HistDeta?id=${that.data.qusersid}&qusersid=${e.currentTarget.dataset.id}&tduid=${that.data.tduId}`,
        })
      } else {
        Toast.fail('请选择自己');
      }
    } else {
      wx.navigateTo({
        url: `../Rebutsn/Rebutsn?teamId=${this.data.tduId}&qid=${this.data.qusersid}&grade=${this.data.shgrade}`,
      })
    }
  },
  // 他评
  onsdbvak(e) {
    const adingList = wx.getStorageSync('admin')
    const ksube = {
      adminId: adingList.userId,
      questionnaireId: this.data.qusersid
    }
    var that = this;
    const sbueig = this.data.tduinbs.filter((item) => {
      return item.adminId == this.data.adminList.adminId
    })
    const {
      grade
    } = sbueig[0];
    // status ==3自评未完成
    // status ==0 未完成
    // 都可以点击进去，满足上级做案例笔记
    if (e.currentTarget.dataset.start == 0 || e.currentTarget.dataset.start == 3) {
      wx.navigateTo({
        url: `../Hisments/Hisments?qusersid=${that.data.qusersid}&teamId=${that.data.tduId}&userId=${that.data.adminID}&xiaID=${e.currentTarget.dataset.id}&quarter=${this.data.Dvalue}&grade=${grade}`
      })
    } else if (e.currentTarget.dataset.start == 1) {
      wx.navigateTo({
        url: `../HistDeta/HistDeta?id=${that.data.qusersid}&qusersid=${e.currentTarget.dataset.id}&tduid=${that.data.tduId}`,
      })
    } else if (e.currentTarget.dataset.start == 3) {
      Toast.fail('下级未自评');
    } else if (e.currentTarget.dataset.start == 4) {
      Toast.fail('有被驳回题目');
    } else {
      wx.navigateTo({
        url: `../Rebutsn/Rebutsn?teamId=${this.data.tduId}&qid=${this.data.qusersid}&grade=${this.data.shgrade}`,
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  },
  onDfang() {
    wx.navigateTo({
      url: '../DeFang/DeFang?id=' + this.data.qusersid,
    })
  },
  onHideshow() {
    wx.switchTab({
      url: '../index/index',
    })
  },
  busieng() {
    console.log('123');
    this.setData({
      showssbu: true
    })
  },
  onClosshowssbue() {
    if (this.data.sbuero == 0) {
      this.setData({
        showssbu: false
      })
    } else {
      const adingList = wx.getStorageSync('admin')
      api._get(`admin/updateIsNew/${adingList.userId}`).then(msg => {
        this.setData({
          showssbu: false
        })
      }).catch(e => {
        console.log(e);
      })
    }

  }
})