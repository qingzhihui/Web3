var wxCharts = require('../../utils/wxcharts.js');
import api from '../../config/api'
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
var lineChart = null;
Page({
  data: {
    textcolor1: '#014f8e',
    toList: {},
    ches: {},
    qusersid: "",
    teamId: "",
    xuske: 100,
  },
  onLoad: function (options) {
    const adingList = wx.getStorageSync('admin')
    api._get(`ums/umsTeam/getLineChartStatistics/${options.id}/${options.teamId}/${adingList.orgId}`).then(res => {
      const wbd = [];
      const laowbd = [];
      console.log(res);
      this.setData({
        ches: res.data
      })
      if (res.data.dataVOList == null) {
        var x_data = wbd
        var y_data = laowbd
        this.OnWxChart(x_data, y_data, '2022')
      } else {
        res.data.dataVOList.map((item) => {
          wbd.push(String(item.month + '月'))
          laowbd.push(String(item.score || 0))
          if (item.score !== null) {
            this.setData({
              xuske: Math.max(item.score),
            })
          }
        })
        //下面是图表一显示的数据，只需替换掉数据折现就会发生变化实现动态生成
        var x_data = wbd
        var y_data = laowbd
        //绘制折线图
        this.OnWxChart(x_data, y_data, '2022')
      }

    }).catch(e => {
      console.log(e);
    })
  },
  //图表点击事件
  touchcanvas: function (e) {
    var that = this;
    lineChart.showToolTip(e, {
      format: function (item, category) {
        var sbueis = '';
        if (category.length == 3) {
          const sb1 = category.split('')[0];
          const sb2 = category.split('')[1];
          sbueis = sb1 + sb2
        }
        else{
          const sb1 = category.split('')[0];
          sbueis = sb1
        }
        const wbd = that.data.ches.dataVOList[parseInt(sbueis) - 1]
        const userId = that.data.ches.userId;
        const teamId = that.data.ches.teamId
        if (that.data.ches.dataVOList[parseInt(sbueis) - 1].score !== null) {
          console.log('123');
          wx.navigateTo({
            url: `../Rebubur/Rebubur?id=${wbd.questionnaireId}&tid=${userId}&zid=${teamId}`,
          })
        } else {
          console.log('1231');
        }

        return category + ' ' + item.name + ':' + item.data
      }
    });
  },
  //折线图绘制方法
  OnWxChart: function (x_data, y_data, name) {
    var windowWidth = '',
      windowHeight = ''; //定义宽高
    try {
      var res = wx.getSystemInfoSync(); //试图获取屏幕宽高数据
      windowWidth = res.windowWidth / 750 * 690; //以设计图750为主进行比例算换
      windowHeight = res.windowWidth / 750 * 550 //以设计图750为主进行比例算换
    } catch (e) {
      console.error('getSystemInfoSync failed!'); //如果获取失败
    }
    lineChart = new wxCharts({
      canvasId: 'lineCanvas', //输入wxml中canvas的id
      type: 'line',
      categories: x_data, //模拟的x轴横坐标参数
      animation: true, //是否开启动画
      color: '#f59e1e',
      legend: true, //标题
      series: [{
        name: name,
        data: y_data,
        format: function (val, name) {
          return val + '分';
        }
      }],
      xAxis: { //是否隐藏x轴分割线
        disableGrid: true,
      },
      yAxis: { //y轴数据
        title: '问卷分数统计', //标题
        format: function (val) { //返回数值
          return val.toFixed(2) + ' 分';
        },
        min: 0, //最小值
        max: this.data.xuske,
        gridColor: '#D8D8D8',
      },
      width: windowWidth * 1.1, //图表展示内容宽度
      height: windowHeight, //图表展示内容高度
      dataLabel: false, //是否在图表上直接显示数据
      dataPointShape: true, //是否在图标上显示数据点标志
      extra: {
        lineStyle: 'Broken' //曲线
      },
    });
  },
  onClickLeft() {
    wx.navigateBack({
      url: '../Descrion/Descrion',
    })
  },
  onShareAppMessage: function () {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  }
})