import React from "react";

function withProps(Component: any, props: any) {
  return function (props2: any) {
    return <Component {...props} {...props2} />;
  };
}

function MyComponent({ name, age }: any) {
  return (
    <div>
      <p>Name: {name}</p>
      <p>Age: {age}</p>
    </div>
  );
}

const EnhancedComponent = withProps(MyComponent, { name: "John",age:"meoser" });

export default EnhancedComponent;
