// pages/Center/Center.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    radio: '1',
    date: '',
    show: false,
    currentDate: new Date().getTime(),
    minDate: new Date(1980, 10, 1).getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    inputvalue: ""
  },
  userNameInputAction(options){
    let value = options.detail.value;
    this.setData({
      inputvalue:value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  onDisplay() {
    this.setData({
      show: true
    });
  },
  onChange(event) {
    this.setData({
      radio: event.detail,
    });
  },
  onClose() {
    this.setData({
      show: false
    });
  },
  onInput(event) {
    this.setData({
      currentDate: event.detail,
    });
  },
  onInputShow() {
    let date = this.data.currentDate;
    let dateShow = new Date(date);
    this.setData({
      date: `${dateShow.getFullYear()}/${dateShow.getMonth() + 1}/${dateShow.getDate()}`,
      show: false
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  onClickLeft() {
    wx.navigateBack({
      url: '../index/index',
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})