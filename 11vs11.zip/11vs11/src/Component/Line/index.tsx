import "./index.scss"

type Props = {
  className?: string
}

export default function Line(props: Props) {
  return (
    <div className={"cmp-line " + props.className ?? ""}>
      <div className="line"/>
      <div className="ball"/>
      <div className="line"/>
      <div className="ball"/>
      <div className="line"/>
    </div>
  )
}