<script setup lang="ts">
import { ref } from "vue";
//数据
let name = ref("掌声");
let age = ref(18);
let job = ref({
    type: "前端工程师",
    salary: "30k",
});

//方法
function changeInfo() {
    name.value = "丽舍",
        age.value = 36,
        job.value.type = "后端",
        job.value.salary = '20k'
    console.log(name, age);
}
</script>
<template>
    <div>
        <h1>一个人的信息</h1>
        <h2>姓名:{{ name }}</h2>
        <h2>年龄:{{ age }}</h2>
        <h2>工作种类:{{ job.type }}</h2>
        <h2>工作工资:{{ job.salary }}</h2>
        <button @click="changeInfo">修改人的信息</button>
    </div>
</template>

