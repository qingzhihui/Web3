import { Suspense } from "react";
import { useRoutes } from "react-router-dom";
import routes from "./router/routes";
import HotnaviGation from "./components/HotnaviGation";
import LoanMations from "./components/LoanMations";
import { Web3Modal } from "@web3modal/react";
import { ethereumClient, projectId } from "./hooks/modal";
// import { bsc } from "wagmi/chains";
import { ParentComponent, HeaderComponent, ContentItem } from "./styles/styles";
import "./App.css";

const App: React.FC = () => {
  const element = useRoutes(routes);
  const elemUrlProps: string = element?.props.match.pathname;
  return (
    <div className="App">
      <ParentComponent>
        <HeaderComponent>
          <HotnaviGation url={elemUrlProps} />
        </HeaderComponent>
        <Suspense fallback={<LoanMations />}>
          <ContentItem>{element}</ContentItem>
        </Suspense>
      </ParentComponent>
      <Web3Modal
        projectId={projectId}
        // defaultChain={bsc}
        ethereumClient={ethereumClient}
      />
    </div>
  );
};

export default App;
