import React from "react";

interface Post {
  id: number;
  title: string;
}
function Blog({ posts }: { posts: Post[] }) {
  return (
    <div>
      <ul>
        {posts.map((p) => (
          <li key={p.id}>{p.title}</li>
        ))}
      </ul>
    </div>
  );
}


export async function getStaticProps() {
    const postList: Post[] = [];
    for (let index = 1; index < 10; index++) {
      postList.push({
        id: index,
        title: "title" + index,
      });
    }
//   const res = await fetch("http://localhost:3000/api/blog");
//   const posts = await res.json();
  return {
    props: {
      posts: postList,
    },
  };
}

export default Blog;
