import Report from '@components/Report'

export default Report
