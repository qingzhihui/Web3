import React from 'react'

const Passentick = () => {
  return (
    <div>
      机票
    </div>
  )
}

export default Passentick
