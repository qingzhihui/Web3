import React, { useEffect } from "react";
import Header from "../../components/Header";
import NavLeft from "../../components/NavLeft";
import "./index.scss";

export default function Admin(props: any) {

  useEffect(() => {}, []);
  return (
    <div className="container">
      <div className="nav-left">
        <NavLeft />
      </div>
      <div className="main">
        <Header />
        <div className="content">{props.children}</div>
      </div>
    </div>
  );
}
