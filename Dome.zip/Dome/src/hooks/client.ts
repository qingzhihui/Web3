import { QueryClient } from "react-query";

const add = (a: any, b: any) => a + b;

const reslu = add(10, 45);

console.log(reslu);


export default new QueryClient();
