
export interface TabItemProps {
  key?: number;
  title?: string;
  image?: string;
  imageUrl?: string;
  state?: boolean
}

const TabItem: TabItemProps[] = [
  {
    key: 0,
    title: '全部',
    image: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/Whitebar_box.png',
    imageUrl: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/Whitebar_arr.png',
    state: true
  }, {
    key: 1,
    title: '机票',
    image: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/aircraft_box.png',
    imageUrl: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/aircraft_arr.png',
    state: false
  }, {
    key: 2,
    title: '酒店',
    image: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/house_box.png',
    imageUrl: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/house_arr.png',
    state: false
  },
  {
    key: 3,
    title: '门票',
    image: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/block_box.png',
    imageUrl: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/block_arr.png',
    state: false
  }
]
export {
  TabItem
}