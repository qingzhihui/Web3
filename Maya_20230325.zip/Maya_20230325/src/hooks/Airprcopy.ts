import AirPrcoABI from "../config/abi/Airprcopy.json";
import NextTokenABI from "../config/abi/NextToken.json";
const AirPrcoAddress = "0x16680C6Ce084cbCC93667f00D054d1d7dCd43f7a";

export interface CreateAidropeProps {
  Title?: string;
  LogoURL?: string;
  Website?: string;
  Facebook?: string;
  Twitter?: string;
  Github?: string;
  Telegram?: string;
  Instagram?: string;
  Discord?: string;
  Reddit?: string;
  Youtube?:string,
  Description?: string;
}
export interface URlDataProps {
  UrlName?: string;
  PoleieData?: any;
  memoryData?: any;
  PrivatData?: any;
  VestinData?: any;
  prerateData?: any;
}


export { AirPrcoAddress, AirPrcoABI, NextTokenABI };
