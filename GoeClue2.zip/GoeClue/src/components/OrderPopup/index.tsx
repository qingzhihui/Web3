import React, { useEffect, useState } from "react";
import "./index.css";
import { ethers } from "ethers";
import order from "../../assets/image/order.png";
import myOrder from "../../assets/image/myOrder.png";
import { IDO_ADDRESS, IDO_ABI } from "../../redux/Contract/IDoContract";
import "./index.css";
import {
  CloseCircleOutlined,
  RedoOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";

declare const window: Window & { ethereum: any };

const Index = () => {
  // const [data,setData] = useState(Array)
  const [pioer, setPioer] = useState(1);
  const [address, setWalletAccount] = useState("");
  const [Ingdata, setIngdata] = useState([]);
  const [Finishdata, setFinishdata] = useState([]);
  const Pidate = (data: any) => {
    const datelio = data;
    const datelioPLe = new Date(datelio * 1000);
    const mdate = new Date(datelioPLe).toLocaleDateString().replace(/\//g, "/");
    const tdate = new Date(datelioPLe).toLocaleTimeString();
    const pdate = `${mdate.split("/")[0]}:${mdate.split("/")[1]}:${
      mdate.split("/")[2]
    } ${tdate.split(":")[0]}:${tdate.split(":")[1]}:${tdate.split(":")[2]}`;
    return pdate;
  };
  const IDodateShow = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const adres = await signer.getAddress();
    const IDoContract = new ethers.Contract(IDO_ADDRESS, IDO_ABI, signer);
    const getUserAllOrders = await IDoContract.getUserAllOrders(adres);
    const getUserHistoricalOrders = await IDoContract.getUserHistoricalOrders(
      adres
    );
    const getplDate: any = [];
    const getLPDate: any = [];
    getUserAllOrders.map(async (item: any) => {
      const getCanAvailable = await IDoContract.getCanAvailable(
        item.account,
        item.purchaseTime.toString()
      );
      const priceFor = ethers.utils.formatUnits(getCanAvailable.toString(), 18);
      const amountNum = ethers.utils.formatUnits(item.amount.toString(), 18);
      const overNum = ethers.utils.formatUnits(item.over.toString(), 18);
      const bgoData = {
        cycle: item.cycle.toString(),
        account: item.account,
        amount: amountNum,
        over: overNum,
        purchaseTime: Pidate(item.purchaseTime.toString()),
        quantityReceived: item.quantityReceived.toString(),
        receivedCycle: item.receivedCycle.toString(),
        completeTime: item.completeTime.toString(),
        done: item.done,
        Gmedate: item.purchaseTime.toString(),
        wndate: Pidate(
          (
            Number(item.purchaseTime.toString()) +
            86400 * 30 * Number(item.cycle.toString())
          ).toString()
        ),
        pricen: priceFor,
      };
      getplDate.push(bgoData);
    });
    getUserHistoricalOrders.map(async (item: any) => {
      const amountNum = ethers.utils.formatUnits(item.amount.toString(), 18);
      const bgoData = {
        cycle: item.cycle.toString(),
        account: item.account,
        amount: amountNum,
        purchaseTime: Pidate(item.purchaseTime.toString()),
        quantityReceived: item.quantityReceived.toString(),
        receivedCycle: item.receivedCycle.toString(),
        completeTime: item.completeTime.toString(),
        done: item.done,
        Gmedate: item.purchaseTime.toString(),
        wndate: Pidate(
          (
            Number(item.purchaseTime.toString()) +
            86400 * 30 * Number(item.cycle.toString())
          ).toString()
        ),
      };
      getLPDate.push(bgoData);
    });

    setTimeout(() => {
      console.log(getLPDate);

      let _OwnedDetr = JSON.parse(JSON.stringify(getLPDate));
      setFinishdata((a: any) => {
        return getLPDate.length === 0 ? a : _OwnedDetr;
      });
      let _OwnedNFT = JSON.parse(JSON.stringify(getplDate));
      setIngdata((a: any) => {
        return getplDate.length === 0 ? a : _OwnedNFT;
      });
    }, 300);
  };
  const claimonClick = async (date: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const IDoContract = new ethers.Contract(IDO_ADDRESS, IDO_ABI, signer);
    const claim = await IDoContract.claim(date);
    await claim.wait();
  };
  useEffect(() => {
    const address = localStorage.getItem("Cone_addr");
    if (address !== null && address !== undefined) {
      setWalletAccount(address);
      IDodateShow();
    } else {
      setWalletAccount("");
    }
  }, []);

  const RenderContent = (data: any) => {
    return (
      <>
        <div className="Popup">
          {data.map((item: any, index: number) => (
            <div className="PopupData" key={index}>
              <div className="popupDataItem">
                <div className="popupDataItemHeader">
                  <div>
                    <img src={order} />
                  </div>
                  <div className="Popupstate">
                    {item.done ? "已结束" : "进行中"}
                  </div>
                </div>
                <div className="dapeis">
                  <div className="data">
                    <div className="Itemtitle">账号:</div>
                  </div>
                  <div className="data">
                    <div className="ItemData">
                      {" "}
                      {item.account.substring(0, 4) +
                        "..." +
                        item.account.substring(38, 42)}
                    </div>
                  </div>
                </div>
                <div className="dapeis">
                  <div className="data">
                    <div className="Itemtitle">购买时间:</div>
                  </div>
                  <div className="data">
                    <div className="ItemData">{item.purchaseTime}</div>
                  </div>
                </div>
                <div className="dapeis">
                  {" "}
                  <div className="data">
                    <div className="Itemtitle">购买数量:</div>
                  </div>
                  <div className="data">
                    <div className="ItemData">{item.amount}</div>
                  </div>
                </div>

                <div className="dapeis">
                  {" "}
                  <div className="data">
                    <div className="Itemtitle">锁仓期:</div>
                  </div>
                  <div className="data">
                    <div className="ItemData">{item.cycle}</div>
                  </div>
                </div>
                <div className="dapeis">
                  <div className="data">
                    <div className="Itemtitle">锁仓至:</div>
                  </div>
                  <div className="data">
                    <div className="ItemData">{item.wndate}</div>
                  </div>
                </div>
                <div className="dapeis">
                  <div className="data">
                    <div className="Itemtitle">可领取:</div>
                  </div>
                  <div className="data">
                    <div className="ItemData">{item.over}</div>
                  </div>
                </div>
                <div className="dapeis">
                  <div className="data">
                    <div className="Itemtitle">待领取:</div>
                  </div>
                  <div className="data">
                    <div className="ItemData">{item.pricen}</div>
                  </div>
                </div>
                <div className="dataButtonArea">
                  <button
                    className="claimbtn"
                    onClick={() => {
                      claimonClick(item.Gmedate);
                    }}
                  >
                    Claim
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </>
    );
  };

  return (
    <>
      <div className="MyOrder">
        <div className="Order_header">
          <div className="Order_titleArea">
            <img src={myOrder} alt="" />
            <span>我的订单</span>
          </div>
        </div>
        <div className="psueornb">
          <div className="sienue_lei">
            <div
              className={[`sienue_lei_item ${pioer == 1 ? "actis" : ""}`].join(
                ""
              )}
              onClick={() => {
                setPioer(1);
              }}
            >
              进行中
            </div>
            <div
              className={[`sienue_lei_item ${pioer == 2 ? "actis" : ""}`].join(
                ""
              )}
              onClick={() => {
                setPioer(2);
              }}
            >
              已结束
            </div>
          </div>
          {pioer == 1 ? (
            <div className="sienue_rel">{RenderContent(Ingdata)}</div>
          ) : (
            <div className="sienue_rel">
              <div className="Popup">
                {Finishdata.map((item: any, index: number) => (
                  <div className="PopupData" key={index}>
                    <div className="popupDataItem2">
                      <div className="popupDataItemHeader">
                        <div>
                          <img src={order} />
                        </div>
                        <div className="Popupstate">
                          {item.done ? "已结束" : "进行中"}
                        </div>
                      </div>
                      <div className="dapeis">
                        <div className="data">
                          <div className="Itemtitle">账号:</div>
                        </div>
                        <div className="data">
                          <div className="ItemData">
                            {" "}
                            {item.account.substring(0, 4) +
                              "..." +
                              item.account.substring(38, 42)}
                          </div>
                        </div>
                      </div>
                      <div className="dapeis">
                        <div className="data">
                          <div className="Itemtitle">购买时间:</div>
                        </div>
                        <div className="data">
                          <div className="ItemData">{item.purchaseTime}</div>
                        </div>
                      </div>
                      <div className="dapeis">
                        {" "}
                        <div className="data">
                          <div className="Itemtitle">购买数量:</div>
                        </div>
                        <div className="data">
                          <div className="ItemData">{item.amount}</div>
                        </div>
                      </div>

                      <div className="dapeis">
                        {" "}
                        <div className="data">
                          <div className="Itemtitle">锁仓期:</div>
                        </div>
                        <div className="data">
                          <div className="ItemData">{item.cycle}</div>
                        </div>
                      </div>
                      <div className="dapeis">
                        <div className="data">
                          <div className="Itemtitle">锁仓至:</div>
                        </div>
                        <div className="data">
                          <div className="ItemData">{item.wndate}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Index;
