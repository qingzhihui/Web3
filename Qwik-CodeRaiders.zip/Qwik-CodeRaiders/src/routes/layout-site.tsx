import { component$, Slot, useStyles$ } from "@builder.io/qwik";
import { routeLoader$ } from "@builder.io/qwik-city";
import styles from "./styles.css?inline";
import { Navigation } from "../components/navigation/navigation";

export const useServerTimeLoader = routeLoader$(() => {
  return {
    date: new Date().toISOString(),
  };
});

export default component$(() => {
  useStyles$(styles);
  return (
    <>
      <main>
        <Navigation />
        <section>
          <Slot />
        </section>
      </main>
      <footer>
        <div class="bg-gray-900 text-white text-white py-14 text-center">
          This is my footer
        </div>
      </footer>
    </>
  );
});
