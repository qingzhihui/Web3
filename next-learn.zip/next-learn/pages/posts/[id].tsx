import React from "react";
interface Post {
  id: string;
  title: string;
}
function Index({ id, title }: { id: string; title: string }) {
  return (
    <div>
      {id}
      <br />
      {title}
    </div>
  );
}

export async function getStaticProps({ params }: { params: { id: string } }) {
  return {
    props: {
      id: params.id,
      title: "title" + params.id,
    },
  };
}

export async function getStaticPaths() {
  const paths = [1, 2, 3, 4, 5, 6, 7].map((id) => {
    return {
      params: { id: id + "" },
    };
  });
  return {
    paths,
    fallback: false,
  };
}

export default Index;