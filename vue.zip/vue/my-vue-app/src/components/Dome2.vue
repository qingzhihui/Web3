<template >
    <button @click="m()">ches {{ b }}</button>

</template>

<script setup lang="ts">


// 大厂定义undefined
var b = void 0;

// undefined的错误用法
function m() {
    var undefined = 1;
    var a = undefined;
    console.log(a);
    console.log(b)
}
</script>

<style>

</style>