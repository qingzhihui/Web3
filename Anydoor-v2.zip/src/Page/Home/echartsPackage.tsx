import * as echarts from 'echarts'
// 用户增加图表
export const options:any = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#57617B'
          }
        }
      },
      // legend: {
      //   icon: 'rect',
      //   itemWidth: 14,
      //   itemHeight: 5,
      //   itemGap: 13,
      //   data: ['近30天',
      //   ],
      //   right: '4%',
      //   textStyle: {
      //     fontSize: 12,
      //     color: 'rgb(0 0 0)'
      //   }
      // },
      grid: {
        left: '2%',
        right: '4%',
        bottom: '3%',
        top: "10%",
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        boundaryGap: false,
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        data: ['01-25',
          '01-30',
          '02-05',
          '02-11',
          '02-17',
          '02-23',
        ]
      }],
      yAxis: [{
    
        type: 'value',
        // name: '单位（%）',
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        axisLabel: {
          margin: 5,
          textStyle: {
            fontSize: 14
          }
        },
        splitLine: {
          lineStyle: {
            type: 'dashed',
            color: '#DDD'
          }
        }
      }],
      series: [{
        name: '近30天',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        showSymbol: false,
        lineStyle: {
          normal: {
            width: 3
          }
        },
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(255, 160, 108, 0.3)'
            }, {
              offset: 0.8,
              color: 'rgba(255, 160, 108, 0)'
            }], false),
            shadowColor: 'rgba(255, 160, 108, 0.1)',
            shadowBlur: 10
          }
        },
        itemStyle: {
          normal: {
    
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(255, 160, 108, 1)'
            }, {
              offset: 1,
              color: 'rgba(255, 160, 108, 1)'
            }])
          },
          emphasis: {
            color: 'rgba(255, 160, 108, 1)',
            borderColor: 'rgba(255, 160, 108, 0.2)',
            extraCssText: 'box-shadow: 8px 8px 8px rgba(0, 0, 0, 1);',
            borderWidth: 10,
    
          },
        },
        data: [3,
          10,
          30,
          60,
          65,
          90,
        ]
      },
      ]
}

// 用户总数图表
export const options1:any = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#57617B'
          }
        }
      },
      // legend: {
      //   icon: 'rect',
      //   itemWidth: 14,
      //   itemHeight: 5,
      //   itemGap: 13,
      //   data: ['近30天',
      //   ],
      //   right: '4%',
      //   textStyle: {
      //     fontSize: 12,
      //     color: 'rgb(0 0 0)'
      //   }
      // },
      grid: {
        left: '2%',
        right: '4%',
        bottom: '3%',
        top: "10%",
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        boundaryGap: false,
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        data: ['01-25',
          '01-30',
          '02-05',
          '02-11',
          '02-17',
          '02-23',
        ]
      }],
      yAxis: [{
    
        type: 'value',
        // name: '单位（%）',
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        axisLabel: {
          margin: 5,
          textStyle: {
            fontSize: 14
          }
        },
        splitLine: {
          lineStyle: {
            type: 'dashed',
            color: '#DDD'
          }
        }
      }],
      series: [{
        name: '近30天',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        showSymbol: false,
        lineStyle: {
          normal: {
            width: 3
          }
        },
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(255, 122, 181, 1)'
            }, {
              offset: 0.8,
              color: 'rgba(255, 160, 108, 0)'
            }], false),
            shadowColor: 'rgba(255, 160, 108, 0.1)',
            shadowBlur: 10
          }
        },
        itemStyle: {
          normal: {
    
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(255, 122, 181, 1)'
            }, {
              offset: 1,
              color: 'rgba(255, 122, 181, 1)'
            }])
          },
          emphasis: {
            color: 'rgba(255, 122, 181, 1)',
            borderColor: 'rgba(255, 122, 181, 1)',
            extraCssText: 'box-shadow: 8px 8px 8px rgba(0, 0, 0, 1);',
            borderWidth: 10,
    
          },
        },
        data: [3,
          50,
          30,
          20,
          85,
          65,
        ]
      },
      ]
}

// 订单量图表
export const options2:any = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#57617B'
          }
        }
      },
      // legend: {
      //   icon: 'rect',
      //   itemWidth: 14,
      //   itemHeight: 5,
      //   itemGap: 13,
      //   data: ['近30天',
      //   ],
      //   right: '4%',
      //   textStyle: {
      //     fontSize: 12,
      //     color: 'rgb(0 0 0)'
      //   }
      // },
      grid: {
        left: '2%',
        right: '4%',
        bottom: '3%',
        top: "10%",
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        boundaryGap: false,
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        data: ['01-25',
          '01-30',
          '02-05',
          '02-11',
          '02-17',
          '02-23',
        ]
      }],
      yAxis: [{
    
        type: 'value',
        // name: '单位（%）',
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        axisLabel: {
          margin: 5,
          textStyle: {
            fontSize: 14
          }
        },
        splitLine: {
          lineStyle: {
            type: 'dashed',
            color: '#DDD'
          }
        }
      }],
      series: [{
        name: '近30天',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        showSymbol: false,
        lineStyle: {
          normal: {
            width: 3
          }
        },
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(0,0,255, 0.3)'
            }, {
              offset: 0.8,
              color: 'rgba(0,0,255, 0)'
            }], false),
            shadowColor: 'rgba(0,0,255, 0.1)',
            shadowBlur: 10
          }
        },
        itemStyle: {
          normal: {
    
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(0,0,255, 1)'
            }, {
              offset: 1,
              color: 'rgba(0,0,255, 1)'
            }])
          },
          emphasis: {
            color: 'rgba(0,0,255, 1)',
            borderColor: 'rgba(0,0,255, 0.2)',
            extraCssText: 'box-shadow: 8px 8px 8px rgba(0, 0, 0, 1);',
            borderWidth: 10,
    
          },
        },
        data: [30,
          10,
          30,
          60,
          15,
          0,
        ]
      },
      ]
}

// 取消订单图表
export const options3:any = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#57617B'
          }
        }
      },
      // legend: {
      //   icon: 'rect',
      //   itemWidth: 14,
      //   itemHeight: 5,
      //   itemGap: 13,
      //   data: ['近30天',
      //   ],
      //   right: '4%',
      //   textStyle: {
      //     fontSize: 12,
      //     color: 'rgb(0 0 0)'
      //   }
      // },
      grid: {
        left: '2%',
        right: '4%',
        bottom: '3%',
        top: "10%",
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        boundaryGap: false,
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        data: ['01-25','01-30','02-05','02-11','02-17','02-23',]
      }],
      yAxis: [{
    
        type: 'value',
        // name: '单位（%）',
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        axisLabel: {
          margin: 5,
          textStyle: {
            fontSize: 14
          }
        },
        splitLine: {
          lineStyle: {
            type: 'dashed',
            color: '#DDD'
          }
        }
      }],
      series: [{
        name: '近30天',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        showSymbol: false,
        lineStyle: {
          normal: {
            width: 3
          }
        },
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(0,255,0, 0.3)'
            }, {
              offset: 0.8,
              color: 'rgba(0,255,0, 0)'
            }], false),
            shadowColor: 'rgba(0,255,0, 0.1)',
            shadowBlur: 10
          }
        },
        itemStyle: {
          normal: {
    
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(0,255,0, 1)'
            }, {
              offset: 1,
              color: 'rgba(0,255,0, 1)'
            }])
          },
          emphasis: {
            color: 'rgba(0,255,0, 1)',
            borderColor: 'rgba(0,255,0, 0.2)',
            extraCssText: 'box-shadow: 8px 8px 8px rgba(0, 0, 0, 1);',
            borderWidth: 10,
    
          },
        },
        data: [
          90,
          20,
          50,
          30,
          80,
          78,
        ]
      },
      ]
}

// 订单收入图表
export const options4:any = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#57617B'
          }
        }
      },
      // legend: {
      //   icon: 'rect',
      //   itemWidth: 14,
      //   itemHeight: 5,
      //   itemGap: 13,
      //   data: ['近30天',
      //   ],
      //   right: '4%',
      //   textStyle: {
      //     fontSize: 12,
      //     color: 'rgb(0 0 0)'
      //   }
      // },
      grid: {
        left: '2%',
        right: '4%',
        bottom: '3%',
        top: "10%",
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        boundaryGap: false,
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        data: ['01-25','01-30','02-05','02-11','02-17','02-23',]
      }],
      yAxis: [{
    
        type: 'value',
        // name: '单位（%）',
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        axisLabel: {
          margin: 5,
          textStyle: {
            fontSize: 14
          }
        },
        splitLine: {
          lineStyle: {
            type: 'dashed',
            color: '#DDD'
          }
        }
      }],
      series: [{
        name: '近30天',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        showSymbol: false,
        lineStyle: {
          normal: {
            width: 3
          }
        },
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(0,255,0, 0.3)'
            }, {
              offset: 0.8,
              color: 'rgba(0,255,0, 0)'
            }], false),
            shadowColor: 'rgba(0,255,0, 0.1)',
            shadowBlur: 10
          }
        },
        itemStyle: {
          normal: {
    
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(0,255,0, 1)'
            }, {
              offset: 1,
              color: 'rgba(0,255,0, 1)'
            }])
          },
          emphasis: {
            color: 'rgba(0,255,0, 1)',
            borderColor: 'rgba(0,255,0, 0.2)',
            extraCssText: 'box-shadow: 8px 8px 8px rgba(0, 0, 0, 1);',
            borderWidth: 10,
    
          },
        },
        data: [3,
          10,
          30,
          60,
          65,
          90,
        ]
      },
      ]
}

// 退款图表
export const options5:any = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#57617B'
          }
        }
      },
      // legend: {
      //   icon: 'rect',
      //   itemWidth: 14,
      //   itemHeight: 5,
      //   itemGap: 13,
      //   data: ['近30天',
      //   ],
      //   right: '4%',
      //   textStyle: {
      //     fontSize: 12,
      //     color: 'rgb(0 0 0)'
      //   }
      // },
      grid: {
        left: '2%',
        right: '4%',
        bottom: '3%',
        top: "10%",
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        boundaryGap: false,
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        data: ['01-25','01-30','02-05','02-11','02-17','02-23',]
      }],
      yAxis: [{
    
        type: 'value',
        // name: '单位（%）',
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: 'rgb(0 0 0)'
          }
        },
        axisLabel: {
          margin: 5,
          textStyle: {
            fontSize: 14
          }
        },
        splitLine: {
          lineStyle: {
            type: 'dashed',
            color: '#DDD'
          }
        }
      }],
      series: [{
        name: '近30天',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        showSymbol: false,
        lineStyle: {
          normal: {
            width: 3
          }
        },
        areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(255, 160, 108, 0.3)'
            }, {
              offset: 0.8,
              color: 'rgba(255, 160, 108, 0)'
            }], false),
            shadowColor: 'rgba(255, 160, 108, 0.1)',
            shadowBlur: 10
          }
        },
        itemStyle: {
          normal: {
    
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
              offset: 0,
              color: 'rgba(255, 160, 108, 1)'
            }, {
              offset: 1,
              color: 'rgba(255, 160, 108, 1)'
            }])
          },
          emphasis: {
            color: 'rgba(255, 160, 108, 1)',
            borderColor: 'rgba(255, 160, 108, 0.2)',
            extraCssText: 'box-shadow: 8px 8px 8px rgba(0, 0, 0, 1);',
            borderWidth: 10,
    
          },
        },
        data: [3,
          10,
          30,
          60,
          65,
          90,
        ]
      },
      ]
}


