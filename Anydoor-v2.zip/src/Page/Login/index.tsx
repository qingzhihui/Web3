import {
  TeamOutlined,
  LockOutlined,
  EllipsisOutlined,
} from "@ant-design/icons";
import { Button, Checkbox, Form, Input, Radio } from "antd";
import "./index.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";

// 登录界面
const Login = () => {
  const navigate = useNavigate();
  // 提交的数据
  const onFinish = async (values: any) => {
    await axios
      .post("http://45.77.206.193:8000/api/token", {
        captcha: 456,
        username: "admin",
        password: "123456",
        captchaKey: 21,
      })
      .then((result: any) => {
        console.log(result);

        // navigate("/Anydoor", {
        //   state: {
        //     data: values,
        //   },
        // });
      })
      .catch((err: any) => {});
  };

  // 忘记密码按钮
  const forgotPassword = () => {
    return console.log("点击了忘记密码");
  };

  // 是否记住密码
  const onChange = (e: any) => {
    console.log(`checked = ${e.target.checked}`);
  };

  // 点击了验证码
  const verificationCodeBtn = () => {
    console.log("点击了验证码");
  };

  return (
    <div className="login_box">
      {/* 左侧 */}
      <div className="box_left">
        <div className="left_consts">
          <div className="leftTitle">Anydoor Trip 后台管理系统</div>
          <div className="leftConst1">
            Anydoor Trip致力于提供最好的奢华旅行体验 <br />
            例如全球体育赛事安排、航班礼宾服务、 <br />
            时尚精品活动和独家名人派对。 <br />
            <br />
            我们相信您的时间非常宝贵 - 我们的在线订购系统是
            <br />
            24 / 7 全天候可用。 无论何时，您都可以信赖我们世界一流的服务
            和任何地方。
            <br />
          </div>
        </div>
      </div>
      {/* 右侧 */}
      <div className="box_right">
        <div className="contBox">
          <div className="welcomeLogin">欢迎登陆</div>
          <div className="phoneNumber">如需帮助，请拨打0756-8609068</div>
          <div>
            <Form
              name="basic"
              labelCol={{ span: 0 }}
              wrapperCol={{ span: 16 }}
              style={{ maxWidth: 600 }}
              initialValues={{ remember: true }}
              onFinish={onFinish}
              autoComplete="off"
            >
              <div className="publicInput">
                <div className="usericon">
                  <TeamOutlined />
                </div>
                <div className="inputuser">
                  <Form.Item className="inputs" name="username">
                    <Input />
                  </Form.Item>
                </div>
              </div>
              <div className="publicInput">
                <div className="passwordicon">
                  <LockOutlined />
                </div>
                <div className="inputuser">
                  <Form.Item className="inputs" name="password">
                    <Input />
                  </Form.Item>
                </div>
              </div>
              <div className="publicInput">
                <div className="yanzhengicon">
                  <EllipsisOutlined />
                </div>
                <div className="inputuser">
                  <Form.Item className="inputs" name="yanzm">
                    <Input />
                  </Form.Item>
                </div>
                <div className="yzmImg">
                  <img
                    onClick={verificationCodeBtn}
                    width="100%"
                    height="100%"
                    src="https://img1.baidu.com/it/u=1002507201,2490577487&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1680109200&t=b2da311341ec35a1d914bba87b8f8bd7"
                    alt=""
                  />
                </div>
              </div>
              <div className="pawCont">
                <Checkbox onChange={onChange}></Checkbox>&nbsp;记住密码
                <div className="wangjipwd" onClick={forgotPassword}>
                  忘记密码
                </div>
              </div>
              <div className="loginbtnBox">
                <Form.Item>
                  <Button className="loginbtn" type="primary" htmlType="submit">
                    登录
                  </Button>
                </Form.Item>
              </div>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Login;
