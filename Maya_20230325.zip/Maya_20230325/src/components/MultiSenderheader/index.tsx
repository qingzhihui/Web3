import { log } from "console";
import React, { useEffect } from "react";
import gobed from "../../assets/image/gobed.png";
import { useTranslation, Trans } from "react-i18next";
import "./index.scss";

const MultiSenderheader = (props: any) => {
  const { t } = useTranslation();
  return (
    <div className="MultiSender_header">
      <div className="headerone">
        <div className="number">
          <div className={["one", "progress"].join(" ")}>1</div>
          <div className="two">2</div>
        </div>
        <div className="allocation">
          <div className="title">{`${t("Add Your Allocation")}`}</div>
          <div className="enter">
            {`${t("Enter your token to be send with allocations")}`}
          </div>
        </div>
      </div>
      <div
        className={["headertow", props.setp === 2 ? "progrHeader" : null].join(
          " "
        )}
      ></div>
      <div className="headerthree">
        <div
          className={["number", props.setp === 2 ? "progress" : null].join(" ")}
        >
          2
        </div>
        <div className="allocation">
          <div className="title">{`${t("Confirmation")}`}</div>
          <div className="enter">{`${t("Let review your information")}`}</div>
        </div>
      </div>
      <div className="imgs">
        <img src={gobed} alt="" />
      </div>
    </div>
  );
};
export default MultiSenderheader;
