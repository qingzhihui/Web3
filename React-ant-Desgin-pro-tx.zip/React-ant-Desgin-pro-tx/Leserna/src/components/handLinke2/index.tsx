import { Button, Popconfirm, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import BigNumber from 'bignumber.js';
import { ethers } from 'ethers';
import { useEffect, useState } from 'react';
import contractABI from '../../../contract/ContractABI.json';
import contractABI2 from '../../../contract/ContractABI2.json';
import './index.css';
const contractAddress = '0xF6cAa12D39861A76E5632ACB33b9431bFC3C90FB';

declare const window: Window & { ethereum: any };

export interface ILisnt {
  key: React.Key;
  address: string;
  binale: string;
}

function index(props: any) {
  const [address, setAddress] = useState(props.address);
  // const [binale, setBinale] = useState(props.binale);
  const [omplete, setOmplete] = useState(props.omplete);
  const [Libsnul, setLibsnul] = useState(props.Libsnul);
  const [blance, setblance] = useState(props.blance);
  const [Lnueshow, setLnueshow] = useState(0);

  const columns: ColumnsType<ILisnt> = [
    {
      title: 'key',
      dataIndex: 'key',
      key: 'key',
      render: (text) => <a>{text}</a>,
    },
    {
      title: 'address',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: 'binale',
      dataIndex: 'binale',
      key: 'binale',
    },
    {
      title: 'Delete',
      key: 'operation',
      fixed: 'right',
      width: 100,
      render: (record: { key: React.Key }) => (
        <Popconfirm title="确定要删除吗?" onConfirm={() => handleDelete(record.key)}>
          <Button type="primary">删除</Button>
        </Popconfirm>
      ),
    },
  ];
  const handleDelete = (e: any) => {
    const LibsData = Libsnul.filter((item: ILisnt) => item.key !== e);
    setLibsnul(LibsData);
      const blueList: any = [];
      LibsData.map((item: any) => {
        blueList.push({ bing: Number(item.binale) });
      });
    var bleu: Number = 0;
    for (var i = 0; i < blueList.length; i++) {
      bleu += blueList[i].bing;
      console.log();

      setLnueshow(Number(bleu));
    }
  };
  const UpdateCurrentWallet = async () => {
    const { ethereum } = window;
    const provider = new ethers.providers.Web3Provider(ethereum);
    const signer = provider.getSigner();
    const KusContract = new ethers.Contract(contractAddress, contractABI, signer);
    const KusContract2 = new ethers.Contract(omplete, contractABI2, signer);
    const Baase: any = [];
    const Libse: any = [];
    Libsnul.map((item: any) => {
      Baase.push(item.address);
      Libse.push(item.binale);
    });
    const feea = await KusContract.fee();
    const deicm = await KusContract2.decimals();

    var shce: any = [];
    Libse.map((msn: any) => {
      const biseb = new BigNumber(msn).times(new BigNumber(10).pow(deicm)).toString();
      shce.push(Number(biseb));
    });

    const amount2 = ethers.constants.MaxUint256;
    const approve = await KusContract2.approve(contractAddress, amount2);
    await approve.wait();
    await KusContract.transferProToken(omplete, Baase, shce, {
      value: ethers.utils.parseEther(ethers.utils.formatEther(feea)),
    });
  };
  const Updateshow = () => {
    props.UpdateCurrentHide();
  };
  useEffect(() => {
    const blueList: any = [];
    Libsnul.map((item: any) => {
      blueList.push({ bing: Number(item.binale) });
    });
    var bleu: Number = 0;
    for (var i = 0; i < blueList.length; i++) {
      bleu += blueList[i].bing;
      setLnueshow(Number(bleu));
    }
  }, []);

  return (
    <div className="handLine">
      <div className="lineitem">
        <div className="titlei" style={{ textAlign: 'center' }}>
          <span>批量发送代币</span>
        </div>
        <div className="lineitem_table">
          <div className="titlei">
            <span>地址列表</span>
          </div>
          <Table
            dataSource={Libsnul}
            bordered={true}
            columns={columns}
            rowKey={(item) => item.key}
          />
        </div>
        <div className="lineitem_zhiayao">
          <div className="titlei">
            <span>摘要</span>
          </div>
          <div className="tiLisn">
            <div className="item">
              <div>{Libsnul.length}</div>
              <div>地址总数</div>
            </div>
            <div className="item">
              <div>{Lnueshow} BNB</div>
              <div>代币发送总数</div>
            </div>
            <div className="item">
              <div>{Libsnul.length}</div>
              <div>交易总数</div>
            </div>
            <div className="item">
              <div>{blance} BNB</div>
              <div>代币余额</div>
            </div>
            <div className="item">
              <div>0 BNB</div>
              <div>预估手续费(含额外手续费 0 BNB)</div>
            </div>
            <div className="item">
              <div>{blance} BNB</div>
              <div>您的余额</div>
            </div>
          </div>
        </div>
        <div className="titshi">
          <span>network does not support ENS</span>
        </div>
        <div className="busleius">
          <Button
            type="primary"
            onClick={() => {
              Updateshow();
            }}
          >
            返回
          </Button>
          <Button
            type="primary"
            onClick={() => {
              UpdateCurrentWallet();
            }}
          >
            发送
          </Button>
        </div>
      </div>
    </div>
  );
}

export default index;
