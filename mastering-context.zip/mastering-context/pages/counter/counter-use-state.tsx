import { useState } from "react";

const Container = ({ children }: any) => <div>{children}</div>;
const Counter = ({ counter }: any) => <div>Counter:{counter}</div>;

const AddOneButton = ({ setCounter }: any) => (
  <div>
    <button
      onClick={() => {
        setCounter((v: any) => v + 1);
      }}
    >
      Add One
    </button>
  </div>
);

export default function CounterUseState() {
  const [counter, setCounter] = useState(0);
  return (
    <div>
      <Container>
        <AddOneButton setCounter={setCounter} />
      </Container>
      <Counter counter={counter} />
    </div>
  );
}
