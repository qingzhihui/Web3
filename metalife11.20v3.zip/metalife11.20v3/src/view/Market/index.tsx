/*
 * @Author: 'Salah' '2236291956@qq.com'
 * @Date: 2022-11-09 17:33:50
 * @LastEditors: 'Salah' '2236291956@qq.com'
 * @LastEditTime: 2022-11-09 17:57:41
 * @FilePath: \Metalife-fei1.1\src\view\Market\index.tsx
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import React, { useState, useEffect } from "react";
import "./index.scss";
import { useTranslation } from "react-i18next";
import Header from "../../components/Header";
import Heues from "../../components/Heues";
import log1 from "../../assets/image/Twitter.png";
import log2 from "../../assets/image/Union.png";
import log3 from "../../assets/image/Instagram.png";
import moment from "moment";
import graphicsThree from '../../assets/image/graphicsThree.png'
import { useInterval } from "ahooks";

const NFT = () => {
  const [interval, setInterval] = useState<any>(1000);
  const [current, setTime] = useState<any>("0 天 0 时 0 分 0 秒");
  const { t } = useTranslation();
  useEffect(() => {
    if (isArrived) {
      setInterval(null);
    }
  });
  const deadLine = moment("2033-10-19 20:22:45");
  const deadLineTime = deadLine.diff(moment());
  let durationTime = moment.duration(deadLineTime);
  let isArrived = deadLineTime < 0;
  useInterval(
    () => {
      let arriveTime = `${durationTime.days()} : ${durationTime.hours()} : ${durationTime.minutes()} : ${durationTime.seconds()}`;
      if (!isArrived) {
        durationTime = moment.duration(deadLine.diff(moment()));
        setTime(() => arriveTime);
      }
    },
    interval,
    { immediate: true }
  );

  return (
    <div className="NftPage">
      <Header MsgIndex="5" />
      <div className="spidried">
        {/* 动画背景 */}
        <div className="ContentLogoThree">
          <img className="HomeContentLogo" src={graphicsThree} alt="" />
        </div>
        <div className="NftDevi">
          <div className="NftDevi_tiry">{current}</div>
          <div className="Nsuerfit">
            <div className="Nsuerfit_spieor">{`${t("COMING SOON")}`}</div>
            <div className="Nsuerfit_nreo">{`${t(
              "We will be here soon!"
            )}`}</div>
          </div>
          <div className="Nsuerfit2">
            <div className="Nsuerfit_spieor2">
              {`${t("We are currently working on our website.")}`}
            </div>
            <div className="Nsuerfit_nreo2">
              {`${t(
                "We will be here soon. Click on the buton to be notified when our site is ready!"
              )}`}
            </div>
          </div>
          <div className="NsuerFotter">
            <div className="foter">
              <img src={log1} alt="" />
            </div>
            <div className="foter">
              <img src={log3} alt="" />
            </div>
            <div className="foter">
              <img src={log2} alt="" />
            </div>
          </div>
          <div className="HomeContentLogoArea">
            <img className="HomeContentLogoThreePhone" src={graphicsThree} alt="" />
          </div>
        </div>
      </div>
      <Heues burl="/MARKET" />
    </div>
  );
};
export default NFT;
