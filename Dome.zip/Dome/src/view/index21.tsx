import React, { memo, useState } from "react";

// 使用 React.memo() 包裹的组件
const MemoizedComponent = memo(({ name }: { name: string }) => {
  console.log(`Rendering MemoizedComponent with name ${name}`);
  return <div>Hello, {name}!</div>;
});

// 不使用 React.memo() 包裹的组件
const NonMemoizedComponent = ({ name }: { name: string }) => {
  console.log(`Rendering NonMemoizedComponent with name ${name}`);
  return <div>Hello, {name}!</div>;
};

function App() {
  const name = "React.memo()";
  const [ches, setChes] = useState(1);

  return (
    <div>
      <MemoizedComponent name={name} />
      <NonMemoizedComponent name={name} />
      <button
        onClick={() => {
          setChes((value) => value + 1);
        }}
      >
        修改
      </button>
    </div>
  );
}

export default App;
