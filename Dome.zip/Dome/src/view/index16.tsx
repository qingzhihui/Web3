import React from "react";

type Props = {
  name: string;
  age: number;
};

type ListItemProps<T> = {
  item: T;
  onClick: (item: T) => void;
};
const userList = [{ name: "Alice" }, { name: "Bob" }, { name: "Charlie" }];
function ListItem<T>({ item, onClick }: ListItemProps<T>) {
  console.log(item);

  return <li onClick={() => onClick(item)}>{/* 渲染item的内容 */}</li>;
}

const Person: React.FC<Props> = ({ name, age }) => {
  const handleItemClick = () => {
    console.log("123");
  };
  return (
    <div>
      <p>Name: {name}</p>
      <p>Age: {age}</p>
      <ListItem<{ name: string }>
        item={userList[0]}
        onClick={handleItemClick}
      />
    </div>
  );
};
export default Person;
