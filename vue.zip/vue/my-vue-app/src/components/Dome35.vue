<template>
  <div class="spoeirn">
    <el-tree :data="data" :expand-on-click-node="false" icon="" :props="defaultProps" @node-click="handleNodeClick">
      <div class="custom-tree-node" slot-scope="{ node, data }">
        <div class="treeNroe">
          <div>珠海八爪智能科技有限公司测试</div>
          <div class="Shinese">
            <el-icon><MoreFilled /></el-icon>
          </div>
        </div>
      </div>
    </el-tree>
  </div>
</template>

<script lang="ts" setup>
interface Tree {
  label: string
  children?: Tree[],
}

const handleNodeClick = (data: Tree) => {
  console.log(data)
}
const data: Tree[] = [
  {
    label: 'Level one 1',
    children: [
      {
        label: 'Level two 1-1',
        children: [
          {
            label: 'Level three 1-1-1',
          },
        ],
      },
    ],
  },
  {
    label: 'Level one 2',
    children: [
      {
        label: 'Level two 2-1',
        children: [
          {
            label: 'Level three 2-1-1',
          },
        ],
      },
      {
        label: 'Level two 2-2',
        children: [
          {
            label: 'Level three 2-2-1',
          },
        ],
      },
    ],
  },
  {
    label: 'Level one 3',
    children: [
      {
        label: 'Level two 3-1',
        children: [
          {
            label: 'Level three 3-1-1',
          },
        ],
      },
      {
        label: 'Level two 3-2',
        children: [
          {
            label: 'Level three 3-2-1',
          },
        ],
      },
    ],
  },
]

const defaultProps = {
  children: 'children',
  label: 'label',
}
</script>

<style>

.spoeirn {
  width: 380px;
  border: 1px solid red;
}

.treeNroe {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
}

.custom-tree-node {
  width: 100%;
}
.Shinese{
  position: absolute;
  right: 0px;
  padding-left: 10px;
  padding-right: 10px;
}
</style>