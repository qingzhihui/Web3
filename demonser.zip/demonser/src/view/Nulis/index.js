import React, { useEffect, useState, useRef } from "react";
import "./index.scss";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import ches from "../../assets/kd.png";
import contractABI from "../../utils/abi.json";
import axios from "axios";
const contractAddress = "0xA0Bd8274c894bbD93d75BA5b47E455408c157901";

function Nulis(props) {
  const [List, setList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [iputes, setIputes] = useState("");
  const [revea, setRevealed] = useState(false);
  const [LIstshow, setLIstshow] = useState(false);
  const HeoimShow = () => {
    props.history.push("/mint");
  };
  const handiputes = (e) => {
    const { value } = e.target;
    setIputes(value);
  };
  const handipuButton = async (id) => {
    const { addr } = props.history.location.state;
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const nftContract = new ethers.Contract(
      contractAddress,
      contractABI,
      signer
    );
    const nftShu = await nftContract.transferFrom(addr, iputes, id, {
      value: ethers.utils.parseEther("0.002"),
    });
    await nftShu.wait();
    window.location.reload();
  };
  useEffect(() => {
    const address = props.location.state.addr;
    console.log(props);
    const Helise = async () => {
      if (typeof window.ethereum !== "undefined") {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const nftContract = new ethers.Contract(
          contractAddress,
          contractABI,
          signer
        );
        const nftShu = await nftContract.ownedNFTAmount(address);
        const NFTAmount = parseFloat(ethers.utils.formatEther(nftShu));
        const mount = new BigNumber(NFTAmount)
          .times(new BigNumber(10).pow(18))
          .toString();
        if (parseInt(mount) !== 0) {
          const alInst = await nftContract.tokenListOfOwner(address);
          const sbun = alInst.toString();
          const orgStr = sbun.split(",");
          var anList = [];
          orgStr.map(async (item) => {
            const tokenURI = await nftContract.tokenURI(parseInt(item));
            const revealed = await nftContract.revealed();

            const neft = await nftContract.nfts(parseInt(item));
            var url = "";
            if (revealed == false) {
              url = `https://gateway.pinata.cloud/ipfs/${tokenURI.substr(
                7,
                53
              )}`;
            } else {
              url = `https://gateway.pinata.cloud/ipfs/${tokenURI.substr(
                7,
                55
              )}`;
              setRevealed(true);
            }
            axios
              .get(url)
              .then(function (response) {
                orgStr.map((msg) => {
                  if (msg == neft.tokenId) {
                    response.data["id"] = neft.tokenId.toString();
                  }
                });
                anList.push(response.data);
                sessionStorage.setItem("Liat", JSON.stringify(anList));
              })
              .catch(function (error) {
                console.log(error);
              });
          });
          const Lisn = JSON.parse(sessionStorage.getItem("Liat"));
          if (Lisn === null) {
            setList([]);
            setLIstshow(false);
          } else {
            setList(Lisn);
            setTimeout(() => {
              setLIstshow(true);
            }, 3000);
          }
        }
      } else {
        console.log("Please install metamask.");
      }
    };
    Helise();

    window.ethereum.on("accountsChanged", async function (accounts) {
      Helise();
    });
  }, []);
  return (
    <div className="Liseios">
      {isLoading ? <div></div> : ""}
      {LIstshow ? (
        <div className="slinsdiem">
          {List.map((item, index) => (
            <div className="snkeli" key={index}>
              <div className="lsiebspei">
                <div className="lsiebspimg">
                  <img
                    src={
                      "https://gateway.pinata.cloud/ipfs/" +
                      item.image.substr(7, 53)
                    }
                    alt=""
                  />
                </div>
                <div className="lsietitle">
                  <span>{item.name}</span>
                </div>
                <div className="lsiemiaos">
                  <span>{item.description}</span>
                </div>
                {revea ? (
                  <div className="pezhnro">
                    {item.attributes.map((msg, index) => (
                      <div key={index} className="cnsusjsdd">
                        <div className="cnsus1">
                          <span className="tnbaluies">{msg.trait_type}</span>：
                        </div>
                        <div  className="cnsus2">
                          <span>{msg.value}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  ""
                )}
                <div className="lisbutone">
                  <input
                    onChange={handiputes}
                    placeholder="please enter recipient"
                  />
                  <button
                    onClick={() => {
                      handipuButton(item.id);
                    }}
                  >
                    transfer
                  </button>
                  <button>
                    <a
                      href={
                        "https://testnets.opensea.io/assets/rinkeby/0xa0bd8274c894bbd93d75ba5b47e455408c157901/" +
                        item.id
                      }
                      target="_blank"
                    >
                      opensea
                    </a>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        ""
      )}
      <div className="kunfangh">
        <div
          className="kunfanlog"
          onClick={() => {
            HeoimShow();
          }}
        ></div>
      </div>
    </div>
  );
}
export default Nulis;
