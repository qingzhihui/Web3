const myCanvas = document.getElementById("main_canvas") as HTMLCanvasElement;

const myCanvas2 = <HTMLCanvasElement>document.getElementById("main_canvas");

// unknown 的意思是并不知道是什么类型
const x = ("hello" as unknown) as number;
