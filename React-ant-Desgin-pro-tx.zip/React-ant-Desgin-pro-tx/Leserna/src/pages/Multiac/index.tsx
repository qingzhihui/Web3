function Index() {
  return <div>1</div>;
}

export default Index;
