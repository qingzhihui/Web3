import './index.scss'
import { useTranslation } from "react-i18next";
import React from 'react'

export default function InputError(props:any) {
    const { t } = useTranslation();
    return (
        <div className='error-title'>{`${t(props.title)}`}</div>
    )
}
