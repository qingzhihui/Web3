<template><div>你好</div></template>

<script setup lang="ts">

</script>

<style>
html {
    filter: grayscale(1);
    /* filter:hue-rotate(45deg) */
}
</style>
