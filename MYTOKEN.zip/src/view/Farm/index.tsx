import React, { useEffect, useState } from "react";
import LogeImge from "../../assets/image/loien.png";
import more from "../../assets/image/Vector.png";
import { useTranslation } from "react-i18next";
import { Slider, Skeleton, Button } from "antd";
import { CaretDownOutlined, CaretUpOutlined } from "@ant-design/icons";
import { INVITE_ADDR, INVITE_ABI } from "../../config/abi/inviteContract";
import { FARM_ADDR, FARM_ABI } from "../../config/abi/farmContract";
import "./index.scss";
import { Modal } from "antd";
import PoolToken from "../../config/Pool.json";
import {
  DigitalConversion,
  InstancedContract,
  ObtainAddress,
  TokenNameDecimals,
} from "../../hooks/config";
import { PAIR_ABI } from "../../config/abi/pancakepair";
declare const window: Window & { ethereum: any };
import { ethers } from "ethers";
import type { SliderMarks } from "antd/es/slider";
import {
  balanceOfConter,
  getUserTotalPartnerRewardConter,
  pendingMintingRewardConter,
  pendingDividendRewardConter,
  tokenConter,
  userInfoConter,
  allowanceValConter,
  wagmiState,
  DleiserPoers,
} from "../../hooks/farm";
const MINUTE_MS = 5000;

const Farm = () => {
  const { t } = useTranslation();
  const [isDeatilopen, setisDeatilopen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const [WalletAccount, setWalletAccount] = useState("");
  const [showList, setShowList] = useState(PoolToken);
  const [unShow, setunShow] = useState(false);
  const [newValue, setNewValue] = useState(1);
  const [awardReward, setAwardReward] = useState({
    award: "",
    reward: "",
  });
  const [loadings, setLoadings] = useState<boolean[]>([]);
  const [loadingState, setLoadingState] = useState(true);
  const setisDeatilopenOnclick = () => {
    setisDeatilopen(!isDeatilopen);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const BineDeatile = async () => {
    const Contract: any = InstancedContract(INVITE_ADDR, INVITE_ABI);
    const UserAddress = await ObtainAddress();
    const getUser = await Contract.getUserReferrer(UserAddress?.address);
    if (getUser === "0x0000000000000000000000000000000000000000") {
      setIsModalOpen(true);
    } else {
      setIsModalOpen(false);
    }
  };
  const bindOnClick = async (index: number) => {
    const Contract: any = InstancedContract(INVITE_ADDR, INVITE_ABI);
    const bind = await Contract.bind(inputValue);
    enterLoading(index);
    await bind.wait();
    turnLoading(index);
    setIsModalOpen(false);
  };
  const inputValueOnChange = (e: any) => {
    setInputValue(e.target.value);
  };
  const PoolDataReward = async () => {
    const LIbse: any = showList;
    showList.map(async (item: any) => {
      const UserAddress = await ObtainAddress();
      Promise.all([
        balanceOfConter(item.code, UserAddress?.address),
        userInfoConter(item.pid, UserAddress?.address, item.code),
        tokenConter(
          item.token1,
          item.token2,
          item.code,
          item.pid,
          UserAddress?.address
        ),
        pendingMintingRewardConter(item.pid, UserAddress?.address),
        getUserTotalPartnerRewardConter(UserAddress?.address),
        pendingDividendRewardConter(item.pid, UserAddress?.address),
        allowanceValConter(item.code, FARM_ADDR),
      ]).then((res) => {
        LIbse[item.pid].balance = res[0].balanceOf;
        LIbse[item.pid].balanceShow = res[0].balanceShow;
        LIbse[item.pid].StakedLP = res[1].StakedLP;
        LIbse[item.pid].StakedLPShow = res[1].StakedLPShow;
        LIbse[item.pid].WeTalk1 = res[2].lPdataToken1;
        LIbse[item.pid].WeTalk2 = res[2].lPdataToken2;
        LIbse[item.pid].drawValu = res[3].drawValu;
        LIbse[item.pid].dividend = res[5].pendingDividendReward;
        LIbse[item.pid].show = res[6].show;
        setAwardReward((stateValue) => {
          return {
            ...stateValue,
            award: res[4].getUserTotalNodeReward,
            reward: res[4].getUserTotalPartnerReward,
          };
        });
      });
    });
    setShowList((state: any) => {
      return (state = LIbse);
    });
    setLoadingState((state: boolean) => {
      return (state = false);
    });
  };
  const onCInput = (e: any, id: any) => {
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = e.target.value;
        setInputValue(e.target.value);
        const Shui = e.target.value || 0;
        if (Shui === 0) {
          setunShow(false);
        } else if (item.inputValue === 0) {
          setunShow(false);
        } else {
          setunShow(true);
        }
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };
  const enterLoading = (index: number) => {
    setLoadings((prevLoadings) => {
      const newLoadings = [...prevLoadings];
      newLoadings[index] = true;
      return newLoadings;
    });
  };
  const turnLoading = (index: number) => {
    setLoadings((prevLoadings) => {
      const newLoadings = [...prevLoadings];
      newLoadings[index] = false;
      return newLoadings;
    });
  };
  const BinCkmax = async (bianes: any, id: any) => {
    setInputValue(bianes);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = bianes;
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
    setunShow(true);
  };
  const deposit = async (pid: any, index: number) => {
    const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
    const rewardToken = await farmContract.rewardToken();
    const RewardData = await TokenNameDecimals(rewardToken);
    const depositValue = DigitalConversion(
      showList[pid].inputValue,
      RewardData.decimals
    );
    const deposit = await farmContract.deposit(pid, depositValue);
    enterLoading(index);
    await deposit.wait();
    turnLoading(index);
    const LIbse: any = showList;
    showList.map(async (item: any) => {
      LIbse[pid].inputValue = "";
    });
    setShowList((state: any) => {
      return (state = LIbse);
    });
  };
  const approve = async (code: any, pid: any, index: number) => {
    console.log(code);
    const ApproveContract: any = InstancedContract(code, PAIR_ABI);
    const apperov = await ApproveContract.approve(
      FARM_ADDR,
      ethers.constants.MaxUint256
    );
    enterLoading(index);
    await apperov.wait();
    turnLoading(index);
    const LIbse: any = showList;
    showList.map(async (item: any) => {
      LIbse[pid].show = true;
    });
    setShowList((state: any) => {
      return (state = LIbse);
    });
  };
  const ClaimOnclick = async (pid: any, index: number) => {
    const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
    const claim = await farmContract.claim(pid);
    enterLoading(index);
    await claim.wait();
    turnLoading(index);
  };
  const WithdrawOnclick = async (pid: any, index: number) => {
    const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
    const withdraw = await farmContract.withdraw(pid);
    enterLoading(index);
    await withdraw.wait();
    turnLoading(index);
  };
  const onChange = (newValue: number) => {
    setNewValue(newValue);
  };
  const marks: SliderMarks = {
    0: {
      style: {
        color: "#fbc29d",
      },
      label: <strong>0</strong>,
    },
    25: {
      style: {
        color: "#e342aa",
      },
      label: <strong>25</strong>,
    },
    50: {
      style: {
        color: "#b950e4",
      },
      label: <strong>50</strong>,
    },
    75: {
      style: {
        color: "#ffffff",
      },
      label: <strong>75</strong>,
    },
    100: {
      style: {
        color: "#ffffff",
      },
      label: <strong>100</strong>,
    },
  };
  const claimPartnerRewardOnClick = async (index: number) => {
    const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
    const claimPartnerReward = await farmContract.claimPartnerReward();
    enterLoading(index);
    await claimPartnerReward.wait();
    turnLoading(index);
  };
  const claimNodeRewardOnclick = async (index: number) => {
    const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
    const claimNodeReward = await farmContract.claimNodeReward();
    enterLoading(index);
    await claimNodeReward.wait();
    turnLoading(index);
  };
  useEffect(() => {
    (window as any).ethereum.on(
      "accountsChanged",
      async function (accounts: any) {
        localStorage.setItem("Meat_addr", accounts[0]);
        setWalletAccount(accounts[0]);
        if (wagmiState()) {
          BineDeatile();
          PoolDataReward();
        } else {
          const data = DleiserPoers();
          setShowList((state: any) => {
            return (state = data);
          });
        }
      }
    );
  }, [WalletAccount]);
  useEffect(() => {
    if (wagmiState()) {
      BineDeatile();
      PoolDataReward();
    } else {
      setTimeout(() => {
        setLoadingState((state: boolean) => {
          return (state = false);
        });
      }, 5000);
    }
    const interval = setInterval(async () => {
      if (wagmiState()) {
        PoolDataReward();
      } else {
        const data = DleiserPoers();
        setShowList((state: any) => {
          return (state = data);
        });
      }
    }, MINUTE_MS);
    return () => clearInterval(interval);
  }, []);
  return (
    <div className="Farm">
      <div className="FarmComponent">
        <div className="FarmComponentFunsei">
          <div className="FarmComponentBuien">
            <div className="FarmComponentItemTitle">
              <div className="FarmComTitle"> {`${t("Reward")}`}</div>
              <div className="FarmComButton">
                <div className="FarmComButtonText">
                  <div className="FarmComButtonTextTIUle">
                    Partner's award：
                  </div>
                  <div className="FarmComButtonTextNro">
                    {awardReward.award === '0' ? ' 0.0': awardReward.award}
                  </div>
                  <Button
                    onClick={() => {
                      claimPartnerRewardOnClick(1);
                    }}
                    type="primary"
                    loading={loadings[1]}
                  >
                    领取
                  </Button>
                </div>
                <div className="FarmComButtonText">
                  <div className="FarmComButtonTextTIUle">Nodal reward：</div>
                  <div className="FarmComButtonTextNro">
                    {awardReward.reward  === '0' ? ' 0.0': awardReward.reward}
                  </div>
                  <Button
                    onClick={() => {
                      claimNodeRewardOnclick(2);
                    }}
                    type="primary"
                    loading={loadings[2]}
                  >
                    领取
                  </Button>
                </div>
              </div>
            </div>
            <div className="FarmComponentItemTDlie">
              <div className="Tbienpser">
                {showList.map((item: any, index: number) => (
                  <div className="FarmComponenTDieItem" key={index}>
                    <div className="FarmComponenTDieItemTitle">
                      <div className="TDieItemTitleLength">
                        <div className="FarmComponenTDieItemTitlkeIMge">
                          <img src={LogeImge} alt="" />
                        </div>
                        <div className="FarmComponenTDieItemTitlkevalue">
                          We Talk-USDT
                        </div>
                      </div>
                      <div className="TDieItemTitleRenthu">
                        {isDeatilopen ? (
                          <div className="TDieItemTitleRenthuINfor">
                            <div className="INforValue">
                              <a target="_blank" href={""}>
                                {`${t("Get CAKE-BNB LP")}`}
                              </a>
                              <img src={more} alt="" />
                            </div>
                            <div className="INforValue">
                              {" "}
                              <a target="_blank" href={""}>
                                {`${t("View Contract")}`}
                              </a>
                              <img src={more} alt="" />
                            </div>
                            <div className="INforValue">
                              <a target="_blank" href={""}>
                                {`${t("See Pair Info")}`}
                              </a>
                              <img src={more} alt="" />
                            </div>
                          </div>
                        ) : (
                          ""
                        )}
                        <div className="TDieItemTitleRenthuButon">
                          {isDeatilopen ? (
                            <button
                              onClick={() => {
                                setisDeatilopenOnclick();
                              }}
                            >
                              <span>{`${t("Hide")}`}</span>
                              <CaretUpOutlined style={{ fontSize: 14 }} />
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                setisDeatilopenOnclick();
                              }}
                            >
                              <span>{`${t("Details")}`}</span>
                              <CaretDownOutlined style={{ fontSize: 14 }} />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                    {isDeatilopen ? (
                      <div className="FarmComponenTDieItemBrole">
                        {loadingState && item.balanceShow !== "" ? (
                          <div className="TDieItemBrolelent">
                            <div className="FarmComponenTDieItemValue">
                              <Skeleton
                                paragraph={{ rows: 4, width: "100%" }}
                                active
                                loading={loadingState}
                              />
                            </div>
                          </div>
                        ) : (
                          <div className="TDieItemBrolelent">
                            <div className="FarmComponenTDieItemValue">
                              <div className="DieItemValueLengt">
                                {`${t("LP Balance")}`}:{" "}
                              </div>
                              <div className="DieItemValueRenth">
                                {item.balanceShow === "0.0"
                                  ? "0.0"
                                  : item.balanceShow}
                              </div>
                            </div>
                            <div className="FarmComponenTDieItemValue">
                              <div className="DieItemValueLengt">
                                {`${t("Staked LP")}`}:{" "}
                              </div>
                              <div className="DieItemValueRenth">
                                {item.StakedLPShow === "0.0" || ""
                                  ? "0.0"
                                  : item.StakedLPShow}
                              </div>
                            </div>
                            <div className="FarmComponenTDieItemValue">
                              <div className="DieItemValueLengt">
                                {`${t(" Pooled")}`} {item.name.split("/")[0]}:
                              </div>
                              <div className="DieItemValueRenth">
                                {item.WeTalk1 === "0.0" || "0"
                                  ? "0.0"
                                  : item.WeTalk1}
                              </div>
                            </div>
                            <div className="FarmComponenTDieItemValue">
                              <div className="DieItemValueLengt">
                                {`${t("Pooled")}`} {item.name.split("/")[1]}:
                              </div>
                              <div className="DieItemValueRenth">
                                {item.WeTalk2 === "0.0" || "0"
                                  ? "0.0"
                                  : item.WeTalk2}
                              </div>
                            </div>
                            <div className="FarmComponenTDieItemValue">
                              <div className="DieItemValueLengt">Mint:</div>
                              <div className="DieItemValueRenth">
                                {item.drawValu === "0.0" || "0"
                                  ? "0.0"
                                  : item.drawValu}
                              </div>
                            </div>
                            <div className="FarmComponenTDieItemValue">
                              <div className="DieItemValueLengt">Dividend:</div>
                              <div className="DieItemValueRenth">
                                {item.dividend === "0.0" || "0"
                                  ? "0.0"
                                  : item.dividend}
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="TDieItemBroleZhne">
                          <div className="DiescProgress">
                            <div className="SliderITem">
                              <Slider
                                step={null}
                                marks={marks}
                                defaultValue={30}
                                onChange={onChange}
                              />
                            </div>
                          </div>
                          <div className="FarmBuisenInput">
                            <input
                              type="text"
                              value={item.inputValue}
                              onChange={(e) => onCInput(e, item.id)}
                              placeholder="Please enter the quantity"
                            />
                            <button
                              onClick={() => {
                                BinCkmax(item.balanceShow, item.id);
                              }}
                            >
                              MAX
                            </button>
                          </div>
                        </div>
                        <div className="TDieItemBroleRent">
                          <div className="FarmBuisenBtuon">
                            <div className="FarmBuisenBtuonItem">
                              <Button onClick={() => {}}>
                                {`${t("Details")}`}
                              </Button>
                            </div>
                            <div className="FarmBuisenBtuonItem">
                              <>
                                {item.show === false ? (
                                  <Button
                                    onClick={() => {
                                      approve(item.code, item.pid, 3);
                                    }}
                                    type="primary"
                                    loading={loadings[3]}
                                  >{`${t("Approve")}`}</Button>
                                ) : (
                                  <>
                                    {item.inputValue !== "" && unShow ? (
                                      <Button
                                        onClick={() => {
                                          deposit(item.pid, 4);
                                        }}
                                        type="primary"
                                        loading={loadings[4]}
                                      >
                                        {`${t("Deposit")}`}
                                      </Button>
                                    ) : (
                                      <div className="nuBut">
                                        <button disabled>
                                          {`${t("Deposit")}`}
                                        </button>
                                      </div>
                                    )}
                                  </>
                                )}
                              </>
                            </div>
                            <div className="FarmBuisenBtuonItem">
                              <Button
                                onClick={() => {
                                  ClaimOnclick(item.pid, 5);
                                }}
                                type="primary"
                                loading={loadings[5]}
                              >{`${t("Claim")}`}</Button>
                            </div>
                            <div className="FarmBuisenBtuonItem">
                              <Button
                                onClick={() => {
                                  WithdrawOnclick(item.pid, 6);
                                }}
                                type="primary"
                                loading={loadings[6]}
                              >{`${t("Withdraw")}`}</Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal
        title="Bind"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        centered={true}
        maskClosable={false}
        footer={null}
      >
        <div className="BindTitle">绑定邀请人地址：</div>
        <div className="Nurilien">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => {
              inputValueOnChange(e);
            }}
            placeholder="请输入邀请人地址"
          />{" "}
          <Button
            onClick={() => {
              bindOnClick(0);
            }}
            type="primary"
            loading={loadings[0]}
          >
            绑定
          </Button>
        </div>
      </Modal>
    </div>
  );
};

export default Farm;
function pendingDividendReward(pid: any, address: string | undefined): any {
  throw new Error("Function not implemented.");
}
