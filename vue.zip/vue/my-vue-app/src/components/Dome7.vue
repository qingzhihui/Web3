<template><div>你好</div></template>

<script setup lang="ts">

// 数组去重的本质
console.log(Object.is(NaN, NaN));
// 两个东西是不是相同需要看情况看场景，你脱离了情况脱离了场景去讨论相不相同没有意义


// 方法1: 使用ES6的Set和展开运算符去重 (严格相等完全没有考虑业务需求)
function uniqueArray(arr) {
    return [...new Set(arr)];
}

// 方法2：不使用标准库，完全手写去重过程
function uniqueArray2(arr) {
    var result: any = [];
    for (var i = 0; i < arr.length; i++) {
        var isFind = false;
        for (var j = 0; j < result.length; j++) {
            if (result[j] === arr[i]) {
                isFind = true;
                break;
            }
        }
        if (!isFind) {
            result.push(arr[j]);
        }
    }
    return result
}


// 字节面试题
// 数组去重
// 原始值使用严格模式等比较
// 对象值递归比较所有属性，属性数量和属性名称必须一致
// 数组中的对象均为plain object


// 如何用以下代码满足字节的面试要求
function uniqueArray3(arr) {
    var result: any = [];
    for (var i = 0; i < arr.length; i++) {
        var isFind = false;
        for (var j = 0; j < result.length; j++) {
            if (result[j] === arr[i]) {
                isFind = true;
                break;
            }
        }
        if (!isFind) {
            result.push(arr[j]);
        }
    }
    return result
}
function equals(v1: any, v2: any) {

}
</script>

<style></style>
