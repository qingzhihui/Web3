<template>
  <button @click="click" id="counter">点击</button>
  <input type="text" v-model="inputValue" @input="handleInput">
</template>
<script lang="ts">
import { ref } from 'vue'
import { debounce } from 'lodash-es'
export default {

  setup() {
    const count = ref(0)
    const inputValue = ref("")
    return {
      count,
      inputValue
    }
  },
  created() {
    this.debouncedHandleInput = debounce(this.handleInput, 1500);
  },
  methods: {
    click: debounce(function () {
      console.log('123');
    }, 500),
    handleInput() {
      // 处理输入事件的逻辑
      console.log('123');
      
    }
  },
  unmounted() {
    // 最好是在组件卸载时
    // 清除掉防抖计时器
    this.debouncedClick.cancel()
  }

}
</script>
<style scoped></style>