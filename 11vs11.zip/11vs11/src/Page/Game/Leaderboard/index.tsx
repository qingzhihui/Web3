export default function Leaderboard() {
  return (
    <>
      <div style={{
        marginTop: "25px",
        display: "flex",
        justifyContent: "center"
      }}>
        <button className="common-btn">COMMING SOON</button>
      </div>
      <div id="LeaderBoard">
      </div>
    </>
  )
}