<script setup lang="ts">
import { ref } from 'vue'
interface Props {
  foo: string
  bar?: number
}
const props = defineProps<Props>();

</script>

<template>

  <h1>{{ props.foo }},{{ props.bar }}</h1>
</template>

<style scoped>

</style>
