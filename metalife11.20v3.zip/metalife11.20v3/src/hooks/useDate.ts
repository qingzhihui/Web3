import React, { useEffect, useState } from "react";
import Web3 from "web3";
import { Meta, Pair } from "../redux/api/api";
import toolNumber from "../constants/sluine.js";
import Jointnode from "../redux/PondJson/Jointnode.json";
declare const window: Window & { ethereum: any };

let JointData: any = Jointnode;
let metaContract: any;

const Orderrecord = async () => {
  let provider = window.ethereum;
  const web3 = new Web3(provider);
  const Poser: any = Jointnode;
  metaContract = new web3.eth.Contract(Meta.Meta_ABI, Meta.Meta_ADDRESS);
  JointData.map(async (item: any, index: any) => {
    const pairContract = new web3.eth.Contract(Pair.PAIR_ABI, item.code);
    var accounts = await web3.eth.getAccounts();
    const allowance = await pairContract.methods
      .allowance(accounts[0], Meta.Meta_ADDRESS)
      .call();
    const decimal = await pairContract.methods.decimals().call();
    const pairBalance = await pairContract.methods
      .balanceOf(accounts[0])
      .call();
    const realBalance = pairBalance / 10 ** decimal;
    const token0 = await pairContract.methods.token0().call();
    const token1 = await pairContract.methods.token1().call();
    const token0Contract = new web3.eth.Contract(Pair.wben_ABI, token0);
    const token1Contract = new web3.eth.Contract(Pair.wben_ABI, token1);
    const depositAmount = await metaContract.methods
      .depositAmount(item.pid, accounts[0])
      .call();
    const pendingMiningReward = await metaContract.methods
      .pendingMiningReward(item.pid, accounts[0])
      .call();
    const pendingDividendReward = await metaContract.methods
      .pendingDividendReward(item.pid, accounts[0])
      .call();
    const getTotalRedeemableLPAmount = await metaContract.methods
      .getTotalRedeemableLPAmount(item.pid, accounts[0])
      .call();
    const totalSupply = await pairContract.methods.totalSupply().call();
    const token0Total = await token0Contract.methods
      .balanceOf(item.code)
      .call();
    const decimals0 = await token0Contract.methods.decimals().call();
    const token1Total = await token1Contract.methods
      .balanceOf(item.code)
      .call();
    const decimals1 = await token1Contract.methods.decimals().call();
    const pldate = web3.utils.fromWei(depositAmount.toString(), "ether");
    let holdRatio =
      Number(depositAmount.toString()) / (Number(totalSupply) - 1000);
    let userToken0 = Number(token0Total) * holdRatio;
    let userToken0show = userToken0 / 10 ** decimals0;
    let userToken1 = Number(token1Total) * holdRatio;
    let userToken1show = userToken1 / 10 ** decimals1;
    const token0toolNumber = toolNumber(userToken0show);
    const token1toolNumber = toolNumber(userToken1show);
    Poser[index].allowa = allowance.toString();
    Poser[index].Maxnu = pairBalance.toString();
    Poser[index].balance = realBalance.toString();
    Poser[index].Luerbse = pairBalance.toString();
    Poser[index].lPdata = Number(pldate.toString()).toFixed(7);
    Poser[index].meatdate = token0toolNumber.substring(0, 13);
    Poser[index].usdtdate = token1toolNumber.substring(0, 13);
    Poser[index].pendingMining = web3.utils.fromWei(
      pendingMiningReward.toString(),
      "ether"
    );
    Poser[index].pendingDividend = web3.utils.fromWei(
      pendingDividendReward.toString(),
      "ether"
    );
    Poser[index].redeemableLPAmount = web3.utils.fromWei(
      getTotalRedeemableLPAmount.toString(),
      "ether"
    );
  });
  return Poser;
};

export { Orderrecord };
