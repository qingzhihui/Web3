import React from 'react';

function Index() {
  return <div style={{ color: 'red' }}>123</div>;
}

export default Index;
