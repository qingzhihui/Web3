<template>
  <div>
    <p>Has published books:</p>
    <!-- <span>{{ author.books.length > 0 ? 'Yes' : 'No' }}</span> -->
    <span>{{ publishedBooksMessage }}</span>
    <p>{{ calculateBooksMessage() }}</p>
  </div>
</template>
<script lang="ts">
import { ref, reactive } from 'vue'
export default {
  setup() {
    let author = reactive({
      name: 'John Doe',
      books: [
        'Vue 2 - Advanced Guide',
        'Vue 3 - Basic Guide',
        'Vue 4 - The Mystery'
      ]
    });
    let firstName = ref("");
    let lastName = ref("");
    return {
      author,
      firstName,
      lastName
    }
  },
  computed: {
    publishedBooksMessage() {
      // `this` 指向当前组件实例
      return this.author.books.length > 0 ? 'Yes' : 'No'
    },
    now() {
      return Date.now()
    },
    fullName: {
      get() {
        return this.firstName + ' ' + this.lastName
      },
      set(newValue: any) {
        // 注意：我们这里使用的是解构赋值语法
        [this.firstName, this.lastName] = newValue.split(' ')
      }
    }
  },
  methods: {
    calculateBooksMessage() {
      return this.author.books.length > 0 ? 'Yes' : 'No'
    }
  }

}
</script>
<style scoped></style>