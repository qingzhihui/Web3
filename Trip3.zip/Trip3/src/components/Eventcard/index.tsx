import React from 'react'
import './index.scss'

export default function index() {
  return (
    <div className='eventcard'>
      <img src={require('@/assets/image/Rectangle48.png')} alt="" />
      <div className='cardmiddle'>
        <div className='middone'>
          <img src={require('@/assets/image/tablerbrand.png')} alt="" />
          <div className='addres'>departure city</div>
          <div className='addrekk'>Bei jing</div>
        </div>
        <div className='middtwo'>
          <img src={require('@/assets/image/tablermap.png')} alt="" />
          <div className='addres'>arrival city</div>
          <div className='addrekk'>Paris</div>
        </div>
        <div className='middthree'>
          <img src={require('@/assets/image/ph.png')} alt="" />
          <div className='date'>Friday, December 9, 2022</div>
        </div>
      </div>
      <div className='cardright'>
        <div className='cardtiitle'>
          <img src={require('@/assets/image/IMAGE8.png')} alt="" />
          Air China
        </div>
        <div className='cardmoney'>Minimum $3,500</div>
        <button>BUY AIR TICKETS</button>
      </div>
    </div>
  )
}
