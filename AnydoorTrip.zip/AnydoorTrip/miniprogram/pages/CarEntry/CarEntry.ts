import api from '../../config/axios'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: false,
    CardNumer: "",
    CardYear: "",
    cardImage: "https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/pluse.png",
    CarData: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
   this.creditCardShow();
  },
  creditCardShow(){
    api._get("user/credit_card").then(res => {
      this.setData({
        CarData: res.data
      })
    }).catch(event => {
      console.log(event);
    })
  },
  DateItemonCliek(event: any) {
    var pages = getCurrentPages();
    var beforePage = pages[pages.length - 2];
    const Props: any = { ...event.currentTarget.dataset.item, Image: this.data.cardImage }
    wx.navigateBack({
      delta: -1,
      success: function () {
        beforePage.CaerFeuineProps(Props);
      }
    })
  },
  CardNumerInput(event: any) {
    this.setData({
      CardNumer: event.detail.value
    })
  },
  CardYearInput(event: any) {
    this.setData({
      CardYear: event.detail.value
    })
  },
  onClose() {
    this.setData({ show: false });
  },
  addDetailsPser() {
    this.setData({
      show: true
    })
  },
  addCarEntry() {
    api._post("user/credit_card", {
      card_id: this.data.CardNumer,
      expire: this.data.CardYear
    }).then(res => {
      this.setData({
        show: false
      })
      this.creditCardShow();
    }).catch(event => {
      console.log(event);
    })
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})