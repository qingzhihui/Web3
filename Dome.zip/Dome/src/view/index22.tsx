import React, { useState, useCallback, MouseEvent } from "react";

function App() {
  const [count, setCount] = useState(0);

  // 使用 useCallback() 缓存的回调函数(显式指定回调函数的类型)
  const handleClick = useCallback(
    (event: MouseEvent<HTMLButtonElement>) => {
      setCount(count + 1);
    },
    [count]
  );

  return (
    <div>
      <h1>React useCallback() Example</h1>
      <p>Count: {count}</p>
      <button onClick={handleClick}>Click me</button>
    </div>
  );
}

export default App;
