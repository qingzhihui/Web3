import { component$, useTask$, useStore, $ } from "@builder.io/qwik";
// useSignal
interface ItemProps {
  handleFunction: any;
}

export const Button = component$((props: ItemProps) => {
  // const message = useSignal("Signal None");
  const state = useStore({
    message: "State None",
    color: "No color",
  });

  // 为什么网页有打印，控制台没有 (控制台是服务器，网页是客户端)，所以这告诉你使用任务任何运行，他首先从服务器运行
  // 因此他首先从服务器呈现因此他从服务器呈现，客户让我在这里向你展示一些非常有趣的东西，我们去网络， 当你点击按钮
  // 的时候他重新加载了那个按钮组件，这就是快速js的秘密来源，他只在我需要的时候加载我需要的东西
  useTask$(({ track }) => {
    track(state);
    // console.log(message.value);
    console.log(state.message);
    // const timout = setTimeout(() => {
    //   console.log(message.value);
    // }, 5000);
    // return clearTimeout(timout);
  });

  const handleClick = $(() => {
    state.message = "Button clicked";
    props.handleFunction()
  });

  return (
    // () =>(state.message = "I was clicked")
    <button
      onClick$={handleClick}
      class="bg-sky-500 py-2 px-4 rounded-sm text-white hover:bg-sky-400"
    >
      Clike Me
    </button>
  );
});
