import Homeico from "../assets/image/Homeico.png";
import HomeicoBox from "../assets/image/HomicoBox.png";
import Minicon from "../assets/image/minicon.png";
import MiniconBox from "../assets/image/miniconBox.png";
import Messageicon from "../assets/image/message.png";
import MessageiconBox from "../assets/image/messageBox.png";
import Gogaoicon from "../assets/image/gogao.png";
import GogaoiconBox from "../assets/image/gogaoBox.png";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import { WBENJson } from "../config/abi/wbenjson.js";
declare const window: Window & { ethereum: any };

export interface RouterProps {
  key?: number;
  title?: string;
  url?: string;
}
const RouterItem: RouterProps[] = [
  {
    key: 0,
    title: "HOME",
    url: "/",
  },
  {
    key: 1,
    title: "FARM",
    url: "/Farm",
  },
  {
    key: 2,
    title: "INVITATION",
    url: "/Invit",
  },
  {
    key: 3,
    title: "ANNOUN",
    url: "/Center",
  },
];
const onScroll = () => {
  let elem: any = document.getElementById("longTable");
  var myElement: any = document.querySelector("#demo");
  if (elem.scrollTop >= 100) {
    myElement.style.background = "rgba(255, 255, 255, 0.08)";
    myElement.style.backdropFilter = "blur(10px)";
    myElement.style.borderRadius = "0px 0px 10px 10px";
  } else {
    myElement.style.backgroundColor = "transparent";
    myElement.style.backdropFilter = "none";
    myElement.style.borderRadius = "0px";
  }
};
const MenuList = [
  {
    key: 0,
    url: "/",
    title: "HOME",
    image: Homeico,
    imgurl: HomeicoBox,
  },

  {
    key: 1,
    url: "/Farm",
    title: "FARM",
    image: Minicon,
    imgurl: MiniconBox,
  },
  {
    key: 2,
    url: "/Invit",
    title: "INVITATION",
    image: Messageicon,
    imgurl: MessageiconBox,
  },
  {
    key: 3,
    url: "/Center",
    title: "ANNOUN",
    image: Gogaoicon,
    imgurl: GogaoiconBox,
  },
];

const allowance = async (tokenAddress: any, lockAddress: any) => {
  const { address } = (await ObtainAddress()) as any;
  const allowance = await (
    InstancedContract(tokenAddress, WBENJson) as any
  ).allowance(address, lockAddress);
  return allowance;
};

const InstancedContract = (address: any, abi: any) => {
  if (window.ethereum) {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const Contract = new ethers.Contract(address, abi, signer);
    return Contract;
  } else {
    return;
  }
};

const DigitalConversion = (parameter: any, numerical: any) => {
  const DigitalValue = new BigNumber(parameter)
    .times(new BigNumber(10).pow(numerical))
    .toFixed();
  return DigitalValue;
};

const ObtainAddress = async () => {
  if (window.ethereum) {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const balance = await signer.getBalance();
    return {
      address,
      balance,
    };
  } else {
    return;
  }
};

const TokenNameDecimals = async (addresNUi: any) => {
  const { address } = (await ObtainAddress()) as any;
  const name = await (InstancedContract(addresNUi, WBENJson) as any).name();
  const symbol = await (InstancedContract(addresNUi, WBENJson) as any).symbol();
  const decimals = await (
    InstancedContract(addresNUi, WBENJson) as any
  ).decimals();
  const balanceOfValue = await (
    InstancedContract(addresNUi, WBENJson) as any
  ).balanceOf(address);
  const balanceOf = ethers.utils.formatUnits(balanceOfValue.toString());
  return {
    name,
    symbol,
    decimals,
    balanceOf,
  };
};

const FormatUnitsConver = (amount: any, decimals: any) => {
  const FormatUnitsValue = ethers.utils.formatUnits(amount, decimals);
  return FormatUnitsValue;
};

export {
  RouterItem,
  MenuList,
  onScroll,
  allowance,
  InstancedContract,
  DigitalConversion,
  ObtainAddress,
  TokenNameDecimals,
  FormatUnitsConver,
};
