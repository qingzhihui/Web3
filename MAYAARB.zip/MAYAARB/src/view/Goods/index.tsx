import React from 'react'

const Goods = () => {
  return (
    <div>Goods</div>
  )
}

export default Goods