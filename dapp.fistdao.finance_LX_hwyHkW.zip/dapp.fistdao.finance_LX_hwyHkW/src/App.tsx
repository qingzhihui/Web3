import React, { useEffect, useState, useRef } from "react";
import IndexRouter from "./router/indexRouter";
import PageRouter from "./router/pageRouter";
import Network from "./components/Network";
import "./App.css";
const BNB = "0x38";
const Eoe = "0x1";
declare const window: Window & { ethereum: any };

function App() {
  const [userEnuer, setUserEnuer] = useState("");
  const [ches, setChes] = useState("");
  const onClick = (value: any) => {
    if (value == "1") {
      Luiser(BNB, value);
    } else {
      Luiser(Eoe, value);
    }
  };
  const Luiser = async (chlid: string, buiser: string) => {
    const provider = window.ethereum;
    const chainId = await provider.request({ method: "eth_chainId" });
    const binanceTestChainId = chlid;
    if (chainId !== binanceTestChainId) {
      try {
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: binanceTestChainId }],
        });
        setUserEnuer(buiser);
      } catch (error) {
        if (buiser == "1") {
          localStorage.setItem("Network", "2");
          Luiser(Eoe, buiser);
          setChes("2");
        } else {
          localStorage.setItem("Network", "1");
          Luiser(BNB, buiser);
          setChes("1");
        }
      }
    }
  };

  useEffect(() => {
    const buiser = localStorage.getItem("Network");
    if (buiser !== null && buiser !== undefined) {
      if (buiser == "1") {
        setUserEnuer(buiser);
      } else {
        setUserEnuer(buiser);
      }
    } else {
      localStorage.setItem("Network", "1");
      setUserEnuer("1");
    }
  }, []);
  return (
    <div className="App">
      {userEnuer !== "" ? (
        <>{userEnuer == "1" ? <IndexRouter /> : <PageRouter />}</>
      ) : (
        ""
      )}
      <Network click={onClick} ches={ches} />
    </div>
  );
}

export default App;
