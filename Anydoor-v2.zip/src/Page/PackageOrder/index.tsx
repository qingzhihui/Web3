import { Image, Input, Select, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { DeleteOutlined, AlignCenterOutlined } from "@ant-design/icons";

// 套餐订单界面
const PackageOrder = () => {
  interface DataType {
    key: React.Key;
    orderNumber: string; //订单号
    userNick: string; //用户昵称
    userImg: string; //用户头像
    hotelName:string // 酒店名称
    setMeal: string // 套餐
    hotelTotalPrice: string // 酒店总价格
    remarks: string //备注
    dateOfCneedheckIn:string // 需求
    deputy:string // 代理
  }
  const data: DataType[] = [
    {
      key: 1,
      orderNumber: "111654947818",
      userNick: "微信用户",
      userImg: "https://img1.baidu.com/it/u=1984993866,886139931&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1679763600&t=f96448b65970f307ebe451847a2a0315",
      hotelName: "珠海xxxx酒店",
      setMeal: "三亚文化东方酒店-3天2晚海岛暖冬·金色圣诞客服套餐",
      hotelTotalPrice:"3437.00",
      remarks: "无",
      dateOfCneedheckIn: "无",
      deputy: "IT长旅",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "订单号",
      dataIndex: "orderNumber",
      width: 120,
    },
    {
      title: "用户昵称",
      dataIndex: "userNick",
      width: 120,
    },
    {
      title: "用户头像",
      width: 80,
      render: (_, record) => (
        <Space size="middle">
          <Image width={60} height={50} src={record.userImg} />
        </Space>
      ),
    },

    {
      title: "酒店名称",
      dataIndex: "hotelName",
      width: 120,
    },
    {
      title: "套餐",
      width: 300,
      dataIndex: "setMeal",
    },
    {
      title: "酒店总价格",
      // width:120,
      dataIndex: "hotelTotalPrice",
    },
    {
      title: "备注/需求",
      render: (_, record) => (
        <Space size="middle">
         <span>{record.remarks}</span>/<span>{record.dateOfCneedheckIn}</span>
        </Space>
      ),
    },
    {
      title: "代理",
      dataIndex: "deputy",
      render: (_text, record) => (
        <Space size="middle">
         <span className="setMeal_backcolor">{_text}</span>
        </Space>
      ),
    },

    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="setMeal_memberCursor" onClick={lookover(record)}>
            {/* <FormOutlined /> */}
            <AlignCenterOutlined />
          </span>
          <span className="setMeal_memberCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 头部下拉选择框-内容
  const options1 = [
    {
      value: "1",
      label: "全部",
    },
    {
      value: "2",
      label: "部分",
    },
  ];

  // 头部下拉选择框-内容---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };
  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 查看
  const lookover = (record: any) => {
    return () => {
      console.log("点击了查看");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };

  return (
    <div className="setMeal_Box">
      <div className="setMeal_headerBox">
        <div className="setMeal_headerBox_thread"></div>
        <div className="setMeal_headerBox_Tit">&nbsp;&nbsp;&nbsp; 套餐订单</div>
        <div className="setMeal_Add_moban">
          <div className="setMeal_seekBtn" onClick={adminSearch}>
            <Select
              labelInValue
              defaultValue={{ value: "1", label: "全部" }}
              style={{ width: 120 }}
              onChange={handleChange1}
              options={options1}
            />
          </div>
        </div>
      </div>

      <div className="setMeal_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default PackageOrder;
