import type { NextPage } from "next";
import useSWR from "swr";
import { Suspense } from "react";

type Data = {
  message: string;
};

const fetcher = (url: string) => fetch(url).then((res) => res.json());

const HelloPage: NextPage = () => {
  const { data, error } = useSWR<Data>("/api/hello", fetcher);

  if (error) return <div>Failed to load</div>;
  if (!data) return <div>Loading...</div>;

  return (
    <Suspense fallback={<div>Loading...</div>}>
      <div>{data.message}</div>
    </Suspense>
  );
};

export default HelloPage;
