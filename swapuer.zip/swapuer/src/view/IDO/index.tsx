import React from 'react'
import Header from '../../components/Header'

function IDO() {
  return (
    <div>
      <Header />
      IDO
    </div>
  )
}

export default IDO
