<template>

</template>

<script setup lang="ts">

// js 的数字存储 64位浮点数

//  符号 指数 尾数
// - 1.08 * 10~二次方2 （-是符号 / .08是尾数 / ~二次方2是指数）
// 尾数决定了这个数的精度

// 比如说你能存两个尾数 那你只能存00-99
// 比如说你能存三个尾数 那你只能存000-999
// 尾数决定了这个数字的精度


// 尾数是有长度限制了 （浮点数规定尾数部分是52位 超过了在多都不要）

// Number.MAX_SAFE_INTEGER + 2

// Number.MAX_SAFE_INTEGER + 1 === Number.MAX_SAFE_INTEGER + 2 //true

function ches() {
    var START: number = 2 ** 53
    var END: number = START + 100
    for (let i = START; i < END; i++) {
        console.log('loop');
    }
    // A. 99次
    // B. 100次
    // C. 报错
    // D. 不可预测 答案
}
// ches()


</script>

<style>

</style>