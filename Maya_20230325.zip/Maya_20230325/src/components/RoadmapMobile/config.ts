export const btnActive = {
    background: "#F95192",
    border: "0.91px solid #F95192",
    color: "#fff",
};

export const btnDefault = {
    background: "#fff",
    border: "0.91px solid #0000003F",
    color: "#000000D8",
};