import React, { useEffect, useState, useRef } from "react";
import { EVM } from "evm";
import { ethers } from "ethers";
import copy from "copy-to-clipboard";
import { Radio, DatePicker, Space, message } from "antd";
import { BigNumber } from "@ethersproject/bignumber";
import { floatformat, posInvFormat } from "../../utils/floatFormat";
import type { DatePickerProps, RangePickerProps } from "antd/es/date-picker";
import { WBENJson } from "../../config/abi/wbenjson";
import {
  CreatelockABI,
  CreatelockAddress,
  lockProps,
  MinutesConversion,
  PercentConversion,
} from "../../hooks/Createlock";
import {
  allowance,
  InstancedContract,
  ObtainAddress,
  TokenNameDecimals,
  Lineg,
  DigitalConversion,
  convertLocalDateToUTCIgnoringTimezone,
  TimestampToTime,
} from "../../hooks/config";
import { RedoOutlined } from "@ant-design/icons";
import "./index.css";
import "./mobile.css";
import { toStringValue } from "../../hooks/Token";
import { useTranslation, Trans } from "react-i18next";
import ButtonLoading from '../../components/ButtonLoading'
import { isAddress } from '../../utils/address'
import InputError from '../../components/InputError'
import { LockError } from '../../hooks/LockInfoError'

declare const window: Window & { ethereum: any };

const Lock: React.FC = (props: any) => {

  const [lockLoading, setLockLoading] = useState<boolean>()

  const [lockupAddr, setLockUpAddress] = useState<string>(CreatelockAddress);
  const [approveloading, setApproveLoading] = useState<boolean>(false)
  const { t } = useTranslation();
  const [lockupAddrPC, setLockupAddrPC] = useState<string>();
  const [lockupAddrMobile, setLockUpAddrMobile] = useState<string>();
  // use vesting
  const [checked1, setChecked1] = useState<boolean>(false);
  // use another owner
  const [checked2, setChecked2] = useState<boolean>(false);


  const [amountInput, setAmountInput] = useState<string>("");
  const [ULieng, setULieng] = useState<Lineg>({});
  const [dapres, setDapres] = useState<any>({});
  const [lockDate, setLockDate] = useState<lockProps>({
    TokenAddress: "",
    Owner: "",
    Minutes: "0",
    LocDate: "",
    Percent: "0",
    Release: "0",
    Amount: "0",
  });


  useEffect(() => {
    setError("amountError", false)
  }, [])

  useEffect(() => {
    if (Number(lockDate.Amount as string)) {
      setError("amountError", false)
    }
  }, [lockDate.Amount as string])

  const isNext = () => {
    if (checked2) {
      // 选择了owner 也选择了use vest
      if (checked1) {
        if ((lockDate.Amount as string)
          && (lockDate.Percent as string)
          && (lockDate.Release as string)
          && (lockDate.Minutes as string)
          && isAddress(lockDate.Owner as string)
          && isAddress(lockDate.TokenAddress as string)
          && (lockDate.LocDate as string)) {
          return true
        } else {
          return false
        }
      } else {
        // 选择了owner 未选择use vest
        // TokenAddress
        // Amount
        // LocDate
        // Owner
        if ((lockDate.Amount as string)
          && isAddress(lockDate.TokenAddress as string)
          && isAddress(lockDate.Owner as string)
          && (lockDate.LocDate as string)) {
          return true
        } else {
          return false
        }
      }
    } else {
      // 未选择owner 但选择了use vest
      if (checked1) {
        // TokenAddress
        // Percent
        // Release
        // Minute
        // Amount
        // LocDate
        if ((lockDate.Amount as string)
          && (lockDate.Percent as string)
          && (lockDate.Release as string)
          && (lockDate.Minutes as string)
          && isAddress(lockDate.TokenAddress as string)
          && (lockDate.LocDate as string)) {
          return true
        } else {
          return false
        }

        // 两者都没选择
      } else {
        // TokenAddress
        // Amount
        // LocDate
        if ((lockDate.Amount as string)
          && isAddress(lockDate.TokenAddress as string)
          && (lockDate.LocDate as string)) {
          return true
        } else {
          return false
        }
      }
    }
  }

  const [NameShow, setNameShow] = useState<boolean>(false);
  const [ApproveShow, setApproveShow] = useState<boolean>(false);
  const refvewting = useRef<any>();
  const refanother = useRef<any>();
  const [kewShow, setKewShow] = useState<boolean>(false);
  const [lockproShow, setlockproShow] = useState<boolean>(false);
  const [PosintgeDate, setPosintgeDate] = useState<string>("");
  const [decimals, setDecimals] = useState<string>("");



  const onChange = (
    value: DatePickerProps["value"] | RangePickerProps["value"],
    dateString: [string, string] | string
  ) => {
    const nowTime = new Date()
    if (nowTime > (value as any)._d) {
      setError("lockupError", true)
    } else {
      setError("lockupError", false)
    }
    // (value as any)._d 用户选择的事件
    // console.log((value as any)._d)
    const UTCIgnoringTimezone = convertLocalDateToUTCIgnoringTimezone(
      new Date(toStringValue(dateString))
    );
    const UTCtransFormation = new Date(
      toStringValue(UTCIgnoringTimezone)
    ).valueOf();
    setLockDate((olddata: lockProps) => {
      return {
        ...olddata,
        LocDate: toStringValue(UTCtransFormation / 1000),
      };
    });
    setPosintgeDate((KewShowValue) => {
      return (KewShowValue = TimestampToTime(
        toStringValue(UTCtransFormation / 1000)
      ));
    });
  };
  const onOk = (
    value: DatePickerProps["value"] | RangePickerProps["value"]
  ) => { };
  const copyAddr = (addr: string) => {
    copy(addr);
    successTip("Copy Successfully")
  };
  // 提示复制成功
  const successTip = (tip: string) => {
    message.success(`${t(tip)}`);
  };
  const OwnerAddress = async () => {
    const { address } = await ObtainAddress() as any;
    if (checked2) {
      return lockDate.Owner as string;
    } else {
      return address;
    }
  };
  const decompile = async (contractAddr: string) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    let code = await provider.getCode(contractAddr);
    const evm = new EVM(code);
    const getFunctions = evm.getFunctions();
    return getFunctions.includes("DOMAIN_SEPARATOR()");
  };
  const lockbtnOnClick = async () => {
    setLockLoading(true)
    try {
      const Owner = OwnerAddress();
      const { TokenAddress, Amount, LocDate, Title, Percent, Minutes, Release } =
        lockDate;
      const isLpToken = await decompile(lockDate.TokenAddress as string);
      const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
      if (checked1) {
        const vestingLock = await Contract.vestingLock(
          Owner,
          TokenAddress,
          isLpToken,
          DigitalConversion(Amount, 18),
          LocDate,
          PercentConversion(Percent),
          MinutesConversion(Minutes),
          PercentConversion(Release),
          Title
        );
        await vestingLock.wait()
        setLockLoading(false)
      } else {
        const lock = await Contract.lock(
          Owner,
          TokenAddress,
          isLpToken,
          DigitalConversion(Amount, 18),
          LocDate,
          Title
        );
        await lock.wait()
        setLockLoading(false)
      }
    } catch (error) {
      setLockLoading(false)
    }
  };
  const TokenAddressonChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setLockDate((olddata: lockProps) => {
      return {
        ...olddata,
        TokenAddress: e.target.value,
      };
    });
    if (ethers.utils.isAddress(e.target.value)) {
      const allowanceParameter = await allowance(
        e.target.value,
        CreatelockAddress
      );
      const MaxUint256: BigNumber = BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = true);
      });
      if (allowanceParameter.eq(MaxUint256)) {
        setApproveShow(true);
      }
      const Uline = await TokenNameDecimals(e.target.value);
      setULieng((ULiengprevState: Lineg) => {
        return (ULiengprevState = Uline);
      });
    } else {
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = false);
      });
    }
  };
  const maxOnCLick = () => {
    setAmountInput(ULieng.balanceOf as string);
    setLockDate((olddata: lockProps) => {
      return {
        ...olddata,
        Amount: ULieng.balanceOf as string,
      };
    });
  };
  const ApproveClick = async () => {
    try {
      setApproveLoading(true)
      const Contract = InstancedContract(
        lockDate.TokenAddress as string,
        WBENJson
      ) as any;
      const MaxUint256: BigNumber = (BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"));
      const approve = await Contract.approve(
        CreatelockAddress,
        MaxUint256
      );
      await approve.wait();
      setApproveShow((pproveShowprevState: any) => {
        return (pproveShowprevState = true);
      });
      setApproveLoading(false)
    } catch (error) {
      setApproveLoading(false)
    }
  };
  const TokenInformation = () => {
    return (
      <div className="Giving">
        <div className="Giving_item">
          <div>{`${t("Name")}`}</div>
          <div>{(ULieng.name as string) || <RedoOutlined spin />}</div>
        </div>
        <div className="Giving_item">
          <div>{`${t("Symbol")}`}</div>
          <div>{(ULieng.symbol as string) || <RedoOutlined spin />}</div>
        </div>
        <div className="Giving_item">
          <div>{`${t("Decimals")}`}</div>
          <div>{(ULieng.decimals as string) || <RedoOutlined spin />}</div>
        </div>
        <div className="Giving_item">
          <div>{`${t("Balance")}`}</div>
          <div>{(ULieng.balanceOf as string) || <RedoOutlined spin />}</div>
        </div>
      </div>
    );
  };
  const lockCreateClicklockbtn = async () => {
    setLockLoading(true)
    try {
      const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
      const editLock = await Contract.editLock(
        dapres.lockId as any,
        DigitalConversion(lockDate.Amount, Number(decimals)),
        lockDate.LocDate
      );
      await editLock.wait()
      setLockLoading(false)
    } catch (error) {
      setLockLoading(false)
    }
  };
  const allowanceSholper = async (address: any) => {
    const allowanceParameter = await allowance(address, CreatelockAddress);
    const MaxUint256: BigNumber = BigNumber.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    if (allowanceParameter.eq(MaxUint256)) {
      setApproveShow(true);
    }
  };
  useEffect(() => {
    if (props.location.state != undefined) {
      const { tokenList, lockId, decimals } = props.location.state;
      setLockDate((prevState: lockProps) => {
        return (prevState = {
          TokenAddress: tokenList.token,
          Title: tokenList.Title,
          Amount: tokenList.amountShow,
          LocDate: tokenList.tgeDate,
          Percent: tokenList.PercentShow,
          Minutes: tokenList.CycleShow,
          Release: tokenList.CycleReleaseShow,
        });
      });
      allowanceSholper(tokenList.token);
      setAmountInput((AmountInput) => {
        return (AmountInput = tokenList.amountShow || 0);
      });
      setDapres((Dapres: any) => {
        return (Dapres = {
          ...props.location.state.tokenList,
          lockId,
        });
      });
      setPosintgeDate((KewShowValue) => {
        return (KewShowValue = TimestampToTime(tokenList.tgeDate));
      });
      setKewShow((KewShowValue) => {
        return (KewShowValue = true);
      });
      setDecimals((decimalsValue) => {
        return (decimalsValue = String(decimals));
      });
      setlockproShow((lockproShowValue) => {
        return (lockproShowValue = true);
      });
      if (Number(tokenList.PercentShow) > 0) {
        setChecked1((Checked1prevState) => {
          return (Checked1prevState = true);
        });
      }
    }
    setLockupAddrPC(lockupAddr);
    const mobileAddr =
      lockupAddr.substring(0, 6) + "..." + lockupAddr.substring(38, 42);
    setLockUpAddrMobile(mobileAddr);
  }, [ULieng]);

  // 开启或者关闭错误提示
  const [lockerror, setLockError] = useState<LockError>({
    amountError: true
  })

  // 提示错误
  const setError = (key: string, value: boolean) => {
    setLockError((prevState: LockError) => {
      return {
        ...prevState,
        [key]: value,
      };
    });
  }

  // onBlur 输入框失焦以后需要判断的函数
  const validInput = (content: string, value: string) => {
    // false:符合条件不显示错误提示
    // true:不符合条件显示错误提示
    switch (content) {
      case "tokenAddress":
        setError("tokenAddrError", !isAddress(value as string))
        break
      case "ownerAddress":
        setError("ownerAddrError", !isAddress(value as string))
        break
      case "Amount":
        if (value && Number(value) > 0) {
          setError("amountError", false)
        } else {
          setError("amountError", true)
        }
        break
      case "TGEPercent":
        if (value && Number(value) <= 100 && Number(value) + Number(lockDate.Release) <= 100) {
          setError("TGEpercentError", false)
        } else {
          setError("TGEpercentError", true)
        }
        break
      case "Cycle":
        if (value && Number(value) > 5) {
          setError("cycleError", false)
        } else {
          setError("cycleError", false)
        }
        break
      case "Release":
        if (value && Number(value) <= 100 && Number(value) + Number(lockDate.Percent) <= 100) {
          setError("cycleReleaseError", false)
        } else {
          setError("cycleReleaseError", true)
        }
        break
    }
  }

  useEffect(() => {
    if (Number(lockDate.Percent) + Number(lockDate.Release) <= 100) {
      setError("TGEpercentError", false)
      setError("cycleReleaseError", false)
    }
  }, [lockDate.Percent, lockDate.Release])

  return (
    <div className="Lock">
      <div className="LockRectangle">
        <div className="title">
          <span>{`${t("Create your lock")}`}</span>
        </div>
        <div className="line" />
        <div className="audited">
          <div className="auditTitle">
            <span>{`${t("MAYALock is audited by")}`}:</span>
          </div>
          <div className="auditImageArea">
            <img
              src={require(`../../assets/image/audited01.png`)}
              alt=""
              className="auditImage"
            />
            <img
              src={require(`../../assets/image/audited02.png`)}
              alt=""
              className="auditImage"
            />
            <img
              src={require(`../../assets/image/audited03.png`)}
              alt=""
              className="auditImage"
            />
            <img
              src={require(`../../assets/image/audited04.png`)}
              alt=""
              className="auditImage"
            />
            <img
              src={require(`../../assets/image/audited05.png`)}
              alt=""
              className="auditImage"
            />
            <img
              src={require(`../../assets/image/audited06.png`)}
              alt=""
              className="auditImage"
            />
          </div>
        </div>
        <div className="Diving">
          <div className="inputTitle">
            <span>{`${t("Token or LP Token address")}`}</span><span style={{ color: "#f95192" }}> *</span>
          </div>
          <input
            disabled={kewShow}
            className={`tokenAddrInput ${kewShow ? "inpactie" : ""}`}
            placeholder={`${t("Enter token or LP token address")}`}
            value={lockDate.TokenAddress || ""}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              TokenAddressonChange(e);
            }}
            style={{ borderColor: lockerror.tokenAddrError ? '#f14668' : '' }}
            onBlur={(e) => { validInput("tokenAddress", e.target.value) }}
          />
          {lockerror.tokenAddrError ? <InputError title="Invalid address" /> : ''}
        </div>
        {NameShow === true ? <TokenInformation /> : ""}
        <div className="radioArea">
          <Radio
            disabled={kewShow}
            onClick={() => {
              setChecked2(!refanother.current.state.checked);
            }}
            ref={refanother}
            checked={checked2}
          >
            {`${t("use another owner?")}`}
          </Radio>
        </div>
        {checked2 === true ? (
          <div className="Diving">
            <div className="inputTitle">
              <span>{`${t("Owner")}`}</span>
            </div>
            <input
              className="titleInput"
              placeholder={`${t("Enter owner address")}`}
              onBlur={(e) => { validInput("ownerAddress", e.target.value) }}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                setLockDate((olddata: lockProps) => {
                  return {
                    ...olddata,
                    Owner: e.target.value,
                  };
                });
              }}
              style={{ borderColor: lockerror.ownerAddrError ? '#f14668' : '' }}
            />
            {lockerror.ownerAddrError ? <InputError title="Invalid address" /> : ''}
          </div>
        ) : (
          ""
        )}
        <div className="Diving">
          <div className="inputTitle">
            <span>{`${t("Title")}`}</span>
          </div>
          <input
            disabled={kewShow}
            className={`titleInput ${kewShow ? "inpactie" : ""}`}
            placeholder={`${t("Ex: My Lock")}`}
            value={lockDate.Title || ""}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              setLockDate((olddata: lockProps) => {
                return {
                  ...olddata,
                  Title: e.target.value,
                };
              });
            }}
          />
        </div>
        <div className="Diving">
          <div className="inputTitle">
            <span>{`${t("Amount")}`}</span><span style={{ color: "#f95192" }}> *</span>
          </div>
          <div className="enterAmount" style={{ borderColor: lockerror.amountError ? '#f14668' : '' }}>
            <input
              className="amountInput"
              placeholder={`${t("Enter amount")}`}
              value={amountInput}

              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                setAmountInput(floatformat(e.target.value));
                setLockDate((olddata: lockProps) => {
                  return {
                    ...olddata,
                    Amount: floatformat(e.target.value),
                  };
                });
              }}
              onBlur={(e) => { validInput("Amount", e.target.value) }}
            />
            <span
              className="max"
              onClick={() => {
                maxOnCLick();
              }}
            >
              {`${t("MAX")}`}
            </span>
          </div>
          {lockerror.amountError ? <InputError title="Invalid number" /> : ''}
        </div>
        <div className="radioArea">
          <Radio
            onClick={() => {
              setChecked1(!refvewting.current.state.checked);
            }}
            checked={checked1}
            ref={refvewting}
          >
            {`${t("use vesting")}`}?
          </Radio>
        </div>
        <div className="Diving">
          <div className="Diving_item">
            <div className="Diving_item_ple">
              <div className="inputTitle">
                <span>{`${t("Lock until")}`}</span><span style={{ color: "#f95192" }}> *</span>
              </div>
              <div className="lockTimeArea" style={{ borderColor: lockerror.lockupError ? '#f14668' : '' }}>
                <Space direction="vertical" size={12} >
                  <DatePicker
                    showTime
                    onChange={onChange}
                    onOk={onOk}
                  />
                </Space>
              </div>
              {lockerror.lockupError ? <InputError title="Invalid time" /> : ''}
            </div>
            {checked1 === true ? (
              <div className="Diving_item_ple">
                <div className="inputTitle">
                  <span>{`${t("TGE Percent")}`}*</span>
                </div>
                <input
                  style={{ borderColor: lockerror.TGEpercentError ? '#f14668' : '' }}
                  disabled={kewShow}
                  className={`titleInput ${kewShow ? "inpactie" : ""}`}
                  placeholder="Ex: 10"
                  value={lockDate.Percent || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setLockDate((olddata: lockProps) => {
                      return {
                        ...olddata,
                        Percent: floatformat(e.target.value),
                      };
                    });
                  }}
                  onBlur={(e) => { validInput("TGEPercent", floatformat(e.target.value)) }}
                />
              </div>
            ) : (
              ""
            )}
          </div>
          {checked1 === true ? (
            <div className="Diving_item">
              <div className="Diving_item_ple">
                <div className="inputTitle">
                  <span>{`${t("Cycle (minutes)")}`}*</span>
                </div>
                <input
                  style={{ borderColor: lockerror.cycleError ? '#f14668' : '' }}
                  placeholder="Ex: 10"
                  disabled={kewShow}
                  // type="number"
                  className={`titleInput ${kewShow ? "inpactie" : ""}`}
                  value={lockDate.Minutes || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setLockDate((olddata: lockProps) => {
                      return {
                        ...olddata,
                        Minutes: posInvFormat(e.target.value),
                      };
                    });
                  }}
                  onBlur={(e) => { validInput("Cycle", e.target.value) }}
                />
                {lockerror.cycleError ? <InputError title="Invalid time" /> : ''}
              </div>
              <div className="Diving_item_ple">
                <div className="inputTitle">
                  <span>{`${t("Cycle Release Percent")}`}*</span>
                </div>
                <input
                  placeholder="Ex: 10"
                  disabled={kewShow}
                  style={{ borderColor: lockerror.cycleReleaseError ? '#f14668' : '' }}
                  className={`titleInput ${kewShow ? "inpactie" : ""}`}
                  value={lockDate.Release || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setLockDate((olddata: lockProps) => {
                      return {
                        ...olddata,
                        Release: floatformat(e.target.value),
                      };
                    });
                  }}
                  onBlur={(e) => { validInput("Release", floatformat(e.target.value)) }}
                />
                {lockerror.cycleReleaseError ? <InputError title="Invalid percent" /> : ''}
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
        <div className="LockAddrArea">
          <div>
            <span className="lockAddrPC">
              {`${t("Please exclude MAYALock's lockup address")}`} {lockupAddrPC}
              <img
                src={require(`../../assets/image/pinkCopy.png`)}
                alt=""
                className="copyAddrLogo"
                onClick={() => {
                  copyAddr(lockupAddr);
                }}
              />
            </span>
            <span className="lockAddrMobile">
              {`${t("Please exclude MAYALock's lockup address")}`}
              <div style={{ justifyContent: "center" }}>
                {lockupAddrMobile}
                <img
                  src={require(`../../assets/image/pinkCopy.png`)}
                  alt=""
                  className="copyAddrLogo"
                  onClick={() => {
                    copyAddr(lockupAddr);
                  }}
                />
              </div>
            </span>
          </div>
          <div>
            {`${t("from fees, rewards, max tx amount to start locking tokens.We don't support rebase tokens")}`}
          </div>
        </div>
        {ApproveShow === true ? (
          <>
            {lockproShow === true ? <>
              {isNext() ? (
                <button
                  className="lockbtn"
                  onClick={() => {
                    lockCreateClicklockbtn();
                  }}
                >
                  {lockLoading ? <ButtonLoading /> : ''} {`${t("Lock")}`}
                </button>
              ) : (
                <button
                  className="lockbtn"
                  style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
                >
                  {`${t("Lock")}`}
                </button>
              )}
            </> : <>
              {isNext() ? (
                <button
                  className="lockbtn"
                  onClick={() => {
                    lockbtnOnClick();
                  }}
                >
                  {lockLoading ? <ButtonLoading /> : ''} {`${t("Lock")}`}
                </button>
              ) : (
                <button
                  className="lockbtn"
                  style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
                >
                  {`${t("Lock")}`}
                </button>
              )}
            </>}
          </>
        ) : <>
          { isNext() ? <button
            className="lockbtn"
            onClick={() => {
              ApproveClick();
            }}
          >
            {approveloading ? <ButtonLoading /> : ''} {`${t("Approve")}`}
          </button> : <button
            className="lockbtn"
            style={{cursor:'not-allowed',backgroundColor:'#999'}}
          >
            {`${t("Approve")}`}
          </button> }
        </>}
      </div>

      <div className="disclaimer">
        {`${t("Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published.")}`}
      </div>
    </div>
  );
};
export default Lock;
