import { useEffect, useState } from "react";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import {
  Button,
  Input,
  notification,
  Modal,
  Tabs,
  Dropdown,
  Space,
  MenuProps,
  Menu,
} from "antd";
import {
  CheckCircleOutlined,
  LoadingOutlined,
  DownOutlined,
} from "@ant-design/icons";
import Header from "../../components/Header";
import "./index.scss";
import {
  PAIR_ABI,
  wben_ABI,
  List,
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
  InstancedContract,
} from "../../hooke/conter";
import { useTranslation } from "react-i18next";
import i18n from "../../i18n";

declare const window: Window & { ethereum: any };

function Index() {
  const MINUTE_MS = 30000;
  const [address, serAddres] = useState("");
  const [showList, setShowList] = useState(List);
  const [inputValue, setInputValue] = useState(0);
  const [unShow, setunShow] = useState(false);
  const key = "updatable";
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [handelvoice, setHandelvoice] = useState("中文简体");
  const { t } = useTranslation();
  const handleOk = async (id: any) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const Contract = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      );
      const withs = await Contract.withdraw(id);
      openNotification2(
        "Retrieving...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setIsModalVisible(false);
      await withs.wait();
      openNotification2(
        "Retrieved successfully.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      const pldata = await Contract.userInfo(id, address);
      const buList: any = [];
      showList.map((item: any) => {
        if (item.id == id) {
          item.lPdata = ethers.utils.formatEther(
            pldata.depositAmount.toString()
          );
        }
        buList.push(item);
      });
      setInputValue(0);
      setIsModalVisible(false);
      setTimeout(() => {
        setShowList(buList);
      }, 300);
    } catch (error: any) {
      setIsModalVisible(false);
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification2(
          "User refuses to retrieve.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
      }
    }
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const openNotification2 = (bindValue: any, durn: any, icon: any) => {
    notification.open({
      key,
      message: "Tips",
      description: bindValue,
      duration: durn,
      icon: icon,
    });
  };
  // 授权
  const approve = async (code: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const PAIRContract = new ethers.Contract(code, PAIR_ABI, signer);
    const apperov = await PAIRContract.approve(
      CONTRACT_ADDRESS,
      ethers.constants.MaxUint256
    );
    openNotification2(
      "Under authorization...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await apperov.wait();
    const buList: any = [];
    showList.map((item: any) => {
      if (item.code == code) {
        item.show = 1;
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
    openNotification2(
      "Authorization succeeded.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
  };
  // 质押
  const deposit = async (id: any) => {
    // try {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const value = new BigNumber(inputValue)
      .times(new BigNumber(10).pow(18))
      .toFixed();
    const desite = await Contract.deposit(id, value.toString());
    openNotification2(
      "In deposit...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await desite.wait();
    openNotification2(
      "Deposit succeeded.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
    const pldata = await Contract.userInfo(id, address);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.lPdata = ethers.utils.formatEther(pldata.depositAmount.toString());
        item.inputValue = "";
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
      whitelistUsersDataShioer();
    }, 300);
  };
  // 领取
  const claim = async (id: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const cladim = await Contract.claim(id);
    openNotification2(
      "Receiving...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await cladim.wait();
    openNotification2(
      "Successfully received.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
    whitelistUsersDataShioer();
  };
  // 最大值
  const BinCkmax = async (bianes: any, id: any) => {
    setInputValue(bianes);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = bianes;
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
    setunShow(true);
  };
  // 赎回
  const withdraw = async (id: any) => {
    setIsModalVisible(true);
  };
  const onCInput = (e: any, id: any) => {
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = e.target.value;
        setInputValue(e.target.value);
        const Shui = e.target.value || 0;
        if (Shui === 0) {
          setunShow(false);
        } else if (item.inputValue === 0) {
          setunShow(false);
        } else {
          setunShow(true);
        }
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };
  const Meslei = [
    {
      label: "中文简体",
      key: "1",
    },
    {
      label: "English",
      key: "2",
    },
  ];
  const handleMenuClick: MenuProps["onClick"] = (e) => {
    setHandelvoice(Meslei[Number(e.key) - 1].label);
    if (e.key == "1") {
      i18n.changeLanguage("zh-CN");
    } else {
      i18n.changeLanguage("en");
    }
  };
  const menu = <Menu onClick={handleMenuClick} items={Meslei} />;

  const usiderConter = async (code: any, address: any) => {
    const Contracter = await InstancedContract(code, PAIR_ABI);
    const usider = Contracter.allowance(address, CONTRACT_ADDRESS);
    return usider;
  };
  const bineofConter = async (code: any, address: any) => {
    const Contracter = await InstancedContract(code, PAIR_ABI);
    return await Contracter.balanceOf(address);
  };
  const pldataConter = async (id: any, address: any) => {
    const Contracter = await InstancedContract(CONTRACT_ADDRESS, CONTRACT_ABI);
    return await Contracter.userInfo(id, address);
  };
  const pendingConter = async (id: any, address: any) => {
    const Contracter = await InstancedContract(CONTRACT_ADDRESS, CONTRACT_ABI);
    return await Contracter.pendingReward(id, address);
  };
  const tokenConter = async (
    token1: any,
    token2: any,
    code: any,
    id: any,
    address: any
  ) => {
    const Contracter = await InstancedContract(CONTRACT_ADDRESS, CONTRACT_ABI);
    const ContractToken1 = await InstancedContract(token1, wben_ABI);
    const ContractToken2 = await InstancedContract(token2, wben_ABI);
    const PAIRContract = await InstancedContract(code, PAIR_ABI);
    const totalSupply = await PAIRContract.totalSupply();
    const bnbTotal1 = await ContractToken1.balanceOf(code);
    const decimals1 = await ContractToken1.decimals();
    const bnbTotal2 = await ContractToken2.balanceOf(code);
    const decimals2 = await ContractToken2.decimals();
    const lisne = await Contracter.userInfo(id, address);
    let holdRatio1 = Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
    let userBnb1 = Number(bnbTotal1) * holdRatio1;
    let nukse1 = userBnb1 / 10 ** decimals1;
    let holdRatio2 = Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
    let userBnb2 = Number(bnbTotal2) * holdRatio2;
    let nukse2 = userBnb2 / 10 ** decimals2;
    const t1 = new Date().valueOf();
    const beins =
      t1.toString().slice(0, 3) +
      "," +
      t1.toString().slice(3, 6) +
      "," +
      t1.toString().slice(6, 9);
    return {
      lPdataToken1: nukse1,
      lPdataToken2: nukse2,
      pron1: beins,
    };
  };
  const whitelistUsersDataShioer = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const LIbse: any = showList;
    showList.map(async (item: any) => {
      Promise.all([
        usiderConter(item.code, address),
        bineofConter(item.code, address),
        pldataConter(item.id, address),
        pendingConter(item.id, address),
        tokenConter(item.token1, item.token2, item.code, item.id, address),
      ]).then((res) => {
        if (Number(res[0].toString()) == Number(ethers.constants.MaxUint256)) {
          LIbse[item.pid].bianes = ethers.utils.formatEther(res[1].toString());
          LIbse[item.pid].lPdata = ethers.utils.formatEther(
            res[2].depositAmount.toString()
          );
          LIbse[item.pid].lPdataToken1 = String(res[4].lPdataToken1.toFixed(4));
          LIbse[item.pid].lPdataToken2 = String(res[4].lPdataToken2.toFixed(4));
          LIbse[item.pid].Pending = ethers.utils.formatEther(res[3].toString());
          LIbse[item.pid].pron1 = res[4].pron1;
          LIbse[item.pid].show = 1;
        } else {
          LIbse[item.pid].bianes = ethers.utils.formatEther(res[1].toString());
          LIbse[item.pid].show = 0;
          LIbse[item.pid].pron1 = res[4].pron1;
        }
      });
    });
    setTimeout(() => {
      let _arr = JSON.parse(JSON.stringify(LIbse));
      setShowList((state: any) => {
        return (state = _arr);
      });
    }, 1500);
  };
  useEffect(() => {
  }, [inputValue, showList, address]);

  useEffect(() => {
    const ahsdr = localStorage.getItem("addr");
    if (ahsdr !== null && ahsdr !== undefined) {
      if (i18n.language === "en") {
        setHandelvoice("English");
      } else {
        setHandelvoice("中文简体");
      }
      whitelistUsersDataShioer();
      (window as any).ethereum.on(
        "accountsChanged",
        async function (accounts: any) {
          localStorage.setItem("addr", accounts[0]);
          setTimeout(() => {
            whitelistUsersDataShioer();
          }, 1000);
        }
      );
      const interval = setInterval(async () => {
        whitelistUsersDataShioer();
      }, MINUTE_MS);
      return () => clearInterval(interval);
    }
  }, []);
  return (
    <div className="Frome">
      <Header />
      <div className="banNdr">
        <div className="sueeis">
          <div className="sueeis_title">{`${t("Dividend factory")}`}</div>
          <div className="speiuise">
            <div className="sapeien">
              <Dropdown
                overlay={menu}
                placement="bottom"
                arrow={{ pointAtCenter: true }}
              >
                <Button>
                  <Space>
                    <div className="speriise">
                      <div className="psoduenxc">{handelvoice}</div>
                      <DownOutlined style={{ fontSize: "10px" }} />
                    </div>
                  </Space>
                </Button>
              </Dropdown>
            </div>
          </div>
        </div>
        <div className="nsuroBIneg">
          {showList.map((item: any) => (
            <div className="NuserList2" key={item.id}>
              <div className="Lisndter">
                <Tabs defaultActiveKey="1">
                  <Tabs.TabPane tab={`${t("Deposit LP dividends")}`} key="1">
                    <div className="NusierItem">
                      <div className="Butile">
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t(
                            "Entered the pool"
                          )}`}</div>
                          ~ {item.lPdataToken1 || "0.0"}{" "}
                          {item.name.split("/")[0]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t(
                            "Entered the pool"
                          )}`}</div>{" "}
                          ~{" "}
                          {item.lPdataToken2 > 0 &&
                          item.lPdataToken2 < 0.0000000001
                            ? "< 0.0000000001"
                            : item.lPdataToken2 || "0.0"}{" "}
                          {item.name.split("/")[1]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Over")}`}</div>~{" "}
                          {Number(item.bianes).toFixed(4) || "0.0"} {item.name}{" "}
                          LP
                        </div>
                      </div>
                      <div className="nbudrki">
                        {item.show === 1 ? (
                          <div className="Bininput">
                            <Input
                              value={item.inputValue}
                              onChange={(e) => onCInput(e, item.id)}
                              type="text"
                              placeholder="0.0"
                            />
                            <div className="Binmax">
                              <Button
                                className="sliense"
                                onClick={() => {
                                  BinCkmax(item.bianes, item.id);
                                }}
                              >
                                {`${t("Max")}`}
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="Bininput">
                            <Input disabled type="text" placeholder="0.0" />
                            <div className="Binmax">
                              {" "}
                              <div className="nuBut">
                                <Button disabled>{`${t("Max")}`}</Button>
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="Nusoer">
                          <div className="Numerbut">
                            {item.show === 1 ? (
                              <>
                                {item.inputValue !== "" && unShow ? (
                                  <Button
                                    onClick={() => {
                                      deposit(item.id);
                                    }}
                                  >
                                    {`${t("Deposit")}`}
                                  </Button>
                                ) : (
                                  <div className="nuBut">
                                    <Button disabled>
                                      {" "}
                                      {`${t("Deposit")}`}
                                    </Button>
                                  </div>
                                )}
                              </>
                            ) : (
                              <Button
                                onClick={() => {
                                  approve(item.code);
                                }}
                              >
                                {`${t("Approve")}`}
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="NusierItemShow">
                      <div className="Butile">
                        <div className="yruci">
                          <div className="tilei">{item.id + 1} 号池</div>
                          <div className="snbueise">{item.name} LP</div>
                        </div>
                        <div className="yruci">
                          <div className="tilei">{`${t("Over")}`}</div>
                          <div className="snbueise">
                            ~ {Number(item.bianes).toFixed(4) || "0.0"}
                          </div>
                        </div>
                      </div>
                      <div className="nbudrki">
                        {item.show === 1 ? (
                          <div className="Bininput">
                            <Input
                              value={item.inputValue}
                              onChange={(e) => onCInput(e, item.id)}
                              type="text"
                              placeholder="0.0"
                            />
                            <div className="Binmax">
                              <Button
                                className="sliense"
                                onClick={() => {
                                  BinCkmax(item.bianes, item.id);
                                }}
                              >
                                {`${t("Max")}`}
                              </Button>
                              <div className="busiense">
                                {item.show === 1 ? (
                                  <>
                                    {item.inputValue !== "" && unShow ? (
                                      <Button
                                        onClick={() => {
                                          deposit(item.id);
                                        }}
                                      >
                                        {`${t("Deposit")}`}
                                      </Button>
                                    ) : (
                                      <div className="nuBut">
                                        <Button disabled>
                                          {" "}
                                          {`${t("Deposit")}`}
                                        </Button>
                                      </div>
                                    )}
                                  </>
                                ) : (
                                  <Button
                                    onClick={() => {
                                      approve(item.code);
                                    }}
                                  >
                                    {`${t("Approve")}`}
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="Bininput">
                            <Input disabled type="text" placeholder="0.0" />
                            <div className="Binmax">
                              {" "}
                              <div className="nuBut">
                                <Button className="nuButbuine" disabled>
                                  {`${t("Max")}`}
                                </Button>
                                <div className="busiense">
                                  {item.show === 1 ? (
                                    <>
                                      {item.inputValue !== "" && unShow ? (
                                        <Button
                                          onClick={() => {
                                            deposit(item.id);
                                          }}
                                        >
                                          {`${t("Deposit")}`}
                                        </Button>
                                      ) : (
                                        <div className="nuBut">
                                          <Button disabled>
                                            {" "}
                                            {`${t("Deposit")}`}
                                          </Button>
                                        </div>
                                      )}
                                    </>
                                  ) : (
                                    <Button
                                      onClick={() => {
                                        approve(item.code);
                                      }}
                                    >
                                      {`${t("Approve")}`}
                                    </Button>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="Fonteruisek">
                        <div className="leng">
                          {`${t("income")}`} :
                          <div className="sbsuen">
                            ~ {item.Pending || "0.0"}
                          </div>
                        </div>
                        <div className="reuse">
                          <div className="soer_btn">
                            {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                              <Button
                                className="sbueienrwe"
                                onClick={() => {
                                  claim(item.id);
                                }}
                              >
                                {`${t("Claim")}`}
                              </Button>
                            ) : (
                              <div className="nuBut">
                                <Button disabled>{`${t("Claim")}`}</Button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tabs.TabPane>
                  <Tabs.TabPane tab={`${t("Retrieve LP")}`} key="2">
                    <div className="NusierItem2">
                      <div className="Butile">
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Over")}`}</div>
                          <span>
                            ~ {Number(item.bianes).toFixed(4) || "0.0"}
                          </span>
                        </div>
                      </div>
                      {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                        <div className="item2nr">
                          <div className="Butile">
                            <div className="yruci">
                              <span> {`${t("Deposited")}`}</span> ：
                              {item.lPdata || "0"} {item.name} LP
                            </div>
                          </div>
                          <div className="Nusoer">
                            <div className="soer_btn">
                              <Button
                                onClick={() => {
                                  withdraw(item.id);
                                }}
                              >
                                {`${t("Withdraw")}`}
                              </Button>
                            </div>
                          </div>
                          <Modal
                            title="Tips"
                            width={400}
                            visible={isModalVisible}
                            okText="确认"
                            cancelText="取消"
                            centered
                            onOk={() => {
                              handleOk(item.id);
                            }}
                            onCancel={handleCancel}
                          >
                            <p>{`${t("Please confirm the withdraw ?")}`}</p>
                          </Modal>
                        </div>
                      ) : (
                        <div className="item2nrs">
                          <div className="Butile">
                            <div className="yruci">
                              <span>{`${t("No deposit LP")}`}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="NusierItem2Show">
                      <div className="Butile">
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Over")}`}</div>
                          <div className="speosnee">
                            ~ {Number(item.bianes).toFixed(4) || "0.0"}
                          </div>
                        </div>
                      </div>
                      {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                        <div className="item2nr">
                          <div className="Butile">
                            <div className="yruci2">
                              <span> {`${t("Deposited")}`}</span> ： ~{" "}
                              {Number(item.lPdata).toFixed(4) || "0"} LP
                            </div>
                          </div>
                          <div className="Nusoer">
                            <div className="soer_btn">
                              <Button
                                onClick={() => {
                                  withdraw(item.id);
                                }}
                              >
                                {`${t("Withdraw")}`}
                              </Button>
                            </div>
                          </div>
                          <Modal
                            title="Tips"
                            width={400}
                            visible={isModalVisible}
                            okText="确认"
                            cancelText="取消"
                            centered
                            onOk={() => {
                              handleOk(item.id);
                            }}
                            onCancel={handleCancel}
                          >
                            <p>{`${t("Please confirm the withdraw ?")}`}</p>
                          </Modal>
                        </div>
                      ) : (
                        <div className="item2nrs">
                          <div className="Butile">
                            <div className="yruci">
                              <span>{`${t("No deposit LP")}`}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </Tabs.TabPane>
                </Tabs>
              </div>
              <div className="Lisndter_2use">
                <div className="psriosimge">
                  <img
                    src={require("../../assets/bda1da128757ea51b6ae3f20fb12e63.png")}
                    alt=""
                  />
                </div>
                <div className="item2nr">
                  <div className="Butile">
                    <div className="yruci">
                      <div className="tilei">{`${t(
                        "To receive dividends"
                      )}`}</div>
                      {Number(item.Pending).toFixed(4) || "0.0"} GoldCoin
                    </div>
                  </div>
                  <div className="Nusoer">
                    <div className="soer_btn">
                      {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                        <Button
                          onClick={() => {
                            claim(item.id);
                          }}
                        >
                          {`${t("Claim")}`}
                        </Button>
                      ) : (
                        <div className="nuBut">
                          <Button disabled>{`${t("Claim")}`}</Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Index;
function tokenConter(
  token1: any,
  token2: any,
  code: any,
  id: any,
  address: any
): any {
  throw new Error("Function not implemented.");
}
