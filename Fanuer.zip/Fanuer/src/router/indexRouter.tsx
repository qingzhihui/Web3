import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Home from "../view/Home";
import Farm from "../view/Farm";
import Invit from "../view/Invit";

class indexRouter extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/Home" component={Home} />
          <Route path="/Farm" component={Farm} />
          <Route path="/Invitation" component={Invit} />
          <Redirect from="/" to="/Home" />
        </Switch>
      </Router>
    );
  }
}

export default indexRouter;
