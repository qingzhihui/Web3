import { CreateLaunchpadError } from "../hooks/Errorhandle";

const LaunchpadErrorInitState: CreateLaunchpadError = {
    TitleBlankError: false,
    PresaleRateBlankError: false,
    PresaleRatePositiveError: false,
    SoftCapBlankError: false,
    SoftCapPositiveError: false,
    SoftCapMinError: false,
    SoftCapMaxError: false,
    HardCapBlankError: false,
    HardCapPositiveError: false,
    MinimumBuyBlankError: false,
    MinimumBuyPositiveError: false,
    MinimumBuyMaxError: false,
    MaximumBuyBlankError: false,
    MaximumBuyPositiveError: false,
    LiquidityBlankError: false,
    LiquidityMinError: false,
    LiquidityMaxError: false,
    ListingRateBlankError: false,
    ListingRatePositiveError: false,
    StartTimeBlankError: false,
    StartTimeMinError: false,
    StartTimeMaxError: false,
    EndTimeBlankError: false,
    EndTimeMinError: false,
    LockupTimeBlankError: false,
    LockupTimeMinError: false,
    FirstReleaseBlankError: false,
    VestingPeriodBlankError: false,
    PresaleTokenBlankError: false,
    FeeOverError: false,
};

export {
    LaunchpadErrorInitState
};