enum Direction {
  Up = 1,
  Down,
  Left,
  Right,
}
console.log(Direction.Up);
console.log(Direction.Down);
