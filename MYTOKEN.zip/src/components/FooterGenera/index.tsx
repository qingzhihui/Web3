import React from "react";
import "./index.scss";
import { useTranslation } from "react-i18next";
import loge from "../../assets/image/loge2.png";
import Fonts1 from "../../assets/image/Twitter_Negative.png";
import Fonts2 from "../../assets/image/TelegraNegative.png";
const FooterGenera = () => {
  const { t } = useTranslation();
  return (
    <div className="FooterGenera">
      <div className="FooterGeneraTitle">
        <div className="FooterGeneraLine">
          <div className="FooterGeneraLineOIMage">
            <img src={loge} alt="" />
          </div>
          <div className="FooterGeneraLineOValue">
            {`${t(
              "We develop indie games with creative gameplay and immersive stories."
            )}`}
          </div>
        </div>
        <div className="FooterGeneraData">
          <div className="FooterGeneraItem">
            <div className="FooterGeneraItemTitle">{`${t("Learn More")}`}</div>
            <div className="FooterGeneraItemValue">
              <div> {`${t("View Proposals")}`}</div>
              <div> {`${t("Read the Vision")}`}</div>
              <div> {`${t("Read Developer Docs")}`}</div>
            </div>
          </div>
          <div className="FooterGeneraItem">
            <div className="FooterGeneraItemTitle">{`${t("Learn More")}`}</div>
            <div className="FooterGeneraItemValue">
              <div>{`${t("Blog")}`}</div>
              <div>{`${t("Read the Vision")}`}</div>
              <div>{`${t("Read Developer Docs")}`}</div>
            </div>
          </div>
          <div className="FooterGeneraItem">
            <div className="FooterGeneraItemTitle">{`${t("Learn More")}`}</div>
            <div className="FooterGeneraItemValue">
              <div>{`${t("Overview")}`}</div>
              <div>{`${t("Design")}`}</div>
              <div>{`${t("Programing")}`}</div>
              <div>{`${t("Collaborate")}`}</div>
            </div>
          </div>
        </div>
      </div>
      <div className="FooterGeneraLone">
        <div className="FooterGeneraLoneItem">
          <img src={Fonts1} alt="" />
        </div>
        <div className="FooterGeneraLoneItem">
          <img src={Fonts2} alt="" />
        </div>
      </div>
      <div className="FooterGeneraTelex">
        {`${t("All Rights Reserved. Designed & Developed by My Token")}`}
      </div>
    </div>
  );
};

export default FooterGenera;
