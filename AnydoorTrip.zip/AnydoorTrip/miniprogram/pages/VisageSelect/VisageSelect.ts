import api from '../../config/axios'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    result: [],
    UserData: [],
  },
  /**
 * 生命周期函数--监听页面加载
 */
  onLoad(options) {
    console.log(options);
    
    this.UserDataSgholebe();
  },
  UserDataSgholebe() {
    api._get('user/reserve_user_info').then(res => {
      this.setData({
        UserData: res.data.map((item: any) => {
          return { ...item, action: false }
        })
      })
    }).catch(e => {
      console.log(e);
    })
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  addDetailsShow() {
    wx.navigateTo({
      url: '../VisaOnline/VisaOnline'
    })
  },
  updateDetailsShow() {
    wx.navigateTo({
      url: '../VisaOnline/VisaOnline'
    })
  },
  oberOnClick() {
    // var pages = getCurrentPages();
    // var beforePage = pages[pages.length - 2];
    // const oBerOnData: any = [];
    // const ResultData: any = this.data.result
    // for (let index = 0; index < ResultData.length; index++) {
    //   oBerOnData.push(this.data.UserData[Number(ResultData[index])])
    // }
    // wx.navigateBack({
    //   delta: -1,
    //   success: function () {
    //     beforePage.NaveCurrent(oBerOnData);
    //   }
    // })
  },
  onChange(event: any) {
    const Data: any = this.data.UserData;
    this.setData({
      result: event.detail
    });
    const UiData = Data.map((item: any, index: any) => {
      if (Number(event.detail[index]) === index) {
        item.action = true;
      }
      return item;
    })
    this.setData({
      UserData: UiData
    });
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})