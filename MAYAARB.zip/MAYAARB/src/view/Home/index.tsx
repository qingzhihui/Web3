import { DeaultData, DigitalConversion, homedataProps } from "../../hooks/home";
import MetaMask from "../../assets/image/ico1.png";
import TrustWall from "../../assets/image/ico3.png";
import WallCont from "../../assets/image/ico5.png";
import coienARM from "../../assets/image/ico10.png";
import coye from "../../assets/image/ico2.png";
import copy from "copy-to-clipboard";
import { BigNumber, ethers } from "ethers";
import { clauseText } from "./clause";
import "./index.scss";
import {
  ArrowDownOutlined,
  DownOutlined,
  RedoOutlined,
} from "@ant-design/icons";
import { Button, MenuProps } from "antd";
import { Dropdown, message, Modal, Progress } from "antd";
import { IDOCONTRACT_ADDR, IDOCONTRACT_ABI } from "../../config/abi";
let timerGetStatus: any = 0;
import { standardTokenABI } from "../../config/standardToken";
import { useEffect, useState } from "react";
import { floatformat } from "../../utils/floatFormat";
import {
  items,
  BUSDAddress,
  MenuUser,
  connecteState,
  InstancedContract,
  ObtainAddress,
  Token0InputValueChange,
  allowance,
  FormatUnitsConver,
} from "../../hooks/config";
declare const window: Window & { ethereum: any };
let timer: any;

interface MenData {
  key?: string;
  menuurl?: string;
  tokTitle?: string;
}

const Home = () => {
  const [tokenItem, setTokenItem] = useState<MenData>({
    key: MenuUser[0].key,
    menuurl: MenuUser[0].address,
    tokTitle: MenuUser[0].label,
  });
  const [messageApi, contextHolder] = message.useMessage();
  const [homedata, setHomeData] = useState<homedataProps>(DeaultData);
  const [BusdIn, setBusdIn] = useState("");
  const [allowanState, setAllowanState] = useState(false);
  const [uliNuler, setUliNuler] = useState(
    "0x0000000000000000000000000000000000000000"
  );
  const [bulinSatate, setBulinSatate] = useState(false);
  const [eventState, setEventState] = useState({
    state: false,
    tilin: 1,
  });
  const [logading, setLogading] = useState(false);
  const generateLink = () => {
    setHomeData((paveState: any) => {
      return {
        ...paveState,
        linkIsGenerate: true,
        generateLink: `https://launchpad.artyfact.game/?ref=${homedata.walletAddr}`,
      };
    });
    localStorage.setItem(
      "link",
      `https://launchpad.artyfact.game/?ref=${homedata.walletAddr}`
    );
  };
  const closePopup = () => {
    setHomeData((paveState: any) => {
      return {
        ...paveState,
        clausePopupIsShow: false,
        clausePopupTitle: "",
      };
    });
  };
  const copyLink = () => {
    copy(homedata.generateLink as string);
    messageApi.open({
      type: "success",
      content: "Copy Successfully !",
      duration: 3,
    });
  };
  const isConnectGetdata = async () => {
    if (window.ethereum && connecteState()) {
      try {
        const tainAres: any = await ObtainAddress();
        if (tainAres.address && tainAres.address !== "") {
          setHomeData((paveState: any) => {
            return {
              ...paveState,
              isLogin: true,
              walletAddr: tainAres.address,
            };
          });
        }
      } catch (error) {
        setHomeData((paveState: any) => {
          return {
            ...paveState,
            isLogin: false,
          };
        });
      }
    }
  };
  const InitGetdataMetho = async () => {
    if (window.ethereum && connecteState()) {
      const tainAres: any = await ObtainAddress();
      const IDOContract = InstancedContract(IDOCONTRACT_ADDR, IDOCONTRACT_ABI);
      const presaleTokenAddr = await IDOContract.ICOToken();
      const preSaleTokenContract = InstancedContract(
        presaleTokenAddr,
        standardTokenABI
      );
      const decimals = await preSaleTokenContract.decimals();
      const bal = await preSaleTokenContract.balanceOf(tainAres.address);
      const sold = await IDOContract.totalSold();
      const mayasold = ethers.utils.formatUnits(sold.toString(), decimals);
      const sym = await preSaleTokenContract.symbol();
      const pri = await IDOContract.price();
      const price = ethers.utils.formatUnits(pri.toString(), decimals);
      const BUSDTokenContract = InstancedContract(
        BUSDAddress,
        standardTokenABI
      );
      const BUSDTokenDecimals = await BUSDTokenContract.decimals();
      const minbuy = await IDOContract.minAmount();
      const maxbuy = await IDOContract.maxAmount();
      const minAmountFormat = ethers.utils.formatUnits(
        minbuy.toString(),
        BUSDTokenDecimals
      );
      const maxAmountFormat = ethers.utils.formatUnits(
        maxbuy.toString(),
        BUSDTokenDecimals
      );
      setHomeData((paveState: any) => {
        return {
          ...paveState,
          MAYABalance: ethers.utils.formatUnits(bal.toString(), decimals),
          MAYASold: mayasold,
          MAYASymbol: sym,
          MAYAPrice: price,
          minAmountFormat: minAmountFormat,
          maxAmountFormat: maxAmountFormat,
        };
      });
    }
  };
  const DroMenuClick: MenuProps["onClick"] = (e) => {
    MenuUser.map((item: any) => {
      if (item.key === e.key) {
        setTokenItem({
          key: item.key,
          menuurl: item.address,
          tokTitle: item.label,
        });
        allowanBuitem(item.address, IDOCONTRACT_ADDR);
      }
    });
  };
  const allowanBuitem = async (tokenAddress: string, lockAddress: string) => {
    if (tokenAddress !== "0x0000000000000000000000000000000000000000") {
      const allowan = await allowance(tokenAddress, lockAddress);
      const MaxUint256: BigNumber = BigNumber.from(
        "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
      );
      if (allowan.gte(MaxUint256)) {
        setAllowanState((state) => {
          return (state = true);
        });
      } else {
        setAllowanState((state) => {
          return (state = false);
        });
      }
    } else {
      setAllowanState((state) => {
        return (state = true);
      });
    }
  };
  useEffect(() => {
    if (window.location.search !== "") {
      const url = window.location.search;
      setUliNuler(url.split("?ref=")[1]);
    }
  }, [uliNuler]);
  useEffect(() => {
    if (window.ethereum && connecteState()) {
      const ethereum = window.ethereum;
      ethereum.on("accountsChanged", (accounts: any) => {
        isConnectGetdata();
        InitGetdataMetho();
        allowanBuitem(tokenItem.menuurl as string, IDOCONTRACT_ADDR);
        setHomeData((paveState: any) => {
          return {
            ...paveState,
            generateLink: `https://launchpad.artyfact.game/?ref=${accounts[0]}`,
          };
        });
      });
    }
  }, []);
  useEffect(() => {
    timerGetStatus = setInterval(async () => {
      const connecteState = localStorage.getItem("wagmi.connected");
      if (connecteState !== null && connecteState !== undefined) {
        isConnectGetdata();
        InitGetdataMetho();
        allowanBuitem(tokenItem.menuurl as string, IDOCONTRACT_ADDR);
        clearInterval(timerGetStatus);
      } else {
        setHomeData(DeaultData);
      }
    }, 1500);
    return () => {
      clearInterval(timerGetStatus);
    };
  }, []);
  useEffect(() => {
    if (!homedata.isLogin) {
      setHomeData((paveState: any) => {
        return {
          ...paveState,
          walletAddr: "",
          linkIsGenerate: false,
        };
      });
    }
  }, [window]);
  const debTokenInputChangeounce = (value: any) => {
    setHomeData((paveState: any) => {
      return {
        ...paveState,
        Token0Input: floatformat(value),
      };
    });
    clearTimeout(timer);
    timer = setTimeout(async () => {
      if (value !== "") {
        const key: any = tokenItem.key;
        const TokeNUmer: any = await Token0InputValueChange(value, key);
        setHomeData((paveState: any) => {
          return {
            ...paveState,
            Token1Input: TokeNUmer.amountOut,
          };
        });
        setBusdIn((state: any) => {
          return (state = TokeNUmer.amountBusdIn);
        });
        const Contract = InstancedContract(
          tokenItem.menuurl as string,
          standardTokenABI
        );
        const { address } = (await ObtainAddress()) as any;
        const binel = await Contract.balanceOf(address);
        const decimals = await Contract.decimals();
        if (Number(value) <= Number(FormatUnitsConver(binel, decimals))) {
          setBulinSatate(true);
          setEventState({
            state: false,
            tilin: 1,
          });
        } else {
          setBulinSatate(false);
          setEventState({
            state: true,
            tilin: 1,
          });
        }
        if (Number(value) >= Number(homedata.minAmountFormat)) {
          setBulinSatate(true);
        } else {
          setBulinSatate(false);
          setEventState({
            state: true,
            tilin: 2,
          });
        }
        if (Number(value) <= Number(homedata.maxAmountFormat)) {
          setBulinSatate(true);
        } else {
          setBulinSatate(false);
          setEventState({
            state: true,
            tilin: 3,
          });
        }
      } else {
        setEventState({
          state: false,
          tilin: 1,
        });
        setBulinSatate(false);
        setHomeData((paveState: any) => {
          return {
            ...paveState,
            Token1Input: "0.0",
          };
        });
      }
    }, 1000);
  };
  const ApproveONclick = async () => {
    console.log("123");
    try {
      console.log("123");
      const Contract = InstancedContract(
        tokenItem.menuurl as string,
        standardTokenABI
      );
      const MaxUint256: BigNumber = BigNumber.from(
        "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
      );

      const approve = await Contract.approve(IDOCONTRACT_ADDR, MaxUint256);
      setLogading(true);
      await approve.wait();
      setAllowanState((state) => {
        return (state = true);
      });
      setLogading(false);
    } catch (error) {
      console.log("123");
      setLogading(false);
      setAllowanState((state) => {
        return (state = false);
      });
    }
  };
  const WallConliBuY = async () => {
    try {
      let varNumer = BigNumber.from(0);
      if (tokenItem.menuurl === "0x0000000000000000000000000000000000000000") {
        varNumer = ethers.utils.parseEther(homedata.Token0Input as string);
      }
      const ContractDecimals = InstancedContract(
        tokenItem.menuurl as string,
        standardTokenABI
      );
      const ContractIDO = InstancedContract(IDOCONTRACT_ADDR, IDOCONTRACT_ABI);
      const decimals = await ContractDecimals.decimals();
      const tokeNuler = DigitalConversion(
        homedata.Token0Input as string,
        decimals
      );
      const BuY = await ContractIDO.buy(
        tokenItem.menuurl as string,
        tokeNuler,
        BusdIn,
        uliNuler,
        {
          value: varNumer,
        }
      );
      setLogading(true);
      await BuY.wait();
      setLogading(false);
    } catch (error) {
      setLogading(false);
    }
  };

  return (
    <div className="HomeComponent">
      {contextHolder}
      <Modal
        title={homedata.clausePopupTitle}
        open={homedata.clausePopupIsShow}
        onOk={closePopup}
        onCancel={closePopup}
        footer={null}
      >
        <div className="clause">{clauseText}</div>
      </Modal>
      <div className="HomeComponentItem">
        <div className="HomeComponentItemTilei">
          <div className="ItemHowerTitle">Presale</div>
          <div className="ComponentItemHower">
            <div className="ItemTileiLent">
              <div className="ItemBalance">
                <div className="ItemBalanceSon">
                  {Number(homedata.MAYABalance)}
                </div>
                <div className="ItemBalanceSon">
                  {Number(homedata.MAYASold)}
                </div>
              </div>
              <div className="ItemBalance">
                <div className="ItemBalanceFon">
                  Your {homedata.MAYASymbol} Balance
                </div>
                <div className="ItemBalanceFon">{homedata.MAYASymbol} Sold</div>
              </div>
              <div className="ItemPrice">
                <Progress
                  percent={30}
                  strokeColor="#F95192"
                  format={(percent: any) => {
                    return `$${percent}`;
                  }}
                />
              </div>
              <div className="ItemFunea">
                <div className="ItemFuneaItem">
                  {homedata.MAYASymbol} Price: {homedata.MAYAPrice}
                </div>
                <div className="ItemFuneaItem">Soft Target:$392,000</div>
                <div className="ItemFuneaItem">Hard Target:$784,000</div>
              </div>
              <div className="ItemNuers">
                <div className="ItemTileiRentValue">
                  Bonus 3% from $2500 purchase, bonus 5% from $5000
                </div>
              </div>
              <div className="ItemImali">
                <div className="ItemImali_imge">
                  <img src={MetaMask} alt="" />
                </div>
                <div className="ItemImali_imge asioer">
                  <img src={TrustWall} alt="" />
                </div>
                <div className="ItemImali_imge">
                  <img src={WallCont} alt="" />
                </div>
              </div>
            </div>
            <div className="ItemTileiRent">
              <div className="ItemTileiRentItem">
                <div className="ItemTirenInputData">
                  <div className="ItemTirenInputone">
                    <div className="ItemTirenInputoneTeleb">
                      <Dropdown menu={{ items, onClick: DroMenuClick }}>
                        <Button onClick={(e) => e.preventDefault()}>
                          <div className="ItemTirenInputoPuoen">
                            <img src={coienARM} alt="" />
                            <div className="ItemTirenPuoenValue">
                              {tokenItem.tokTitle}
                            </div>
                            <DownOutlined style={{ fontSize: "13px" }} />
                          </div>
                        </Button>
                      </Dropdown>
                    </div>
                    <div className="ItemTirenInputoneNrowl">
                      <input
                        type="text"
                        placeholder="0.0"
                        value={homedata.Token0Input || ""}
                        onChange={(e) => {
                          debTokenInputChangeounce(e.target.value);
                        }}
                      />
                    </div>
                  </div>
                  <div className="ItemTirenICones">
                    <div className="ItemTirenIConesItem">
                      <ArrowDownOutlined twoToneColor="#F95192" />
                    </div>
                  </div>
                  <div className="ItemTirenInputtwo">
                    <div className="ItemTirenInputoneTeleb">
                      <div className="ItemTirenInputoPuoen">
                        <img src={coienARM} alt="" />
                        <div className="ItemTirenPuoenValue">
                          {homedata.MAYASymbol}
                        </div>
                      </div>
                    </div>
                    <div className="ItemTirenInputoneNrowl">
                      <input
                        type="text"
                        placeholder="0.0"
                        disabled={true}
                        value={homedata.Token1Input || ""}
                      />
                    </div>
                  </div>
                </div>
                <div className="ItemTirenTeles">
                  <div className="ItemTirenTelesItem">
                    <span>MINIMUM BUY：</span>{" "}
                    {Number(homedata.minAmountFormat) | 0}
                  </div>
                  <div className="ItemTirenTelesItem">
                    <span>MAX：</span> {Number(homedata.maxAmountFormat) | 0}
                  </div>
                </div>
                <div className="ItemTirenLuins">
                  <div className="ItemTirenLuinsValue">
                    {" "}
                    To purchase {homedata.MAYASymbol} confirm 2 transactions:
                  </div>
                  <div className="ItemTirenLuinsValue">
                    {" "}
                    1. Approve token balance.
                  </div>
                  <div className="ItemTirenLuinsValue">
                    2. Buy {homedata.MAYASymbol}. If no transactions are
                    received to your wallet, reconnect the wallet to the
                    launchpad
                  </div>
                </div>
                {eventState.state ? (
                  <div className="eventData">
                    <div className="eventDataItem">
                      {eventState.tilin === 1 ? (
                        <div>Tip：Token balance less than amount</div>
                      ) : eventState.tilin === 2 ? (
                        <div>Tip：Amount greater than the minimum</div>
                      ) : (
                        <div>Tip：Amount less than the maximum</div>
                      )}
                    </div>
                  </div>
                ) : (
                  ""
                )}

                <div className="ItemTirenbtone">
                  {homedata.walletAddr !== "" ? (
                    <>
                      {allowanState ? (
                        <>
                          {bulinSatate ? (
                            <button
                              onClick={() => {
                                WallConliBuY();
                              }}
                            >
                              <span>Buy</span>
                              {logading ? (
                                <div className="piseLoce">
                                  <RedoOutlined spin />
                                </div>
                              ) : (
                                ""
                              )}
                            </button>
                          ) : (
                            <button disabled className="ButyPoe">
                              Buy
                            </button>
                          )}
                        </>
                      ) : (
                        <button
                          onClick={() => {
                            ApproveONclick();
                          }}
                        >
                          <span>Approve</span>
                          {logading ? (
                            <div className="piseLoce">
                              <RedoOutlined spin />
                            </div>
                          ) : (
                            ""
                          )}
                        </button>
                      )}
                    </>
                  ) : (
                    <button>Connect Wallet</button>
                  )}
                </div>
                <div className="ItemTirenFoonte">
                  By making a purchase of {homedata.MAYASymbol} tokens, you
                  agree to the{" "}
                  <span
                    className="clause_textdec"
                    onClick={() => {
                      setHomeData((paveState: any) => {
                        return {
                          ...paveState,
                          clausePopupIsShow: true,
                        };
                      });
                    }}
                  >
                    Terms
                  </span>
                  ,
                  <span
                    className="clause_textdec"
                    onClick={() => {
                      setHomeData((paveState: any) => {
                        return {
                          ...paveState,
                          clausePopupIsShow: true,
                        };
                      });
                    }}
                  >
                    Privacy Policy
                  </span>
                  and{" "}
                  <span
                    className="clause_textdec"
                    onClick={() => {
                      setHomeData((paveState: any) => {
                        return {
                          ...paveState,
                          clausePopupIsShow: true,
                        };
                      });
                    }}
                  >
                    Legal Notice
                  </span>
                  .
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="HomeComponentItemFonte">
          <div className="HomeComponentItemTalie">My referral link:</div>
          <div className="ItemFonteNrokn">
            <div
              className="ItemFonteNroknTitle"
              style={{
                justifyContent: homedata.linkIsGenerate ? "initial" : "center",
              }}
            >
              {homedata.linkIsGenerate
                ? homedata.generateLink
                : "Generate your referral link!"}
            </div>
            <div
              className="ItemFonteNroknValeu"
              onClick={() => {
                copyLink();
              }}
            >
              <img src={coye} alt="" />
              <span>Copy</span>
            </div>
          </div>
          <div className="ItemFonteButon">
            {homedata.isLogin ? (
              <>
                {homedata.linkIsGenerate ? (
                  <button
                    style={{ background: "#999", cursor: "not-allowed" }}
                    onClick={() => {}}
                  >
                    Generate link
                  </button>
                ) : (
                  <button
                    style={{ background: "#f95192", cursor: "pointer" }}
                    onClick={() => {
                      generateLink();
                    }}
                  >
                    Generate link
                  </button>
                )}
              </>
            ) : (
              <button
                style={{ background: "#999", cursor: "not-allowed" }}
                onClick={() => {}}
              >
                Generate link
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
