import {FormEvent, useEffect, useRef, useState} from "react";
import "./index.scss"
import $ from "jquery"

type Props = {
  list: {
    label: string,
    value: string
  }[]
  active: string
  onChange?(item: {label: string, value: string}):void
}

export default function Select(props: Props) {
  const [current, setCurrent] = useState({label: "", value: ""})
  useEffect(() => {
    setCurrent(
      props.list.find(item => item.value === props.active) ?? {label: "", value: ""}
    )
  }, [props.active, props.list])
  const ref = useRef(null)

  function toggleOpen() {
    if (ref.current) {
      if ($(ref.current).hasClass("active")) {
        $(ref.current).removeClass("active")
        $(ref.current).children(".select-list").slideUp()
      } else {
        $(ref.current).addClass("active")
        $(ref.current).children(".select-list").slideDown()
      }
    }
  }
  return (
    <div className="select" ref={ref} onClick={toggleOpen}>
      <span className="select-text">{current.label}</span>
      <img src="/img/down.png" alt=""/>
      <div className="select-list">
        {
          props.list.map((item, key) => {
            return <div className="select-item" key={key} onClick={() => {
              if (props.onChange) {
                props.onChange(item)
              }
            }}>{item.label}</div>
          })
        }
      </div>
    </div>
  )
}