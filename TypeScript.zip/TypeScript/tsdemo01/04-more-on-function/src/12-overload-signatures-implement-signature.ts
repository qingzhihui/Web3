// 因为在重载函数中必须要求我们传递一个参数
// function fn(x: string): void;
// 实现签名我们不传递参数会报错，
// 因为我们在我们是看不到实现函数这个签名里面的参数的，
// 我们只能看到重载签名这个参数的约束
// function fn() {}

// fn('hello')

// function fn(x: boolean): void;
// function fn(x: string): void;
// function fn(x: boolean | string) {}

// function fn(x: string): string;
// function fn(x: boolean): boolean;
// function fn(x: string | boolean): string | boolean {
//     return true
// }
