import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import tabler_droplet_share from "../../assets/image/tabler_droplet-share.png";
import FooterGenera from "../../components/FooterGenera";
import {
  ico1,
  ico2,
  ico3,
  ico4,
  ico5,
  flab,
  Guin2,
  Guin3,
  Guin4,
  Guin5,
  Guin1,
  Guin6,
} from "../../hooks/home";
import "./index.scss";
import "./mobile.scss";
import { FooterComponent } from "../../styles/styles";
import { onScroll } from "../../hooks/config";

const Home = () => {
  const { t } = useTranslation();
  useEffect(() => {}, []);

  return (
    <div className="Home">
      <div className="HomeContent" id={"longTable"} onScroll={onScroll}>
        <div className="HomeComponentPlonks">
          <div className="HomeContentItem">
            <div className="HomeComponentBuien">
              <div className="HomeComponentBuienItem">
                <div className="HomeComponentBuienValine">
                  <div className="BuienItemValiue">
                    {`${t(
                      "MyToken is a DAO autonomous community dedicated to utilizing blockchain technology to develop high-quality ecological applications, maximizing the value of technology and continuously creating wealth for ecological builders."
                    )}`}
                  </div>
                  <div className="BuienItemButtonBox">
                    <div className="BuienItemButton">
                      <button> {`${t("GET STARTED")}`}</button>
                    </div>
                    <div className="BuienItemButton BuienItemButton2">
                      <button>
                        {`${t("LEARN MORE")}`}
                        <img src={tabler_droplet_share} alt="" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="HomeComponentBuienItem2"></div>
            </div>
          </div>
          <div className="HomeComponentWorks">
            <div className="HomeWorksHowDev">
              <div className="HomeWorksHow">
                <div className="HomeWorksTitle">{`${t(
                  "Ecological applications"
                )}`}</div>
                <div className="HomeWorksRole">
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico1} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">{`${t(
                      "Wallet"
                    )}`}</div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "A wallet that supports multiple public chains and can achieve on chain cross chain and high security."
                      )}`}
                    </div>
                  </div>
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico2} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">
                      {`${t("Distributed Exchange")}`}
                    </div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "A decentralized trading tool with ultra fast computing power and support for exchange and matching transactions."
                      )}`}
                    </div>
                  </div>
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico3} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">{`${t(
                      "Public Blockchain"
                    )}`}</div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "An independent public chain with super computing power and ultra fast running speed, more suitable for various commercial applications."
                      )}`}
                    </div>
                  </div>
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico4} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">{`${t("Metaverse Mall")}`}</div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "A meta universe software that integrates social networking, entertainment, shopping, consumption and payment, better integrates reality and virtual space, and enables real economic activities."
                      )}`}
                    </div>
                  </div>
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico5} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">{`${t(
                      "Chain Game"
                    )}`}</div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "Develop various games based on one's own public chain and wallet to continuously generate revenue for ecological builders."
                      )}`}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="HomeWorksSpecieDev">
              <div className="HomeComponentSpecie">
                <div className="HomeSpecieLength">
                  <div className="HomeSpecieLengthItem">
                    <div className="HomeSpecieLengthItemTitle">
                      {`${t("WeTalk Social Tool")}`}
                    </div>
                    <div className="HomeSpecieLengthItemValue">
                      {`${t(
                        "A highly anonymous and encrypted social software that integrates functions such as social networking, wallet, trading, information, and data analysis. WeTalk will bring users a more convenient and secure communication tool. WeTalk adheres to the concept of DAO autonomy, allowing anyone to participate in ecological construction and receive corresponding rewards based on their contribution."
                      )}`}
                    </div>
                  </div>
                </div>
                <div className="HomeSpecieRental">
                  <img src={flab} alt="" />
                </div>
              </div>
            </div>
            <div className="HomeComponentFooterDev">
              <div className="HomeComponentFooter">
                <div className="HomeComponentFooterTitle">
                  {" "}
                  {`${t("Development planning")}`}
                </div>
                <div className="HomeComponentFooterVine">
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={Guin1} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      <div className="FooterItemValueNtro">
                        <span>{`${t("April 2023")}`}</span>
                      </div>
                      <div className="FooterItemValueText">
                        {`${t(
                          "MyToken launched Pancake, launched the first phase of community construction, and launched WeTalk's head mining"
                        )}`}
                      </div>
                    </div>
                  </div>
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={Guin2} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      <div className="FooterItemValueNtro">
                        <span>{`${t("October 2023")}`}</span>
                      </div>
                      <div className="FooterItemValueText">
                        {`${t(
                          "Launch WeTalk social software, launch WeTalk ecological mining, and achieve the target of over 100000000 active users in 1-3 years"
                        )}`}
                      </div>
                    </div>
                  </div>
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={Guin3} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      <div className="FooterItemValueNtro">
                        {" "}
                        <span> {`${t("2024")}`}</span>
                      </div>
                      <div className="FooterItemValueText">
                        {`${t(
                          "Launch independently developed wallets and decentralized exchanges"
                        )}`}
                      </div>
                    </div>
                  </div>
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={Guin4} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      <div className="FooterItemValueNtro">
                        {" "}
                        <span>{`${t("2025")}`}</span>
                      </div>
                      <div className="FooterItemValueText">
                        {`${t(
                          "Launch a self-developed public chain and launch the development of a metaverse mall"
                        )}`}
                      </div>
                    </div>
                  </div>
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={Guin5} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      <div className="FooterItemValueNtro">
                        {" "}
                        <span>{`${t("2026")}`}</span>
                      </div>
                      <div className="FooterItemValueText">
                        {`${t(
                          "Launch Metaverse Mall and 1-3 fun chain games"
                        )}`}
                      </div>
                    </div>
                  </div>
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={Guin6} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      <div className="FooterItemValueNtro">
                        {" "}
                        <span>{`${t("2027-2037")}`}</span>
                      </div>
                      <div className="FooterItemValueText">
                      {`${t("Achieve the goal of 500000000+users in the Metaverse Mall within 5-10 years")}`}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <FooterComponent>
            <FooterGenera />
          </FooterComponent>
        </div>
      </div>
    </div>
  );
};

export default Home;
