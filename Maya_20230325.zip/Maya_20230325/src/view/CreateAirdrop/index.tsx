import React, { useState, useEffect } from "react";
import "./index.scss";
import { Input } from "antd";
import {
  AirPrcoABI,
  AirPrcoAddress,
  CreateAidropeProps,
  URlDataProps,
} from "../../hooks/Airprcopy";
import { InstancedContract, ObtainAddress } from "../../hooks/config";
import { useHistory, useLocation } from "react-router-dom";
import ButtonLoading from "../../components/ButtonLoading";
import { useTranslation, Trans } from "react-i18next";
import { validWebsiteUrL } from '../../utils/validWebsite'
import InputError from '../../components/InputError'
import { websiteError } from '../../hooks/WebsiteErrorhandle'
import LaunchpadRoadmapPC from "../../components/RoadmapPC/LaunchpadRoadmapPC"
import PrivateSaleRoadmapPC from "../../components/RoadmapPC/PrivateSaleRoadmapPC"
import LaunchpadRoadmapMobile from "../../components/RoadmapMobile/LaunchpadRoadmapMobile"
import PrivateSaleRoadmapMobile from "../../components/RoadmapMobile/PrivateSaleRoadmapMobile"
import { SocialMediaErrorState } from "../../state/SocialMediaErrorState";
const { TextArea } = Input;
declare const window: Window & { ethereum: any };
const Airdrop: React.FC = (props: any) => {
  let history = useHistory();
  const { state } = useLocation<any>();
  const [userLine, setUserLine] = useState<string>("");
  const [userInputValue, setUserInputValue] = useState<CreateAidropeProps>({});
  const [BuiotnShow, setBuiotnShow] = useState<boolean>(false);
  const [URlData, setURlData] = useState<URlDataProps>({});
  const [loading, setLoading] = useState<boolean>(false);
  const [URLName, setURLName] = useState<string>("");
  const [webError, setWebError] = useState<websiteError>(SocialMediaErrorState)

  // 开启或者关闭错误提示 
  const setError = (content: string, value: boolean) => {
    setWebError((olddata: websiteError) => {
      return {
        ...olddata,
        [content]: !value,
      };
    });
  }

  const { t } = useTranslation();
  const NextOnCLikc = async () => {
    try {
      setLoading(true);
      const Contract = InstancedContract(AirPrcoAddress, AirPrcoABI) as any;
      const { address } = await ObtainAddress() as any;
      const create = await Contract.create(
        address,
        userLine,
        `${userInputValue.Title},${userInputValue.LogoURL},${userInputValue.Website},${userInputValue.Facebook},${userInputValue.Twitter},${userInputValue.Github},${userInputValue.Telegram},${userInputValue.Instagram},${userInputValue.Discord},${userInputValue.Reddit},${userInputValue.Description}`
      );
      await create.wait();
      setLoading(false);
    } catch (error) {
      setLoading(false);
    }
  };
  const RluoerOnCLikc = async () => {
    console.log('RluoerOnCLikc ', URlData)
    history.push({
      pathname: "/Burn",
      state: {
        data: URlData,
        Userfiel: userInputValue,
        libns: `${userInputValue.Title},${userInputValue.LogoURL},${userInputValue.Website},${userInputValue.Facebook},${userInputValue.Twitter},${userInputValue.Github},${userInputValue.Telegram},${userInputValue.Instagram},${userInputValue.Discord},${userInputValue.Reddit},${userInputValue.Description}`,
      },
    });
  };
  const BackOnClick = () => {
    history.push({
      pathname: "/WhiteList",
      state,
    });
  };
  useEffect(() => { }, [URlData, URLName]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          console.log(state);
          if (state.PoleieData != undefined) {
            setURlData((data: URlDataProps) => {
              return (data = state);
            });
            const { inputValue, routeName } = state.PoleieData;
            setUserLine(inputValue);
            setURLName(routeName);
            if (state.UrlName === "WhiteList") {
              setBuiotnShow((state: boolean) => {
                return (state = true);
              });
            }
          } else {
            const { inputValue, routeName } = state.data.PoleieData;
            setUserLine(inputValue);
            setURLName(routeName);
            console.log(URLName);
            setURlData((data: URlDataProps) => {
              return (data = state.data);
            });
            setUserInputValue((InputValueData: CreateAidropeProps) => {
              return (InputValueData = state.Userfiel);
            });
            if (state.data.UrlName === "WhiteList") {
              setBuiotnShow((state: boolean) => {
                return (state = true);
              });
            }
          }
        }
      }
    }
  }, []);

  // onblur
  const validwebInput = (key: string, value: string) => {
    setError(key, validWebsiteUrL(key, value))
  }

  const isNext = () => {
    if (
      validWebsiteUrL("LogoUrl", userInputValue.LogoURL as string)
      &&
      validWebsiteUrL("Website", userInputValue.Website as string)
    ) {
      return true
    } else {
      return false
    }
  }

  return (
    <div className="CreateAirdrop">
      <div className="CreateAirdrop_countent">
        <div className="title">{`${t("Create New Launchpad")}`}</div>
        <div className="CreateAirdrop_table">
          <div className="attention">(*) {`${t("is required field.")}`}</div>
          <div className="titleinput">
            <div className="titleipt">{`${t("Airdrop Title")}`}</div>
            <div className="inputs">
              <Input
                placeholder={`${t("Ex: Join my mayasale airdrop")}`}
                bordered={false}
                value={userInputValue.Title || ""}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  setUserInputValue((olddata: any) => {
                    return {
                      ...olddata,
                      Title: e.target.value,
                    };
                  });
                }}
              />
            </div>
          </div>
          <div className="logoweinput">
            <div className="urlinput">
              <div className="titlelo">
                {`${t("Logo URL")}`} <span>*</span>
              </div>
              <div className="inputs" style={{ borderColor: webError.LogoUrl ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://images.youwant.io/...")}`}
                  bordered={false}
                  value={userInputValue.LogoURL || ""}
                  onBlur={(e) => { validwebInput("LogoUrl", e.target.value) }}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        LogoURL: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon99.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.LogoUrl ? <InputError title="Invalid website" /> : ''}
              <div className="lourl">
                {`${t(
                  "URL must end with a supported image extension png, jpg, jpeg or gif. You can upload your image at"
                )}`}{" "}
                <a href="">https://images.youwant.io/</a>
              </div>
            </div>
            <div className="weinput">
              <div className="titlewe">
                {`${t("Website")}`} <span>*</span>
              </div>
              <div className="inputs" style={{ borderColor: webError.Website ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://...")}`}
                  bordered={false}
                  value={userInputValue.Website || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Website: e.target.value,
                      };
                    });
                  }}
                  onBlur={(e) => { validwebInput("Website", e.target.value) }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon22.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Website ? <InputError title="Invalid website" /> : ''}
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Facebook</div>
              <div className="inputs" style={{ borderColor: webError.Facebook ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://facebook.com/...")}`}
                  bordered={false}
                  value={userInputValue.Facebook || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Facebook: e.target.value,
                      };
                    });
                  }}
                  onBlur={(e) => { validwebInput("Facebook", e.target.value) }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon88.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Facebook ? <InputError title="Invalid website" /> : ''}
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Twitter</div>
              <div className="inputs" style={{ borderColor: webError.Twitter ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://twitter.com/...")}`}
                  bordered={false}
                  value={userInputValue.Twitter || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Twitter: e.target.value,
                      };
                    });
                  }}
                  onBlur={(e) => { validwebInput("Twitter", e.target.value) }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon66.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Twitter ? <InputError title="Invalid website" /> : ''}
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Github</div>
              <div className="inputs" style={{ borderColor: webError.Github ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://github.com/...")}`}
                  bordered={false}
                  value={userInputValue.Github || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Github: e.target.value,
                      };
                    });
                  }}
                  onBlur={(e) => { validwebInput("Github", e.target.value) }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon11.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Github ? <InputError title="Invalid website" /> : ''}
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Telegram</div>
              <div className="inputs" style={{ borderColor: webError.Telegram ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://t.me/...")}`}
                  bordered={false}
                  value={userInputValue.Telegram || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Telegram: e.target.value,
                      };
                    });
                  }}
                  onBlur={(e) => { validwebInput("Telegram", e.target.value) }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon55.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Telegram ? <InputError title="Invalid website" /> : ''}
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Instagram</div>
              <div className="inputs" style={{ borderColor: webError.Instagram ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://instagram.com/...")}`}
                  bordered={false}
                  value={userInputValue.Instagram || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Instagram: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon33.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Instagram ? <InputError title="Invalid website" /> : ''}
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Discord</div>
              <div className="inputs" style={{ borderColor: webError.Discord ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://t.me/...")}`}
                  bordered={false}
                  value={userInputValue.Discord || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Discord: e.target.value,
                      };
                    });
                  }}
                  onBlur={(e) => { validwebInput("Discord", e.target.value) }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon77.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Discord ? <InputError title="Invalid website" /> : ''}
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Youtube</div>
              <div className="inputs" style={{ borderColor: webError.Youtube ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://www.youtube.com/watch?v=xxxxxxxxx")}`}
                  bordered={false}
                  value={userInputValue.Youtube || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Youtube: e.target.value,
                      };
                    });
                  }}
                  onBlur={(e) => { validwebInput("Youtube", e.target.value) }}
                  prefix={
                    <img
                      src={require("../../assets/image/youtube.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Youtube ? <InputError title="Invalid website" /> : ''}
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Reddit</div>
              <div className="inputs" style={{ borderColor: webError.Reddit ? '#f14668' : '' }}>
                <Input
                  placeholder={`${t("Ex: https://reddit.com/...")}`}
                  bordered={false}
                  value={userInputValue.Reddit || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Reddit: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon44.png")}
                      alt=""
                    />
                  }
                />
              </div>
              {webError.Reddit ? <InputError title="Invalid website" /> : ''}
            </div>
          </div>
          <div className="descriptiontext">
            <div className="titlede">{`${t("Description")}`}</div>
            <div className="inputstext">
              <TextArea
                placeholder={`${t("Ex: This is the best project...")}`}
                allowClear
                value={userInputValue.Description || ""}
                onChange={(e) => {
                  setUserInputValue((olddata: any) => {
                    return {
                      ...olddata,
                      Description: e.target.value,
                    };
                  });
                }}
              />
            </div>
          </div>
          <div className="buts">
            <button
              className="back"
              onClick={() => {
                BackOnClick();
              }}
            >{`${t("Back")}`}</button>
            {BuiotnShow === true ? <>
              {isNext() ? (
                <button
                  className="createbtn diancli"
                  onClick={() => {
                    RluoerOnCLikc();
                  }}
                >
                  {`${t("Next")}`}
                </button>
              ) : (
                <button
                  className="createbtn diancli"
                  style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
                >
                  {`${t("Next")}`}
                </button>
              )}
            </> : <>
              {isNext() ? <button
                className="createbtn diancli"
                onClick={() => {
                  NextOnCLikc();
                }}
              >
                {`${t("Next")}`}
              </button> : <button
                className="createbtn diancli"
                style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
              >
                {`${t("Next")}`}
              </button>}
            </>}
          </div>
        </div>
      </div>
      <div className="CreateAirdrop-roadmapPC">
        {URLName === "Sale" ? <PrivateSaleRoadmapPC step={3} /> : <LaunchpadRoadmapPC step={3} />}
      </div>
      <div className="CreateAirdrop-roadmapMobile">
        {URLName === "Sale" ? <PrivateSaleRoadmapMobile step={3} /> : <LaunchpadRoadmapMobile step={3} />}
      </div>
    </div>
  );
};
export default Airdrop;
