import React, { useState, useTransition } from "react";

function Index() {
  const [showCounter, setShowCounter] = useState(false);
  const [count, setCount] = useState(0);

  const [isePending, setTransition] = useTransition();

  const onClick = () => {
    setTransition(() => {
      setShowCounter((prev) => !prev);
    });

    setCount((prev) => prev + 1);
  };
  return (
    <div>
        {isePending && <h1>Loading...</h1>}
      <button onClick={onClick}>Click Me</button>
      {showCounter && <div>{count}</div>}
    </div>
  );
}

export default Index;
