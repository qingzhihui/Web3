import { login_request } from "./login_request";

let flag = false;

export const login = async () => {
  if (flag)return;
  flag = true;
  const opt = Object();
  wx.showLoading({
    title: "登陆中...",
  })
  login_request().then((res) => {
    let cookie = res.cookies[0]
    if (cookie){
      wx.setStorageSync("Cookie", cookie.split(" ")[0]);
      wx.setStorageSync("is_login", true);
    }
    opt.title = "登录成功";
    opt.icon = "suuccess";
    opt.duration = 1000;
    wx.navigateTo({ url: "/pages/chat/chat" });
  }).catch(() => {
    opt.title = "登陆失败";
    opt.icon = "error";
    opt.duration = 1000;
  }).finally(() => {
    wx.hideLoading();
    wx.showToast(opt);
    flag = false;
  })
}