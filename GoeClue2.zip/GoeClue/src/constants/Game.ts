const luiere = {
  ItemOne: {},
  ItemTwo: {},
  ItemThree: {},
  ItemFour: {},
  ItemFive: {},
  ItemSix: {},
  ItemSeven: {},
  ItemEight: {},
  ItemNine: {},
  ItemTen: {},
  ItemEleven: {}
};

export default luiere;
