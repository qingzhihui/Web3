/**
 * 获取系统信息
*/
export const systemInfo = () => {
  return wx.getSystemInfoSync();
}

/**
 * 获取胶囊的尺寸信息
 */
export const capsuleClientRect = () => {
  return wx.getMenuButtonBoundingClientRect();
}

/**
 * 获取系统状态栏高度
*/
export const statusBarHeight = () => {
  // 获取状态栏高度
  return systemInfo().statusBarHeight;
}

/**
 * 获取胶囊高度
*/
export const capsuleHeight = () => {
  // 获取胶囊高度
  return capsuleClientRect().height;
}

/**
 * 获取胶囊距离顶部高度
*/
export const capsuleTop = () => {
  // 获取胶囊高度
  return capsuleClientRect().top;
}

/**
 * 获取胶囊到状态栏的高度
*/
export const capsuleHeightToStatus = () => {
  //获取系统信息的概念
  let status_bar_height = statusBarHeight();
  // 获取胶囊距离顶部高度
  let capsule_top = capsuleTop() - status_bar_height;
  return capsule_top;
}

/**
 * 获取整个顶栏高度
*/
export const topBarHeight = () => {
  return capsuleHeightToStatus() * 2 + statusBarHeight() + capsuleHeight();
}

export default {
  systemInfo,
  capsuleClientRect,
  statusBarHeight,
  capsuleHeight,
  capsuleTop,
  capsuleHeightToStatus,
  topBarHeight
}