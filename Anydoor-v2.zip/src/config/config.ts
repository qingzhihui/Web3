import gkuo from "../assets/image/gkuo.png";
import gkuoBox from "../assets/image/gkuoBox.png";
import shez from "../assets/image/shez.png";
import shezBox from "../assets/image/shezBox.png";
import jues from "../assets/image/jues.png";
import juesBox from "../assets/image/juesBox.png";
import bij from "../assets/image/bij.png";
import bijBox from "../assets/image/bijBox.png";
import juding from "../assets/image/juding.png";
import judingBox from "../assets/image/judingBox.png";
import ycu from "../assets/image/ycu.png";
import ycuBox from "../assets/image/ycuBox.png";
import taocan from "../assets/image/taocan.png";
import taocanBox from "../assets/image/taocanBox.png";
import vip from "../assets/image/vip.png";
import vipBox from "../assets/image/vipBox.png";
import Ddang from "../assets/image/Ddang.png";
import DdangBox from "../assets/image/DdangBox.png";
import fenxiao from "../assets/image/fenxiao.png";
import fenxiaoBox from "../assets/image/fenxiaoBox.png";
import yxiao from "../assets/image/yxiao.png";
import yxiaoBox from "../assets/image/yxiaoBox.png";
import shangc from "../assets/image/shangc.png";
import shangcBox from "../assets/image/shangcBox.png";
import jpiao from "../assets/image/jpiao.png";
import jpiaoBox from "../assets/image/jpiaoBox.png";

export interface childProps {
  key?: number;
  title?: string;
  url?: string;
}
export interface RouterConfigProps {
  key?: number;
  title?: string;
  icon?: string;
  icons?: string;
  url?: string;
  children?: childProps[];
}
const RouterConfig: RouterConfigProps[] = [
  {
    key: 0,
    title: "数据概况",
    icon: gkuo,
    icons: gkuoBox,
    url: "/Admin",
  },
  {
    key: 1,
    title: "系统设置",
    icon: shez,
    icons: shezBox,
    url: "/Admin/SystemSettings",
    children: [
      {
        key: 0,
        title: "数据库配置",
        url: "",
      },
      {
        key: 1,
        title: "基础配置",
        url: "/BasicSettingsPage",
      },
      {
        key: 2,
        title: "支付配置",
        url: "/PaymentSettings",
      },
      {
        key: 3,
        title: "邮箱配置",
        url: "/MailboxSettings",
      },
      {
        key: 4,
        title: "消息通知",
        url: "/Messagenotification",
      },
      {
        key: 5,
        title: "首页导航配置",
        url: "/HomePageNavigation",
      },
      {
        key: 6,
        title: "分享海报设计",
        url: "/SharePosterDesign",
      },
      {
        key: 7,
        title: "物流运费模板配置",
        url: "/LogisticsFreightTemplate",
      },
      {
        key: 8,
        title: "数据备份",
        url: "/DataBackupPage",
      },
    ],
  },
  {
    key: 2,
    title: "角色（员工）权限",
    icon: jues,
    icons: juesBox,
    url: "/Admin/RoleEmployeePower",
    children: [
      {
        key: 0,
        title: "管理员管理",
        url: "",
      },
      {
        key: 1,
        title: "用户管理",
        url: "/UserManage",
      },
      {
        key: 2,
        title: "角色管理",
        url: "/RoleManagement",
      },
      {
        key: 3,
        title: "权限管理",
        url: "/PermissionManagement",
      },
    ],
  },
  {
    key: 3,
    title: "游记（笔记）管理",
    icon: bij,
    icons: bijBox,
    url: "/Admin/EssayNotes",
    children: [
      {
        key: 0,
        title: "文章管理",
        url: "",
      },
      {
        key: 1,
        title: "文章分类管理",
        url: "/EssayClassifyManag",
      },
      {
        key: 2,
        title: "文章评论管理",
        url: "/EssayDiscussManag",
      },
      {
        key: 3,
        title: "广告管理",
        url: "/AdvertisingManag",
      },
    ],
  },
  {
    key: 4,
    title: "酒店管理",
    icon: juding,
    icons: judingBox,
    url: "/Admin/HotelManagement",
    children: [
      {
        key: 0,
        title: "酒店类型",
        url: "",
      },
      {
        key: 1,
        title: "酒店列表",
        url: "/HotelList",
      },
      {
        key: 2,
        title: "添加酒店",
        url: "/AddHotel",
      },
      {
        key: 3,
        title: "分类管理",
        url: "/Management",
      },
      {
        key: 4,
        title: "酒店采集管理",
        url: "/HotelGatherManage",
      },
      {
        key: 5,
        title: "酒店数据汉化",
        url: "/HotelDataSinicization",
      },
      {
        key: 6,
        title: "入住管理",
        url: "/CheckInManage",
      },
    ],
  },
  {
    key: 5,
    title: "演出/展会",
    icon: ycu,
    icons: ycuBox,
    url: "/Admin/Performance",
  },
  {
    key: 6,
    title: "奢旅（酒店套餐）",
    icon: taocan,
    icons: taocanBox,
    url: "/Admin/HotelPackage",
  },
  {
    key: 7,
    title: "会员管理",
    icon: vip,
    icons: vipBox,
    url: "/Admin/MemberManagement",
    children: [
      {
        key: 0,
        title: "会员管理",
        url: "",
      },
      {
        key: 1,
        title: "付费会员",
        url: "/PaidMember",
      },
    ],
  },
  {
    key: 8,
    title: "订单管理",
    icon: Ddang,
    icons: DdangBox,
    url: "/Admin/OrderManagement",
    children: [
      {
        key: 0,
        title: "酒店订单",
        url: "/HotelOrdersPage",
      },
      {
        key: 1,
        title: "套餐订单",
        url: "/PackageOrder",
      },
      {
        key: 2,
        title: "商城订单",
        url: "/MallOrder",
      },
      {
        key: 3,
        title: "售后订单",
        url: "/AfterSalesOrders",
      },
      {
        key: 4,
        title: "订单日记",
        url: "/OrderJournal",
      },
    ],
  },
  {
    key: 9,
    title: "分销系统",
    icon: fenxiao,
    icons: fenxiaoBox,
    url: "/Admin/DistributionSystem",
    children: [
      {
        key: 0,
        title: "分销基础配置",
        url: "",
      },
      {
        key: 1,
        title: "分销商订单",
        url: "/DistributorOrders",
      },
      {
        key: 2,
        title: "分销商列表",
        url: "/DistributorListPage",
      },
      {
        key: 3,
        title: "分销提现",
        url: "/DistributorWithdrawal",
      },
      {
        key: 4,
        title: "分销排行榜",
        url: "/DistributionRankings",
      },
    ],
  },
  {
    key: 10,
    title: "营销活动",
    icon: yxiao,
    icons: yxiaoBox,
    url: "/Admin/MarketingActivities",
    children: [
      {
        key: 0,
        title: "优惠卷",
        url: "",
      },
      {
        key: 1,
        title: "限时抢购",
        url: "/FlashSale",
      },
      {
        key: 2,
        title: "整点抢购",
        url: "/Rushtourse",
      },
      {
        key: 3,
        title: "团购",
        url: "/Grourcase",
      },
      {
        key: 4,
        title: "秒杀",
        url: "/SeaMane",
      },
    ],
  },
  {
    key: 11,
    title: "积分商城",
    icon: shangc,
    icons: shangcBox,
    url: "/Admin/PointsMall",
  },
  {
    key: 12,
    title: "机票",
    icon: jpiao,
    icons: jpiaoBox,
    url: "/Admin/Passentick",
  },
];

const RouterDataCirculator = (useID: any) => {
  const RouterData: any = [];
  for (let index = 0; index < RouterConfig.length; index++) {
    if (RouterConfig[index].key === useID) {
      RouterConfig[index].children?.map((item: any) => {
        RouterData.push(item);
      });
    }
  }
  return RouterData;
};

export { RouterConfig ,RouterDataCirculator};
