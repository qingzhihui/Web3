import { Image, Input, Select, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { DeleteOutlined, AlignCenterOutlined } from "@ant-design/icons";

// 订单日记界面
const OrderJournal = () => {
  interface DataType {
    key: React.Key;
    orderNumber: string; //订单号
    orderType: string; //订单类型
    operate:string // 操作
    returnInformation: string // 返回信息
    operator: string //操作人
    createTime:string // 创建时间
  }
  const data: DataType[] = [
    {
      key: 1,
      orderNumber: "111654947818",
      orderType: "酒店订单",
      operate: "退款",
      returnInformation: "{'code':2000,'msg':'操作成功'}",
      operator: "管理员",
      createTime: "2023-01-01",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "序号",
      // width: 120,
      render: (_text, record,index) => (
        <Space size="middle">
          <span>{index+1}</span>
        </Space>
      ),
    },
    {
      title: "订单号",
      dataIndex: "orderNumber",
      // width: 120,
    },
    {
      title: "订单类型",
      dataIndex: "orderType",
      // width: 120,
    },

    {
      title: "操作",
      dataIndex: "operate",
      // width: 120,
      render: (_text, record) => (
        <Space size="middle">
          <span className="OrderJournal_operateback">{_text}</span>
        </Space>
      ),
    },
    {
      title: "返回信息",
      // width: 80,
      dataIndex: "returnInformation",
    },
    {
      title: "操作人",
      // width: 80,
      dataIndex: "operator",
    },
    {
      title: "创建时间",
      // width: 120,
      dataIndex: "createTime",
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="OrderJournal_memberCursor" onClick={lookover(record)}>
            {/* <FormOutlined /> */}
            <AlignCenterOutlined />
          </span>
          <span className="OrderJournal_memberCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 头部下拉选择框-内容
  const options1 = [
    {
      value: "1",
      label: "全部",
    },
    {
      value: "2",
      label: "部分",
    },
  ];

  // 头部下拉选择框-内容---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };
  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 查看
  const lookover = (record: any) => {
    return () => {
      console.log("点击了查看");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };

  return (
    <div className="OrderJournal_Box">
      <div className="OrderJournal_headerBox">
        <div className="OrderJournal_headerBox_thread"></div>
        <div className="OrderJournal_headerBox_Tit">&nbsp;&nbsp;&nbsp; 订单日记</div>
        <div className="OrderJournal_Add_moban">
          <div className="OrderJournal_seekBtn" onClick={adminSearch}>
            <Select
              labelInValue
              defaultValue={{ value: "1", label: "全部" }}
              style={{ width: 120 }}
              onChange={handleChange1}
              options={options1}
            />
          </div>
        </div>
      </div>

      <div className="OrderJournal_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default OrderJournal;
