type voidFunc = () => void;

const f1: voidFunc = () => {
  return true;
};
const f3: voidFunc = () => true;


const f4: voidFunc = () => function(){
    return true
};

const v1:void = f1()
const v2 = f2()
const v3 = f4()


// 错误
// function f5():void{
//     return true
// }


// 错误
// const f6 = function():void{
//     return true
// }