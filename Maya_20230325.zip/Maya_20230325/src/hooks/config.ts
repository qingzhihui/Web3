import React from "react";
import type { MenuProps } from "antd";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import { WBENJson } from "../config/abi/wbenjson";
import moment from "moment";

declare const window: Window & { ethereum: any };
export type MenuItem = Required<MenuProps>["items"][number];

export interface Lineg {
  name?: string;
  symbol?: string;
  decimals?: string;
  balanceOf?: string;
}
const getItem = (
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
  type?: "group",
  router?: string
): MenuItem => {
  return {
    key,
    icon,
    children,
    label,
    type,
    router,
  } as MenuItem;
};
const allowance = async (tokenAddress: string, lockAddress: string) => {
  const { address } = await ObtainAddress()  as any;
  const allowance = await (InstancedContract(tokenAddress, WBENJson) as any).allowance(
    address,
    lockAddress
  );
  return allowance;
};

const InstancedContract = (address: any, abi: any) => {
  if(window.ethereum){
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const Contract = new ethers.Contract(address, abi, signer);
    return Contract;
  } else {
    return
  }
};

const DigitalConversion = (parameter: any, numerical: any) => {
  const DigitalValue = new BigNumber(parameter)
    .times(new BigNumber(10).pow(numerical))
    .toFixed();
  return DigitalValue;
};

const ObtainAddress = async () => {
  if(window.ethereum){
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const balance = await signer.getBalance();
    return {
      address,
      balance,
    };
  } else {
    return
  }
};
const TokenNameDecimals = async (addresNUi: any) => {
  const { address } = await ObtainAddress() as any;
  const name = await (InstancedContract(addresNUi, WBENJson) as any).name();
  const symbol = await (InstancedContract(addresNUi, WBENJson) as any).symbol();
  const decimals = await (InstancedContract(addresNUi, WBENJson) as any).decimals();
  const balanceOfValue = await (InstancedContract(addresNUi, WBENJson) as any).balanceOf(
    address
  );
  const balanceOf = ethers.utils.formatUnits(balanceOfValue.toString());
  return {
    name,
    symbol,
    decimals,
    balanceOf,
  };
};


const TimestampToTime = (timestamp: any) => {
  var date = new Date(timestamp * 1000);
  var Y = date.getFullYear() + "-";
  var M =
    (date.getMonth() + 1 < 10
      ? "0" + (date.getMonth() + 1)
      : date.getMonth() + 1) + "-";
  var D = (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + " ";
  var h = date.getHours() + ":";
  var m = date.getMinutes() + ":";
  var s = date.getSeconds();
  return Y + M + D + h + m + s;
};

const convertLocalDateToUTCIgnoringTimezone = (utcDate: Date) => {
  const utcres = moment(utcDate).utc();
  return utcres;
};

const FormatUnitsConver = (amount: any, decimals: any) => {
  const FormatUnitsValue = ethers.utils.formatUnits(amount, decimals);
  return FormatUnitsValue;
};

export {
  getItem,
  InstancedContract,
  DigitalConversion,
  ObtainAddress,
  allowance,
  TokenNameDecimals,
  TimestampToTime,
  FormatUnitsConver,
  convertLocalDateToUTCIgnoringTimezone,
};
