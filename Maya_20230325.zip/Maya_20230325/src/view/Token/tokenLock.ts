import { ethers } from "ethers";
import {
  InstancedContract,
  ObtainAddress,
  TokenNameDecimals,
} from "../../hooks/config";
import { CreatelockABI, CreatelockAddress } from "../../hooks/Createlock";
export interface DataType {
  key: React.Key;
  token: any;
  amount: string;
}

const getCumulativeData = async () => {
  const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
  const allNormalTokenLockedCount = await Contract.allNormalTokenLockedCount();
  var TokenItem: DataType[] = [];
  if (Number(allNormalTokenLockedCount.toString()) > 0) {
    const getCumulativeNormalTokenLockInfo =
      await Contract.getCumulativeNormalTokenLockInfo(
        0,
        allNormalTokenLockedCount.toString()
      );
    getCumulativeNormalTokenLockInfo.map(async (item: any, index: number) => {
      const TokenData = await TokenNameDecimals(item.token);
      TokenItem.push({
        key: index,
        token: {
          name: TokenData.name,
          addres: item.token,
          symbol: TokenData.symbol,
          decimals: TokenData.decimals,
          balanceOf: TokenData.balanceOf,
        },
        amount: ethers.utils.formatUnits(
          item.amount.toString(),
          TokenData.decimals
        ),
      });
    });
  }
  return TokenItem;
};

const normalLocksForUser = async () => {
  const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
  const { address } = await ObtainAddress() as any;
  const normalLocksForUser = await Contract.normalLocksForUser(address);
  const ForUserItem: DataType[] = [];
  normalLocksForUser.map(async (item: any, index: number) => {
    const TokenData = await TokenNameDecimals(item.token);
    ForUserItem.push({
      key: index,
      token: {
        name: TokenData.name,
        addres: item.token,
        symbol: TokenData.symbol,
        decimals: TokenData.decimals,
        balanceOf: TokenData.balanceOf,
      },
      amount: ethers.utils.formatUnits(
        item.amount.toString(),
        TokenData.decimals
      ),
    });
  });
  return ForUserItem;
};

export { getCumulativeData, normalLocksForUser };
