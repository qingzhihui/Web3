module.exports = {
  basePath: "/introducing-react-17",
  assetPrefix: "/introducing-react-17/",
};
