import React, { Component } from "react";
import "./index.scss";
import limg1 from "../../assets/s6.png";
import limg2 from "../../assets/s7.png";
import limg3 from "../../assets/s8.png";
import limg4 from "../../assets/1_10.png";
import zhoimg from "../../assets/xz1.png";
import yunimg from "../../assets/xz2.png";
import libimg from "../../assets/Phase.png";
import img01 from "../../assets/01.png";
import img02 from "../../assets/02.png";
import img03 from "../../assets/03.png";
import img04 from "../../assets/04.png";
import ExhIundev from '../../components/ExhIundev'

export default class index extends Component {
  render() {
    return (
      <div className="Luenes">
        <div className="Luenesdom" id='activity1'>
          <div className="Luen_title">
            <div className="sluines">
              <span>ABOUT EMOER</span>
              <div className="lihr"></div>
            </div>
          </div>
          <div className="uslins">
            <div className="uniList">
              <div className="unitem">
                <div className="iems">
                  <div className="iemsimg">
                    <img src={limg1} />
                  </div>
                  <div className="iemsbit">
                    <span>SWAP</span>
                  </div>
                  <div className="iemsnro">
                    <span>
                      Swap between tokens on the Emoer network at the lowest
                      fees
                    </span>
                  </div>
                </div>
              </div>
              <div className="unitem">
                <div className="iems">
                  <div className="iemsimg">
                    <img src={limg2} />
                  </div>
                  <div className="iemsbit">
                    <span>LIQUIDITY</span>
                  </div>
                  <div className="iemsnro">
                    <span>
                      Swap between tokens on the Emoer network at the lowest
                      fees
                    </span>
                  </div>
                </div>
              </div>
              <div className="unitem">
                <div className="iems">
                  <div className="iemsimg">
                    <img src={limg3} />
                  </div>
                  <div className="iemsbit">
                    <span>FARMS</span>
                  </div>
                  <div className="iemsnro">
                    <span>
                      Swap between tokens on the Emoer network at the lowest
                      fees
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="LuenesLlin" id='activity2'>
          <div className="Luen_title">
            <div className="sluines">
              <span>SOCIETY BENEFITS</span>
              <div className="lihr"></div>
            </div>
          </div>
          <div className="nrlise">
            <div className="nrliseimg">
              <img src={limg4} />
            </div>
            <div className="nrlisenro">
              <div className="snieros">
                <div className="nrlisenro_tiler">
                  <span>Growth = Goodness</span>
                </div>
                <div className="nrlisenro_tinr">
                  <span>
                    Shiba Fantom is committed to donating a portion of proceeds
                    to both developers improving the crypto space for all users
                    and verified animal shelters in need. The more we grow, the
                    more we can give back to communities that are fostering
                    positivity.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="nuleiskus" id='activity3'>
          <div className="Luen_title">
            <div className="sluines">
              <span>ROABMAP</span>
              <div className="lihr"></div>
            </div>
          </div>
          <div className="Lenuerd">
            <div className="Lenuitem">
              <div className="zuoshei">
                <img src={zhoimg} />
              </div>
              <div className="nroleui">
                <div className="nroleui_title">
                  <img src={libimg} />
                </div>
                <div className="nroleui_nro">
                  <img src={img01} />
                  <div className="tilieles">
                    V1 Unapologetic Apes mint is live
                    <br />
                    Acquire nodes and begin the once-a-week raffle
                    <br />
                    distribution of nodes. The 1st nodes will be $Strong and
                    <br />
                    $Fire nodes.
                    <br /> Prepare for the launch of the 1st Ape crate
                    subscriptions. Get your exclusive crate of Unapologetic Ape
                    themed
                    <br /> gear.
                  </div>
                </div>
              </div>
              <div className="zuoshle">
                <img src={yunimg} />
              </div>
            </div>
            <div className="Lenuitem">
              <div className="zuoshei">
                <img src={zhoimg} />
              </div>
              <div className="nroleui">
                <div className="nroleui_title">
                  <img src={libimg} />
                </div>
                <div className="nroleui_nro">
                  <img src={img02} />
                  <div className="tilieles">
                    Intensified marketing,
                    <br /> includingreaching out to
                    <br /> prominent fashion brands for
                    <br /> collaborations.Merch Store to
                    <br />
                    open for UAPE holders.
                    <br /> Continued marketing to build
                    <br />
                    brand awareness
                    <br /> Sneak peek of Unapologetic
                    <br /> City Preview of U-Apes
                    <br />
                    Clothing line.Hiring within
                    <br />
                    the community for various positions
                  </div>
                </div>
              </div>
              <div className="zuoshle">
                <img src={yunimg} />
              </div>
            </div>
            <div className="Lenuitem">
              <div className="zuoshei">
                <img src={zhoimg} />
              </div>
              <div className="nroleui">
                <div className="nroleui_title">
                  <img src={libimg} />
                </div>
                <div className="nroleui_nro">
                  <img src={img03} />
                  <div className="tilieles">
                    Unapologetic City developers
                    <br />
                    and prototype finalized
                    <br /> V2 Airdrop exclusive to
                    <br /> holders
                    <br /> First drop from the Clothing
                    <br />
                    line
                  </div>
                </div>
              </div>
              <div className="zuoshle">
                <img src={yunimg} />
              </div>
            </div>
            <div className="Lenuitem">
              <div className="zuoshei">
                <img src={zhoimg} />
              </div>
              <div className="nroleui">
                <div className="nroleui_title">
                  <img src={libimg} />
                </div>
                <div className="nroleui_nro">
                  <img src={img04} />
                  <div className="tilieles">
                    Unapologetic City goes live
                    <br /> Claiming of condos in
                    <br /> Apetopia Palms begin 
                    <br />V2 road map release
                  </div>
                </div>
              </div>
              <div className="zuoshle">
                <img src={yunimg} />
              </div>
            </div>
          </div>
        </div>
        <div>
          <ExhIundev />
        </div>
      </div>
    );
  }
}
