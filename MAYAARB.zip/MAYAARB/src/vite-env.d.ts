/// <reference types="vite/client" />
declare module "react/jsx-runtime" {
    export default any;
}
