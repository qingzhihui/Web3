import React from "react";
import "./index.scss";

const Footer = () => {
  return (
    <div className="footer">
      <div className="footer_nro">
        <div className="footer_nro_letne">
          <div className="nro_letne_item">Home</div>
          <div className="nro_letne_item">Visa</div>
          <div className="nro_letne_item">Flights</div>
          <div className="nro_letne_item">Hotel</div>
          <div className="nro_letne_item">Tickets</div>
        </div>
        <div className="footer_nro_center">
          <div className="nro_letne_item">Terms & Conditions</div>
          <div className="nro_letne_item">Member Terms</div>
          <div className="nro_letne_item">Privacy Policy</div>
          <div className="nro_letne_item">FAQ</div>
        </div>
        <div className="footer_nro_reft">
          <div className="nro_letne_item">Follow us</div>
          <div className="letne_item_img">
            <div className="item_img_nrio">
              <img
                src={require("@/assets/image/ic_baseline-wechat.png")}
                alt=""
              />
            </div>
            <div className="item_img_nrio">
              <img
                src={require("@/assets/image/icon-park-outline_weibo.png")}
                alt=""
              />
            </div>
            <div className="item_img_nrio">
              <img
                src={require("@/assets/image/Facebook-Negative.png")}
                alt=""
              />
            </div>
            <div className="item_img_nrio">
              <img
                src={require("@/assets/image/Twitter-Negative.png")}
                alt=""
              />
            </div>
            <div className="item_img_nrio">
              <img
                src={require("@/assets/image/Instagram-Negative.png")}
                alt=""
              />
            </div>
            <div className="item_img_nrio">
              <img src={require("@/assets/image/TikTok-Negative.png")} alt="" />
            </div>
            <div className="item_img_nrio">
              <img
                src={require("@/assets/image/YouTube-Negative.png")}
                alt=""
              />
            </div>
            <div className="item_img_nrio">
              <img
                src={require("@/assets/image/Telegram-Negative.png")}
                alt=""
              />
            </div>
          </div>
          <div className="nro_letne_item">
            Anydoor Trip Co. LTD © 2021-2022.
          </div>
          <div className="nro_letne_item">Travel Agent License：8621951</div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
