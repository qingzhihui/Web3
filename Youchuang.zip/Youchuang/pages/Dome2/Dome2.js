const app = getApp()
Page({
  data: {
    statsuBarHeight: app.globalData.statsuBarHeight,
    headHeight: 40,
    chatListHeight: 0,
    keyboardHeight: 0,
    messageList: [],
    inutPanelHeight: 50,
    toView: "item0",
    curMessage: "",
  },
  onLoad() {
    this.setChatListHeight();
    wx.onKeyboardHeightChange(res => { //监听键盘高度变化
      this.setData({
        keyboardHeight: res.height
      });
      this.setChatListHeight();
      this.scroll2Bottom();
    });
  },
  setChatListHeight() {
    this.setData({
      chatListHeight: app.globalData.sysHeight - app.globalData.statsuBarHeight - this.data.headHeight - this.data.keyboardHeight - this.data.inutPanelHeight
    })
  },
  hideKeyboard() {
    wx.hideKeyboard();
    this.hideMediaPanel();
  },
  getInput(e) {
    let value = e.detail.value;
    this.setData({
      curMessage: value
    });
  },
  send() {
    let curMessage = this.data.curMessage;
    if (curMessage.trim() === "") {
      wx.showToast({
        title: '请输入聊天内容',
        duration: 2000,
        icon: "none"
      })
      return;
    }
    let messageList = this.data.messageList;
    messageList.push(curMessage);
    this.setData({
      curMessage: "",
      messageList: messageList
    })
  },
})