import { Button, Input } from 'antd';
import { ethers } from 'ethers';
import { Component } from 'react';
import { history } from 'umi';

import HandLinke2, { ILisnt } from '../../components/handLinke2/index';
import './index.css';
declare const window: Window & { ethereum: any };
const { TextArea } = Input;
export interface IAdmin {
  id: number;
}
class index extends Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      address: '',
      textarea: '',
      omplete: '',
      binale: '',
      Lisbn: [],
      showHandLinke: true,
      Libsnul: [],
      blance: '',
    };
  }
  addressLink = async () => {
    const Calarr = sessionStorage.getItem('addr');
    if (Calarr == '') {
      console.log('请先连接钱包');
    } else {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const addr = await signer.getAddress();
      const bal = await provider.getBalance(addr);
      this.setState({
        address: addr,
        blance: ethers.utils.formatEther(bal),
      });
    }
  };
  handtextareaChange = (e: any) => {
    this.setState({
      textarea: e.target.value,
    });
  };
  handAutoCompleteChange = (e: any) => {
    this.setState({
      omplete: e.target.value,
    });
  };
  onKeyPress = (e: any) => {
    if (e.keyCode === 13 && e.shiftKey) {
      e.preventDefault();
      this.addNewLineToTextArea();
    }
  };
  onGetLines = () => {
    var tmpArl = (document.querySelector('#test') as HTMLInputElement).value;
    const tmpList = tmpArl.split(/\r*\n/);
    let List: IAdmin[] = [];
    for (let index = 0; index < tmpList.length; index++) {
      List.push({
        id: index + 1,
      });
    }
    this.setState({
      Lisbn: List,
    });
  };
  addNewLineToTextArea() {
    let textar = this.state.textarea + '\r\n';
    this.setState({ textarea: textar });
  }
  UpdateCurrentWallet = () => {
    var Lins: any = [];
    var VaList = this.state.textarea.split(/\r*\n/);
    const newDataList = VaList.filter((item: any) => item !== '');
    Lins = newDataList;

    const Lubse: string[] = [];
    const Blueb: string[] = [];
    Lins.map((item: string) => {
      Lubse.push(item.split(',')[0]);
      Blueb.push(item.split(',')[1]);
    });

    let Nisler: ILisnt[] = [];
    Lins.map((item: string, index: number) => {
      Nisler.push({ key: index, address: Lubse[index], binale: Blueb[index] });
    });

    this.setState({
      Libsnul: Nisler,
      showHandLinke: false,
    });
  };
  UpdateCurrentHide = () => {
    this.setState({
      showHandLinke: true,
    });
  };
  TransLinkShow = () => {
    history.push('/carry/TransLink');
  };
  componentDidMount() {
    this.addressLink();
    console.log(window.ethereum);
    console.log(ethers);
    this.onGetLines();
  }
  render() {
    const { showHandLinke, address, omplete, Libsnul, binale, blance, Lisbn, textarea } =
      this.state;
    return (
      <div className="LIbping">
        {showHandLinke ? (
          <div className="nroleei">
            <div className="titlei" style={{ textAlign: 'center' }}>
              <span>批量发送代币</span>
            </div>
            <div className="inputDaibu">
              <div className="titlei">
                <span>选择代币</span>
              </div>
              <Input
                style={{ width: '100%' }}
                allowClear={true}
                bordered={false}
                value={omplete}
                onChange={this.handAutoCompleteChange}
                placeholder="请输入代币"
              />
            </div>
            <div className="textareadiv">
              <div className="titlei">
                <span>收币地址</span>
              </div>
              <div className="xhusnali">
                <div className="zlinse">
                  {Lisbn.map((item: any, index: any) => (
                    <div key={index}> {item.id}</div>
                  ))}
                </div>
                <TextArea
                  rows={4}
                  id="test"
                  allowClear={true}
                  bordered={false}
                  value={textarea}
                  placeholder="请输入钱包地址"
                  onChange={this.handtextareaChange}
                  autoSize={{ minRows: 3, maxRows: 18 }}
                  onKeyDown={this.onKeyPress}
                  onBlur={this.onGetLines}
                />
              </div>
            </div>
            <div className="bsluien">
              <div className="wske">查看例子</div>
            </div>
            <div className="rederLis">
              返回
              <span
                onClick={() => {
                  this.TransLinkShow();
                }}
              >
                普通版
              </span>
            </div>
            <div>
              <Button
                type="primary"
                onClick={() => {
                  this.UpdateCurrentWallet();
                }}
              >
                下一步
              </Button>
            </div>
          </div>
        ) : (
          <HandLinke2
            UpdateCurrentHide={this.UpdateCurrentHide}
            address={address}
            omplete={omplete}
            Libsnul={Libsnul}
            binale={binale}
            blance={blance}
          />
        )}
      </div>
    );
  }
}

export default index;
