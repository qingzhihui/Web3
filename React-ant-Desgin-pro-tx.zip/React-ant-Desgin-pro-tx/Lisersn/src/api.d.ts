declare namespace API{
    interface IUser{
        id:number
        name:string
    }
    interface Product{
        id:number
        name:string
    }
    interface ProductList{
        data?:Product[];
        success:boolean
    }
}