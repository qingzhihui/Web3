/* eslint-disable react-hooks/rules-of-hooks */
import React, { useEffect, useRef, useState } from "react";
import "./index.scss";
import type { RadioChangeEvent } from "antd";
import { BigNumber, ethers } from "ethers";
import { Radio } from "antd";
import { Loading3QuartersOutlined } from "@ant-design/icons";
import { Select } from "antd";
import { DatePicker } from "antd";
import dayjs from 'dayjs';
import type { DatePickerProps, RangePickerProps } from "antd/es/date-picker";
import {
  convertLocalDateToUTCIgnoringTimezone,
  DigitalConversion,
  FormatUnitsConver,
  InstancedContract,
  ObtainAddress,
  TokenNameDecimals,
} from "../../hooks/config";
import LaunchpadRoadmapPC from "../../components/RoadmapPC/LaunchpadRoadmapPC"
import PrivateSaleRoadmapPC from "../../components/RoadmapPC/PrivateSaleRoadmapPC"
import LaunchpadRoadmapMobile from "../../components/RoadmapMobile/LaunchpadRoadmapMobile"
import PrivateSaleRoadmapMobile from "../../components/RoadmapMobile/PrivateSaleRoadmapMobile"
import { useTranslation } from "react-i18next";
import { DigitalInput, OptionList, toStringValue } from "../../hooks/Token";
import { RouterOptionItem } from "../../state/TokenState";
import { useHistory, useLocation } from "react-router-dom";
import { MinutesConversion, PercentConversion } from "../../hooks/Createlock";
import { LaunchpadProps, sleaProps, WhitelistProps } from "../../hooks/launchpad";
import { WBENJson } from "../../config/abi/wbenjson";
import { floatformat } from "../../utils/floatFormat";
import InputError from "../../components/InputError";
import { isNext } from './nextbuttonIsExec'
import { CreateLaunchpadError } from "../../hooks/Errorhandle";
import { LaunchpadErrorInitState } from "../../state/LaunchpadErrorState";
import moment from "moment";

declare const window: Window & { ethereum: any };

const Whitelist: React.FC = (props: any) => {
  const { t } = useTranslation();
  const { Option } = Select;
  let history = useHistory();
  const { state } = useLocation<any>();
  const [defaultrouter, setDefaultRouter] = useState<string>('')
  const [WhitelistData, setWhitelistData] = useState<WhitelistProps>({
    prerate: "",
    able: "false",
    softcap: "",
    hardcap: "",
    minbuy: "",
    maxbuy: '',
    liquidity: '',
    listingrate: '',
    Starttime: '',
    Endtime: '',
    lockup: '',
    firstrelease: '',
    vestperiod: '',
    pretokencycle: '',
    usevest: false,
    Refund: "0",
    Router: "0xD99D1c33F9fC3444f8101754aBC46c52416550D1",
  });
  const [calPresaleRate, setCalPresaleRate] = useState<string>();
  const [calHardCap, setCalHardCap] = useState<string>();
  const [calLiquidity, setCalLiquidity] = useState<string>();
  const [calListingRate, setCalListingRate] = useState<string>();
  const [WhiteState, setWhiteState] = useState<boolean>(false);
  const [Poleie, setPoleie] = useState<LaunchpadProps>({});
  const uservest = useRef<any>();
  const [calculate, setCalculate] = useState<string>("");
  // 从哪里进来的页面 Lauchpad 或者 Sale
  const [pagetitle, setPageTitle] = useState<string>('')
  const [LaunchpadError, setLaunchpadError] = useState<CreateLaunchpadError>(LaunchpadErrorInitState);

  const disabledDate: RangePickerProps['disabledDate'] = (current) => {
    return current && current < moment().startOf('days');
  };

  const range = (start: number, end: number) => {
    const result = [];
    for (let i = start; i < end; i++) {
      result.push(i);
    }
    return result;
  };

  const setError = (key: string, value: boolean) => {
    setLaunchpadError((olddata: CreateLaunchpadError) => {
      return {
        ...olddata,
        [key]: value,
      };
    });
  };
  const PresaleRateValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setCalPresaleRate(inputChange);
      setWhitelistData((olddata: any) => {
        if (inputChange === '') {
          setError("PresaleRateBlankError", true)
        } else {
          setError("PresaleRateBlankError", false)
        }
        if (inputChange && Number(inputChange) <= 0) {
          setError("PresaleRatePositiveError", true)
        } else {
          setError("PresaleRatePositiveError", false)
        }
        return {
          ...olddata,
          prerate: inputChange
        };
      });
    }
    CalculateAmount(Poleie, inputChange, calHardCap, calLiquidity, calListingRate);;
  };
  const PresaleRateBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("PresaleRateBlankError", true)
      } else {
        setError("PresaleRateBlankError", false)
      }
      if (e.target.value && Number(e.target.value) <= 0) {
        setError("PresaleRatePositiveError", true)
      } else {
        setError("PresaleRatePositiveError", false)
      }
    }
    CalculateAmount(Poleie, e.target.value, calHardCap, calLiquidity, calListingRate);;
  };
  const setWhiteListType = (e: RadioChangeEvent) => {
    setWhitelistData((olddata: WhitelistProps) => {
      return {
        ...olddata,
        able: e.target.value,
      };
    });
  };
  const SoftCapValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setWhitelistData((olddata: any) => {
        if (inputChange === '') {
          setError("SoftCapBlankError", true)
        } else {
          setError("SoftCapBlankError", false)
        }
        if (inputChange && Number(inputChange) <= 0) {
          setError("SoftCapPositiveError", true)
        } else {
          setError("SoftCapPositiveError", false)
        }
        if (WhitelistData.hardcap && inputChange) {
          if (Number(inputChange) < Number(WhitelistData.hardcap) * 0.25) {
            setError("SoftCapMinError", true)
          } else {
            setError("SoftCapMinError", false)
          }
          if (Number(inputChange) > Number(WhitelistData.hardcap)) {
            setError("SoftCapMaxError", true)
          } else {
            setError("SoftCapMaxError", false)
          }
        } else {
          setError("SoftCapMinError", false)
          setError("SoftCapMaxError", false)
        }
        return {
          ...olddata,
          softcap: inputChange
        };
      });
    }
  };
  const SoftCapBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("SoftCapBlankError", true)
      } else {
        setError("SoftCapBlankError", false)
      }
      if (e.target.value && Number(e.target.value) <= 0) {
        setError("SoftCapPositiveError", true)
      } else {
        setError("SoftCapPositiveError", false)
      }
      if (WhitelistData.hardcap && e.target.value) {
        if (Number(e.target.value) < Number(WhitelistData.hardcap) * 0.25) {
          setError("SoftCapMinError", true)
        } else {
          setError("SoftCapMinError", false)
        }
        if (Number(e.target.value) > Number(WhitelistData.hardcap)) {
          setError("SoftCapMaxError", true)
        } else {
          setError("SoftCapMaxError", false)
        }
      } else {
        setError("SoftCapMinError", false)
        setError("SoftCapMaxError", false)
      }
    }
  };
  const HardCapValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setCalHardCap(inputChange);
      setWhitelistData((olddata: any) => {
        if (inputChange === '') {
          setError("HardCapBlankError", true)
        } else {
          setError("HardCapBlankError", false)
        }
        if (inputChange && Number(inputChange) <= 0) {
          setError("HardCapPositiveError", true)
        } else {
          setError("HardCapPositiveError", false)
        }
        if (WhitelistData.softcap && inputChange) {
          if (Number(WhitelistData.softcap) < Number(inputChange) * 0.25) {
            setError("SoftCapMinError", true)
          } else {
            setError("SoftCapMinError", false)
          }
          if (Number(WhitelistData.softcap) > Number(inputChange)) {
            setError("SoftCapMaxError", true)
          } else {
            setError("SoftCapMaxError", false)
          }
        } else {
          setError("SoftCapMinError", false)
          setError("SoftCapMaxError", false)
        }
        return {
          ...olddata,
          hardcap: inputChange
        };
      });
    }
    CalculateAmount(Poleie, calPresaleRate, inputChange, calLiquidity, calListingRate);;
  };
  const HardCapBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("HardCapBlankError", true)
      } else {
        setError("HardCapBlankError", false)
      }
      if (e.target.value && Number(e.target.value) <= 0) {
        setError("HardCapPositiveError", true)
      } else {
        setError("HardCapPositiveError", false)
      }
      if (WhitelistData.softcap && e.target.value) {
        if (Number(WhitelistData.softcap) < Number(e.target.value) * 0.25) {
          setError("SoftCapMinError", true)
        } else {
          setError("SoftCapMinError", false)
        }
        if (Number(WhitelistData.softcap) > Number(e.target.value)) {
          setError("SoftCapMaxError", true)
        } else {
          setError("SoftCapMaxError", false)
        }
      } else {
        setError("SoftCapMinError", false)
        setError("SoftCapMaxError", false)
      }
    }
    CalculateAmount(Poleie, calPresaleRate, e.target.value, calLiquidity, calListingRate);;
  };
  const MinimumBuyValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setWhitelistData((olddata: any) => {
        if (inputChange === '') {
          setError("MinimumBuyBlankError", true)
        } else {
          setError("MinimumBuyBlankError", false)
        }
        if (inputChange && Number(inputChange) <= 0) {
          setError("MinimumBuyPositiveError", true)
        } else {
          setError("MinimumBuyPositiveError", false)
        }
        if (WhitelistData.maxbuy && inputChange) {
          if (Number(inputChange) >= Number(WhitelistData.maxbuy)) {
            setError("MinimumBuyMaxError", true)
          } else {
            setError("MinimumBuyMaxError", false)
          }
        } else {
          setError("MinimumBuyMaxError", false)
        }
        return {
          ...olddata,
          minbuy: inputChange
        };
      });
    }
  };
  const MinimumBuyBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("MinimumBuyBlankError", true)
      } else {
        setError("MinimumBuyBlankError", false)
      }
      if (e.target.value && Number(e.target.value) <= 0) {
        setError("MinimumBuyPositiveError", true)
      } else {
        setError("MinimumBuyPositiveError", false)
      }
      if (WhitelistData.maxbuy && e.target.value) {
        if (Number(e.target.value) >= Number(WhitelistData.maxbuy)) {
          setError("MinimumBuyMaxError", true)
        } else {
          setError("MinimumBuyMaxError", false)
        }
      } else {
        setError("MinimumBuyMaxError", false)
      }
    }
  };
  const MaximumBuyValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setWhitelistData((olddata: any) => {
        if (inputChange === '') {
          setError("MaximumBuyBlankError", true)
        } else {
          setError("MaximumBuyBlankError", false)
        }
        if (inputChange && Number(inputChange) <= 0) {
          setError("MaximumBuyPositiveError", true)
        } else {
          setError("MaximumBuyPositiveError", false)
        }
        if (WhitelistData.minbuy && inputChange) {
          if (Number(WhitelistData.minbuy) >= Number(inputChange)) {
            setError("MinimumBuyMaxError", true)
          } else {
            setError("MinimumBuyMaxError", false)
          }
        } else {
          setError("MinimumBuyMaxError", false)
        }
        return {
          ...olddata,
          maxbuy: inputChange
        };
      });
    }
  };
  const MaximumBuyBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("MaximumBuyBlankError", true)
      } else {
        setError("MaximumBuyBlankError", false)
      }
      if (e.target.value && Number(e.target.value) <= 0) {
        setError("MaximumBuyPositiveError", true)
      } else {
        setError("MaximumBuyPositiveError", false)
      }
      if (WhitelistData.minbuy && e.target.value) {
        if (Number(WhitelistData.minbuy) >= Number(e.target.value)) {
          setError("MinimumBuyMaxError", true)
        } else {
          setError("MinimumBuyMaxError", false)
        }
      } else {
        setError("MinimumBuyMaxError", false)
      }
    }
  };
  const selectRefundType = (value: string) => {
    setWhitelistData((olddata: WhitelistProps) => {
      return {
        ...olddata,
        Refund: value,
      };
    });
  };
  const selectRouter = (value: string) => {
    RouterOptionItem.filter((Opitem: OptionList) => {
      if (Opitem.value === value) {
        setWhitelistData((olddata: WhitelistProps) => {
          return {
            ...olddata,
            Router: Opitem.value,
          };
        });
      }
    });
  };
  const LiquidityValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setCalLiquidity(inputChange)
    if (inputChange !== undefined) {
      setWhitelistData((olddata: any) => {
        if (inputChange === '') {
          setError("LiquidityBlankError", true)
        } else {
          setError("LiquidityBlankError", false)
        }
        if (inputChange && Number(inputChange) <= 50) {
          setError("LiquidityMinError", true)
        } else {
          setError("LiquidityMinError", false)
        }
        if (inputChange && Number(inputChange) > 100) {
          setError("LiquidityMaxError", true)
        } else {
          setError("LiquidityMaxError", false)
        }
        return {
          ...olddata,
          liquidity: inputChange
        };
      });
    }
    CalculateAmount(Poleie, calPresaleRate, calHardCap, inputChange, calListingRate);;
  };
  const LiquidityBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("LiquidityBlankError", true)
      } else {
        setError("LiquidityBlankError", false)
      }
      if (e.target.value && Number(e.target.value) <= 50) {
        setError("LiquidityMinError", true)
      } else {
        setError("LiquidityMinError", false)
      }
      if (e.target.value && Number(e.target.value) > 100) {
        setError("LiquidityMaxError", true)
      } else {
        setError("LiquidityMaxError", false)
      }
    }
    CalculateAmount(Poleie, calPresaleRate, calHardCap, e.target.value, calListingRate);;
  };
  const ListingRateValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setCalListingRate(inputChange);
      setWhitelistData((olddata: any) => {
        if (inputChange === '') {
          setError("ListingRateBlankError", true)
        } else {
          setError("ListingRateBlankError", false)
        }
        if (inputChange && Number(inputChange) <= 0) {
          setError("ListingRatePositiveError", true)
        } else {
          setError("ListingRatePositiveError", false)
        }
        return {
          ...olddata,
          listingrate: inputChange
        };
      });
    }
    CalculateAmount(Poleie, calPresaleRate, calHardCap, calLiquidity, inputChange);;
  };
  const ListingRateBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("ListingRateBlankError", true)
      } else {
        setError("ListingRateBlankError", false)
      }
      if (e.target.value && Number(e.target.value) <= 0) {
        setError("ListingRatePositiveError", true)
      } else {
        setError("ListingRatePositiveError", false)
      }
    }
    CalculateAmount(Poleie, calPresaleRate, calHardCap, calLiquidity, e.target.value);;
  };
  const selectStartTime = (
    value: DatePickerProps["value"] | RangePickerProps["value"],
    dateString: [string, string] | string
  ) => {
    if (value === null) {
      setError("StartTimeBlankError", true)
      setError("StartTimeMinError", false)
      setError("StartTimeMaxError", false)
    } else {
      setError("StartTimeBlankError", false)
      const UTCIgnoringTimezone = convertLocalDateToUTCIgnoringTimezone(new Date(toStringValue(dateString)));
      const UTCtransFormation = new Date(toStringValue(UTCIgnoringTimezone)).valueOf();
      const date = Date.now();
      let start = (value as any)._d
      if (start < date) {
        setError("StartTimeMinError", true)
      } else {
        setError("StartTimeMinError", false)
      }
      if (value && WhitelistData.Endtime) {
        if (UTCtransFormation / 1000 > Number(WhitelistData.Endtime)) {
          setError("StartTimeMaxError", true)
        } else {
          setError("StartTimeMaxError", false)
        }
      }
      setWhitelistData((olddata: WhitelistProps) => {
        return {
          ...olddata,
          Starttime: toStringValue(UTCtransFormation / 1000),
        };
      });
    }
  };
  const finishSelectStartTime = (
    value: DatePickerProps["value"] | RangePickerProps["value"]
  ) => {
    if (value === null) {
      setError("StartTimeBlankError", true)
      setError("StartTimeMinError", false)
      setError("StartTimeMaxError", false)
    } else {
      setError("StartTimeBlankError", false)
      let UTCtransFormation = value?.valueOf()
      let result = UTCtransFormation as any / 1000;
      let start = (value as any)._d
      const date = Date.now();
      if (start < date) {
        setError("StartTimeMinError", true)
      } else {
        setError("StartTimeMinError", false)
      }
      if (value && WhitelistData.Endtime) {
        if (parseInt(result.toString()) > Number(WhitelistData.Endtime)) {
          setError("StartTimeMaxError", true)
        } else {
          setError("StartTimeMaxError", false)
        }
      }
    }
  };
  const selectEndTime = (
    value: DatePickerProps["value"] | RangePickerProps["value"],
    dateString: [string, string] | string
  ) => {
    if (value === null) {
      setError("EndTimeBlankError", true)
      setError("EndTimeMinError", false)
    } else {
      setError("EndTimeBlankError", false)
      const UTCIgnoringTimezone = convertLocalDateToUTCIgnoringTimezone(new Date(toStringValue(dateString)));
      const UTCtransFormation = new Date(toStringValue(UTCIgnoringTimezone)).valueOf();
      setWhitelistData((olddata: WhitelistProps) => {
        if (value && WhitelistData.Starttime) {
          if (UTCtransFormation / 1000 < Number(WhitelistData.Starttime)) {
            setError("EndTimeMinError", true)
          } else {
            setError("EndTimeMinError", false)
          }
        }
        return {
          ...olddata,
          Endtime: toStringValue(UTCtransFormation / 1000),
        };
      });
    }
  };
  const finishSelectEndTime = (
    value: DatePickerProps["value"] | RangePickerProps["value"]
  ) => {
    if (value === null) {
      setError("EndTimeBlankError", true)
      setError("EndTimeMinError", false)
    } else {
      setError("EndTimeBlankError", false)
      let UTCtransFormation = value?.valueOf()
      let result = UTCtransFormation as any / 1000;
      if (value && WhitelistData.Starttime) {
        if (parseInt(result.toString()) < Number(WhitelistData.Starttime)) {
          setError("EndTimeMinError", true)
        } else {
          setError("EndTimeMinError", false)
        }
      }
    }
  };
  const LockUpTimeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setWhitelistData((olddata: WhitelistProps) => {
      if (inputChange === '') {
        setError("LockupTimeBlankError", true)
      } else {
        setError("LockupTimeBlankError", false)
      }
      if (inputChange !== undefined && inputChange !== '') {
        if (Number(inputChange) < 5) {
          setError("LockupTimeMinError", true)
        } else {
          setError("LockupTimeMinError", false)
        }
      }
      return {
        ...olddata,
        lockup: inputChange
      };
    });
  };
  const LockUpTimeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      setError("LockupTimeBlankError", true)
    } else {
      setError("LockupTimeBlankError", false)
    }
    if (e.target.value !== undefined && e.target.value !== '') {
      if (Number(e.target.value) < 5) {
        setError("LockupTimeMinError", true)
      } else {
        setError("LockupTimeMinError", false)
      }
    }
  };
  const FirstReleaseForPresaleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setWhitelistData((olddata: WhitelistProps) => {
      if (inputChange === '') {
        setError("FirstReleaseBlankError", true)
      } else {
        setError("FirstReleaseBlankError", false)
      }
      if (WhitelistData.pretokencycle && inputChange) {
        if (Number(inputChange) + Number(WhitelistData.pretokencycle) > 100) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      }
      return {
        ...olddata,
        firstrelease: inputChange
      };
    });
  };
  const FirstReleaseForPresaleBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      setError("FirstReleaseBlankError", true)
    } else {
      setError("FirstReleaseBlankError", false)
    }
    if (WhitelistData.pretokencycle && e.target.value) {
      if (Number(e.target.value) + Number(WhitelistData.pretokencycle) > 100) {
        setError("FeeOverError", true)
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const VestingPeriodEachCycleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setWhitelistData((olddata: WhitelistProps) => {
      if (inputChange === '') {
        setError("VestingPeriodBlankError", true)
      } else {
        setError("VestingPeriodBlankError", false)
      }
      return {
        ...olddata,
        vestperiod: inputChange
      };
    });
  };
  const VestingPeriodEachCycleBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      setError("VestingPeriodBlankError", true)
    } else {
      setError("VestingPeriodBlankError", false)
    }
  };
  const TokenReleaseEachCycleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setWhitelistData((olddata: WhitelistProps) => {
      if (inputChange === '') {
        setError("PresaleTokenBlankError", true)
      } else {
        setError("PresaleTokenBlankError", false)
      }
      if (WhitelistData.firstrelease && inputChange) {
        if (Number(inputChange) + Number(WhitelistData.firstrelease) > 100) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      }
      return {
        ...olddata,
        pretokencycle: inputChange
      };
    });
  };
  const TokenReleaseEachCycleBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      setError("PresaleTokenBlankError", true)
    } else {
      setError("PresaleTokenBlankError", false)
    }
    if (WhitelistData.firstrelease && e.target.value) {
      if (Number(e.target.value) + Number(WhitelistData.firstrelease) > 100) {
        setError("FeeOverError", true)
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const BackOnClick = async () => {
    if (state != undefined) {
      if (state.inputValue != undefined) {
        history.push({
          pathname: `/${state.routeName}`,
          state: state,
        });
      } else if (state.PoleieData != undefined) {
        history.push({
          pathname: `/${state.PoleieData.routeName}`,
          state: state,
        });
      } else {
        history.push({
          pathname: `/${state.data.PoleieData.routeName}`,
          state: state,
        });
      }
    }
  };
  const NextOnClick = async () => {
    const { address } = (await ObtainAddress()) as any;
    const memoryAddrs = [address, address];
    let tokenDecimals = 18;
    let tokenSymbol = "BNB";
    if (Poleie.Radiovalue !== "0x0000000000000000000000000000000000000000") {
      const Uline = await TokenNameDecimals(Poleie.Radiovalue);
      tokenDecimals = Uline.decimals;
      tokenSymbol = Uline.symbol;
    }
    const PrivateSaleInfo = [
      Poleie.Radiovalue,
      WhitelistData.able,
      DigitalConversion(WhitelistData.softcap, tokenDecimals),
      DigitalConversion(WhitelistData.hardcap, tokenDecimals),
      DigitalConversion(WhitelistData.minbuy, tokenDecimals),
      DigitalConversion(WhitelistData.maxbuy, tokenDecimals),
      WhitelistData.Starttime,
      WhitelistData.Endtime,
    ];
    const VestingInfo = [
      PercentConversion(WhitelistData.firstrelease).toString(),
      MinutesConversion(WhitelistData.vestperiod).toString(),
      PercentConversion(WhitelistData.pretokencycle).toString(),
    ];
    const prerateData = {
      Presale: DigitalConversion(WhitelistData.prerate, tokenDecimals),
      Refund: WhitelistData.Refund,
      Router: WhitelistData.Router,
      listingrate: DigitalConversion(WhitelistData.listingrate, tokenDecimals),
      liquidity: PercentConversion(WhitelistData.liquidity),
      lockup: MinutesConversion(WhitelistData.lockup),
    };
    if (state != undefined) {
      if (state.inputValue != undefined) {
        history.push({
          pathname: "/CreateAirdrop",
          state: {
            UrlName: "WhiteList",
            PoleieData: Poleie,
            memoryData: memoryAddrs,
            PrivatData: PrivateSaleInfo,
            VestinData: VestingInfo,
            prerateData: prerateData,
            WhiteliData: WhitelistData,
            pagetitle: pagetitle
          },
        });
      } else {
        state.pagetitle = pagetitle
        history.push({
          pathname: "/CreateAirdrop",
          state: state,
        });
      }
    } else {
      history.push({
        pathname: "/CreateAirdrop",
        state: {
          UrlName: "WhiteList",
          PoleieData: Poleie,
          memoryData: memoryAddrs,
          PrivatData: PrivateSaleInfo,
          VestinData: VestingInfo,
          prerateData: prerateData,
          WhiteliData: WhitelistData,
          pagetitle: pagetitle
        },
      });
    }
  };
  const urlBuleUrleJudge = (urleJudgeValue: string) => {
    setPageTitle(urleJudgeValue)
    if (urleJudgeValue === "Sale") {
      setWhitelistData((olddata: WhitelistProps) => {
        return {
          ...olddata,
          usevest: true,
        };
      });
    } else if (urleJudgeValue === "Lauchpad") {
      setWhitelistData((olddata: WhitelistProps) => {
        return {
          ...olddata,
          usevest: false,
        };
      });
      setWhiteState((state: any) => {
        return (state = true);
      });
    } else {
      setWhitelistData((olddata: WhitelistProps) => {
        return {
          ...olddata,
          usevest: true,
        };
      });
      setWhiteState((state: any) => {
        return (state = false);
      });
    }
  };
  const CalculateAmount = async (Poleie: sleaProps, presaleRate: any, hardCap: any, liquidity: any, listingRate: any) => {
    const { FeeOptions } = Poleie;
    let presaleRateCal = 0;
    let hardCapCal = 0;
    let liquidityPercentCal = 0;
    let listingRateCal = 0;
    if (presaleRate) {
      presaleRateCal = presaleRate;
    }
    if (hardCap) {
      hardCapCal = hardCap;
    }
    if (liquidity) {
      liquidityPercentCal = PercentConversion(liquidity);
    }
    if (listingRate) {
      listingRateCal = listingRate;
    }
    const raisedFeePercentCal = Number(FeeOptions?.split(",")[0]);
    const raisedTokenFeePercentCal = Number(FeeOptions?.split(",")[1])
    const DENOMINATORCal = 10000;
    const totalPresaleTokensCal = presaleRateCal * hardCapCal;
    const totalFeeTokensCal = totalPresaleTokensCal * raisedTokenFeePercentCal / DENOMINATORCal;
    const totalRaisedFeeCal = hardCapCal * raisedFeePercentCal / DENOMINATORCal;
    const netCapCal = hardCapCal - totalRaisedFeeCal;
    const totalFeeTokensToAddLPCal = netCapCal * liquidityPercentCal / DENOMINATORCal;
    const totalLiquidityTokensCal = totalFeeTokensToAddLPCal * listingRateCal;
    const finallyCalResult = totalPresaleTokensCal + totalFeeTokensCal + totalLiquidityTokensCal;
    setCalculate(finallyCalResult.toString());
  }
  // const CalculateAmount = async (Poleie: sleaProps, presaleRate: any, hardCap: any, liquidity: any, listingRate: any) => {
  //   const { FeeOptions, Radiovalue } = Poleie;
  //   let feeTokenDecimals = 18;
  //   let IcoTokenDecimals = 18;
  //   let realDecimals = IcoTokenDecimals / feeTokenDecimals;
  //   let presaleRateCal: BigNumber = BigNumber.from(0);
  //   let hardCapCal: BigNumber = BigNumber.from(0);
  //   let liquidityPercentCal: BigNumber = BigNumber.from(0);
  //   let listingRateCal: BigNumber = BigNumber.from(0);
  //   const tokenContract = InstancedContract(Radiovalue, WBENJson) as any;
  //   if (Radiovalue !== "0x0000000000000000000000000000000000000000") {
  //     feeTokenDecimals = await tokenContract.decimals();
  //   }
  //   if (presaleRate) {
  //     presaleRateCal = BigNumber.from(presaleRate).mul(
  //       BigNumber.from(10).pow(IcoTokenDecimals)
  //     );
  //   }

  //   if (hardCap) {
  //     hardCapCal = BigNumber.from(hardCap).mul(
  //       BigNumber.from(10).pow(feeTokenDecimals)
  //     );
  //   }

  //   if (liquidity) {
  //     liquidityPercentCal = BigNumber.from(PercentConversion(liquidity));
  //   }

  //   if (listingRate) {
  //     listingRateCal = BigNumber.from(Number(listingRate)).mul(
  //       BigNumber.from(10).pow(IcoTokenDecimals)
  //     );
  //   }

  //   const raisedFeePercentCal: BigNumber = BigNumber.from(
  //     FeeOptions?.split(",")[0]
  //   );
  //   const raisedTokenFeePercentCal: BigNumber = BigNumber.from(
  //     FeeOptions?.split(",")[1]
  //   );
  //   const DENOMINATORCal: BigNumber = BigNumber.from(10000);
  //   const totalPresaleTokensCal: BigNumber = presaleRateCal.mul(hardCapCal).div(BigNumber.from(10).pow(feeTokenDecimals));
  //   const totalFeeTokensCal: BigNumber = totalPresaleTokensCal.mul(raisedTokenFeePercentCal).div(DENOMINATORCal);
  //   const totalRaisedFeeCal: BigNumber = hardCapCal.mul(raisedFeePercentCal).div(DENOMINATORCal);
  //   const netCapCal: BigNumber = hardCapCal.sub(totalRaisedFeeCal);
  //   const totalFeeTokensToAddLPCal: BigNumber = netCapCal.mul(liquidityPercentCal).div(DENOMINATORCal);
  //   const totalLiquidityTokensCal: BigNumber = totalFeeTokensToAddLPCal.mul(listingRateCal).div(BigNumber.from(10).pow(feeTokenDecimals));
  //   const finallyCalResult = totalPresaleTokensCal.add(totalFeeTokensCal).add(totalLiquidityTokensCal);
  //   setCalculate(FormatUnitsConver(finallyCalResult, IcoTokenDecimals));
  // }
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          if (state.inputValue != undefined) {
            setPoleie((data: any) => {
              return (data = state);
            });
            urlBuleUrleJudge(state.routeName);
          } else if (state.PoleieData != undefined) {
            setPoleie((Poleiedata: any) => {
              return (Poleiedata = state.PoleieData);
            });
            setWhitelistData((Whitelistdata: WhitelistProps) => {
              return (Whitelistdata = state.WhiteliData);
            });
            urlBuleUrleJudge(state.PoleieData.routeName);
          } else {
            setPoleie((Poleiedata: any) => {
              return (Poleiedata = state.data.PoleieData);
            });
            setWhitelistData((Whitelistdata: WhitelistProps) => {
              return (Whitelistdata = state.data.WhiteliData);
            });
            urlBuleUrleJudge(state.data.PoleieData.routeName);
          }
        }
      }
    }
  }, [state]);
  useEffect(() => {
    setDefaultRouter(RouterOptionItem[0].value)
  }, [calculate])
  return (
    <>
      <div className="Whitelist">
        <div className="require">(*) {`${t("is required field.")}`}</div>
        {WhiteState === false ? (
          ""
        ) : (
          <>
            <div className="rate-title">{`${t("Presale rate")}`}<span style={{ color: "#f95192" }}>*</span></div>
            <input
              placeholder={`${t("Ex: 100")}`}
              className="rate-input"
              value={(WhitelistData.prerate as string)}
              style={{ borderColor: LaunchpadError.PresaleRateBlankError || LaunchpadError.PresaleRatePositiveError ? '#f14668' : '' }}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                PresaleRateValueChange(e);
              }}
              onBlur={(e) => {
                PresaleRateBlurChange(e);
              }}
              onFocus={(e) => {
                PresaleRateValueChange(e);
              }}
            ></input>
            {LaunchpadError.PresaleRateBlankError ? <InputError title="Presale rate cannot be blank" /> : ''}
            {LaunchpadError.PresaleRatePositiveError ? <InputError title="Presale rate must be positive number" /> : ''}
            <div className="tip">
              {`${t("If I spend 1 ")}`}{" "}
              {Poleie.Radiovalue === "0x0000000000000000000000000000000000000000"
                ? "BNB"
                : Poleie.Radiovalue ===
                  "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                  ? "BUSD"
                  : Poleie.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                    ? "USDT"
                    : Poleie.Radiovalue ===
                      "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                      ? "USDC"
                      : ""}{" "}
              {`${t("how many tokens will I receive?")}`}
            </div>
          </>
        )}
        <div className="Whitrelist-title">{`${t("Whitelist")}`}</div>
        <div>
          <Radio.Group
            onChange={setWhiteListType}
            value={(WhitelistData.able as string)}
          >
            <Radio value="false">{`${t("Disable")}`}</Radio>
            <Radio value="true">{`${t("Enable")}`}</Radio>
          </Radio.Group>
        </div>
        <div className="tip" style={{ margin: "15px 0" }}>
          {`${t("You can enable/disable whitelist anytime")}`}
        </div>
        <div className="datablock">
          <div className="datablockColumn">
            <div className="datablockItem">
              <div>
                {`${t("Softcap")}`} (
                {Poleie.Radiovalue ===
                  "0x0000000000000000000000000000000000000000"
                  ? "BNB"
                  : Poleie.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                    ? "BUSD"
                    : Poleie.Radiovalue ===
                      "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                      ? "USDT"
                      : Poleie.Radiovalue ===
                        "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                        ? "USDC"
                        : ""}
                )<span style={{ color: "#f95192" }}>*</span>
              </div>
              <input
                placeholder={`${t("Ex: 10")}`}
                className="datablock-input"
                value={(WhitelistData.softcap as string)}
                style={{ borderColor: LaunchpadError.SoftCapBlankError || LaunchpadError.SoftCapPositiveError || LaunchpadError.SoftCapMinError || LaunchpadError.SoftCapMaxError ? '#f14668' : '' }}
                onChange={(e) => {
                  SoftCapValueChange(e);
                }}
                onBlur={(e) => {
                  SoftCapBlurChange(e);
                }}
              ></input>
              {LaunchpadError.SoftCapBlankError ? <InputError title="Softcap cannot be blank" /> : ''}
              {LaunchpadError.SoftCapPositiveError ? <InputError title="Softcap must be positive number" /> : ''}
              {LaunchpadError.SoftCapMinError ? <InputError title="Softcap must be greater than or equal 25% of Hardcap" /> : ''}
              {LaunchpadError.SoftCapMaxError ? <InputError title="Softcap must be less than or equal Hardcap" /> : ''}
              <div className="tip datablickitem-tip">{`${t("Softcap must be >= 25% of Hardcap!")}`}</div>
            </div>
            <div className="datablockItem">
              <div>
                {`${t("Hardcap")}`} (
                {Poleie.Radiovalue ===
                  "0x0000000000000000000000000000000000000000"
                  ? "BNB"
                  : Poleie.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                    ? "BUSD"
                    : Poleie.Radiovalue ===
                      "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                      ? "USDT"
                      : Poleie.Radiovalue ===
                        "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                        ? "USDC"
                        : ""}
                )<span style={{ color: "#f95192" }}>*</span>
              </div>
              <input
                placeholder={`${t("Ex: 20")}`}
                className="datablock-input"
                value={(WhitelistData.hardcap as string)}
                style={{ borderColor: LaunchpadError.HardCapBlankError || LaunchpadError.HardCapPositiveError ? '#f14668' : '' }}
                onChange={(e) => {
                  HardCapValueChange(e);
                }}
                onBlur={(e) => {
                  HardCapBlurChange(e);
                }}
                onFocus={(e) => {
                  HardCapValueChange(e);
                }}
              ></input>
              {LaunchpadError.HardCapBlankError ? <InputError title="Hardcap cannot be blank" /> : ''}
              {LaunchpadError.HardCapPositiveError ? <InputError title="Hardcap must be positive number" /> : ''}
            </div>
          </div>
          <div className="datablockColumn">
            <div className="datablockItem">
              <div>
                {`${t("Minimum buy")}`} (
                {Poleie.Radiovalue ===
                  "0x0000000000000000000000000000000000000000"
                  ? "BNB"
                  : Poleie.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                    ? "BUSD"
                    : Poleie.Radiovalue ===
                      "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                      ? "USDT"
                      : Poleie.Radiovalue ===
                        "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                        ? "USDC"
                        : ""}
                )<span style={{ color: "#f95192" }}>*</span>
              </div>
              <input
                placeholder={`${t("Ex: 0.1")}${Poleie.Radiovalue ===
                  "0x0000000000000000000000000000000000000000"
                  ? "BNB"
                  : Poleie.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                    ? "BUSD"
                    : Poleie.Radiovalue ===
                      "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                      ? "USDT"
                      : Poleie.Radiovalue ===
                        "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                        ? "USDC"
                        : ""
                  }`}
                className="datablock-input"
                value={(WhitelistData.minbuy as string)}
                style={{ borderColor: LaunchpadError.MinimumBuyBlankError || LaunchpadError.MinimumBuyPositiveError || LaunchpadError.MinimumBuyMaxError ? '#f14668' : '' }}
                onChange={(e) => {
                  MinimumBuyValueChange(e);
                }}
                onBlur={(e) => {
                  MinimumBuyBlurChange(e);
                }}
              ></input>
              {LaunchpadError.MinimumBuyBlankError ? <InputError title="Minimum buy cannot be blank" /> : ''}
              {LaunchpadError.MinimumBuyPositiveError ? <InputError title="Minimum buy must be positive number" /> : ''}
              {LaunchpadError.MinimumBuyMaxError ? <InputError title="Minimum buy must be less than Maximum buy" /> : ''}
            </div>
            <div className="datablockItem">
              <div>
                {`${t("Maximum buy")}`} (
                {Poleie.Radiovalue ===
                  "0x0000000000000000000000000000000000000000"
                  ? "BNB"
                  : Poleie.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                    ? "BUSD"
                    : Poleie.Radiovalue ===
                      "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                      ? "USDT"
                      : Poleie.Radiovalue ===
                        "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                        ? "USDC"
                        : ""}
                )<span style={{ color: "#f95192" }}>*</span>
              </div>
              <input
                placeholder={`${t("Ex: 0.2")} ${Poleie.Radiovalue ===
                  "0x0000000000000000000000000000000000000000"
                  ? "BNB"
                  : Poleie.Radiovalue ===
                    "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                    ? "BUSD"
                    : Poleie.Radiovalue ===
                      "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                      ? "USDT"
                      : Poleie.Radiovalue ===
                        "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                        ? "USDC"
                        : ""
                  }`}
                className="datablock-input"
                value={(WhitelistData.maxbuy as string)}
                style={{ borderColor: LaunchpadError.MaximumBuyBlankError || LaunchpadError.MaximumBuyPositiveError ? '#f14668' : '' }}
                onChange={(e) => {
                  MaximumBuyValueChange(e);
                }}
                onBlur={(e) => {
                  MaximumBuyBlurChange(e);
                }}
              ></input>
              {LaunchpadError.MaximumBuyBlankError ? <InputError title="Maximum buy cannot be blank" /> : ''}
              {LaunchpadError.MaximumBuyPositiveError ? <InputError title="Maximum buy must be positive number" /> : ''}
            </div>
          </div>
          {WhiteState === false ? (
            ""
          ) : (
            <>
              <div className="datablockColumn">
                <div className="datablockItem">
                  <div>{`${t("Refund type")}`}</div>
                  <Select
                    defaultValue="0"
                    style={{ width: 300 }}
                    onChange={selectRefundType}
                    className="selectRefundType"
                    options={[
                      { value: "0", label: `${t("Burn")}` },
                      { value: "1", label: `${t("Refund")}` },
                    ]}
                  />
                </div>
                <div className="datablockItem">
                  <div>
                    {`${t("Router")}`}
                    <span style={{ color: "#f95192" }}>*</span>
                  </div>
                  <Select
                    defaultValue={defaultrouter}
                    style={{ width: 300 }}
                    onChange={(value: string) => {
                      selectRouter(value);
                    }}
                    className="selectRouter"
                    options={RouterOptionItem}
                  >
                    {RouterOptionItem.map((item: OptionList) => (
                      <Option key={item.key} value={item.value}>
                        {item.label}
                      </Option>
                    ))}
                  </Select>
                  <div className="loadImg">
                    <Loading3QuartersOutlined style={{ color: "#f14668" }} />
                  </div>
                </div>
              </div>
              <div className="datablockColumn">
                <div className="datablockItem">
                  <div>
                    {`${t("liquidity")}`} (%)
                    <span style={{ color: "#f95192" }}>*</span>
                  </div>
                  <input
                    placeholder={`${t("Ex: 52")}`}
                    className="datablock-input"
                    value={(WhitelistData.liquidity as string)}
                    style={{ borderColor: LaunchpadError.LiquidityBlankError || LaunchpadError.LiquidityMinError || LaunchpadError.LiquidityMaxError ? '#f14668' : '' }}
                    onChange={(e) => {
                      LiquidityValueChange(e);
                    }}
                    onBlur={(e) => {
                      LiquidityBlurChange(e);
                    }}
                    onFocus={(e) => {
                      LiquidityValueChange(e);
                    }}
                  ></input>
                  {LaunchpadError.LiquidityBlankError ? <InputError title="Liquidity cannot be blank" /> : ''}
                  {LaunchpadError.LiquidityMinError ? <InputError title="Liquidity must be greater than 50%" /> : ''}
                  {LaunchpadError.LiquidityMaxError ? <InputError title="Liquidity must be less than or equal to 100%" /> : ''}
                </div>
                <div className="datablockItem">
                  <div>
                    {`${t("listing rate")}`}
                    <span style={{ color: "#f95192" }}>*</span>
                  </div>
                  <input
                    placeholder={`${t("Ex: 500")}`}
                    className="datablock-input"
                    value={(WhitelistData.listingrate as string)}
                    style={{ borderColor: LaunchpadError.ListingRateBlankError || LaunchpadError.ListingRatePositiveError ? '#f14668' : '' }}
                    onChange={(e) => {
                      ListingRateValueChange(e);
                    }}
                    onBlur={(e) => {
                      ListingRateBlurChange(e);
                    }}
                    onFocus={(e) => {
                      ListingRateValueChange(e);
                    }}
                  ></input>
                  {LaunchpadError.ListingRateBlankError ? <InputError title="Listing rate cannot be blank" /> : ''}
                  {LaunchpadError.ListingRatePositiveError ? <InputError title="Listing rate must be positive number" /> : ''}
                  <div className="tip datablickitem-tip">
                    1{" "}
                    {Poleie.Radiovalue ===
                      "0x0000000000000000000000000000000000000000"
                      ? "BNB"
                      : Poleie.Radiovalue ===
                        "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                        ? "BUSD"
                        : Poleie.Radiovalue ===
                          "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                          ? "USDT"
                          : Poleie.Radiovalue ===
                            "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                            ? "USDC"
                            : ""}{" "}
                    = {(WhitelistData.listingrate as string)} {Poleie.IcoTokenSymbol}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
        {pagetitle === "Lauchpad" ?
          <>
            <div className="tip" style={{ margin: "5px 0" }}>{`${t("Enter the percentage of raised funds that should be allocated to Liquidity on (Min 51%, Max 100%)")}`}</div>
            <div className="tip" style={{ margin: "5px 0" }}>
              {`${t("If I spend 1 ")}`}{" "}
              {Poleie.Radiovalue === "0x0000000000000000000000000000000000000000"
                ? "BNB"
                : Poleie.Radiovalue === "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
                  ? "BUSD"
                  : Poleie.Radiovalue === "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                    ? "USDT"
                    : Poleie.Radiovalue === "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                      ? "USDC"
                      : ""}{" "}
              {`${t("on how many tokens will I receive? Usually this amount is lower than presale rate to allow for a higher listing price on")}`}
            </div>
          </>
          :
          <></>
        }
        <div className="Select start time & end time">
          <div>
            {`${t("Select start time & end time")}`}
            <span style={{ color: "#f95192" }}> *</span>
          </div>
        </div>
        <div className="datablock">
          <div className="datablockColumn">
            <div className="datablockItem">
              <div>{`${t("Start time")}`}<span style={{ color: "#f95192" }}>*</span></div>
              <DatePicker
                disabledDate={disabledDate}
                showTime
                placeholder={"Select start date and time"}
                onChange={selectStartTime}
                onOk={finishSelectStartTime}
                allowClear
              />
              {LaunchpadError.StartTimeBlankError ? <InputError title="Start time cannot be blank" /> : ''}
              {LaunchpadError.StartTimeMinError ? <InputError title="Start time needs to be after now" /> : ''}
              {LaunchpadError.StartTimeMaxError ? <InputError title="Start time needs to be before End time" /> : ''}
            </div>
            <div className="datablockItem">
              <div>{`${t("End time")}`}<span style={{ color: "#f95192" }}>*</span></div>
              <DatePicker
                disabledDate={disabledDate}
                showTime
                placeholder={"Select end date and time"}
                onChange={selectEndTime}
                onOk={finishSelectEndTime}
                allowClear
              />
              {LaunchpadError.EndTimeBlankError ? <InputError title="End time cannot be blank" /> : ''}
              {LaunchpadError.EndTimeMinError ? <InputError title="End time needs to be after Start time" /> : ''}
            </div>
          </div>
          {WhiteState === false ? (
            ""
          ) : (
            <div className="datablockColumn">
              <div className="datablockItem">
                <div>
                  {`${t("Liquidity lockup time")}`}
                  {`${t("(minutes)")}`}
                  <span style={{ color: "#f95192" }}>*</span>
                </div>
                <input
                  className="datablock-input"
                  placeholder={`${t("Ex: 30")}`}
                  value={(WhitelistData.lockup as string)}
                  style={{ borderColor: LaunchpadError.LockupTimeBlankError || LaunchpadError.LockupTimeMinError ? '#f14668' : '' }}
                  onChange={(e) => {
                    LockUpTimeValueChange(e);
                  }}
                  onBlur={(e) => {
                    LockUpTimeBlurChange(e);
                  }}
                ></input>
                {LaunchpadError.LockupTimeBlankError ? <InputError title="Lock up time cannot be blank" /> : ''}
                {LaunchpadError.LockupTimeMinError ? <InputError title="Lock up time must be greater than 5 minutes" /> : ''}
              </div>
            </div>
          )}
        </div>
        {WhiteState === false ? (
          ""
        ) : (
          <div>
            <Radio
              onClick={() => {
                setWhitelistData((olddata: WhitelistProps) => {
                  return {
                    ...olddata,
                    usevest: !WhitelistData.usevest as boolean,
                  };
                });
              }}
              value={(WhitelistData.usevest as boolean)}
              ref={uservest}
              checked={WhitelistData.usevest as boolean}
            >
              {`${t("Using Vesting Contributor?")}`}
            </Radio>
          </div>
        )}

        {(WhitelistData.usevest as boolean) ? (
          <>
            {pagetitle === "Lauchpad" ? (
              <div className="alert">
                {`${t("Vesting Contributor does not support rebase tokens.")}`}
              </div>)
              :
              ("")
            }
            <div className="datablock">
              <div className="datablockColumn">
                <div className="datablockItem">
                  <div>
                    {`${t("First release for presale")}`}
                    {`${t("(percent)")}`}
                    <span style={{ color: "#f95192" }}>*</span>
                  </div>
                  <input
                    placeholder={`${t("Ex: 40")}`}
                    className="datablock-input"
                    value={(WhitelistData.firstrelease as string)}
                    style={{ borderColor: LaunchpadError.FirstReleaseBlankError || LaunchpadError.FeeOverError ? '#f14668' : '' }}
                    onChange={(e) => {
                      FirstReleaseForPresaleValueChange(e);
                    }}
                    onBlur={(e) => {
                      FirstReleaseForPresaleBlurChange(e);
                    }}
                  ></input>
                  {LaunchpadError.FirstReleaseBlankError ? <InputError title="First release for presale cannot be blank" /> : ''}
                  {LaunchpadError.FeeOverError ? <InputError title="First release for presale and Percent token release each cycle must be less than 100%" /> : ''}
                </div>
              </div>
              <div className="datablockColumn">
                <div className="datablockItem">
                  <div>
                    {`${t("Vesting period each cycle")}`}
                    {`${t("(minutes)")}`}
                    <span style={{ color: "#f95192" }}>*</span>
                  </div>
                  <input
                    placeholder={`${t("Ex: 3")}`}
                    className="datablock-input"
                    value={(WhitelistData.vestperiod as string)}
                    style={{ borderColor: LaunchpadError.VestingPeriodBlankError ? '#f14668' : '' }}
                    onChange={(e) => {
                      VestingPeriodEachCycleValueChange(e)
                    }}
                    onBlur={(e) => {
                      VestingPeriodEachCycleBlurChange(e)
                    }}
                  ></input>
                  {LaunchpadError.VestingPeriodBlankError ? <InputError title="Vesting period each cycle cannot be blank" /> : ''}
                </div>
                <div className="datablockItem">
                  <div>
                    {`${t("Presale token release each cycle")}`}
                    {`${t("(percent)")}`}
                    <span style={{ color: "#f95192" }}>*</span>
                  </div>
                  <input
                    placeholder={`${t("Ex: 20")}`}
                    className="datablock-input"
                    value={(WhitelistData.pretokencycle as string)}
                    style={{ borderColor: LaunchpadError.PresaleTokenBlankError || LaunchpadError.FeeOverError ? '#f14668' : '' }}
                    onChange={(e) => {
                      TokenReleaseEachCycleValueChange(e)
                    }}
                    onBlur={(e) => {
                      TokenReleaseEachCycleBlurChange(e)
                    }}
                  ></input>
                  {LaunchpadError.PresaleTokenBlankError ? <InputError title="Presale token release each cycle cannot be blank" /> : ''}
                  {LaunchpadError.FeeOverError ? <InputError title="First release for presale and Percent token release each cycle must be less than 100%" /> : ''}
                </div>
              </div>
            </div>
          </>
        ) : (
          ""
        )}
        {Poleie.routeName === "Lauchpad" ? (
          <div className="footer-text">
            {`${t("Need")}`} {Number(calculate) || 0} {Poleie.IcoTokenSymbol}{" "}
            {`${t("to create launchpad")}`}
          </div>
        ) : (
          ""
        )}
        <div className="footerbtn">
          <div className="footer-button-area">
            <button
              className="footer-back-btn"
              onClick={() => {
                BackOnClick();
              }}
            >
              {`${t("Back")}`}
            </button>
            {isNext(LaunchpadError, pagetitle, WhitelistData.usevest as boolean, WhitelistData) ? <button
              className="footer-next-btn"
              onClick={() => {
                NextOnClick();
              }}
            >
              {`${t("Next")}`}
            </button> : <button
              className="footer-next-btn"
              style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
            >
              {`${t("Next")}`}
            </button>
            }
          </div>
        </div>
      </div>
      <div className="Whitelist-roadmapPC">
        {pagetitle === 'Sale' ? <PrivateSaleRoadmapPC step={2} /> : <LaunchpadRoadmapPC step={2} />}
      </div>
      <div className="Whitelist-roadmapMobile">
        {pagetitle === 'Sale' ? <PrivateSaleRoadmapMobile step={2} /> : <LaunchpadRoadmapMobile step={2} />}
      </div>
    </>
  );
};
export default Whitelist;
