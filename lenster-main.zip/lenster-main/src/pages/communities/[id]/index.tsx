import ViewCommunity from '@components/Community'

export default ViewCommunity
