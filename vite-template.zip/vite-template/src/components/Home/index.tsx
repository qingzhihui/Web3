import { useState, useRef, useEffect } from "react";
function Home() {
  //   const [email, setEmail] = useState("");
  //   const [password, setPassword] = useState("");
  const emailRef = useRef();
  const paggwordRef = useRef();
  const [count, setCount] = useState(0);

  const onSubmit = (e: any) => {
    e.preventDefault();
    // console.log({ email, password });
    console.log({
      email: emailRef.current.value,
      password: paggwordRef.current.value,
    });
  };
  useEffect(() => {
    console.log(count);
  }, [count]);

  const adjustCount = (amount: any) => {
    setCount((currentCount) => {
      return currentCount + amount;
    });
  };
  return (
    <div>
      <div>
        {count}{" "}
        <button
          onClick={() => {
            adjustCount(1);
          }}
        >
          +
        </button>
      </div>
      <form onSubmit={onSubmit}>
        <label htmlFor="email">Email</label>
        <input
          ref={emailRef}
          // value={email}
          // onChange={(e) => setEmail(e.target.value)}
          type="email"
          id="email"
        />
        <label htmlFor="email">Password</label>
        <input
          ref={paggwordRef}
          // value={password}
          // onChange={(e) => setPassword(e.target.value)}
          type="password"
          id="password"
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default Home;
