import { useState } from "react";

const useFormInput = (initialValue: any) => {
  const [value, setValue] = useState(initialValue);

  const handleChange = (e: any) => {
    setValue(e.target.value);
  };

  return {
    value,
    onChange: handleChange,
  };
};

// 在组件中使用自定义 Hook
const MyForm = () => {
  const usernameInput = useFormInput("");
  const passwordInput = useFormInput("");

  return (
    <form>
      <input type="text" {...usernameInput} />
      <input type="password" {...passwordInput} />
      {/* 其他表单元素 */}
    </form>
  );
};


export default MyForm