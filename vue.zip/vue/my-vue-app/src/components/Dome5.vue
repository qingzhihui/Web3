<template></template>

<script setup lang="ts">
// 属性存不存在

/**
 * 判断对象中是否存在某个属性
 * @param {Object} obj 对象
 * @param {String} key 属性名
 */
//  错误写法

// 第一种：
// function hasProperty(obj, key) {
//  return obj[key] !== undefined;
//     return obj.key !== undefined;
// }
// 第二种：
// function hasProperty(obj, key) {
// return Object.keys(obj).includes(key);
// }
// 第三种：
// function hasProperty(obj, key) {
// return obj.hasOwnProperty(key);
// }

var obj = { a: undefined, b: 1 }
Object.defineProperty(obj, 'c', {
    enumerable: false,
    value: 1
})
console.log(hasProperty(obj, 'a'));
console.log(Object.keys(obj));

//  正确的
function hasProperty(obj, key) {
    return key in obj;
}
</script>
