import { PAIR_ABI } from "./Contract/pancakepair";
import { wben_ABI } from "./Contract/wbenjson";
import List from "./UsJson/Colest.json";
import { ethers } from "ethers";
import { CONTRACT_ABI, CONTRACT_ADDRESS } from "./Contract/contractApp";

declare const window: Window & { ethereum: any };

export interface UiseProps {
  id?: number;
  name?: string;
  code?: string;
  token1?: string;
  token2?: string;
  userToken1?: string;
  userToken2?: string;
  icon?: string;
  icons?: string;
  counts?: string;
  Pending?: string;
  lPdata?: string;
  show?: number;
  wenbi?: number;
  lPdataToken1?: string;
  lPdataToken2?: string;
  binsShow?: boolean;
  bianes?: string;
  LpList?: number;
  pron1?: string;
  pron2?: string;
  pid?: number;
  sbuer?: string;
  inputValue?: string;
}

const InstancedContract = async (ADDRESS: any, ABI: any) => {
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = provider.getSigner();
  const Contract = new ethers.Contract(ADDRESS, ABI, signer);
  return Contract;
};

const ObtainAddress = async () => {
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = provider.getSigner();
  const address = await signer.getAddress();
  const balance = await signer.getBalance();
  return {
    address,
    balance,
  };
};

const usiderConter = async (code: any, address: any) => {
  const Contracter = await InstancedContract(code, PAIR_ABI);
  const usider = Contracter.allowance(address, CONTRACT_ADDRESS);
  return usider;
};
const bineofConter = async (code: any, address: any) => {
  const Contracter = await InstancedContract(code, PAIR_ABI);
  return await Contracter.balanceOf(address);
};
const pldataConter = async (id: any, address: any) => {
  const Contracter = await InstancedContract(CONTRACT_ADDRESS, CONTRACT_ABI);
  return await Contracter.userInfo(id, address);
};
const pendingConter = async (id: any, address: any) => {
  const Contracter = await InstancedContract(CONTRACT_ADDRESS, CONTRACT_ABI);
  return await Contracter.pendingReward(id, address);
};
const tokenConter = async (
  token1: any,
  token2: any,
  code: any,
  id: any,
  address: any
) => {
  const Contracter = await InstancedContract(CONTRACT_ADDRESS, CONTRACT_ABI);
  const ContractToken1 = await InstancedContract(token1, wben_ABI);
  const ContractToken2 = await InstancedContract(token2, wben_ABI);
  const PAIRContract = await InstancedContract(code, PAIR_ABI);
  const totalSupply = await PAIRContract.totalSupply();
  const bnbTotal1 = await ContractToken1.balanceOf(code);
  const decimals1 = await ContractToken1.decimals();
  const bnbTotal2 = await ContractToken2.balanceOf(code);
  const decimals2 = await ContractToken2.decimals();
  const lisne = await Contracter.userInfo(id, address);
  let holdRatio1 = Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
  let userBnb1 = Number(bnbTotal1) * holdRatio1;
  let nukse1 = userBnb1 / 10 ** decimals1;
  let holdRatio2 = Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
  let userBnb2 = Number(bnbTotal2) * holdRatio2;
  let nukse2 = userBnb2 / 10 ** decimals2;
  const t1 = new Date().valueOf();
  const beins =
    t1.toString().slice(0, 3) +
    "," +
    t1.toString().slice(3, 6) +
    "," +
    t1.toString().slice(6, 9);
  return {
    lPdataToken1: nukse1,
    lPdataToken2: nukse2,
    pron1: beins,
  };
};


export {
  PAIR_ABI,
  wben_ABI,
  List,
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
  ObtainAddress,
  InstancedContract,
  tokenConter,
  usiderConter,
  bineofConter,
  pldataConter,
  pendingConter,
};
