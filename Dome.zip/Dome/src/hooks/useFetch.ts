import { Option } from "antd/lib/mentions";
import React, { useState, useEffect, useRef, useLayoutEffect } from "react";


// useEffect 的函数会在组件渲染到屏幕之后执行
// useLayoutEffect则是在DOM结构更新后、渲染前执行，相当于有一个防抖效果

const useCallbackRef = (callback: any) => {
  const callbackRef = useRef(callback);
  useLayoutEffect(() => {
    callbackRef.current = callback;
  }, [callback]);
  return callbackRef;
};
// 两个陷阱
// 1.围绕清理函数
// 2.引用使用效果内部的状态

export const useFetch = (options: any) => {
  // 2.使用fetch将其数据下载到这里
  const [data, setData] = useState(null);
  const savedOnSuccess = useCallbackRef(options.onSuccess);
  useEffect(() => {
    console.log("useFetch useEffect");
    // 清理函数：当值改变原始清理时，函数在新的使用效果函数被调用之前被调用所以我们没有在这里返回一个
    // 我认为应该做的是我们应该觉得我们是否已经取消所以我将在这里创建一个let值 并说 被取消了
    let isCancelled = false;
    if (options.url) {
      fetch(options.url)
        .then((response) => response.json())
        .then((json) => {
          if (!isCancelled) {
            savedOnSuccess.current?.(json);
            setData(json);
          }
        });
      return () => {
        isCancelled = true;
      };
    }
    // 3.然后查看他，我们知道我们现在要一个新的对象，
    // 一个不会匹配旧的对象 因为他通过引用而不是通过值完成的，
    // 所以即使这个对象的内容是相同的，但每次通过这个时都会出现问题，每次他都是对
    // 新对象的新引用，这就是为什么这种效果会一遍又一遍的触发
  }, [options.url]);
  return {
    data,
  };
};
// 判断两个值是否一样
export const depCompar = (oldDeps: any, newDeps: any) => {
  return (
    oldDeps.length === newDeps.length &&
    oldDeps.every((dep: any, i: any) => dep === newDeps[i])
  );
};
