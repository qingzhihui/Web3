import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Deposit from "../page/Deposit";

class IndexRouter extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/Deposit" component={Deposit} />
          <Redirect from="/" to="/Deposit" />
        </Switch>
      </Router>
    );
  }
}

export default IndexRouter;
