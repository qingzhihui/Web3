import "./index.scss"
import logo from "../Header/img/logo.png"
import {useEffect} from "react";
import $ from "jquery"
import {useLocation} from "react-router-dom";

export default function Footer() {
  function refreshHeight() {
    $("#footer-white").height($("#footer").outerHeight() ?? "")
  }
  useEffect(() => {
    $(window).on("resize", refreshHeight)
    $(function() {
      refreshHeight()
    })
  }, [])
  const location = useLocation()
  useEffect(() => {
    refreshHeight()
  }, [location])
  return (
    <>
      <div id="footer-white" style={{marginTop: 50}}/>
      <div id="footer">
        <div className="top">
          <div className="left">
            <div className="sites">
              <div className="title">Partners</div>
              <div className="list">
                <a href="https://coinmarketcap.com" target="_blank" className="item">
                  <img src="/img/footer/1.png" alt=""/>
                  <span>CoinMarketCap</span>
                </a>
                 <a href="https://coingecko.com/" target="_blank" className="item">
                  <img src="/img/footer/2.png" alt=""/>
                  <span>CoinGecko</span>
                </a>
                <a href="https://dappradar.com/" target="_blank" className="item">
                  <img src="/img/footer/3.png" alt=""/>
                  <span>DappRadar</span>
                </a>
                <a href="https://pancakeswap.finance/" target="_blank" className="item">
                  <img src="/img/footer/pancakeswap.ico" alt=""/>
                  <span>Pancakeswap</span>
                </a>
                 <a href="https://binance.com/" target="_blank" className="item">
                  <img src="/img/footer/binance.jpg" alt=""/>
                  <span>Binance</span>
                </a>
                 <a href="https://tofunft.com/" target="_blank" className="item">
                  <img src="/img/footer/tofu.ico" alt=""/>
                  <span>TOFU</span>
                </a>
                 <a href="https://app.gala.games/" target="_blank" className="item">
                  <img src="/img/footer/gala-logo.png" alt=""/>
                  <span>GALA</span>
                </a>
              </div>
            </div>
            {/*<div className="sites">*/}
            {/*  <div className="title">CHART</div>*/}
            {/*  <div className="list">*/}
            {/*    <a href="#" className="item">*/}
            {/*      <img src="/img/footer/4.png" alt=""/>*/}
            {/*      <span>PooCoin</span>*/}
            {/*    </a>*/}
            {/*    <a href="#" className="item">*/}
            {/*      <img src="/img/footer/5.png" alt=""/>*/}
            {/*      <span>DEX TOOLS</span>*/}
            {/*    </a>*/}
            {/*  </div>*/}
            {/*</div>*/}
          </div>
          <div className="right">
            <img src={logo} alt=""/>
          </div>
        </div>
        <div className="icon-list">
        <a href="https://t.me/FBW1_NFT" target="_blank" className="icon-item">
          <img src="/img/telegram.png" alt=""/>
        </a>
        <a href="https://twitter.com/footballworld_V" target="_blank" className="icon-item">
          <img src="/img/tt.png" alt=""/>
        </a>
        <a href="https://docs.footballworldnft.com/" target="_blank" className="icon-item">
          <img src="/img/book.png" alt=""/>
        </a>
      </div>
        <div className="copyRight">Copyright © 2022 FootBallWorld Game Team. All Rights Reserved</div>
      </div>
    </>
  )
}