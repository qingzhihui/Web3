import React, { Component } from "react";
import Alieb from "../../assets/yant.mp4";
import "./index.scss";
import linslui from "../../assets/enlues/js.png";
export default class Abure extends Component {
  state = {
    const: 0,
  };
  showHome = () => {
    this.props.history.push("/index");
  };
  render() {
    return (
      <div className="liensekun">
        <video src={Alieb} autoPlay loop muted></video>
        <div className="abslsimg">
          <div className="bieklus">
            <div className="bieklus_zhowx">
             <div className="dabisle">
             <div className="linhseto" onClick={this.showHome}></div>
             </div>
              <div className="bieklus_img">
                <img src={linslui} alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
