import React, { useState, useRef } from 'react'
import './index.scss'
import { Button, Dropdown, Menu, Space, MenuProps } from "antd";
import { PhoneBlock } from '../../utils/phoneblock'
import { CaretDownOutlined } from "@ant-design/icons";
import { Radio } from 'antd';
export default function Register() {

  const [phoneblock, setPhoneBlock] = useState('+86')

  const selectPhoneBlock: MenuProps["onClick"] = ({ key }) => {
    PhoneBlock.map((item: any) => {
      if (item.key === key) {
        setPhoneBlock(PhoneBlock[Number(key) - 1].label)
      }
    })
  };

  const BlockMenu = <Menu onClick={selectPhoneBlock} items={PhoneBlock} />

  const [agree, setAgree] = useState<boolean>(false)

  const isAgree = useRef<any>()

  const handleAgreement = () => {
    setAgree(!isAgree.current.state.checked);
  }

  return (
    <div className='register'>
      <div className='register-area'>
        {/* 显示主标题 */}
        <span className='register-title'>Become a member of Anydoor Trip</span>
        {/* 显示两个副标题 */}
        <span className='register-subtitle'>Explore the world with Anydoor Trip</span>
        <span className='register-subtitle'>Join Anydoor Trip and enjoy unique privileges and unparalleled travel memories all over the world.</span>
        {/* 显示矩形框区域 */}
        <div className='register-reactangle'>
          {/* 显示标题 */}
          <div className='reactangle-title'>Join Anydoor Trip </div>

          {/* 第一行输入框区域 */}
          <div className='reactangle-inputColumn row fillWidth'>
            <input
              placeholder='Last name'
              className='reactangle-input'
            >
            </input>
            <input
              placeholder='First & middle name'
              className='reactangle-input'
            >
            </input>
          </div>

          {/* 第二行输入框区域 */}
          <div className='reactangle-inputColumn row fillWidth'>
            <input
              placeholder='Date of birth'
              className='reactangle-input'
            >
            </input>
            <input
              placeholder='Nickname (optional)'
              className='reactangle-input'
            >
            </input>
          </div>

          {/* 第三行输入框区域 */}
          <div className='reactangle-inputColumn row fillWidth'>
            <div className='phone-inputArea'>
              <Dropdown overlay={BlockMenu}>
                <Button >
                  <Space>
                    <div className="phone-blockArea">
                      {phoneblock}
                    </div>
                    <CaretDownOutlined />
                  </Space>
                </Button>
              </Dropdown>
              <input
                placeholder='Mobile phone'
                className='phone-input'
              >
              </input>
            </div>
            {/* <input
                placeholder='Mobile phone'
                className='reactangle-input'
              >
              </input> */}
            <input
              placeholder='Mail'
              className='reactangle-input'
            >
            </input>
          </div>

          {/* 显示标题 */}
          <div className='reactangle-title'>Password setting</div>

          {/* 密码输入框区域 */}
          <div className='reactangle-inputColumn column'>
            <input
              placeholder='Password'
              className='reactangle-input'
            >
            </input>
            <span className='password-tip'>6~15 alphanumeric characters are mixed, and English needs discrete upper and lower case</span>
          </div>

          {/* 再次输入密码输入框区域 */}
          <div className='reactangle-inputColumn column'>
            <input
              placeholder='Password Confirmation'
              className='reactangle-input'
            >
            </input>
            <span className='password-tip'>Please re-enter the password</span>
          </div>

          {/* 协议同意区域 */}
          <div className='agree-area'>
            {/* 单选框 */}
            <Radio onClick={handleAgreement} ref={isAgree} checked={agree} />
            <span className='agreement'>By submitting your application, you agree to Anydoor
              Trip's Membership Terms and Privacy Policy.
            </span>
          </div>

          {/* 注册按钮区域 */}
          <button className='register-button'>Register</button>
        </div>
      </div>
    </div>
  )
}
