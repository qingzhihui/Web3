// pages/Teamlist/Teamlist.js
import api from '../../config/api'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    activeNames: ['0'],
    Buelbei: "请选择团队",
    BusList: {},
    Tbuel: [],
    Lid: "",
    cbie: "1",
    beismShow: false
  },
  onBulenu(e) {
    var that = this;
    this.setData({
      Lid: e.currentTarget.dataset.id,
      activeNames: ['0'],
      Buelbei: e.currentTarget.dataset.name,
    })
    const adingList = wx.getStorageSync('admin')
    wx.request({
      // url: 'https://pjsp.vchao.wang/ums/umsTeam/getStatistics',
      url: 'http://localhost:8080/ums/umsTeam/getStatistics',
      method: "GET",
      header: {
        'content-type': 'application/json',
        'Authorization': 'Bearer ' + adingList.token
      },
      data: {
        userId: adingList.userId,
        teamId: e.currentTarget.dataset.id,
        interval: this.data.cbie,
        orgId: adingList.orgId
      },
      success: function (res) {
        that.setData({
          BusList: res.data.data
        })
      },
      fail: function (err) {
        console.log('请求失败', err)
      }
    })
  },
  onClickLeft() {
    wx.switchTab({
      url: '../index/index',
    })
  },
  onChangeLis(event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  onChange(event) {
    var that = this;
    const adingList = wx.getStorageSync('admin')
    if (event.detail.index == 0) {
      this.setData({
        cbie: 1
      })
    } else if (event.detail.index == 1) {
      this.setData({
        cbie: 2
      })
    } else {
      this.setData({
        cbie: 3
      })
    }
    wx.request({
      // url: 'http://localhost:8080/ums/umsTeam/getStatistics',
      url: 'https://pjsp.vchao.wang/ums/umsTeam/getStatistics',
      method: "GET",
      header: {
        'content-type': 'application/json',
        'Authorization': 'Bearer ' + adingList.token
      },
      data: {
        userId: adingList.userId,
        teamId: that.data.Lid,
        interval: this.data.cbie,
        orgId: adingList.orgId
      },
      success: function (res) {
        console.log(res);
        that.setData({
          BusList: res.data.data
        })
      },
      fail: function (err) {
        console.log('请求失败', err)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    const adingList = wx.getStorageSync('admin')
    if (adingList.userId == null) {
      this.setData({
        beismShow: true
      })
    } else {
      api._get(`ums/umsTeam/selectUmsTeamList/${adingList.userId}`).then(res => {
        that.setData({
          Tbuel: res.data,
          Lid: res.data[0].id,
          Buelbei: res.data[0].teamName
        })
        wx.request({
          url: 'https://pjsp.vchao.wang/ums/umsTeam/getStatistics',
          // url: 'http://localhost:8080/ums/umsTeam/getStatistics',
          method: "GET",
          header: {
            'content-type': 'application/json',
            'Authorization': 'Bearer ' + adingList.token
          },
          data: {
            userId: adingList.userId,
            teamId: res.data[0].id,
            interval: this.data.cbie,
            orgId: adingList.orgId
          },
          success: function (res) {
            console.log(res);
            that.setData({
              BusList: res.data.data
            })
          },
          fail: function (err) {
            console.log('请求失败', err)
          }
        })

      }).catch(e => {
        console.log(e);
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  }
})