import { ReadOutlined, DeleteOutlined } from "@ant-design/icons";
import {
  Button,
  DatePicker,
  DatePickerProps,
  Form,
  Input,
  Modal,
  Radio,
  Space,
  Table,
} from "antd";
import { RangePickerProps } from "antd/es/date-picker";
import type { ColumnsType } from "antd/es/table";
import { createRef, useState } from "react";
import "./index.css";

// 优惠卷界面
const CouponPage = () => {
  const { RangePicker } = DatePicker;
  const [isReviseTableData, setReviseTableData] = useState(false);
  const FormRef = createRef<any>();
  // 开始时间时间1
  const onChange = (
    value: DatePickerProps["value"] | RangePickerProps["value"],
    dateString: [string, string] | string
  ) => {
    console.log("Selected Time: 1", value);
    console.log("Formatted Selected Time: 1", dateString);
  };
  // 开始时间时间1
  const onOk = (
    value: DatePickerProps["value"] | RangePickerProps["value"]
  ) => {
    console.log("onOk: 1", value);
  };
  // 开始时间时间2
  const onChange2 = (
    value: DatePickerProps["value"] | RangePickerProps["value"],
    dateString: [string, string] | string
  ) => {
    console.log("Selected Time: 2", value);
    console.log("Formatted Selected Time: 2", dateString);
  };
  // 开始时间时间2
  const onOk2 = (
    value: DatePickerProps["value"] | RangePickerProps["value"]
  ) => {
    console.log("onOk 2: ", value);
  };
  interface DataType {
    key: number;
    couponName: string; // 优惠卷名称
    RollCollectionMethod: string; // 领卷方式
    discountMethod: string; // 折扣方式
    restrictedGoods: string; // 限定商品
    deductionLimit: string; // 抵扣额度
    useThreshold: string; // 使用门槛
    openingHours: string; //开放时间
    usageTime: string; //使用时间
    status: string; //状态
  }

  const data: DataType[] = [
    {
      key: 1,
      couponName: "酒店折扣卷",
      RollCollectionMethod: "主动领卷",
      discountMethod: "折扣",
      restrictedGoods: "限定商品",
      deductionLimit: "88折",
      useThreshold: "无门槛",
      openingHours: "2023-01-01—2023-01-10",
      usageTime: "2023-01-01—2023-06-01",
      status: "点击禁用",
    },
    {
      key: 2,
      couponName: "机票满减卷",
      RollCollectionMethod: "注册有礼",
      discountMethod: "满减",
      restrictedGoods: "无限定",
      deductionLimit: "68折",
      useThreshold: "满600可用",
      openingHours: "注册自动领取",
      usageTime: "2023-01-01—2023-06-01",
      status: "点击禁用",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "优惠卷名称",
      dataIndex: "couponName",
      width: 120,
    },
    {
      title: "领卷方式",
      dataIndex: "RollCollectionMethod",
      width: 120,
    },
    {
      title: "折扣方式",
      dataIndex: "discountMethod",
      width: 120,
    },
    {
      title: "限定商品",
      dataIndex: "restrictedGoods",
      width: 120,
      render: (_text, record) => (
        <Space size="middle">
          <span style={{ color: _text == "限定商品" ? "#3296FA" : "" }}>
            {_text}
          </span>
        </Space>
      ),
    },
    {
      title: "抵扣额度",
      dataIndex: "deductionLimit",
      width: 120,
    },
    {
      title: "使用门槛",
      dataIndex: "useThreshold",
      width: 120,
    },
    {
      title: "开放时间",
      dataIndex: "openingHours",
      // width: 120,
    },
    {
      title: "使用时间",
      dataIndex: "usageTime",
      // width: 120,
    },
    {
      title: "状态",
      dataIndex: "status",
      // width: 120,
      render: (_text, record) => (
        <Space size="middle">
          <span className="coupon_statusBackClo">{_text}</span>
        </Space>
      ),
    },
    {
      title: "操作",
      key: "action",
      // width: 200,
      render: (_, record) => (
        <Space size="middle">
          <span className="coupon_publicCursor" onClick={readBtn(record)}>
            <ReadOutlined />
          </span>
          <span className="coupon_publicCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 查看
  const readBtn = (record: any) => {
    return () => {
      console.log("点击了查看");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };
  const cehsi: any = [
    {
      id: 0,
      value: "满减卷",
    },
    {
      id: 1,
      value: "折扣卷",
    },
    {
      id: 2,
      value: "全场卷",
    },
    {
      id: 3,
      value: "指定分类卷",
    },
    {
      id: 4,
      value: "指定商品卷",
    },
  ];
  //   用于判断点击变色
  const [isNum, setNum] = useState(0);

  //   各类卷按钮
  const handleClick = (index: any) => {
    return () => {
      setNum(index);
      if (index == 0) {
        console.log("满减卷");
      } else if (index == 1) {
        console.log("折扣卷");
      } else if (index == 2) {
        console.log("全场卷");
      } else if (index == 3) {
        console.log("指定分类卷");
      } else {
        console.log("指定商品卷");
      }
    };
  };
  // 添加--关闭弹窗
  const ReviseTableDataClose = () => {
    setReviseTableData(false);
  };

  // 添加
  const addShou = () => {
    return () => {
      console.log("添加按钮,打开弹窗");
      setReviseTableData(true);
    };
  };
  //  添加-提交按钮
  const onReviseSubmitBtn = (values: any) => {
    console.log("添加提交的数据", values);
    // 清空
    FormRef.current.resetFields();
  };

  return (
    <div className="coupon_Box">
      <div className="coupon_headerBox">
        <div className="coupon_headerBox_thread"></div>
        <div className="coupon_headerBox_Tit">&nbsp;&nbsp;&nbsp; 优惠卷</div>
        <div className="coupon_headerbtnBox">
          {cehsi.map((item: any, index: any) => {
            return (
              <div
                key={item.id}
                style={{
                  backgroundColor: index == isNum ? "#3296FA" : "",
                  color: index == isNum ? "#FFF" : "",
                }}
                onClick={handleClick(index)}
              >
                {item.value}
              </div>
            );
          })}
        </div>
        <div className="coupon_headerAddBtn" onClick={addShou()}>
          添加
        </div>
        {/* 添加 */}
        <Modal
          footer={[null]}
          open={isReviseTableData}
          onCancel={ReviseTableDataClose}
        >
          <div className="coupon_headerBox">
            <div className="coupon_headerBox_thread"></div>
            <div className="coupon_headerBox_Tit">
              &nbsp;&nbsp;&nbsp; 添加优惠卷
            </div>
          </div>
          <div className="coupon_tableBox">
            <Form
              name="basic"
              ref={FormRef}
              labelCol={{ span: 7 }}
              wrapperCol={{ span: 16 }}
              style={{ maxWidth: 700 }}
              initialValues={{ remember: true }}
              onFinish={onReviseSubmitBtn}
              autoComplete="off"
            >
              <Form.Item label="优惠卷名称" name="couponName">
                <Input placeholder="请输入优惠卷名称" />
              </Form.Item>
              <Form.Item label="领卷方式" name="billingMethod">
                <Radio.Group>
                  <Radio value="1"> 主动领卷 </Radio>
                  <Radio value="2"> 新用户注册发放 </Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item label="折扣方式" name="discountMethod">
                <Radio.Group>
                  <Radio value="1"> 满减 </Radio>
                  <Radio value="2"> 折扣 </Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item label="限定商品" name="restrictedGoods">
                <Radio.Group>
                  <Radio value="1"> 无限定 </Radio>
                  <Radio value="2"> 指定商品 </Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item label="折扣额度" name="deductionLimit">
                <Input placeholder="满减为减掉的金额，折扣为减去百分之几" />
              </Form.Item>
              <Form.Item label="使用门槛" name="useThreshold">
                <Input placeholder="订单满多元才能使用" />
              </Form.Item>
              <Form.Item label="发放时间" name="openingHours">
                <RangePicker
                  showTime={{ format: "HH:mm" }}
                  format="YYYY-MM-DD HH:mm"
                  onChange={onChange}
                  onOk={onOk}
                />
              </Form.Item>
              <Form.Item label="使用时间" name="usageTime">
                <RangePicker
                  showTime={{ format: "HH:mm" }}
                  format="YYYY-MM-DD HH:mm"
                  onChange={onChange2}
                  onOk={onOk2}
                />
              </Form.Item>
              <Form.Item label="状态" name="restrictedGoods">
                <Radio.Group>
                  <Radio value="1"> 启用 </Radio>
                  <Radio value="2"> 禁用 </Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                <Button
                  className="coupon_btn"
                  size="middle"
                  type="primary"
                  htmlType="submit"
                >
                  提交
                </Button>
              </Form.Item>
            </Form>
          </div>
        </Modal>
      </div>

      <div className="coupon_tableBox">
        <Table columns={columns} dataSource={data} />
      </div>
    </div>
  );
};

export default CouponPage;
