import React from "react";
import "./index.scss";

const TickeList = () => {
    return (
        <div className="Tickelist">
            <div className="Planelist_item1">
                <img
                    className="psuieng_image"
                    src={require("@/assets/image/Rectangle-2.png")}
                    alt=""
                />
                <div className="Planelist_item1_priobu">
                    <div className="Planelist_item1_image">
                        <img src={require("@/assets/image/block_arr.png")} alt=""/>
                    </div>
                    <div className="Planelist_item1_title">
                        <div className="Planelist_item1_text">Concert</div>
                    </div>
                </div>
            </div>
            <div className="priobu_cender">
                <div className="priobu_Buining">
                    <div className="priobu_cender_image">
                        <img src={require("@/assets/image/damai.png")} alt=""/>
                    </div>
                </div>
                <div className="priobu_Tnxie">
                    <div className="priobu_Tnxie_title">Time: 2022.12.17 Saturday 20:00
                        Venue: Beijing | Beijing Le Space</div>
                    <div className="priobu_Tnxie_nro">Quantity: 1</div>
                </div>
            </div>
            <div className="speubsei_porbtn">
                <button>Details</button>
            </div>
        </div>
    );
};

export default TickeList;
