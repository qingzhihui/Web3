// pages/Mine/Mine.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    paramAtoB: "",
    UserData: {},
    useState: false,
    LoginTitle: "登录"
  },
  onLoad() {
    const AdminData = wx.getStorageSync('admin');
    if (AdminData === "") {
      this.setData({
        useState: true,
      })
    } else {
      this.setData({
        UserData: AdminData,
        useState: false,
      })
    }
  },
  MineTitleLongeiu(){
    wx.navigateTo({
      url:'../logines/logines'
    })
  },
  LoginStateButton(event: any) {
    const AdminData = wx.getStorageSync('admin');
    this.setData({
      useState: event,
      UserData: AdminData,
    })
  },
  MinderOnClick() {

  },
  MinLogOutlogin() {
    wx.showToast({
      title: '退出成功',
      duration: 1000
    });
    wx.removeStorageSync('admin');
    wx.removeStorageSync('history');
    this.setData({
      UserData: {},
      useState: true
    })
  },
  handleContact(e: any) {
    console.log(e.detail.path)
    console.log(e.detail.query)
  },
  MinMemberShow() {
    wx.navigateTo({
      url: '../MinMember/MinMember'
    })
  },
  MinFollowShow() {
    wx.navigateTo({
      url: '../MinFollow/MinFollow'
    })
  },
  MinroblemShow() {
    wx.navigateTo({
      url: '../Minroblem/Minroblem'
    })
  },
  MinPrivacSHow() {
    wx.navigateTo({
      url: '../MinPrivac/MinPrivac'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})