import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import BesHome from "../view/BesHome";
import BesAbout from "../view/BesAbout";
import BesGame from "../view/BesGame";
import BesMint from "../view/BesMint";
import BesMarkey from "../view/BesMarkey";
import BesRank from '../view/BesRank';

class indexRouter extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/Home" component={BesHome} />
          <Route path="/About" component={BesAbout} />
          <Route path="/Mint" component={BesMint} />
          <Route path="/Game" component={BesGame} />
          <Route path="/Market" component={BesMarkey} />
          <Route path="/Rank" component={BesRank} />
          <Redirect from="/" to="/Home" />
        </Switch>
      </Router>
    );
  }
}

export default indexRouter;
