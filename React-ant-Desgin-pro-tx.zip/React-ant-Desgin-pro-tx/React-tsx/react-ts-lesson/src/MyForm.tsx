import React, { FormEvent, useState, ChangeEvent } from "react";

function MyForm() {
  const [username, setUsername] = useState<string>("");
  const [level, setLevel] = useState("1");
  const submit = (e: FormEvent) => {
    e.preventDefault();
    console.log("submit");
  };
  const changeUsername = (e: ChangeEvent<HTMLInputElement>) => {
    setUsername(e.target.value);
  };
  const changeLevel = (e: ChangeEvent<HTMLSelectElement>) => {
    setLevel(e.target.value);
  };
  return (
    <div>
      {username}
      {level}
      <form onSubmit={submit}>
        <input type="text" value={username} onChange={changeUsername} />
        <select defaultValue={level} onChange={changeLevel}>
          <option value={1}>op1</option>
          <option value={2}>op2</option>
          <option value={3}>op3</option>
        </select>
        <button type="submit">提交</button>
      </form>
    </div>
  );
}

export default MyForm;
