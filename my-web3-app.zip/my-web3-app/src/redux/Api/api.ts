import { Meta_ADDRESS, Meta_ABI } from "../Contract/MetaContract";
import { PAIR_ABI } from "../Contract/Pancakepair";
const Meta: any = { Meta_ADDRESS, Meta_ABI };
export { Meta, PAIR_ABI };
