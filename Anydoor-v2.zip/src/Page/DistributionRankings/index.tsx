import { Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

// 分销排行榜界面
const DistributionRankings = () => {
  interface DataType {
    key: number;
    ranking: string; // 排名
    userId: string; //用户ID
    TotalWithdrawalAmount: string; //提现总额
  }

  const data: DataType[] = [
    {
      key: 1,
      ranking: "1",
      userId: "1648",
      TotalWithdrawalAmount: "3155",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "排名",
      dataIndex: "ranking",
      // width: 200,
    },
    {
      title: "用户ID",
      dataIndex: "userId",
      // width: 200,
    },
    {
      title: "提现总额",
      dataIndex: "TotalWithdrawalAmount",
      // width: 200,
    },
  ];

  return (
    <div className="fxtx_Box">
      <div className="fxtx_headerBox">
        <div className="fxtx_headerBox_thread"></div>
        <div className="fxtx_headerBox_Tit">&nbsp;&nbsp;&nbsp; 分销排行榜</div>
      </div>

      <div className="fxtx_tableBox">
        <Table columns={columns} dataSource={data} />
      </div>
      <div className="fxtx_footer">最后更新于2023-03-01</div>
    </div>
  );
};

export default DistributionRankings;
