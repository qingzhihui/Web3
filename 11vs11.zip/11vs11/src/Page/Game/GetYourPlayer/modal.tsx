import "./modal.scss"
import loading from "./loading.png"
import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import {useTranslation} from "react-i18next";

type Props = {
  status: "loading" | "success" | "error" | "close",
  errMessage: string
  setStatus(status: "loading" | "success" | "error" | "close"): void
}

export default function Modal(props: Props) {
  const navigate = useNavigate()
  const {t} = useTranslation()
  function jump() {
    navigate("/game/my-player")
  }
  return (
    <>
      {props.status !== "close" ? (
        <div className="get-your-player-modal">
          <div className="title">
            {
              props.status === "success" ?
                "Purchase success" : props.status === "error" ? "Purchase error" : props.status === "loading" ? "Loading Purchase" : null
            }
          </div>
          <div className="content">
            <video autoPlay loop muted src="https://boxcard.footballworldnft.com/box.mp4"/>
            {
              props.status === "loading" ? (
                <div className="loading">
                  <img src={loading} alt=""/>
                  loading
                </div>
              ) : props.status === "error" ? (
                <>
                  <div className="message">{props.errMessage}</div>
                  <div className="common-btn" onClick={() => props.setStatus("close")}>{t("game.close")}</div>
                </>
              ) : props.status === "success" ? (
                <div className="common-btn" onClick={jump}>Check</div>
              ) : null
            }
          </div>
        </div>
      ): null}
    </>
  )
}