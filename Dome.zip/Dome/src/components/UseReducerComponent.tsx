import React, { useReducer } from "react";

const initialState = {
  counter: 100,
};

// 主要作用就是更新state

// 1. useReducer
// 主要作用就是更新state。

// 参数：

// 第一个是 reducer 函数，这个函数返回一个新的state。
// 后面再详述该函数的使用。
// 第二个是 state 初始值。
// 返回值：

// 当前 state。（可以在业务代码中获取、操作的就是它。）
// dispatch 函数，纯函数，用来更新state，并会触发re-render。
// （通俗地说，dispatch就是重新操作state的，会让组件重新渲染）

// 2. reducer函数
// 作用：处理传入的state，并返回新的state。

// 参数：
// 接受当前 state。
// 接受一个action，它是 dispatch 传入的。

// 返回值：
// 新的state。

// 3. dispatch函数
// 发送一个对象给reducer，即action。

// 参数： 一个对象。
// 返回值： 无。

type ACTIONTYPES =
  | { type: "increment"; payload: number }
  | { type: "decrement"; payload: number };

function counterReducer(state: typeof initialState, action: ACTIONTYPES) {
  switch (action.type) {
    case "increment":
      return {
        ...state,
        counter: state.counter + action.payload,
      };
    case "decrement":
      return {
        ...state,
        counter: state.counter - action.payload,
      };
    default:
      throw new Error("Bad action");
  }
}

const UseReducerComponent = () => {
  const [state, dispatch] = useReducer(counterReducer, initialState);
  return (
    <div>
      <div>{state.counter}</div>
      <div>
        <button
          onClick={() =>
            dispatch({
              type: "increment",
              payload: 10,
            })
          }
        >
          increment
        </button>
        <button
          onClick={() =>
            dispatch({
              type: "decrement",
              payload: 10,
            })
          }
        >
          decrement
        </button>
      </div>
    </div>
  );
};

export default UseReducerComponent;
