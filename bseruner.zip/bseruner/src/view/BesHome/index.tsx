import React, { useEffect, useState } from "react";
import { useMoralis } from "react-moralis";
import Header from "../../components/Header";
import Heues from "../../components/Heues";
import "./index.scss";
import dvide from "../../assets/8889.mp4";
import logdein from "../../assets/11111.mp4";
import ShuaQin from "../../components/ShueQin";
declare const window: Window & { ethereum: any };

function Home(props: any) {
  const [showBen, setShowBen] = useState(true);
  useEffect(() => {
    const width = document.documentElement.clientWidth;
    const height = document.documentElement.clientHeight;
    if (width < height) {
      const contentDOM = document.getElementById("sbdueo");
      contentDOM!.style.width = height + "px";
      contentDOM!.style.height = width + "px";
      contentDOM!.style.top = (height - width) / 2 + "px";
      contentDOM!.style.left = 0 - (height - width) / 2 + "px";
      contentDOM!.style.transform = "rotate(90deg)";
    }
    setTimeout(() => {
      setShowBen(false);
    }, 5000);
  }, []);
  return (
    <div className="conteron">
      {showBen ? (
        <div className="logdeng">
          <video id="video" src={logdein} autoPlay loop muted></video>
        </div>
      ) : (
        <>
          <div className="bsietob">
            <div className="bsie_ero">
              <div className="sbdueo">
                <video id="sbdueo" src={dvide} autoPlay loop muted></video>
              </div>
            </div>
          </div>
          <ShuaQin />
          <div className="tbalei">
            <Header />
            <Heues burl="/Home" />
          </div>
          <div className="sbueos">
            <div className="sbueosItem">
              <div className="sbtem1">
                <span>PRIVACY POLICY</span>
              </div>
              <div className="sbtem2">
                <span>TERMS OF SERVICE</span>
              </div>
            </div>
            <div className="sbueosItem">
              <div className="sbtem2">
                <span>Copyright @ 2022 PONZOPAY.AII rights reserved.</span>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
export default Home;
