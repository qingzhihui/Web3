import React, { Component } from "react";
import "./index.scss";
import tox from "../../assets/enlues/lt1.png";
import tox2 from "../../assets/enlues/lt2.png";
import toki from "../../assets/1.gif";
import toki2 from "../../assets/kus.png";
export default class Firstu extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  scrollToAnchor = (anchorName) => {
    if (anchorName) {
      let anchorElement = document.getElementById(anchorName);
      if (anchorElement) {
        anchorElement.scrollIntoView({ block: "start", behavior: "smooth" });
      }
    }
  };
  HomeShow = () => {
    this.props.history.push("/index");
  };
  componentDidMount() {}
  render() {
    return (
      <div className="danaro">
        <div className="Lisnkuer">
          <div className="nkuer1"></div>
          <div className="nkuer2">
            <div className="linehseshow">
              <div className="ksiebsue">
                <div className="ksi_eitem">
                  <div className="toxpg">
                    <img src={tox} alt="" />
                  </div>
                  <div className="toxpglsien">
                    <div className="nudrks">
                      Hello! you can ask me questions.{" "}
                    </div>
                  </div>
                </div>
                <div className="ksi_eitem" id="activity1">
                  <div className="toxpglsien2">
                    <div className="nudrks">Have you heard of Rektclub?</div>
                  </div>
                  <div className="toxpg">
                    <img src={tox2} alt="" />
                  </div>
                </div>
                <div className="ksi_eitem">
                  <div className="toxpg">
                    <img src={tox} alt="" />
                  </div>
                  <div className="sliebselt">
                    <div className="toxpglsien5">
                      <div className="nudrks">
                        Yes I have, Rektclub is the social club of normie
                        hodlers. A group of ever-rekt crypto hodlers who always
                        believe in the potential of this space despite being 99%
                        down on our bags.
                      </div>
                    </div>
                    <div className="toxpglsien5_1">
                      <div className="nudrks">
                        Rektclub is the symbol of resilience, courage and
                        degen-ness. Are you rekt yet?
                      </div>
                    </div>
                  </div>
                </div>
                <div className="ksi_eitem">
                  <div className="toxpglsien2s" id="activity2">
                    <div className="nudrks">
                      What do I get from buying this ?
                    </div>
                  </div>
                  <div className="toxpg">
                    <img src={tox2} alt="" />
                  </div>
                </div>
                <div className="ksi_eitem">
                  <div className="toxpg">
                    <img src={tox} alt="" />
                  </div>
                  <div className="toxpglsien5_2">
                    <div className="nudrks">
                      {" "}
                      No benefits whatsoever. Remember how you were rekt last
                      time? We don’t promise anything unless we can deliver.
                    </div>
                  </div>
                </div>
                <div className="ksi_eitem">
                  <div className="toxpglsien2s">
                    <div className="nudrks">
                      Yo ! so what does this thing look like?
                    </div>
                  </div>
                  <div className="toxpg">
                    <img src={tox2} alt="" />
                  </div>
                </div>
                <div className="ksi_eitem" id="activity5">
                  <div className="toxpg">
                    <img src={tox} alt="" />
                  </div>
                  <div className="toxpglsien5s">
                    <div className="nudrks">
                      <img src={toki} alt="" />
                    </div>
                  </div>
                </div>
                <div className="ksi_eitem">
                  <div className="toxpg">
                    <img src={tox} alt="" />
                  </div>
                  <div className="toxpglsien">
                    <div className="nudrks">
                      Are you hodling more even tho you’re rekt hard?
                    </div>
                  </div>
                </div>
                <div className="ksi_eitem" id="activity4">
                  <div className="toxpglsien2s_1">
                    <div className="nudrks">
                      What type of amateur question is that, of course LOL
                    </div>
                  </div>
                  <div className="toxpg">
                    <img src={tox2} alt="" />
                  </div>
                </div>
              </div>
            </div>
            <div className="spelixsietr">
              <div
                className="lsine1"
                onClick={() => this.scrollToAnchor("activity1")}
              >
                about rekt club
              </div>
              <div
                className="lsine1"
                onClick={() => this.scrollToAnchor("activity2")}
              >
                society benefits
              </div>
              <div
                className="lsine1"
                onClick={() => this.scrollToAnchor("activity4")}
              >
                exhibit
              </div>
              <div
                className="lsine1"
                onClick={() => this.scrollToAnchor("activity5")}
              >
                team
              </div>
            </div>
          </div>
          <div
            className="speliguab"
            onClick={() => {
              this.HomeShow();
            }}
          >
            <div className="ksibzn"></div>
          </div>
        </div>
      </div>
    );
  }
}
