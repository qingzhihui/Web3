import React, { Component, useState } from 'react';
import "./index.css"
import { Button, Checkbox, Form, Input, } from 'antd';


// 支付配置界面
const BasicSettingsPage: React.FC = () => {

    // 提交
    const submitData = (values: any) => {
        console.log('提交的数据:', values);
    };

    const onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };

    const { TextArea } = Input;
    return (
        <div className='zf_Box'>
            <div className='zf_headerBox'>
                <div className='zf_headerBox_thread'></div>
                <div className='zf_headerBox_Tit'>&nbsp;&nbsp;&nbsp;支付配置</div>
            </div>
            <div className='zf_inputBox'>
                <Form
                    name="basic"
                    labelCol={{ span: 8 }}
                    wrapperCol={{ span: 16 }}
                    style={{ maxWidth: 600 }}
                    initialValues={{ remember: true }}
                    onFinish={submitData}
                    onFinishFailed={onFinishFailed}
                    autoComplete="off"
                >
                    <Form.Item label="小程序支付商家号" name="payMerchantID">
                        <Input placeholder="请输入小程序支付商家号" />
                    </Form.Item>

                    <Form.Item label="小程序支付Api密码" name="payApiPassword">
                        <Input placeholder="请输入小程序支付Api密码" />
                    </Form.Item>
                    <Form.Item label="微信支付apiclient_cert.pem" name="payCert">
                        <TextArea rows={4} placeholder="为保证安全性，不显示证书内容，若要修改，请直接输入" />
                    </Form.Item>
                    <Form.Item label="微信支付apiclient_key.pem" name="payKey">
                        <TextArea rows={4} placeholder="为保证安全性，不显示证书内容，若要修改，请直接输入" />
                    </Form.Item>
                    <Form.Item label="其他" name="other">
                        <Input placeholder="请输入" />
                    </Form.Item>

                    <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                        <Button className='zf_btn' size="middle" type="primary" htmlType="submit">提交</Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    )
}

export default BasicSettingsPage;