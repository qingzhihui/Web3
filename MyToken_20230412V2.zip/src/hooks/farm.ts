import { BigNumber } from "ethers";
import { FARM_ABI, FARM_ADDR } from "../config/abi/farmContract";
import { PAIR_ABI } from "../config/abi/pancakepair";
import { WBENJson } from "../config/abi/wbenjson";
import PoolToken from "../config/Pool.json";
import {
  FormatUnitsConver,
  InstancedContract,
  TokenNameDecimals,
  allowance,
} from "./config";

const balanceOfConter = async (code: any, address: any) => {
  const LPContract: any = InstancedContract(code, WBENJson);
  const balanceOf = await LPContract.balanceOf(address);
  const decimals = await LPContract.decimals();
  const balanceShow = FormatUnitsConver(balanceOf, decimals);
  return {
    balanceOf: balanceOf.toString(),
    balanceShow: balanceShow,
  };
};
const userInfoConter = async (pid: any, address: any, code: any) => {
  const LPContract: any = InstancedContract(code, WBENJson);
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const userInfo = await farmContract.userInfo(pid, address);
  const decimals = await LPContract.decimals();
  return {
    StakedLP: userInfo.depositAmount.toString(),
    StakedLPShow: FormatUnitsConver(
      userInfo.depositAmount.toString(),
      decimals
    ),
  };
};
const getRewardToken = async () => {
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const rewardToken = await farmContract.rewardToken();
  const rewardTokenData = await TokenNameDecimals(rewardToken);
  const rewardTokenSymbol = rewardTokenData.symbol;
  return rewardTokenSymbol
};
const getUserLevelByPid = async (pid: any, address: any) => {
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const userlevel = await farmContract.level(pid,address);
  return userlevel.toString()
};
const pendingMintingRewardConter = async (pid: any, address: any) => {
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const rewardToken = await farmContract.rewardToken();
  const RewardData = await TokenNameDecimals(rewardToken);
  const pendingMintingReward = await farmContract.pendingMintingReward(
    pid,
    address
  );
  return {
    pendingMinting: FormatUnitsConver(
      pendingMintingReward.toString(),
      RewardData.decimals
    ),
  };
};
const getUserTotalPartnerRewardConter = async (address: any) => {
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const rewardToken = await farmContract.rewardToken();
  const rewardTokenData = await TokenNameDecimals(rewardToken);
  const getUserTotalPartnerReward = await farmContract.getUserTotalPartnerReward(address);
  const getUserTotalNodeReward = await farmContract.getUserTotalNodeReward(address);
  return {
    totalPartnerReward: FormatUnitsConver(
      getUserTotalPartnerReward.toString(),
      rewardTokenData.decimals
    ),
    totalNodeReward: FormatUnitsConver(
      getUserTotalNodeReward.toString(),
      rewardTokenData.decimals
    ),
  };
};
const pendingDividendRewardConter = async (pid: any, address: any) => {
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const usdtToken = await farmContract.USDT();
  const usdtTokenData = await TokenNameDecimals(usdtToken);
  const pendingDividendReward = await await farmContract.pendingDividendReward(
    pid,
    address
  );
  return {
    pendingDividend: FormatUnitsConver(
      pendingDividendReward.toString(),
      usdtTokenData.decimals
    ),
  };
};

const allowanceValConter = async (code: any, address: any) => {
  const allowanceVal = await allowance(code, address);
  const MaxUint256: BigNumber = BigNumber.from(
    "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
  );
  if (allowanceVal.eq(MaxUint256)) {
    return {
      show: true,
    };
  } else {
    return {
      show: false,
    };
  }
};

const wagmiState = () => {
  const colleState = localStorage.getItem("wagmi.connected");
  if (colleState !== null && colleState !== undefined) {
    return true;
  } else {
    return false;
  }
};

const tokenConter = async (
  token1: any,
  token2: any,
  code: any,
  id: any,
  address: any
) => {
  const FarmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const Token0Contract: any = InstancedContract(token1, WBENJson);
  const Token1Contract: any = InstancedContract(token2, WBENJson);
  const PairContract: any = InstancedContract(code, PAIR_ABI);
  const totalSupply = await PairContract.totalSupply();
  const Token0Total = await Token0Contract.balanceOf(code);
  const Token0Decimals = await Token0Contract.decimals();
  const Token1Total = await Token1Contract.balanceOf(code);
  const Token1Decimals = await Token1Contract.decimals();
  const userInfo = await FarmContract.userInfo(id, address);
  let holdRatio = Number(userInfo.depositAmount) / (Number(totalSupply) - 1000);
  let userToken0Amount = Number(Token0Total) * holdRatio;
  let userToken0 = userToken0Amount / 10 ** Token0Decimals;
  let userToken1Amount = Number(Token1Total) * holdRatio;
  let userToken1 = userToken1Amount / 10 ** Token1Decimals;
  const t1 = new Date().valueOf();
  const beins =
    t1.toString().slice(0, 3) +
    "," +
    t1.toString().slice(3, 6) +
    "," +
    t1.toString().slice(6, 9);
  return {
    Token0AmountShow: userToken0,
    Token1AmountShow: userToken1,
    pron1: beins,
  };
};

const DleiserPoers = () => {
  const data: any = [];
  PoolToken.map((item: any) => {
    item.balance = "";
    item.balanceShow = "0.0";
    item.StakedLP = "";
    item.StakedLPShow = "0.0";
    item.WeTalk1 = "";
    item.WeTalk2 = "";
    item.drawValu = "";
    item.dividend = "";
    item.show = false;
    data.push(item);
  });
  return data;
};

export {
  tokenConter,
  balanceOfConter,
  userInfoConter,
  pendingMintingRewardConter,
  getUserTotalPartnerRewardConter,
  pendingDividendRewardConter,
  allowanceValConter,
  wagmiState,
  DleiserPoers,
  getRewardToken,
  getUserLevelByPid
};
