// interface Box {
//   contents: any;
// }
// let box: Box = {
//   contents: 100,
// };

// unknown类型是不能做任何操作的
// interface Box {
//   contents: unknown;
// }

// let x: Box = {
//   contents: "hello world",
// };

// 两种解决办法
// 第一种使用类型缩小，加一个判断
// if (typeof x.contents == "string") {
//   console.log(x.contents.toLowerCase());
// }
// 第二种办法，使用类型断言（直接打印）
// console.log((x.contents as string).toLowerCase());

// 函数的重载
// interface NumerBox {
//   contents: number;
// }

// interface StringBox {
//   contents: string;
// }

// interface BooleanBox {
//   contents: boolean;
// }

// function setContents(box: StringBox, newContents: string): void;
// function setContents(box: NumerBox, newContents: number): void;
// function setContents(box: BooleanBox, newContents: boolean): void;

// function setContents(box: { contents: any }, newContents: any) {
//     box.contents = newContents
// }

// 泛型(让用户定义传入什么类型)
// interface Box<Type> {
//   contents: Type;
// }

// let boxA: Box<string> = {
//   contents: "hello",
// };

// interface StringBox {
//   contents: number;
// }

// let boxB: StringBox = {
//   contents: 100,
// };

// 泛型扩展
// interface Box<Type> {
//   contents: Type;
// }

// interface Apple {
//   // ..
// }

// let a: Apple = {};
// type AppleBox = Box<Apple>;

// let ab: AppleBox = {
//   contents: a,
// };

// 类型别名定义泛型

// type Box<Type> = {
//   contents: Type;
// };

// 联合类型
// type OrNull<Type> = Type | null;
// type OneOrMany<Type> = Type | Type[];
// type OneOrManyOrNull<Type> = OrNull<OneOrMany<Type>>;
// type OOneOrManyOrNullNString = OneOrManyOrNull<string>;

function identity<Type>(arg: Type): Type {
  return arg;
}

let output = identity<string>("myString");

console.log(output);
