<template>
</template>

<script setup>
document.addEventListener('visibilitychange', function () {

  if (document.visibilityState === "hidden") {
    console.log(document.visibilityState)
  } else {
    console.log(document.visibilityState)
  }

})
</script>

<style>
</style>
