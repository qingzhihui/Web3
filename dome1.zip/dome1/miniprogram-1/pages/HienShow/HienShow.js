import api from '../../config/api'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    HisList: [],
    activeNames: ['0'],
    Buelbei: "请选择团队",
    Tbuel: [],
    Lid: "",
    qusersid: "",
    userId:"",
    tid:""
  },
  onClickLeft() {
    wx.switchTab({
      url: '../mssage/mssage',
    })
  },
  onHeltail(e) {
    wx.navigateTo({
      url: `../Reportpage/Reportpage?id=${e.currentTarget.id}&tid=${this.data.userId}&zid=${this.data.tid}`
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var that = this;
    const adingList = wx.getStorageSync('admin')
    api._get(`ums/umsTeam/selectUmsTeamList/${adingList.userId}`).then(res => {
      console.log(res);
      that.setData({
        Tbuel: res.data,
        qusersid: options.id,
        userId:adingList.userId
      })
    })
  },
  onChange(event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  GetAddressList(){
    var that = this;
    api._get(`ums/umsQuestionnaire/getReportingQuestionnaire/${that.data.userId}/${that.data.tid}`).then(res => {
      console.log(res);
      that.setData({
        HisList: res.data,
      })
    }).catch(e => {
      console.log(e);
    })
  },
  onBulenu(e) {
    var that = this;
    api._get(`ums/umsQuestionnaire/getReportingQuestionnaire/${that.data.userId}/${e.currentTarget.dataset.id}`).then(res => {
      console.log(res);
      that.setData({
        HisList: res.data,
        Buelbei:e.currentTarget.dataset.name,
        activeNames:['0'],
        tid:e.currentTarget.dataset.id
      })
    }).catch(e => {
      console.log(e);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  }
})