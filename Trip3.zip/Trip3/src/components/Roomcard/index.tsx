import React from 'react'
import './index.scss'

export default function index() {
  return (
    <div className='roomcard'>
      <div className='cardleft'>
        <img src={require('@/assets/image/room.png')} alt="" className='imgroom' />
      </div>
      <div className='cardright'>
        <div className='info'>
          <div className='king'>King bed room</div>
          <div className='bed'><img src={require('@/assets/image/material.png')} alt="" /> 1 queen bed (1.8m wide)</div>
          <div className='sleeps'><img src={require('@/assets/image/tabler.png')} alt="" /> Sleeps two people</div>
          <div className='meters'><img src={require('@/assets/image/mdi.png')} alt="" /> 50 square meters | 1st floor</div>
          <div className='imgs'>
            <img src={require('@/assets/image/iconoir.png')} alt="" />
            <img src={require('@/assets/image/healthicons.png')} alt="" />
            <img src={require('@/assets/image/ic.png')} alt="" />
            <img src={require('@/assets/image/bi.png')} alt="" />
            <img src={require('@/assets/image/grommet.png')} alt="" />
            <img src={require('@/assets/image/fluen22.png')} alt="" />
          </div>
        </div>
        <div className='inforight'>
          <img src={require('@/assets/image/am.png')} alt="" />
          <div className='money'>$4,000 /night</div>
          <div className='booknow'>Book Now</div>
        </div>
      </div>
    </div>
  )
}
