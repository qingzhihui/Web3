import { formatTime } from "../../../utils/util";
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    dataList:{
      type: Array,
      observer: "mapDataList"
    }
  },

  /**
   * 监听器
  */
  observers: {

  },

  /**
   * 页面生命周期函数 
  */
  lifetimes: {
    

  },

  /**
   * 组件的初始数据
   */
  data: {
    
  },

  /**
   * 组件的方法列表
   */
  methods: {
    mapDataList: function () {
      let data = this.data.dataList;
      data.forEach(element => {        
        element.time = formatTime(new Date(element.time))
      });
      this.setData({
        dataList: data
      });   
    }
  }
})
