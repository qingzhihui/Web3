import React, { Component } from "react";
import "./index.css";
import * as echarts from "echarts";
import {
  options,
  options1,
  options2,
  options3,
  options4,
  options5,
} from "./echartsPackage";

// 数据概况界面
class Home extends Component {
  // const Home = () => {
  componentDidMount(): void {
    this.userAddChart();
    this.userTotal();
    this.orderQuantity();
    this.cancellationOfOrder();
    this.orderRevenue();
    this.drawback();
  }
  // 用户增加图表
  userAddChart() {
    let main = document.getElementById("userAdd");
    let myChart = echarts.init(main as HTMLDivElement);
    let option: any = options;
    myChart.setOption(option);
  }

  // 用户总数图表
  userTotal() {
    let main1 = document.getElementById("userTotal");
    let myChart1 = echarts.init(main1 as HTMLDivElement);
    let option1: any = options1;
    myChart1.setOption(option1);
  }

  // 订单量
  orderQuantity() {
    let main2 = document.getElementById("orderQuantity");
    let myChart2 = echarts.init(main2 as HTMLDivElement);
    let option2: any = options2;
    myChart2.setOption(option2);
  }

  //取消订单
  cancellationOfOrder() {
    let main3 = document.getElementById("cancellationOfOrder");
    let myChart3 = echarts.init(main3 as HTMLDivElement);
    let option3: any = options3;
    myChart3.setOption(option3);
  }

  //订单收入
  orderRevenue() {
    let main4 = document.getElementById("orderRevenue");
    let myChart4 = echarts.init(main4 as HTMLDivElement);
    let option4: any = options4;
    myChart4.setOption(option4);
  }

  //退款
  drawback() {
    let main5 = document.getElementById("drawback");
    let myChart5 = echarts.init(main5 as HTMLDivElement);
    let option5: any = options5;
    myChart5.setOption(option5);
  }
  render() {
    return (
      <div className="homeBox">
        {/* 用户数据展示 */}
        <div className="userShowBox pubBox">
          <div className="pubTitle">
            <div className="xiantiao"></div>
            <div className="headerTitle">&nbsp;&nbsp;&nbsp;用户数据展示</div>
          </div>
          {/* 新增 */}
          <div className="publicFirstBox">
            <div className="firstBoxTit">
              <span>新增</span>
              <span>(单位：人)</span>
            </div>
            <div className="firstBoxCont">
              <div className="firstBoxContNum">
                <div className="publicRed">10 ↑</div>
                <div>8</div>
                <div className="publicGreen">155 ↑</div>
              </div>
              <div className="firstBoxContTit">
                <div className="publicRed">今日新增</div>
                <div>昨日新增</div>
                <div className="publicGreen">本月新增</div>
              </div>
            </div>
          </div>
          {/* 用户增加 */}
          <div className="publicSecondBox">
            <div className="firstBoxTit">
              <span>用户增加</span>
              <span>近30天▼</span>
            </div>
            <div className="publicEchartsBox" id="userAdd"></div>
          </div>
          {/* 用户总数 */}
          <div className="publicSecondBox">
            <div className="firstBoxTit">
              <span>用户总数</span>
              <span>近30天▼</span>
            </div>
            <div className="publicEchartsBox" id="userTotal"></div>
          </div>
        </div>
        {/* 订单数据统计 */}
        <div className="orderGoodsShowBox pubBox">
          <div className="pubTitle">
            <div className="xiantiao"></div>
            <div className="headerTitle">&nbsp;&nbsp;&nbsp;订单数据统计</div>
          </div>
          {/* 订单数据 */}
          <div className="publicFirstBox">
            <div className="firstBoxTit">
              <span>订单数据</span>
              <span></span>
            </div>
            <div className="firstBoxCont">
              <div className="firstBoxContNum">
                <div className="publicBlue">155</div>
                <div className="publicRed">18</div>
                <div>155</div>
              </div>
              <div className="firstBoxContTit">
                <div className="publicBlue">今日新增</div>
                <div className="publicRed">昨日新增</div>
                <div>本月新增</div>
              </div>
            </div>
          </div>
          {/* 订单量 */}
          <div className="publicSecondBox">
            <div className="firstBoxTit">
              <span>订单量</span>
              <span>近30天▼</span>
            </div>
            <div className="publicEchartsBox" id="orderQuantity"></div>
          </div>
          {/* 取消订单 */}
          <div className="publicSecondBox">
            <div className="firstBoxTit">
              <span>取消订单</span>
              <span>近30天▼</span>
            </div>
            <div className="publicEchartsBox" id="cancellationOfOrder"></div>
          </div>
        </div>
        {/* 财务数据统计 */}
        <div className="financeShowBox pubBox">
          <div className="pubTitle">
            <div className="xiantiao"></div>
            <div className="headerTitle">&nbsp;&nbsp;&nbsp;财务数据统计</div>
          </div>
          {/* 财务数据 */}
          <div className="publicFirstBox">
            <div className="firstBoxTit">
              <span>财务数据</span>
              <span></span>
            </div>
            <div className="firstBoxCont">
              <div className="firstBoxContNum">
                {/* <div>10 ↑</div> */}
                <div className="publicGreen">￥15580</div>
                <div className="publicRed">￥2360</div>
              </div>
              <div className="firstBoxContTit">
                {/* <div>今日新增</div> */}
                <div className="publicGreen">销售金额</div>
                <div className="publicRed">新增退款</div>
              </div>
            </div>
          </div>
          {/* 订单收入 */}
          <div className="publicSecondBox">
            <div className="firstBoxTit">
              <span>订单收入</span>
              <span>近30天▼</span>
            </div>
            <div className="publicEchartsBox" id="orderRevenue"></div>
          </div>
          {/* 退款 */}
          <div className="publicSecondBox">
            <div className="firstBoxTit">
              <span>退款</span>
              <span>近30天▼</span>
            </div>
            <div className="publicEchartsBox" id="drawback"></div>
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
