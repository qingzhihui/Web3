export default [
  // 从定向 redirect:'/user'
  { path: '/', component: '@/pages/index' },
  {
    path: '/user',
    component: '@/pages/user/index',
    name: 'user',
    icon: 'smile',
  },
  {
    path: '/wrappers',
    component: '@/pages/wrappers/index',
    exact: false,
    name: 'wrappers',
    icon: 'crown',
  },
  {
    path: '/ches',
    component: '@/pages/ches/index',
    exact: false,
    name: 'ches',
    icon: 'crown',
  },
  {
    path: '/product',
    component: '@/pages/product/index',
    exact: false,
    name: 'product',
    icon: 'crown',
  },
];
