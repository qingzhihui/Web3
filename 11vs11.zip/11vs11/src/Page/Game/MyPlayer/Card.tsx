import "./card.scss";
type Props = {
  title: string;
  img: string;
  list?: { [key: string]: any };
};
function isNum(val: string | number) {
  let str = `${val}`;
  let regPos = /^[0-9]+.?[0-9]*/; //判断是否是数字。
  return regPos.test(str);
}

export default function Card(props: Props) {
  return (
    <div className="m-card">
      <h1>{props.title}</h1>
      <div className="card-content">
        <img
          src={`https://metadata.rektclub.org/ipfs/` + props.img}
          className="left-img"
        />
        <div className={`right ${props.list?.Properties ?? ""}`}>
          {props?.list
            ? Object.keys(props.list).map((item, key) => {
                if (isNum(props?.list?.[item])) {
                  return (
                    <div className="num" key={key}>
                      <div className="left">{item}:</div>
                      <div className="right">
                        <div
                          style={{ width: `${props?.list?.[item]}%` }}
                          className={`line`}
                        />
                        <span className="value">{props?.list?.[item]}</span>
                      </div>
                    </div>
                  );
                } else {
                  return (
                    <div key={key}>
                      {item}:{" "}
                      <span className="value">{props?.list?.[item]}</span>
                    </div>
                  );
                }
              })
            : null}
        </div>
      </div>
    </div>
  );
}
