import "./index.css";
import { ReloadOutlined } from "@ant-design/icons";
const Index = () => {
  return (
    <div className="ButtonLoading">
      <ReloadOutlined spin style={{ fontSize: "15px", color: "#f9339" ,marginRight:"5px"}} />
    </div>
  );
};

export default Index;
