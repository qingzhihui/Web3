import api from '../../config/axios'
let timer: any;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    city: "",
    SelectDate: [],
    SelectState: false,
    History: [],
    Internal: [],
    Intional: [],
    AddressOne: [],
    AddressTwo: [],
    seate: true
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options: any) {
    this.setData({
      city: options.city
    })
    api._get('city/list/hot').then(res => {
      this.setData({
        Internal: res.data.listHotCityByChina,
        Intional: res.data.listHotCity
      })
    }).catch(event => {
      console.log(event);
    })
    // api._get('cityAll').then(res => {
    //   console.log(res);
      
    //   this.setData({
    //     AddressOne: res.data.chinaCity,
    //     AddressTwo: res.data.internationalCity
    //   })
    // }).catch(event => {
    //   console.log(event);
    // })
    const cityData = wx.getStorageSync('cityDem');
    if (cityData !== "") {
      this.setData({
        History: cityData,
      })
    }
  },
  TitleItemClick() {
    this.setData({
      seate: !this.data.seate
    })
  },
  ItemDetails(event: any) {
    var pages = getCurrentPages();
    var beforePage = pages[pages.length - 2];
    wx.switchTab({
      url: "../Index/Index",
      success: function () {
        beforePage.AddressProps(event.currentTarget.dataset.code);
      }
    })
  },
  onClickLeft() {
    var that = this;
    var pages = getCurrentPages();
    var beforePage = pages[pages.length - 2];
    wx.switchTab({
      url: "../Index/Index",
      success: function () {
        beforePage.AddressProps(that.data.city.split('市')[0]);
      }
    })
  },
  HotelData(value: string) {
    api._get(`city/list?cityName=${value}`).then(res => {
      this.setData({
        SelectDate: res.data,
        SelectState: true
      })
    }).catch(e => {
      console.log(e);
    })
  },
  debounce(event: any) {
    this.setData({
      inputShow: event.detail.value
    })
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (event.detail.value !== "") {
        this.HotelData(event.detail.value)
        if (this.data.History.length === 0) {
          wx.setStorageSync('cityDem', [event.detail.value]);
        } else {
          this.data.History.map((item: string) => {
            if (item !== event.detail.value) {
              wx.setStorageSync('cityDem', [...this.data.History, event.detail.value]);
            } else {
              wx.setStorageSync('cityDem', [...this.data.History]);
            }

          })
        }
      } else {
        this.setData({
          SelectState: false,
          SelectDate: []
        })
      }
    }, 800);
  },
  SearceDelect() {
    wx.removeStorage({
      key: 'cityDem'
    })
    this.historBuien();
  },
  historBuien() {
    const HistorData = wx.getStorageSync('cityDem');
    if (HistorData !== "") {
      this.setData({
        History: HistorData,
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },





  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})