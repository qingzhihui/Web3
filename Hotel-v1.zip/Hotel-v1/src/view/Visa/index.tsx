import React from "react";

const Visa = () => {
  return <div>Visa</div>;
};

export default Visa;
