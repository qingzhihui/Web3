import React from "react";

function Lee() {
  const user = {
    name: "less",
  };
  const h1 = <h1>{user.name}</h1>;
  const say = (str: string) => {
    console.log(str);
    return str;
  };
  return (
    <div>
      <>
        {h1}
        {console.log(say("say"))}
      </>
    </div>
  );
}

export default Lee;
