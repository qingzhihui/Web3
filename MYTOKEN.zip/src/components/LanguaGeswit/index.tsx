import { useState } from "react";
import type { MenuProps } from "antd";
import { CaretDownOutlined } from "@ant-design/icons";
import { Button, Dropdown, Space } from "antd";
import i18n from "../../i18n";
import "./index.scss";

const International = () => {
  const [handelvoice, setHandelvoice] = useState("中文");
  const Meslei = [
    {
      label: "中文",
      key: "1",
    },
    {
      label: "English",
      key: "2",
    },
  ];

  const items: MenuProps["items"] = [
    {
      key: "1",
      label: "中文",
    },
    {
      key: "2",
      label: "English",
    },
  ];
  const handleMenuClick: MenuProps["onClick"] = (e) => {
    const MenuItem: any = items[Number(e.key) - 1];
    setHandelvoice(MenuItem.label);
    if (MenuItem.key == "1") {
      i18n.changeLanguage("zh-CN");
    } else {
      i18n.changeLanguage("en");
    }
  };

  return (
    <div className="spiineosr">
      <div className="sapeien">
        <Dropdown
          menu={{ items, onClick: handleMenuClick }}
          placement="bottom"
          autoAdjustOverflow={true}
          overlayStyle={{
            zIndex: 999999999,
          }}
          arrow={{ pointAtCenter: true }}
          trigger={["click", "contextMenu"]}
        >
          <Button>
            <Space>
              <div className="speriise">
                <div className="psoduenxc">
                  <div className="psoduenxcTitlex">{handelvoice}</div>
                  <CaretDownOutlined style={{ fontSize: "13px" }} />
                </div>
              </div>
            </Space>
          </Button>
        </Dropdown>
      </div>
    </div>
  );
};

export default International;
