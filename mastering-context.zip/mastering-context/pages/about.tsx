import { useRouter } from "next/router";

function AboutPage() {
  const router = useRouter();
  const { name } = router.query;
  return <div>About Page {name}</div>;
}

export default AboutPage;
