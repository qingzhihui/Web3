export interface ANLusier {
  PId: string; //pid
  lpToken?: string; //池子地址
  lpTone?: string; //池子名称
  poolType?: string; //那个节点
  pledgee?: string; //质押人地址
  amount?: string; //质押数量
  amounpro?: string; //质押显示
  miningRewardDebt?: string; //已领数量
  pendingRewad?: string; // 待领数量
  pendingDividend?: string; //待领分红
  dividendRewardDebt?: string; //分红数量
  depositTime?: string; //质押时间
  depositdata?: string; //质押时间显示
  lockupTime?: string; //锁产期
  redeemdate?: string; //赎回开始时间
  redprodate?: string; //赎回开始时间显示
  endeemdate?: string; //赎回结束时间
  endprodate?: string; //赎回结束时间显示
  chamberdate?: string; //锁仓至时间
  chaprodate?: string; //锁仓至时间显示
  start?: boolean;
}
