<template>
</template>

<script setup>
// 手写 call 函数
//不得使用 apply，bind 辅助

Function.prototype.myCall = function (
    ctx, ...args
) {
  ctx = (ctx === null || ctx === undefined) ? globalThis : Object(ctx)
  var key = Symbol('temp')
  ctx[key] = this;
  Object.defineProperty(ctx, key, {
    enumerable: false,
    value: this
  })
  var result = ctx[key](...args);
  delete ctx.fn;
  return result;
}

function method(a, b) {
  console.log(this, a, b); //这个this指向全局
  return a + b;
}

method.myCall(null, 2, 3)
</script>

<style>
</style>
