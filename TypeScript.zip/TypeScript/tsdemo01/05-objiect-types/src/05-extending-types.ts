interface BasicAddress {
  name?: string;
  street: string;
  city: string;
  conuntry: string;
  postalCode: string;
}

// interface AddressWithUhit{
//     name?: string;
//     street: string;
//     city: string;
//     conuntry: string;
//     postalCode: string;
//     unit:string
// }

interface AddressWithUhit extends BasicAddress {
  unit: string;
}

let awu: AddressWithUhit = {
  unit: "3单元",
  street: "契合街道",
  city: "北京",
  conuntry: "中国",
  postalCode: "100000",
};

interface Colorful {
  color: string;
}
interface Circle {
  radius: number;
}
interface ColorCircle extends Colorful, Circle {}

const cc: ColorCircle = {
  color: "red",
  radius: 100,
};
