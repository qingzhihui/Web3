import React, { Component } from "react";
import IndexRouter from "./router/indexRouter";
import "./App.css";
export default class App extends Component {
  constructor(props){
    super(props);
    this.state={
    }
  }
  componentDidMount() {
    const width = document.documentElement.clientWidth;
    const height = document.documentElement.clientHeight; 
    if (width < height) {
      const contentDOM = document.getElementById("nxliudu"); 
      contentDOM.style.width = height + "px"; 
      contentDOM.style.height = width + "px";
      contentDOM.style.top = (height - width) / 2 + "px";
      contentDOM.style.left = 0 - (height - width) / 2 + "px";
      contentDOM.style.transform = "rotate(90deg)";
    }
  }
  render() {
    return (
      <div className="nxliudu" id="nxliudu">
        <IndexRouter />
      </div>
    );
  }
}
