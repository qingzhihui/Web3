import { LogoutOutlined, SmileOutlined } from '@ant-design/icons';
import { history, useModel } from '@umijs/max';
import { Menu, notification } from 'antd';
import type { ItemType } from 'antd/lib/menu/hooks/useItems';
import { ethers } from 'ethers';
import type { MenuInfo } from 'rc-menu/lib/interface';
import React, { useCallback, useEffect, useState } from 'react';
import HeaderDropdown from '../HeaderDropdown';
import styles from './index.less';
declare const window: Window & { ethereum: any };

export type GlobalHeaderRightProps = {
  menu?: boolean;
};

const AvatarDropdown: React.FC<GlobalHeaderRightProps> = ({ menu }) => {
  const { setInitialState } = useModel('@@initialState');
  const [address, setAddress] = useState('');

  const loginOut = async () => {
    setAddress('');
    sessionStorage.removeItem('addr');
  };
  const addresLInk = async () => {
    if (typeof window.ethereum !== 'undefined') {
      await window.ethereum.request({ method: 'eth_requestAccounts' });
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const addr = await signer.getAddress();
      setAddress(addr);
      sessionStorage.setItem('addr', addr);
      console.log('You have connected your wallet');
    } else {
      console.log('Please install metamask.');
    }
  };
  const openNotification = () => {
    notification.open({
      message: '温馨提示',
      description: '请先连接钱包在继续操作',
      icon: <SmileOutlined style={{ color: '#108ee9' }} />,
      onClick: () => {
        console.log('Notification Clicked!');
      },
    });
  };

  const onMenuClick = useCallback(
    (event: MenuInfo) => {
      const { key } = event;
      if (key === 'logout') {
        setInitialState((s) => ({ ...s, currentUser: undefined }));
        loginOut();
        return;
      }
      history.push(`/account/${key}`);
    },
    [setInitialState],
  );

  const menuItems: ItemType[] = [
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: '断开钱包',
    },
  ];
  useEffect(() => {
    const adrs = sessionStorage.getItem('addr');
    if (adrs !== null) {
      setAddress(adrs);
    } else {
      openNotification();
    }
  }, []);

  const menuHeaderDropdown = (
    <Menu className={styles.menu} selectedKeys={[]} onClick={onMenuClick} items={menuItems} />
  );

  return (
    <HeaderDropdown overlay={menuHeaderDropdown}>
      {address !== '' ? (
        <span className={styles.menukun}>
          {' '}
          {address.substring(0, 4) + '...' + address.substring(38, 42)}
        </span>
      ) : (
        <span className={styles.menukun2} onClick={() => addresLInk()}>
          连接钱包
          {/* <Avatar size="small" className={styles.avatar} src={currentUser.avatar} alt="avatar" />
        <span className={`${styles.name} anticon`}>{currentUser.name}</span> */}
        </span>
      )}
    </HeaderDropdown>
  );
};

export default AvatarDropdown;
