import { useEffect, useState } from "react";
import "./index.scss";
import ches from "./ches.png";
import { ethers } from "ethers";
import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../../../redux/Contract/SmartContract";
import {
  PLAYERFRA_ABI,
  PLAYERFRA_ADDRESS,
} from "../../../redux/Contract/playerFragment";
import { FBI_ABI, FBI_ADDRESS } from "../../../redux/Contract/fbiContract";
import { message } from "antd";
import BigNumber from "bignumber.js";
import sbeu from "./merge-plus.png";

export default function Merge() {
  const [liShow, setliShow] = useState(false);
  const [liShow2, setliShow2] = useState(false);
  const [address, setAddress] = useState("");
  const [tokenBaLiost, setTokenBaLiost] = useState([]);
  const [tokenId1, setTokenId1] = useState("");
  const [tokenId2, setTokenId2] = useState("");
  const [image1, setImage1] = useState("");
  const [image2, setImage2] = useState("");
  const [Bueshow, setBueshow] = useState(false);
  const [tokenBalan, setTokenBalan] = useState([]);

  const BewngShow = () => {
    setliShow(true);
  };
  const BewngShow2 = () => {
    setliShow2(true);
  };
  const liNSEShow = () => {
    setliShow(false);
  };
  const liNSEShow2 = () => {
    setliShow2(false);
  };
  const tokenList = (id: any, image: any) => {
    setTokenId1(id);
    setImage1(`https://metadata.rektclub.org/ipfs/` + image);
    const duslit = tokenBaLiost;
    duslit.map((item: any) => {
      if (item.tokenId == id) {
        item.reutener = false;
      } else {
        item.reutener = true;
      }
    });
    setTokenBaLiost(duslit);
    setliShow(false);
  };
  const tokenList2 = (id: any, image: any) => {
    setTokenId2(id);
    setImage2(`https://metadata.rektclub.org/ipfs/` + image);
    const duslit = tokenBaLiost;
    duslit.map((item: any) => {
      if (item.tokenId == id) {
        item.reutener = false;
      } else {
        item.reutener = true;
      }
    });
    setTokenBaLiost(duslit);
    setliShow2(false);
  };
  const commonSHoi = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const playerContract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const playerFragment = new ethers.Contract(
      PLAYERFRA_ADDRESS,
      PLAYERFRA_ABI,
      signer
    );
    const fbiContract = new ethers.Contract(FBI_ADDRESS, FBI_ABI, signer);
    const linkapue = await playerFragment.allowance(addr, CONTRACT_ADDRESS);
    const fbiapprove = await fbiContract.allowance(addr, CONTRACT_ADDRESS);
    if (Number(ethers.utils.formatEther(linkapue)) < 100) {
      const apuerns = await playerFragment.approve(
        CONTRACT_ADDRESS,
        ethers.constants.MaxUint256
      );
      await apuerns.wait();
    }
    if (Number(ethers.utils.formatEther(fbiapprove)) < 30000) {
      const seloss = await fbiContract.approve(
        CONTRACT_ADDRESS,
        ethers.constants.MaxUint256
      );
      await seloss.wait();
    }
    try {
      // const mergep = await playerContract.merge(tokenId1, tokenId2);
      // await mergep.wait();
      const playerbalance = await playerContract.balanceOf(addr);
      const lastplayer = await playerContract.tokenOfOwnerByIndex(
        addr,
        playerbalance - 1
      );
      const xytokenid = Number(lastplayer.toString());
      const xytokenuri = await playerContract.tokenURI(21);
      let tokenBalance: any = [];
      await fetch(xytokenuri)
        .then((response) => response.json())
        .then((data) => {
          const uri = data.image.slice(7);
          tokenBalance.push({
            tokenId: xytokenid.toString(),
            image: uri,
            cName: data.name,
            rarity: data.attributes[0].value,
            occ: data.attributes[1].value,
            speed: data.attributes[2].value,
            shoot: data.attributes[3].value,
            guard: data.attributes[4].value,
            save: data.attributes[5].value,
            lucky: data.attributes[6].value,
            reveal: true,
          });
        });
      console.log(tokenBalance);
      setTokenBalan(tokenBalance);
      setBueshow(true);
      setImage1("");
      setImage2("");
    } catch (error: any) {
      const beinug = error.data.message.split(":");
      message.error(beinug[2]);
    }
  };
  const porksuerHide = () => {
    setBueshow(false);
  };
  useEffect(() => {
    const Buens = async () => {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const instances = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      );
      const addr = await signer.getAddress();
      setAddress(addr);
      const balance = await instances.balanceOf(addr);
      const bel = ethers.utils.formatEther(balance);
      const nftAmount = new BigNumber(bel)
        .times(new BigNumber(10).pow(18))
        .toString();
      let tokenBalance: any = [];
      for (let i = 0; i < Number(nftAmount); i++) {
        const tokenId = await instances.tokenOfOwnerByIndex(addr, i);
        const playerData = await instances.playerDatas(tokenId);
        const basetokenUri = await instances.tokenURI(tokenId.toString());
        // console.log(basetokenUri);
        await fetch(basetokenUri)
          .then((response) => response.json())
          .then((data) => {
            const uri = data.image.slice(7);
            if (playerData.unbox === true) {
              tokenBalance.push({
                tokenId: tokenId.toString(),
                image: uri,
                name: data.name,
                rarty: data.attributes[0].value,
                occ: data.attributes[1].value,
                speed: data.attributes[2].value,
                shoot: data.attributes[3].value,
                guard: data.attributes[4].value,
                save: data.attributes[5].value,
                lucky: data.attributes[6].value,
                reveal: true,
                reutener: true,
              });
            } else if (playerData.unbox === false) {
              tokenBalance.push({
                tokenId: tokenId.toString(),
                image: data.image,
                name: data.name,
              });
            }
          });
      }
      setTokenBaLiost(tokenBalance);
      // console.log(tokenBalance);
    };
    Buens();
  }, []);
  return (
    <>
      <div
        style={{
          marginTop: "25px",
          display: "flex",
          justifyContent: "center",
        }}
      >
        {/* <button className="common-btn">COMMING SOON</button> */}
      </div>
      <div id="mergekub">
        <div className="top">
          <div className="addBox">
            <h1>MAIN Player</h1>
            <div className="box">
              <div
                className="black"
                onClick={() => {
                  BewngShow();
                }}
              >
                {" "}
                <img src={image1 || sbeu} alt="" />
              </div>
            </div>
          </div>
          <div className="addBox">
            <h1>MAIN Player</h1>
            <div className="box">
              <div
                className="black"
                onClick={() => {
                  BewngShow2();
                }}
              >
                <img src={image2 || sbeu} alt="" />
              </div>
            </div>
          </div>
        </div>
        <button
          className="common-btn"
          onClick={() => {
            commonSHoi();
          }}
        >
          Merge
        </button>
        {/* 弹框 */}
        {liShow ? (
          <div className="prodios">
            <div className="nsieln">
              <div className="bsuetile">
                <span>我的NFT</span>
              </div>
              <div className="plises">
                {tokenBaLiost.map((item: any) => (
                  <div key={item.tokenId}>
                    {item.reutener == true ? (
                      <div
                        className="nsieln_item"
                        onClick={() => {
                          tokenList(item.tokenId, item.image);
                        }}
                      >
                        <div className="item_title">{item.name}</div>
                        <div className="iteList">
                          <div className="ite_ledrt">
                            <img
                              src={
                                `https://metadata.rektclub.org/ipfs/` +
                                item.image
                              }
                              alt=""
                            />
                          </div>
                          <div className="ite_rest">
                            <div className="bsn">
                              Properties：<span>{item.rarty}</span>
                            </div>
                            <div className="bsn">
                              Speed：<span>{item.speed}</span>
                            </div>
                            <div className="bsn">
                              Shoot：<span>{item.shoot}</span>
                            </div>
                            <div className="bsn">
                              Guard：<span>{item.guard}</span>
                            </div>
                            <div className="bsn">
                              Save：<span>{item.save}</span>
                            </div>
                            <div className="bsn">
                              Lucky：<span>{item.lucky}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                ))}
              </div>
              <div
                className="gubaie"
                onClick={() => {
                  liNSEShow();
                }}
              >
                关闭
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
        {/* 弹框2 */}
        {liShow2 ? (
          <div className="prodios">
            <div className="nsieln">
              <div className="bsuetile">
                <span>我的NFT</span>
              </div>
              <div className="plises">
                {tokenBaLiost.map((item: any) => (
                  <div key={item.tokenId}>
                    {item.reutener == true ? (
                      <div
                        className="nsieln_item"
                        onClick={() => {
                          tokenList2(item.tokenId, item.image);
                        }}
                      >
                        <div className="item_title">{item.name}</div>
                        <div className="iteList">
                          <div className="ite_ledrt">
                            <img
                              src={
                                `https://metadata.rektclub.org/ipfs/` +
                                item.image
                              }
                              alt=""
                            />
                          </div>
                          <div className="ite_rest">
                            <div className="bsn">
                              Properties：<span>{item.rarty}</span>
                            </div>
                            <div className="bsn">
                              Speed：<span>{item.speed}</span>
                            </div>
                            <div className="bsn">
                              Shoot：<span>{item.shoot}</span>
                            </div>
                            <div className="bsn">
                              Guard：<span>{item.guard}</span>
                            </div>
                            <div className="bsn">
                              Save：<span>{item.save}</span>
                            </div>
                            <div className="bsn">
                              Lucky：<span>{item.lucky}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                ))}
              </div>
              <div
                className="gubaie"
                onClick={() => {
                  liNSEShow2();
                }}
              >
                关闭
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
      {/* nrto */}
      {Bueshow ? (
        <div className="Nubyer">
          {tokenBalan.map((item: any) => (
            <div className="Bueio" key={item.tokenId}>
              <div className="nsieln_item">
                <div className="item_title">{item.cName}</div>
                <div className="iteList">
                  <div className="ite_ledrt">
                    <img
                      src={`https://metadata.rektclub.org/ipfs/` + item.image}
                      alt=""
                    />
                  </div>
                  <div className="ite_rest">
                    {/* <div className="item_title">{item.name}</div> */}
                    <div className="bsn">
                      Properties：<span>{item.rarity}</span>
                    </div>
                    <div className="bsn">
                      Occupation：<span>{item.occ}</span>
                    </div>
                    <div className="bsn">
                      Speed：<span>{item.speed}</span>
                    </div>
                    <div className="bsn">
                      Shoot：<span>{item.shoot}</span>
                    </div>
                    <div className="bsn">
                      Guard：<span>{item.guard}</span>
                    </div>
                    <div className="bsn">
                      Save：<span>{item.save}</span>
                    </div>
                    <div className="bsn">
                      Lucky：<span>{item.lucky}</span>
                    </div>
                  </div>
                </div>
                <div className="porksuer" onClick={()=>{
                  porksuerHide()
                }}>X</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        ""
      )}
    </>
  );
}
