import { GridColDef } from "@mui/x-data-grid";

export const columns = [
  { field: 1, headerName: "ID" },
  { field: 2, headerName: "姓名" },
  { field: 3, headerName: "年龄" },
  { field: 4, headerName: "性别" },
  { field: 5, headerName: "是否在校" },
  { field: 6, headerName: "操作" },
];

export const rows = [
  { id: 1, name: "Snow", sage: 35, first: "男", state: true },
  { id: 2, name: "Lannpr", sage: 42, first: "女", state: true },
  { id: 3, name: "Lannister", sage: 45, first: "男", state: true },
  { id: 4, name: "Stark", sage: 16, first: "女", state: true },
  { id: 5, name: "Targaryen", sage: 18, first: "男", state: true },
];

