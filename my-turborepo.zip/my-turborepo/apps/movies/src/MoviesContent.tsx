import React from "react";
import { MovieCard } from "card";
import { Grid } from "@mantine/core";

const movies = [
  {
    title: "Halo",
    image:
      "https://puui.qpic.cn/vcover_vt_pic/0/mzc002008v8rka31681528902765/350?max_age=7776001",
  },
  {
    title: "Doctor Strange",
    image:
      "https://puui.qpic.cn/vcover_vt_pic/0/mzc00200i92xzzu1681889995023/350?max_age=7776001",
  },
  {
    title: "The Lost City",
    image:
      "https://puui.qpic.cn/vcover_vt_pic/0/mzc0020035tt9q91681994852918/350?max_age=7776001",
  },
];

const MoviesContent = () => {
  return (
    <Grid
      sx={{
        gap: "1rem",
      }}
    >
      {movies.map((movie) => (
        <MovieCard {...movie} key={movie.title} showAddButton />
      ))}
    </Grid>
  );
};

export default MoviesContent;
