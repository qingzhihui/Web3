import React, { useEffect, useState } from "react";
import "./index.scss";
import { EditOutlined, KeyOutlined } from "@ant-design/icons";
import { Progress, Input, Modal, Radio, Table, Statistic, Alert } from "antd";
import type { RadioChangeEvent } from "antd";
import { WBENJson } from "../../config/abi/wbenjson";
import ButtonLoading from "../../components/ButtonLoading";
import {
  DigitalConversion,
  FormatUnitsConver,
  InstancedContract,
  TimestampToTime,
  TokenNameDecimals,
} from "../../hooks/config";
import { TextareaData } from "../../hooks/MultiSender";
import { LaunchPadABI } from "../../hooks/launchpad";
import {
  ContributorsProps,
  CurrentPropsType,
  CycleBpsConversion,
  CycleConversion,
  getAlloDataProps,
  StartProps,
  StatusProps,
  vluesProps,
} from "../../hooks/LockRecordInfo";
import { useHistory, useLocation } from "react-router-dom";
import { ethers, BigNumber } from "ethers";
import { useTranslation } from "react-i18next";
import { log } from "console";
const { Countdown } = Statistic;
declare const window: Window & { ethereum: any };

const CurrentPresales: React.FC = (props: any) => {
  const { t } = useTranslation();
  const [data, setData] = useState<CurrentPropsType>({});
  const [TextArea1, setTextArea1] = useState<string>("");
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [Somedata, setSomedata] = useState<getAlloDataProps[]>([]);
  const [Allocation, setAllocation] = useState<StartProps>({});
  const [isModalOpenSetting, setisModalOpenSetting] = useState<boolean>(false);
  const { TextArea } = Input;
  let history = useHistory();
  const [RadioValue, setRadioValue] = useState<number>(0);
  const [AddRemoleJudge, setAddRemoleJudge] = useState<string>("");
  const [TokenAddress, setTokenAddress] = useState<string>("");
  const [AmountValue, setAmountValue] = useState<string>("");
  const [isModalContributors, setisModalContributors] =
    useState<boolean>(false);
  const [maxInve, setMaxInve] = useState<string>("");
  const [privateSale, setPrivateSale] = useState<boolean>(false);
  const [ContributorsData, setContributorsData] = useState<ContributorsProps[]>(
    []
  );
  // 现在的时间戳 数字类型 毫秒
  const date = Date.now();
  const [StatusData, setStatusData] = useState<StatusProps>({});
  const [buywithloading, setBuyWithLoading] = useState<boolean>(false);
  const [valueDate, setvalueDate] = useState<boolean>(false);
  const [vluesList, setvluesList] = useState<vluesProps>({});
  // withdraw loading
  const [withdrawloading, setWithdrawLoading] = useState<boolean>(false);
  // finalize loading
  const [finalizeloading, setFinalizeLoading] = useState<boolean>(false);
  // cancelpool loading
  const [cancelpoolloading, setCancelPoolLoading] = useState<boolean>(false);
  const [UserClaimAble, setUserClaimAble] = useState("");
  const [ownerState, setOwnerState] = useState(false);
  const { state } = useLocation<any>();
  const [BnBShow, setBnBShow] = useState(false);
  const [claimState, setclaimState] = useState(false);
  const [SaleType, setSaleType] = useState(0);
  const [cancel, setCancel] = useState(false);
  const [joinInfosState, setJoinInfosState] = useState(false);
  const [emergencyState, setEmergencyState] = useState(false);
  const [endTimeState, setendTimeState] = useState(false);
  const [PoolState, setPoolState] = useState(false);
  const [FinalizeState, setFinalizeState] = useState(false);
  const [poolstate, setPoolstate] = useState(0);
  const [Contributors, setContributors] = useState(false);
  const [disablewhiteloading, setDisableWhiteLoading] = useState<boolean>(false)
  const SomebodyAirdropDataShow = async (data: any) => {
    const LaunchPadContract = InstancedContract(data.address, LaunchPadABI) as any;
    const icoToken = await LaunchPadContract.icoToken();
    const icoTokenContract = InstancedContract(icoToken, WBENJson) as any;
    const contractBalance = await icoTokenContract.balanceOf(data.address);
    const name = await icoTokenContract.name();
    const symbol = await icoTokenContract.symbol();
    const decimals = await icoTokenContract.decimals();
    const totalSupply = await icoTokenContract.totalSupply();
    const presaleRate = await LaunchPadContract.presaleRate();
    const hardCap = await LaunchPadContract.hardCap();
    const softCap = await LaunchPadContract.softCap();
    const feeToken = await LaunchPadContract.feeToken();
    const owner = await LaunchPadContract.owner();
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    if (owner === address) {
      setOwnerState(true);
    } else {
      setOwnerState(false);
    }
    const whitelistPool = await LaunchPadContract.whitelistPool();
    const checkIsWhitelisted = await LaunchPadContract.checkIsWhitelisted(
      address
    );
    const startTime = await LaunchPadContract.startTime();
    const joinInfos = await LaunchPadContract.joinInfos(address);
    const clasate = await LaunchPadContract.state();
    const endTime = await LaunchPadContract.endTime();
    const raisedAmount = await LaunchPadContract.raisedAmount();
    // 1
    if (
      Number(whitelistPool.toString()) === 0 &&
      Number(startTime.toString()) < date
    ) {
      setBnBShow(true);
    } else if (
      Number(whitelistPool.toString()) === 1 &&
      checkIsWhitelisted &&
      Number(startTime.toString()) < date
    ) {
      setBnBShow(true);
    } else if (
      Number(whitelistPool.toString()) === 2 &&
      Number(startTime.toString()) < date
    ) {
      setBnBShow(true);
    } else {
      setBnBShow(false);
    }

    // 2
    if (Number(whitelistPool.toString()) === 0) {
      setRadioValue(1);
      setSaleType(1);
    } else if (Number(whitelistPool.toString()) === 1) {
      setRadioValue(2);
      setSaleType(2);
    } else {
      setRadioValue(3);
      setSaleType(3);
    }

    // 3
    if (
      Number(clasate.toString()) === 2 &&
      Number(joinInfos.totalTokens.toString()) > 0
    ) {
      setclaimState(true);
    } else {
      setclaimState(false);
    }

    // 4
    if (
      Number(clasate.toString()) === 3 &&
      Number(contractBalance.toString()) > 0
    ) {
      setCancel(true);
    } else {
      setCancel(false);
    }

    // 5
    if (
      Number(joinInfos.totalTokens.toString()) > 0 &&
      Number(clasate.toString()) === 1
    ) {
      setEmergencyState(true);
    } else if (
      Number(joinInfos.totalTokens.toString()) > 0 &&
      Number(clasate.toString()) === 3
    ) {
      setJoinInfosState(true);
    } else {
      setEmergencyState(false);
      setJoinInfosState(false);
    }

    // 6
    if (
      Number(clasate.toString()) === 1 &&
      Number(endTime.toString()) < date
    ) {
      setendTimeState(false);
    } else if (Number(raisedAmount.toString()) == Number(hardCap.toString())) {
      setendTimeState(false);
    } else if (Number(clasate.toString()) === 3) {
      setendTimeState(false);
    } else {
      setendTimeState(true);
    }

    // 7
    if (Number(clasate.toString()) === 1) {
      setPoolState(false);
    } else {
      setPoolState(true);
    }

    // 8
    if (
      (Number(clasate.toString()) === 1 &&
        endTime < date &&
        Number(raisedAmount.toString()) < Number(hardCap.toString())) ||
      Number(clasate.toString()) === 2 ||
      Number(clasate.toString()) === 3
    ) {
      setFinalizeState(true);
    } else {
      setFinalizeState(false);
    }

    let feeTokenDecimals: any = 18;
    let feeTokenSymbol = "BNB";
    if (feeToken !== "0x0000000000000000000000000000000000000000") {
      const feeTokenContract = InstancedContract(feeToken, WBENJson) as any;
      feeTokenDecimals = await feeTokenContract.decimals();
      feeTokenSymbol = await feeTokenContract.symbol();
    }
    setPoolstate(Number(clasate.toString()));
    const feeTokenDecimalCal = BigNumber.from(10).pow(feeTokenDecimals);
    const totalPresaleTokens: BigNumber = presaleRate
      .mul(hardCap)
      .div(feeTokenDecimalCal);
    const totalPresaleTokensShow = ethers.utils.formatUnits(
      totalPresaleTokens.toString(),
      decimals
    );
    const raisedFeePercent: BigNumber =
      await LaunchPadContract.raisedFeePercent();
    const DENOMINATOR = await LaunchPadContract.DENOMINATOR();
    const liquidityPercent: BigNumber =
      await LaunchPadContract.liquidityPercent();
    const listingRate = await LaunchPadContract.listingRate();
    const totalRaisedFee: BigNumber = hardCap
      .mul(raisedFeePercent)
      .div(DENOMINATOR);
    const netCap: BigNumber = hardCap.sub(totalRaisedFee);
    const totalFeeTokensToAddLP: BigNumber = netCap
      .mul(liquidityPercent)
      .div(DENOMINATOR);
    const totalLiquidityTokens: BigNumber = totalFeeTokensToAddLP
      .mul(listingRate)
      .div(feeTokenDecimalCal);
    const totalLiquidityTokensShow = ethers.utils.formatUnits(
      totalLiquidityTokens.toString(),
      decimals
    );
    const firstReleasePercent = await LaunchPadContract.firstReleasePercent();
    const poolType = await LaunchPadContract.poolType();
    const autoListing = await LaunchPadContract.autoListing();
    const lpLockTime = await LaunchPadContract.lpLockTime();
    const lpLockTimeDate: CurrentPropsType = {
      PresaleAddress: data.address,
      TokenName: name,
      TokenSymbol: symbol,
      TokenDecimal: decimals,
      TokenAddress: icoToken,
      start: data.start,
      end: data.end,
      TotalSupply: FormatUnitsConver(totalSupply.toString(), decimals),
      FeeTokenSymbol: feeTokenSymbol,
      TokensForPresale: totalPresaleTokensShow.toString(),
      TokensForLiquidity: totalLiquidityTokensShow.toString(),
      PresaleRate: FormatUnitsConver(presaleRate, decimals),
      FirstReleaseForPresale:
        CycleBpsConversion(firstReleasePercent).toString(),
      ListingRate: FormatUnitsConver(listingRate, decimals),
      SoftCap: FormatUnitsConver(softCap, feeTokenDecimals),
      HardCap: FormatUnitsConver(hardCap, feeTokenDecimals),
      UnsoldTokens: poolType.toString() === "0" ? "Burn" : "Refund",
      PresaleStartTime: TimestampToTime(startTime.toString()),
      PresaleEndTime: TimestampToTime(endTime.toString()),
      raisedAmount: data.raisedAmount,
      ListingOn:
        autoListing.toString() === "true" ? "Pancakwswap" : "Manual Listing",
      LiquidityPercent: CycleBpsConversion(
        liquidityPercent.toString()
      ).toString(),
      LiquidityLockupTime: CycleConversion(lpLockTime.toString()).toString(),
    };
    setData((dataValue: CurrentPropsType) => {
      return (dataValue = lpLockTimeDate);
    });
    const getUserClaimAble = await LaunchPadContract.getUserClaimAble(address);
    setUserClaimAble(getUserClaimAble.toString());
    // 第一个数组
    const whitelist: getAlloDataProps[] = [];
    const allAllocationCount = await LaunchPadContract.allAllocationCount();
    if (Number(allAllocationCount.toString()) > 0) {
      for (
        let index = 0;
        index < Number(allAllocationCount.toString());
        index++
      ) {
        const getWLUsers = await LaunchPadContract.getAllocations(
          0,
          allAllocationCount.toString()
        );
        whitelist.push({
          address: getWLUsers[index],
        });
      }
    }
    const state = await LaunchPadContract.state();
    const minInvest = await LaunchPadContract.minInvest();
    const maxInvest = await LaunchPadContract.maxInvest();

    const tokenReleaseEachCycle =
      await LaunchPadContract.tokenReleaseEachCycle();
    const vestingPeriodEachCycle =
      await LaunchPadContract.vestingPeriodEachCycle();
    setSomedata((dataValue: getAlloDataProps[]) => {
      return (dataValue = whitelist);
    });

    setMaxInve(FormatUnitsConver(maxInvest.toString(), 18));
    // 第二个数组
    const contributorsList: ContributorsProps[] = [];
    const getJoinedUsersLength = await LaunchPadContract.getJoinedUsersLength();
    const getJoinedUsers = await LaunchPadContract.getJoinedUsers();
    if (Number(getJoinedUsersLength.toString()) > 0) {
      for (
        let index = 0;
        index < Number(getJoinedUsersLength.toString());
        index++
      ) {
        const joinInfos = await LaunchPadContract.joinInfos(
          getJoinedUsers[index]
        );
        contributorsList.push({
          key: index,
          No: index + 1,
          Address: getJoinedUsers[index],
          Amount: FormatUnitsConver(joinInfos.totalInvestment.toString(), 18),
        });
      }
    }
    if (Number(getJoinedUsersLength.toString()) > 0) {
      setContributors(true);
    } else {
      setContributors(false);
    }
    setStatusData((dataPrls: StatusProps) => {
      return (dataPrls = {
        Status: state.toString(),
        SaleType:
          whitelistPool.toString() === "0"
            ? "Public"
            : whitelistPool.toString() === "1"
              ? "Whitelist Only"
              : "Public AntiBot",
        MinimumBuy: FormatUnitsConver(minInvest, feeTokenDecimals),
        MaximumBuy: FormatUnitsConver(maxInvest, feeTokenDecimals),
        Totalibutors: getJoinedUsersLength.toString(),
        Youpurchased: FormatUnitsConver(
          joinInfos.totalInvestment.toString(),
          feeTokenDecimals
        ),
        tokenReleaseEachCycle: CycleBpsConversion(
          tokenReleaseEachCycle.toString()
        ).toString(),
        vestingPeriodEachCycle: CycleConversion(
          vestingPeriodEachCycle.toString()
        ).toString(),
      });
    });
    setAllocation((AllocationprevState: any) => {
      return (AllocationprevState = {
        start: Number(
          FormatUnitsConver(raisedAmount.toString(), feeTokenDecimals)
        ),
        amount: FormatUnitsConver(hardCap.toString(), feeTokenDecimals),
      });
    });
    setContributorsData((dataValue: ContributorsProps[]) => {
      return (dataValue = contributorsList);
    });
    if (
      Number(whitelistPool.toString()) === 1 &&
      checkIsWhitelisted.toString() === "false"
    ) {
      setPrivateSale(true);
    }
  };
  const MaxOnclick = () => {
    setAmountValue(maxInve);
  };
  // 弹框1
  const handleOk = async () => {
    var tmpArl = (document.querySelector("#test") as HTMLInputElement).value;
    const tmpList = tmpArl.split(/\r*\n/);
    const { decimals } = await TokenNameDecimals(vluesList.Address);
    const { QuantityArray, WalletArray } = TextareaData(tmpList, decimals);
    const LaunchPadContract = InstancedContract(
      data.PresaleAddress as string,
      LaunchPadABI
    ) as any;
    if (AddRemoleJudge === "Add") {
      const setWhitelistBuyers = await LaunchPadContract.setWhitelistBuyers(
        WalletArray
      );
    } else {
      const removeWhitelistBuyers =
        await LaunchPadContract.removeWhitelistBuyers(WalletArray);
    }
    setTextArea1("");
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
    setvalueDate(false);
  };
  // 弹框3
  const handleOkSetting = async () => { };
  const handleCancelSetting = () => {
    setisModalOpenSetting(false);
    setvalueDate(false);
  };
  const TextAreaonChangeAdd = (e: any) => {
    setTextArea1(e.target.value);
  };
  const RadioOnChange = (e: RadioChangeEvent) => {
    setRadioValue(e.target.value);
    if (Number(e.target.value) === 1) {
      ModalOpenSettingOnCLiuc(0);
    } else if (Number(e.target.value) === 2) {
      ModalOpenSettingOnCLiuc(1);
    } else {
      setvalueDate(true);
      setisModalOpenSetting(true);
    }
  };
  const SettingBuotneOnclick = async (data: any) => {
    setisModalOpenSetting(true);
  };
  const ModalOpenSettingOnCLiuc = async (Num: any) => {
    setDisableWhiteLoading(true)
    try {
      const LaunchPadContract = InstancedContract(
        data.PresaleAddress as string,
        LaunchPadABI
      ) as any;
      const setWhitelistPool = await LaunchPadContract.setWhitelistPool(
        Num,
        "0x0000000000000000000000000000000000000000",
        0
      );
      await setWhitelistPool.wait()
      setDisableWhiteLoading(false)
      if (Num === 1) {
        setSaleType(1);
      } else {
        setSaleType(2);
      }
    } catch (error) {
      setDisableWhiteLoading(false)
    }

  };
  const BuywithOnClick = async (data: any) => {
    try {
      setBuyWithLoading(true);
      const PrivateSaleConstaer = InstancedContract(
        data.PresaleAddress,
        LaunchPadABI
      ) as any;
      const realValue = DigitalConversion(AmountValue, 18);
      const contribute = await PrivateSaleConstaer.contribute(realValue, {
        value: realValue,
      });
      await contribute.wait();
      setBuyWithLoading(false);
    } catch (error) {
      setBuyWithLoading(false);
    }
  };
  const FinalizeOnClick = async () => {
    try {
      setFinalizeLoading(true);
      const LaunchPadContract = InstancedContract(
        data.PresaleAddress as string,
        LaunchPadABI
      ) as any;
      const finalize = await LaunchPadContract.finalize();
      await finalize.wait();
      setFinalizeLoading(false);
    } catch (error) {
      setFinalizeLoading(false);
    }
  };
  const handleOkContributors = async () => { };
  const WithdrawCanceledTokensClick = async () => {
    try {
      setWithdrawLoading(true);
      const LaunchPadContract = InstancedContract(
        data.PresaleAddress as string,
        LaunchPadABI
      ) as any;
      const claimCanceledTokens = await LaunchPadContract.claimCanceledTokens();
      await claimCanceledTokens.wait();
      setWithdrawLoading(false);
    } catch (error) {
      setWithdrawLoading(false);
    }
  };
  const CancelPoolOnClick = async () => {
    try {
      setCancelPoolLoading(true);
      const LaunchPadContract = InstancedContract(
        data.PresaleAddress as string,
        LaunchPadABI
      ) as any;
      const cancel = await LaunchPadContract.cancel();
      await cancel.wait();
      setCancelPoolLoading(false);
    } catch (error) {
      setCancelPoolLoading(false);
    }
  };
  const handleCancelContributors = () => {
    setisModalContributors(false);
  };
  const setWhitelistPoolOnclick = async () => {
    const LaunchPadContract = InstancedContract(
      data.PresaleAddress as string,
      LaunchPadABI
    ) as any;
    const { decimals } = await TokenNameDecimals(vluesList.Address);
    const setWhitelistPool = await LaunchPadContract.setWhitelistPool(
      2,
      vluesList.Address,
      DigitalConversion(vluesList.Amount, decimals)
    );
    await setWhitelistPool.wait();
    setSaleType(3);
  };
  const setIsModalOpenOnClick = (item: any) => {
    setIsModalOpen(true);
    if (item === "Add") {
      setAddRemoleJudge("Add");
    } else {
      setAddRemoleJudge("Remove");
    }
  };
  const columns = [
    {
      title: `${t("No")}`,
      dataIndex: "No",
    },
    {
      title: `${t("Address")}`,
      dataIndex: "Address",
    },
    {
      title: `${t("Amount")}`,
      dataIndex: "Amount",
    },
  ];
  const ClaimOnClick = async (data: any) => {
    const LaunchPadContract = InstancedContract(
      data.PresaleAddress,
      LaunchPadABI
    ) as any;
    const claimTokens = await LaunchPadContract.claimTokens();
  };
  const editUpdateOnClick = () => {
    history.push({
      pathname: "/CreateUpdata",
      state: {
        urlName: "CurrentPresales",
        editUpdata: data,
        address: TokenAddress,
      },
    });
  };
  const withdrawContributeOnClick = async (data: any) => {
    try {
      setBuyWithLoading(true);
      const PrivateSaleConstaer = InstancedContract(
        data.PresaleAddress,
        LaunchPadABI
      ) as any;
      const withdrawContribute = await PrivateSaleConstaer.withdrawContribute();
      await withdrawContribute.wait();
      setBuyWithLoading(false);
    } catch (error) {
      setBuyWithLoading(false);
    }
  };
  const emergencyWithdrawContributeOnClick = async (data: any) => {
    try {
      setBuyWithLoading(true);
      const PrivateSaleConstaer = InstancedContract(
        data.PresaleAddress,
        LaunchPadABI
      ) as any;
      const emergencyWithdrawContribute =
        await PrivateSaleConstaer.emergencyWithdrawContribute();
      await emergencyWithdrawContribute.wait();
      setBuyWithLoading(false);
    } catch (error) {
      setBuyWithLoading(false);
    }
  };
  useEffect(() => {
  }, [data, TokenAddress, Allocation, ContributorsData]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          if (state.data != undefined) {
            SomebodyAirdropDataShow(state.data);
            setTokenAddress((paStast: string) => {
              return (paStast = state.data.address);
            });
          } else {
            const { address } = state;
            SomebodyAirdropDataShow({ ...state.editUpdata, address });
            setTokenAddress((paStast: string) => {
              return (paStast = state.address);
            });
          }
        }
      }
    }
  }, []);
  return (
    <div className="CurrentCurrency">
      <div className="Somebody_introduce">
        <div className="introduce_left">
          <div className="name_title">
            <div className="nameimgs">
              <div className="heaimgs">
                <img src={require("../../assets/image/Frame.png")} alt="" />
              </div>
              <div>
                <div className="name"></div>
                <div className="imgs">
                  <img src={require("../../assets/image/icon1.png")} alt="" />
                  <img src={require("../../assets/image/icon2.png")} alt="" />
                  <img src={require("../../assets/image/icon3.png")} alt="" />
                  <img src={require("../../assets/image/icon4.png")} alt="" />
                  <img src={require("../../assets/image/icon5.png")} alt="" />
                  <img src={require("../../assets/image/icon6.png")} alt="" />
                  <img src={require("../../assets/image/icon7.png")} alt="" />
                  <img src={require("../../assets/image/icon8.png")} alt="" />
                </div>
              </div>
            </div>
            <div className="keystxt">
              <div className="key">
                <KeyOutlined />
              </div>
              <div
                className="edit"
                onClick={() => {
                  editUpdateOnClick();
                }}
              >
                <EditOutlined style={{ color: "#f95192" }} />
              </div>
            </div>
            <div className="up">
              {(Number(data.start) as number) > date
                ? `${t("Upcoming")}`
                : StatusData.Status === "1" &&
                  Number(data.raisedAmount) < Number(data.HardCap) &&
                  Number(data.end) < date
                  ? `${t("Sale Ended")}`
                  : Number(data.raisedAmount) === Number(data.HardCap)
                    ? `${t("Fiiled")}`
                    : StatusData.Status === "3"
                      ? `${t("Canceled")}`
                      : StatusData.Status === "2"
                        ? `${t("Sale Ended")}`
                        : `${t("Sale Live")}`}
            </div>
          </div>
          <div className="txts">
            <div className="txtcount">
              <div className="titletxt">{`${t("Presale Address")}`}</div>
              <div className="date">{data.PresaleAddress as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Token Name")}`}</div>
              <div className="date">{data.TokenName as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Token Symbol")}`}</div>
              <div className="dateus">{data.TokenSymbol as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Token Decimal")}`}</div>
              <div className="datet">{data.TokenDecimal as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Token address")}`}</div>
              <div className="datet">{data.TokenAddress as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Total Supply")}`}</div>
              <div className="datet">
                {Number(data.TotalSupply as string)}{" "}
                {data.TokenSymbol as string}
              </div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Tokens For Presale")}`}</div>
              <div className="datet">
                {Number(data.TokensForPresale as string)}{" "}
                {data.TokenSymbol as string}
              </div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Tokens For Liquidity")}`}</div>
              <div className="date">
                {Number(data.TokensForLiquidity as string)}{" "}
                {data.TokenSymbol as string}
              </div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Presale Rate")}`}</div>
              <div className="date">
                1 {data.FeeTokenSymbol as string} = {Number(data.PresaleRate as string)}{" "}
                {data.TokenSymbol as string}
              </div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t(
                "First Release For Presale"
              )}`}</div>
              <div className="dateus">
                {data.FirstReleaseForPresale as string}%
              </div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Listing Rate")}`}</div>
              <div className="datet">
                1 {data.FeeTokenSymbol as string} = {Number(data.ListingRate as string)}{" "}
                {data.TokenSymbol as string}
              </div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Soft Cap")}`}</div>
              <div className="datet">
                {Number(data.SoftCap as string)}{" "}
                {data.FeeTokenSymbol as string}
              </div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Hard Cap")}`}</div>
              <div className="datet">
                {Number(data.HardCap as string)}{" "}
                {data.FeeTokenSymbol as string}
              </div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Unsold Tokens")}`}</div>
              <div className="datet">{`${t(data.UnsoldTokens as string)}`}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Presale Start Time")}`}</div>
              <div className="datet">{data.PresaleStartTime as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Presale End Time")}`}</div>
              <div className="datet">{data.PresaleEndTime as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Listing On")}`}</div>
              <div className="datet">{data.ListingOn as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Liquidity Percent")}`}</div>
              <div className="datet">{data.LiquidityPercent as string}%</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Liquidity Lockup Time")}`}</div>
              <div className="datet">{data.LiquidityLockupTime as string}{`${t("minutes")}`}{`${t("（after pool ends）")}`}</div>
            </div>
          </div>
        </div>
        <div className="introduce_right">
          <div className="intitle">
            {`${t("Make sure the website is mayasale.finance!")}`}
          </div>
          <div className="nusepoeiDate">
            <div className="sale-title">
              {Number(data.start) > date ? `${t("Sale Starts In")}` : ""}
              {Number(data.start) < date && Number(data.end) > date
                ? `${t("Sale Ends In")}`
                : ""}
              {Number(data.end) < date ? "" : ""}
            </div>
            {Number(data.end) > date ? (
              <>
                <div className="nusePone">
                  {Number(data.start) > date ? (
                    <Countdown
                      value={Number(data.start)}
                      format="DD:HH:mm:ss"
                    />
                  ) : (
                    ""
                  )}
                  {Number(data.start) < date && Number(data.end) > date ? (
                    <Countdown value={Number(data.end)} format="DD:HH:mm:ss" />
                  ) : (
                    ""
                  )}
                </div>
              </>
            ) : (
              ""
            )}
          </div>
          <div className="progress">
            <Progress
              percent={((Number(data.raisedAmount) / Number(data.HardCap)) * 100) as number}
              showInfo={false}
            />
            <div className="progress_itmel">
              <div>0 BNB</div>
              <div>{Number(Allocation.amount as string)} BNB</div>
            </div>
          </div>
          <div className="progress_uitle"></div>
          {endTimeState ? (
            <div className="progress_input">
              <div className="progress_input_titler">
                {`${t("Amount")}`} ({`${t("max")}`}: {maxInve} BNB)
              </div>
              <div className="progress_input_input">
                <Input
                  placeholder="0.0"
                  value={AmountValue}
                  onChange={(e) => {
                    setAmountValue(e.target.value);
                  }}
                />
                <button
                  onClick={() => {
                    MaxOnclick();
                  }}
                >
                  {`${t("Max")}`}
                </button>
              </div>
              {privateSale ? (
                <div className="progress_input_button">
                  <Alert message={`${t("You are not in whitellist")}`} banner />
                </div>
              ) : (
                ""
              )}
              <div className="pnsuein_button">
                {BnBShow ? (
                  <button
                    onClick={() => {
                      BuywithOnClick(data);
                    }}
                  >
                    {buywithloading ? <ButtonLoading /> : ""}{" "}
                    {`${t("Buy with BNB")}`}
                  </button>
                ) : (
                  <button className="flaseBuen" disabled>
                    {buywithloading ? <ButtonLoading /> : ""}{" "}
                    {`${t("Buy with BNB")}`}
                  </button>
                )}
                {claimState ? (
                  <button
                    onClick={() => {
                      ClaimOnClick(data);
                    }}
                  >
                    {buywithloading ? <ButtonLoading /> : ""} {`${t("Claim")}`}{" "}
                    ({UserClaimAble})
                  </button>
                ) : (
                  ""
                )}
                {joinInfosState ? (
                  <button
                    onClick={() => {
                      withdrawContributeOnClick(data);
                    }}
                  >
                    {buywithloading ? <ButtonLoading /> : ""}{" "}
                    {`${t("withdrawContribute")}`} ({UserClaimAble})
                  </button>
                ) : (
                  ""
                )}
                {emergencyState ? (
                  <button
                    onClick={() => {
                      emergencyWithdrawContributeOnClick(data);
                    }}
                  >
                    {buywithloading ? <ButtonLoading /> : ""}{" "}
                    {`${t("emergencyWithdrawContribute")}`} ({UserClaimAble})
                  </button>
                ) : (
                  ""
                )}
              </div>
            </div>
          ) : (
            ""
          )}
          <div className="ownerzone">
            <div className="ownerzone_item">
              <div className="ownerzone_item_nrio">
                <div>{`${t("Status")}`}</div>
                <div>
                  {(Number(data.start) as number) > date
                    ? `${t("Upcoming")}`
                    : StatusData.Status === "1" &&
                      Number(data.raisedAmount) < Number(data.HardCap) &&
                      Number(data.end) < date
                      ? `${t("Sale Ended")}`
                      : Number(data.raisedAmount) === Number(data.HardCap)
                        ? `${t("Fiiled")}`
                        : StatusData.Status === "3"
                          ? `${t("Canceled")}`
                          : StatusData.Status === "2"
                            ? `${t("Sale Ended")}`
                            : `${t("Sale Live")}`}
                </div>
              </div>
              <div className="ownerzone_item_nrio">
                <div>{`${t("Sale Type")}`}</div>
                <div>{`${t(StatusData.SaleType as string)}` || 0}</div>
              </div>
              <div className="ownerzone_item_nrio">
                <div>{`${t("Minimum Buy")}`}</div>
                <div>{Number(StatusData.MinimumBuy as string) || 0}{" "}{data.FeeTokenSymbol as string}</div>
              </div>
              <div className="ownerzone_item_nrio">
                <div>{`${t("Maximum Buy")}`}</div>
                <div>{Number(StatusData.MaximumBuy as string) || 0}{" "}{data.FeeTokenSymbol as string}</div>
              </div>
              <div className="ownerzone_item_nrio">
                <div>{`${t("Total Contributors")}`}</div>
                <div>{(StatusData.Totalibutors as string) || 0}</div>
              </div>
              <div className="ownerzone_item_nrio">
                <div>{`${t("You purchased")}`}</div>
                <div>{Number(StatusData.Youpurchased as string) || 0}{" "}{data.FeeTokenSymbol as string}</div>
              </div>
              <div className="ownerzone_item_nrio">
                <div>{`${t("Vesting for Presale")}`}</div>
                <div>
                  <div>{StatusData.tokenReleaseEachCycle as string}%({`${t("each")}`}{StatusData.vestingPeriodEachCycle as string} {`${t("minutes")}`})</div>
                </div>
              </div>
            </div>
            {ownerState ? (
              <div className="ownerzone_item">
                <div className="owntitle">{`${t("Owner Zone")}`}</div>
                <div className="owntitle_title">
                  <div>{`${t("Sale Type")}`}</div>
                </div>
                <div className="owntitle_Reios">
                  <Radio.Group onChange={RadioOnChange} value={RadioValue}>
                    <Radio value={1}>{`${t("Public")}`}</Radio>
                    <Radio value={2}>{`${t("Whitelist")}`}</Radio>
                    <Radio value={3}>{`${t("Public Anti-Bot")}`}</Radio>
                  </Radio.Group>
                </div>
                {SaleType === 1 ? (
                  ""
                ) : SaleType === 2 ? (
                  <>
                    <div className="warmreminder">
                      <button
                        onClick={() => {
                          setIsModalOpenOnClick("Add");
                        }}
                      >
                        {`${t("Add users to whitelist")}`}
                      </button>
                      <button
                        onClick={() => {
                          setIsModalOpenOnClick("Remove");
                        }}
                      >
                        {`${t("Remove users from whitelist")}`}
                      </button>
                      {/* <button
                        onClick={() => {
                          ModalOpenSettingOnCLiuc(0);
                        }}
                      >
                        { disablewhiteloading ? <><ButtonLoading></ButtonLoading>{" "} {`${t("Setting time to public")}`}</> : `${t("Setting time to public")}`}
                      </button> */}
                      <button
                        onClick={() => {
                          ModalOpenSettingOnCLiuc(0);
                        }}
                      >
                        {disablewhiteloading ? <><ButtonLoading></ButtonLoading>{" "} {`${t("Disable whitelist")}`}</> : `${t("Disable whitelist")}`}
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="SettingBuotne">
                    <button
                      onClick={() => {
                        SettingBuotneOnclick(data);
                      }}
                    >
                      Setting Token Holding
                    </button>
                  </div>
                )}
                <div className="action">
                  <div className="actitle">{`${t("Pool Actions")}`}</div>
                  {Contributors ? (
                    <button
                      onClick={() => {
                        setisModalContributors(true);
                      }}
                    >
                      {`${t("List of Contributors")}`}
                    </button>
                  ) : (
                    ""
                  )}
                  {FinalizeState ? (
                    <button className="Pusiner">
                      {" "}
                      {finalizeloading ? <><ButtonLoading /></> : ""}{`${t("Finalize")}`}{" "}
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        FinalizeOnClick();
                      }}
                    >
                      {finalizeloading ? <><ButtonLoading /></> : ""}{`${t("Finalize")}`}{" "}
                    </button>
                  )}
                  {cancel ? (
                    <button
                      onClick={() => {
                        WithdrawCanceledTokensClick();
                      }}
                    >
                      {withdrawloading ? <ButtonLoading /> : ""}{" "}
                      {`${t("Withdraw canceled tokens")}`}
                    </button>
                  ) : (
                    <>
                      {PoolState ? (
                        ""
                      ) : (
                        <button
                          onClick={() => {
                            CancelPoolOnClick();
                          }}
                        >
                          {cancelpoolloading ? <ButtonLoading /> : ""}{" "}
                          {`${t("Cancel Pool")}`}
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
      {Somedata.length === 0 ? (
        ""
      ) : (
        <div className="Somebody_allocations">
          <div className="allocations">
            <div className="altitle">{`${t("Whitelist")}`}</div>

            <>
              {Somedata.map((item: getAlloDataProps, index: number) => (
                <div className="datatext" key={index}>
                  <div className="one">{item.address}</div>
                  <div className="ddateus">{item.amount}</div>
                </div>
              ))}
            </>
          </div>
        </div>
      )}
      <Modal
        title={`${AddRemoleJudge === "Add"
          ? `${t("Add users to whitelist")}`
          : `${t("Remove addresses from blacklist")}`
          }`}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <div>
          <TextArea
            rows={4}
            id="test"
            autoSize={{ minRows: 10, maxRows: 6 }}
            placeholder={`${t(
              "Insert address: separate with breaks line.Ex: 0x34E7f6A4d0BB1fa7aFe548582c47Df337FC337E6 0xd8Ebc66f0E3D638156D6F5eFAe9f43B1eBc113B1 0x968136BB860D9534aF1563a7c7BdDa02B1A979C2"
            )}`}
            value={TextArea1}
            onChange={(e: any) => {
              TextAreaonChangeAdd(e);
            }}
          />
        </div>
      </Modal>
      <Modal
        title={`${t("Setting time to start")}`}
        open={isModalOpenSetting}
        onOk={handleOkSetting}
        onCancel={handleCancelSetting}
        footer={null}
      >
        <div className="sbuiePloe">
          <div className="intitle">
            {`${t(
              "Public with holding condition With this option you can control who can contribute to the pool. OnlyUsers who hold a minimum amount of token you suggest would beable to contribute"
            )}`}
          </div>
          <div className="InonmTole_tile">{`${t("Token Address")}`}</div>
          <div className="InonmTole">
            <Input
              placeholder="Enter token address."
              value={vluesList.Address}
              onChange={(e) => {
                setvluesList((olddata: vluesProps) => {
                  return {
                    ...olddata,
                    Address: e.target.value,
                  };
                });
              }}
            />
          </div>
          <div className="InonmTole_tile">{`${t("Min Holding Amount")}`}</div>
          <div className="InonmTole">
            <Input
              placeholder="ex:1000"
              value={vluesList.Amount}
              onChange={(e) => {
                setvluesList((olddata: vluesProps) => {
                  return {
                    ...olddata,
                    Amount: e.target.value,
                  };
                });
              }}
            />
          </div>
          <div className="AmountOnser">
            <button
              onClick={() => {
                setWhitelistPoolOnclick();
              }}
            >
              Save Settings
            </button>
          </div>
        </div>
      </Modal>
      <Modal
        title={`${t("Contributors")}`}
        open={isModalContributors}
        onOk={handleOkContributors}
        onCancel={handleCancelContributors}
        footer={null}
      >
        <Table dataSource={ContributorsData} columns={columns} />
        <div>
          <button>导出</button>
        </div>
      </Modal>
    </div>
  );
};
export default CurrentPresales;
