import React, { Component } from "react";
import Header from "../../components/Header";
import Buwe1 from "../../assets/shtu.png";
import fx1 from "../../assets/fx1.png";
import fx2 from "../../assets/fx2.png";
import "./index.scss";
import { Carousel } from "antd";
import Heues from "../../components/Heues";

export default class index extends Component {
  card: React.RefObject<any>;
  constructor(props: any) {
    super(props);
    this.card = React.createRef();
  }
  onChange = (currentSlide: number) => {
    console.log(currentSlide);
  };
  render() {
    return (
      <div className="minstikl">
        <div className="mintite">
          <Header />
        </div>
        <div className="snuelise">
          <div className="mindtbei">
            <Carousel afterChange={this.onChange} ref={this.card}>
              <div className="minditme">
                <div className="nsielnimg">
                  <img src={Buwe1} alt="" />
                </div>
              </div>
              <div className="minditme">
                <div className="nsielnimg">
                  <img src={Buwe1} alt="" />
                </div>
              </div>
              <div className="minditme">
                <div className="nsielnimg">
                  <img src={Buwe1} alt="" />
                </div>
              </div>
              <div className="minditme">
                <div className="nsielnimg">
                  <img src={Buwe1} alt="" />
                </div>
              </div>
            </Carousel>
            <div className="suAnsr">
              <div className="anniur1">
                <img
                  src={fx1}
                  alt=""
                  onClick={() => {
                    this.card.current.prev();
                  }}
                />
              </div>
              <div className="anniur2">
                <img
                  src={fx2}
                  alt=""
                  onClick={() => {
                    this.card.current.next();
                  }}
                />
              </div>
            </div>
          </div>
          <div className="sliebsi"></div>
          <div className="sliebuton">
            <button>MINT</button>
          </div>
        </div>
        <Heues burl="/Mint" />
      </div>
    );
  }
}
