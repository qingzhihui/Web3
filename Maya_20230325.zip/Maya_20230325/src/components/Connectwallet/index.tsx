import { useEffect, useState } from "react";
import { MetamShow, connectWalletConnect } from "../../hooks/Cowallet";
import "./index.scss";
import { Modal } from "antd";
import { Dropdown, Menu } from "antd";
import type { MenuProps } from "antd";
import { CloseOutlined, ExportOutlined } from "@ant-design/icons";
import { useTranslation, Trans } from "react-i18next";

const Connectwallet = () => {
  const { t } = useTranslation();

  const [isModalOpen,setIsModalOpen] = useState<boolean>(false)
  const [address, setAddress] = useState("");
  const [isTimese, setisTimese] = useState(false);
  const showHide2 = () => {
    setisTimese(false);
  };
  useEffect(() => {
    const addr = localStorage.getItem("MaYa_addr");
    if (addr !== null && addr !== undefined) {
      setAddress(addr);
      setisTimese(false);
    }

    if(!window.ethereum){
      setIsModalOpen(true)
    }

  }, []);
  const MetaMaskOnClikc = () => {
    MetamShow()
      .then((res) => {
        setAddress(res);
        setisTimese(false);
      })
      .catch((error) => {
      });
  };
  const Mespuser = [
    {
      label: (
        <div className="pserivkie">
          <div className="pserivkie_title">{`${t("Disconnect")}`}</div>
          <div className="pserivkie_loger">
            {" "}
            <ExportOutlined style={{ fontSize: "16px" }} />
          </div>
        </div>
      ),
      key: "1",
    },
  ];
  const handleMenuClickPuier: MenuProps["onClick"] = (e) => {
    if (e.key == "1") {
      setAddress("");
      window.localStorage.clear();
    }
  };
  const menuPuier = <Menu onClick={handleMenuClickPuier} items={Mespuser} />;

  const handleOk = () => {
    setIsModalOpen(false)
  }

  return (
    <div className="Connectwallet">
      <div className="poineuByuer">
        {address === "" ? (
          <button
            onClick={() => {
              setisTimese(true);
            }}
          >
            {`${t("Connect Wallet")}`}
          </button>
        ) : (
          <Dropdown
            overlay={menuPuier}
            placement="bottomRight"
            arrow={{ pointAtCenter: true }}
          >
            <div className="addre">
              {" "}
              {address.substring(0, 4) + "..." + address.substring(38, 42)}
            </div>
          </Dropdown>
        )}
      </div>
      {isTimese ? (
        <div className="pserExbuse">
          <div
            className="pserzhes"
            onClick={() => {
              setisTimese(false);
            }}
          ></div>
          <div className="pserTise">
            <div className="pserExchange_nro">
              {address}
              <div className="nrobue1">
                <div>{`${t("Connect Wallet")}`}</div>
                <div
                  className="gbuiengkum"
                  onClick={() => {
                    showHide2();
                  }}
                >
                  <CloseOutlined
                    style={{
                      color: "#ffff",
                      fontSize: "28px",
                    }}
                  />
                </div>
              </div>
              <div className="nrobue2">
                <div className="modalContent">
                  <div
                    className="connectbtnItem"
                    onClick={() => {
                      MetaMaskOnClikc();
                    }}
                  >
                    <img
                      src={require("../../assets/image/MetamaskLogo.png")}
                      alt=""
                    />
                    <span>MetaMask</span>
                  </div>
                  <div
                    className="connectbtnItem"
                    onClick={() => {
                      MetamShow();
                    }}
                  >
                    <img
                      src={require("../../assets/image/TokenPocketLogo.png")}
                      alt=""
                    />
                    <span>Token Pocket</span>
                  </div>
                  <div
                    className="connectbtnItem"
                    onClick={() => {
                      connectWalletConnect();
                    }}
                  >
                    <img
                      src={require("../../assets/image/WalletConnectLogo.png")}
                      alt=""
                    />
                    <span>WalletConnect</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}


      <Modal
        title={`${t("无钱包")}`}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleOk}
        // footer={null}
      >
        <span>您没有登录钱包，请登录钱包使用全部功能</span>
      </Modal>
    </div>
  );
};

export default Connectwallet;
