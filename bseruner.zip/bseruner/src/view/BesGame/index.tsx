import React, { Component } from "react";
import "./index.scss";
import Header from "../../components/Header";
import zheng from "../../assets/zfa.png";
import zheng2 from "../../assets/zfa2.png";
import Heues from "../../components/Heues";

export default class index extends Component {
  render() {
    return (
      <div className="games">
        <div className="mintite">
          <Header />
        </div>
        <div className="gamesNero">
          <div className="fle1">
            <img src={zheng} alt="" />
          </div>
          <div className="clisbeu">
            <img src={zheng2} alt="" />
            <div className="clinro">
              <span>Go play</span>
            </div>
          </div>
        </div>
        <Heues burl="/Game" />
      </div>
    );
  }
}
