import React, { useEffect, useState } from "react";
import Dome from "./view/dome3";
import "./App.css";
declare const window: Window & { ethereum: any };

function App() {
  return (
    <div className="App">
      <Dome />
    </div>
  );
}

export default App;
