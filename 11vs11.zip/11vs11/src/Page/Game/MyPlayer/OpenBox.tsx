import "./OpenBox.scss";
import gift from "./gift.png";
import Card from "./Card";
import { useEffect, useState } from "react";
import { useGetWeb3 } from "../../../hooks/useGetWeb3";
import {useTranslation} from "react-i18next";

type Props = {
  status: "loading" | "close" | "success" | "open" | "error";
  setStatus(status: "loading" | "close" | "success" | "open" | "error"): void;
  unBox(e: any): void;
  tokenId: string;
  tokenBalance: any[];
  loading: any;
  acceptData:any
};

type Item = {
  cName?: string;
  image?: string;
  tokenId?: string;
  rarty?: string;
  occ?: string;
  speed?: string;
  shoot?: string;
  guard?: string;
  save?: string;
  lucky?: string;
};

export default function OpenBox(props: Props) {
  const [obj, setObj] = useState<Item>({});
  
  useEffect(() => {
    if (props.status === "loading") {
      console.log(props.status);
      let find = props.tokenBalance.find((item) => {
        return item.tokenId === props.tokenId;
      });
      if (find && find.image.slice(37) != "CardPackItem_3.png") {
        setObj(find);
        props.acceptData(find)
        props.setStatus("success");
      }
    }
  }, [props.tokenBalance]);
  const toBalance = async (e: any) => {
    try {
      console.log(e);
    } catch (error) {
      console.log(error);
    }
  };
  const {t} = useTranslation()

  return (
    <>
      {props.status !== "close" ? (
        <div id="open-box">
          {props.status !== "success" ? (
            <>
              <div className="content">
                <video
                  loop
                  muted
                  autoPlay
                  src="https://metadata.11vs11.club/box.mp4"
                />
              </div>
              {props.status === "loading" ? (
                <div className="text">Flip the Card, Please wait...</div>
              ) : props.status === "error" ? (
                <div className="text">Error</div>
              ) : props.status === "open" ? (
                <div className="text">Please click the "Flip the Card" button</div>
              ) : null}
            </>
          ) : (
            <>
              <Card
                title={obj?.cName ?? ""}
                img={obj?.image ?? ""}
                list={{
                  Properties: obj?.rarty ?? "",
                  Occupation: obj?.occ ?? "",
                  Speed: obj?.speed ?? "",
                  Shoot: obj?.shoot ?? "",
                  Guard: obj?.guard ?? "",
                  Save: obj?.save ?? "",
                  Lucky: obj?.lucky ?? "",
                }}
              />
              <div className="text">Flip the Card Success !</div>
            </>
          )}
          {props.status !== "success" ? (
            <button
              className="common-btn"
              value={props.tokenId}
              onClick={props.unBox}
            >
              {props.status !== "loading" ? "Flip the Card" : "Fliping"}
            </button>
          ) : null}
          <div className="common-btn" onClick={() => props.setStatus("close")}>
            {t("game.close")}
          </div>
        </div>
      ) : null}
    </>
  );
}
