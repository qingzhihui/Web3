export default {
    uploadUrl: `http://127.0.0.1/uploadImg/` //你的上传到服务器地址
  }