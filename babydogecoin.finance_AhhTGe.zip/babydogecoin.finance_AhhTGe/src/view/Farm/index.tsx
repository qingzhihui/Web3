import React, { useEffect, useState, useLayoutEffect } from "react";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import { Button, Input, notification, Modal, Tabs } from "antd";
import { CheckCircleOutlined, LoadingOutlined } from "@ant-design/icons";
import Header from "../../components/Header";
import "./index.scss";
import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../../redux/Contract/contractApp";
import { PAIR_ABI } from "../../redux/Contract/pancakepair";
import { wben_ABI } from "../../redux/Contract/wbenjson";
import List from "../../redux/UsJson/Colest.json";
import { useTranslation } from "react-i18next";

declare const window: Window & { ethereum: any };

function Index() {
  const MINUTE_MS = 1000;
  const [address, serAddres] = useState("");
  const [showList, setShowList] = useState(List);
  const [inputValue, setInputValue] = useState(0);
  const [unShow, setunShow] = useState(false);
  const key = "updatable";
  const [isModalVisible, setIsModalVisible] = useState(false);
  const { t } = useTranslation();
  const handleOk = async (id: any) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const Contract = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      );
      const withs = await Contract.withdraw(id);
      openNotification2(
        "Retrieving...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setIsModalVisible(false);
      await withs.wait();
      openNotification2(
        "Retrieved successfully.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      const pldata = await Contract.userInfo(id, address);
      const buList: any = [];
      showList.map((item: any) => {
        if (item.id == id) {
          item.lPdata = ethers.utils.formatEther(
            pldata.depositAmount.toString()
          );
        }
        buList.push(item);
      });
      setInputValue(0);
      setIsModalVisible(false);
      setTimeout(() => {
        setShowList(buList);
      }, 300);
    } catch (error: any) {
      setIsModalVisible(false);
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification2(
          "User refuses to retrieve.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
      }
    }
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const openNotification2 = (bindValue: any, durn: any, icon: any) => {
    notification.open({
      key,
      message: "Tips",
      description: bindValue,
      duration: durn,
      icon: icon,
    });
  };
  // 授权
  const approve = async (code: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const PAIRContract = new ethers.Contract(code, PAIR_ABI, signer);
    const apperov = await PAIRContract.approve(
      CONTRACT_ADDRESS,
      ethers.constants.MaxUint256
    );
    openNotification2(
      "Under authorization...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await apperov.wait();
    const buList: any = [];
    showList.map((item: any) => {
      if (item.code == code) {
        item.show = 1;
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
    openNotification2(
      "Authorization succeeded.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
  };
  // 质押
  const deposit = async (id: any) => {
    // try {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const value = new BigNumber(inputValue)
      .times(new BigNumber(10).pow(18))
      .toFixed();
    const desite = await Contract.deposit(id, value.toString());
    openNotification2(
      "In deposit...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await desite.wait();
    openNotification2(
      "Deposit succeeded.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
    const pldata = await Contract.userInfo(id, address);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.lPdata = ethers.utils.formatEther(pldata.depositAmount.toString());
        item.inputValue = "";
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };
  // 领取
  const claim = async (id: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const cladim = await Contract.claim(id);
    openNotification2(
      "Receiving...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await cladim.wait();
    openNotification2(
      "Successfully received.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
  };
  // 最大值
  const BinCkmax = async (bianes: any, id: any) => {
    setInputValue(bianes);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = bianes;
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
    setunShow(true);
  };
  // 赎回
  const withdraw = async (id: any) => {
    setIsModalVisible(true);
  };
  const onCInput = (e: any, id: any) => {
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = e.target.value;
        setInputValue(e.target.value);
        const Shui = e.target.value || 0;
        if (Shui === 0) {
          setunShow(false);
        } else if (item.inputValue === 0) {
          setunShow(false);
        } else {
          setunShow(true);
        }
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };

  useEffect(() => {
    const ahsdr = localStorage.getItem("addr");
    if (ahsdr !== null && ahsdr !== undefined) {
      setTimeout(() => {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const LIbse: any = showList;
        showList.map(async (item: any) => {
          const address = await signer.getAddress();
          serAddres(address);
          const PAIRContract = new ethers.Contract(item.code, PAIR_ABI, signer);
          const usider = await PAIRContract.allowance(
            address,
            CONTRACT_ADDRESS
          );
          const Contract = new ethers.Contract(
            CONTRACT_ADDRESS,
            CONTRACT_ABI,
            signer
          );
          const bineof = await PAIRContract.balanceOf(address);
          const pldata = await Contract.userInfo(item.id, address);
          const pending = await Contract.pendingReward(item.id, address);

          const ContractToken1 = new ethers.Contract(
            item.token1,
            wben_ABI,
            signer
          );
          const ContractToken2 = new ethers.Contract(
            item.token2,
            wben_ABI,
            signer
          );
          const totalSupply = await PAIRContract.totalSupply();
          const bnbTotal1 = await ContractToken1.balanceOf(item.code);
          const decimals1 = await ContractToken1.decimals();
          const bnbTotal2 = await ContractToken2.balanceOf(item.code);
          const decimals2 = await ContractToken2.decimals();
          const lisne = await Contract.userInfo(item.id, address);
          let holdRatio1 =
            Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
          let userBnb1 = Number(bnbTotal1) * holdRatio1;
          let nukse1 = userBnb1 / 10 ** decimals1;
          let holdRatio2 =
            Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
          let userBnb2 = Number(bnbTotal2) * holdRatio2;
          let nukse2 = userBnb2 / 10 ** decimals2;
          const t1 = new Date().valueOf();
          const beins =
            t1.toString().slice(0, 3) +
            "," +
            t1.toString().slice(3, 6) +
            "," +
            t1.toString().slice(6, 9);

          if (
            Number(usider.toString()) == Number(ethers.constants.MaxUint256)
          ) {
            LIbse[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            LIbse[item.pid].lPdata = ethers.utils.formatEther(
              pldata.depositAmount.toString()
            );
            LIbse[item.pid].lPdataToken1 = String(nukse1.toFixed(10));
            LIbse[item.pid].lPdataToken2 = String(nukse2.toFixed(10));
            LIbse[item.pid].Pending = ethers.utils.formatEther(
              pending.toString()
            );
            LIbse[item.pid].pron1 = beins;
            LIbse[item.pid].show = 1;
          } else {
            LIbse[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            LIbse[item.pid].show = 0;
            LIbse[item.pid].pron1 = beins;
          }
        });
        setTimeout(() => {
          setShowList(LIbse);
        }, 500);
      }, 500);
      // 切换钱包
      (window as any).ethereum.on(
        "accountsChanged",
        async function (accounts: any) {
          localStorage.setItem("addr", accounts[0]);
          setTimeout(() => {
            serAddres(accounts[0]);
            const provider = new ethers.providers.Web3Provider(window.ethereum);
            const signer = provider.getSigner();
            const LIbse: any = showList;
            showList.map(async (item: any) => {
              const PAIRContract = new ethers.Contract(
                item.code,
                PAIR_ABI,
                signer
              );
              const usider = await PAIRContract.allowance(
                accounts[0],
                CONTRACT_ADDRESS
              );
              const Contract = new ethers.Contract(
                CONTRACT_ADDRESS,
                CONTRACT_ABI,
                signer
              );
              const bineof = await PAIRContract.balanceOf(accounts[0]);
              const pldata = await Contract.userInfo(item.id, accounts[0]);
              const pending = await Contract.pendingReward(
                item.id,
                accounts[0]
              );

              const ContractToken1 = new ethers.Contract(
                item.token1,
                wben_ABI,
                signer
              );
              const ContractToken2 = new ethers.Contract(
                item.token2,
                wben_ABI,
                signer
              );
              let totalSupply = "";
              const ches2 = PAIRContract.totalSupply();
              ches2.then((res: any) => (totalSupply = res));
              let bnbTotalNum1 = "";
              let bnbTotal1 = ContractToken1.balanceOf(item.code);
              bnbTotal1.then((res: any) => (bnbTotalNum1 = res));
              const decimals1 = await ContractToken1.decimals();
              let bnbTotalNum2 = "";
              let bnbTotal2 = ContractToken2.balanceOf(item.code);
              bnbTotal2.then((res: any) => (bnbTotalNum2 = res));
              const decimals2 = await ContractToken2.decimals();
              const lisne = await Contract.userInfo(item.id, accounts[0]);
              let holdRatio1 =
                Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
              let userBnb1 = Number(bnbTotalNum1) * holdRatio1;
              let nukse1 = userBnb1 / 10 ** decimals1;
              let holdRatio2 =
                Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
              let userBnb2 = Number(bnbTotalNum2) * holdRatio2;
              let nukse2 = userBnb2 / 10 ** decimals2;
              if (
                Number(usider.toString()) == Number(ethers.constants.MaxUint256)
              ) {
                LIbse[item.pid].bianes = ethers.utils.formatEther(
                  bineof.toString()
                );
                LIbse[item.pid].lPdata = ethers.utils.formatEther(
                  pldata.depositAmount.toString()
                );
                LIbse[item.pid].lPdataToken1 = String(nukse1.toFixed(10));
                LIbse[item.pid].lPdataToken2 = String(nukse2.toFixed(10));
                LIbse[item.pid].Pending = ethers.utils.formatEther(
                  pending.toString()
                );
                LIbse[item.pid].show = 1;
              } else {
                LIbse[item.pid].bianes = ethers.utils.formatEther(
                  bineof.toString()
                );
                LIbse[item.pid].show = 0;
              }
            });
            setTimeout(() => {
              setShowList(LIbse);
            }, 500);
          }, 1000);
        }
      );
      const interval = setInterval(async () => {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const Listusn: any = showList;
        showList.map(async (item: any) => {
          const Contract = new ethers.Contract(
            CONTRACT_ADDRESS,
            CONTRACT_ABI,
            signer
          );
          const address = await signer.getAddress();
          const PAIRContract = new ethers.Contract(item.code, PAIR_ABI, signer);
          const usider = await PAIRContract.allowance(
            address,
            CONTRACT_ADDRESS
          );
          const pending = await Contract.pendingReward(item.id, address);
          const bineof = await PAIRContract.balanceOf(address);
          const pldata = await Contract.userInfo(item.id, address);
          const t1 = new Date().valueOf();
          const beins =
            t1.toString().slice(0, 3) +
            "," +
            t1.toString().slice(3, 6) +
            "," +
            t1.toString().slice(6, 9);
          if (
            Number(usider.toString()) == Number(ethers.constants.MaxUint256)
          ) {
            Listusn[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            Listusn[item.pid].lPdata = ethers.utils.formatEther(
              pldata.depositAmount.toString()
            );
            Listusn[item.pid].pron1 = beins;
            Listusn[item.pid].Pending = ethers.utils.formatEther(
              pending.toString()
            );
            Listusn[item.pid].show = 1;
          } else {
            Listusn[item.pid].show = 0;
            Listusn[item.pid].pron1 = beins;
          }
        });
        setTimeout(() => {
          let _Listusn = JSON.parse(JSON.stringify(Listusn));
          setShowList(_Listusn);
        }, 500);
      }, MINUTE_MS);
      return () => clearInterval(interval);
    }
  }, [inputValue, showList, address]);
  return (
    <div className="Frome">
      <Header />
      <div className="banNdr">
        <div className="sueeis">
          <div className="sueeis_title">
            <img src={require("../../assets/nuei.png")} alt="" />
            {`${t("Dividend factory")}`}
          </div>
          <div className="pioasbue">
            <img src={require("../../assets/goyp.png")} alt="" />
          </div>
        </div>
        <div className="nsuroBIneg">
          {showList.map((item: any) => (
            <div className="NuserList2" key={item.id}>
              <div className="Lisndter">
                <Tabs defaultActiveKey="1">
                  <Tabs.TabPane tab={`${t("Deposit LP dividends")}`} key="1">
                    <div className="NusierItem">
                      <div className="Butile">
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Entered the pool")}`}</div>
                          {item.lPdataToken1 || "0.0"} {item.name.split("/")[0]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Entered the pool")}`}</div>{" "}
                          {item.lPdataToken2 > 0 &&
                          item.lPdataToken2 < 0.0000000001
                            ? "< 0.0000000001"
                            : item.lPdataToken2 || "0.0"}{" "}
                          {item.name.split("/")[1]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Over")}`}</div>
                          {item.bianes || "0.0"} {item.name} LP
                        </div>
                      </div>
                      <div className="nbudrki">
                        {item.show === 1 ? (
                          <div className="Bininput">
                            <Input
                              value={item.inputValue}
                              onChange={(e) => onCInput(e, item.id)}
                              type="text"
                              placeholder="0.0"
                            />
                            <div className="Binmax">
                              <Button
                                onClick={() => {
                                  BinCkmax(item.bianes, item.id);
                                }}
                              >
                                Max
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="Bininput">
                            <Input disabled type="text" placeholder="0.0" />
                            <div className="Binmax">
                              {" "}
                              <div className="nuBut">
                                <Button disabled>Max</Button>
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="Nusoer">
                          <div className="Numerbut">
                            {item.show === 1 ? (
                              <>
                                {item.inputValue !== "" && unShow ? (
                                  <Button
                                    onClick={() => {
                                      deposit(item.id);
                                    }}
                                  >
                                    {`${t("Deposit")}`}
                                  </Button>
                                ) : (
                                  <div className="nuBut">
                                    <Button disabled> {`${t("Deposit")}`}</Button>
                                  </div>
                                )}
                              </>
                            ) : (
                              <Button
                                onClick={() => {
                                  approve(item.code);
                                }}
                              >
                               {`${t("Approve")}`}
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tabs.TabPane>
                  <Tabs.TabPane tab={`${t("Retrieve LP")}`} key="2">
                    <div className="NusierItem2">
                      <div className="Butile">
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Entered the pool")}`}</div>
                          {item.lPdataToken1 || "0.0"} {item.name.split("/")[0]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Entered the pool")}`}</div>{" "}
                          {item.lPdataToken2 || "0.0"} {item.name.split("/")[1]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">{`${t("Over")}`}</div>
                          {item.bianes || "0.0"} {item.name} LP
                        </div>
                      </div>
                      {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                        <div className="item2nr">
                          <div className="Butile">
                            <div className="yruci">
                              <span> {`${t("Deposited")}`}</span> ：{item.lPdata || "0"}{" "}
                              {item.name} LP
                            </div>
                          </div>
                          <div className="Nusoer">
                            <div className="soer_btn">
                              <Button
                                onClick={() => {
                                  withdraw(item.id);
                                }}
                              >
                               {`${t("Withdraw")}`}
                              </Button>
                            </div>
                          </div>
                          <Modal
                            title="Tips"
                            width={400}
                            visible={isModalVisible}
                            okText="确认"
                            cancelText="取消"
                            centered
                            onOk={() => {
                              handleOk(item.id);
                            }}
                            onCancel={handleCancel}
                          >
                            <p>{`${t("Please confirm the withdraw ?")}`}</p>
                          </Modal>
                        </div>
                      ) : (
                        <div className="item2nrs">
                          <div className="Butile">
                            <div className="yruci">
                              <span>{`${t("No deposit LP")}`}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </Tabs.TabPane>
                </Tabs>
              </div>
              <div className="Lisndter_2use">
                <div className="psriosimge">
                  <img src={require("../../assets/nuei.png")} alt="" />
                </div>
                <div className="item2nr">
                  <div className="Butile">
                    <div className="yruci">
                      <div className="tilei">{`${t("To receive dividends")}`}</div>
                      {item.Pending || "0.0"} BabyDoge
                    </div>
                  </div>
                  <div className="Nusoer">
                    <div className="soer_btn">
                      {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                        <Button
                          onClick={() => {
                            claim(item.id);
                          }}
                        >
                        {`${t("Claim")}`}  
                        </Button>
                      ) : (
                        <div className="nuBut">
                          <Button disabled>{`${t("Claim")}`}</Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Index;
