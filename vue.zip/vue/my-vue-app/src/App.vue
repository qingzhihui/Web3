<script setup>
import HelloWorld from './components/HelloWorld.vue'
import Dome from './components/Dome.vue';
import Dome2 from './components/Dome2.vue'
import Dome3 from './components/Dome3.vue'
import Dome4 from './components/Dome4.vue';
import Dome5 from './components/Dome5.vue';
import Dome6 from './components/Dome6.vue';
import Dome7 from './components/Dome7.vue';
import Dome8 from './components/Dome8.vue';
import Dome9 from './components/Dome9.vue';
import Dome10 from './components/Dome10.vue'
import Demo11 from './components/Dome11.vue'
import Demo12 from './components/Dome12.vue'
import Demo13 from './components/Dome13.vue'
import Demo14 from './components/Dome14.vue'
import Demo15 from './components/Dome15.vue'
import Demo16 from './components/Dome16.vue'
import Demo17 from './components/Dome17.vue'
import Demo18 from './components/Dome18.vue'
import Demo19 from './components/Dome19.vue'
import Demo20 from './components/Dome20.vue'
import Demo21 from './components/Dome21.vue'
import Demo22 from './components/Dome22.vue'
import Demo23 from './components/Dome23.vue'
import Demo24 from './components/Dome24.vue'
import Demo25 from './components/Dome25.vue'
import Demo26 from './components/Dome26.vue'
import Demo27 from './components/Dome27.vue'
import Demo28 from './components/Dome28.vue'
import Demo29 from './components/Dome29.vue'
import Dome30 from "./components/Dome30.vue";
import Dome31 from "./components/Dome31.vue";
import Dome32 from "./components/Dome32.vue";
import Dome33 from "./components/Dome33.vue";
import Dome35 from "./components/Dome35.vue";
</script>

<template>
  <!-- <HelloWorld foo="你爹来啦" bar="0" /> -->
  <!-- <Dome /> -->
  <!-- 为什么不让使用undefined -->
  <!-- <Dome2 /> -->
  <!-- 随机颜色 -->
  <!-- <Dome3 /> -->
  <!-- 无法预算的大数远算 -->
  <!-- <Dome4 /> -->
  <!-- 判断对象中是否存在某个属性 -->
  <!-- <Dome5 /> -->
  <!-- 黑白滤镜 -->
  <!-- <Dome6 /> -->
  <!-- 你不知道的数组去重 -->
  <!-- <Dome7 /> -->
  <!-- 你不知道的阴影 -->
  <!-- <Dome8 /> -->
  <!-- 调整文字方向 -->
  <!-- <Dome9 /> -->
  <!--  文字方向调整-->
  <!--  <Dome10/>-->
  <!--  map和parseint-->
  <!--  <Demo11/>-->
  <!--  轮播图实现-->
  <!--  <Demo12/>-->
  <!--  函数防抖-->
  <!-- <Demo13/> -->
  <!--  不使用计时器做动画-->
  <!--  <Demo15/>-->
  <!--  为什么会死循环-->
  <!--  <Demo16/>-->
  <!--  数字格式化-->
  <!--  <Demo17/>-->
  <!--  css实现平滑滚动效果-->
  <!--  <Demo18/>-->
  <!--  原型链知识,逐帧动画，动画的暂停和恢复-->
  <!--  <Demo19/>-->
  <!--  粘性布局-->
  <!--  <Demo20/>-->
  <!--  多行溢出处理-->
  <!--  <Demo21 />-->
  <!--  this的指向-->
  <!--  <Demo22/>-->
  <!-- 手写bind  -->
  <!--  <Demo23/>-->
  <!--  手写call-->
  <!--  <Demo24/>-->
  <!--  无法取消的默认行为-->
  <!--  <Demo25/>-->
  <!--  元素的尺寸-->
  <!--  <Demo26/>-->
  <!--  监听元素重叠-->
  <!--  <Demo27/>-->
  <!--  失活页面的计时器问题-->
  <!--  <Demo28/>-->
  <!-- 鼠标的位置 -->
  <!--  <Demo29/>-->
  <!--  Flip 动画(解决排序)-->
  <!--  <Dome30/>-->
  <!-- 过度事件多次触发的问题 -->
  <!--  <Dome31 />-->
  <!--  高亮关键字（键盘鼠标抬起事件）-->
  <!--  <Dome32/>-->
  <!--  青蛙跳台阶-->
  <!--  <Dome33/>-->
  <Dome35 />
</template>

<style scoped></style>
