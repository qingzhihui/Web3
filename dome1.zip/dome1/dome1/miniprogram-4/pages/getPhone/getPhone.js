Page({
  getTal(e) {
    // encrypteData 加密数据
    // iv 加密向量
    // appid,secret,code
    let {
      encryptedData,
      iv
    } = e.detail
    let appid = "wx1766604f6ce5a6de"
    let secret = "1bb263e3bb34e4c07ed27da8fcc8f9d7"

    wx.checkSession({
      success: (res) => {
        console.log('已经登录');
      },
      fail() {
        console.log('未登录');
        wx.login({
          success(result) {
            console.log(result);
            let code = result.code
            wx.request({
              url: 'http://localhost:5000/v1/getPhoneNumber',
              method: "GET",
              data: {
                encryptedData,
                iv,
                appid,
                secret,
                code
              },
              success(phoneNumber){
                console.log(phoneNumber);
              }
            })
          }
        })
      }
    })
  },
  //检查有没有登录

})