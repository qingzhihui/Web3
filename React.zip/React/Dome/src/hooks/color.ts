import _ from "lodash";

export function Swatch(color: any) {
  console.log(`Swatch: ${color}`);
  return `Swatch: ${color}`;
}

const memoedSwatch = _.memoize(Swatch);
// memoedSwatch("red");
// memoedSwatch("blue");
// memoedSwatch("red");
// memoedSwatch("blue");

const prev: any = {
  color: null,
  result: null,
};

function rmSwatch(color: any) {
  if (color === prev.color) {
    return prev.result;
  }
  prev.color = color;
  prev.result = Swatch(color);
  return prev.result;
}


Swatch("red");
Swatch("blue");
Swatch("red");
Swatch("blue");
