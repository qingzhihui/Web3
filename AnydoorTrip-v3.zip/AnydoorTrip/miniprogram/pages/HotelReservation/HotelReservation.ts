import api from '../../config/axios'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    DetailsProps: {},
    winesData: [],
    price: {},
    policy: [],
    Secial: []
  },
  /**
 * 生命周期函数--监听页面加载
 */
  onLoad(options) {
    if (options.prosTken !== undefined) {
      const PropsReceive: any = options.prosTken;
      const HotelPanst: any = JSON.parse(PropsReceive);
      api._get(`hotel/list-policy/${HotelPanst.hotel_id}`).then(res => {
        this.setData({
          policy: res.data,
        })
      }).catch(e => {
        console.log(e);
      })
      this.setData({
        DetailsProps: JSON.parse(PropsReceive)
      })
    }
    this.getSecial();
  },
  getSecial() {
    api._get('hotel/get_special_list').then(res => {
      const Peower: any = [];
      res.data.map((item: any) => {
        Peower.push({ ...item, state: false })
      })
      this.setData({
        Secial: Peower
      })
    }).catch(e => {
      console.log(e);
    })
  },
  DelectWinesData(event: any) {
    const WinesDelecData: any = []
    for (let i = 0, len = this.data.winesData.length; i < len; i++) {
      if (i != event.currentTarget.dataset.id) {
        WinesDelecData.push(this.data.winesData[i])
      }
    }
    this.setData({
      winesData: WinesDelecData
    })
  },
  NaveCurrent(event: any) {
    this.setData({
      winesData: event
    })
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },

  HotelDataNuier() {
    const Reuest: string[] = [];
    const CLuser: string[] = [];
    this.data.Secial.map((item: any) => {
      if (item.state === true) {
        Reuest.push(item.key);
        CLuser.push(item.name)
      }
    })
    return {
      Reuest, CLuser
    }
  },
  HotelPaymentShow() {
    const UderData: any = this.HotelDataNuier();
    const data: any = this.data.DetailsProps;
    const wines: any = this.data.winesData[0]
    const oderData = {
      inTime: data.check_in,
      outTime: data.check_out,
      roomPlanId: data.id,
      hotelId: data.hotel_id,
      remark: String(UderData.CLuser),
      reserveUserInfoId: wines.id,
      roomNum: data.number_of_rooms,
      strategy: data.source,
      planType: data.plantype,
      num:data.number_of_adults,
      sourceId:data.sourceId
    }
    api._post('user/place-order', oderData).then(res => {
      const data: any = JSON.stringify(res.data);
      wx.navigateTo({
        url: `../HotelPayment/HotelPayment?item=${JSON.stringify({
          DetailsProps: this.data.DetailsProps,
          winesData: this.data.winesData,
          price: this.data.price,
          special: UderData.Reuest,
          CialeData: UderData.CLuser,
          Sccess: data
        })}`
      })
    }).catch(event => {
      console.log(event);
    })

  },
  addDetailsShow() {
    wx.navigateTo({
      url: '../Addwines/Addwines'
    })
  },
  guestInfoOnclick(event: any) {
    const eventPorps: any = []
    this.data.Secial.map((item: any) => {
      if (item.key === event.currentTarget.dataset.id) {
        if (item.state === true) {
          item.state = false;
        } else {
          item.state = true;
        }
      }
      eventPorps.push(item);
    })
    this.setData({
      Secial: eventPorps
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})