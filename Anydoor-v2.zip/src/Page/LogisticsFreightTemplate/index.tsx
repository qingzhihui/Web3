import { Button, Form, Input, Modal, Radio, Select, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import React, { useState } from "react";
import "./index.css";

import { DeleteOutlined, FormOutlined } from "@ant-design/icons";

// 物流运费模板界面
const LogisticsFreightTemplate: React.FC = () => {
  const { TextArea } = Input;
  const [isUpdajx, setUpdajx] = useState(false);

  interface DataType {
    key: number;
    templateCode: string; //模板编码
    area: string; //地区
    logisticsFreight: string; //物流运费设置
  }
  const data: DataType[] = [
    {
      key: 1,
      templateCode: "TM001",
      area: "全国",
      logisticsFreight: "运费同意8元..",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "模板编码",
      dataIndex: "templateCode",
      key: "templateCode",
    },
    {
      title: "地区",
      dataIndex: "area",
      key: "area",
    },
    {
      title: "物流运费设置",
      dataIndex: "logisticsFreight",
      key: "logisticsFreight",
    },
    {
      title: "状态",
      render: (_, record) => (
        <Space size="middle">
          <span onClick={forbiddenjx(record)} className="clickDisable">
            点击禁用
          </span>
        </Space>
      ),
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span onClick={uploadjx(record)} className="wl_publicStyleA">
            <FormOutlined />
          </span>
          <span onClick={deletejx(record)} className="wl_publicStyleA">
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 下拉选择框-地区-内容
  const options1 = [
    {
      value: "1",
      label: "珠海",
    },
    {
      value: "2",
      label: "深圳",
    },
  ];

  // 下拉选择-地区---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };

  //修改--提交按钮
  const onReviseBtn = (values: any) => {
    console.log("提交的数据:", values);
  };

  // 点击禁用按钮
  const forbiddenjx = (record: any) => {
    return () => {
      console.log(record.key); // hello
      console.log("点击了禁用");
    };
  };

  // 表格删除按钮
  const deletejx = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key); // hello
      // console.log
    };
  };

  // 点击X关闭
  const handleCancel = () => {
    setUpdajx(false);
  };

  // 表格修改物流按钮
  const uploadjx = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record); // hello
      setUpdajx(true);
      // console.log
    };
  };

  return (
    <div>
      {/* 邮件模板管理 */}
      <div className="wl_Box">
        <div className="wl_headerBox">
          <div className="wl_headerBox_thread"></div>
          <div className="wl_headerBox_Tit">
            &nbsp;&nbsp;&nbsp;物流运费模板配置
          </div>
          <div className="wl_Add_moban">添加运费模板</div>
        </div>

        <div className="wl_tableBox">
          {/* scroll={{ x: 'max-content', y: 170 }}  */}
          <Table columns={columns} dataSource={data} />
        </div>
        {/* 邮箱配置内容编辑 */}
        <Modal
          className="wlUploadCont"
          footer={[null]}
          open={isUpdajx}
          onCancel={handleCancel}
        >
          <div className="wl_headerBox">
            <div className="wl_headerBox_thread"></div>
            <div className="wl_headerBox_Tit">&nbsp;&nbsp;&nbsp;运费模板</div>
          </div>
          <div className="wlUploadCont_Box">
            <Form
              name="basic"
              labelCol={{ span: 6 }}
              wrapperCol={{ span: 18 }}
              style={{ maxWidth: 600 }}
              initialValues={{ remember: true }}
              onFinish={onReviseBtn}
              autoComplete="off"
            >
              <Form.Item label="模板编码" name="templateCode1">
                <Input placeholder="例如：TM*****,TM0001" />
              </Form.Item>

              <Form.Item label="地区" name="area">
                <Select
                  labelInValue
                  style={{ width: 120 }}
                  onChange={handleChange1}
                  options={options1}
                />
              </Form.Item>

              <Form.Item label="物流运费设置" name="mailboxTemplateContent1">
                <TextArea rows={4} placeholder="例如：统一运费8元" />
              </Form.Item>

              <Form.Item label="是否启用" name="disabledOrNot1">
                <Radio.Group>
                  <Radio value="启用"> 启用 </Radio>
                  <Radio value="禁用"> 禁用 </Radio>
                </Radio.Group>
              </Form.Item>

              <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                <Button
                  className="wl_btn"
                  size="middle"
                  type="primary"
                  htmlType="submit"
                >
                  提交
                </Button>
              </Form.Item>
            </Form>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default LogisticsFreightTemplate;
