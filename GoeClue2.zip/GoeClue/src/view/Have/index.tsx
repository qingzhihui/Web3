import React, { useState, useEffect } from "react";
import { Progress } from "antd";
import { useHistory } from "react-router-dom";
import { ethers } from "ethers";
import axios from "axios";
import {
  playerNFT_ADDRESS,
  playerNFT_ABI,
} from "../../redux/Contract/playerNFTContract";
import "./Have.scss";

declare const window: Window & { ethereum: any };

const Index = () => {
  const [userNume, setuserNume] = useState(100);
  const [puisne, setPuisne] = useState(false);
  const [puisne2, setPuisne2] = useState(false);
  const [puisne3, setPuisne3] = useState(false);
  const [address, setWalletAccount] = useState("");
  // 盲h
  const [Urlbein, setUrlbein] = useState([]);
  // nft
  const [Srlbein, setSrlbein] = useState([]);
  let history = useHistory();
  const PsioemCLikc = () => {
    setPuisne(!puisne);
  };
  const PsioemCLikc2 = () => {
    setPuisne2(!puisne2);
  };
  const PsioemCLikc3 = () => {
    setPuisne3(!puisne3);
  };
  const CunserHide = () => {
    history.push("/Court");
  };
  const HaveMoheSHow = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addres = await signer.getAddress();
    const playerNFTContract = new ethers.Contract(
      playerNFT_ADDRESS,
      playerNFT_ABI,
      signer
    );
    const getUserAllUnRevealedNFT = await playerNFTContract.getUserAllUnRevealedNFT(addres);
    const getUnrevealedNFTAmount = await playerNFTContract.getUnrevealedNFTAmount(addres);
    if (getUnrevealedNFTAmount.toString() !== "0") {
      var prData = getUserAllUnRevealedNFT.toString().split(",");
      const OwnedNFT: any = [];
      prData.map(async (item: any) => {
        const unrevealNFTURI = await playerNFTContract.tokenURI(item);
        axios.get(unrevealNFTURI).then(function (response) {
          const nftNueir: Object = {
            tokenID: Number(item.toString()),
            url:
              "https://ipfs.youwant.io/ipfs/" +
              response.data.image.substr(7, 65),
          };
          OwnedNFT.push(nftNueir);
        });
      });
      setTimeout(() => {
        let _OwnedNFT = JSON.parse(JSON.stringify(OwnedNFT));
        setUrlbein((a: any) => {
          return OwnedNFT.length === 0 ? a : _OwnedNFT;
        });
      }, 300);
    }
  };
  const HaveNfteSHow = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addres = await signer.getAddress();
    const playerNFTContract = new ethers.Contract(
      playerNFT_ADDRESS,
      playerNFT_ABI,
      signer
    );
    const getUserAllRevealedNFT = await playerNFTContract.getUserAllRevealedNFT(addres);
    const getRevealedNFTAmount = await playerNFTContract.getRevealedNFTAmount(addres);
    if (getRevealedNFTAmount.toString() !== "0") {
      var bftData = getUserAllRevealedNFT.toString().split(",");
      const OwnedNFTdate: any = [];
      bftData.map(async (item: any) => {
        const revealNFTURI = await playerNFTContract.tokenURI(item);
        axios.get(revealNFTURI).then(function (response) {
          const nfER = response.data.attributes;
          const nftNueir: Object = {
            tokenID: Number(item.toString()),
            url:
              "https://ipfs.youwant.io/ipfs/" +
              response.data.image.substr(7, 65),
            name: nfER[0].value,
            level: nfER[1].value,
            rarity: nfER[2].value,
            talent: nfER[3].value,
            physique: nfER[4].value,
            attack: nfER[5].value,
            defense: nfER[6].value,
          };
          OwnedNFTdate.push(nftNueir);
        });
      });
      setTimeout(() => {
        let _OwnedNFTdate = JSON.parse(JSON.stringify(OwnedNFTdate));
        setSrlbein((a: any) => {
          return OwnedNFTdate.length === 0 ? a : _OwnedNFTdate;
        });
      }, 300);
    }
  };
  const OpenonClick = async (tokenId: number) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const playerNFTContract = new ethers.Contract(
      playerNFT_ADDRESS,
      playerNFT_ABI,
      signer
    );
    const revealNFT = await playerNFTContract.revealNFT(tokenId);
    await revealNFT.wait();
    HaveMoheSHow();
    HaveNfteSHow();
  };
  useEffect(() => {
    const address = localStorage.getItem("Cone_addr");
    if (address !== null && address !== undefined) {
      setWalletAccount(address);
      HaveMoheSHow();
      HaveNfteSHow();
    } else {
      setWalletAccount("");
    }
  }, []);
  return (
    <div className="Have">
      <div className="HaveNro">
        <div className="HaveNro_title">
          <button
            onClick={() => {
              CunserHide();
            }}
          >
            返回
          </button>
          <div className="pisnuimg">Have</div>
        </div>
        <div className="HaveNro_item">
          <div className="HaveNro_item_title">My Stadium</div>
          <div
            className={[`HaveNro_item_tinro ${puisne ? "puisne1" : ""}`].join(
              ""
            )}
          >
            <div className="item_tinro_nri">
              <div className="item_tinro_IMG">
                <img src={require("../../assets/image/s1.png")} alt="" />
              </div>
              <div className="item_tin_duer">
                <Progress
                  strokeColor={{
                    "0%": "#29f49a",
                    "100%": "#15d8e5",
                  }}
                  percent={100}
                  size="small"
                  format={(percent) => (
                    <div className="pertile">{`${percent}/${userNume}`}</div>
                  )}
                />
              </div>
              <div className="Receive">
                <button>Receive</button>
              </div>
            </div>
            <div className="item_tinro_nri">
              <div className="item_tinro_IMG">
                <img src={require("../../assets/image/s1.png")} alt="" />
              </div>
              <div className="item_tin_duer">
                <Progress
                  strokeColor={{
                    "0%": "#29f49a",
                    "100%": "#15d8e5",
                  }}
                  percent={30}
                  size="small"
                  format={(percent) => (
                    <div className="pertile">{`${percent}/${userNume}`}</div>
                  )}
                />
              </div>
              <div className="Receive">
                <button>Receive</button>
              </div>
            </div>
            <div className="item_tinro_nri">
              <div className="item_tinro_IMG">
                <img src={require("../../assets/image/s1.png")} alt="" />
              </div>
              <div className="item_tin_duer">
                <Progress
                  percent={30}
                  strokeColor={{
                    "0%": "#29f49a",
                    "100%": "#15d8e5",
                  }}
                  size="small"
                  format={(percent) => (
                    <div className="pertile">{`${percent}/${userNume}`}</div>
                  )}
                />
              </div>
              <div className="Receive">
                <button>Receive</button>
              </div>
            </div>
            <div className="item_tinro_nri">
              <div className="item_tinro_IMG">
                <img src={require("../../assets/image/s1.png")} alt="" />
              </div>
              <div className="item_tin_duer">
                <Progress
                  percent={30}
                  strokeColor={{
                    "0%": "#29f49a",
                    "100%": "#15d8e5",
                  }}
                  size="small"
                  format={(percent) => (
                    <div className="pertile">{`${percent}/${userNume}`}</div>
                  )}
                />
              </div>
              <div className="Receive">
                <button>Receive</button>
              </div>
            </div>
          </div>
          <div className="HaveNro_item_footer">
            <div
              onClick={() => {
                PsioemCLikc();
              }}
            >
              Details
            </div>
          </div>
        </div>
        <div className="HaveNro_item">
          <div className="HaveNro_item_title">My Player</div>
          <div
            className={[`HaveNro_item_tinro ${puisne2 ? "puisne1" : ""}`].join(
              ""
            )}
          >
            {Srlbein.map((item: any) => (
              <div className="item_tinro_nri2" key={item.tokenID}>
                <div className="item_tinro_IMG">
                  <img src={item.url} alt="" />
                </div>
              </div>
            ))}
          </div>
          <div className="HaveNro_item_footer">
            <div
              onClick={() => {
                PsioemCLikc2();
              }}
            >
              Details
            </div>
          </div>
        </div>
        <div className="HaveNro_item">
          <div className="HaveNro_item_title">My Blind box</div>
          <div
            className={[`HaveNro_item_tinro ${puisne3 ? "puisne2" : ""}`].join(
              ""
            )}
          >
            {Urlbein.map((item: any) => (
              <div className="item_tinro_nri3" key={item.tokenID}>
                <div className="item_tinro_IMG">
                  <img src={item.url} alt="" />
                  <div className="item_tinro_apor">
                    <div className="tinro_apor_input">
                      <input type="text" placeholder="address...." />
                    </div>
                    <div className="tinro_apor_iboutt">
                      <button
                        onClick={() => {
                          OpenonClick(item.tokenID);
                        }}
                      >
                        Open
                      </button>
                      <button>Transfer</button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="HaveNro_item_footer">
            <div
              onClick={() => {
                PsioemCLikc3();
              }}
            >
              Details
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
