// pages/VisageMeet/VisageMeet.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    paymentlist: [
      {
        "name": "Group61",
        "id": 0
      }, {
        "name": "Group62",
        "id": 1
      }, {
        "name": "Amex",
        "id": 2
      }, {
        "name": "Group63",
        "id": 3
      }, {
        "name": "Group64",
        "id": 4
      }, {
        "name": "Group65",
        "id": 5
      }, {
        "name": "Group66",
        "id": 6
      }, {
        "name": "Group67",
        "id": 7
      }
    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  CaerShowShow(){
    wx.navigateTo({
      url: '../CarEntry/CarEntry'
    })
  },
  VisageSelectShow(){
    wx.navigateTo({
      url: '../VisageSuccess/VisageSuccess'
    })
  },

  changePayMethod: function (e: any) {
    this.setData({
      selectpaymethodId: e.currentTarget.dataset.id
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})