import { Button, Form, Input } from 'antd';
import "./index.css";

// 数据库配置界面
const DatabaseConfigurationPage = () => {
    const submitData = (values: any) => {
        console.log('提交的数据:', values);
    };

    const onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };
    return (
        <div className='sql_Box'>
            <div className='sql_headerBox'>
                <div className='sql_headerBox_thread'></div>
                <div className='sql_headerBox_Tit'>&nbsp;&nbsp;&nbsp;数据库配置</div>
            </div>
            <div className='sql_inputBox'>
                <Form
                    name="basic"
                    labelCol={{ span: 5 }}
                    wrapperCol={{ span: 18 }}
                    style={{ maxWidth: 600 }}
                    initialValues={{ remember: true }}
                    onFinish={submitData}
                    onFinishFailed={onFinishFailed}
                    autoComplete="off"
                >
                    <Form.Item label="数据库地址" name="databaseAddress">
                        <Input placeholder="请输入数据库地址" />
                    </Form.Item>
                    <Form.Item label="数据库名称" name="databaseName">
                        <Input placeholder="请输入数据库名称!" />
                    </Form.Item>
                    <Form.Item label="用户名" name="username">
                        <Input placeholder="请输入用户名!" />
                    </Form.Item>
                    <Form.Item label="密码" name="password">
                        <Input.Password placeholder="请输入密码!" />
                    </Form.Item>
                    <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                        <Button className='sql_btn' size="middle" type="primary" htmlType="submit">提交</Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    )

}

export default DatabaseConfigurationPage;