<template>
  <div class="container">
    <div class="carousel">
      <div class="item">
        <a href="">
          <img src="../assets/img1.jpg" alt="">
        </a>
      </div>
      <div class="item">
        <a href="">
          <img src="../assets/img2.jpg" alt="">
        </a>
      </div>
      <div class="item">
        <a href="">
          <img src="../assets/img1.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="indicator">
      <span class="active"></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>
</template>

<script setup lang="ts">

var doms = {
  carouselList: document.querySelector('.carousel-list'),
  arrowLeft: document.querySelector('.arrow-left'),
  arrowRight: document.querySelector('.arrow-right'),
  indicators: document.querySelector('.indicator span')
}

function moveTo(index) {
  doms.carouselList.style.transform = `translateX(-${index}%)`;
  doms.carouselList.style.transition = '0.5s';
//  去掉指示器的选中效果
  var active = document.querySelector('.indicator span.active');
  active.classList.remove('active')
//  添加选中的指示器
  doms.indicators[index].carouselList.add('active')
  //给指示器添加事件
  dome.indicators.forEach(function (item, i) {
    item.onclick = function () {
      moveTo(i);
    }
  })
}

function init() {
//  复制第一张图片
  var first = doms.carouselList.firstElementChild.cloneNode(true)
//  复制最后一张图片
  var last = doms.carouselList.lastElementChild.cloneNode(true)
//  将第一张图片放到末尾
  doms.carouselList.appendChild(first);
//  将最后一张图片放到开头
  doms.carouselList.insertBefore(last, doms.carouselList.firstElementChild)
}

init()
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.container {
  width: 500px;
  height: 300px;
  margin: 10px auto;
  overflow: hidden;
  position: relative;
}

.container .carousel img {
  width: 500px;
  height: 300px;
}

.carousel {
  width: 100%;
  height: 100%;
  display: flex;
  transition: 0.5s;
}

.indicator {
  position: absolute;
  bottom: 10px;
  display: flex;
  left: 50%;
  transform: translateX(-50%);
}

.indicator span {
  width: 20px;
  height: 20px;
  border: 2px solid #ccc;
  border-radius: 50%;
}

.indicator span.active {
  background: #fff;
  border-color: #fff;
}

</style>
