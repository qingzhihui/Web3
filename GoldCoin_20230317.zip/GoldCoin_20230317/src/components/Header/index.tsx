import React, { useState, useEffect } from "react";
import "./index.scss";
import { ethers } from "ethers";
import { Button, Dropdown, Menu, Space } from "antd";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import Loge from "../../assets/logo3.png";
import math from "../../assets/meth.png";
import type { MenuProps } from "antd";
import toke from "../../assets/token.png";
import i18n from "../../i18n";

declare const window: Window & { ethereum: any };

function Index() {
  let history = useHistory();
  const [loShow, setloShow] = useState(false);
  const [address, setAddress] = useState("");
  const [Balance, setBalance] = useState("");
  const { t } = useTranslation();
  const Biens = (key: any) => {
    history.push(key);
  };
  const LoshowDe = () => {
    setloShow(!loShow);
  };

  // 切换网络
  const MetamShow = async () => {
    const provider = window.ethereum;
    const chainId = await provider.request({ method: "eth_chainId" });
    const binanceTestChainId = "0x38";
    if (chainId === binanceTestChainId) {
      Metaddr();
    } else {
      try {
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: binanceTestChainId }],
        });
        console.log("You have succefully switched to ethereum main network");
        Metaddr();
      } catch (switchError: any) {
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              // params: [
              //   {
              //     chainId: "0x4",
              //     chainName: "Rinkeby - Testnet",
              //     nativeCurrency: {
              //       name: "Rinkeby",
              //       symbol: "RIN",
              //       decimals: 18,
              //     },
              //     blockExplorerUrls: ["https://rinkeby.etherscan.io/"],
              //     rpcUrls: [
              //       "https://rinkeby.infura.io/v3/55d040fb60064deaa7acc8e320d99bd4/",
              //     ],
              //   },
              // ],
              params: [
                {
                  chainId: "0x38",
                  chainName: "Binance Smart Chain Mainnet",
                  nativeCurrency: {
                    name: "Binance Coin",
                    symbol: "BNB",
                    decimals: 18,
                  },
                  blockExplorerUrls: ["https://bscscan.com"],
                  rpcUrls: ["https://bsc-dataseed1.binance.org"],
                },
              ],
            });
          } catch (addError) {
            console.error(addError);
          }
        }
        console.log("Failed to switch to the network");
      }
    }
  };
  const Metaddr = async () => {
    if (typeof window.ethereum !== "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const addr = await signer.getAddress();
      setAddress(addr);
      localStorage.setItem("addr", addr);
      const bal = await provider.getBalance(addr);
      setBalance(ethers.utils.formatEther(bal));
      setloShow(false);
    } else {
      console.log("Please install metamask.");
    }
  };
  const BlseiHide = () => {
    window.localStorage.clear();
    setAddress("");
  };
  useEffect(() => {
    const addr = localStorage.getItem("addr");
    if (addr !== null) {
      setAddress(addr);
    }
    (window as any).ethereum.on(
      "accountsChanged",
      async function (accounts: any) {
        setAddress(accounts[0]);
        localStorage.setItem("addr", accounts[0]);
      }
    );
  }, [address]);
  return (
    <>
      <div className="Hader">
        <div className="nsuerHder">
          <div className="Hder_left">
            <img src={Loge} alt="" />
          </div>
          <div className="Hder_reft">
            <div className="NBsuerp">
              {address !== "" ? (
                <div className="Realsibu">
                  <div className="noelue">
                    <span>
                      {address.substring(0, 4) +
                        "..." +
                        address.substring(38, 42)}
                    </span>
                  </div>
                  <div>
                    <div
                      className="bsuein"
                      onClick={() => {
                        BlseiHide();
                      }}
                    >
                      {`${t("Exit")}`}
                    </div>
                  </div>
                </div>
              ) : (
                <Button onClick={() => LoshowDe()}>{`${t(
                  "Connect Wallet"
                )}`}</Button>
              )}
            </div>
          </div>
        </div>
      </div>
      {loShow ? (
        <div className="Chusekn">
          <div className="cuidne" onClick={() => LoshowDe()}></div>
          <div className="nruber">
            <div className="nruber_title">
              <img src={Loge} alt="" />
              {/* <div className="siesuf">FISTDAO V2</div> */}
              <div className="gubei" onClick={() => LoshowDe()}>
                {/* <img src={gbi} alt="" /> */}X
              </div>
            </div>
            <div className="Buseklis">
              <div className="klis_item" onClick={() => MetamShow()}>
                <div className="lisimg">
                  <img src={toke} alt="" />
                </div>
                <div>TokenPocket</div>
              </div>
              <div className="klis_item" onClick={() => MetamShow()}>
                <div className="lisimg">
                  <img src={math} alt="" />
                </div>
                <div>Metamask</div>
              </div>
              {/* <div className="klis_item">
                <div className="lisimg">
                  <img src={wall} alt="" />
                </div>
                <div>WalletConnect</div>
              </div> */}
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  );
}

export default Index;
