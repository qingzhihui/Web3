import { useEffect, useState } from "react";
import "./index.scss";
import { ethers } from "ethers";
import {
  teamNFT_ADDRESS,
  teamNFT_ABI,
} from "../../redux/Contract/teamNFTContract.js";
import {
  playerNFT_ADDRESS,
  playerNFT_ABI,
} from "../../redux/Contract/playerNFTContract";
import {
  CloseCircleOutlined,
  PlusCircleOutlined,
  RedoOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";
import loge from "../../assets/image/soccer6.png";
import prin from "../../constants/index";
import luiere from "../../constants/Game";
import { useHistory } from "react-router-dom";
declare const window: Window & { ethereum: any };

const Game = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalQundu, setIsModalQundu] = useState(false);
  const [pbuse, setpbuse] = useState(true);
  const [nuber, setNuber] = useState("");
  const [pnserItem, setPnserItem] = useState(luiere);
  const [address, setWalletAccount] = useState("");
  const [nudate, setNudate] = useState([]);
  const [prdate, setPrdate] = useState([]);
  const [serdate, setSerdate] = useState({});
  const [isTimese, setisTimese] = useState(false);
  const [oreTime, setoreTime] = useState({
    gontime: "",
    oreTime: 1,
  });
  const [uprNumer, setuprNumer] = useState(0);
  let history = useHistory();

  const showModal = (num: string) => {
    setIsModalOpen(true);
    setNuber(num);
  };
  const showHide = () => {
    setIsModalOpen(false);
  };
  const showHide2 = () => {
    setIsModalQundu(false);
  };
  const ItemONcline = () => {
    history.push("/Details");
  };
  const CurluHide = () => {
    history.push("/Court");
  };
  const handtelmShowper = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const adres = await signer.getAddress();
    const teamNFTContract = new ethers.Contract(
      teamNFT_ADDRESS,
      teamNFT_ABI,
      signer
    );
    const getAllOwnedNFT = await teamNFTContract.getAllOwnedNFT(adres);
    const getDesignatedTeamsInfo = await teamNFTContract.getDesignatedTeamsInfo(
      getAllOwnedNFT
    );
    const Temadate: any = [];
    const baseURI = await teamNFTContract.baseURI();
    getDesignatedTeamsInfo.map(async (item: any) => {
      const nftNueir: Object = {
        tokeid: Number(item[0].toString()),
        name: item[1],
        pndata: item[3].toString(),
        url:
          "https://ipfs.youwant.io/ipfs/" +
          baseURI.substr(7, 50) +
          item[2].toString() +
          ".png",
      };
      Temadate.push(nftNueir);
    });
    setTimeout(() => {
      let _OwnedTem = JSON.parse(JSON.stringify(Temadate));
      setPrdate((a: any) => {
        return Temadate.length === 0 ? a : _OwnedTem;
      });
    }, 300);
  };
  const QuinerOnclik = (item: any) => {
    // console.log((pnserItem.proue as ));

    // prin[Number(nuber)]
    setPnserItem((prevState) => {
      return { ...prevState, [prin[Number(nuber)]]: item };
    });
    setIsModalOpen(false);
  };
  const handGameShoe = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const adres = await signer.getAddress();
    const teamContract = new ethers.Contract(
      teamNFT_ADDRESS,
      teamNFT_ABI,
      signer
    );
    const playerNFTContract = new ethers.Contract(
      playerNFT_ADDRESS,
      playerNFT_ABI,
      signer
    );
    const getTotalIdlePlayer = await teamContract.getTotalIdlePlayer(adres);
    const getDesignatedPlayersInfo =
      await playerNFTContract.getDesignatedPlayersInfo(getTotalIdlePlayer);
    const Nftdate: any = [];
    const baseURI = await playerNFTContract.baseURI();
    getDesignatedPlayersInfo.map(async (item: any) => {
      const getPlayerIntegratedData =
        await playerNFTContract.getPlayerIntegratedData(item[0].toString());
      const battleStatus = await teamContract.battleStatus(
        Number(item[0].toString())
      );
      const nftNueir: Object = {
        tokeid: Number(item[0].toString()),
        name: item[1],
        Integra: getPlayerIntegratedData.toString(),
        url:
          "https://ipfs.youwant.io/ipfs/" +
          baseURI.substr(7, 50) +
          item[1] +
          "_" +
          item[3] +
          ".png",
        level: item[2],
        rarity: item[3],
        talent: item[4].toString(),
        physique: item[5].toString(),
        attack: item[6].toString(),
        defense: item[7].toString(),
        show: battleStatus,
      };
      Nftdate.push(nftNueir);
    });
    setTimeout(() => {
      let _OwnedNFT = JSON.parse(JSON.stringify(Nftdate));
      setNudate((a: any) => {
        return Nftdate.length === 0 ? a : _OwnedNFT;
      });
    }, 300);
  };
  const GameBaochun = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const teamContract = new ethers.Contract(
        teamNFT_ADDRESS,
        teamNFT_ABI,
        signer
      );
      const Arrdate: any = [];
      const oiuser = Object.values(pnserItem);
      for (let index = 0; index < 11; index++) {
        Arrdate.push((oiuser[index] as any).tokeid);
      }
      const peridate = Arrdate.filter((mes: any) => {
        return mes !== undefined;
      });
      const setLineup = await teamContract.setLineup(
        (serdate as any).tokeid,
        peridate
      );
      setoreTime({ gontime: "保存中", oreTime: 1 });
      setisTimese(true);
      await setLineup.wait();
      setoreTime({ gontime: "保存成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "保存失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const SerdateOnclik = async (date: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const teamContract = new ethers.Contract(
      teamNFT_ADDRESS,
      teamNFT_ABI,
      signer
    );
    const getTeamLineUp = await teamContract.getTeamLineUp(date.tokeid);
    const playerNFTContract = new ethers.Contract(
      playerNFT_ADDRESS,
      playerNFT_ABI,
      signer
    );
    const Qunper: any = [];
    const getDesignatedPlayersInfo =
      await playerNFTContract.getDesignatedPlayersInfo(getTeamLineUp);
    const baseURI = await playerNFTContract.baseURI();
    getDesignatedPlayersInfo.map(async (item: any) => {
      const getPlayerIntegratedData =
        await playerNFTContract.getPlayerIntegratedData(item[0].toString());
      const battleStatus = await teamContract.battleStatus(
        Number(item[0].toString())
      );
      const Qunpeir: Object = {
        tokeid: Number(item[0].toString()),
        name: item[1],
        Integra: getPlayerIntegratedData.toString(),
        url:
          "https://ipfs.youwant.io/ipfs/" +
          baseURI.substr(7, 50) +
          item[1] +
          "_" +
          item[3] +
          ".png",
        level: item[2],
        rarity: item[3],
        talent: item[4].toString(),
        physique: item[5].toString(),
        attack: item[6].toString(),
        defense: item[7].toString(),
        show: battleStatus,
      };
      Qunper.push(Qunpeir);
    });
    setTimeout(() => {
      const Qdata = {
        ItemOne: Qunper[0] || {},
        ItemTwo: Qunper[1] || {},
        ItemThree: Qunper[2] || {},
        ItemFour: Qunper[3] || {},
        ItemFive: Qunper[4] || {},
        ItemSix: Qunper[5] || {},
        ItemSeven: Qunper[6] || {},
        ItemEight: Qunper[7] || {},
        ItemNine: Qunper[8] || {},
        ItemTen: Qunper[9] || {},
        ItemEleven: Qunper[10] || {},
      };
      let _Qdata = JSON.parse(JSON.stringify(Qdata));
      setPnserItem((a: any) => {
        return Qunper.length === 0 ? a : _Qdata;
      });
      const Numdate: any = [];
      Qunper.map((item: any) => {
        Numdate.push(Number(item.Integra));
      });
      if (Numdate.length === 0) {
        setuprNumer(0);
      } else {
        const sum: number = Numdate.reduce((x: number, y: number) => x + y);
        setuprNumer(sum);
      }
      setSerdate(date);
      setIsModalQundu(false);
    }, 800);
  };
  const pionserOnclick = async (Qid: any, numer: any) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const teamContract = new ethers.Contract(
        teamNFT_ADDRESS,
        teamNFT_ABI,
        signer
      );
      const romovePlayer = await teamContract.romovePlayer(
        (serdate as any).tokeid,
        Qid
      );
      setoreTime({ gontime: "卸下中", oreTime: 1 });
      setisTimese(true);
      await romovePlayer.wait();
      setoreTime({ gontime: "卸下成功", oreTime: 2 });
      setisTimese(true);
      const nurie: any = pnserItem;
      const lkuier = uprNumer - Number(nurie[numer].Integra);
      nurie[numer] = {};
      setPnserItem(nurie);
      setTimeout(() => {
        setuprNumer(lkuier);
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "卸下失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const GamePlius = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const teamContract = new ethers.Contract(
        teamNFT_ADDRESS,
        teamNFT_ABI,
        signer
      );
      const clearFormerLineUp = await teamContract.clearFormerLineUp(
        (serdate as any).tokeid
      );
      setoreTime({ gontime: "卸下中", oreTime: 1 });
      setisTimese(true);
      await clearFormerLineUp.wait();
      setoreTime({ gontime: "卸下成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
      setPnserItem(luiere);
      setuprNumer(0);
    } catch (error) {
      setoreTime({ gontime: "卸下失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  useEffect(() => {
    const address = localStorage.getItem("Cone_addr");
    if (address !== null && address !== undefined) {
      setWalletAccount(address);
      handGameShoe();
      handtelmShowper();
    } else {
      setWalletAccount("");
    }
  }, [pnserItem, nuber, uprNumer]);

  return (
    <div className="Game">
      <div className="Gamrisr">
        <div className="Game_cender">
          <div className="Game_cender_tiole">
            <div className="cender_tiole_left">
              {(pnserItem.ItemOne as any).tokeid == undefined ? (
                <img
                  className="img1"
                  src={require("../../assets/image/LI.png")}
                  alt=""
                  onClick={() => {
                    showModal("0");
                  }}
                />
              ) : (
                <>
                  <img
                    className="img1"
                    src={(pnserItem.ItemOne as any).url}
                    alt=""
                    onClick={() => {
                      showModal("0");
                    }}
                  />
                  <div className="puiben">
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemOne as any).attack} ATT
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemOne as any).physique} PHY
                      </div>
                    </div>
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemOne as any).talent} TAL
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemOne as any).defense} DEF
                      </div>
                    </div>
                  </div>
                  <div className="puiben2">
                    {(pnserItem.ItemOne as any).Integra} /{" "}
                    {(pnserItem.ItemOne as any).tokeid}
                  </div>
                  {(pnserItem.ItemOne as any).show == true ? (
                    <div className="plsuieber">
                      <button
                        onClick={() => {
                          pionserOnclick(
                            (pnserItem.ItemOne as any).tokeid,
                            "ItemOne"
                          );
                        }}
                      >
                        卸下
                      </button>
                    </div>
                  ) : (
                    ""
                  )}
                </>
              )}
            </div>
            <div className="cender_tiole_const">
              {(pnserItem.ItemTwo as any).tokeid == undefined ? (
                <img
                  className="img1"
                  src={require("../../assets/image/LI.png")}
                  alt=""
                  onClick={() => {
                    showModal("1");
                  }}
                />
              ) : (
                <>
                  <img
                    className="img1"
                    src={(pnserItem.ItemTwo as any).url}
                    alt=""
                    onClick={() => {
                      showModal("1");
                    }}
                  />
                  <div className="puiben">
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemTwo as any).attack} ATT
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemTwo as any).physique} PHY
                      </div>
                    </div>
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemTwo as any).talent} TAL
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemTwo as any).defense} DEF
                      </div>
                    </div>
                  </div>
                  <div className="puiben2">
                    {(pnserItem.ItemTwo as any).Integra} /{" "}
                    {(pnserItem.ItemTwo as any).tokeid}
                  </div>
                  {(pnserItem.ItemTwo as any).show == true ? (
                    <div className="plsuieber">
                      <button
                        onClick={() => {
                          pionserOnclick(
                            (pnserItem.ItemTwo as any).tokeid,
                            "ItemTwo"
                          );
                        }}
                      >
                        卸下
                      </button>
                    </div>
                  ) : (
                    ""
                  )}
                </>
              )}
            </div>
            <div className="cender_tiole_reft">
              {(pnserItem.ItemThree as any).tokeid == undefined ? (
                <img
                  className="img1"
                  src={require("../../assets/image/LI.png")}
                  alt=""
                  onClick={() => {
                    showModal("2");
                  }}
                />
              ) : (
                <>
                  <img
                    className="img1"
                    src={(pnserItem.ItemThree as any).url}
                    alt=""
                    onClick={() => {
                      showModal("2");
                    }}
                  />
                  <div className="puiben">
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemThree as any).attack} ATT
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemThree as any).physique} PHY
                      </div>
                    </div>
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemThree as any).talent} TAL
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemThree as any).defense} DEF
                      </div>
                    </div>
                  </div>
                  <div className="puiben2">
                    {(pnserItem.ItemThree as any).Integra} /{" "}
                    {(pnserItem.ItemThree as any).tokeid}
                  </div>
                  {(pnserItem.ItemThree as any).show == true ? (
                    <div className="plsuieber">
                      <button
                        onClick={() => {
                          pionserOnclick(
                            (pnserItem.ItemThree as any).tokeid,
                            "ItemThree"
                          );
                        }}
                      >
                        卸下
                      </button>
                    </div>
                  ) : (
                    ""
                  )}
                </>
              )}
            </div>
          </div>
          <div className="Game_cender_tiole2">
            <div className="sperioser">
              <div className="cender_tiole_left2">
                {(pnserItem.ItemFour as any).tokeid == undefined ? (
                  <img
                    className="img1"
                    src={require("../../assets/image/LI.png")}
                    alt=""
                    onClick={() => {
                      showModal("3");
                    }}
                  />
                ) : (
                  <>
                    <img
                      className="img1"
                      src={(pnserItem.ItemFour as any).url}
                      alt=""
                      onClick={() => {
                        showModal("3");
                      }}
                    />
                    <div className="puiben">
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemFour as any).attack} ATT
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemFour as any).physique} PHY
                        </div>
                      </div>
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemFour as any).talent} TAL
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemFour as any).defense} DEF
                        </div>
                      </div>
                    </div>
                    <div className="puiben2">
                      {(pnserItem.ItemFour as any).Integra} /{" "}
                      {(pnserItem.ItemFour as any).tokeid}
                    </div>
                    {(pnserItem.ItemFour as any).show == true ? (
                      <div className="plsuieber">
                        <button
                          onClick={() => {
                            pionserOnclick(
                              (pnserItem.ItemFour as any).tokeid,
                              "ItemFour"
                            );
                          }}
                        >
                          卸下
                        </button>
                      </div>
                    ) : (
                      ""
                    )}
                  </>
                )}
              </div>
              <div className="cender_tiole_const2">
                {(pnserItem.ItemFive as any).tokeid == undefined ? (
                  <img
                    className="img1"
                    src={require("../../assets/image/LI.png")}
                    alt=""
                    onClick={() => {
                      showModal("4");
                    }}
                  />
                ) : (
                  <>
                    <img
                      className="img1"
                      src={(pnserItem.ItemFive as any).url}
                      alt=""
                      onClick={() => {
                        showModal("4");
                      }}
                    />
                    <div className="puiben">
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemFive as any).attack} ATT
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemFive as any).physique} PHY
                        </div>
                      </div>
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemFive as any).talent} TAL
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemFive as any).defense} DEF
                        </div>
                      </div>
                    </div>
                    <div className="puiben2">
                      {(pnserItem.ItemFive as any).Integra} /{" "}
                      {(pnserItem.ItemFive as any).tokeid}
                    </div>
                    {(pnserItem.ItemFive as any).show == true ? (
                      <div className="plsuieber">
                        <button
                          onClick={() => {
                            pionserOnclick(
                              (pnserItem.ItemFive as any).tokeid,
                              "ItemFive"
                            );
                          }}
                        >
                          卸下
                        </button>
                      </div>
                    ) : (
                      ""
                    )}
                  </>
                )}
              </div>
              <div className="cender_tiole_reft2">
                {(pnserItem.ItemSix as any).tokeid == undefined ? (
                  <img
                    className="img1"
                    src={require("../../assets/image/LI.png")}
                    alt=""
                    onClick={() => {
                      showModal("5");
                    }}
                  />
                ) : (
                  <>
                    <img
                      className="img1"
                      src={(pnserItem.ItemSix as any).url}
                      alt=""
                      onClick={() => {
                        showModal("5");
                      }}
                    />
                    <div className="puiben">
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemSix as any).attack} ATT
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemSix as any).physique} PHY
                        </div>
                      </div>
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemSix as any).talent} TAL
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemSix as any).defense} DEF
                        </div>
                      </div>
                    </div>
                    <div className="puiben2">
                      {(pnserItem.ItemSix as any).Integra} /{" "}
                      {(pnserItem.ItemSix as any).tokeid}
                    </div>
                    {(pnserItem.ItemSix as any).show == true ? (
                      <div className="plsuieber">
                        <button
                          onClick={() => {
                            pionserOnclick(
                              (pnserItem.ItemSix as any).tokeid,
                              "ItemSix"
                            );
                          }}
                        >
                          卸下
                        </button>
                      </div>
                    ) : (
                      ""
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
          <div className="Game_cender_tiole3">
            <div className="cender_tiole_left3">
              {(pnserItem.ItemSeven as any).tokeid == undefined ? (
                <img
                  className="img1"
                  src={require("../../assets/image/LI.png")}
                  alt=""
                  onClick={() => {
                    showModal("6");
                  }}
                />
              ) : (
                <>
                  <img
                    className="img1"
                    src={(pnserItem.ItemSeven as any).url}
                    alt=""
                    onClick={() => {
                      showModal("6");
                    }}
                  />
                  <div className="puiben">
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemSeven as any).attack} ATT
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemSeven as any).physique} PHY
                      </div>
                    </div>
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemSeven as any).talent} TAL
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemSeven as any).defense} DEF
                      </div>
                    </div>
                  </div>
                  <div className="puiben2">
                    {(pnserItem.ItemSeven as any).Integra} /{" "}
                    {(pnserItem.ItemSeven as any).tokeid}
                  </div>
                  {(pnserItem.ItemSeven as any).show == true ? (
                    <div className="plsuieber">
                      <button
                        onClick={() => {
                          pionserOnclick(
                            (pnserItem.ItemSeven as any).tokeid,
                            "ItemSeven"
                          );
                        }}
                      >
                        卸下
                      </button>
                    </div>
                  ) : (
                    ""
                  )}
                </>
              )}
            </div>
            <div className="cender_tiole_const3">
              {(pnserItem.ItemEight as any).tokeid == undefined ? (
                <img
                  className="img1"
                  src={require("../../assets/image/LI.png")}
                  alt=""
                  onClick={() => {
                    showModal("7");
                  }}
                />
              ) : (
                <>
                  <img
                    className="img1"
                    src={(pnserItem.ItemEight as any).url}
                    alt=""
                    onClick={() => {
                      showModal("7");
                    }}
                  />
                  <div className="puiben">
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemEight as any).attack} ATT
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemEight as any).physique} PHY
                      </div>
                    </div>
                    <div className="soeite">
                      <div className="soeite_item">
                        {(pnserItem.ItemEight as any).talent} TAL
                      </div>
                      <div className="soeite_item">
                        {(pnserItem.ItemEight as any).defense} DEF
                      </div>
                    </div>
                  </div>
                  <div className="puiben2">
                    {(pnserItem.ItemEight as any).Integra} /{" "}
                    {(pnserItem.ItemEight as any).tokeid}
                  </div>
                  {(pnserItem.ItemEight as any).show == true ? (
                    <div className="plsuieber">
                      <button
                        onClick={() => {
                          pionserOnclick(
                            (pnserItem.ItemEight as any).tokeid,
                            "ItemEight"
                          );
                        }}
                      >
                        卸下
                      </button>
                    </div>
                  ) : (
                    ""
                  )}
                </>
              )}
            </div>
          </div>
          <div className="Game_cender_tiole4">
            <div className="sperioser2">
              <div className="cender_tiole_left4">
                {(pnserItem.ItemNine as any).tokeid == undefined ? (
                  <img
                    className="img1"
                    src={require("../../assets/image/LI.png")}
                    alt=""
                    onClick={() => {
                      showModal("8");
                    }}
                  />
                ) : (
                  <>
                    <img
                      className="img1"
                      src={(pnserItem.ItemNine as any).url}
                      alt=""
                      onClick={() => {
                        showModal("8");
                      }}
                    />
                    <div className="puiben">
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemNine as any).attack} ATT
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemNine as any).physique} PHY
                        </div>
                      </div>
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemNine as any).talent} TAL
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemNine as any).defense} DEF
                        </div>
                      </div>
                    </div>
                    <div className="puiben2">
                      {(pnserItem.ItemNine as any).Integra} /{" "}
                      {(pnserItem.ItemNine as any).tokeid}
                    </div>
                    {(pnserItem.ItemNine as any).show == true ? (
                      <div className="plsuieber">
                        <button
                          onClick={() => {
                            pionserOnclick(
                              (pnserItem.ItemNine as any).tokeid,
                              "ItemNine"
                            );
                          }}
                        >
                          卸下
                        </button>
                      </div>
                    ) : (
                      ""
                    )}
                  </>
                )}
              </div>
              <div className="cender_tiole_const4">
                {(pnserItem.ItemTen as any).tokeid == undefined ? (
                  <img
                    className="img1"
                    src={require("../../assets/image/LI.png")}
                    alt=""
                    onClick={() => {
                      showModal("9");
                    }}
                  />
                ) : (
                  <>
                    <img
                      className="img1"
                      src={(pnserItem.ItemTen as any).url}
                      alt=""
                      onClick={() => {
                        showModal("9");
                      }}
                    />
                    <div className="puiben">
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemTen as any).attack} ATT
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemTen as any).physique} PHY
                        </div>
                      </div>
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemTen as any).talent} TAL
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemTen as any).defense} DEF
                        </div>
                      </div>
                    </div>
                    <div className="puiben2">
                      {(pnserItem.ItemTen as any).Integra} /{" "}
                      {(pnserItem.ItemTen as any).tokeid}
                    </div>
                    {(pnserItem.ItemTen as any).show == true ? (
                      <div className="plsuieber">
                        <button
                          onClick={() => {
                            pionserOnclick(
                              (pnserItem.ItemTen as any).tokeid,
                              "ItemTen"
                            );
                          }}
                        >
                          卸下
                        </button>
                      </div>
                    ) : (
                      ""
                    )}
                  </>
                )}
              </div>
              <div className="cender_tiole_reft4">
                {(pnserItem.ItemEleven as any).tokeid == undefined ? (
                  <img
                    className="img1"
                    src={require("../../assets/image/LI.png")}
                    alt=""
                    onClick={() => {
                      showModal("10");
                    }}
                  />
                ) : (
                  <>
                    <img
                      className="img1"
                      src={(pnserItem.ItemEleven as any).url}
                      alt=""
                      onClick={() => {
                        showModal("10");
                      }}
                    />
                    <div className="puiben">
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemEleven as any).attack} ATT
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemEleven as any).physique} PHY
                        </div>
                      </div>
                      <div className="soeite">
                        <div className="soeite_item">
                          {(pnserItem.ItemEleven as any).talent} TAL
                        </div>
                        <div className="soeite_item">
                          {(pnserItem.ItemEleven as any).defense} DEF
                        </div>
                      </div>
                    </div>
                    <div className="puiben2">
                      {(pnserItem.ItemEleven as any).Integra} /{" "}
                      {(pnserItem.ItemEleven as any).tokeid}
                    </div>
                    {(pnserItem.ItemEleven as any).show == true ? (
                      <div className="plsuieber">
                        <button
                          onClick={() => {
                            pionserOnclick(
                              (pnserItem.ItemEleven as any).tokeid,
                              "ItemEleven"
                            );
                          }}
                        >
                          卸下
                        </button>
                      </div>
                    ) : (
                      ""
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
          <div
            className="zhangkia"
            onClick={() => {
              setpbuse(false);
            }}
          >
            <PlusCircleOutlined style={{ fontSize: "33px", color: "#fff" }} />
          </div>
        </div>
        <div className={[`Game_left ${pbuse ? "acione" : ""}`].join("")}>
          <div
            className="busienr"
            onClick={() => {
              setpbuse(true);
            }}
          ></div>
          <div className="wnsuiiern">
            <div className="Game_title">
              <div
                className="Game_loget"
                onClick={() => {
                  setIsModalQundu(true);
                }}
              >
                {(serdate as any).tokeid === undefined ? (
                  <img src={loge} alt="" />
                ) : (
                  <img src={(serdate as any).url} alt="" />
                )}
              </div>
              <div className="Game_loget_nro">
                战斗力：
                {(serdate as any).tokeid == undefined ? "0" : uprNumer}
              </div>
            </div>
            <div className="Game_nsuer">
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("0");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemOne as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemOne as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("1");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemTwo as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemTwo as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("2");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemThree as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemThree as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("3");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemFour as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemFour as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("4");
                }}
              >
                {" "}
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemFive as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemFive as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("5");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemSix as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemSix as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("6");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemSeven as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemSeven as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("7");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemEight as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemEight as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("8");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemNine as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemNine as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("9");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemTen as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemTen as any).Integra}
                    </div>
                  )}
                </div>
              </div>
              <div
                className="Game_nsuer_item"
                onClick={() => {
                  showModal("10");
                }}
              >
                <div className="itemPoser">
                  <div className="itemPoser_left">
                    <img
                      src={require("../../assets/image/Frame2.png")}
                      alt=""
                    />
                  </div>
                  {(pnserItem.ItemEleven as any).Integra === undefined ? (
                    <div className="itemPoser_reft">
                      <img
                        src={require("../../assets/image/Frame4345.png")}
                        alt=""
                      />
                    </div>
                  ) : (
                    <div className="prooins">
                      <img src={require("../../assets/image/pk.png")} alt="" />
                      {(pnserItem.ItemEleven as any).Integra}
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="Game_footer">
              <div className="Game_footer_nusior">
                <button
                  onClick={() => {
                    CurluHide();
                  }}
                >
                  返回
                </button>
              </div>
              <div className="Game_footer_nusior">
                <button
                  onClick={() => {
                    GamePlius();
                  }}
                >
                  一键卸下
                </button>
              </div>
              <div className="Game_footer_nusior">
                <button
                  onClick={() => {
                    GameBaochun();
                  }}
                >
                  一键保存
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* 选择 */}
      {isModalOpen ? (
        <div className="psershow">
          <div
            className="pserzhes"
            onClick={() => {
              showHide();
            }}
          ></div>
          <div className="pserNro">
            <div className="nusiero">
              <div className="gbNiuero">
                {nudate.map((item: any, index: any) => (
                  <div className="gbNiuero_item" key={index}>
                    <div
                      className="gbNiuero_item_img"
                      onClick={() => {
                        ItemONcline();
                      }}
                    >
                      <img src={item.url} alt="" />
                      <div className="oluernr">
                        <div className="soeite">
                          <div className="soeite_item">{item.attack} ATT</div>
                          <div className="soeite_item">{item.physique} PHY</div>
                        </div>
                        <div className="soeite">
                          <div className="soeite_item">{item.talent} TAL</div>
                          <div className="soeite_item">{item.defense} DEF</div>
                        </div>
                      </div>
                      <div className="oluernr2">
                        {item.Integra} / {item.tokeid}
                      </div>
                    </div>
                    <div className="gbNibout">
                      <button
                        onClick={() => {
                          QuinerOnclik(item);
                        }}
                      >
                        装备
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <div
                className="gbuieng"
                onClick={() => {
                  showHide();
                }}
              >
                <CloseCircleOutlined
                  style={{
                    color: "#000",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      {/* 选择球队 */}
      {isModalQundu ? (
        <div className="psershow2">
          <div
            className="pserzhes"
            onClick={() => {
              showHide2();
            }}
          ></div>
          <div className="pserNro">
            <div className="nusiero">
              <div className="gbNiuero">
                {prdate.map((item: any, index: any) => (
                  <div
                    className="gbNiuero_item_or"
                    key={index}
                    onClick={() => {
                      SerdateOnclik(item);
                    }}
                  >
                    <div className="gbNiuero_itLeft">
                      <img src={item.url} alt="" />
                    </div>
                    <div className="gbNiuero_itruke">
                      <div className="itruke_til"> 名字：{item.name}</div>
                      <div> 战斗力：{item.pndata}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div
                className="gbuieng"
                onClick={() => {
                  showHide2();
                }}
              >
                <CloseCircleOutlined
                  style={{
                    color: "#ffff",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      {/* 提示 */}
      {isTimese ? (
        <div className="pserExbuse">
          <div className="pserzhes"></div>
          <div className="pserTise">
            <div className="pserExchange_nro">
              <div className="nriopsr">
                <div className="logding">
                  {(oreTime as any).oreTime === 1 ? (
                    <RedoOutlined spin className="Luiisnr" />
                  ) : (oreTime as any).oreTime === 2 ? (
                    <CheckCircleOutlined className="Luiisnr" />
                  ) : (
                    <CloseCircleOutlined className="Luiisnr" />
                  )}
                </div>
                <div className="Ptimeb">{(oreTime as any).gontime}</div>
              </div>
              <div
                className="gbuiengkum"
                onClick={() => {
                  showHide2();
                }}
              >
                <CloseCircleOutlined
                  style={{
                    color: "#ffff",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </div>
  );
};

export default Game;
