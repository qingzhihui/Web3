import {
  UserOutlined,
  CaretDownOutlined,
  PoweroffOutlined,
} from "@ant-design/icons";
import type { MenuProps } from "antd";
import { Dropdown, Space } from "antd";
import { useNavigate } from "react-router-dom";
import "./index.scss";

const Header = () => {
  const navigate = useNavigate();
  const items: MenuProps["items"] = [
    {
      key: "1",
      label: "a danger item1",
    },
    {
      key: "2",
      label: "a danger item2",
    },
    {
      key: "3",
      label: "a danger item3",
    },
  ];
  const HeaderLogelin = () => {
    console.log("123");
    navigate("/Login", {
      state: {},
    });
  };
  return (
    <div className="Header">
      <div className="HeaderPeoose">
        <div className="HeaderPeooseLengt">
          <div className="HeaderPeooseLengtIcone">
            <UserOutlined style={{ fontSize: "18px", color: "#000" }} />
          </div>
          <div className="HeaderPeooseRengthText">
            <span>hhhhhhhh（小程序管理员）</span>
            <Dropdown
              menu={{ items }}
              arrow={{ pointAtCenter: true }}
              placement="bottomRight"
            >
              <div className="" onClick={(e) => e.preventDefault()}>
                <CaretDownOutlined
                  style={{ fontSize: "16px", color: "#000" }}
                />
              </div>
            </Dropdown>
          </div>
        </div>
        <div
          className="HeaderPeooseRents"
          onClick={() => {
            HeaderLogelin();
          }}
        >
          <PoweroffOutlined
            style={{ fontSize: "21px", color: "#000", cursor: "pointer" }}
          />
        </div>
      </div>
    </div>
  );
};

export default Header;
