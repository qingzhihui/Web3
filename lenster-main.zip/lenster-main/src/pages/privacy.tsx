import Privacy from '@components/Pages/Privacy'

export default Privacy
