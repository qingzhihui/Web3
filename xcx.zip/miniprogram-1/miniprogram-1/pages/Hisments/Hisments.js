import api from '../../config/api'
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    start: 0,
    current: 0,
    startTouch: '',
    startNum: '0',
    videoList: [],
    touch: false,
    touchStartTime: 0, //触摸开始时间
    touchEndTime: 0, // 触摸结束时间
    touchEbutn: "下一题",
    show: "",
    setea: 0,



    // 数据
    radio: '0',
    activeNames: ['0'],
    activeNames2: ['0'],
    show2: false,
    show3: false,
    show4: false,

    // 案例笔记
    anid: "",
    value: "",
    message4: "",
    Chadata: [],

    // 佐证
    // 二级
    uestionnaireTwoId: "",
    // 选项id
    optionTableId: "",
    // 佐证内容
    message: "",
    // 用户id
    adminId: '',
    // 题目id
    subjectId: "",
    // 添加的id
    musid: "",
    radio3: '',


    // 确认自评信息
    radio2: '',
    message2: "",
    quetitle: "",
    queName: '',

    message3: "",
    message4: "",
    dinping: false,
    bohueo: false,
    show4: false,
    value: "",
    // 展示用户信息
    Beinlist: {},
    // 下级ID
    ShauserId: "",
    // 确认无异
    lisneID: '',
    // 问卷ID
    Qusersid: "",
    // 团队ID
    TeamId: "",
    dufelns: [],
    BueleList: [],
    lustr: false,
    questireTwoId: "",
    tmuid: "",
    Dvalue: "",
    touchShow: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      adminId: options.userId,
      TeamId: options.teamId,
      ShauserId: options.xiaID,
      Qusersid: options.qusersid,
      Dvalue: options.quarter
    })
    var that = this;
    var listTem = that.data.videoList;
    for (var i = 0; i < listTem.length; i++) {
      var arr = (listTem[i].quickProjectWorkerTagName).split(',')
      listTem[i].tagnamesArr = arr;
    }

    // 是否到做题时间
    api._get(`ums/umsQuestionnaireHistory/selectCheck/${options.qusersid}`).then(res => {
      console.log(res);
      if (res.data == 1) {
        this.setData({
          beishow: false
        })
      } else {
        this.setData({
          beishow: true
        })
        Toast.fail('还未到做题时间！');
      }
    }).catch(e => {
      console.log(e);
    })


    // 查询所有题目
    api._get(`ums/umsQuestionnaire/questionnaireList?param=3&id=${options.qusersid}&flag=1&teamId=${options.teamId}&userId=${options.userId}`).then(res => {
      console.log(res);
      const Buele = [];
      res.data[0].umsOptionTables.map((msg) => {
        if (msg.identification == true) {
          Buele.push(msg.score);
        }
      })
      that.setData({
        videoList: res.data,
        ShauserId: options.xiaID,
        TeamId: options.teamId,
        BueleList: Buele
      })
      const bueid = res.data[this.data.current].id;
      const Buelesbuei = [];
      res.data[this.data.current].umsOptionTables.map((msg) => {
        if (msg.identification == true) {
          Buelesbuei.push(msg.score);
        }
      })
      api._get(`ums/umsEvidence/selectEvidence/${options.teamId}/${bueid}/${options.userId}/${this.data.ShauserId}`).then(res => {
        if (res.data == null) {
          this.setData({
            radio: '0',
            message: "",
            anid: "",
            value: "",
            message4: "",
            BueleList: Buelesbuei,
            beinse: 0
          })
        } else {
          this.setData({
            radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
            message: res.data.content,
            musid: res.data.id,
            BueleList: Buelesbuei,
            message4: "",
            anid: "",
            value: "",
            beinse: 1,
            radio3: String(res.data.status),
            message3: res.data.comment,
          })
          if (res.data.status == 1) {
            this.setData({
              dinping: true,
              bohueo: false
            })
          } else if (res.data.status == 2) {
            this.setData({
              bohueo: true,
              dinping: false,
            })
          } else {
            this.setData({
              bohueo: false,
              dinping: false,
            })
          }
        }
      }).catch(e => {
        console.log(e);
      })
    }).catch(e => {
      console.log(e);
    })
    // 展示用户信息
    api._get(`ums/umsQuestionnaire/getUserAssessmentInformation/${options.xiaID}/${options.qusersid}/${options.teamId}`).then(res => {
      this.setData({
        Beinlist: res.data
      })
    }).catch(e => {
      console.log(e);
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.videoContext = wx.createVideoContext('videoplayer');
    this.setData({
      updateState: true
    })
  },
  onClose() {
    this.setData({
      show: false
    });
  },
  onCloseShow(e) {
    var that = this;
    api._get(`ums/umsEvidence/selectEvidenceInfo/${this.data.TeamId}/${e.currentTarget.dataset.id}/${that.data.ShauserId}`).then(res => {
      this.setData({
        radio2: res.data[0].score,
        message2: res.data[0].content,
        quetitle: res.data[0].questionnaireName,
        queName: res.data[0].subjectName,
        lisneID: res.data[0].id,
        dufelns: res.data[0].fractions,
        questireTwoId: e.currentTarget.dataset.item,
        tmuid: e.currentTarget.dataset.id
      })
    }).catch(e => {
      console.log(e);
    })
    this.setData({
      show: true
    });

  },
  onChange4(e) {
    this.setData({
      radio2: e
    })
  },
  onChange3(event) {
    if ((event.detail == 1)) {
      setTimeout(() => {
        this.setData({
          radio3: event.detail,
          dinping: true,
          bohueo: false
        });
      }, 300)
    } else {
      setTimeout(() => {
        this.setData({
          radio3: event.detail,
          bohueo: true,
          dinping: false,
        });
      }, 300)
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  // 下面主要模仿滑动事件
  touchstart: function (e) {
    this.setData({
      touchStartTime: e.timeStamp,
      showGuide: false
    })
    let startTouch = e.changedTouches[0]
    this.setData({
      startTouch: startTouch,
      touch: false
    })
  },
  touchmove: function (e) {
    let Y = e.changedTouches[0].pageY - this.data.startTouch.pageY;
  },
  touchend: function (e) {
    this.setData({
      touchEndTime: e.timeStamp
    })
    this.getDirect(this.data.startTouch, e.changedTouches[0]);
  },
  touchcancel: function (e) {
    this.getDirect(this.data.startTouch, e.changedTouches[0])
  },
  // 计算滑动方向
  getDirect: function (start, end) {
    var X = end.pageX - start.pageX,
      Y = end.pageY - start.pageY;
    if (Math.abs(X) > Math.abs(Y) && X > 0) {} else if (Math.abs(X) > Math.abs(Y) && X < 0) {} else if (Math.abs(Y) > Math.abs(X) && Y > 40) {
      if (this.data.current > 0) {
        this.setData({
          touch: true,
          transitionOver: false
        })
        this.pre()
      } else {
        this.setData({
          current: 0
        })
      }
    } else if (Math.abs(Y) > Math.abs(X) && Y < -40) {
      if (this.data.current < this.data.videoList.length - 2) {
        this.setData({
          touch: true
        })
        this.next()
      } else {
        var startNum = parseInt(this.data.startNum) + 5;
        this.setData({
          current: this.data.videoList.length - 1
        })
        const Buele = [];
        this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
          if (msg.identification == true) {
            Buele.push(msg.score);
          }
        })
        const bueid = this.data.videoList[this.data.current].id;
        const adingList = wx.getStorageSync('admin')
        api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${adingList.userId}/${this.data.ShauserId}`).then(res => {
          if (res.data == null) {
            this.setData({
              startNum: startNum,
              touchEbutn: "到低了",
              message: "",
              radio3: "",
              bohueo: false,
              dinping: false,
              beinse: 0,
              BueleList: Buele,
              message3: '',
              touchShow: false,
              setea: 0
            })
          } else {
            this.setData({
              radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
              message: res.data.content,
              musid: res.data.id,
              radio3: String(res.data.status),
              message3: res.data.comment,
              BueleList: Buele,
              beinse: 1,
              touchShow: false,
              touchEbutn: "到低了",
              setea: 1
            })
            if (res.data.status == 1) {
              this.setData({
                dinping: true,
                bohueo: false
              })
            } else if (res.data.status == 2) {
              this.setData({
                bohueo: true,
                dinping: false,
              })
            } else {
              this.setData({
                bohueo: false,
                dinping: false,
              })
            }
          }
        }).catch(e => {
          console.log(e);
        })

      }
    }
  },

  // 播放上一个
  pre: function () {
    this.setData({
      current: this.data.current - 1,
      touchEbutn: "下一题",
      touchShow: true
    })
    const Buele = [];
    this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
      if (msg.identification == true) {
        Buele.push(msg.score);
      }
    })
    const bueid = this.data.videoList[this.data.current].id;
    api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.adminId}/${this.data.ShauserId}`).then(res => {
      console.log(res.data);
      if (res.data == null) {
        this.setData({
          radio: '0',
          message: "",
          anid: "",
          value: "",
          message4: "",
          message3: "",
          radio3: "0",
          bohueo: false,
          dinping: false,
          setea: 0,
          BueleList: Buele,
          beinse: 0
        })
      } else {
        this.setData({
          radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
          message: res.data.content,
          musid: res.data.id,
          radio3: String(res.data.status),
          message3: res.data.comment,
          BueleList: Buele,
          beinse: 1
        })
        if (res.data.status == 1) {
          this.setData({
            dinping: true,
            bohueo: false
          })
        } else if (res.data.status == 2) {
          this.setData({
            bohueo: true,
            dinping: false,
          })
        } else {
          this.setData({
            bohueo: false,
            dinping: false,
          })
        }
      }

    }).catch(e => {
      console.log(e);
    })
  },
  // 播放下一个
  next: function () {
    console.log('播放洗一个')
    this.setData({
      current: this.data.current + 1,
    })
    const Buele = [];
    this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
      if (msg.identification == true) {
        Buele.push(msg.score);
      }
    })
    const bueid = this.data.videoList[this.data.current].id;
    api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.adminId}/${this.data.ShauserId}`).then(res => {
      console.log(res)
      if (res.data == null) {
        this.setData({
          radio: '0',
          message: "",
          anid: "",
          value: "",
          message4: "",
          message3: "",
          radio3: "0",
          bohueo: false,
          dinping: false,
          setea: 0,
          BueleList: Buele,
          beinse: 0
        })
      } else {
        this.setData({
          radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
          message: res.data.content,
          musid: res.data.id,
          radio3: String(res.data.status),
          message3: res.data.comment,
          BueleList: Buele,
          beinse: 1,
          setea: 1
        })
        if (res.data.status == 1) {
          this.setData({
            dinping: true,
            bohueo: false
          })
        } else if (res.data.status == 2) {
          this.setData({
            bohueo: true,
            dinping: false,
          })
        } else {
          this.setData({
            bohueo: false,
            dinping: false,
          })
        }
      }

    }).catch(e => {
      console.log(e);
    })
  },

  snsdkue(param) {
    this.setData({
      touch: true,
    })
    if (this.data.radio !== '0') {
      if (this.data.beinse == 1) {
        if (this.data.current < this.data.videoList.length - 2) {
          this.next()
        } else {
          var startNum = parseInt(this.data.startNum) + 5;
          this.setData({
            current: this.data.videoList.length - 1
          })
          const Buele = [];
          this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
            if (msg.identification == true) {
              Buele.push(msg.score);
            }
          })
          const bueid = this.data.videoList[this.data.current].id;
          api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.adminId}/${this.data.ShauserId}`).then(res => {
            console.log(res);
            if (res.data == null) {
              this.setData({
                startNum: startNum,
                touchEbutn: "到低了",
                message: "",
                setea: 0,
                touchShow: false,
                radio3: '0',
                message3: '',
                bohueo: false,
                dinping: false,
                beinse: 0,
                BueleList: Buele,
              })
            } else {
              console.log(Buele);
              this.setData({
                radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
                message: res.data.content,
                musid: res.data.id,
                radio3: String(res.data.status),
                message3: res.data.comment,
                BueleList: Buele,
                beinse: 1,
                touchShow: false,
                touchEbutn: "到低了",
                setea: 1
              })
              if (res.data.status == 1) {
                this.setData({
                  dinping: true,
                  bohueo: false
                })
              } else if (res.data.status == 2) {
                this.setData({
                  bohueo: true,
                  dinping: false,
                })
              } else {
                this.setData({
                  bohueo: false,
                  dinping: false,
                })
              }
            }
          }).catch(e => {
            console.log(e);
          })
        }
      } else {
        const LInse = {
          questionnaireId: this.data.Qusersid,
          questionnaireTwoId: this.data.uestionnaireTwoId,
          optionTableId: this.data.optionTableId,
          content: this.data.message,
          adminId: this.data.adminId,
          subjectId: this.data.subjectId,
          target: this.data.ShauserId,
          teamId: this.data.TeamId
        }
        // 判断该题是不是需要作证的，如果需要就要判断内容是否为空
        const arr = param.currentTarget.dataset.index
        let value = this.data.radio.split(',')[0]
        let status = false;
        arr.map(m => {
          if (m == value) {
            status = true
          }
        })
        if (status) {
          if (LInse.content == '' || LInse.content == null) {
            Toast.fail('该题必须输入作证内容');
            return;
          }
        }
        api._post('ums/umsEvidence/addEvidenceHe', LInse).then(res => {
          console.log(res);
          if (res.code == 500) {
            Toast.fail(res.message);
          } else {
            if (res.data.submissionStatus == 1) {
              const LInse = {
                questionnaireId: this.data.Qusersid,
                questionnaireTwoId: this.data.uestionnaireTwoId,
                optionTableId: this.data.optionTableId,
                content: this.data.message,
                adminId: this.data.adminId,
                subjectId: this.data.subjectId,
                target: this.data.ShauserId,
                teamId: this.data.TeamId
              }
              api._post('ums/umsEvidence/addEvidenceHe', LInse).then(res => {
                api._get(`ums/umsEvidence/selectEvidenceCount/${this.data.ShauserId}/${this.data.adminId}/${this.data.Qusersid}/${this.data.TeamId}`).then(res => {
                  if (res.code == 250) {
                    Toast.fail('存在驳回');
                    var pages = getCurrentPages();
                    var beforePage = pages[pages.length - 2];
                    wx.navigateBack({
                      url: '../Descrion/Descrion',
                      success: function () {
                        beforePage.GetAddressList();
                      }
                    })
                  } else if (res.code == 252) {
                    Toast.fail('有待完成题目');
                    api._get(`ums/umsEvidence/checkSubject/${this.data.Qusersid}/${this.data.ShauserId}/${this.data.TeamId}/${2}`).then(res => {
                      console.log(res);
                      this.data.videoList.map((item) => {
                        if (item.id == res.data[0].subjectId) {
                          console.log(res.data[0].subjectId);
                          this.setData({
                            current: this.data.videoList.indexOf(item),
                            beinse: 0,
                            message: "",
                            radio3: '',
                            message3: '',
                            bohueo: false,
                            dinping: false,
                          })
                        }
                      })
                    }).catch(e => {
                      console.log(e);
                    })
                  } else {
                    wx.navigateTo({
                      url: `../Reports/Reports?id=${this.data.Qusersid}&tid=${this.data.ShauserId}&zid=${this.data.TeamId}`
                    })
                  }
                })

              }).catch(e => {
                console.log(e)
              })
            } else {
              if (this.data.current < this.data.videoList.length - 2) {
                this.next()
              } else {
                var startNum = parseInt(this.data.startNum) + 5;
                this.setData({
                  current: this.data.videoList.length - 1
                })
                const Buele = [];
                this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
                  if (msg.identification == true) {
                    Buele.push(msg.score);
                  }
                })
                const bueid = this.data.videoList[this.data.current].id;
                api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.adminId}/${this.data.ShauserId}`).then(res => {
                  if (res.data == null) {
                    this.setData({
                      startNum: startNum,
                      touchEbutn: "到低了",
                      message: "",
                      setea: 0,
                      touchShow: false,
                      radio3: '0',
                      message3: '',
                      bohueo: false,
                      dinping: false,
                      beinse: 0,
                      BueleList: Buele,
                    })
                  } else {
                    this.setData({
                      radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
                      message: res.data.content,
                      musid: res.data.id,
                      radio3: String(res.data.status),
                      message3: res.data.comment,
                      BueleList: Buele,
                      beinse: 1,
                      touchShow: false,
                      touchEbutn: "到低了",
                      setea: 1
                    })
                    if (res.data.status == 1) {
                      this.setData({
                        dinping: true,
                        bohueo: false
                      })
                    } else if (res.data.status == 2) {
                      this.setData({
                        bohueo: true,
                        dinping: false,
                      })
                    } else {
                      this.setData({
                        bohueo: false,
                        dinping: false,
                      })
                    }
                  }

                }).catch(e => {
                  console.log(e)
                })
              }
            }
          }
        })
      }
    } else {
      if (this.data.current < this.data.videoList.length - 2) {
        this.next()
      } else {
        var startNum = parseInt(this.data.startNum) + 5;
        this.setData({
          current: this.data.videoList.length - 1
        })
        const Buele = [];
        this.data.videoList[this.data.current].umsOptionTables.map((msg) => {
          if (msg.identification == true) {
            Buele.push(msg.score);
          }
        })
        this.setData({
          BueleList: Buele,
        })
        const bueid = this.data.videoList[this.data.current].id;
        api._get(`ums/umsEvidence/selectEvidence/${this.data.TeamId}/${bueid}/${this.data.adminId}/${this.data.ShauserId}`).then(res => {
          if (res.data == null) {
            this.setData({
              startNum: startNum,
              touchEbutn: "到低了",
              message: "",
              setea: 0,
              touchShow: false,
              beinse: 0,
              BueleList: Buele,
            })
          } else {
            this.setData({
              radio: `${String(res.data.score)},${String(res.data.optionTableId)}`,
              message: res.data.content,
              musid: res.data.id,
              radio3: String(res.data.status),
              message3: res.data.comment,
              BueleList: Buele,
              beinse: 1,
              touchShow: false,
              touchEbutn: "到低了",
              setea: 1
            })
            if (res.data.status == 1) {
              this.setData({
                dinping: true,
                bohueo: false
              })
            } else if (res.data.status == 2) {
              this.setData({
                bohueo: true,
                dinping: false,
              })
            } else {
              this.setData({
                bohueo: false,
                dinping: false,
              })
            }
          }
        }).catch(e => {
          console.log(e);
        })
      }
    }
  },
  // 佐证
  onChange(event) {
    this.setData({
      uestionnaireTwoId: event.currentTarget.dataset.item,
      subjectId: event.currentTarget.dataset.id,
      radio: event.currentTarget.dataset.id,
    })
    this.data.videoList.map((item) => {
      if (item.id == event.currentTarget.dataset.id) {
        item.umsOptionTables.map((msg) => {
          if (msg.id == parseInt(event.detail.split(',')[1])) {
            this.setData({
              optionTableId: event.detail.split(',')[1]
            })
            if (msg.identification == true) {
              setTimeout(() => {
                this.setData({
                  show2: true,
                  radio: event.detail,
                });
              }, 10)
            } else {
              this.setData({
                radio: event.detail.split(',')[0],
                show2: false,
              });
            }
          }
        })
      }
    })
  },
  onChange2(event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  onClickLeft() {
    var pages = getCurrentPages();
    var beforePage = pages[pages.length - 2];
    wx.navigateBack({
      url: `../Descrion/Descrion?id=${this.data.Qusersid}&quarter=${this.data.Dvalue}`,
      success: function () {
        beforePage.GetAddressList();
      }
    })
  },
  snTindex(param) {
    if (this.data.radio !== '0') {
      const LInse = {
        questionnaireId: this.data.Qusersid,
        questionnaireTwoId: this.data.uestionnaireTwoId,
        optionTableId: this.data.optionTableId,
        content: this.data.message,
        adminId: this.data.adminId,
        subjectId: this.data.subjectId,
        target: this.data.ShauserId,
        teamId: this.data.TeamId
      }
      // 判断该题是不是需要作证的，如果需要就要判断内容是否为空
      const arr = param.currentTarget.dataset.index
      let value = this.data.radio.split(',')[0]
      let status = false;
      arr.map(m => {
        if (m == value) {
          status = true
        }
      })
      if (status) {
        if (LInse.content == '' || LInse.content == null) {
          Toast.fail('该题必须输入作证内容');
          console.log(LInse.content);
          return;
        }
      }
      api._post('ums/umsEvidence/addEvidenceHe', LInse).then(res => {
        console.log(res);
        if (res.code == 500) {
          Toast.fail(res.message);
        } else {
          api._get(`ums/umsEvidence/selectEvidenceCount/${this.data.ShauserId}/${this.data.adminId}/${this.data.Qusersid}/${this.data.TeamId}`).then(res => {
            if (res.code == 250) {
              Toast.fail('存在驳回');
              var pages = getCurrentPages();
              var beforePage = pages[pages.length - 2];
              wx.navigateBack({
                url: '../Descrion/Descrion',
                success: function () {
                  beforePage.GetAddressList();
                }
              })
            } else if (res.code == 252) {
              Toast.fail('有待完成题目');
              api._get(`ums/umsEvidence/checkSubject/${this.data.Qusersid}/${this.data.ShauserId}/${this.data.TeamId}/${2}`).then(res => {
                console.log(res);
                this.data.videoList.map((item) => {
                  if (item.id == res.data[0].subjectId) {
                    console.log(res.data[0].subjectId);
                    this.setData({
                      current: this.data.videoList.indexOf(item),
                      beinse: 0,
                      message: "",
                      radio3: '',
                      message3: '',
                      bohueo: false,
                      dinping: false,
                    })
                  }
                })
              }).catch(e => {
                console.log(e);
              })
            } else {
              wx.navigateTo({
                url: `../Reports/Reports?id=${this.data.Qusersid}&tid=${this.data.ShauserId}&zid=${this.data.TeamId}`
              })
            }
          }).catch(e => {
            console.log(e);
          })
        }
      }).catch(e => {
        console.log(e)
      })
    } else {
      Toast.fail('请完成题目再提交！');
    }
  },
  onClose2() {
    this.setData({
      show2: false
    });
  },
  onChangeMessage(event) {
    this.setData({
      message: event.detail
    })
  },
  onChangeMessage3(event) {
    this.setData({
      message3: event.detail
    })
  },
  // 添加佐证
  onCloseZuo() {
    if (this.data.message == '') {
      Toast.fail('请输入佐证');
      this.setData({
        show2: true
      });
    } else {
      this.setData({
        show2: false
      });
    }
  },


  // },
  slieslCli() {
    this.setData({
      show3: true
    });
  },
  // 案例标题
  AnonChange(event) {
    this.setData({
      value: event.detail
    })
  },
  //  案例内容
  AnonChange2(event) {
    this.setData({
      message4: event.detail
    })
  },
  Anlishow(e) {
    console.log(e.currentTarget.dataset.id);
    this.setData({
      show3: true,
      anid: e.currentTarget.dataset.id
    });
  },
  onClose3() {
    this.setData({
      show3: false
    });
  },
  // 添加案例
  onClose3Dug(e) {
    const anList = {
      subjectId: this.data.anid,
      title: this.data.value,
      content: this.data.message4,
      adminId: this.data.adminId
    }
    // 他评案例笔记题目编号未传
    api._post('ums/umsCaseNotes/addCaseNote', anList).then(res => {
      this.setData({
        message4: "",
        value: ""
      })
    }).catch(e => {
      console.log(e)
    })
  },
  // 查询案例
  Anlshow4(e) {
    this.setData({
      show4: true
    })
    api._get(`ums/umsCaseNotes/selectCaseNoteById/${this.data.adminId}/${e.currentTarget.dataset.id}`).then(res => {
      const biem = [];
      res.data.map((item) => {
        item.createTime = item.createTime.split('T')[0]
        biem.push(item)
      })
      this.setData({
        Chadata: biem
      })
    }).catch(e => {
      console.log(e)
    })
    this.setData({
      show4: true
    })

  },
  onClose4() {
    this.setData({
      show3: false
    });
  },
  onChanges2(event) {
    this.setData({
      activeNames2: event.detail,
    });
  },
  LiTiao() {
    console.log(this.data.videoList[this.data.current].length);
    // this.setData({
    //   current: this.data.current + 1,
    // })
  },
  onTioan() {
    if (this.data.radio3 == 1) {
      api._put('ums/umsEvidence/updEvidence', {
        status: this.data.radio3,
        comment: this.data.message3,
        id: this.data.lisneID
      }).then(res => {
        Toast.fail(res.message);
        this.setData({
          setea: 1
        })
      }).catch(e => {
        console.log(e)
      })
    } else {
      api._post('ums/umsMessage/addMessage', {
        questionnaireId: this.data.Qusersid,
        questionnaireTwoId: this.data.questireTwoId,
        teamId: this.data.TeamId,
        adminId: this.data.adminId,
        message: this.data.message3,
        subjectId: this.data.tmuid,
        target: this.data.ShauserId,
      }).then(res => {
        if (res.code == 500) {
          Toast.fail(res.message);
        }
        this.setData({
          setea: 1
        })
      }).catch(e => {
        console.log(e)
      })
    }
  },
  // 引用案例
  Lisbeani() {
    this.data.Chadata.map((item) => {
      this.setData({
        message: item.content
      })
    })
  },
  onShareAppMessage() {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  }
})