import React, { forwardRef, useState } from "react";

const FancyInput = forwardRef((props, ref: any) => (
  <div>
    <input type="text" ref={ref} {...props} />
  </div>
));

const Index = () => {
  const [input, setInput] = useState("");
  const inputRef: any = React.createRef();

  const handleClick = () => {
    inputRef.current.focus();
    setInput((value) => (value = inputRef.current.value));
  };

  return (
    <div>
      <FancyInput ref={inputRef} />
      <div>{input}</div>
      <button onClick={handleClick}>Focus Input</button>
    </div>
  );
};

export default Index;
