interface Colorful2 {
  color: string;
}
interface Circle2 {
  redius: number;
}
type ColorfulCircle = Colorful2 & Circle2;

const df: ColorfulCircle = {
  color: "red",
  redius: 100,
};

// 匿名函数
function draw(circle: Colorful2 & Circle2) {
  console.log(circle.color);
  console.log(circle.redius);
}

draw({
  color: "red",
  redius: 100,
});
