import { useEffect, useState } from "react";
import { ethers } from "ethers";
// abi
import contract from "./utils/abi.json";
import Headerdev from "./components/Headerdev";
import "./App.scss";
import beimg from "./assets/1_06.png";
import Luenesdev from "./components/Luenesdev";

const contractAddress = "0x2ad4D70F1Ee587dE3bA479F4579d23594654ddb8";
const abi = contract.abi;

function App() {
  //#region
  // // 声明两个变量
  // const [data, setData] = useState("");
  // const [contract, setContract] = useState();

  // // 获取数据
  // const getData = async () => {
  //   const data = await contract.greet();
  //   setData(data);
  // };

  // // 更新数据
  // const updateData = async () => {
  //   const transaction = await contract.setGreeting(data);
  //   await transaction.wait();
  //   getData();
  // };
  // // 初始化连接函数
  // const initConnection = async () => {
  //   if (typeof window.ethereum !== "undefined") {
  //     await window.ethereum.request({ method: "eth_requestAccounts" });
  //     const provider = new ethers.providers.Web3Provider(window.ethereum);
  //     const signer = provider.getSigner();
  //     setContract(
  //       new ethers.Contract(
  //         "0x5FbDB2315678afecb367f032d93F642f64180aa3",
  //         Greeter.abi,
  //         signer
  //       )
  //     );
  //   } else {
  //     console.log("Please install metamask.");
  //   }
  // };
  // useEffect(() => {
  //   // initConnection();
  // });
  //#endregion
  const mint = async () => {
    try {
      const { ethereum } = window;
      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const nftContract = new ethers.Contract(contractAddress, abi, signer);
        console.log("Initialize payment");
        let nftTxn = await nftContract.mintNFTs(1, {
          value: ethers.utils.parseEther("0.0001"),
        });
        console.log("Wining... please wait");
        await nftTxn.wait();
        console.log(
          `Mined,see transaction:https://rinkeby.etherscan.io/tx/${nftTxn.hash}`
        );
      } else {
        console.log("Ethereum object does not exist");
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className="Contener">
      <div className="Aeader">
        <Headerdev />
      </div>
      <div className="Appming">
        <div className="slines">
          <span>EMOER</span>
        </div>
        <div className="bsunts">
          <button onClick={() => mint()}>MINT</button>
        </div>
      </div>
      <div className="tbiusi">
        <img src={beimg} />
      </div>
      <div className="LuList">
        <Luenesdev  />
      </div>
      {/* <button onClick={getData}>Get Data</button>
      <button onClick={updateData}>set Data</button>
      <input
        onChange={(e) => setData(e.target.value)}
        placeholder="Naw Greeting"
      />
      <p>{data}</p>*/}
    </div>
  );
}

export default App;
