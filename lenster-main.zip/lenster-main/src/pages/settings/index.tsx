import ProfileSettings from '@components/Settings/Profile'

export default ProfileSettings
