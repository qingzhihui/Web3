class Genericnumber<NumType> {
  zeroValue: NumType;
  add: (x: NumType, y: NumType) => NumType;
}

// let myGemeric = new Genericnumber<number>();
// myGemeric.zeroValue = 0;
// myGemeric.add = function (x, y) {
//   return x + y;
// };



let myGemeric = new Genericnumber<string>();
myGemeric.zeroValue = '';
myGemeric.add = function (x, y) {
  return x + y;
};