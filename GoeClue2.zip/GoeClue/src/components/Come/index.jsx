import React from "react";
import "./Come.scss";
function Come() {
  return (
    <div id="Come">
      <div className="come-contain">
        <div className="come-logo"></div>
        <div className="come-title">COMING SOON</div>
        <div className="come-subTitle">We will be here soon!</div>
        <div className="come-dsc">
          We are currently working on our website. <br/>We will be here soon. Click
          on the buton to be notified when our site is ready!
        </div>
        <ul className="links">
            <li className="link tw"></li>
            <li className="link tg"></li>
            <li className="link yt"></li>
        </ul>
      </div>
      <div className="u-p"></div>
    </div>
  );
}

export default Come;
