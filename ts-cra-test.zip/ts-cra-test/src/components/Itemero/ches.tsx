import React, { ReactElement, ReactNode } from "react";

interface IndexProps {
  items: any;
  render: any;
}
const Index: React.FC<IndexProps> = <ListItem extends {}>({
  items,
  render,
}: {
  items: ListItem[];
  render: (item: ListItem) => ReactNode;
}) => {
  return (
    <div>
      <ul>
        {items.map((item, index) => (
          <li key={index}>{render(item)}</li>
        ))}
      </ul>
    </div>
  );
};
