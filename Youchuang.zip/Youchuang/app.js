// app.js
import api from './config/api'
App({
  globalData: {
    statsuBarHeight:0,
    sysWidth:0,
    sysHeight:0,
  },
  onLaunch() {
    const res = wx.getSystemInfoSync()
    var statusbarH = res.statusBarHeight
    this.globalData.statsuBarHeight=statusbarH;
    this.globalData.sysWidth = res.screenWidth;
    this.globalData.sysHeight = res.screenHeight;
  },
})