import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Home from "../view/Home";
import Farm from "../view/Farm";
import IDO from "../view/IDO";
import Swap from "../view/Swap";
import Unity from "../view/Unity";

class indexRouter extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/Home" component={Home} />
          <Route path="/Farm" component={Farm} />
          <Route path="/IDO" component={IDO} />
          <Route path="/Swap" component={Swap} />
          <Route path="/Unity" component={Unity} />
          <Redirect from="/" to="/Home" />
        </Switch>
      </Router>
    );
  }
}

export default indexRouter;
