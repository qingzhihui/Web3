console.log('你好ts');

var str:string = "你好"

function getData(){
	return '你好'
}