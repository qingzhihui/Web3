import React from "react";
import "./index.scss";
import { useHistory } from "react-router-dom";
import shtiao from "../../assets/stiao.png";
import { Button, Modal } from "antd";

function Header() {
  let history = useHistory();
  const MenuList = [
    {
      key: "/Home",
      label: "HOME",
    },
    {
      key: "/Swap",
      label: "Swap",
    },
    {
      key: "/Farm",
      label: "Farm",
    },
    {
      key: "/IDO",
      label: "IDO",
    },
    {
      key: "/Unity",
      label: "Unity",
    },
  ];

  const onClickHeader = (MenuItem: any) => {
    history.push(MenuItem.key);
  };
  
  return (
    <div className="hebaise">
      <div className="heloge">
        <img src={shtiao} alt="" />
      </div>
      <div className="henudri">
        {MenuList.map((item: any, index: any) => (
          <div
            key={index}
            onClick={() => onClickHeader(item)}
            className="henitem"
          >
            <span>{item.label}</span>
          </div>
        ))}
      </div>
      <div className="hebarut">
        <Button type="primary">连接钱包</Button>
      </div>
    </div>
  );
}

export default Header;
