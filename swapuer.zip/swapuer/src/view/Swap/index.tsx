import React, { useEffect, useState } from "react";
import "./index.scss";
import Header from "../../components/Header";
import li1 from "../../assets/li1.png";
import li2 from "../../assets/li2.png";
import xusa from "../../assets/icons/xua.svg";
import { Button, Modal, Input } from "antd";
import { DollarCircleOutlined } from "@ant-design/icons";
import toKenList from "../../constants/token/token.json";

function Swap() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalOpen2, setIsModalOpen2] = useState(false);
  const [toList, setToList] = useState(toKenList.tokens);
  const [tokenone, setTokenOne] = useState({});
  const [tokentwe, setTokenTwo] = useState({});

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const showModal2 = () => {
    setIsModalOpen2(true);
  };

  const handleCancel2 = () => {
    setIsModalOpen2(false);
  };
  // 币1
  const BIenerOne = (addr: string, name: string, url: string) => {
    setTokenOne({
      addr: addr,
      name: name,
      url: url,
    });
    setIsModalOpen(false);
  };
  // 币2
  const BIenerTwo = (addr: string, name: string, url: string) => {
    setTokenTwo({
      addr: addr,
      name: name,
      url: url,
    });
    setIsModalOpen2(false);
  };
  useEffect(() => {
    const TolekenOne = toList.filter((item: any) => {
      return item.symbol == "WBNB";
    });
    const TolekenTwo = toList.filter((item: any) => {
      return item.symbol == "CAKE";
    });
    setTokenOne({
      addr: TolekenOne[0].address,
      name: TolekenOne[0].symbol,
      url: TolekenOne[0].logoURI,
    });
    setTokenTwo({
      addr: TolekenTwo[0].address,
      name: TolekenTwo[0].symbol,
      url: TolekenTwo[0].logoURI,
    });
  }, [toList]);
  return (
    <div className="busitm">
      <div className="mnsue"></div>
      <Header />
      <div className="busbuk">
        <div className="busnr">
          <div className="busnr_titl">
            <div className="busnr_biti">Exchange</div>
            <div className="busnr_nroi">Trade tokens in an instant</div>
            <div className="Busieru">
              <div className="icno1"></div>
              <div className="icno2"></div>
            </div>
          </div>
          <div className="busnr_nrop">
            <div className="nropFarm">
              <div className="nropFarm_titl">
                <div className="zioti" onClick={showModal}>
                  <div className="zitcon">
                    <img src={li1} alt="" />
                  </div>
                  <div>{(tokenone as any).name}</div>
                  <div className="xisods">
                    <img src={xusa} alt="" />
                  </div>
                </div>
                <div className="Yusenit">
                  <span>余额：</span>0.361271
                </div>
                <Modal
                  title="选择代币"
                  footer={null}
                  open={isModalOpen}
                  onCancel={handleCancel}
                  centered
                  width="460px"
                  bodyStyle={{
                    height: "100%",
                    width: "100%",
                  }}
                >
                  <div className="shanbi">
                    <div className="shuinput">
                      <Input placeholder="搜索名称或粘贴地址" />
                    </div>
                    <div className="shancyui">
                      <div className="shantilwe">常用代币</div>
                      <div className="shuielist">
                        <div className="ielitem">
                          <img src={li1} alt="" />
                          <div className="buinet">USDT</div>
                        </div>
                        <div className="ielitem">
                          <img src={li2} alt="" />
                          <div className="buinet">CAKE</div>
                        </div>
                      </div>
                    </div>
                    <div className="daibList">
                      {toList.map((item: any, index) => (
                        <div
                          className="tbuitem"
                          key={index}
                          onClick={() =>
                            BIenerOne(item.address, item.symbol, item.logoURI)
                          }
                        >
                          <div className="tbleu_tei">
                            <img src={item.logoURI} alt="" />
                          </div>
                          <div className="tbzh_ueni">
                            <div className="tbzh_Tile">{item.symbol}</div>
                            <div className="tbzh_Nro">{item.name}</div>
                          </div>
                          <div className="weiv_ubt">{item.buing}</div>
                        </div>
                      ))}
                    </div>
                    <div className="consbi">
                      <span>管理代币</span>
                      <DollarCircleOutlined />
                    </div>
                  </div>
                </Modal>
              </div>
              <div className="nropFarm_nro">
                <div className="nro_input">
                  <input placeholder="0.0" />
                </div>
                <div className="bupils">
                  <Button>Max</Button>
                </div>
              </div>
            </div>
            <div className="nropTol">
              <div className="nropTol_titl" onClick={showModal2}>
                <div className="zioti">
                  <div className="zitcon">
                    <img src={li2} alt="" />
                  </div>
                  <div>{(tokentwe as any).name}</div>
                  <div className="xisods">
                    <img src={xusa} alt="" />
                  </div>
                </div>
                <div className="Yusenit">
                  <span>余额：</span>0.0
                </div>
              </div>
              <div className="nropTol_nro">
                <div className="nro_input">
                  <input placeholder="0.0" />
                </div>
              </div>
              <Modal
                title="选择代币"
                footer={null}
                open={isModalOpen2}
                onCancel={handleCancel2}
                centered
                width="460px"
                bodyStyle={{ height: "100%", width: "100%" }}
              >
                <div className="shanbi">
                  <div className="shuinput">
                    <Input placeholder="搜索名称或粘贴地址" />
                  </div>
                  <div className="shancyui">
                    <div className="shantilwe">常用代币</div>
                    <div className="shuielist">
                      <div className="ielitem">
                        <img src={li1} alt="" />
                        <div className="buinet">USDT</div>
                      </div>
                      <div className="ielitem">
                        <img src={li2} alt="" />
                        <div className="buinet">CAKE</div>
                      </div>
                    </div>
                  </div>
                  <div className="daibList">
                    {toList.map((item: any, index) => (
                      <div
                        className="tbuitem"
                        key={index}
                        onClick={() =>
                          BIenerTwo(item.address, item.symbol, item.logoURI)
                        }
                      >
                        <div className="tbleu_tei">
                          <img src={item.logoURI} alt="" />
                        </div>
                        <div className="tbzh_ueni">
                          <div className="tbzh_Tile">{item.symbol}</div>
                          <div className="tbzh_Nro">{item.name}</div>
                        </div>
                        <div className="weiv_ubt">{item.buing}</div>
                      </div>
                    ))}
                  </div>
                  <div className="consbi">
                    <span>管理代币</span>
                    <DollarCircleOutlined />
                  </div>
                </div>
              </Modal>
            </div>
          </div>
          <div className="busitone">
            <Button>兑换</Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Swap;
