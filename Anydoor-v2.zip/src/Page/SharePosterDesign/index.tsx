import { Button, Form, Input } from 'antd';
import React, { useState } from 'react';
import "./index.css";
import SharePostersUpload1 from "./SharePostersUpload1";
import SharePostersUpload2 from "./SharePostersUpload2";
import SharePostersUpload3 from "./SharePostersUpload3";

// 分享海报设计界面
const onFinish = (values: any) => {
    console.log('Success:', values);
};

const onFinishFailed = (errorInfo: any) => {
    console.log('Failed:', errorInfo);
};


// const [parentCount, setParentCountt] = useState<[]>([]);

const getuploadData1 = (val:any) => {
    // setParentCountt(val);
    console.log("传过来上传信息1",val)
};
const getuploadData2 = (val:any) => {
    // setParentCountt(val);
    console.log("传过来上传信息2",val)
};
const getuploadData3 = (val:any) => {
    // setParentCountt(val);
    console.log("传过来上传信息3",val)
};

const SharePosterDesign: React.FC = () => {
    return (
        <div className='fx_Box'>
            <div className='fx_headerBox'>
                <div className='fx_headerBox_thread'></div>
                <div className='fx_headerBox_Tit'>&nbsp;&nbsp;&nbsp;分享海报</div>
            </div>
            <div className='fx_inputBox'>
                <Form
                    name="basic"
                    labelCol={{ span: 5 }}
                    wrapperCol={{ span: 18 }}
                    style={{ maxWidth: 600 }}
                    initialValues={{ remember: true }}
                    onFinish={onFinish}
                    onFinishFailed={onFinishFailed}
                    autoComplete="off"
                >
                    <Form.Item label="小程序名称" name="ppletName">
                        <Input placeholder="请输入小程序名称!" />
                    </Form.Item>

                    <Form.Item label="酒店内容" name="jd">
                        <Input placeholder="请输入酒店内容!" />
                    </Form.Item>

                    {/* 图片上传 */}
                    <Form.Item label="大图">
                        <SharePostersUpload1 getupload1={getuploadData1}/>
                    </Form.Item>
                    <Form.Item label="酒店图片">
                        <SharePostersUpload2 getupload2={getuploadData2}/>
                    </Form.Item>
                    <Form.Item label="分享二维码">
                        <SharePostersUpload3 getupload3={getuploadData3}/>
                    </Form.Item>

                    <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                        <Button className='jc_btn' size="middle" type="primary" htmlType="submit">提交</Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    )
}

export default SharePosterDesign;