import React from 'react'

const Grourcase = () => {
  return (
    <div>
      团购
    </div>
  )
}

export default Grourcase
