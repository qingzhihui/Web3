import React from "react";
import "antd/dist/antd.less";
import "./App.css";
import Demo from "./view/index5";

function App() {
  return (
    <div className="App">
      <Demo />
    </div>
  );
}

export default App;
