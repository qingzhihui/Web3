// 函数二义性
//三角关系 对象，构造函数，原型
// this指向  心智负担
class  User{

}
new User();
User();

function a(){
    if(new.target){
        throw  new Error("can't invoke with  'new'")
    }
}
//如果有值说明这个函数是通过new调用的
//没有值就当中普通函数调用的
