let testString = "Hello World";
testString = "王八蛋";

const constantString = "Hello World";
// constantString = ""

// 文字类型
let s: "hello" = "hello";
// s = 'world'
function printTrxt(s: string, alignment: "left" | "right" | "center") {}
printTrxt("hello", "left");
// 错误
// printTrxt('world','center2')

// 数字文字类型
function compare(a: string, b: string): -1 | 0 | 1 {
  return a == b ? 0 : a > b ? 1 : -1;
}

// 数字文字组合类型
interface Options {
  width: number;
}
function configure(x: Options | "auto") {}

configure({
  width: 100,
});
configure("auto");
// 错误
// configure('automatic')

// 布尔类型
let b1: true = true;
let b2: false = false;

// 文字推理
const objs = {
  count: 0,
};
if (true) {
  obj.count = 1;
}

// 可能常见的问题
function handleRequest(url: string, method: "GET" | "POST" | "GUESS") {}
const req = {
  url: "https://example.com",
  method: "GET",
  //   method: "GET" as 'GET' 1.将method的值推理为文字类型
} as const //3.固定类型
handleRequest(req.url, req.method);  // as "GET"   2.将method的值推理为文字类型
