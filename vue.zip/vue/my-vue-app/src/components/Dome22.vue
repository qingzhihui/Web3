<template>
</template>

<script setup>
//this的指向（this表示当前的远行环境，this指向谁取决于他的运行环境，
// 他的函数没有运行，这个this他就不确定，只有函数被运行的时候this才能被确定）

// this 基本知识点
// 1.通过 new 调用
//实例：new method()
//函数中的this指向：新对象

// 2.直接调用
//实例：method()
//函数中的this指向：全局对象

// 3.通过对象调用
//实例：obj.method()
//函数中的this指向：前面的对象

// 4.call，apply，bind
//实例：method.call(ctx)
//函数中的this指向：第一个参数


function fn1() {
  console.log(this);
}

fn1()// 指向全局对象

var obj2 = {
  fn1: fn1,
}
obj2.fn1(); //得到的就是一个对象

new fun2
{

} //指向新对象

// 指向obj正确 但是不确定
var obj = {
  fn2: function () {
    console.log(this)
  }
}

var newFun = fn1.bind({}); //得到一个新对象
newFun(); //this指向的是你传入的对象

</script>

<style>
</style>
