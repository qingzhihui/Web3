import React from "react";
import "./index.scss";
import { useTranslation } from "react-i18next";
import loge from "../../assets/image/loge2.png";
import Fonts3 from "../../assets/image/wyue.png";
import Fonts1 from "../../assets/image/Twitter_Negative.png";
import Fonts2 from "../../assets/image/TelegraNegative.png";
const FooterGenera = () => {
  const { t } = useTranslation();
  return (
    <div className="FooterGenera">
      <div className="FooterGeneraTitle">
        <div className="FooterGeneraLine">
          <div className="FooterGeneraLineOIMage">
            <img src={loge} alt="" />
          </div>
          <div className="FooterGeneraLineOValue">
            {`${t(
              "Developing sustainable development ecology, practicing DAO autonomy concept, and establishing a sustainable wealth mechanism"
            )}`}
          </div>
        </div>
        <div className="FooterGeneraData">
          <div className="FooterGeneraItem">
            <div className="FooterGeneraItemTitle"> {`${t("Contact Us")}`}</div>
            <div className="FooterGeneraItemValue">
              <div>{`${t("Website")}`}: my-token.net</div>
              <div className="ItemValueBuin">
                <div className="FooterGeneraLone">
                  <div className="FooterGeneraLoneItem acimg">
                    <img src={Fonts3} alt="" />
                  </div>
                  <div className="FooterGeneraLoneItem">
                    <img src={Fonts1} alt="" />
                  </div>
                  <div className="FooterGeneraLoneItem">
                    <img src={Fonts2} alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* <div className="FooterGeneraItem">
            <div className="FooterGeneraItemTitle">{`${t("Learn More")}`}</div>
            <div className="FooterGeneraItemValue">
              <div>{`${t("Blog")}`}</div>
              <div>{`${t("Read the Vision")}`}</div>
              <div>{`${t("Read Developer Docs")}`}</div>
            </div>
          </div>
          <div className="FooterGeneraItem">
            <div className="FooterGeneraItemTitle">{`${t("Learn More")}`}</div>
            <div className="FooterGeneraItemValue">
              <div>{`${t("Overview")}`}</div>
              <div>{`${t("Design")}`}</div>
              <div>{`${t("Programing")}`}</div>
              <div>{`${t("Collaborate")}`}</div>
            </div>
          </div> */}
        </div>
      </div>
      <div className="FooterGeneraTelex">
        {`${t("Copyright © 2023 My ToKen | Powered by MYTOKEN")}`}
      </div>
    </div>
  );
};

export default FooterGenera;
