import { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { useMenu } from "@/hooks/useConfig";
import { MenuList } from "@/hooks/config";
import { Button, Dropdown, Menu, Space, MenuProps } from "antd";
import { CaretDownOutlined } from "@ant-design/icons";
import "./index.scss";

const ches = {
  key: "1",
  name: "English",
};

function Header(props: any) {
  const [network, setNetwork] = useState(ches);
  let history = useHistory();
  const onClickHeader = (MenuItem: any) => {
    history.push(MenuItem.key);
  };
  const Buseir: any = [
    {
      key: "1",
      label: <div className="wereiku">English</div>,
    },
    {
      key: "2",
      label: <div className="wereiku">中文简体</div>,
    },
  ];
  const onClick: MenuProps["onClick"] = ({ key }) => {
    Buseir.map((item: any) => {
      if (item.key === key) {
        setNetwork({
          key: key,
          name: item.label.props.children,
        });
        localStorage.setItem("Network", key);
      }
    });
  };
  const menu = <Menu onClick={onClick} items={Buseir} />;
  useEffect(() => {}, []);

  return (
    <div className="header">
      <div className="header_proin">
        <div className="header_nroe">
          <div className="loge">
            <img src={require("@/assets/image/loge.png")} alt="" />
          </div>
          <div className="header_item">
            {MenuList.map((item: useMenu) => (
              <div
                className="header_item_title"
                onClick={() => {
                  onClickHeader(item);
                }}
                key={item.key}
              >
                {item.label}
              </div>
            ))}
          </div>
          <div className="header_message">
            <button>Login</button>
          </div>
        </div>
      </div>
      <div className="hader_gojha">
        <img src={require("@/assets/image/Group.png")} alt="" />
        <div>
          <Dropdown overlay={menu}>
            <Button onClick={(e) => e.preventDefault()}>
              <Space>
                <div className="slueipoi">
                  {(network as any).key === "1" ? (
                    <div className="werei">{(network as any).name}</div>
                  ) : (
                    <div className="werei">{(network as any).name}</div>
                  )}
                </div>
                <CaretDownOutlined />
              </Space>
            </Button>
          </Dropdown>
        </div>
      </div>
    </div>
  );
}

export default Header;
