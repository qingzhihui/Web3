const oneHundred: bigint = BigInt(100);
const anoutherHundred: bigint = 100n;

const firstName = Symbol("name");
const secondName = Symbol("name");

// if(firstName === secondName){
    
// }