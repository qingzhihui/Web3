import React from "react";
import Script from "next/script";

function ches() {
  return (
    <div>
      <Script src="./a.js" strategy="lazyOnload" />
      ches
    </div>
  );
}

export default ches;
