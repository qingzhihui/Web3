let v: undefined = undefined;
let o: null = null;

// 错误
// let a:string = undefined

function doSomething(x: string | null) {
  if (x == null) {
    // 做一些事情
  } else {
    console.log("Hello," + x.toUpperCase());
  }
}
function liveDangerously(x?: number | null) {
  // 加 ! 壮言为这个值不是null
  //   这个感叹号仅当你知道这个值不可能是null或undefined的时候使用才是重要的
  // （一般情况下不要过多使用这个感叹号，因为他会带来意外的一些问题）
  console.log(x!.toFixed());
}
