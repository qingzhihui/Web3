import React, { useState } from "react";
import "./index.scss";
import { useHistory } from "react-router-dom";
import { Slider, Progress } from "antd";

const Details = () => {
  const [dhes, setDhes] = useState("binge.png");
  const [disabled, setDisabled] = useState(true);
  let history = useHistory();
  const GomeProers = () => {
    history.push("/Game");
  };
  return (
    <div
      className="Details"
      style={{
        backgroundImage: `url(${require(`../../assets/image/${dhes}`)})`,
      }}
    >
      <div className="wpisien">
        <div className="wpisien_left">
          <div className="wpisien_left_nroe">
            <div className="wpisien_left_img">
              <img src={require("../../assets/image/r.png")} alt="" />
            </div>
            <div className="wpisien_left_title">LW</div>
            <div className="psilsien">
              <div className="psilsienItem">
                <div>能量值88</div>
                <div>能量值89</div>
              </div>
              <div className="posierjdt">
                <Slider defaultValue={50} disabled={disabled} />
              </div>
              <div className="spioerbe">15383/86290</div>
            </div>
            <div className="psodButom">
              <button>
                <img
                  src={require("../../assets/image/common icon_energy_yellow2.png")}
                  alt=""
                />
                训练球员
              </button>
            </div>
          </div>
        </div>
        <div className="wpisien_conset">
          <div className="wpisien_conset_nro">
            <div className="wpisien_conset_title">主要属性</div>
            <div className="wpisien_conset_skier">
              <div>
                <Progress
                  width={230}
                  type="circle"
                  percent={75}
                  format={(percent) => (
                    <div>
                      <div className="butext">能力值</div>
                      <div className="bueitn">{`${percent}`}</div>
                    </div>
                  )}
                />
              </div>
              <div className="pioseu">
                <div className="pioseu_title">球队能力值</div>
                <div className="poisneuz">88</div>
                <div className="pioseu_title">球队天赋</div>
                <div className="poisneuz2">+3</div>
                <div className="nusiern">
                  <img
                    src={require("../../assets/image/noto_trophy.png")}
                    alt=""
                  />
                  <div className="nusiern_zdhe">1000</div>
                </div>
              </div>
            </div>
            <div className="poniern">
              <div className="poniern_item">
                <div className="poniern_item_nr">体质PHY：</div>
                <div className="spoenise">
                  {" "}
                  <Progress
                    percent={30}
                    format={(percent) => (
                      <div className="posneih">{percent}</div>
                    )}
                  />
                </div>
              </div>
              <div className="poniern_item">
                <div className="poniern_item_nr">进攻ATT：</div>
                <div className="spoenise">
                  <Progress
                    percent={30}
                    format={(percent) => (
                      <div className="posneih">{percent}</div>
                    )}
                  />
                </div>
              </div>
              <div className="poniern_item">
                <div className="poniern_item_nr">防守DEF：</div>
                <div className="spoenise">
                  <Progress
                    percent={30}
                    format={(percent) => (
                      <div className="posneih">{percent}</div>
                    )}
                  />
                </div>
              </div>
              <div className="poniern_item">
                <div className="poniern_item_nr">等级LV：</div>
                <div className="spoenise">
                  <Progress
                    percent={30}
                    format={(percent) => (
                      <div className="posneih">{percent}</div>
                    )}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="wpisien_redfde">
          <div className="wpisien_redfde_siir">
            <div className="wpisien_redfde_IMG">
              <img src={require("../../assets/image/1.gif")} alt="" />
            </div>
            <div className="wpisien_redfde_buone">
              <button
                className="perzbie"
                onClick={() => {
                  GomeProers();
                }}
              >
                装备
              </button>
              <button
                className="perzbie2"
                onClick={() => {
                  GomeProers();
                }}
              >
                返回
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Details;
