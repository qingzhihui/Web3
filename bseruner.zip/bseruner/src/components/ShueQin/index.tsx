import React from "react";
import leaves1 from "../../assets/cp1.png";
import leaves2 from "../../assets/cp2.png";
import leaves3 from "../../assets/cp3.png";
import leaves4 from "../../assets/cp4.png";
import "./index.scss";

function index() {
  return (
    <div className="sdabe">
      <section>
        <div className="set">
          <div>
            <img src={leaves1} alt="" />
          </div>
          <div>
            <img src={leaves2} alt="" />
          </div>
          <div>
            <img src={leaves3} alt="" />
          </div>
          <div>
            <img src={leaves4} alt="" />
          </div>
          <div>
            <img src={leaves1} alt="" />
          </div>
          <div>
            <img src={leaves2} alt="" />
          </div>
          <div>
            <img src={leaves3} alt="" />
          </div>
          <div>
            <img src={leaves4} alt="" />
          </div>
        </div>
        <div className="set set-2">
          <div>
            <img src={leaves1} alt="" />
          </div>
          <div>
            <img src={leaves2} alt="" />
          </div>
          <div>
            <img src={leaves3} alt="" />
          </div>
          <div>
            <img src={leaves4} alt="" />
          </div>
          <div>
            <img src={leaves1} alt="" />
          </div>
          <div>
            <img src={leaves2} alt="" />
          </div>
          <div>
            <img src={leaves3} alt="" />
          </div>
          <div>
            <img src={leaves4} alt="" />
          </div>
        </div>
        <div className="set set-3">
          <div>
            <img src={leaves1} alt="" />
          </div>
          <div>
            <img src={leaves2} alt="" />
          </div>
          <div>
            <img src={leaves3} alt="" />
          </div>
          <div>
            <img src={leaves4} alt="" />
          </div>
          <div>
            <img src={leaves1} alt="" />
          </div>
          <div>
            <img src={leaves2} alt="" />
          </div>
          <div>
            <img src={leaves3} alt="" />
          </div>
          <div>
            <img src={leaves4} alt="" />
          </div>
        </div>
      </section>
    </div>
  );
}

export default index;
