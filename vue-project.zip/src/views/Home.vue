<script setup lang="ts">
// setup 组件只需引入不用注册，属性和方法也不用返回
// 也不用写setup函数，也不用写export default ，
// 甚至是自定义指令也可以在我们的template中自动获得。

import { ref } from 'vue';
import TestCom from "../components/TestCom.vue"
const flag = ref("开端-第一次循环");
const msg = '公交车-第一次循环';

const changeHander = (): void => {
  flag.value = '开端-第二次循环'
}

let myAddHander = (mess: any): void => {
  console.log('新增==>', mess);
}

let myDelHander = (mess: any): void => {
  console.log('删除==>', mess);
}

</script>

<template>
  <div class="home">
    显示的值{{ flag }}
    <button @click="changeHander">改变值</button>
  </div>
  <test-com :info="msg" time="42分钟" @myAdd="myAddHander" @myDel='myDelHander'></test-com>
</template>

<style scoped></style>
