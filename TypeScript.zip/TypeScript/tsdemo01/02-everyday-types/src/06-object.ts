function printCoord(pt: { x: number; y: number }) {
  console.log("坐标的x值为 ：" + pt.x);
  console.log("坐标的y值为 ：" + pt.y);
}
printCoord({ x: 3, y: 7 });

//   可选值(用户可传可不传)
function printName(obj: { first: string; last?: string }) {
  //   这种调用是错误的 因为对象obj可能是空的
  //   console.log(obj.last.toUpperCase());

  //   解决方法 1
  //   if (obj.last != undefined) {
  //       console.log(obj.last.toLowerCase);
  //   }

  //   解决方法 2
  console.log(obj.last?.toUpperCase());
}
// 必须传递对应的类型
// 不能传递未指定的值
printName({
  first: "Felix",
});
printName({
  first: "Felix",
  last: "Lu",
});
