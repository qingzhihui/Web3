import { Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

// 分销提现界面
const DistributorWithdrawal = () => {
  interface DataType {
    key: number;
    orderList: string; // 订单列表
    username: string; //用户
    withdrawalAmount: string; //提现金额
  }

  const data: DataType[] = [
    {
      key: 1,
      orderList: "153461464131",
      username: "微信333",
      withdrawalAmount: "688.00",
    },
    {
      key: 2,
      orderList: "153461464131",
      username: "微信0780",
      withdrawalAmount: "128.00",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "订单列表",
      dataIndex: "orderList",
      // width: 200,
    },
    {
      title: "用户",
      dataIndex: "username",
      // width: 200,
    },
    {
      title: "提现金额",
      dataIndex: "withdrawalAmount",
      // width: 200,
    },
  ];

  return (
    <div className="fxtx_Box">
      <div className="fxtx_headerBox">
        <div className="fxtx_headerBox_thread"></div>
        <div className="fxtx_headerBox_Tit">&nbsp;&nbsp;&nbsp; 分销提现</div>
      </div>

      <div className="fxtx_tableBox">
        <Table columns={columns} dataSource={data} />
      </div>
    </div>
  );
};

export default DistributorWithdrawal;
