import 'C:/Users/AnyDoorTrip-05/Desktop/Lisersn/node_modules/antd/es/result/style';
