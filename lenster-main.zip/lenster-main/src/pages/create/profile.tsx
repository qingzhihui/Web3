import Create from '@components/Create'

export default Create
