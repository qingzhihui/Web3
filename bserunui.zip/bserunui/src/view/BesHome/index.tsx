import React, { useEffect, useState } from "react";
import "./index.scss";
import { message } from "antd";
import copy from "copy-to-clipboard";
import { CONTRACT_ABI, CONTRACT_ADDRESS } from "../../Contract/contractApp";
import { Mint_ADDRESS, Mint_ABI } from "../../Contract/mintContract";
import { PAIR_ABI } from "../../Contract/pancakepair";
import { ethers } from "ethers";
import { notification } from "antd";
const code = "0x163314BE8cFE6002eaBE7652db10090a26c925c2";
declare const window: Window & { ethereum: any };
const adrrels = "0x14499d4e3f19E6631653eeadfD671B2BDFa9d1C1";

const openNotification = () => {
  notification.open({
    message: "提示",
    description: "你暂无权限查看",
    duration: 10,
    top: 120,
  });
};
function Home(props: any) {
  const [listnu, setListnu] = useState([]);
  const [nusier, setNusier] = useState(0);
  const [address, setAddress] = useState("");
  const [usLst, setuslst] = useState([]);
  const [LPdata, setLPdata] = useState([]);
  const Fosnt = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const mintContract = new ethers.Contract(Mint_ADDRESS, Mint_ABI, signer);
    const cleader = await mintContract.getCommunityLeaderArray();
    const PAIRContract = new ethers.Contract(code, PAIR_ABI, signer);
    const Buser: any = [];
    const Uiser: any = [];
    const LPList: any = [];
    cleader.map(async (item: any, index: any) => {
      const pcard = await mintContract.ownedPurpleGoldCardAmount(item);
      const Lpamount = await Contract.userInfo(0, item);
      const lseri = await PAIRContract.balanceOf(CONTRACT_ADDRESS);

      if (
        Number(pcard.toString()) > 0 &&
        Number(Lpamount.depositAmount.toString()) > 0
      ) {
        const Proportion =
          Number(Lpamount.depositAmount.toString()) / Number(lseri.toString());
        if (index == 0) {
          console.log(Lpamount.depositAmount.toString());
        }

        Uiser.push(item);
        LPList.push(Proportion + "%");
        Buser.push({
          address: item,
          Lpdata: Proportion,
        });
      }
      setTimeout(() => {
        setuslst(Uiser);
        setListnu(Buser);
        setLPdata(LPList);
        setNusier(Buser.length);
      }, 500);
    });
  };
  const Metaddr = async () => {
    if (typeof window.ethereum !== "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const addr = await signer.getAddress();
      if (addr == adrrels) {
        setAddress(addr);
      } else {
        openNotification();
      }

      console.log("You have connected your wallet");
    } else {
      console.log("Please install metamask.");
    }
  };
  const LoshowDe = () => {
    setAddress("");
  };
  const skUerNuer = () => {
    if (copy(String(usLst))) {
      success("复制成功");
    } else {
      success("复制失败");
    }
  };
  const success = (luser: any) => {
    message.success(luser, 2);
  };
  const skUerLPdata = () => {
    if (copy(String(LPdata))) {
      success("复制成功");
    } else {
      success("复制失败");
    }
  };
  useEffect(() => {
    if (address !== "") {
      Fosnt();
    }
  }, [address]);
  return (
    <div className="conteron">
      <div className="snueing">
        <div className="Hder_reft">
          {address !== "" ? (
            <>
              <div className="sksiuer">
                <button
                  onClick={() => {
                    skUerLPdata();
                  }}
                >
                  一键复制LP
                </button>
                <button
                  onClick={() => {
                    skUerNuer();
                  }}
                >
                  一键复制钱包
                </button>
              </div>
              <div className="Realsibu">
                <div className="noelue">
                  <span>
                    {address.substring(0, 4) +
                      "..." +
                      address.substring(38, 42)}
                  </span>
                </div>
                <div>
                  <div
                    className="bsuein"
                    onClick={() => {
                      LoshowDe();
                    }}
                  >
                    断开连接
                  </div>
                </div>
              </div>
            </>
          ) : (
            <button onClick={() => Metaddr()}>连接钱包</button>
          )}
        </div>
        <div className="buseitile">
          <div> 符合条件用户如下:</div>
          <div className="sbuedri">总共查询到 {nusier} 条数据</div>
        </div>
        {listnu.map((item: any, index: any) => (
          <div className="buseit" key={index}>
            {/* <div className="bulioet">
              <div className="tirel">ID:</div>
              <div className="tnerl">{item.id}</div>
            </div> */}
            <div className="bulioet">
              <div className="tirel">ADDRESS:</div>
              <div className="tnerl">{item.address}</div>
            </div>
            <div className="bulioet">
              <div className="tirel">FISTDAO / USDT:</div>
              <div className="tnerl">{item.Lpdata}%</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default Home;
