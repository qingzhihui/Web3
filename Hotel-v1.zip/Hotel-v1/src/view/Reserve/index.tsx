import React from "react";
import "./index.scss";

const Reserve = () => {
  return (
    <div className="reserve">
      <div className="reserve_nreo">
        <div className="reserve_nreo_item">
          <div className="reser_item_fun">
            <div className="item_fun_porn">
              <div className="fun_porn_image">
                <img
                  src={require("../../assets/image/Rectangle-2.png")}
                  alt=""
                />
              </div>
              <div className="fun_porn_nro">
                <div className="porn_nro_title">
                  【Rock Brothers Presents】 Youth is not always there
                </div>
                <div className="porn_nro_tnro">
                  Time: 2022.12.17 Saturday 20:00 Venue: Beijing | Beijing Le
                  Space
                </div>
                <div className="porn_nro_piece">Quantity: 1 piece</div>
                <div className="piece_Num">$ 200</div>
              </div>
              <div className="porn_nro_wser">
                <img src={require("../../assets/image/ewm.png")} alt="" />
              </div>
            </div>
            <div className="item_fun_foot">
              <div className="fun_foot_image">
                <img src={require("../../assets/image/damai.png")} alt="" />
              </div>
              <div className="fun_foot_tnie">
                E-ticket: You can directly check the ticket and enter the venue
              </div>
              <div className="fun_foot_fnuit">
                <button>already paid</button>
              </div>
            </div>
          </div>
          <div className="reser_item_kun">
            <div className="priong_tile">
              Instructions for watching performances
            </div>
            <div className="priong_bnrui">
              <div className="titlei">Show duration</div>
              <div className="brolei">
                About 60 minutes (subject to the site)
              </div>
            </div>
            <div className="priong_bnrui">
              <div className="titlei">Admission time</div>
              <div className="brolei">
                Please enter about 30 minutes before the performance
              </div>
            </div>
            <div className="priong_bnrui">
              <div className="titlei">No Items</div>
              <div className="brolei">
                Due to security and copyright reasons, food, drink, professional
                video recording equipment, lighters and other items are
                prohibited in most performance, exhibition and competition
                venues. Please pay attention to the prompts of on-site staff and
                broadcasting and cooperate.
              </div>
            </div>
            <div className="priong_bnrui">
              <div className="titlei">Deposit instructions</div>
              <div className="brolei">
                There is no deposit place. Please take care of your belongings
                to avoid loss of valuables.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reserve;
