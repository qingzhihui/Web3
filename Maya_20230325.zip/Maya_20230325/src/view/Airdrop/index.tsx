import React, { useEffect, useState, useTransition } from "react";

import "./index.css";
import "./mobile.css";
import { useHistory, useLocation } from "react-router-dom";
import CurrencyContainer from "../../components/CurrencyContainer/index";
import { FormatUnitsConver, InstancedContract, Lineg, ObtainAddress, TokenNameDecimals } from "../../hooks/config";
import { ethers } from "ethers";
import { useTranslation, Trans } from "react-i18next";
import Loading from "../../components/Loading";
import { AirDropDataPienSers, getAirDropArray } from "../../hooks/AntiBot";
import { AirPrcoABI, AirPrcoAddress, NextTokenABI } from "../../../src/hooks/Airprcopy";
import { AirDropABI } from "../../hooks/SomebodyAirdrop";
import { isAddress } from '../../utils/address'
import InputError from '../../components/InputError'

declare const window: Window & { ethereum: any };

const Airdrop: React.FC = () => {
  const { t } = useTranslation();
  let history = useHistory();
  const { state } = useLocation<any>();
  const [btnState, setBtnState] = useState<number>(1);
  const [addrInput, setAddrInput] = useState<string>("");
  const [allist, setAllList] = useState<any[]>([]);
  const [myList, setMyList] = useState<any[]>([]);
  const [createList, setCreateList] = useState<any[]>([]);
  const [ULieng, setULieng] = useState<Lineg>({});
  const [NameShow, setNameShow] = useState<boolean>(false);
  const [deateList, setdeateList] = useState<any>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [isePending, setTransition] = useTransition();
  const [airdropAmount, setAirdropAmount] = useState("");
  const [errorshow,isErrorShow] = useState<boolean>(false)
  const [isexec,setIsExec] = useState<boolean>(false)
  const [faltFeeShow, setFaltFeeShow] = useState<string>("");
  const [participants, setParticipants] = useState(0);

  const NextAirporn = () => {
    history.push({
      pathname: "/CreateAirece",
      state: {
        UrlName: "Airdrop",
        inputValue: addrInput,
      },
    });
  };

  const AddrInputOnChenge = async (e: any) => {
    setAddrInput((AddrInput: string) => {
      return (AddrInput = e.target.value);
    });
    if (ethers.utils.isAddress(e.target.value)) {
      const Uline = await TokenNameDecimals(e.target.value);
      setULieng((ULiengprevState: Lineg) => {
        return (ULiengprevState = Uline);
      });
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = true);
      });
    } else {
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = false);
      });
    }
  };

  const AddrInputOnPones = async (address: string) => {
    if (ethers.utils.isAddress(address)) {
      const Uline = await TokenNameDecimals(address);
      setULieng((ULiengprevState: Lineg) => {
        return (ULiengprevState = Uline);
      });
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = true);
      });
    } else {
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = false);
      });
    }
  };

  const CurrencyContainerShow = async () => {
    try {
      setLoading(true);
      Promise.all([getAirDropArray(), ObtainAddress()])
        .then(async (resolve) => {
          const getPrivateListData = await AirDropDataPienSers(
            resolve[0],
            resolve[1]
          );
          setTransition(() => {
            setdeateList((Datelist: any) => {
              return (Datelist = getPrivateListData.Pulein);
            });
            setAllList((Datelist: any) => {
              return (Datelist = getPrivateListData.Pulein);
            });
            setMyList((Datelist: any) => {
              return (Datelist = getPrivateListData.mylist);
            });
            setCreateList((Datelist: any) => {
              return (Datelist = getPrivateListData.createlist);
            });
          });
          setLoading(false);
        })
        .catch((error) => {
          setLoading(false);
        });
    } catch (error) {
      setLoading(false);
    }
  };
  
  const getTotalAirdropAmountAndParticipants = async () => {
    const AirDropFactoryContract = InstancedContract(AirPrcoAddress, AirPrcoABI) as any;
    // const flatFee = await AirDropFactoryContract.flatFee();
    // setFaltFeeShow(FormatUnitsConver(flatFee.toString(),18));
    const airDropArrayLength = await AirDropFactoryContract.getAirDropArrayLength();
    setAirdropAmount(airDropArrayLength.toString())
    const airDropArray = await AirDropFactoryContract.getAirDropArray();
    let totalParticipants = 0;
    for (let index = 0; index < airDropArrayLength; index++) {
      const airDropContractAddr = airDropArray[index];
      const AirDropConstaer = InstancedContract(airDropContractAddr, AirDropABI) as any;
      const allAllocationCount = await AirDropConstaer.allAllocationCount();
      totalParticipants = totalParticipants + Number(allAllocationCount);
      setParticipants(totalParticipants);
    }
  }
  useEffect(() => { }, [allist, myList, createList, airdropAmount, participants]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        setLoading(true);
        CurrencyContainerShow();
        if (state != undefined) {
          setAddrInput((AddrInput: string) => {
            return (AddrInput = state.inputValue);
          });
          AddrInputOnPones(state.inputValue)
        }
      }
      getTotalAirdropAmountAndParticipants();
    }
  }, []);

  const changeBtn = (id: number) => {
    setBtnState(id);
    if (id === 2) {
      setdeateList(myList);
    } else if (id === 3) {
      setdeateList(createList);
    } else {
      setdeateList(allist);
    }
  };

  const judgeAddr = (value:string) => {
    if(isAddress(value)){
      isErrorShow(false)
      setIsExec(true)
    } else {
      isErrorShow(true)
      setIsExec(false)
    }
  }

  useEffect(() => {
    if(isAddress(addrInput)){
      // isErrorShow(false)
      setIsExec(true)
    } else {
      // isErrorShow(true)
      setIsExec(false)
    }
  },[addrInput])

  return (
    <div className="Airdrop">
      <div className="airdrop-content">
        <div className="AirdropTitle">{`${t("Create New Airdrop")}`}</div>
        <div className="InputArea">
          <div className="airdrop_require require-title">(<span style={{ color: "#F95192" }}> *</span>){`${t("is required field.")}`}</div>
          <div className="InputAreaColumnOne">
            <div className="InputAreaColumnOneLeft">
              {`${t("Token address")}`}{" "}
              <span style={{ color: "#F95192" }}> *</span>
            </div>
          </div>
          <input
            className="addrInput"
            value={addrInput || ""}
            placeholder={`${t("Please input token address")}`}
            onChange={(e) => {
              AddrInputOnChenge(e);
            }}
            onBlur={(e) => { judgeAddr(e.target.value) }}
            style={{borderColor:errorshow ? '#f14668' : ''}}
          />
          { errorshow ? <InputError title={`${t("Invalid token address")}`} /> : '' }
          <div className="createFee">
            {`${t("Create airdrop fee")}`}: {faltFeeShow || 0} BNB
          </div>
          {NameShow === true ? (
            <>
              <div className="createFees">
                <div>{`${t("Name")}`}</div>
                <div>{ULieng.name}</div>
              </div>
              <div className="createFees">
                {" "}
                <div>{`${t("Symbol")}`}</div>
                <div>{ULieng.symbol}</div>
              </div>
              <div className="createFees">
                <div>{`${t("Decimals")}`}</div>
                <div>{ULieng.decimals}</div>
              </div>
            </>
          ) : (
            ""
          )}
          { isexec ? <button
            className="nextbtn"
            onClick={() => {
              NextAirporn();
            }}
          >
            {`${t("Next")}`}
          </button> : <button
            className="nextbtn"
            style={{cursor:'not-allowed',backgroundColor:'#999'}}
          >
            {`${t("Next")}`}
          </button> }

        </div>
        <div className="disclaimer">
          {`${t("Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published.")}`}
        </div>
        <div className="AirdropTitle">{`${t("Current Airdrop")}`}</div>
        <div className="DataArea">
          <div className="DataItem">
            <div className="dataitem-title">{`${t("Airdrop Launched")}`}</div>
            <div className="dataitem-num">{airdropAmount}</div>
          </div>
          <div className="data-line" />
          <div className="DataItem">
            <div className="dataitem-title">{`${t(
              "Participants in All-time"
            )}`}</div>
            <div className="dataitem-num">{participants}</div>
          </div>
        </div>
        <div className="textbtnArea">
          <div
            className="textbtnItem"
            onClick={() => {
              changeBtn(1);
            }}
          >
            <span
              className="textbtn"
              style={{ color: btnState === 1 ? "#F95192" : "#222222" }}
            >
              {`${t("All Airdrops")}`}
            </span>
            <div
              className="textbtn-line"
              style={{ background: btnState === 1 ? "#F95192" : "transparent" }}
            />
          </div>
          <div
            className="textbtnItem"
            onClick={() => {
              changeBtn(2);
            }}
          >
            <span
              className="textbtn"
              style={{ color: btnState === 2 ? "#F95192" : "#222222" }}
            >
              {`${t("My Airdrops")}`}
            </span>
            <div
              className="textbtn-line"
              style={{ background: btnState === 2 ? "#F95192" : "transparent" }}
            />
          </div>
          <div
            className="textbtnItem"
            onClick={() => {
              changeBtn(3);
            }}
          >
            <span
              className="textbtn"
              style={{ color: btnState === 3 ? "#F95192" : "#222222" }}
            >
              {`${t("Created By You")}`}
            </span>
            <div
              className="textbtn-line"
              style={{ background: btnState === 3 ? "#F95192" : "transparent" }}
            />
          </div>
        </div>
        {loading ? (
          <div className="Airdrop-loading">
            <Loading />
          </div>
        ) : (
          <CurrencyContainer currencylist={deateList} />
        )}
      </div>
    </div>
  );
};

export default Airdrop;
