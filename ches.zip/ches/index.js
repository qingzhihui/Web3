// 数组求和，不允许使用循环，不允许使用标准库的函数

// nums: 5, 1, 3, 6, 2;

// f(i) 表示从数组第i位到末尾之和

// f(i) = nums[i] + f(i+1)

// i>nums.length  f(i) = 0

function sum(nums) {
  function f(i) {
    return i > nums.length ? 0 : nums[i] + f(i + 1);
  }
  return f(0);
}

console.log(sum([]), sum([5, 1, 3, 6, 2]));

console.log('123')