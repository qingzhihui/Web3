import { useEffect, useState } from "react";
import { CopyOutlined } from "@ant-design/icons";
import { useTranslation } from "react-i18next";
import "./index.scss";
import "./mobile.scss";
import { InstancedContract, ObtainAddress } from "../../hooks/config";
import { INVITE_ABI, INVITE_ADDR } from "../../config/abi/inviteContract";

const Invit = () => {
  const { t } = useTranslation();
  const [value, setValue] = useState("");
  const [addData, setaddData] = useState([]);

  const useInvitShoe = async () => {
    const NVIContract: any = InstancedContract(INVITE_ADDR, INVITE_ABI);
    const UserAddress = await ObtainAddress();
    const getUserReferrer = await NVIContract.getUserReferrer(
      UserAddress?.address
    );
    const getUserTotalSubardinatesNumber =
      await NVIContract.getUserTotalSubardinatesNumber(UserAddress?.address);
    const AddressData: any = [];
    for (
      let index = 0;
      index < Number(getUserTotalSubardinatesNumber.toString());
      index++
    ) {
      const getUserTotalSubardinatesByIndex =
        await NVIContract.getUserTotalSubardinatesByIndex(
          UserAddress?.address,
          index
        );
      AddressData.push(getUserTotalSubardinatesByIndex);
    }
    setValue((state) => {
      return (state = getUserReferrer);
    });
    setaddData((state) => {
      return (state = AddressData);
    });
  };

  useEffect(() => {
    useInvitShoe();
  }, []);
  return (
    <div className="Invit">
      <div className="InvitComponent">
        <div className="InvitComponentFunsei">
          <div className="InvitComponentItem">
            <div className="InvitComponentItemTitle">
              <span> {`${t("Invitation information")}`}</span>
            </div>
            <div className="InvitComponentItemVnri">
              <div className="ItemVnriNrol">
                <div className="ItemVnriNrolTitle">
                  <div className="ItemVnriNrolper">{`${t(
                    "My superior wallet"
                  )}`}</div>
                  <div className="ItemVnriNroInput">
                    <input
                      type="text"
                      disabled
                      value={value || ""}
                      placeholder="No superior wallet"
                    />
                    <div className="ItemVnriNroiCon">
                      <button>
                        <CopyOutlined style={{ fontSize: 20, color: "#FFF" }} />
                      </button>
                    </div>
                  </div>
                </div>
                <div className="ItemVnriFles">
                  {`${t("Number of people I invited")}`}:0
                </div>
                <div className="ItemVnriDilue">
                  <div className="ItemVnriDilueTitle">
                    {`${t("No subordinate wallet")}`}
                  </div>
                  <div className="ItemVnriDilueNrole">
                    {addData.length === 0 ? (
                      <div className="NdateShw">{`${t(
                        "No subordinate wallet"
                      )}`}</div>
                    ) : (
                      <>
                        {addData.map((item: any, index: number) => (
                          <div className="ItemVnriDilueNroleItem" key={index}>
                            {item}
                          </div>
                        ))}
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Invit;
