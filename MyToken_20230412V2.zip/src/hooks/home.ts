import ico1 from "../assets/image/ico1.png";
import ico2 from "../assets/image/ico2.png";
import ico3 from "../assets/image/ico3.png";
import ico4 from "../assets/image/ico4.png";
import ico5 from "../assets/image/ico5.png";
import flab from "../assets/image/flab.png";
import Guin1 from "../assets/image/Guin1.png";
import Guin2 from "../assets/image/Guin2.png";
import Guin3 from "../assets/image/Guin3.png";
import Guin4 from "../assets/image/Guin4.png";
import Guin5 from "../assets/image/Guin5.png";
import Guin6 from "../assets/image/Guin6.png";
export {
  ico1,
  ico2,
  ico3,
  ico4,
  ico5,
  flab,
  Guin2,
  Guin3,
  Guin4,
  Guin5,
  Guin1,
  Guin6,
};
