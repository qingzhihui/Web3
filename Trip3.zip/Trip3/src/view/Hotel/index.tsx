import React from 'react'
import './index.scss'
import { Input } from 'antd';

export default function index() {
  return (
    <div className='start'>
      <div className='startsreach'>
        <div className='starttitle'>Start to book your perfect trip freely</div>
        <div className='sreachbut'>
          <div className='please'>
            <div>Hotel reservation</div>
            <Input placeholder="Please enter the city, hotel name" bordered={false} />
          </div>
          <button>search</button>
        </div>
      </div>
      <div className='startchoose'>
        <div className='destination'>Choose the destination you want to go to</div>
        <div className='chooseimage'>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
      <div className='startselect'>
        <div className='brand'>Select brand</div>
        <div className='selectimgs'>
          <img src={require('@/assets/image/start1.png')} alt="" />
          <img src={require('@/assets/image/start2.png')} alt="" />
          <img src={require('@/assets/image/start3.png')} alt="" />
          <img src={require('@/assets/image/start4.png')} alt="" />
          <img src={require('@/assets/image/start5.png')} alt="" />
          <img src={require('@/assets/image/start6.png')} alt="" />
          <img src={require('@/assets/image/start7.png')} alt="" />
          <img src={require('@/assets/image/start8.png')} alt="" />
          <img src={require('@/assets/image/start9.png')} alt="" />
          <img src={require('@/assets/image/start10.png')} alt="" />
          <img src={require('@/assets/image/start11.png')} alt="" />
          <img src={require('@/assets/image/start12.png')} alt="" />
        </div>
      </div>
    </div>
  )
}
