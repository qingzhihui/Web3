import React, { useState } from "react";

// type Props = {
//   name: string;
//   age: number;
// };
// const Person: React.FC<Props> = ({ name, age }) => {
//   return (
//     <div>
//       <p>Name: {name}</p>
//       <p>Age: {age}</p>
//     </div>
//   );
// };

// interface State {
//   count: number;
// }
// const Counter: React.FC = () => {
//   const [state, setState] = useState<State>({ count: 0 });

//   const increment = () => {
//     setState({ count: state.count + 1 });
//   };

//   return (
//     <div>
//       <p>Count: {state.count}</p>
//       <button onClick={increment}>Increment</button>
//     </div>
//   );
// };

// 使用 Person 组件
// const App = () => {
//   return (
//     <div>
//       <Person name="John" age={30} />
//       <Counter />
//     </div>
//   );
// };

// type Props<T> = {
//   data: T[];
// };

// const List: React.FC<Props<string>> = ({ data }) => {
//   return (
//     <ul>
//       {data.map((item, index) => (
//         <li key={index}>{item}</li>
//       ))}
//     </ul>
//   );
// };

// const App = () => {
//   const dataList = ["Item 1", "Item 2", "Item 3"];

//   return <List data={dataList} />;
// };

type Props<T> = {
  data: T[];
  renderItem: (item: T) => React.ReactNode;
};

const List = <T extends {}>({ data, renderItem }: Props<T>) => {
  return (
    <ul>
      {data.map((item, index) => (
        <li key={index}>{renderItem(item)}</li>
      ))}
    </ul>
  );
};

// 使用 List 组件
const App = () => {
  const dataList = [
    { id: 1, name: "Item 1" },
    { id: 2, name: "Item 2" },
    { id: 3, name: "Item 3" },
  ];

  return (
    <List
      data={dataList}
      renderItem={(item) => (
        <div>
          <p>ID: {item.id}</p>
          <p>Name: {item.name}</p>
        </div>
      )}
    />
  );
};

export default App;
