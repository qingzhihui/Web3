import api from '../../config/axios'
let timer: any;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cityID: "",
    SelectDate: [],
    SelectState: false,
    Internal: [],
    Intional: [],
    active: 0,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options: any) {
    this.setData({
      cityID: options.id
    })
    const InternalData: any = [];
    const IntionalData: any = [];
    api._get('https://apis-01.anydoortrip.com/hotel/popular_cities').then(res => {
      res.data.map((item: any) => {
        if (item.country === "中国") {
          InternalData.push({
            cityName: item.city
          })
        } else {
          IntionalData.push({
            cityName: item.city
          })
        }
      })
      this.setData({
        Internal: InternalData,
        Intional: IntionalData
      })
    }).catch(event => {
      console.log(event);
    })
  },
  ItemDetails(event: any) {
    var pages = getCurrentPages();
    var beforePage = pages[pages.length - 2];
    const item = { id: Number(this.data.cityID), value: event.currentTarget.dataset.code }
    wx.navigateBack({
      delta: -1,
      success: function () {
        beforePage.AddressProps(item);
      }
    })
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  HotelData(value: string) {
    api._get(`hotel/city_search?keyword=${value}`).then(res => {
      const Data: any = [];
      console.log(res);
      if (res.length !== 0 || res !== null) {
        res.data.map((item: any) => {
          if (item.locationType === "city") {
            Data.push(item);
          }
        })
      }
      this.setData({
        SelectDate: Data,
        SelectState: true
      })
    }).catch(e => {
      console.log(e);
    })
  },
  debounce(event: any) {
    this.setData({
      inputShow: event.detail.value
    })
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (event.detail.value !== "") {
        this.HotelData(event.detail.value)
      } else {
        this.setData({
          SelectState: false,
          SelectDate: []
        })
      }
    }, 800);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },





  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})