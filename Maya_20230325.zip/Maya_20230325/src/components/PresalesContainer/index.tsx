/* eslint-disable no-lone-blocks */
/* eslint-disable array-callback-return */
import React, { useEffect, useState } from "react";

import "./index.css";
import "./mobile.css";
import { Progress, message, Statistic } from "antd";
import { useHistory } from "react-router-dom";
import { PrivateSalePropsType } from "../../hooks/PrivateSale";
import { useTranslation, Trans } from "react-i18next";
import { log } from "console";
const { Countdown } = Statistic;
interface Props {
  tokenlist: PrivateSalePropsType[];
}

const TokenContainer: React.FC<Props> = ({ tokenlist }) => {
  // 现在的时间戳 数字类型 毫秒
  const date = new Date().getTime();
  let history = useHistory();
  const { t } = useTranslation();
  const [messageApi, contextHolder] = message.useMessage();
  const [toklist, setTokList] = useState<PrivateSalePropsType[]>([]);
  const collectTip = (content: string) => {
    messageApi.open({
      type: "success",
      content: content,
    });
  };
  const [psieon, setPsieon] = useState(false);

  useEffect(() => {
    // console.log(tokenlist);
    setTokList((TokList: PrivateSalePropsType[]) => {
      return (TokList = tokenlist);
    });
    tokenlist.map((item: PrivateSalePropsType) => {
      if (item.tgeBps === "0") {
        setPsieon((state: boolean) => {
          return (state = true);
        });
      }
    });
  }, [tokenlist]);

  const setCollectStatus = (id: number) => {
    let tklist: any = [];
    let tipContent: string;
    toklist.map((item: any, index: number) => {
      if (index === id) {
        if (item.isCollect) {
          tipContent = "取消收藏";
        } else {
          tipContent = "收藏成功";
        }
        item.isCollect = !item.isCollect;
        {
          collectTip(tipContent);
        }
      }
      tklist.push(item);
    });
    setTimeout(() => {
      setTokList(tklist);
    }, 100);
  };
  const ViewAirdropOnClick = (item: any) => {
    history.push({
      pathname: "/CurrentPresales",
      state: {
        data: item,
      },
    });
  };

  // 列表项随机图片生成
  const getImageRandomid = () => {
    return Math.floor(Math.random() * 4) + 1
  }

  return (
    <div className="currencyArea">
      {contextHolder}
      {toklist.map((item: any, index: number) => (
        <div className="currencyItem" key={index}>
          <div className="currencyImageArea">
            <div
              className="collectRound"
              onClick={() => {
                setCollectStatus(index);
              }}
            >
              <img
                src={require(`../../assets/image/notCollect.png`)}
                alt=""
                className="collectLogo"
                style={{
                  filter: item.isCollect
                    ? "sepia(1) saturate(4) hue-rotate(295deg)"
                    : "grayscale(100%)",
                }}
              />
            </div>
            <div className="catRound">
              <img
                src={require(`../../assets/image/airdrop-dataLogo.png`)}
                alt=""
                className="airdrop-bottomCat"
              />
            </div>
            <img
              src={require(`../../assets/image/airdrop-image0${getImageRandomid()}.png`)}
              alt=""
              className="currencyImage"
            />
          </div>
          {psieon ? (
            ""
          ) : (
            <div className="planes">
              {`${t("Project will receive")}`} {item.tgeBps}%{" "}
              {`${t("at first release")}`}
            </div>
          )}

          <div className="tokenInfo">
            <div className="tokenInfo-item">
              {/* <div className="tokenInfo-title">{`${t("Title")}`}</div> */}
              <div className="tokenInfo-name">{item.Title}</div>
            </div>
            <div className="tokenInfo-line" />
            <div className="tokenInfo-item">
              <div className="tokeninfo-title">
                {/* {`${t("Sale Ends In")}`} */}
                {Number(item.start) > date ? `${t("Sale Starts In")}` : ""}
                {Number(item.start) < date && Number(item.end) > date
                  ? `${t("Sale Ends In")}`
                  : ""}
                {Number(item.end) < date ? `${t("Sale Ended")}` : ""}
                {/* </div>
              <div className="tokeninfo-name"> */}
                {/* 未开始 */}
                {Number(item.start) > date ? (
                  <Countdown value={Number(item.start)} format="DD:HH:mm:ss" />
                ) : (
                  ""
                )}
                {/* 进行中 显示距离结束 */}
                {Number(item.start) < date && Number(item.end) > date ? (
                  <Countdown value={Number(item.end)} format="DD:HH:mm:ss" />
                ) : (
                  ""
                )}
                {/* 已结束 */}
                {Number(item.end) < date ? "" : ""}
              </div>
            </div>
          </div>
          <div className="tokenDataItem">
            <span className="total">
              {`${t("Soft Cap")}`}/ {`${t("Hard Cap")}`}
            </span>
          </div>
          <div className="tokenDataItem">
            <span className="totalnum">
              {Number(item.softCap)} BNB - {Number(item.hardCap)} BNB
            </span>
          </div>
          <div className="progress-title">
            {`${t("Progress")}`} ({(Number(item.raisedAmount) / Number(item.hardCap)) * 100}%)
          </div>
          <Progress
            percent={
              ((Number(item.raisedAmount) / Number(item.hardCap)) *
                100) as number
            }
          />
          <div className="tokenData">
            <div className="tokenDataItem">
              <span className="total">{`${t("Liquidity (%)")}`}:</span>
              <span className="totalnum">{item.liquidityPercent}%</span>
            </div>
            <div className="tokenDataItem">
              <span className="total">{`${t("Lockup Time(m)")}`}:</span>
              <span className="totalnum">{item.lpLockTime}{" "}{`${t("minutes")}`}</span>
            </div>
          </div>
          <div className="currency-bottombtn">
            {item.start > date ? (
              <button className="currency-button comingbtn">
                <div className="comingRound" />
                {`${t("Upcoming")}`}
              </button>
            ) : item.status === "1" &&
              Number(item.raisedAmount) < Number(item.hardCap) &&
              item.end < date ? (
              <button className="currency-button cancelbtn">
                <div className="cancelRound" />
                {`${t("Sale Ended")}`}
              </button>
            ) : item.status === "2" ? (
              <button className="currency-button cancelbtn">
                <div className="cancelRound" />
                {`${t("Sale Ended")}`}
              </button>
            ) : item.status === "3" ? (
              <button className="currency-button saleEndbtn">
                <div className="saleEndRound" />
                {`${t("Canceled")}`}
              </button>
            ) : item.raisedAmount.toString() === item.hardCap ? (
              <button className="currency-button savebtn">
                <div className="saveRound" />
                {`${t("Fiiled")}`}
              </button>
            ) : (
              <button className="currency-button savebtn">
                <div className="saveRound" />
                {`${t("Sale Live")}`}
              </button>
            )}
            <button
              className="currency-button viewbtn"
              onClick={() => {
                ViewAirdropOnClick(item);
              }}
            >
              {`${t("View")}`}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TokenContainer;
