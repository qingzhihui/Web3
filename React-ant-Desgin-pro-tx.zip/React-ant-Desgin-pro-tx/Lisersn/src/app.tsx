import React from 'react';
import { RequestConfig } from 'umi';
import { notification } from 'antd';
import { ResponseError } from 'umi-request';
import PageLoading from './components/PageLoading';
export async function getInitialState(): Promise<API.IUser> {
  return Promise.resolve({
    id: 1,
    name: '123',
  });
}

const errorHandler = (error: ResponseError) => {
  notification.error({
    description: '你的网络发生异常,无法连接服务器',
    message: '网络异常',
  });
};
export const request: RequestConfig = {
  errorHandler,
};
export const initialStateConfig = {
  loading: <PageLoading />,
};
