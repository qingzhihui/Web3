import {
    DeleteOutlined, FormOutlined
} from '@ant-design/icons';
import { Button, Form, Input, Modal, Radio, Space, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import "./index.css";


// 文章分类管理界面
const EssayClassifyManag = () => {
    const [isAddEssayClass, setAddEssayClass] = useState(false);
    interface DataType {
        key: number;
        classifyName: string;
        status: string;
    }
    const data: DataType[] = [
        {
            key: 1,
            classifyName: '美食',
            status: "正常",
        },
    ];

    const columns: ColumnsType<DataType> = [
        {
            title: '美食',
            dataIndex: 'classifyName',
            key: 'classifyName',
        },
        {
            title: '状态',
            key: 'tags',
            render: (_, record) => (
                <Space size="middle">
                    <div className='EsCla_tagsStyle'>{record.status}</div>
                </Space>
            ),
        },
        {
            title: '操作',
            key: 'action',
            render: (_, record) => (
                <Space size="middle">
                    <span className='EsCla_publicCursor' onClick={uploadus(record)}><FormOutlined /></span>
                    <span onClick={deleteus(record)}><DeleteOutlined /></span>
                </Space>
            ),
        },
    ];

    // 新增分类--提交按钮
    const AddClassifyBtn = (values: any) => {
        console.log('提交的数据:', values);
    };


    // 修改
    const uploadus = (record: any) => {
        return () => {
            console.log("点击了修改");
            console.log(record.key);
        }
    }
    // 删除
    const deleteus = (record: any) => {
        return () => {
            console.log("点击了删除");
            console.log(record.key);
        }
    }
    // 点击X关闭
    const handleCancel = () => {
        setAddEssayClass(false);
    };

    // 点击新增分类
    const usAddUser = () => {
        console.log("点击了新增分类");
        setAddEssayClass(true);
    }

    return (
        <div className='EsCla_Box'>
            <div className='EsCla_headerBox'>
                <div className='EsCla_headerBox_thread'></div>
                <div className='EsCla_headerBox_Tit'>&nbsp;&nbsp;&nbsp; 文章分类管理</div>
                <div className='EsCla_Add_moban'>
                    <div className='EsCla_addAdminBtn' onClick={usAddUser}>新增分类</div>
                    {/* 新增用户 */}
                    <Modal className='EsCla_addAdmin' footer={[null]} open={isAddEssayClass} onCancel={handleCancel}>
                        <div className='EsCla_headerBox'>
                            <div className='EsCla_headerBox_thread'></div>
                            <div className='EsCla_headerBox_Tit'>&nbsp;&nbsp;&nbsp;新增分类</div>
                        </div>
                        <div className='EsCla_addAdmin_Box'>
                            <Form
                                name="basic"
                                labelCol={{ span: 6 }}
                                wrapperCol={{ span: 18 }}
                                style={{ maxWidth: 600 }}
                                initialValues={{ remember: true }}
                                onFinish={AddClassifyBtn}
                                autoComplete="off"
                            >
                                <Form.Item label="分类名称" name="ClassifyName">
                                    <Input placeholder="例如：美食" />
                                </Form.Item>

                                <Form.Item label="状态" name="status">
                                    <Radio.Group>
                                        <Radio value="启用"> 启用 </Radio>
                                        <Radio value="禁用"> 禁用 </Radio>
                                    </Radio.Group>
                                </Form.Item>


                                <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                                    <Button className='us_btn' size="middle" type="primary" htmlType="submit">提交</Button>
                                </Form.Item>
                            </Form>
                        </div>
                    </Modal>
                </div>
            </div>

            <div className='EsCla_tableBox'>
                <Table columns={columns} dataSource={data} scroll={{ x: 'max-content', y: 550 }} />
            </div>
        </div>
    )
}

export default EssayClassifyManag;