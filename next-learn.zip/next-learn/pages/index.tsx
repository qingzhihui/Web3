import type { NextPage } from "next";
import Head from "next/head";
import Image from "next/image";
import Link from "next/link";
import styles from "../styles/Home.module.css";

const Home: NextPage = () => {
  return (
    <div className={styles.container}>
      {/* <ul>
        {[1, 2, 3, 4, 5].map((id) => (
          <li key={id}>
            <Link href={`/user/${id}`}>
              <a>user{id}</a>
            </Link>
          </li>
        ))}
      </ul> */}
    </div>
  );
};

export default Home;
