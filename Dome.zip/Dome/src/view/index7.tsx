import React, { useEffect, useState } from "react";
import PromisePool from "@supercharge/promise-pool";
import { PokemonList, getPokemon, getPokemonList } from "@/hooks/getPokemon";

const Index = () => {
  const [data, setData] = useState<any>([]);
  useEffect(() => {
    async function getData() {
      try {
        const list: any = await getPokemonList();
        //#region
        // 1.
        // list.results.slice(0, 10).forEach(async (listItem: any) => {
        //   console.log(listItem);
        //   const pokemon = await getPokemon(listItem.url);
        //   console.log(pokemon.name);
        // });

        // 2.
        // list.results.reduce(async (pr: any, pokemon: any) => {
        //   await pr;
        //   return getPokemon(pokemon.url).then((res) => {
        //     console.log(res.name);
        //   });
        // }, Promise.resolve(undefined));

        // 3.
        // for (const listItem of list.results) {
        //   const pokemon = await getPokemon(listItem.url);
        //   console.log(pokemon.name);
        // }

        // 4.
        // const data = await Promise.all(
        //   list.results
        //     .slice(0, 5)
        //     .map((pokemon: any) => getPokemon(pokemon.url))
        // );

        // 5.
        // withConcurrency(2) 切换并发性，所以我们将他提高到10，看看我们如何做我们可以有10个并发
        // 连接并且仍然可以工作，这使我们减少到大约3秒，所以我们有10个同时连接获取pokemon数据，这样我们就
        // 不会溢出我们管理连接的能力，但我们也可以更快的获取数据，这很好
        //#endregion
        const { results } = await PromisePool.withConcurrency(10)
          .for(list.results)
          .process(async (data: any) => {
            return await getPokemon(data.url);
          });
        console.log(results.map((p) => p.name));
        setData(results.map((p) => p.name));
      } catch (error) {
        console.log(error);
      }
    }
    getData();
  }, []);
  return (
    <div>
      <ul>
        {data.map((item: any, index: number) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
};

export default Index;

// yarn add ts-jest jest -D
// npm i @supercharge/promise-pool
//  yarn add @types/jest -D
