// 接口

interface StringArray {
  [index: number]: string;
}
const myArray: StringArray = ["a", "b"];
const sercondItem = myArray[0];

interface TestString {
  [props: string]: number;
}

let testString: TestString = {
  x: 100,
  y: 200,
  a: 300,
  // b:"1"
};

// string 和 number 并存的情况

interface Animal {
  name: string;
}
interface Dog extends Animal {
  breed: string;
}
// 索引
interface NotOkay {
  [index: string]: number | string;
  length: number;
  name: string;
}

let ontOkay: NotOkay = {
  x: 100,
  length: 100,
  name: "fleix",
};

// 只读的索引签名

interface ReadonlyStringArray {
  readonly [index: number]: string;
}

let myArray2: ReadonlyStringArray = ["a", "b"];

// myArray2[0] = 'FLEIX'