import React from 'react'
import './index.scss'
import { DatePicker, Select } from 'antd';
const { RangePicker } = DatePicker;

export default function index() {
  return (
    <div className='hotdetails'>
      <div className='detailsone'>
        <div className='onetop'>
          <div className='imgsone'><img src={require('@/assets/image/gro.png')} alt="" /></div>
          <div className='deta'>
            <div className='aman'>Aman at Summer Palace</div>
            <div className='king'>King bed room</div>
            <div className='equipments'>
              <div className='equipment'><img src={require('@/assets/image/material.png')} alt="" />1 queen bed (1.8m wide)</div>
              <div className='equipment'><img src={require('@/assets/image/tabler.png')} alt="" />Sleeps two people</div>
              <div className='equipment'><img src={require('@/assets/image/mdi.png')} alt="" />50 square meters | 1st floor</div>
              <div className='equipment'><img src={require('@/assets/image/ic.png')} alt="" />Free wifi</div>
              <div className='equipment'><img src={require('@/assets/image/healthicons.png')} alt="" />Child care</div>
              <div className='equipment'><img src={require('@/assets/image/fluent.png')} alt="" />Free breakfast</div>
              <div className='equipment'><img src={require('@/assets/image/grommet.png')} alt="" />Swimming pool</div>
              <div className='equipment'><img src={require('@/assets/image/bi.png')} alt="" />Free parking</div>
            </div>
          </div>
          <div className='imgstwo'><img src={require('@/assets/image/am.png')} alt="" /></div>
        </div>
        <div className='onebottom'>
          <div className='dates'><RangePicker bordered={false} /></div>
          <div className='roomk'><img src={require('@/assets/image/park.png')} alt="" /><input type="number" />room</div>
        </div>
      </div>
      <div className='detailstwo'>
        <div className='twoinformation'>Guest Information</div>
        <div className='twoname'>The name of the guest must be exactly the same as the valid ID used at check-in.</div>
        <div className='twoinputs'>
          <div className='input'><input type="text" placeholder='Last name' /></div>
          <div className='input'><input type="text" placeholder='First & middle name' /></div>
          <div className='input'><input type="text" placeholder='Mail' /></div>
          <div className='input'>
            <Select
              defaultValue="lucy"
              style={{ width: 100 }}
              options={[
                {
                  value: 'lucy',
                  label: 'Lucy',
                },
              ]}
            />
            <input type="text" placeholder='Mobile phone' />
          </div>
        </div>
        <div className='twoadd'><img src={require('@/assets/image/symbols.png')} alt="" />Add new guests (optional)</div>
      </div>
      <div className='detailsthree'>
        <div className='threetitle'>Accommodation Policy</div>
        <div className='threepolicy'>
          <div className='policyone'>
            <div className='check'>Check in and check out</div>
            <div className='checkin'>Check-in after 15:00</div>
            <div>Check-out time before 12:00</div>
          </div>
          <div className='policytwo'>
            <div className='check'>Children and extra beds</div>
            <div>The hotel allows travelers to stay with children</div>
          </div>
          <div className='policythree'>
            <div className='check'>important information</div>
            <div>All children, including infants and toddlers, must present a valid ID</div>
          </div>
        </div>
      </div>
      <div className='detailsfour'>
        <div className='fourtitle'>Price Details</div>
        <div className='fourinfa'>
          <div className='infaleft'>
            <div className='night'>
              <div className='title'>1 room x 1 night</div>
              <div className='money'>$ 3650</div>
            </div>
            <div className='taxes'>
              <Select
                defaultValue="Taxes and Surcharges"
                style={{ width: 200 }}
                options={[
                  {
                    value: 'Taxes and Surcharges',
                    label: 'Taxes and Surcharges',
                  },
                ]}
              />
              <div className='money'>$ 350</div>
            </div>
            <div className='charge'>
              <div className='title'>service charge</div>
              <div className='money'>$ 350</div>
            </div>
          </div>
          <div className='infaright'>
            <div className='total'>Total $ 4,000</div>
            <div className='select'>Select</div>
            <div className='submitting'>By submitting this order, you have read and agreed to the Terms of Use and Privacy of Anydoor Trip.</div>
          </div>
        </div>
      </div>
    </div>
  )
}
