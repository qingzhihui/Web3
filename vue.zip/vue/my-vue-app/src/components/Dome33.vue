<template>

</template>

<script setup>
// 台阶数量 ： n
//青蛙一次可以跳 1 级 或 2 级 有多少种方式跳到顶部

// 1级台阶 （1种）
//2级台阶 （2种）
//3级台阶 （3种）
//4级台阶 （5种）
//5级台阶 （8种）
//6级台阶 （13种）

// 情况数量：
// n=1:f(n) = 1
// n=2:f(n) = 2
// n>2:f(n) = f(n-1) + f(n-2)


function f(n) {
  if (n <= 0) {
    throw new Error('台阶数量必须大于0')
  }
  if (n <= 2) {
    return n;
  }
  var last1 = 2, last2 = 1;
  for (var i = 3; i <= n; i++) {
    // last1 = last1 + last2;
    // last2 = last1 - last2;

    last1 = last2 + (last2 = last1)
  }
  return last1
}
console.log(f(5));
</script>

<style>

</style>
