/* 函数签名*/

// 问题
// 1.我写的函数将来怎么调用？
// 2.我调用的这个函数当时是怎么写的？

//1. 设计 ：函数签名 》 函数名，参数列表，返回值
//     isPrime?   n?   boolean?   return?

//2. 实现
/*
* @parm {Number} n 待判断的数
* @return {Boolean} 判断的结果
* */

function isPrime(n) {

}