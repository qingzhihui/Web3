<template><div class="pisein">你好</div></template>

<script setup lang="ts">


</script>

<style>
.pisein {
    width: 100px;
    height: 100px;
    border-radius: 50px;
    filter: drop-shadow(0px 0px 10px black);
    background-color: aqua;
}
</style>
