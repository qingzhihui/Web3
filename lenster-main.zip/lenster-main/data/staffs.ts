export const mainnetStaffs = ['0x0d' /** @yoginth.lens */]

export const testnetStaffs = ['0x15' /** @yoginth.test */]
