interface Circle {
  kind: "circle";
  radius: number;
}

interface Square {
  kind: "square";
  sideLength: number;
}

interface Triangle {
  kind: "triangle";
  sideLength: number;
}

type Shape2 = Circle | Square | Triangle;

function getArea2(shape: Shape2) {
  switch (shape.kind) {
    case "circle":
      return Math.PI * shape.radius ** 2;
    case "square":
      return shape.sideLength ** 2;

    // default是上面两个判断都不成立才走到这来
    //  报错原因 never只能自己给自己 确认不能给他
    // default:
    //   const _exhaustiveCheck: never = shape;
    //   return _exhaustiveCheck;
  }
}
