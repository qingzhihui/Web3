import React, { useState, useEffect } from "react";
import axios from "axios";

interface Post {
  userId: number;
  id: number;
  title: string;
  body: string;
}

function App() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    const intervalId = setInterval(() => {
      async function fetchData() {
        setLoading(true);
        try {
          const response = await axios.get<Post[]>(
            "https://jsonplaceholder.typicode.com/posts"
          );
          setPosts((prevPosts) => [...prevPosts, ...response.data]); // 使用回调函数更新状态
        } catch (error) {
          setError("Error fetching data");
        }
        setLoading(false);
      }
      fetchData();
    }, 10000);

    return () => clearInterval(intervalId);
  }, []);

  const handleUpdatePost = (postId: number) => {
    // 找到要修改的帖子
    const postToUpdate = posts.find((post) => post.id === postId);
    if (postToUpdate) {
      // 使用回调函数更新状态
      setPosts((prevPosts) => {
        // 找到要修改的帖子在状态中的位置
        const index = prevPosts.findIndex((post) => post.id === postId);
        if (index === -1) {
          // 如果找不到要修改的帖子，则直接返回原状态
          return prevPosts;
        } else {
          // 将要修改的帖子替换为更新后的帖子，并返回新的状态
          const updatedPosts = [...prevPosts];
          updatedPosts.splice(index, 1, {
            ...postToUpdate,
            title: "Updated Title",
          });
          return updatedPosts;
        }
      });
    }
  };

  return (
    <div>
      <h1>Periodic Request Example</h1>
      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}
      {!loading && !error && (
        <>
          <h2>All Posts</h2>
          <ul>
            {posts.map((post) => (
              <li key={post.id}>
                <h3>{post.title}</h3>
                <p>{post.body}</p>
                <button onClick={() => handleUpdatePost(post.id)}>
                  Update
                </button>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

export default App;
