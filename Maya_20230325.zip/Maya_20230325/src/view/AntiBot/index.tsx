import React, { useEffect, useState } from "react";
import { Modal } from "antd";
import "./index.css";
import "./mobile.css";
import { useHistory } from "react-router-dom";
import AntiBotToken from "../../components/AntiBotToken";
import { Lineg, TokenNameDecimals } from "../../hooks/config";
import { ethers } from "ethers";
import { useTranslation, Trans } from "react-i18next";
import { isAddress } from '../../utils/address'
import InputError from '../../components/InputError'
const Antibot: React.FC = () => {
  const { t } = useTranslation();
  let history = useHistory();
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [inputVsalue, setInputValue] = useState<string>("");
  const [ULieng, setULieng] = useState<Lineg>({});
  const [NameShow, setNameShow] = useState<boolean>(false);
  const [errorshow, isErrorShow] = useState<boolean>(false)
  const [isexec, setIsExec] = useState<boolean>(false)
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const InputValueOnCheng = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue((InputValue: string) => {
      return (InputValue = e.target.value);
    });
    if (ethers.utils.isAddress(e.target.value)) {
      const Uline = await TokenNameDecimals(e.target.value);
      setULieng((ULiengprevState: Lineg) => {
        return (ULiengprevState = Uline);
      });
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = true);
      });
    } else {
      setNameShow((NameShowprevState: boolean) => {
        return (NameShowprevState = false);
      });
    }
  };
  const onClick = async (value: any) => {
    setInputValue((InputValue: string) => {
      return (InputValue = value);
    });
    const Uline = await TokenNameDecimals(value);
    setULieng((ULiengprevState: Lineg) => {
      return (ULiengprevState = Uline);
    });
    setNameShow((NameShowprevState: boolean) => {
      return (NameShowprevState = true);
    });
    setIsModalOpen(false);
  };
  const NextonCLick = () => {
    history.push({
      pathname: "/antibotPon",
      state: {
        inputValue: inputVsalue,
      },
    });
  };

  const judgeAddr = (value: string) => {
    if (isAddress(value)) {
      isErrorShow(false)
      setIsExec(true)
    } else {
      isErrorShow(true)
      setIsExec(false)
    }
  }

  useEffect(() => {
    if (isAddress(inputVsalue)) {
      // isErrorShow(false)
      setIsExec(true)
    } else {
      // isErrorShow(true)
      setIsExec(false)
    }
  }, [inputVsalue])
  // 渲染PC端的内容
  const renderPCAntiBot = () => {
    return (
      <div className="contentPC">
        <img
          src={require(`../../assets/image/paw.png`)}
          className="pawBgImage"
          alt=""
        />
        <div className="pageTitle">{`${t("Anti-Bot")}`}</div>
        <div className="contentCenter">
          <div className="antibot-reuqire">(*) {`${t("is required field.")}`}</div>
          <div className="contentCenterColumnOne">
            <div className="ColumnOneLeft">
              {`${t("Token address")}`} <span>*</span>
            </div>
            <div className="create-buttonAreaPC">
              <button onClick={() => {
                showModal();
              }}>
                {`${t("Create token")}`}
                <img
                  src={require(`../../assets/image/paw.png`)}
                  alt=""
                  className="createPawImage"
                />
              </button>
            </div>
          </div>
          <div className="contentCenterColumnTwo">
            <input
              placeholder={`${t("Please input token address")}`}
              value={inputVsalue || ""}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                InputValueOnCheng(e);
              }}
              style={{ borderColor: errorshow ? '#f14668' : '' }}
              onBlur={(e) => { judgeAddr(e.target.value) }}
            />
            {errorshow ? <InputError title="Invalid address" /> : ''}
            <div className="InputDesc">
              {`${t("Choose a token to integrate with Maya Anti-Bot.")}`}
            </div>
            <div className="InputDesc">
              {`${t("Check out the guide how to integrate Maya Anti-Bot for custom contract here:")}`}
              <a
                href="https://github.com/pinkmoonfinance/pink-antibot-guide"
                className="linkDesc"
                target="blank"
              >
                <div className="InputDesc">
                  https://github.com/pinkmoonfinance/pink-antibot-guide
                </div>
              </a>
            </div>
          </div>
          {NameShow === true ? (
            <div className="peilsiens">
              <div className="peilsiens_item">
                <div>{`${t("Name")}`}</div>
                <div>{ULieng.name}</div>
              </div>
              <div className="peilsiens_item">
                <div>{`${t("Symbol")}`}</div>
                <div>{ULieng.symbol}</div>
              </div>
              <div className="peilsiens_item">
                <div>{`${t("Decimals")}`}</div>
                <div>{ULieng.decimals}</div>
              </div>
              <div className="buttonArea">
                {isexec ? <button
                  onClick={() => {
                    NextonCLick();
                  }}
                >
                  {`${t("Next")}`}
                </button> : <button
                  style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
                >
                  {`${t("Next")}`}
                </button>}
              </div>
            </div>
          ) : (
            ""
          )}
          {/* <div className="buttonArea">
            <button
              onClick={() => {
                showModal();
              }}
            >
              {`${t("Create token")}`}
              <img
                src={require(`../../assets/image/paw.png`)}
                alt=""
                className="createPawImage"
              />
            </button>
          </div> */}
        </div>
        <div className="descContent">
          {`${t("Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published.")}`}
        </div>
      </div >
    );
  };
  const renderMobileAntibot = () => {
    return (
      <div className="contentMobile">
        <div className="contentCenter">
          <div className="contentCenterColumnOne">
            <div className="antibot-reuqire">(*) {`${t("is required field.")}`}</div>
            <div className="ColumnOneLeft">
              <div>{`${t("Token address")}`} <span>*</span></div>
              <div className="create-buttonArea">
                <button onClick={() => {
                  showModal();
                }}>
                  {`${t("Create token")}`}
                  <img
                    src={require(`../../assets/image/paw.png`)}
                    alt=""
                    className="createPawImage"
                  />
                </button>
              </div>
            </div>
          </div>
          <div className="contentCenterColumnTwo">
            <input
              placeholder={`${t("Please input token address")}`}
              value={inputVsalue || ""}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                InputValueOnCheng(e);
              }}
              style={{ borderColor: errorshow ? '#f14668' : '' }}
              onBlur={(e) => { judgeAddr(e.target.value) }}
            />
            {errorshow ? <InputError title="Invalid address" /> : ''}
          </div>
          <div className="InputDesc">
            {`${t("Choose a token to integrate with Maya Anti-Bot.")}`}
          </div>
          <div className="InputDesc">
            {`${t("Check out the guide how to integrate Maya Anti-Bot for custom contract here:")}`}
          </div>
          <a
            href="https://github.com/pinkmoonfinance/pink-antibot-guide"
            className="linkDesc"
            target="blank"
          >
            <div className="InputDesc">
              https://github.com/pinkmoonfinance/pink-antibot-guide
            </div>
          </a>
          { NameShow === true ? (
            <div className="peilsiens">
              <div className="peilsiens_item">
                <div>{`${t("Name")}`}</div>
                <div>{ULieng.name}</div>
              </div>
              <div className="peilsiens_item">
                <div>{`${t("Symbol")}`}</div>
                <div>{ULieng.symbol}</div>
              </div>
              <div className="peilsiens_item">
                <div>{`${t("Decimals")}`}</div>
                <div>{ULieng.decimals}</div>
              </div>
              <div className="buttonArea">
                {isexec ? <button
                  onClick={() => {
                    NextonCLick();
                  }}
                >
                  {`${t("Next")}`}
                </button> : <button
                  style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
                >
                  {`${t("Next")}`}
                </button>}
              </div>
              {/* <div className="buttonArea">
                {isexec ? <button
                  onClick={() => {
                    NextonCLick();
                  }}
                >
                  {`${t("Next")}`}
                </button> : <button
                  style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
                >
                  {`${t("Next")}`}
                </button>}
              </div> */}
            </div>
          ) : (
            ""
          )}
          {/* <div className="buttonArea">
            {isexec ? <button
              onClick={() => {
                NextonCLick();
              }}
            >
              {`${t("Next")}`}
            </button> : <button
              style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
            >
              {`${t("Next")}`}
            </button>}
            <button onClick={() => {
              showModal();
            }}>
              {`${t("Create token")}`}
              <img
                src={require(`../../assets/image/paw.png`)}
                alt=""
                className="createPawImage"
              />
            </button>
          </div> */}
        </div>
        <div className="descContentMobile">
          {`${t("Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published.")}`}
        </div>
        <img
          src={require(`../../assets/image/paw.png`)}
          className="pawImage"
          alt=""
        />
      </div>
    );
  };

  return (
    <div className="antibot">
      <img
        src={require(`../../assets/image/Antibot-cat.png`)}
        alt=""
        className="bottomCatPC"
      />
      <img
        src={require(`../../assets/image/Antibot-cat.png`)}
        alt=""
        className="bottomCatMobile"
      />
      {renderPCAntiBot()}
      {renderMobileAntibot()}
      <Modal
        title={`${t("Create token")}`}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={null}
      >
        <div className="Basic_Model">
          <AntiBotToken Createclick={onClick} />
        </div>
      </Modal>
    </div>
  );
};

export default Antibot;
