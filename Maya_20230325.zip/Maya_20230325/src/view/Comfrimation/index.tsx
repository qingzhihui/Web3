import { useState, useEffect } from "react";
import "./index.scss";
import type { RadioChangeEvent } from "antd";
import { Radio, Table } from "antd";
import { useHistory } from "react-router-dom";
import { useTranslation, Trans } from "react-i18next";
import MultiSenderheader from "../../components/MultiSenderheader";
import {
  ILisnt,
  MultiSenderABI,
  MultiSenderAddress,
  Quantitgroup,
  TextareaData,
} from "../../hooks/MultiSender";
import { ethers } from "ethers";
import { InstancedContract } from "../../hooks/config";
import { ArrayspLitting } from "../../hooks/Comfrimation";

const Comfrimation = (props: any) => {
  const { t } = useTranslation();
  let history = useHistory();
  const [value, setValue] = useState<number>(1);
  const [Numier, setNumier] = useState<string>("");
  const [dataSource, setDataSource] = useState<ILisnt[]>([]);
  const [ParameterData, setParameterData] = useState([]);
  const [tokenaddress, setTokenAddress] = useState<string>("");
  const [decimalsCal, setDecimalsCal] = useState<number>(0);
  const [finishState, setFinishState] = useState<boolean>(false);
  const [usrl, setUsrl] = useState<string>("");

  const onChange = (e: RadioChangeEvent) => {
    setValue(e.target.value);
  };
  const ProcessOnClick = async () => {
    const { QuantityArray, WalletArray } = TextareaData(ParameterData, 18);
    const TotalQuantity = Quantitgroup(QuantityArray);
    const etherTx = await (InstancedContract(
      MultiSenderAddress,
      MultiSenderABI
    ) as any).multisendEther(WalletArray, QuantityArray, {
      value: TotalQuantity.toString(),
    });
    await etherTx.wait()
    setFinishState(true);
    setUsrl(`https://testnet.bscscan.com/tx/${etherTx.hash}`);
  };
  const TokensOnClick = async () => {
    const { QuantityArray, WalletArray } = TextareaData(ParameterData, decimalsCal);
    var pleuTike: boolean = true;
    if (value === 1) {
      pleuTike = true;
    } else {
      pleuTike = false;
    }
    const tokenTx = await (InstancedContract(
      MultiSenderAddress,
      MultiSenderABI
    ) as any).multisendToken(tokenaddress, pleuTike, WalletArray, QuantityArray, {
      value: 0,
    });
    await tokenTx.wait()
    setFinishState(true);
    setUsrl(`https://testnet.bscscan.com/tx/${tokenTx.hash}`);
  };

  const columns = [
    {
      title: `${t("Address")}`,
      dataIndex: "address",
      key: "address",
    },
    {
      title: `${t("Amount")}`,
      dataIndex: "binale",
      key: "binale",
    },
  ];
  useEffect(() => {
  }, [finishState]);
  useEffect(() => {
    if (props.location.state != undefined) {
      const { dotData, decimals } = props.location.state;
      console.log(decimals);
      setDecimalsCal(decimals);
      const { totalAmount } = TextareaData(dotData, decimalsCal);
      const arrAen = ArrayspLitting(dotData);
      setDataSource((DataSourceprevState: any) => {
        return (DataSourceprevState = arrAen);
      });
      setParameterData((ParameterDataprevState: any) => {
        return (ParameterDataprevState = dotData);
      });
      setNumier((NumierprevState: any) => {
        return (NumierprevState = totalAmount.toString());
      });
      setTokenAddress((TokenAddressprevState: any) => {
        return (TokenAddressprevState = props.location.state.address);
      });
    }
  }, []);
  const { balance, dotData, symbol, btenshow } = props.location.state;
  return (
    <div className="ation">
      <div className="comfrimation">
        <MultiSenderheader setp={2} />
        <div className="count">
          <div className="comfrimation_top">
            <div className="list">
              <div>{`${t("Total address")}`}</div>
              <div>{dotData.length}</div>
            </div>
            <div className="list">
              <div>{`${t("Total amount to send")}`}</div>
              <div className="fen">{Numier}{" "}{symbol === "" ? "BNB" : symbol}</div>
            </div>
            <div className="list">
              <div>{`${t("Number of transaction")}`}</div>
              <div>{dotData.length}</div>
            </div>
            <div className="list">
              <div>{`${t("Your")}`} {symbol === "" ? "BNB" : symbol} {`${t("balance")}`}</div>
              <div className="lan">
                {balance} {symbol === "" ? "BNB" : symbol}
              </div>
            </div>
            <div className="list">
              <div>{`${t("Token to send")}`}</div>
              <div className="fen">{symbol === "" ? "BNB" : symbol}</div>
            </div>
          </div>
          <div className="LisnueTable">
            <Table
              bordered={false}
              scroll={{ x: 800, y: 400 }}
              dataSource={dataSource}
              columns={columns}
            />
          </div>
          <div className="comfrimation_buttom">
            {symbol === "" ? (
              ""
            ) : (
              <div className="selsect">
                <Radio.Group onChange={onChange} value={value}>
                  <Radio value={1}>{`${t("Safe mode")}`}</Radio>
                  <Radio value={2}>{`${t("Unsafe mode")}`}</Radio>
                </Radio.Group>
              </div>
            )}
            {
              finishState === true ? ("") : (
                <div className="buttons">
                  <button
                    className="back"
                    onClick={() => {
                      history.push("/MultiSender");
                    }}
                  >
                    {`${t("Back")}`}
                  </button>
                  {btenshow === 1 ? (
                    <button
                      className="process"
                      onClick={() => {
                        ProcessOnClick();
                      }}
                    >
                      {`${t("Send")}`}
                    </button>
                  ) : (
                    <button
                      className="process"
                      onClick={() => {
                        TokensOnClick();
                      }}
                    >
                      {`${t("Send")}`}
                    </button>
                  )}
                </div>)
            }
            {
              finishState === true ? (
                <div>
                  <a href={usrl} target="_blank">
                    {`${t("Link")}`}
                  </a>
                </div>) : ("")
            }
          </div>
        </div>
      </div>
    </div>
  );
};
export default Comfrimation;
