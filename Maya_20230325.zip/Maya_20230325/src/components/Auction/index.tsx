import React, { useState } from "react";
import { Radio, Space } from "antd";
import type { RadioChangeEvent } from "antd";
import { useTranslation, Trans } from "react-i18next";
import "../../styles/index.css";
import "../../styles/mobile.css";

const Auction: React.FC = () => {
  const { t } = useTranslation();
  const [currency, setCurrency] = useState();
  const [Options, setOptions] = useState();
  const [Listing, setListing] = useState();
  const [content, setContent] = useState("launchpad");
  const ChangeCurrency = (e: RadioChangeEvent) => {
    setCurrency(e.target.value);
  };
  const ChangeFeeOptions = (e: RadioChangeEvent) => {
    setOptions(e.target.value);
  };
  const ChangeListingOptions = (e: RadioChangeEvent) => {
    setListing(e.target.value);
  };
  const renders = (contents: string) => {
    setContent(contents);
  };
  return (
    <div className="create" style={{ height: "600px" }}>
      <div className="create-title">{`${t("Create dutch auction ")}`}</div>
      <div className="require-title">(*){`${t("is required field")}`}.</div>
      <div className="addressbtn">
        <div className="token-addr">
          {`${t("Create dutch auction ")}`} <span style={{ color: "#F95192" }}> *</span>
        </div>
        <button className="create-btn">{`${t("Create token")}`}</button>
      </div>
      <input placeholder="xxx" className="addrInput" />
      <div className="create-fee">{`${t("Pool creation fee")}`}: 0 BNB</div>
      <div className="currency-text">{`${t("Currency")}`}</div>
      <Radio.Group onChange={ChangeCurrency} value={currency}>
        <Space direction="vertical">
          <Radio value={"BNB"}>BNB</Radio>
          <Radio value={"BUSD"}>BUSD</Radio>
          <Radio value={"USDT"}>USDT</Radio>
          <Radio value={"USDC"}>USDC</Radio>
        </Space>
      </Radio.Group>
      <div className="paywith-text">{`${t("Users will pay with BNB for your token")}`}</div>
      <div className="fee-option">{`${t("Fee Options")}`}</div>
      <Radio.Group onChange={ChangeFeeOptions} value={Options}>
        <Space direction="vertical">
          <Radio value={"5% BNB raised only"}>
            {`${t("5% BNB raised only")}`}{" "}
            <span style={{ color: "#3298DC" }}>(Recommended)</span>
          </Radio>
          <Radio value={"2% BNB raised + 2% token sold"}>
            {`${t("2% BNB raised + 2% token sold")}`}
          </Radio>
        </Space>
      </Radio.Group>
      {/* <div className='listing-option'>Listing Options</div>
              <Radio.Group onChange={ChangeListingOptions} value={Listing}>
                  <Space direction="vertical">
                      <Radio value={"Auto Listing"}>Auto Listing</Radio>
                      <Radio value={"Manual listing"}>Manual listing</Radio>
                  </Space>
              </Radio.Group> */}
      {/* <div className='tip-yellowRectangle'>For auto listing, after you finalize the pool your token will be auto listed on DEX.</div> */}
      <button className="nextbtn">{`${t("Next")}`}</button>
    </div>
  );
};

export default Auction;
