<template>
</template>

<script setup>

layBtn.onClick = function () {
//  蒙城显示
  posterModal.style.display = "block";
//  视频播放进度归零
  video.currentTime = 0;
  video.play();
  //滚轮事件
  window.addEventListener('wheel', wheelHandler, {
    passive: false
  })
}

function wheelHandler(e) {
  e.preventDefault();
}


</script>

<style>
</style>
