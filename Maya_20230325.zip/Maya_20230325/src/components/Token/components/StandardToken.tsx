import React, { useState, useEffect } from "react";
import { Checkbox, Input, Form } from "antd";
import { ethers, BigNumber } from "ethers";
import type { CheckboxChangeEvent } from "antd/es/checkbox";
import "../../../styles/index.css";
import "../../../styles/mobile.css";
import styles from "../index.module.css";
import { ConterTokenList, DigitalInput, DisableDoubleCharacters } from "../../../hooks/Token";
import { ConterTokenItem } from "../../../state/TokenState";
import ButtonLoading from '../../ButtonLoading'
import { useTranslation, Trans } from "react-i18next";
import { posInvFormat } from "../../../utils/floatFormat";
import { Constan } from "../../../config/constants/constants";
import { FormatUnitsConver, InstancedContract } from "../../../hooks/config";
import InputError from '../../InputError'
import { StandardTokenError } from '../../../hooks/Errorhandle'
import LockInfo from "../../../view/LockInfo";
import { StandardTokenErrorInitState } from "../../../state/StandardTokenErrorState";
declare const window: Window & { ethereum: any };

interface StandardProps {
  Token: string;
  StandardonAdd: (e: any) => void;
  loading: boolean;
}
const StandardToken: React.FC<StandardProps> = ({ Token, StandardonAdd, loading }) => {
  const { t } = useTranslation();
  const [standarNer, setStandarNer] = useState<ConterTokenList>(ConterTokenItem);
  const [flatFeeShow, setFlatFeeShow] = useState("");

  // 定义错误类型
  const [standardTokenError, setStandardTokenError] = useState<StandardTokenError>(StandardTokenErrorInitState)

  // 开启或者关闭错误提示
  const setError = (key: string, value: boolean) => {
    setStandardTokenError((olddata: StandardTokenError) => {
      return {
        ...olddata,
        [key]: value
      }
    })
  }
  const isCreate = () => {
    if (!standardTokenError.NameCharactersError
      && !standardTokenError.NameBlankError
      && !standardTokenError.SymbolCharactersError
      && !standardTokenError.SymbolBlankError
      && !standardTokenError.DecimalsBlankError
      && !standardTokenError.DecimalsMinError
      && !standardTokenError.DecimalsMaxError
      && !standardTokenError.TotalSupplyBlankError
      && !standardTokenError.TotalSupplyAmountError
      && standarNer.Name
      && standarNer.Symbol
      && standarNer.Decimals
      && standarNer.Supply
    ) {
      return true
    } else {
      return false
    }
  }

  const [form] = Form.useForm();
  const StandardCreateOnClikc = () => {
    StandardonAdd({
      TokenPunie: Token,
      StandsData: standarNer,
    });
  };
  const NameValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DisableDoubleCharacters(e);
    if (inputChange !== undefined) {
      setStandarNer((olddata: ConterTokenList) => {
        if (inputChange === '') {
          setError("NameBlankError", true)
        } else {
          setError("NameBlankError", false)
        }
        if (inputChange && inputChange.length < 2) {
          setError("NameCharactersError", true)
        } else {
          setError("NameCharactersError", false)
        }
        return {
          ...olddata,
          Name: inputChange,
        };
      })
    }
  };
  const SymbolValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DisableDoubleCharacters(e);
    if (inputChange !== undefined) {
      setStandarNer((olddata: ConterTokenList) => {
        if (inputChange === '') {
          setError("SymbolBlankError", true)
        } else {
          setError("SymbolBlankError", false)
        }
        if (inputChange && inputChange.length < 2) {
          setError("SymbolCharactersError", true)
        } else {
          setError("SymbolCharactersError", false)
        }
        return {
          ...olddata,
          Symbol: inputChange,
        };
      });
    }
  };
  const DecimalsValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    if (inputChange !== undefined) {
      setStandarNer((olddata: ConterTokenList) => {
        if (inputChange === '') {
          setError("DecimalsBlankError", true)
        } else {
          setError("DecimalsBlankError", false)
        }
        if (inputChange && Number(inputChange) < 2) {
          setError("DecimalsMinError", true)
        } else {
          setError("DecimalsMinError", false)
        }
        if (inputChange && Number(inputChange) > 18) {
          setError("DecimalsMaxError", true)
        } else {
          setError("DecimalsMaxError", false)
        }
        if (standarNer.Supply !== undefined && standarNer.Supply !== '' && inputChange !== undefined) {
          if (BigNumber.from(10).pow(Number(inputChange)).mul(BigNumber.from(standarNer.Supply)).gte(BigNumber.from(10).pow(33))) {
            setError("TotalSupplyAmountError", true)
          } else {
            setError("TotalSupplyAmountError", false)
          }
        }
        if (standarNer.Supply === '' || inputChange === '') {
          setError("TotalSupplyAmountError", false)
        }
        return {
          ...olddata,
          Decimals: inputChange,
        };
      });
    }
  };
  const SupplyValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setStandarNer((olddata: ConterTokenList) => {
      if (inputChange === '') {
        setError("TotalSupplyBlankError", true)
      } else {
        setError("TotalSupplyBlankError", false)
      }
      if (inputChange !== undefined && inputChange !== '' && standarNer.Decimals !== undefined) {
        if (BigNumber.from(10).pow(Number(standarNer.Decimals)).mul(BigNumber.from(inputChange)).gte(BigNumber.from(10).pow(33))) {
          setError("TotalSupplyAmountError", true)
        } else {
          setError("TotalSupplyAmountError", false)
        }
      }
      if (standarNer.Decimals === '' || inputChange === '') {
        setError("TotalSupplyAmountError", false)
      }
      return {
        ...olddata,
        Supply: inputChange
      };
    });
  };
  const NameBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("NameBlankError", true)
      } else {
        setError("NameBlankError", false)
      }
      if (e.target.value && e.target.value.length < 2) {
        setError("NameCharactersError", true)
      } else {
        setError("NameCharactersError", false)
      }
    }
  };
  const SymbolBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("SymbolBlankError", true)
      } else {
        setError("SymbolBlankError", false)
      }
      if (e.target.value && e.target.value.length < 2) {
        setError("SymbolCharactersError", true)
      } else {
        setError("SymbolCharactersError", false)
      }
    }
  };
  const DecimalsBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("DecimalsBlankError", true)
      } else {
        setError("DecimalsBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 2) {
        setError("DecimalsMinError", true)
      } else {
        setError("DecimalsMinError", false)
      }
      if (e.target.value && Number(e.target.value) > 18) {
        setError("DecimalsMaxError", true)
      } else {
        setError("DecimalsMaxError", false)
      }
      if (standarNer.Supply !== undefined && standarNer.Supply !== '' && e.target.value !== undefined) {
        if (BigNumber.from(10).pow(Number(e.target.value)).mul(BigNumber.from(standarNer.Supply)).gte(BigNumber.from(10).pow(33))) {
          setError("TotalSupplyAmountError", true)
        } else {
          setError("TotalSupplyAmountError", false)
        }
      }
      if (standarNer.Supply === '' || e.target.value === '') {
        setError("TotalSupplyAmountError", false)
      }
    }
  };
  const SupplyBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      setError("TotalSupplyBlankError", true)
    } else {
      setError("TotalSupplyBlankError", false)
    }
    if (e.target.value !== undefined && e.target.value !== '' && standarNer.Decimals !== undefined) {
      if (BigNumber.from(10).pow(Number(standarNer.Decimals)).mul(BigNumber.from(e.target.value)).gte(BigNumber.from(10).pow(33))) {
        setError("TotalSupplyAmountError", true)
      } else {
        setError("TotalSupplyAmountError", false)
      }
    }
    if (standarNer.Decimals === '' || e.target.value === '') {
      setError("TotalSupplyAmountError", false)
    }
  }
  const getCreateStandardTokenFlatFee = async () => {
    const StandardTokenFacctoryContract = InstancedContract(
      Constan[0].Address,
      Constan[0].Condebi
    ) as any;
    const flatFee = await StandardTokenFacctoryContract.flatFee();
    setFlatFeeShow(FormatUnitsConver(flatFee.toString(), 18))
  }
  useEffect(() => { }, [flatFeeShow]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        getCreateStandardTokenFlatFee();
      }
    }
  }, []);
  return (
    <div className="StandardToken">
      <Form form={form}>
        <div className={styles.tulieng}>
          <div className={styles.createfee}>{`${t("Token creation fee:")}`} {flatFeeShow || 0} BNB</div>
          <div className={styles.require}>{`${t("Name")}`}<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder={`${t("Ex: Ethereum")}`}
            className={styles.addrInput}
            value={standarNer.Name as string}
            style={{ borderColor: standardTokenError.NameBlankError || standardTokenError.NameCharactersError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              NameValueChange(e);
            }}
            onBlur={(e) => {
              NameBlurChange(e);
            }}
          />
        </div>
        {standardTokenError.NameBlankError ? <InputError title="Name cannot be blank" /> : ''}
        {standardTokenError.NameCharactersError ? <InputError title="Name must be at least 2 characters" /> : ''}
        <div className={styles.tulieng}>
          <div className={styles.require}>{`${t("Symbol")}`}<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder={`${t("Ex: ETH")}`}
            className={styles.addrInput}
            value={standarNer.Symbol as string}
            style={{ borderColor: standardTokenError.SymbolBlankError || standardTokenError.SymbolCharactersError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              SymbolValueChange(e);
            }}
            onBlur={(e) => {
              SymbolBlurChange(e);
            }}
          />
        </div>
        {standardTokenError.SymbolBlankError ? <InputError title="Symbol cannot be blank" /> : ''}
        {standardTokenError.SymbolCharactersError ? <InputError title="Symbol must be at least 2 characters" /> : ''}
        <div className={styles.tulieng}>
          <div className={styles.require}>{`${t("Decimals")}`}<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder={`${t("Ex: 18")}`}
            className={styles.addrInput}
            value={standarNer.Decimals as string}
            style={{ borderColor: standardTokenError.DecimalsBlankError || standardTokenError.DecimalsMinError || standardTokenError.DecimalsMaxError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              DecimalsValueChange(e);
            }}
            onBlur={(e) => {
              DecimalsBlurChange(e);
            }}
          />
        </div>
        {standardTokenError.DecimalsBlankError ? <InputError title="Decimals cannot be blank" /> : ''}
        {standardTokenError.DecimalsMinError ? <InputError title="Decimals must be greater than or equal to 2" /> : ''}
        {standardTokenError.DecimalsMaxError ? <InputError title="Decimals must be less than or equal to 18" /> : ''}
        <div className={styles.tulieng}>
          <div className={styles.require}>{`${t("Total supply")}`}<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder={`${t("Ex: 100000000000")}`}
            className={styles.addrInput}
            value={standarNer.Supply as string}
            style={{ borderColor: standardTokenError.TotalSupplyBlankError || standardTokenError.TotalSupplyAmountError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              SupplyValueChange(e);
            }}
            onBlur={(e) => {
              SupplyBlurChange(e);
            }}
          />
        </div>
        {standardTokenError.TotalSupplyBlankError ? <InputError title="Total supply cannot be blank" /> : ''}
        {standardTokenError.TotalSupplyAmountError ? <InputError title="Invalid total supply" /> : ''}
        <div className={styles.tulieng}>
          <Checkbox
            onChange={(e: CheckboxChangeEvent) => {
              setStandarNer((olddata: ConterTokenList) => {
                return {
                  ...olddata,
                  UseAntiBot: e.target.checked,
                };
              });
            }}
            checked={standarNer.UseAntiBot as boolean}
            style={{ lineHeight: "32px" }}
          >
            {`${t("Implement Maya Anti-Bot System?")}`}
          </Checkbox>
        </div>
        {isCreate() ? <button
          onClick={() => {
            StandardCreateOnClikc();
          }}
          className={`nextbtn ${styles.nextbtn}`}
        >
          {loading ? <ButtonLoading /> : ''}{`${t("Create token")}`}
        </button> : <button
          style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
          className={`nextbtn ${styles.nextbtn}`}
        >
          {`${t("Create token")}`}
        </button>}
      </Form>
    </div>
  );
};

export default StandardToken;
