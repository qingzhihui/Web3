import { useState } from 'react';
import Child from './components/Child';

const Parent = () => {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h1>Parent Component</h1>
      <Child count={count} />
      <button onClick={() => setCount(count + 1)}>Increment Count</button>
    </div>
  );
};
export default Parent;