// Componet/Componet.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    propArray: {
      type: Array,
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    selectShow: false,//初始option不显示
    nowText: "请选择",//初始内容
    selectArray: [{
      "id": "6",
      "text": "USD"
    }, {
      "id": "2",
      "text": "JPY"
    }, {
      "id": "3",
      "text": "THP"
    }, {
      "id": "4",
      "text": "EUR"
    }, {
      "id": "5",
      "text": "GBP"
    }, {
      "id": "6",
      "text": "HKD"
    }]
  },
  /**
   * 组件的方法列表
   */
  methods: {
    selectToggle: function () {
      var nowShow = this.data.selectShow;
      this.setData({
        selectShow: !nowShow
      })
    },
    SelectBInd() {
      this.triggerEvent('SelectBInd', {
        Tere: this.data.nowText,
        state: true
      })
    },
    setText: function (e: any) {
      this.setData({
        nowText: e.currentTarget.dataset.name,
        selectShow: !this.data.selectShow
      })
      this.triggerEvent('SelectBInd', {
        Tere: e.currentTarget.dataset.nam,
        state: true
      })
    }
  },
  attached() {
    this.setData({
      nowText: this.data.selectArray[0].text
    })
    this.triggerEvent('SelectBInd', {
      Tere: this.data.selectArray[0].text,
      state: false
    })
  }
})