import React, { useState } from 'react'
import './index.scss'
import group2 from '../../assets/image/group2.png'
import Frame from '../../assets/image/Frame.png'
import { useTranslation, Trans } from "react-i18next";
export default function Index() {
  const [datesty, setDatesty] = useState<number>(1)
  const datestyle = (num: number) => {
    setDatesty(num)
  }
  const { t } = useTranslation();
  return (
    <div className='leaderboard'>
      <div className='header'>
        <div className='header_content'>
          <div className='left'>
            <div className='top'>{`${t("Total success this week")}`}</div>
            <div className='bottom'>6</div>
          </div>
          <div className='middle'></div>
          <div className='right'>
            <div className='top'>{`${t("Total raised this week")}`}</div>
            <div className='bottom'>$244.8K</div>
          </div>
        </div>
      </div>
      <div className='footer'>
        <div className='scll'>
          <div className='footer_header'>
            <div className={`date ${datesty === 1 ? "selected" : ""}`} onClick={() => { datestyle(1) }}>Week 47/2022</div>
            <div className={`date ${datesty === 2 ? "selected" : ""}`} onClick={() => { datestyle(2) }}>Week 47/2022</div>
            <div className={`date ${datesty === 3 ? "selected" : ""}`} onClick={() => { datestyle(3) }}>Week 47/2022</div>
            <div className={`date ${datesty === 4 ? "selected" : ""}`} onClick={() => { datestyle(4) }}>Week 47/2022</div>
            <div className={`date ${datesty === 5 ? "selected" : ""}`} onClick={() => { datestyle(5) }}>Week 47/2022</div>
            <div className={`date ${datesty === 6 ? "selected" : ""}`} onClick={() => { datestyle(6) }}>Week 47/2022</div>
            <div className={`date ${datesty === 7 ? "selected" : ""}`} onClick={() => { datestyle(7) }}>Week 47/2022</div>
            <div className={`date ${datesty === 8 ? "selected" : ""}`} onClick={() => { datestyle(8) }}>Week 47/2022</div>
          </div>
        </div>

        <div className='footer_item'>
          <div className='item-left'>
            <div className='number'>1</div>
            <div className='portrait'><img src={Frame} alt="" /></div>
            <div className='information'>
              <div className='information_top'>
                <div className='name'>Christmas Floki</div>
                <div className='region'>FLOC</div>
              </div>
              <div className='information_bottom'>
                <div className='bnb'>300 BNB</div>
                <div className='time'>
                  <div className='title'>{`${t("Listing time")}`}:</div>
                  <div className='time_date'>2022.11.21 19:06</div>
                </div>
              </div>
            </div>
          </div>
          <div className='item-right'>
            <div className='percentage progress'><div className='text'>50%</div></div>
            <div className='but'>{`${t("View pool")}`}</div>
          </div>
        </div>
        <div className='footer_item'>
          <div className='item-left'>
            <div className='number'>2</div>
            <div className='portrait'><img src={Frame} alt="" /></div>
            <div className='information'>
              <div className='information_top'>
                <div className='name'>Multinet</div>
                <div className='region'>MNC</div>
              </div>
              <div className='information_bottom'>
                <div className='bnb'>141.95388214294496 BNB</div>
                <div className='time'>
                  <div className='title'>{`${t("Listing time")}`}:</div>
                  <div className='time_date'>2022.11.21 12:58</div>
                </div>
              </div>
            </div>
          </div>
          <div className='item-right'>
            <div className='percentage progress'><div className='text'>50%</div></div>
            <div className='but'>{`${t("View pool")}`}</div>
          </div>
        </div>
        <div className='footer_item'>
          <div className='item-left'>
            <div className='number'>3</div>
            <div className='portrait'><img src={Frame} alt="" /></div>
            <div className='information'>
              <div className='information_top'>
                <div className='name'>REGENT COIN</div>
                <div className='region'>REGENT</div>
              </div>
              <div className='information_bottom'>
                <div className='bnb'>137.96047364481305 BNB</div>
                <div className='time'>
                  <div className='title'>{`${t("Listing time")}`}:</div>
                  <div className='time_date'>2022.11.21 09:03</div>
                </div>
              </div>
            </div>
          </div>
          <div className='item-right'>
            <div className='percentage progress'><div className='text'>50%</div></div>
            <div className='but'>{`${t("View pool")}`}</div>
          </div>
        </div>
        <div className='footer_item'>
          <div className='item-left'>
            <div className='number'>4</div>
            <div className='portrait'><img src={Frame} alt="" /></div>
            <div className='information'>
              <div className='information_top'>
                <div className='name'>SoccerN</div>
                <div className='region'>SON</div>
              </div>
              <div className='information_bottom'>
                <div className='bnb'>133.4211758067575 BNB</div>
                <div className='time'>
                  <div className='title'>{`${t("Listing time")}`}:</div>
                  <div className='time_date'>2022.11.21 12:00</div>
                </div>
              </div>
            </div>
          </div>
          <div className='item-right'>
            <div className='percentage progress'><div className='text'>50%</div></div>
            <div className='but'>{`${t("View pool")}`}</div>
          </div>
        </div>
        <div className='footer_item'>
          <div className='item-left'>
            <div className='number'>5</div>
            <div className='portrait'><img src={Frame} alt="" /></div>
            <div className='information'>
              <div className='information_top'>
                <div className='name'>KRAMPUS</div>
                <div className='region'>KRAMPUS</div>
              </div>
              <div className='information_bottom'>
                <div className='bnb'>125 BNB</div>
                <div className='time'>
                  <div className='title'>{`${t("Listing time")}`}:</div>
                  <div className='time_date'>2022.11.21 18:03</div>
                </div>
              </div>
            </div>
          </div>
          <div className='item-right'>
            <div className='percentage progress'><div className='text'>50%</div></div>
            <div className='but'>{`${t("View pool")}`}</div>
          </div>
        </div>
        <div className='footer_item'>
          <div className='item-left'>
            <div className='number'>6</div>
            <div className='portrait'><img src={Frame} alt="" /></div>
            <div className='information'>
              <div className='information_top'>
                <div className='name'>Qatari Bet</div>
                <div className='region'>QB</div>
              </div>
              <div className='information_bottom'>
                <div className='bnb'>110.70990437011808 BNB</div>
                <div className='time'>
                  <div className='title'>{`${t("Listing time")}`}:</div>
                  <div className='time_date'>2022.11.21 17:13</div>
                </div>
              </div>
            </div>
          </div>
          <div className='item-right'>
            <div className='percentage progress'><div className='text'>50%</div></div>
            <div className='but'>{`${t("View pool")}`}</div>
          </div>
        </div>
      </div>
      <div className='imgs'><img src={group2} alt="" /></div>
    </div>
  )
}
