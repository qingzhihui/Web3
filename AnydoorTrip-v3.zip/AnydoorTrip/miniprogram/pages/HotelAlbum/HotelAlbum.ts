import api from '../../config/axios'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: null,
    pictures: [],
    pictures2: [],
    id: '',
    BUnSHow: false,
    SunShow: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options: any) {
    console.log(options.id);

    api._get(`hotel/images/${options.id}`).then(res => {
      console.log(res);

      this.setData({
        pictures: res.data.hotel,
        pictures2: res.data.room,
        BUnSHow: true,
        id: options.id
      })
    }).catch(e => {
      console.log(e);
    })
  },
  previewImage: function (e: any) {
    var index = e.currentTarget.dataset.index,
      pictures = this.data.pictures;
    wx.previewImage({
      current: pictures[index],
      urls: pictures
    })
  },
  previewImage2: function (e: any) {
    var index = e.currentTarget.dataset.index,
      pictures2 = this.data.pictures2;
    wx.previewImage({
      current: pictures2[index],
      urls: pictures2
    })
  },
  HotelAlbumBUnSHow() {
    this.setData({
      BUnSHow: !this.data.BUnSHow
    })
  },
  HotelAlbumSunShow() {
    this.setData({
      SunShow: !this.data.SunShow
    })
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})