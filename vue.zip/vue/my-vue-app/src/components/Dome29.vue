<template>
</template>

<script setup>
dom.addEventListener(
    /* e 是鼠标的事件对象
    * e.x
    * e.clientX
    * e.pageX
    * e.screenX
    * e.movementX
    * e.offsetX
    * */
    'click', function (e) {

    }
)
</script>

<style>
</style>
