import Hd from "../../Component/Hd";
import Title from "../../Component/Title";
import Line from "../../Component/Line";
import "./index.scss"
import Modal from "./modal";
import {useRef} from "react";
import {useTranslation} from "react-i18next";

export default function Team() {
  const modal = useRef<{
    open?(title: string, h2:string, text: string):void
  }>(null)

  const {t} = useTranslation()


  const list = [
    {
      img: "Muzammil.jpg",
      title: "Muzammil",
      h2: "CEO",
      text: "The founder of the football world, engaged in the game industry for 12 years, has very rich experience in game development. And he has unique insights into the blockchain market and investment."
    },
    {
      img: "Lara.jpg",
      title: "Lara",
      h2: "CAO",
      text: "Football world art designer, mainly responsible for game original painting design and community building."
    },
    {
      img: "SELORM KWAKU.jpg",
      title: "SELORM KWAKU",
      h2: "CTO",
      text: "Football World Technology Development, mainly responsible for smart contract development and testing, is a senior technician with 8 years of experience.\n"
    },
    {
      img: "Anees ur.jpg",
      title: "Anees ur",
      h2: "CIO",
      text: "Football world planning, mainly responsible for in-game levels, daily tasks and activities."
    },
    {
      img: "Rod serginhio.jpg",
      title: "Rod serginhio",
      h2: "CMO",
      text: "Marketing Director of Football World, mainly responsible for the planning of daily activities, external publicity and the placement of various media advertisements."
    },
    {
      img: "Kseniya.jpg",
      title: "Kseniya",
      h2: "CUO",
      text: "The football world consultant is mainly responsible for collecting user feedback on the game, assisting the technical team to optimize the game functions, and communicating with players."
    },
  ].map(item => {
    return {
      ...item,
      title: t("team."+item.title),
      h2: t("team."+item.h2),
      text: t("team."+item.text)
    }
  })

  return (
    <div id="team">
      <Modal ref={modal}/>
      <Title title={t("team.TEAM")}/>
      <div className="list">
        {
          list.map((item, key) => {
            return (
              <div className="item" key={key} onClick={() => {
                if (modal?.current?.open) {
                  modal.current.open(item.title, item.h2, item.text)
                }
              }}>
                <img className="avatar xz" key={key} src={"/img/team/" + item.img}/>
                <div className="text">
                  <h1>{item.title}</h1>
                  <h2>{item.h2}</h2>
                </div>
              </div>
            )
          })
        }
      </div>
      <Line className="b-line"/>
    </div>
  )
}