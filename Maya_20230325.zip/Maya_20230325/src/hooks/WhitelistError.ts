
// 发射平台创建功能第二个页面
export interface whitelistError{
    preRateError?:boolean,
    softCapError?:boolean,
    hardCapError?:boolean,
    minbuyError?:boolean,
    maxbuyError?:boolean,
    routerError?:boolean,
    liquidityError?:boolean,
    listingRateError?:boolean,
    startTimeError?:boolean,
    endTimeError?:boolean,
    lockupTimeError?:boolean,
    firstreleaseError?:boolean,
    vestingError?:boolean
    presaletokenError?:boolean
}