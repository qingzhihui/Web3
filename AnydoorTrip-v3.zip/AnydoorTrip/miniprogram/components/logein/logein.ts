Component({
  /**
   * 组件的属性列表
   */
  properties: {
    title: {
      type: String,
      value: ""
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    encryptedData: "",
    iv: ""
  },

  /**
   * 组件的方法列表
   */
  methods: {
    login() {
      wx.login();
    },
    getTal(e: any) {
      var that = this;
      let {
        encryptedData,
        iv
      } = e.detail
      wx.login({
        success(result) {
          if (e.detail.errMsg === "getPhoneNumber:ok") {
            let code = result.code
            wx.request({
              url: 'https://sas-myad-login2.anydoortrip.com/wxLogin',
              method: "POST",
              data: {
                code: code,
                encryptedData: encryptedData,
                iv: iv,
                phone_code: e.detail.code
              },
              success: function (res: any) {
                const data = res.data.data;
                const token = res.header.token;
                const dataBuins = { ...data, access_token: token }
                wx.setStorageSync('admin', dataBuins);
                that.triggerEvent('LoginStateButton', false)
              },
              fail: function (err) {
                console.log('请求失败', err);
                that.triggerEvent('LoginStateButton', true)
              }
            })
          } else if (e.detail.errMsg === 'getPhoneNumber:fail user deny') {
            wx.showToast({
              title: '您拒绝了授权',
              icon: 'none',
              duration: 2000
            })
            that.triggerEvent('LoginStateButton', true)
          }
        },
        fail(error) {
          console.log(error);
        }
      })
    },
  }
})
