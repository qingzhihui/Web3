export interface PokemonList {
  name?: string;
  roles?: {
    admin?: string;
    user?: string;
  };
}
export const getPokemon = async (url: string): Promise<PokemonList> => {
  const listresp = await fetch(url);
  return await listresp.json();
};
export const getPokemonList = async (): Promise<PokemonList> => {
  const listresp = await fetch("/url.json");
  return await listresp.json();
};

export const getFirstPokemon = (): Promise<PokemonList> =>
  new Promise(async (resolve, reject) => {
    try {
      const list: any = await getPokemonList();
      resolve(await getPokemon(list.results[0].url));
    } catch (error) {
      reject(error);
    }
  });

export const getPokemonListPorps = (
  cb: (err: Error | undefined, pokemonList: PokemonList | undefined) => void
): void => {
  fetch("/url.json")
    .then((res) => res.json())
    .then((data: PokemonList) => cb(undefined, data))
    .catch((err) => cb(err, undefined));
};

getPokemonListPorps((_err, data) => {
  console.log(data);
});
