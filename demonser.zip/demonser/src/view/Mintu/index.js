import React from "react";
import { useEffect, useState, useRef } from "react";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import "./index.scss";
import nimag from "../../utils/mint.js";
import contractABI from "../../utils/abi.json";
import { Web3Provider } from "@ethersproject/providers";
import ches from "../../assets/kd.png";
import toxing from "../../assets/toxiang.png";
import luby from "../../assets/lbuy.png";
import maoti from "../../assets/maoti.png";
import WalletConnect from "../../assets/Wallet.png";
import WalletConnectProvider from "@walletconnect/web3-provider";
import guangb from "../../assets/gb.png";
import loges from "../../assets/enlues/jss.png";
import axios from "axios";
import { ShakeHorizontal } from "reshake";
const contractAddress = "0xA0Bd8274c894bbD93d75BA5b47E455408c157901";

function Mintu(props) {
  const [fruit1, setFruit1] = useState("");
  const [Ddisplay, setDisplay] = useState(true);
  const [isClick, setisClick] = useState(true);
  const [balance, setBalance] = useState("");
  const [bakushow, setbakushow] = useState(false);
  const [actiovtin, setactiovtin] = useState(true);
  const [qctiovtin, setqctiovtin] = useState(true);
  const [atlins, setatlins] = useState({
    image: "",
    name: "",
    description: "",
  });
  const [address, setAddress] = useState("");
  const [display, setdisplay] = useState(false);
  const [walletConnectProvider, setWalletConnectProvider] = React.useState();
  const [web3Library, setWeb3Library] = React.useState();
  const [web3Account, setWeb3Account] = React.useState();
  let slotRef = [useRef(null), useRef(null), useRef(null)];
  const fruits = nimag;
  let timer = null;

  const Sguanbi = () => {
    setdisplay(false);
  };
  const Showlu = () => {
    setdisplay(false);
  };
  const sliensds = () => {
    setdisplay(true);
  };
  const disconnect = async () => {
    window.location.reload();
  };

  const initSwitch = async () => {
    const provider = window.ethereum;
    const chainId = await provider.request({ method: "eth_chainId" });
    const binanceTestChainId = "0x4";
    if (chainId === binanceTestChainId) {
      initConnection();
      setdisplay(false);
    } else {
      try {
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: binanceTestChainId }],
        });
        initConnection();
      } catch (switchError) {
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [
                {
                  chainId: "0x4",
                  chainName: "Rinkeby - Testnet",
                  nativeCurrency: {
                    name: "Rinkeby",
                    symbol: "RIN",
                    decimals: 18,
                  },
                  blockExplorerUrls: ["https://rinkeby.etherscan.io/"],
                  rpcUrls: [
                    "https://rinkeby.infura.io/v3/55d040fb60064deaa7acc8e320d99bd4/",
                  ],
                },
              ],
            });
          } catch (addError) {
            console.error(addError);
          }
        }
      }
    }
  };
  const initConnection = async () => {
    if (typeof window.ethereum !== "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const addr = await signer.getAddress();
      setAddress(addr);
      const bal = await provider.getBalance(addr);
      setBalance(ethers.utils.formatEther(bal));
      setdisplay(false);
    } else {
      console.log("Please install metamask.");
    }
  };
  const connectWaletConnect = async () => {
    try {
      const RPC_URLS = {
        1: "https://mainnet.infura.io/v3/55d040fb60064deaa7acc8e320d99bd4",
        4: "https://rinkeby.infura.io/v3/55d040fb60064deaa7acc8e320d99bd4",
      };
      const provider = new WalletConnectProvider({
        rpc: {
          1: RPC_URLS[1],
          4: RPC_URLS[4],
        },
        qrcode: true,
        pollingInterval: 15000,
      });
      setWalletConnectProvider(provider);
      const accounts = await provider.enable();
      const account = accounts[0];
      const library = new Web3Provider(provider, "any");
      setWeb3Library(library);
      setWeb3Account(account);
    } catch (ex) {
      console.log(ex);
    }
  };
  const timerStart = () => {
    if (timer) {
      clearInterval(timer);
    }
    setDisplay(false);
    timer = setInterval(() => {
      const ches = () => {
        slotRef.forEach((slot, i) => {
          const selected = triggerSlotRotation(slot.current);
          if (i + 1 === 1) setFruit1(selected);
          else if (i + 1 === 2) setFruit1(selected);
          else setFruit1(selected);
        });
      };
      ches();
    }, 400);
  };
  const timerStop = () => {
    clearInterval(timer);
    timer = 0;
  };
  const HeoimShow = () => {
    props.history.push("/index");
  };
  const bsinebn = () => {
    props.history.push("/MyNFTs", {
      addr: address,
    });
  };

  const triggerSlotRotation = (ref) => {
    function setTop(top) {
      ref.style.top = `${top}px`;
    }
    let options = ref.children;
    let randomOption = Math.floor(Math.random() * fruits.length);
    let choosenOption = options[randomOption];
    setTop(-choosenOption.offsetTop + 2);
    setTimeout(() => {
      timerStop();
      setDisplay(true);
      setisClick(false);
    }, 5000);
    return fruits[randomOption];
  };
  const sliebuse = () => {
    setactiovtin(false);
    setqctiovtin(false);
  };
  const sliebuse2 = () => {
    setactiovtin(true);
    setqctiovtin(true);
  };
  const slieHide = () => {
    setbakushow(false);
    setactiovtin(true);
    setqctiovtin(true);
  };
  const mint = async () => {
    if (typeof window.ethereum !== "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const addr = await signer.getAddress();
      const bal = await provider.getBalance(addr);
      setBalance(ethers.utils.formatEther(bal));
      const { ethereum } = window;
      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const nftContract = new ethers.Contract(
          contractAddress,
          contractABI,
          signer
        );
        let nftTxn = await nftContract.mint(1, {
          value: ethers.utils.parseEther("0.001"),
          gasLimit: 3000000,
        });
        setbakushow(true);
        await nftTxn.wait();
        const total = await nftContract.totalSupply();
        const ches = parseFloat(ethers.utils.formatEther(total));
        const che2 = new BigNumber(ches)
          .times(new BigNumber(10).pow(18))
          .toString();
        const tokenURI = await nftContract.tokenURI(parseInt(che2));
        const url =
          "https://gateway.pinata.cloud/ipfs/" + tokenURI.substr(7, 53);
        axios
          .get(url)
          .then(function (response) {
            setatlins(response.data);
            setTimeout(() => {
              setactiovtin(false);
              setqctiovtin(false);
            }, 2000);
          })
          .catch(function (error) {
            console.log(error);
          });

        // console.log("Wining... please wait");
        // await nftTxn.wait();

        // console.log(
        //   `Mined,see transaction:https://rinkeby.etherscan.io/tx/${nftTxn.hash}`
        // );
      } else {
        console.log("Ethereum object does not exist");
      }
      // if (parseInt(ethers.utils.formatEther(bal)) <= 0.1) {
      //   try {
      //     const { ethereum } = window;
      //     if (ethereum) {
      //       const provider = new ethers.providers.Web3Provider(ethereum);
      //       const signer = provider.getSigner();
      //       const nftContract = new ethers.Contract(
      //         contractAddress,
      //         contract,
      //         signer
      //       );
      //       console.log("Initialize payment");
      //       let nftTxn = await nftContract.mint(1, {
      //         value: 0,
      //       });

      //       console.log("Wining... please wait");
      //       await nftTxn.wait();
      //       console.log(
      //         `Mined,see transaction:https://rinkeby.etherscan.io/tx/${nftTxn.hash}`
      //       );
      //     } else {
      //       console.log("Ethereum object does not exist");
      //     }
      //   } catch (error) {
      //     console.log(error);
      //   }
      // } else {
      //   console.log("Your balance is insufficient");
      // }
    } else {
      console.log("Please install metamask.");
    }
  };

  return (
    <div className="listMint" id="activity1">
      <div className="sldlkue">
        <div className="skuebss">
          <div className="dangping">
            <div className="SlotMachine">
              <div className="slot">
                <section>
                  <div className="container" ref={slotRef[0]}>
                    {fruits.map((fruit, i) => (
                      <div key={i}>
                        <img src={fruit} alt="" />
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            </div>
            <div className="sluitbsui"></div>
            <div
              className={Ddisplay ? "roll" : "rolls"}
              onClick={() => timerStop()}
            ></div>
          </div>
        </div>
        {address == "" ? (
          <div className="lisbetext">
            Note: Please connect the wallet first to operate
          </div>
        ) : (
          ""
        )}
        <div className="moitemnro">
          <div className="mustin">
            {isClick ? (
              <div className="pibuon">
                <button
                  className={address == "" ? "cat" : ""}
                  disabled={address == "" ? true : false}
                  onClick={() => timerStart()}
                >
                  GET REKT
                </button>
              </div>
            ) : (
              <div className="pibuon">
                <button onClick={() => mint()}>MINT NOW</button>
              </div>
            )}
            <div className="mustin_title">
              <span>
                <div>
                  <b>Story of Rekt Club </b>
                </div>
                The year is 2022. We hard-working plebs are once again rekt by
                the market. It seems as if that once beautiful crypto rich dream
                twitter/tiktok influencers been shilling is no longer a reality.
                Now work-to-earn is the new paradigm. Having one job is no
                longer enough to cover the loss from our crypto degen lifestyles
                but rather we need three. Flipping burgers at the McDonald's
                isn’t that bad afterall — perhaps we’d be earning enough money
                to afford a new pair of StepN sneakers just to be rug pulled
                again. Who will bail us out this time? Is it CZ or SBF. Can you
                guys please refund? Are you rekt enough yet?
                <div className="sebyse">- Join the Rekt Club</div>
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="kunfangh">
        <div
          className="kunfanlog"
          onClick={() => {
            HeoimShow();
          }}
        ></div>
      </div>
      {bakushow ? (
        <div className="Nuslis">
          <div
            className="belise"
            onClick={() => {
              slieHide();
            }}
          ></div>
          <div className="main">
            <div className={["box ", actiovtin ? "b1" : "b1s"].join(" ")}></div>
            <div className={["box", qctiovtin ? "b2" : "b2s"].join(" ")}>
              <div className="lsiebspei">
                <div className="lsiebspimg">
                  <img
                    src={
                      "https://gateway.pinata.cloud/ipfs/" +
                      atlins.image.substr(7, 53)
                    }
                    alt=""
                  />
                </div>
                <div className="lsietitle">
                  <span>{atlins.name}</span>
                </div>
                <div className="lsiemiaos">
                  <span>{atlins.description}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      <div className="toblret">
        <div className="iteusfelo">
          {address == "" ? (
            <div className="itbtnns">
              <ShakeHorizontal>
                <button onClick={() => sliensds()}></button>
              </ShakeHorizontal>
            </div>
          ) : (
            <div className="itbtnns">
              <div className="sbuselck" onClick={() => bsinebn()}>
                <div className="sbielsie">My NFTs</div>
                <div className="tbiaokk"></div>
              </div>
              <div className="itbtnro">
                <div className="itbtnroimg">
                  <img src={toxing} alt="" />
                </div>
                <div className="itbtnrotuil">
                  <span>
                    {address.substring(0, 4) +
                      "..." +
                      address.substring(38, 42)}
                  </span>
                </div>
                <div
                  className="itbtnrokul"
                  onClick={() => {
                    disconnect();
                  }}
                >
                  <span>DISCONNECT</span>
                </div>
              </div>
            </div>
          )}
        </div>
        {display ? (
          <div className="dabuos">
            <div className="sinuyse" onClick={() => Showlu()}></div>
            <div className="siebsi">
              <div className="lsiens">
                <div className="suebxedu">
                  <img src={luby} alt="" />
                  <img src={loges} alt="" />
                </div>

                <div className="tipoens" onClick={() => Sguanbi()}>
                  <img src={guangb} alt="" />
                </div>
              </div>
              <div className="lsibki">
                <div className="slienus" onClick={() => initSwitch()}>
                  <div className="stilo">
                    <img src={maoti} alt="" />
                  </div>
                  <div className="stilotil">
                    <span>MetaMask</span>
                  </div>
                </div>
                <div className="slienus" onClick={() => connectWaletConnect()}>
                  <div className="stilo">
                    <img src={WalletConnect} alt="" />
                  </div>
                  <div className="stilotil">
                    <span>WalletConnect</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
}

export default Mintu;
