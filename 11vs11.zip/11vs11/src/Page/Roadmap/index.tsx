import "./index.scss"
import Hd from "../../Component/Hd";
import Title from "../../Component/Title";
import Line from "../../Component/Line";
export default function Roadmap() {
  return (
    <div id="roadmap">
      <Title title="ROADMAP"/>
     {/* <h1>
        ASRA City DAO aims to establish itself as the  leading virtual ASRA City DAO aims to establish itself as the  leading virtual
      </h1>*/}
      <div className="list">
        <div className="line"/>
        <div className="item">
          <div className="football">
            <img src="/img/football1.png" alt=""/>
            <div className="f-connect">
              <div className="line"/>
              <div className="round"/>
            </div>
          </div>
          <div className="text">
            <h1>Phase 1</h1>
            <div className="value">
              Form a team.<br/>
              game design.<br/>
              Economic Model Design.<br/>
              Original game design.
            </div>
          </div>
        </div>
        <div className="item">
          <div className="football">
            <img src="/img/football2.png" alt=""/>
            <div className="f-connect">
              <div className="line"/>
              <div className="round"/>
            </div>
          </div>
          <div className="text">
            <h1>Stage 2</h1>
            <div className="value">
              Smart Contract Development<br/>
              Smart Contract Testing<br/>
              white paper<br/>
              Community Building<br/>
              Community Marketing
            </div>
          </div>
        </div>
        <div className="item">
          <div className="football">
            <img src="/img/football3.png" alt=""/>
            <div className="f-connect">
              <div className="line"/>
              <div className="round"/>
            </div>
          </div>
          <div className="text">
            <h1>Stage 3</h1>
            <div className="value">
              Blind box sale<br/>
              Media Diffusion<br/>
              The public beta version of the game is online
            </div>
          </div>
        </div>
        <div className="item">
          <div className="football">
            <img src="/img/football4.png" alt=""/>
            <div className="f-connect">
              <div className="line"/>
              <div className="round"/>
            </div>
          </div>
          <div className="text">
            <h1>Stage 4</h1>
            <div className="value">
              Token Sale<br/>
              The official version of the game is online<br/>
              Smart Contract Audit<br/>
              Game function expansion
            </div>
          </div>
        </div>
        <div className="item">
          <div className="football">
            <img src="/img/football5.png" alt=""/>
            <div className="f-connect">
              <div className="line"/>
              <div className="round"/>
            </div>
          </div>
          <div className="text">
            <h1>Stage 5</h1>
            <div className="value">
              Top Media Marketing Promotion<br/>
              Release of the star version of the joint jersey<br/>
              Community Airdrop Activities<br/>
              FBW listed exchange...
            </div>
          </div>
        </div>
      </div>
      <Line className="b-line"/>
    </div>
  )
}