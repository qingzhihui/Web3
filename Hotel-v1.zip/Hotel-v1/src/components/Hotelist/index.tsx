import React from "react";
import "./index.scss";

const Planelist = () => {
    return (
        <div className="Hotelist">
            <div className="Planelist_item1">
                <img
                    className="psuieng_image"
                    src={require("@/assets/image/IMAGE-11.png")}
                    alt=""
                />
                <div className="Planelist_item1_priobu">
                    <div className="Planelist_item1_image">
                        <img src={require("@/assets/image/house_arr.png")} alt=""/>
                    </div>
                    <div className="Planelist_item1_title">
                        <div className="Planelist_item1_text">Aman at Summer Palace</div>

                    </div>
                </div>
            </div>
            <div className="priobu_cender">
                <div className="priobu_Buining">
                    <div className="priobu_cender_image">
                        <img src={require("@/assets/image/AM1.png")} alt=""/>
                    </div>
                    <div className="priobu_Buining_title">King bed room</div>
                </div>
                <div className="priobu_Tnxie">
                    <div className="priobu_Tnxie_title">Confirmation code</div>
                    <div className="priobu_Tnxie_nro">#195 123 489</div>
                </div>
            </div>
            <div className="speubsei_porbtn">
                <button>Details</button>
            </div>
        </div>
    );
};

export default Planelist;
