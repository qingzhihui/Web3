// 有问题
// function printAll2(strs: string | string[] | null) {
//   if (strs) {
//     if (typeof strs === "object") {
//       for (const s of strs) {
//         console.log(s);
//       }
//     } else if (typeof strs === "string") {
//       console.log(strs);
//     } else {
//     }
//   }
// }

function multiplyall(values: number[] | undefined, factor: number) {
  if (!values) {
    return values;
  } else {
    return values.map((x) => {
      return x * factor;
    });
  }
}

// console.log(multiplyall([3, 4], 2));
console.log(multiplyall(undefined, 2));
