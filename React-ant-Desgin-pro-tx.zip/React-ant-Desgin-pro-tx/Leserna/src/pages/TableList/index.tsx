import { Button, InputNumber, Popconfirm, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { ethers } from 'ethers';
import * as ExcelJs from 'exceljs';
import { useState } from 'react';
import { generateHeaders, saveWorkbook } from '../../utils';

import './index.css';
export interface IAdmin {
  key: React.Key;
  address: string;
  privateKey: string;
  mnemonic: string;
}
function index() {
  const [serinput, setSerinput] = useState<number>(1);
  const [addrList, setAddrList] = useState<IAdmin[]>([]);
  const columns: ColumnsType<IAdmin> = [
    {
      title: 'key',
      dataIndex: 'key',
      key: 'key',
      render: (text) => <a>{text}</a>,
    },
    {
      title: 'address',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: 'mnemonic',
      dataIndex: 'mnemonic',
      key: 'mnemonic',
    },
    {
      title: 'privateKey',
      dataIndex: 'privateKey',
      key: 'privateKey',
    },
    {
      title: 'Delete',
      key: 'operation',
      fixed: 'right',
      width: 100,
      render: (record: { key: React.Key }) =>
        addrList.length >= 1 ? (
          <Popconfirm title="确定要删除吗?" onConfirm={() => handleDelete(record.key)}>
            <Button type="primary">删除</Button>
          </Popconfirm>
        ) : null,
    },
  ];

  const onChange = (value: number) => {
    setSerinput(value);
  };
  const newAddress = () => {
    let dataArr = [];
    for (let i = 0; i < serinput; i++) {
      const wallet = ethers.Wallet.createRandom();
      const mnemonic = wallet.mnemonic;
      const privateKey = wallet.privateKey;
      const address = wallet.address;
      dataArr[i] = {
        key: i + 1,
        address,
        privateKey,
        mnemonic: mnemonic.phrase,
      };
    }
    console.log(dataArr);
    setAddrList(dataArr);
    setSerinput(0);
  };
  const handleDelete = (key: React.Key) => {
    const newData = addrList.filter((item: IAdmin) => item.key !== key);
    setAddrList(newData);
  };
  const handleDownload = () => {
    const workbook = new ExcelJs.Workbook();
    const worksheet = workbook.addWorksheet('demo sheet');
    worksheet.properties.defaultRowHeight = 20;
    const Biecoluem = columns.filter((item) => item.key !== 'operation');
    worksheet.columns = generateHeaders(Biecoluem);
    let headerRow = worksheet.getRow(1);
    headerRow.eachCell((cell, colNum) => {
      cell.font = {
        italic: true,
        size: 12,
        name: '微软雅黑',
        color: { argb: '444444' },
      };
      cell.alignment = { vertical: 'middle', horizontal: 'left', wrapText: false };
    });
    let rows = worksheet.addRows(addrList);
    rows?.forEach((row) => {
      row.font = {
        size: 11,
        name: '微软雅黑',
      };
      row.alignment = { vertical: 'middle', horizontal: 'left', wrapText: false };
    });
    saveWorkbook(workbook, 'simple-demo.xlsx');
  };

  return (
    <div className="cheeslie">
      <div className="cheFlieb">
        <InputNumber
          style={{ width: 500 }}
          min={0}
          max={50}
          defaultValue={serinput}
          onChange={onChange}
        />
        <Button
          type="primary"
          onClick={() => {
            newAddress();
          }}
        >
          一键生成
        </Button>
        <Button
          type="primary"
          onClick={() => {
            handleDownload();
          }}
        >
          导出EXCEL
        </Button>
      </div>
      {addrList.length !== 0 ? (
        <div className="tablues">
          <Table
            columns={columns}
            bordered={true}
            dataSource={addrList}
            rowKey={(admin) => admin.key}
          />
        </div>
      ) : null}
    </div>
  );
}

export default index;
