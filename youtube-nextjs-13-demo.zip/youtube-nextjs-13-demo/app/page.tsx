import React from "react";

const Home = () => {
  return <div>I am the homepage</div>;
};

export default Home;
