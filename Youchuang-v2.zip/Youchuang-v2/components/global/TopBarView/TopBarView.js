import topBar from "../../../utils/global/topBar";
Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多 slot 支持
  },

  /**
   * 组件的属性列表
   */
  properties: {
    // 顶栏高度
    height: {
      type: String,
      value: topBar.topBarHeight() + "px"
    },
    // 顶栏底部边框样式
    borderBottom: {
      type: String,
      value: "none"
    },
    // 顶栏背景色
    backgroundColor: {
      type: String,
      value: "transparent"
    },
    // 返回图标高度
    backIconHeight: {
      type: String,
      value: topBar.capsuleHeight() + "px"
    },
    /**
     * 胶囊距离状态栏距离
    */
    capsuleHeightToStatus: {
      type: String,
      value: topBar.capsuleHeightToStatus() + "px"
    },
    // 字体颜色
    color: {
      type: String,
      value: "#B5BFCA"
    },
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件在页面中的生命周期函数 
   */
  pageLifetimes: {
    show: function () {

    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /**
     * 回到上一页
     */
    _goBack: function () {
      wx.navigateBack();
    }
  }
})
