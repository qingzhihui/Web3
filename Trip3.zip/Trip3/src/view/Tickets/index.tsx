import React from 'react'

const Tickets = () => {
  return (
    <div>Tickets</div>
  )
}

export default Tickets