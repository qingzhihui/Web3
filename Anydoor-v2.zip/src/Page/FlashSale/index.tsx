import { DeleteOutlined, ReadOutlined } from "@ant-design/icons";
import {
  Button,
  DatePicker,
  DatePickerProps,
  Form,
  Input,
  Modal,
  Radio,
  Select,
  Space,
  Table,
} from "antd";
import { RangePickerProps } from "antd/es/date-picker";
import type { ColumnsType } from "antd/es/table";
import { createRef, useState } from "react";
import "./index.css";

// 限时抢购界面
const FlashSale = () => {
  const { RangePicker } = DatePicker;
  const [isReviseTableData, setReviseTableData] = useState(false);
  const FormRef = createRef<any>();
  // 开始时间时间1
  const onChange = (
    value: DatePickerProps["value"] | RangePickerProps["value"],
    dateString: [string, string] | string
  ) => {
    console.log("Selected Time: 1", value);
    console.log("Formatted Selected Time: 1", dateString);
  };
  // 开始时间时间1
  const onOk = (
    value: DatePickerProps["value"] | RangePickerProps["value"]
  ) => {
    console.log("onOk: 1", value);
  };
  // 开始时间时间2
  const onChange2 = (
    value: DatePickerProps["value"] | RangePickerProps["value"],
    dateString: [string, string] | string
  ) => {
    console.log("Selected Time: 2", value);
    console.log("Formatted Selected Time: 2", dateString);
  };
  // 开始时间时间2
  const onOk2 = (
    value: DatePickerProps["value"] | RangePickerProps["value"]
  ) => {
    console.log("onOk 2: ", value);
  };
  interface DataType {
    key: number;
    activityName: string; // 活动名称
    eventhotel: string; // 活动酒店
    eventPrice: string; // 活动价格
    activityProductQuantity: string; // 活动商品数量
    openingHours: string; //开放时间
    usageTime: string; //使用时间
    status: string; //状态
  }

  const data: DataType[] = [
    {
      key: 1,
      activityName: "五一出游大礼包",
      eventhotel: "喜来登酒店",
      eventPrice: "618",
      activityProductQuantity: "99",
      openingHours: "2023-01-01—2023-01-10",
      usageTime: "2023-01-01—2023-06-01",
      status: "点击禁用",
    },
    {
      key: 2,
      activityName: "春游大礼包",
      eventhotel: "喜来登酒店",
      eventPrice: "588",
      activityProductQuantity: "99",
      openingHours: "2023-01-01—2023-01-10",
      usageTime: "2023-01-01—2023-06-01",
      status: "点击禁用",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "活动名称",
      dataIndex: "activityName",
      width: 200,
    },
    {
      title: "活动酒店",
      dataIndex: "eventhotel",
      width: 200,
    },
    {
      title: "活动价格",
      dataIndex: "eventPrice",
      width: 120,
    },
    {
      title: "开放时间",
      dataIndex: "openingHours",
      // width: 120,
    },
    {
      title: "使用时间",
      dataIndex: "usageTime",
      // width: 120,
    },
    {
      title: "状态",
      dataIndex: "status",
      // width: 120,
      render: (_text, record) => (
        <Space size="middle">
          <span className="fSale_statusBackClo">{_text}</span>
        </Space>
      ),
    },
    {
      title: "操作",
      key: "action",
      // width: 200,
      render: (_, record) => (
        <Space size="middle">
          <span className="fSale_publicCursor" onClick={readBtn(record)}>
            <ReadOutlined />
          </span>
          <span className="fSale_publicCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 下拉选择框-地区-内容
  const options1 = [
    {
      value: "1",
      label: "珠海",
    },
    {
      value: "2",
      label: "广州",
    },
  ];

  // 下拉选择-地区---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log("会员类型", value);
  };

  // 查看
  const readBtn = (record: any) => {
    return () => {
      console.log("点击了查看");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };
  const cehsi: any = [
    {
      id: 0,
      value: "满减卷",
    },
    {
      id: 1,
      value: "折扣卷",
    },
    {
      id: 2,
      value: "全场卷",
    },
    {
      id: 3,
      value: "指定分类卷",
    },
    {
      id: 4,
      value: "指定商品卷",
    },
  ];
  //   用于判断点击变色
  const [isNum, setNum] = useState(0);

  //   各类卷按钮
  const handleClick = (index: any) => {
    return () => {
      setNum(index);
      if (index == 0) {
        console.log("满减卷");
      } else if (index == 1) {
        console.log("折扣卷");
      } else if (index == 2) {
        console.log("全场卷");
      } else if (index == 3) {
        console.log("指定分类卷");
      } else {
        console.log("指定商品卷");
      }
    };
  };
  // 添加--关闭弹窗
  const ReviseTableDataClose = () => {
    setReviseTableData(false);
  };

  // 添加
  const addShou = () => {
    return () => {
      console.log("添加按钮,打开弹窗");
      setReviseTableData(true);
    };
  };
  //  添加-提交按钮
  const onReviseSubmitBtn = (values: any) => {
    console.log("添加提交的数据", values);
    // 清空
    FormRef.current.resetFields();
  };

  return (
    <div className="fSale_Box">
      <div className="fSale_headerBox">
        <div className="fSale_headerBox_thread"></div>
        <div className="fSale_headerBox_Tit">&nbsp;&nbsp;&nbsp; 限时抢购</div>
        <div className="fSale_headerAddBtn" onClick={addShou()}>
          添加
        </div>
        {/* 添加 */}
        <Modal
          footer={[null]}
          open={isReviseTableData}
          onCancel={ReviseTableDataClose}
        >
          <div className="fSale_headerBox">
            <div className="fSale_headerBox_thread"></div>
            <div className="fSale_headerBox_Tit">
              &nbsp;&nbsp;&nbsp; 添加限时抢购
            </div>
          </div>
          <div className="fSale_tableBox">
            <Form
              name="basic"
              ref={FormRef}
              labelCol={{ span: 7 }}
              wrapperCol={{ span: 16 }}
              style={{ maxWidth: 700 }}
              initialValues={{ remember: true }}
              onFinish={onReviseSubmitBtn}
              autoComplete="off"
            >
              <Form.Item label="活动名称" name="activityName">
                <Input placeholder="例如五一出行" />
              </Form.Item>
              <Form.Item label="活动酒店" name="eventhotel">
                <Select
                  placeholder="请选择"
                  labelInValue
                  style={{ width: 120 }}
                  onChange={handleChange1}
                  options={options1}
                />
              </Form.Item>
              <Form.Item label="活动价格" name="eventPrice">
                <Input placeholder="请输入价格" />
              </Form.Item>
              <Form.Item label="活动商品数量" name="eventPrice">
                <Input placeholder="请输入数量" />
              </Form.Item>

              <Form.Item label="发放时间" name="openingHours">
                <RangePicker
                  showTime={{ format: "HH:mm" }}
                  format="YYYY-MM-DD HH:mm"
                  onChange={onChange}
                  onOk={onOk}
                />
              </Form.Item>
              <Form.Item label="使用时间" name="usageTime">
                <RangePicker
                  showTime={{ format: "HH:mm" }}
                  format="YYYY-MM-DD HH:mm"
                  onChange={onChange2}
                  onOk={onOk2}
                />
              </Form.Item>
              <Form.Item label="状态" name="restrictedGoods">
                <Radio.Group>
                  <Radio value="1"> 启用 </Radio>
                  <Radio value="2"> 禁用 </Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                <Button
                  className="fSale_btn"
                  size="middle"
                  type="primary"
                  htmlType="submit"
                >
                  提交
                </Button>
              </Form.Item>
            </Form>
          </div>
        </Modal>
      </div>

      <div className="fSale_tableBox">
        <Table columns={columns} dataSource={data} />
      </div>
    </div>
  );
};

export default FlashSale;
