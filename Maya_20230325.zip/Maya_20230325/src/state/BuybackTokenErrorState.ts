import { BuybackTokenError } from "../hooks/Errorhandle";

const BuybackTokenErrorInitState: BuybackTokenError = {
    NameBlankError: false,
    NameCharactersError: false,
    SymbolBlankError: false,
    SymbolCharactersError: false,
    TotalSupplyBlankError: false,
    TotalSupplyAmountError: false,
    RewardTokenBlankError: false,
    RewardTokenInvalidError: false,
    LiquidityFeeBlankError: false,
    LiquidityFeeMinError: false,
    BuybackFeeBlankError: false,
    BuybackFeeMinError: false,
    ReflectionFeeBlankError: false,
    ReflectionFeeMinError: false,
    MarketingFeeBlankError: false,
    MarketingFeeMinError: false,
    FeeOverError: false,
};

export {
    BuybackTokenErrorInitState
};