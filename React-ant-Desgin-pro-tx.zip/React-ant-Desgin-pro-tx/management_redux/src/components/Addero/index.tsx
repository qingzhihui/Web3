import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import { useDispatch, useSelector } from "react-redux";
import Box from "@mui/material/Box";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import TextField from "@mui/material/TextField";
import styles from "./index.module.css";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { increment } from "../../redux/counterSlice";
import { Todo } from "../../hooks/types";

const Addero = () => {
  const dispatch = useDispatch();
  const count = useSelector((state: any) => state.counter.TodoStore);
  const [useDate, setUseDate] = React.useState<Todo[]>(count);
  const [open, setOpen] = React.useState(false);
  const [name, setName] = React.useState("");
  const [sage, setSage] = React.useState(0);
  const [first, setFirst] = React.useState("");
  const [states, setState] = React.useState("");

  const handleClickOpen = () => {
    setOpen(true);
  };
  const DateProshi = () => {
    let state: boolean = true;
    if (states === "1") {
      state = true;
    } else {
      state = false;
    }
    const UnsDate: Todo[] = [
      {
        id: new Date().getTime(),
        name: name,
        sage: sage,
        first: first,
        state: state,
      },
    ];
    return UnsDate;
  };
  const handleClose = () => {
    setOpen(false);
    const dateUer: Todo[] = DateProshi();
    dispatch(increment(dateUer));
  };
  const handlefirstChange = (event: SelectChangeEvent) => {
    setFirst(event.target.value as string);
  };
  const handleStateChange = (event: SelectChangeEvent) => {
    setState(event.target.value as string);
  };
  React.useEffect(() => {}, [name, sage, first, states]);

  return (
    <div>
      <Button variant="outlined" onClick={handleClickOpen}>
        添加
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"添加"}</DialogTitle>
        <DialogContent>
          <Box component="div" className={styles.proonse}>
            <Box
              component="div"
              sx={{ marginTop: 1 }}
              className={styles.buinre}
            >
              <TextField
                id="outlined-basic"
                label="姓名"
                size="small"
                variant="outlined"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                }}
              />
            </Box>
            <Box
              component="div"
              sx={{ marginTop: 1 }}
              className={styles.buinre}
            >
              <TextField
                id="outlined-basic"
                label="年龄"
                size="small"
                variant="outlined"
                value={sage}
                onChange={(e) => {
                  setSage(Number(e.target.value));
                }}
              />
            </Box>
            <Box component="div" className={styles.buinre}>
              <FormControl sx={{ marginTop: 1, minWidth: 223 }} size="small">
                <InputLabel id="demo-simple-select-label">性别</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={first}
                  label="Age"
                  onChange={handlefirstChange}
                >
                  <MenuItem value={"男"}>男</MenuItem>
                  <MenuItem value={"女"}>女</MenuItem>
                </Select>
              </FormControl>
            </Box>
            <Box component="div" className={styles.buinre}>
              <FormControl sx={{ margin: 1, minWidth: 223 }} size="small">
                <InputLabel id="demo-simple-select-label">状态</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={states}
                  label="Age"
                  onChange={handleStateChange}
                >
                  <MenuItem value={"1"}>在校</MenuItem>
                  <MenuItem value={"0"}>离校</MenuItem>
                </Select>
              </FormControl>
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>取消</Button>
          <Button onClick={handleClose} autoFocus>
            确定
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Addero;
