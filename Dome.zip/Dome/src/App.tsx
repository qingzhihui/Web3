import React from "react";
import "antd/dist/antd.less";
import "./App.css";
import Demo from "./view/index26";

function App() {
  return (
    <div className="App">
      {/* name={"123"} age={0} */}
      <Demo  />
    </div>
  );
}

export default App;
