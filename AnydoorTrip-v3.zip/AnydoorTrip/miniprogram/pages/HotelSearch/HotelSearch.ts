import api from '../../config/axios'
import { differenceInterval, SecenInputeAwinet } from '../../config/config';
let timer: any;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    show: false,
    brandData: [],
    result: [],
    BrandList: [],
    SecenValue: "",
    number_per: 10,
    page_number: 1,
    HotelData: [],
    startTime: "",
    EndTime: "",
    nuerlin: "",
    code: "",
    locationType: "",
    loading: false,
    stepperProps: "",
    perNuer: "",
    roomNumer: ""
  },

  /**
 * 生命周期函数--监听页面加载
 */
  onLoad(options: any) {
    const intervalDate: any = differenceInterval(options.startTime, options.EndTime);
    this.setData({
      startTime: options.startTime,
      EndTime: options.EndTime,
      nuerlin: intervalDate,
      stepperProps: options.stepper,
      roomNumer: options.roomNumer,
      SecenValue: options.city,
      perNuer: options.city
    })
    SecenInputeAwinet().then((res: any) => {
      this.setData({
        brandData: res.data
      })
    })
    if (options.city !== "") {
      this.SecenInputData();
      this.SecenInputData()
    }
  },
  SecenInputOnCheng(event: any) {
    this.setData({
      SecenValue: event.detail.value
    })
    this.debounce(event.detail.value)
  },
  debounce(valueState: any) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (valueState === "") {
        this.setData({
          HotelData: [],
          SecenValue: this.data.perNuer,
          loading: true
        })
        this.SecenInputData();
      } else {
        this.setData({
          HotelData: [],
          loading: true
        })
        this.SecenInputData();
      }
    }, 2000);
  },
  SeaHoteOnclick() {
    var childEle = this.selectComponent('#childEle');
    childEle.showPopup();
    childEle.getFirstWeek({
      startTime: this.data.startTime,
      EndTime: this.data.EndTime,
      nuerlin: this.data.nuerlin,
      stepperProps: this.data.stepperProps,
      roomNumer: this.data.roomNumer
    })
  },
  send(e: any) {
    const perdate = differenceInterval(e.detail.date[0], e.detail.date[1]);
    this.setData({
      startTime: e.detail.date[0],
      EndTime: e.detail.date[1],
      nuerlin: String(perdate),
      stepperProps: e.detail.stepper,
      roomNumer: e.detail.roomNumer
    })
    setTimeout(() => {
      this.setData({
        HotelData: [],
        loading: true
      })
      this.SecenInputData();
    }, 1000)
  },
  onChange(event: any) {
    const NusierDate = event.detail.map(Number);
    this.setData({
      result: event.detail,
      BrandList: NusierDate
    });
  },
  SecenInputData() {
    const urls = `search-hotel?hotelName=&city=${this.data.SecenValue}&groupId=${String(this.data.BrandList)}&pageSize=20&pageNum=1`
    api._get(urls).then(res => {
      if (res.data.length === 0) {
        this.setData({
          loading: true
        })
        setTimeout(() => {
          this.setData({
            loading: false
          })
        }, 3000)
      } else {
        this.setData({
          HotelData: res.data,
          loading: false
        })
      }
    })
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  HotelDetailsShow(event: any) {
    wx.navigateTo({
      url: `../HotelDetails/HotelDetails?id=${event.currentTarget.dataset.id}&startTime=${this.data.startTime}&EndTime=${this.data.EndTime}&roomNumer=${this.data.roomNumer}`
    })
  },
  ActionSheet() {
    this.setData({ show: true });
  },
  NrolonClose() {
    this.setData({ show: false });
  },
  NrolonClner() {
    this.setData({
      show: false,
      HotelData: [],
      loading: true
    });
    this.SecenInputData();
  },
  ResettingClner() {
    this.setData({
      result: [],
      BrandList: []
    });
    this.SecenInputData();
  },
  onClose() {
    this.setData({ show: false });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBFuner() {

  },


  SecenPercePuhsien() {
    wx.showLoading({
      title: '加载中，请耐心等待..'
    });
    console.log('123');

  },

  onReachBottom() {
    var that = this;
    const number = that.data.number_per + 10;
    that.setData({
      number_per: number
    })
    setTimeout(function () {
      that.SecenPercePuhsien();
    }, 500)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})