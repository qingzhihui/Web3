import React, { useEffect, useState } from "react";
import "../../styles/index.css";
import "../../styles/mobile.css";
import LaunchpadRoadmapPC from "../../components/RoadmapPC/LaunchpadRoadmapPC"
import LaunchpadRoadmapMobile from "../../components/RoadmapMobile/LaunchpadRoadmapMobile"
import Launchpad from "../../components/Launchpad";
import Launch from "../../components/Launch";
import Auction from "../../components/Auction";
import Pool from "../../components/Pool";
import Token from "../../components/Token";
import { useTranslation, Trans } from "react-i18next";
const Lauch: React.FC = (props: any) => {
  const { t } = useTranslation();
  const [createoption, setCreateOption] = useState(1);
  const [content, setContent] = useState("launchpad");
  const [backstate, setBackstate] = useState(false);
  const renders = (contents: string) => {
    setContent(contents);
  };
  const renderCreateLauch = () => {
    if (content === "launchpad") {
      return <Launchpad state={backstate} />;
    } else if (content === "launch") {
      return <Launch />;
    } else if (content === "auction") {
      return <Auction />;
    } else if (content === "pool") {
      return <Pool />;
    } else {
      return <Token />;
    }
  };
  const renderPCContent = () => {
    return (
      <div className="LanchPCContent">
        <div className="LanchpageTop">
          <div className="LanchpageTopLeft">
            {/* <div className="textbuttonArea">
              <div
                className="textbtnItem"
                onClick={() => {
                  setCreateOption(1);
                }}
              >
                <div>
                  <div
                    className="btntext"
                    style={{
                      color: createoption === 1 ? "#F95192" : "#FFB4D0",
                    }}
                    onClick={() => {
                      renders("launchpad");
                    }}
                  >
                    {`${t("Create launchpad")}`}
                  </div>
                  <div
                    className="textbtn-line"
                    style={{
                      background:
                        createoption === 1 ? "#F95192" : "transparent",
                    }}
                  />
                </div>
              </div> */}

            {/* <div
                className="textbtnItem"
                onClick={() => {
                  setCreateOption(2);
                }}
              >
                <div>
                  <div
                    className="btntext"
                    style={{
                      color: createoption === 2 ? "#F95192" : "#FFB4D0",
                    }}
                    onClick={() => {
                      renders("launch");
                    }}
                  >
                    Create fair launch
                  </div>
                  <div
                    className="textbtn-line"
                    style={{
                      background:
                        createoption === 2 ? "#F95192" : "transparent",
                    }}
                  />
                </div>
              </div>

              <div
                className="textbtnItem"
                onClick={() => {
                  setCreateOption(3);
                }}
              >
                <div>
                  <div
                    className="btntext"
                    style={{
                      color: createoption === 3 ? "#F95192" : "#FFB4D0",
                    }}
                    onClick={() => {
                      renders("auction");
                    }}
                  >
                    Create dutch auction
                  </div>
                  <div
                    className="textbtn-line"
                    style={{
                      background:
                        createoption === 3 ? "#F95192" : "transparent",
                    }}
                  />
                </div>
              </div>

              <div
                className="textbtnItem"
                onClick={() => {
                  setCreateOption(4);
                }}
              >
                <div>
                  <div
                    className="btntext"
                    style={{
                      color: createoption === 4 ? "#F95192" : "#FFB4D0",
                    }}
                    onClick={() => {
                      renders("pool");
                    }}
                  >
                    Create subscription pool
                  </div>
                  <div
                    className="textbtn-line"
                    style={{
                      background:
                        createoption === 4 ? "#F95192" : "transparent",
                    }}
                  />
                </div>
              </div> */}

            {/* <div
                className="textbtnItem"
                onClick={() => {
                  setCreateOption(5);
                }}
              >
                <div>
                  <div
                    className="btntext"
                    style={{
                      color: createoption === 5 ? "#F95192" : "#FFB4D0",
                    }}
                    onClick={() => {
                      renders("token");
                    }}
                  >
                    {`${t("Create token")}`}
                  </div>
                  <div
                    className="textbtn-line"
                    style={{
                      background:
                        createoption === 5 ? "#F95192" : "transparent",
                    }}
                  />
                </div>
              </div>
            </div> */}
            <div className="qbaolePsien qbaoleItrn"></div>
            <div className="qbaolePsien2 qbaoleItrn"></div>
            <div className="qbaolePsien3 qbaoleItrn"></div>
            <div className="qbaolePsien4 qbaoleItrn"></div>
            <div
              className="qbaolePsien5 qbaoleItrn"
              style={{
                transform: content === 'launchpad' ? 'scale(1.5)' : '',
                border: content === 'launchpad' ? '1px solid #ff84b3' : '',
                color: content === 'launchpad' ? '#ff84b3' : 'rgb(121,121,121)'
              }}
              onClick={() => {
                renders("launchpad");
              }}
            >
              {" "}
              {`${t("Create launchpad")}`}
            </div>
            <div
              className="qbaolePsien6 qbaoleItrn"
              style={{
                transform: content !== 'launch' && content !== 'launchpad' ? 'scale(1.5)' : '',
                border: content !== 'launch' && content !== 'launchpad' ? '1px solid #ff84b3' : '',
                color: content === 'token' ? '#ff84b3' : 'rgb(121,121,121)'
              }}
              onClick={() => {
                renders("token");
              }}
            >
              {" "}
              {`${t("Create token")}`}
            </div>
            <img
              src={require(`../../assets/image/sleepingCat.png`)}
              alt=""
              className="catImage"
            />
          </div>
          {renderCreateLauch()}
        </div>
        {content !== 'token' ? <LaunchpadRoadmapPC step={1} /> : ''}
        <div className="disclaimer">
          {`${t(
            "Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published."
          )}`}
        </div>
      </div>
    );
  };
  const renderMobileContent = () => {
    return (
      <div className="LanchMobileContent">
        <div style={{ overflow: "auto" }}>
          <div className="topButtonArea">
            <div
              className="topbtnItem"
              onClick={() => {
                setCreateOption(1);
              }}
            >
              <div
                className="btn-text"
                style={{ color: createoption === 1 ? "#F95192" : "#FFB4D0" }}
                onClick={() => {
                  renders("launchpad");
                }}
              >
                {`${t("Create launchpad")}`}
              </div>
              <div
                className="topbtn-line"
                style={{
                  background: createoption === 1 ? "#F95192" : "transparent",
                }}
              />
            </div>

            {/* <div
              className="topbtnItem"
              onClick={() => {
                setCreateOption(2);
              }}
            >
              <div
                className="btn-text"
                style={{ color: createoption === 2 ? "#F95192" : "#FFB4D0" }}
                onClick={() => {
                  renders("launch");
                }}
              >
                {`${t("Create fair launch")}`}
              </div>
              <div
                className="topbtn-line"
                style={{
                  background: createoption === 2 ? "#F95192" : "transparent",
                }}
              />
            </div> */}

            {/* <div
              className="topbtnItem"
              onClick={() => {
                setCreateOption(3);
              }}
            >
              <div
                className="btn-text"
                style={{ color: createoption === 3 ? "#F95192" : "#FFB4D0" }}
                onClick={() => {
                  renders("auction");
                }}
              >
                Create dutch auction
              </div>
              <div
                className="topbtn-line"
                style={{
                  background: createoption === 3 ? "#F95192" : "transparent",
                }}
              />
            </div>

            <div
              className="topbtnItem"
              onClick={() => {
                setCreateOption(4);
              }}
            >
              <div
                className="btn-text"
                style={{ color: createoption === 4 ? "#F95192" : "#FFB4D0" }}
                onClick={() => {
                  renders("pool");
                }}
              >
                Create subscription pool
              </div>
              <div
                className="topbtn-line"
                style={{
                  background: createoption === 4 ? "#F95192" : "transparent",
                }}
              />
            </div> */}

            <div
              className="topbtnItem"
              onClick={() => {
                setCreateOption(5);
              }}
            >
              <div
                className="btn-text"
                style={{ color: createoption === 5 ? "#F95192" : "#FFB4D0" }}
                onClick={() => {
                  renders("token");
                }}
              >
                {`${t("Create token")}`}
              </div>
              <div
                className="topbtn-line"
                style={{
                  background: createoption === 5 ? "#F95192" : "transparent",
                }}
              />
            </div>
          </div>
          {renderCreateLauch()}
          {content !== 'token' ? <LaunchpadRoadmapMobile step={1} /> : ''}
          <div className="disclaimer">
            {`${t(
              "Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published."
            )}`}
          </div>
          <div className="bottom-Area">
            <img src={require(`../../assets/image/sleepingCat.png`)} alt="" />
          </div>
        </div>
      </div>
    );
  };
  useEffect(() => {
    if (props.location.state != undefined) {
      const { BackState } = props.location.state;
      setBackstate((state: any) => {
        return (state = BackState);
      });
    }
  }, [backstate]);
  return (
    <div className="LanchPage">
      {renderPCContent()}
      {renderMobileContent()}
    </div>
  );
};

export default Lauch;
