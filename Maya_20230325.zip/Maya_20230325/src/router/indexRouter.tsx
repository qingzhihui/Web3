import React, { Suspense } from "react";
import { HashRouter, Route, Switch, Redirect } from "react-router-dom";
import App from "../App";
import Admin from "../view/Admin";
import Home from "../view/Home";
import AntiBot from "../view/AntiBot";
import Airdrop from "../view/Airdrop";
import Lauchpad from "../view/Lauchpad";
import Leaderboard from "../view/Leaderboard";
import Liquidity from "../view/Liquidity";
import Lock from "../view/Lock";
import MultiSender from "../view/MultiSender";
import Sale from "../view/Sale";
import Token from "../view/Token";
import Presale from "../view/Presale";
import PrivateSale from "../view/PrivateSale";
import Create from "../view/Create";
import Comfrimation from "../view/Comfrimation";
import UpdateLock from "../view/UpdateLock";
import LockRecordInfo from "../view/LockRecordInfo";
import LockInfo from "../view/LockInfo";
import lpLocksRecord from "../view/lpLocksRecord";
import lpLockInfo from "../view/lpLockInfo";
import antibotPon from "../view/antibotPon";
import CreateAirdrop from "../view/CreateAirdrop";
import SomebodyAirdrop from "../view/SomebodyAirdrop";
import Burn from "../view/Burn";
import Whitelist from "../view/WhiteList";
import PrivateSaleCurrency from "../view/PrivateSaleCurrency";
import CurrentPresales from "../view/CurrentPresales";
import Loading from "../components/Loading";
import CreateAirece from "../view/CreateAirece";
import CreateUpdata from "../view/CreateUpdata";

export default function Router() {
  return (
    <HashRouter>
      <App>
        <Suspense fallback={<Loading />}>
          <Route
            path="/"
            render={() => (
              <Admin>
                <Switch>
                  <Route path="/Home" component={Home} />
                  <Route path="/Airdrop" component={Airdrop} />
                  <Route path="/AntiBot" component={AntiBot} />
                  <Route path="/Lauchpad" component={Lauchpad} />
                  <Route path="/Leaderboard" component={Leaderboard} />
                  <Route path="/Liquidity" component={Liquidity} />
                  <Route path="/Lock" component={Lock} />
                  <Route path="/MultiSender" component={MultiSender} />
                  <Route path="/Sale" component={Sale} />
                  <Route path="/Token" component={Token} />
                  <Route path="/Presale" component={Presale} />
                  <Route path="/PrivateSale" component={PrivateSale} />
                  <Route path="/Create" component={Create} />
                  <Route path="/Comfrimation" component={Comfrimation} />
                  <Route path="/UpdateLock" component={UpdateLock} />
                  <Route path="/LockRecordInfo" component={LockRecordInfo} />
                  <Route path="/LockInfo" component={LockInfo} />
                  <Route path="/lpLocksRecord" component={lpLocksRecord} />
                  <Route path="/lpLockInfo" component={lpLockInfo} />
                  <Route path="/antibotPon" component={antibotPon} />
                  <Route path="/CreateAirdrop" component={CreateAirdrop} />
                  <Route path="/SomebodyAirdrop" component={SomebodyAirdrop} />
                  <Route path="/Burn" component={Burn} />
                  <Route path="/Whitelist" component={Whitelist} />
                  <Route path="/CreateAirece" component={CreateAirece} />
                  <Route path="/CreateUpdata" component={CreateUpdata} />
                  <Route
                    path="/PrivateSaleCurrency"
                    component={PrivateSaleCurrency}
                  />
                  <Route path="/CurrentPresales" component={CurrentPresales} />
                  <Redirect from="/" to="/Home" />
                </Switch>
              </Admin>
            )}
          />
        </Suspense>
      </App>
    </HashRouter>
  );
}
