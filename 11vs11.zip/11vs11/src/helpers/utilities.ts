import { IChainData } from "./types";
import { supportedChains } from "./chains";

export function getChainData(chainId: number): IChainData {
  const chainData = supportedChains.filter(
    (chain: any) => chain.chain_id === chainId
  )[0];

  if (!chainData) {
    throw new Error("ChainId missing or not supported");
  }

  const API_KEY = process.env.REACT_APP_INFURA_ID;

  if (
    chainData.rpc_url.includes("infura.io") &&
    chainData.rpc_url.includes("%API_KEY%") &&
    API_KEY
  ) {
    const rpcUrl = chainData.rpc_url.replace("%API_KEY%", API_KEY);

    return {
      ...chainData,
      rpc_url: rpcUrl,
    };
  }

  return chainData;
}

export function switchToBNB(provider: any) {
  const chainId = 97;

  provider.request({
    method: "wallet_addEthereumChain",
    params: [
      {
        chainId: "0x" + chainId.toString(16),
        rpcUrls: ["https://bsc.mytokenpocket.vip/"],
      },
    ],
  });
}

export const conciseAddress = (
  address: string,
  startSlice = 6,
  endSlice = 3
): string => {
  return `${address.slice(0, startSlice)}...${address.slice(
    address.length - endSlice,
    address.length
  )}`;
};
