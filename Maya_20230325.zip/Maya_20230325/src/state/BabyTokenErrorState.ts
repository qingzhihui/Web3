import { BabyTokenError } from "../hooks/Errorhandle";

const BabyTokenErrorInitState: BabyTokenError = {
    NameBlankError: false,
    NameCharactersError: false,
    SymbolBlankError: false,
    SymbolCharactersError: false,
    TotalSupplyBlankError: false,
    TotalSupplyAmountError: false,
    RewardTokenBlankError: false,
    RewardTokenInvalidError: false,
    DividendsBlankError: false,
    DividendsMaxError: false,
    RewardFeeBlankError: false,
    RewardFeeMinError: false,
    LiquidityFeeBlankError: false,
    LiquidityFeeMinError: false,
    MarketingFeeBlankError: false,
    MarketingFeeMinError: false,
    FeeOverError: false,
    WalletBlankError: false,
    WalletInvalidError: false,
};

export {
    BabyTokenErrorInitState
};