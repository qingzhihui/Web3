import React from "react";
import "./App.css";

export default function App(props: any) {
  return <div>{props.children}</div>;
}
