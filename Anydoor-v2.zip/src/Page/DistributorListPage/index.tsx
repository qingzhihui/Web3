import { Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";
import {
  DeleteOutlined,
  SelectOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";

// 分销商列表界面
const DistributorListPage = () => {
  interface DataType {
    key: number;
    distributor: string; // 分销商
    status: string; //状态
  }

  const data: DataType[] = [
    {
      key: 1,
      distributor: "酒店",
      status: "已通过",
    },
    {
      key: 2,
      distributor: "机票",
      status: "待审核",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "酒店",
      dataIndex: "distributor",
      // width: 200,
    },
    {
      title: "状态",
      dataIndex: "status",
      // width: 120,
      render: (_text, record) => (
        <Space size="middle">
          <span style={{ color: _text == "待审核" ? "#3296FA" : "" }}>
            {_text}
          </span>
        </Space>
      ),
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="fxsList_memberCursor">
            <CheckCircleOutlined
              style={{ color: record.status == "已通过" ? "#999" : "" }}
            />
          </span>
          <span className="fxsList_memberCursor">
            <SelectOutlined />
          </span>
          <span className="fxsList_memberCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };

  return (
    <div className="fxsList_Box">
      <div className="fxsList_headerBox">
        <div className="fxsList_headerBox_thread"></div>
        <div className="fxsList_headerBox_Tit">&nbsp;&nbsp;&nbsp; 分销商列表</div>
      </div>

      <div className="fxsList_tableBox">
        <Table columns={columns} dataSource={data} />
      </div>
    </div>
  );
};

export default DistributorListPage;
