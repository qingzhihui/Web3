<template>
  <div class="container">

  </div>
</template>

<script setup lang="ts">
const layout = () => {
  console.log('123')
}

// window.onresize = layout;

function debounce(fu, delay) {
  var timerId;
  return function () {
    clearTimeout(timerId)
    timerId = setTimeout(fu, delay)
  }
}

var func = debounce(layout, 1000)
//一秒钟后，调用layout
window.onresize = func;


//思考题：如果layout要传4个参数，那么你调func的时候肯定要传递4个参数进去，那个这个防抖怎么写

</script>

<style>


</style>
