import React, { useEffect, useCallback, useState, useMemo, useRef } from 'react'
import { useTranslation } from 'contexts/Localization'
const Cesop = (props: any) => {
  const { t } = useTranslation()
  return (
    <div className="snueLIse">
      <div className="snueLIsevlog">
        <div className='imgls'></div>
      </div>
      <div className="snueLIsetile">{t(props.name)}</div>
    </div>
  )
}
export default Cesop
