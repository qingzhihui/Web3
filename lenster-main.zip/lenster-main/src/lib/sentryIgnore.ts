export const denyUrls = [
  // Browser extensions
  /^chrome-extension:\/\//i,
  /^moz-extension:\/\//i,
  /^safari-web-extension:\/\//i
]
