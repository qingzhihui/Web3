import React, { useEffect, useState } from "react";
import "./index.css";
import { ethers } from "ethers";
import { useTranslation } from "react-i18next";
import { RedoOutlined, CloseCircleOutlined } from "@ant-design/icons";
import { PAIR_ABI } from "../../redux/Contract/pancakepair";
import { Meta_ADDRESS, Meta_ABI } from "../../redux/Contract/MetaContract";
declare const window: Window & { ethereum: any };

const MINUTE_MS = 2000;

const Index = (props: any) => {
  const [pending, setPending] = useState("");
  const [Dividend, setDividend] = useState("");
  const [LPAmount, setLPAmount] = useState("");
  const [oneStar, setOneStar] = useState("");
  const [twoStar, setTwoStar] = useState("");
  const [threeStar, setthreeStar] = useState("");
  const [levels, setlevels] = useState("");

  const upeoiru = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const MetaContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
    const pendingMiningReward = await MetaContract.pendingMiningReward(
      props.pid,
      address
    );
    const pendingDividendReward = await MetaContract.pendingDividendReward(
      props.pid,
      address
    );
    const getTotalRedeemableLPAmount =
      await MetaContract.getTotalRedeemableLPAmount(props.pid, address);
    const oneStarThreshold = await MetaContract.oneStarUserpledgeThreshold();
    const twoStarThreshold = await MetaContract.twoStarUserpledgeThreshold();
    const threeStarThreshold =
      await MetaContract.threeStarUserpledgeThreshold();
    const oneStarLP = await MetaContract.getUSDTAmountTransferToLPAmount(
      props.pid,
      oneStarThreshold
    );
    const twoStarLP = await MetaContract.getUSDTAmountTransferToLPAmount(
      props.pid,
      twoStarThreshold
    );
    const threeStarLP = await MetaContract.getUSDTAmountTransferToLPAmount(
      props.pid,
      threeStarThreshold
    );
    const pendingMining = Number(
      ethers.utils.formatUnits(pendingMiningReward.toString(), 18)
    ).toFixed(7);
    setPending(pendingMining);
    const pendingDividend = Number(
      ethers.utils.formatUnits(pendingDividendReward.toString(), 18)
    ).toFixed(7);
    setDividend(pendingDividend);
    const redeemableLPAmount = Number(
      ethers.utils.formatUnits(getTotalRedeemableLPAmount.toString(), 18)
    ).toFixed(7);
    setLPAmount(redeemableLPAmount);
    const oneStarUser = ethers.utils.formatUnits(oneStarLP.toString(), 18);
    setOneStar(oneStarUser);
    const twoStarUser = ethers.utils.formatUnits(twoStarLP.toString(), 18);
    setTwoStar(twoStarUser);
    const threeStarUser = ethers.utils.formatUnits(threeStarLP.toString(), 18);
    setthreeStar(threeStarUser);
    const level = await MetaContract.level(props.pid, address);
    const levels = level.toString();
    setlevels(levels);
  };
  const showHide2 = () => {
    props.onHIde();
  };

  const { t } = useTranslation();
  useEffect(() => {
    upeoiru();
    const interval = setInterval(async () => {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const address = await signer.getAddress();
      const MetaContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const pendingMiningReward = await MetaContract.pendingMiningReward(
        props.pid,
        address
      );
      const pendingDividendReward = await MetaContract.pendingDividendReward(
        props.pid,
        address
      );
      const getTotalRedeemableLPAmount =
        await MetaContract.getTotalRedeemableLPAmount(props.pid, address);
      const oneStarThreshold = await MetaContract.oneStarUserpledgeThreshold();
      const twoStarThreshold = await MetaContract.twoStarUserpledgeThreshold();
      const threeStarThreshold =
        await MetaContract.threeStarUserpledgeThreshold();
      const oneStarLP = await MetaContract.getUSDTAmountTransferToLPAmount(
        props.pid,
        oneStarThreshold
      );
      const twoStarLP = await MetaContract.getUSDTAmountTransferToLPAmount(
        props.pid,
        twoStarThreshold
      );
      const threeStarLP = await MetaContract.getUSDTAmountTransferToLPAmount(
        props.pid,
        threeStarThreshold
      );
      const pendingMining = Number(
        ethers.utils.formatUnits(pendingMiningReward.toString(), 18)
      ).toFixed(7);
      setPending(pendingMining);
      const pendingDividend = Number(
        ethers.utils.formatUnits(pendingDividendReward.toString(), 18)
      ).toFixed(7);
      setDividend(pendingDividend);
      const redeemableLPAmount = Number(
        ethers.utils.formatUnits(getTotalRedeemableLPAmount.toString(), 18)
      ).toFixed(7);
      setLPAmount(redeemableLPAmount);
      const oneStarUser = ethers.utils.formatUnits(oneStarLP.toString(), 18);
      setOneStar(oneStarUser);
      const twoStarUser = ethers.utils.formatUnits(twoStarLP.toString(), 18);
      setTwoStar(twoStarUser);
      const threeStarUser = ethers.utils.formatUnits(
        threeStarLP.toString(),
        18
      );
      setthreeStar(threeStarUser);
      const level = await MetaContract.level(props.pid, address);
      const levels = level.toString();
      setlevels(levels);
    }, MINUTE_MS);
    return () => clearInterval(interval);
  }, [pending, Dividend, LPAmount, oneStar, twoStar, threeStar, levels]);
  return (
    <div className="pserPsders">
      <div
        className="pserzhes"
        onClick={() => {
          props.onHIde();
        }}
      ></div>
      <div className="pserTisepeo">
        {pending === "" ? (
          <div className="lodingS">
            <div className="seuniser">
              <div className="proouise">
                <RedoOutlined
                  spin
                  style={{ fontSize: "28px", color: "#fff" }}
                />
              </div>
              {`${t("Loading...")}`}
            </div>
          </div>
        ) : (
          <div className="pserExchange_nronur">
            <div className="DataItemColumnOnepro">
              <div className="itemimg">
                <img
                  src="https://cloud-data-s2-images.fistdao.finance/usdt.png"
                  alt=""
                />
                <div className="utopm">
                  <img
                    src="https://cloud-data-s2-images.fistdao.finance/usdt.png"
                    alt=""
                  />
                </div>
              </div>
              <div className="DataItemColumnOneRight">
                <div className="dreamDaoText">ABC/USDT</div>
              </div>
            </div>
            <div className="DataItemColumnTwo2">
              <div className="APRTitle">{`${t("Star rating")}`}:</div>
              <div className="APRRightArea">
                <span className="APRNumberOne">{levels || 0}</span>
              </div>
            </div>
            <div className="DataItemColumnTwo2">
              <div className="APRTitle">{`${t("pendingMiningReward")}`}:</div>
              <div className="APRRightArea">
                <span className="APRNumberOne">{pending || 0}</span>
              </div>
            </div>
            <div className="DataItemColumnTwo2">
              <div className="APRTitle">{`${t("pendingDividendReward")}`}:</div>
              <div className="APRRightArea">
                <span className="APRNumberOne">{Dividend || 0}</span>
              </div>
            </div>
            <div className="DataItemColumnTwo2">
              <div className="APRTitle">{`${t("redeemableLPAmount")}`}:</div>
              <div className="APRRightArea">
                <span className="APRNumberOne">{LPAmount || 0}</span>
              </div>
            </div>
            <div className="DataItemColumnTwo2">
              <div className="APRTitle">{`${t("One star threshold")}`}:</div>
              <div className="APRRightArea">
                <span className="APRNumberOne">{oneStar || 0}</span>
              </div>
            </div>
            <div className="DataItemColumnTwo2">
              <div className="APRTitle">{`${t("Two star threshold")}`}:</div>
              <div className="APRRightArea">
                <span className="APRNumberOne">{twoStar || 0}</span>
              </div>
            </div>
            <div className="DataItemColumnTwo2">
              <div className="APRTitle">{`${t("Three star threshold")}`}:</div>
              <div className="APRRightArea">
                <span className="APRNumberOne">{threeStar || 0}</span>
              </div>
            </div>
          </div>
        )}
        <div
          className="gbuiengkumpro"
          onClick={() => {
            showHide2();
          }}
        >
          <CloseCircleOutlined
            style={{
              color: "#ffff",
              fontSize: "28px",
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default Index;
