import { IChainData } from "./types";

export const supportedChains: IChainData[] = [
  {
    name: "Binance Smart Chain Test net",
    short_name: "bsc-testnet",
    chain: "smartchain",
    network: "testnet",
    chain_id: 97,
    network_id: 97,
    rpc_url: "https://bsc-dataseed1.defibit.io/",
    native_currency: {
      symbol: "BNB",
      name: "BNB",
      decimals: "18",
      contractAddress: "",
      balance: "",
    },
  },
  // {
  //   name: "ETH Mainnet",
  //   short_name: "ETH",
  //   chain: "Ethereum",
  //   network: "Mainnet",
  //   chain_id: 1,
  //   network_id: 1,
  //   rpc_url: "https://rpc.ankr.com/eth",
  //   native_currency: {
  //     symbol: "ETH",
  //     name: "Ethereum",
  //     decimals: "18",
  //     contractAddress: "",
  //     balance: "",
  //   },
  // },
  // {
  //   name: "AVAX-C Mainnet",
  //   short_name: "ETH",
  //   chain: "Avalanche C-Chain",
  //   network: "Mainnet",
  //   chain_id: 43114,
  //   network_id: 43114,
  //   rpc_url: "https://rpc.ankr.com/avalanche",
  //   native_currency: {
  //     symbol: "AVAX",
  //     name: "AVAX",
  //     decimals: "18",
  //     contractAddress: "",
  //     balance: "",
  //   },
  // },
  // {
  //   name: "Binance Smart Chain",
  //   short_name: "bsc",
  //   chain: "smartchain",
  //   network: "mainnet",
  //   chain_id: 56,
  //   network_id: 56,
  //   rpc_url: "https://bsc.mytokenpocket.vip/",
  //   native_currency: {
  //     symbol: "BNB",
  //     name: "BNB",
  //     decimals: "18",
  //     contractAddress: "",
  //     balance: "",
  //   },
  // },
  // {
  //   name: "Binance Smart Chain Test net",
  //   short_name: "bsc-testnet",
  //   chain: "smartchain",
  //   network: "testnet",
  //   chain_id: 97,
  //   network_id: 97,
  //   rpc_url: "https://bsc-dataseed1.defibit.io/",
  //   native_currency: {
  //     symbol: "BNB",
  //     name: "BNB",
  //     decimals: "18",
  //     contractAddress: "",
  //     balance: "",
  //   },
  // },
];

export const supportedChainsID: number[] = supportedChains.map(
  (chainData) => chainData.chain_id
);
