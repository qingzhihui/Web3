import React from 'react'

function Farm() {
  return (
    <div>
      Farm
    </div>
  )
}

export default Farm
