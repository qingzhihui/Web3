import React, { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import {useLocation } from "react-router-dom";
import { childProps, RouterConfig } from "../../config/config";
import { useNavigate } from "react-router-dom";
import "./index.css";

// 系统设置界面
const EssayNotes = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id, url } = location.state;
  const [perNro, setPerNro] = useState({
    perId: id,
    perUrl: url,
  });
  const [perData, setPerData] = useState<childProps[]>([]);
  const [action, setAction] = useState(0);

  const ItenMuiser = (id: any) => {
    const RouterData: any = [];
    for (let index = 0; index < RouterConfig.length; index++) {
      if (RouterConfig[index].key === id) {
        RouterConfig[index].children?.map((item: any) => {
          RouterData.push(item);
        });
      }
    }
    setPerData((state: any) => {
      return (state = RouterData);
    });
  };
  const outletonClick = (data: any) => {
    setAction((state: any) => {
      return (state = data.key);
    });
    navigate(`${perNro.perUrl}${data.url}`, { state: {} });
  };
  useEffect(() => {
    console.log(perNro);

    ItenMuiser(perNro.perId);
  }, [perNro]);

  return (
    <div className="outletComonent">
      <div className="outletComLent">
        <div className="outletComLent_data">
          {/* outlAction */}
          {perData.map((item: any) => (
            <div
              key={item.key}
              onClick={() => {
                outletonClick(item);
              }}
              className={`outletComLent_item ${
                action === item.key ? "outlAction" : ""
              }`}
            >
              <span>{item.title}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="outletComRent">
        <Outlet />
      </div>
    </div>
  );
};

export default EssayNotes;
