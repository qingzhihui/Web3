<template>
  <div class="container">

  </div>
</template>

<script setup lang="ts">
//RAF
requestAnimationFrame(function () {

})

// 计时器动画
function ches (x, ball) {
  setInterval(function () {
    x++;
    ball.style.left = screenX + 'px';
  }, 16);
}

function raf() {
  requestAnimationFrame(function () {
    //设置动画，例如改变位置
    raf(); // 继续设置下一帧
  })
}
</script>

<style>


</style>
