import { DeleteOutlined, FormOutlined, PlusOutlined } from "@ant-design/icons";
import {
  Button,
  Form,
  Input,
  Modal,
  Radio,
  Select,
  Space,
  Table,
  Upload,
  UploadFile,
  UploadProps,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import { RcFile } from "antd/es/upload";
import { useState } from "react";
import "./index.css";

// 广告管理界面
const AdvertisingManag = () => {
  const [isAddAdvertising, setAddAdvertising] = useState(false);

  interface DataType {
    key: number;
    title: string;
    images: string;
    type: string;
    status: string;
  }

  const data: DataType[] = [
    {
      key: 1,
      title: "世界美好",
      images:
        "https://img2.baidu.com/it/u=3251517863,3422665060&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1679504400&t=7be388dab3d0846584b692ad2ebe5ecb",
      type: "著游Banner",
      status: "点击禁用",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "排序",
      dataIndex: "key",
      width: 200,
    },
    {
      title: "标题",
      dataIndex: "title",
      width: 200,
    },
    {
      title: "图片",
      render: (_, record) => (
        <Space size="middle">
          <img className="adver_Tab" src={record.images} alt="" />
        </Space>
      ),
    },
    {
      title: "类型",
      dataIndex: "type",
      width: 200,
    },
    {
      title: "状态",
      render: (_, record) => (
        <Space size="middle">
          <div onClick={forbiddenBtn(record)} className="adver_tagsStyle">{record.status}</div>
        </Space>
      ),
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="adver_publicCursor" onClick={uploadus(record)}>
            <FormOutlined />
          </span>
          <span className="adver_publicCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });

  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewTitle, setPreviewTitle] = useState("");
  const [fileList, setFileList] = useState<UploadFile[]>([]);

  const handleCancel1 = () => setPreviewOpen(false);

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
    setPreviewTitle(
      file.name || file.url!.substring(file.url!.lastIndexOf("/") + 1)
    );
  };

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) =>
    setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );

  // 禁用按钮
  const forbiddenBtn= (record: any) => {
    return () => {
      console.log("点击了禁用");
      console.log(record.key);
    };
  };
  // 新增广告---下拉选择框-广告类型-内容
  const options1 = [
    {
      value: "1",
      label: "开屏广告",
    },
    {
      value: "2",
      label: "积分商城轮播图",
    },
    {
      value: "3",
      label: "首页Banner",
    },
    {
      value: "4",
      label: "奢旅Banner",
    },
    {
      value: "5",
      label: "演出展会首页Banner",
    },
    {
      value: "6",
      label: "会员权益页广告",
    },
  ];

  // 新增广告---下拉选择-广告类型---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };

  // 新增广告---下拉选择框-跳转路径-内容
  const options2 = [
    {
      value: "1",
      label: "内部网页跳转",
    },
    {
      value: "2",
      label: "外部网页跳转",
    },
    {
      value: "3",
      label: "关联小程序跳转",
    },
  ];

  // 新增广告---下拉选择-跳转路径---选中内容
  const handleChange11 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };

  const onFinish = (values: any) => {
    console.log("Success:", values);
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log("Failed:", errorInfo);
  };

  // 修改
  const uploadus = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };
  // 点击X关闭
  const handleCancel = () => {
    setAddAdvertising(false);
  };

  // 点击新增分类
  const usAddUser = () => {
    console.log("点击了新增分类");
    setAddAdvertising(true);
  };

  return (
    <div className="adver_Box">
      <div className="adver_headerBox">
        <div className="adver_headerBox_thread"></div>
        <div className="adver_headerBox_Tit">&nbsp;&nbsp;&nbsp; 广告管理</div>
        <div className="adver_Add_moban">
          <div className="adver_addAdminBtn" onClick={usAddUser}>
            新增广告
          </div>
          {/* 新增用户 */}
          <Modal
            className="adver_addAdmin"
            footer={[null]}
            open={isAddAdvertising}
            onCancel={handleCancel}
          >
            <div className="adver_headerBox">
              <div className="adver_headerBox_thread"></div>
              <div className="adver_headerBox_Tit">
                &nbsp;&nbsp;&nbsp;新增广告
              </div>
            </div>
            <div className="adver_addAdmin_Box">
              <Form
                name="basic"
                labelCol={{ span: 6 }}
                wrapperCol={{ span: 18 }}
                style={{ maxWidth: 600 }}
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
              >
                <Form.Item label="广告类型" name="ggtype">
                  <Select
                    labelInValue
                    defaultValue={{ value: "1", label: "开屏广告" }}
                    style={{ width: 120 }}
                    onChange={handleChange1}
                    options={options1}
                  />
                </Form.Item>
                <Form.Item label="用户头像" name="templateCode">
                  <Upload
                    action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                    listType="picture-card"
                    fileList={fileList}
                    onPreview={handlePreview}
                    onChange={handleChange}
                  >
                    {fileList.length >= 1 ? null : uploadButton}
                  </Upload>
                  <Modal
                    open={previewOpen}
                    title={previewTitle}
                    footer={null}
                    onCancel={handleCancel1}
                  >
                    <img
                      alt="example"
                      style={{ width: "100%" }}
                      src={previewImage}
                    />
                  </Modal>
                </Form.Item>
                <Form.Item
                  label="标题"
                  name="title"
                  rules={[{ required: true, message: "请输入模板标题!" }]}
                >
                  <Input placeholder="请输入模板标题" />
                </Form.Item>
                <Form.Item label="选择跳转路径" name="tzurl">
                  <Select
                    labelInValue
                    defaultValue={{ value: "1", label: "内部网页跳转" }}
                    style={{ width: 120 }}
                    onChange={handleChange11}
                    options={options2}
                  />
                </Form.Item>
                <Form.Item label="内部链接" name="title">
                  <Input placeholder="若需要带参数，请在页面路径后?a=1&b=2" />
                </Form.Item>
                <Form.Item
                  label="排序"
                  name="px"
                  rules={[{ required: true, message: "请输入排序!" }]}
                >
                  <Input placeholder="请输入排序" />
                </Form.Item>

                <Form.Item label="状态" name="disabledOrNot">
                  <Radio.Group>
                    <Radio value="apple"> 启用 </Radio>
                    <Radio value="pear"> 禁用 </Radio>
                  </Radio.Group>
                </Form.Item>

                <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                  <Button
                    className="adver_btn"
                    size="middle"
                    type="primary"
                    htmlType="submit"
                  >
                    提交
                  </Button>
                </Form.Item>
              </Form>
            </div>
          </Modal>
        </div>
      </div>

      <div className="adver_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default AdvertisingManag;
