import React from "react";

const Rushtourse = () => {
  return <div>抢购</div>;
};

export default Rushtourse;
