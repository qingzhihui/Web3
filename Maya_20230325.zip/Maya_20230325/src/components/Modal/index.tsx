import React from "react";
import { CloseCircleOutlined } from "@ant-design/icons";
import "./index.css";
import "./mobile.css";
import { useTranslation, Trans } from "react-i18next";
interface ButtonProps {
    page: string;
    content: string;
    title: string;
    closedModal: () => void;
}

// export default function Modal(props: ButtonProps) {
    // 定义函数组件的第一种写法
    // const { page, content, title , closedModal} = props;

    // 定义函数组件的第二种写法
    const Modal: React.FC<ButtonProps> = ({ page, content, title , closedModal}) => {
    const { t } = useTranslation();

    return (
        <div className="ModalBg">
        <CloseCircleOutlined
            className="closed"
            onClick={() => {
                closedModal();
            }}
        />
        <div className="modal-title">{`${t(title)}`}</div>

        <div className=""></div>
        </div>
    );
}

export default Modal
