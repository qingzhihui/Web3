<template>
  <div class="poem">
    
  </div>
</template>

<script setup lang="ts">
//整个表达式会得到什么样的结果
['1', '2', '3'].map(parseInt)
console.log(parseInt('a')) //NaN
console.log(['1', '2', '3'].map(parseInt))
// ['1', '2', '3'].map(函数)
// [
//     函数('1', 0), // parseInt('1', 0) 得到1
//     函数('2', 1), // parseInt('2', 1) 得到NaN
//     函数('3', 2) // parseInt('3',2) 得到NaN
// ]
// parseInt有两种用法
// 第一种传一个参数
// 第二种传两个参数 （第二个参数是一个数字，取值是2到36之间，他表示进制）


//思考题
console.log(['0b11', '0x12', '013'].map(parseInt))
</script>

<style>

</style>
