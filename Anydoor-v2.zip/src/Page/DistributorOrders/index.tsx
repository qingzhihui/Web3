import { Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

// 分销商订单界面
const DistributorOrders = () => {
  interface DataType {
    key: number;
    orderNumber: string; // 订单编号
    usernmae: string; // 用户名
    paymentAmount: string; // 支付金额
    createTime: string; // 创建时间
    status: string; //状态
  }

  const data: DataType[] = [
    {
      key: 1,
      orderNumber: "11656464616814",
      usernmae: "admin",
      paymentAmount: "618.00",
      createTime: "2023-01-01 17:00:00",
      status: "待支付",
    },
    {
      key: 2,
      orderNumber: "16464616461616",
      usernmae: "lalala",
      paymentAmount: "588.00",
      createTime: "2023-03-04 09:10:00",
      status: "已支付",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "订单编号",
      dataIndex: "orderNumber",
      // width: 200,
    },
    {
      title: "用户名",
      dataIndex: "usernmae",
      // width: 200,
    },
    {
      title: "支付金额",
      dataIndex: "paymentAmount",
      // width: 120,
    },
    {
      title: "创建时间",
      dataIndex: "createTime",
      // width: 120,
    },
    {
      title: "状态",
      dataIndex: "status",
      // width: 120,
      render: (_text, record) => (
        <Space size="middle">
          <span style={{ background: _text == "已支付" ? "#3296FA" : "#F0AD4E" }} className="fxsdj_status">{_text}</span>
        </Space>
      ),
    },
  ];

  return (
    <div className="fxsdj_Box">
      <div className="fxsdj_headerBox">
        <div className="fxsdj_headerBox_thread"></div>
        <div className="fxsdj_headerBox_Tit">&nbsp;&nbsp;&nbsp; 分销商订单</div>
      </div>

      <div className="fxsdj_tableBox">
        <Table columns={columns} dataSource={data} />
      </div>
    </div>
  );
};

export default DistributorOrders;
