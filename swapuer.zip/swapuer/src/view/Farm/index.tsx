import React from 'react'
import Header from '../../components/Header'

function Farm() {
  return (
    <div>
      <Header />
      Farm
    </div>
  )
}

export default Farm
