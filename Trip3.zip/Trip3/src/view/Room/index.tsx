import React from 'react'
import './index.scss'
import Roomcard from '@/components/Roomcard'
import Evalu from '@/components/Evalu'
import { Progress } from 'antd';

export default function index() {
  return (
    <div className='room'>
      <div className='select'>
        <div className='selecttop'>
          <div><img src={require('@/assets/image/am.png')} alt="" /></div>
          <div className='aman'>
            <div className='title'>Aman at Summer Palace</div>
            <div className='infa'><img src={require('@/assets/image/tablermap.png')} alt="" /> 1 Gongmenqian Street, China</div>
            <div className='infa'>Aman Summer Palace Beijing is located at the east gate of the Summer Palace, ...</div>
          </div>
          <div className='selectbut'>select room type</div>
        </div>
        <div className='selectbuttom'>
          <img src={require('@/assets/image/image11.png')} alt="" />
          <img src={require('@/assets/image/image12.png')} alt="" />
          <img src={require('@/assets/image/image13.png')} alt="" />
          <img src={require('@/assets/image/image14.png')} alt="" />
        </div>
      </div>
      <div className='room_type'>
        <div className='type'>Room type</div>
        <Roomcard />
        <Roomcard />
        <Roomcard />
        <Roomcard />
      </div>
      <div className='evaluation'>
        <div className='title'>Evaluation</div>
        <div className='verygood'>
          <div className='goodletf'>
            <div className='percentsign'><img src={require('@/assets/image/diamond.png')} alt="" />4.7 / 5</div>
            <div className='good'>very good</div>
          </div>
          <div className='goodright'>
            <div className='progressbar'>
              <div className='progressbartop'>
                <div>Cleanliness</div>
                <div>4.7</div>
              </div>
              <div className='progressbarbuttom'>
                <Progress percent={50} showInfo={false} strokeColor="black" />
              </div>
            </div>
            <div className='progressbar'>
              <div className='progressbartop'>
                <div>Cleanliness</div>
                <div>4.7</div>
              </div>
              <div className='progressbarbuttom'>
                <Progress percent={50} showInfo={false} strokeColor="black" />
              </div>
            </div>
            <div className='progressbar'>
              <div className='progressbartop'>
                <div>Cleanliness</div>
                <div>4.7</div>
              </div>
              <div className='progressbarbuttom'>
                <Progress percent={50} showInfo={false} strokeColor="black" />
              </div>
            </div>
            <div className='progressbar'>
              <div className='progressbartop'>
                <div>Cleanliness</div>
                <div>4.7</div>
              </div>
              <div className='progressbarbuttom'>
                <Progress percent={50} showInfo={false} strokeColor="black" />
              </div>
            </div>
          </div>
        </div>
        <Evalu />
        <Evalu />
        <Evalu />
      </div>
    </div>
  )
}
