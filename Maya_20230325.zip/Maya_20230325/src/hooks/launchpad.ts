import LaunchPadFactoryABI from "../config/abi/LaunchPadFactory.json";
import StdRouterABI from "../config/abi/StdRouter.json";
import LaunchPadABI from "../config/abi/LaunchPad.json";
const LaunchPadFactoryAddress = "0x1BaBD6Aebe5b61503d74eeFE63001748f79727F3";

export interface WhitelistProps {
  prerate?: string;
  able?: string;
  usevest?: boolean;
  softcap?: string;
  hardcap?: string;
  minbuy?: string;
  maxbuy?: string;
  liquidity?: string;
  listingrate?: string;
  lockup?: string;
  firstrelease?: string;
  vestperiod?: string;
  pretokencycle?: string;
  Starttime?: string; //开始时间
  Endtime?: string; //结束时间
  Refund?: string;
  Router?: string;
}

export interface LaunchpadProps {
  routeName?: string;
  inputValue?: string;
  Radiovalue?: string;
  FeeOptions?: string;
  ListingOptions?: string;
  FeeTokenSymbol?: string;
  FeeTokenDecimals?: number;
  IcoTokenSymbol?: string;
  IcoTokenDecimals?: number;
}

export interface sleaProps {
  routeName?: string;
  inputValue?: string;
  Radiovalue?: string;
  FeeOptions?: string;
  ListingOptions?: string;
  FeeTokenSymbol?: string;
  FeeTokenDecimals?: number;
}

export {
  LaunchPadFactoryABI,
  LaunchPadFactoryAddress,
  StdRouterABI,
  LaunchPadABI,
};
