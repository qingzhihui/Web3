import React, { useEffect, useState } from "react";
import Web3 from "web3";
import { Meta, PAIR_ABI } from "../redux/Api/api";
import { Pidate } from "./TimeDate";
declare const window: Window & { ethereum: any };

let metaContract: any;

const Orderrecord = async () => {
  let provider = window.ethereum;
  const web3 = new Web3(provider);
  const Poser: any = [];
  metaContract = new web3.eth.Contract(Meta.Meta_ABI, Meta.Meta_ADDRESS);
  for (let index = 0; index < 4; index++) {
    await metaContract.methods
      .getUserAllDepositInfoInPool(
        index,
        "0x8566267a72019BE5C925aA60e813D079a435bd2E"
      )
      .call()
      .then((res: any) => {
        const Threea: any = [];
        res.map(async (item: any) => {
          const canWithdraw = await metaContract.methods
            .canWithdrawOrNot(item[8].toString())
            .call();
          const redeemdate = await metaContract.methods
            .getNextRedemptionStartTime(item[8].toString())
            .call();
          const endeemdate = await metaContract.methods
            .getNextRedemptionEndTime(item[8].toString())
            .call();
          const bgoData = {
            PId: item[0].toString(),
            lpToken: item[1].toString(),
            poolType: item[2].toString(),
            pledgee: item[3].toString(),
            depositTime: item[8].toString(),
            redeemdate: redeemdate.toString(),
            redprodate: Pidate(redeemdate.toString()),
            endeemdate: endeemdate.toString(),
            endprodate: Pidate(endeemdate.toString()),
            start: canWithdraw,
            pendingRewad: "",
            pendingDividend: "",
          };
          Threea.push(bgoData);
        });
        Poser.push(Threea)
      });
  }
  return Poser;
};

export { Orderrecord };
