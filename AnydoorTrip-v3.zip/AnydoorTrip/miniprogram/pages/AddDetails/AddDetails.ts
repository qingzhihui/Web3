import { AddcertProps, cellValueData } from "../../config/addhooke";
import { formatTime } from "../../utils/util";
import { ConvertPinyin } from '../../config/ChineseHelper.js';
import api from '../../config/axios'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    show: false,
    showpopup: false,
    Birthday: false,
    nationality: false,
    phone: false,
    nationalityValue: "",
    BirthdayDate: "",
    currentDate: new Date().getTime(),
    minDate: new Date(1949, 10, 1).getTime(),
    formatter(type: any, value: any) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    cellData: cellValueData,
    phoneValue: "86",
    radio: 'male',
    columns: ['Chain', '美国', '巴西', '韩国', '塞尔维亚'],
    colPhone: [],
    certData: [],
    certShowID: "",
    pruiNuer: {
      surName: "",
      engName: "",
      venName: ""
    },
    mobile_phone: "",
    cloneShow: false,
    Entil: ""
  },

  /**
 * 生命周期函数--监听页面加载
 */
  onLoad() {
    api._get('dialing-code/list').then(res => {
      const PhoneData: any = [];
      res.data.map((item: any) => {
        PhoneData.push(item.areaCode)
      })
      this.setData({
        colPhone: PhoneData
      })
    }).catch(e => {
      console.log(e);
    })
  },
  prinInputSurName(event: any) {
    const onserData: any = this.data.pruiNuer;
    onserData.surName = event.detail.value;
    this.setData({
      pruiNuer: onserData
    })
  },
  prinInputEngName(event: any) {
    const onserData: any = this.data.pruiNuer;
    onserData.engName = event.detail.value;
    this.setData({
      pruiNuer: onserData
    })
  },
  prinInputVenName(event: any) {
    const onserData: any = this.data.pruiNuer;
    onserData.venName = event.detail.value;
    this.setData({
      pruiNuer: onserData
    })
  },
  phoneInput(event: any) {
    this.setData({
      mobile_phone: event.detail.value
    })
  },
  prinseColekng() {
    const onserData: any = this.data.pruiNuer;
    const texy = ConvertPinyin(onserData.surName);
    onserData.surName = texy;
    this.setData({
      pruiNuer: onserData
    })
  },


  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  onChange(event: any) {
    console.log(event.detail);
  },
  VanCellOnclick() {
    this.setData({ show: true });
  },
  onClose() {
    this.setData({ show: false });
  },
  onSelect(event: any) {
    console.log(event.detail);
  },
  showPopup(e: any) {
    this.setData({
      certShowID: e.currentTarget.dataset.id,
      showpopup: true
    });
  },
  onPopupConfirm() {
    const CloseData = formatTime(new Date(this.data.currentDate))
    const cruneData: any = this.data.certData;
    cruneData.map((item: any) => {
      if (item.key === Number(this.data.certShowID)) {
        item.certdata = CloseData;
      }
    })
    this.setData({ certData: cruneData, showpopup: false });
  },
  getValue(e: any) {
    // const Canon: any = this.data.canonIcal;
    // var regNum = new RegExp(Canon.regexp);
    if (e.detail.value !== '') {
      const cruneData: any = this.data.certData;
      cruneData.map((item: any) => {
        if (item.key === e.currentTarget.dataset.id) {
          item.certent = e.detail.value;
        }
      })
      this.setData({
        certData: cruneData,
        cloneShow: false
      })
    } else {
      this.setData({
        cloneShow: true
      })
    }
  },
  onPopupClose() {
    this.setData({ showpopup: false });
  },
  onPopupInput(event: any) {
    this.setData({
      currentDate: event.detail,
    });
  },
  prinInputEntil(event: any) {
    this.setData({
      Entil: event.detail.value,
    });
  },
  BirthdayConfirm() {
    const CloseData = formatTime(new Date(this.data.currentDate))
    this.setData({ BirthdayDate: CloseData, Birthday: false });
  },
  BirthdayClose() {
    this.setData({ Birthday: false });
  },
  showBirthday() {
    this.setData({ Birthday: true });
  },
  BirthdayInput(event: any) {
    this.setData({
      currentDate: event.detail,
    });
  },
  showNationality() {
    this.setData({ nationality: true });
  },
  NationalityClose() {
    this.setData({ nationality: false });
  },
  onpickerConfirm(event: any) {
    const { value } = event.detail;
    this.setData({
      nationalityValue: value,
      nationality: false
    })
  },
  showPhone() {
    this.setData({
      phone: true
    })
  },
  onPhoneConfirm(event: any) {
    const { value } = event.detail;
    this.setData({
      phoneValue: value,
      phone: false
    })
  },
  PhoneClose() {
    this.setData({
      phone: false
    })
  },
  Addrose() {
    console.log(this.data.certData)
  },
  AddWinesOnClick() {
    const CerItem: AddcertProps = this.data.certData[0];
    const cnData: any = {
      cnName: this.data.pruiNuer.surName,
      surname: this.data.pruiNuer.engName,
      enName: this.data.pruiNuer.venName,
      gender: this.data.radio,
      nationality: this.data.nationalityValue,
      mobilePhone: this.data.mobile_phone,
      phoneCountryCode: this.data.phoneValue,
      //  CerItem.certent
      idNumber: '',
      // CerItem.certdata
      expire_date: '',
      birthday: "2020-02-01",
      email: this.data.Entil,
      // CerItem.key
      certificateType: ''
    }
    api._post('user/reserve-user-info', cnData).then(res => {
      var pages = getCurrentPages();
      var beforePage = pages[pages.length - 2];
      wx.showLoading({
        title: '添加成功'
      });
      setTimeout(() => {
        wx.hideLoading();
      }, 1000)
      wx.navigateBack({
        delta: -1,
        success: function () {
          beforePage.UserDataSgholebe();
        }
      })
    }).catch(e => {
      console.log(e);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  DateItemDunr(e: any) {
    const Data: any = [];
    Data.push({
      key: this.data.certData.length,
      title: e.currentTarget.dataset.value,
      type: e.currentTarget.dataset.type
    })
    if (this.data.certData.length === 0) {
      this.setData({
        certData: Data,
        show: false
      });
    } else {
      const arre: any = [...this.data.certData, ...Data]
      this.setData({
        certData: arre,
        show: false
      });
    }
  },
  onRadioChange(event: any) {
    this.setData({
      radio: event.detail,
    });
  },
  DelectcertItem(event: any) {
    const certDelectDate = this.data.certData.filter((item: any) => {
      return item.key !== event.currentTarget.dataset.id;
    })
    this.setData({
      certData: certDelectDate
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})