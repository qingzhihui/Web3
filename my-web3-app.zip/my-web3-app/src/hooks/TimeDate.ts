const Pidate = (data: any) => {
  const datelio = data;
  const datelioPLe = new Date(datelio * 1000);
  const mdate = new Date(datelioPLe).toLocaleDateString().replace(/\//g, "/");
  const tdate = new Date(datelioPLe).toLocaleTimeString();
  const pdate = `${mdate.split("/")[0]}:${mdate.split("/")[1]}:${
    mdate.split("/")[2]
  }: ${tdate.split(":")[0]}:${tdate.split(":")[1]}:${tdate.split(":")[2]}`;
  return pdate;
};

export { Pidate };
