import {login_url} from "./config";
const getCode = () => {
  return new Promise((resolve, reject) => {
    wx.login({
      success: res => {
        resolve(res.code);
      },
      fail: err => {
        reject(err)
      }
    })
  })
}

const getUserInfo = () => {
  return new Promise((resolve, reject) => {
    wx.getUserProfile({
      desc: '展示用户信息',
      success: (res) => {
        resolve(res);
      },
      fail: err => {
        reject(err)
      }
    })
  })
}

export const login_request = async () => {
  return new Promise((resolve, reject)=>{
    Promise.all([getCode()]).then((res) => {
      wx.request({
        url: login_url,
        method: "POST",
        header: {"Cookie": wx.getStorageSync("Cookie")},
        data: {
          code: res[0]
        },
        success: res => {
          resolve(res);
        },
        fail: err => {
          reject(err);
        }
      })
    }).catch(err => {
      reject(err);
    })
  })
}