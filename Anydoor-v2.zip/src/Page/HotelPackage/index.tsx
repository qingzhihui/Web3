import React from "react";

const HotelPackage = () => {
  return <div>奢旅（酒店套餐）</div>;
};

export default HotelPackage;
