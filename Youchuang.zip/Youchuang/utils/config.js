// export const login_url = "https://chat.youchuangkeji.com/user/login";
// export const chat_url = "https://chat.youchuangkeji.com/openai/text";

export const portrait = "https://profile-avatar.csdnimg.cn/default.jpg!1"
