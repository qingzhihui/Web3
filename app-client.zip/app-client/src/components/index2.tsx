import React from "react";
import useSWR from "swr";

const fetcher = (...args: any) => fetch(args).then((resp) => resp.json());

const Index2 = () => {
  const { data, isLoading } = useSWR(
    "https://api2.binance.com/api/v3/ticker/24hr",
    fetcher,
    { suspense: true }
  );
  //   if (isLoading) return <h1>Loading...</h1>;
  //   console.log(data);
  return (
    <div>
      {data?.map((coin: any, index: number) => {
        return <h1 key={index}>{coin.lastPrice}</h1>;
      })}
    </div>
  );
};

export default Index2;
