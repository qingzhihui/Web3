/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect } from "react";
import "./index.scss";
import { useHistory } from "react-router-dom";
import { EditOutlined, RightOutlined } from "@ant-design/icons";
import { Table, Modal, Statistic } from "antd";

import {
  FormatUnitsConver,
  InstancedContract,
  ObtainAddress,
  TokenNameDecimals,
} from "../../hooks/config";
import { useTranslation, Trans } from "react-i18next";
import { CreatelockABI, CreatelockAddress } from "../../hooks/Createlock";
import { ColumnsType } from "antd/lib/table";
import {
  AggregateProps,
  CalculatorProps,
  LockRecordDataAggregate,
} from "../../hooks/LockInfo";
interface lockRecordProps {
  balanceOf?: string;
  decimals?: number;
  name?: string;
  symbol?: string;
}
const { Countdown } = Statistic;
const paginationProps = {
  showSizeChanger: true,
  showQuickJumper: true,
  pageSize: 6,
};

const LockInfo: React.FC = (props: any) => {
  const { t } = useTranslation();
  let history = useHistory();
  // 现在的时间戳 数字类型 毫秒
  const date = Date.now();
  const [vestInfoIsShow, setVestInfoIsShow] = useState<boolean>(false);
  const [lockRecord, setLockRecord] = useState<lockRecordProps>({});
  const [ToAddress, setToAddress] = useState<any>();
  const [modalInput, setModalInput] = useState<string>("");
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [lockId, setlockId] = useState<string>("");
  const [LockRecordData, setLockRecordData] = useState<AggregateProps>({});
  const [LockRecorAggregate, setLockRecorAggregate] = useState<
    CalculatorProps[]
  >([]);
  const [buineShow, setBuineShow] = useState<boolean>(false);
  const [prushow, setPrushow] = useState<boolean>(false);
  const [tgeString, setTGEString] = useState<string>("");
  const [withdrawabl, setwithdrawabl] = useState("");

  const checkVestInfo = () => {
    setVestInfoIsShow(!vestInfoIsShow);
  };
  const getLocksForTokenData = async (
    TokenID: string,
    TokenAddress: string
  ) => {
    const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
    const getLockById = await Contract.getLockById(TokenID);
    const TokenData = await TokenNameDecimals(TokenAddress);
    const AggregateData = LockRecordDataAggregate(
      getLockById,
      lockRecord.decimals as number
    );
    const withdrawableTokens = await Contract.withdrawableTokens(TokenID);
    setwithdrawabl(FormatUnitsConver(withdrawableTokens.toString(), lockRecord.decimals));
    setLockRecord((LockRecordprevState: any) => {
      return (LockRecordprevState = TokenData);
    });
    const { LockRecordData, CalculatorInfo } = AggregateData;
    setLockRecorAggregate((LockRecordataprevState: CalculatorProps[]) => {
      return (LockRecordataprevState = CalculatorInfo);
    });
    setLockRecordData((LockRecordDataprevState: AggregateProps) => {
      let tge: string = (
        Number(LockRecordData.tgeDate as string) * 1000
      ).toString();
      setTGEString(tge);
      return (LockRecordDataprevState = LockRecordData);
    });
    const { address } = await ObtainAddress() as any;
    if (LockRecordData.Owner != address || LockRecordData.Owner === "0x0000000000000000000000000000000000000000") {
      setPrushow(true);
    } else {
      setPrushow(false);
    }
    if (Number(LockRecordData.Percent) === 0) {
      setBuineShow(true);
    } else {
      setBuineShow(false);
    }
  };
  const handleOk = async () => {
    const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
    const transferLock = await Contract.transferLockOwnership(
      lockId,
      modalInput
    );
    await transferLock.wait();
    setIsModalOpen(false);
  };
  const renounceLockOwnership = async () => {
    const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
    const renounceLockOwnership = await Contract.renounceLockOwnership(lockId);
    await renounceLockOwnership.wait();
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const columns: ColumnsType<CalculatorProps> = [
    {
      title: `${t("Unlock #")}`,
      dataIndex: "Unlock",
    },
    {
      title: `${t("Time")}`,
      dataIndex: "Time",
    },
    {
      title: `${t("Unlocked tokens")}`,
      dataIndex: "tokens",
    },
  ];
  const modalInputOnCheng = (e: React.ChangeEvent<HTMLInputElement>) => {
    setModalInput(e.target.value);
  };
  const unlockOnClick = async () => {
    const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
    const unlock = await Contract.unlock(lockId);
    await unlock.wait();
  };
  const updateOnClick = async () => {
    history.push({
      pathname: "/Lock",
      state: {
        tokenList: LockRecordData,
        lockId: lockId,
        decimals: lockRecord.decimals as number,
      },
    });
  };
  useEffect(() => { }, [buineShow, prushow]);
  useEffect(() => {
    if (props.location.state != undefined) {
      const { TokenAddress, TokenID } = props.location.state;
      getLocksForTokenData(TokenID, TokenAddress);
      setToAddress((ToAddressprevState: any) => {
        return (ToAddressprevState = TokenAddress);
      });
      setlockId((lockIdprevState: any) => {
        return (lockIdprevState = TokenID);
      });
    }
  }, []);
  return (
    <div className="lock-info">
      <div className="unlock-in">
        <div className="unlock-title">
          {`${t("Unlock in")}`}{" "}
          {Number(tgeString) < date ? (
            "00:00:00:00"
          ) : (
            <div className="countdown">
              <Countdown value={Number(tgeString)} format="DD:HH:mm:ss" />
            </div>
          )}
        </div>
      </div>
      <div className="Token-Info">
        <div className="updatelock-tableItem lockrecord-title">{`${t("Token Info")}`}</div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Address")}`}</span>
            <span className="tableItem-name">{ToAddress}</span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Name")}`}</span>
            <span className="tableItem-name">{lockRecord.name as string}</span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Symbol")}`}</span>
            <span className="tableItem-title">
              {lockRecord.symbol as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Decimals")}`}</span>
            <span className="tableItem-title">
              {lockRecord.decimals as number}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
      </div>
      <div className="unlock-info">
        <div className="updatelock-tableItem lockrecord-title">{`${t("Lock Info")}`}</div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Title")}`}</span>
            <span className="tableItem-name">
              {LockRecordData.Title as string}
              <EditOutlined
                style={{ color: "rgb(249, 81, 146)", cursor: "pointer" }}
              />
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t(
              "Total Amount Locked"
            )}`}</span>
            <span className="tableItem-name">
              {Number(LockRecordData.amountShow as string)}{" "}
              {lockRecord.symbol as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t(
              "Total Values Locked"
            )}`}</span>
            <span className="tableItem-name">
              ${LockRecordData.Locked as number}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Owner")}`}</span>
            <span className="tableItem-title TokenAddress">
              {LockRecordData.Owner as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Lock Date")}`}</span>
            <span className="tableItem-title">
              {LockRecordData.lockDateShow as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Address")}`}</span>
            <span className="tableItem-name">
              {LockRecordData.token as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("TGE Date")}`}</span>
            <span className="tableItem-name">
              {LockRecordData.tgeDateShow as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        {buineShow === true ? (
          ""
        ) : (
          <>
            <div className="updatelock-tableItem">
              <div className="tableItem-text">
                <span className="tableItem-title">{`${t("TGE Percent")}`}</span>
                <span className="tableItem-title">
                  {LockRecordData.PercentShow as string}%
                </span>
              </div>
              <div className="tableItem-line" />
            </div>
            <div className="updatelock-tableItem">
              <div className="tableItem-text">
                <span className="tableItem-title">{`${t("Cycle")}`}</span>
                <span className="tableItem-title">
                  {LockRecordData.CycleShow as string} {`${t("minutes")}`}
                </span>
              </div>
              <div className="tableItem-line" />
            </div>
            <div className="updatelock-tableItem">
              <div className="tableItem-text">
                <span className="tableItem-title">{`${t(
                  "Cycle Release Percent"
                )}`}</span>
                <span className="tableItem-title">
                  {LockRecordData.CycleReleaseShow as string}%
                </span>
              </div>
              <div className="tableItem-line" />
            </div>
            <div className="updatelock-tableItem">
              <div className="tableItem-text">
                <span className="tableItem-title">{`${t(
                  "Unlocked Amount"
                )}`}</span>
                <span className="tableItem-title">
                  {LockRecordData.UnlockedAmount as string}{" "}
                  {lockRecord.symbol as string}
                </span>
              </div>
              <div className="tableItem-line" />
            </div>
            <div className="updatelock-tableItem">
              <div className="tableItem-text">
                <span className="tableItem-title">{`${t(
                  "Vesting Info"
                )}`}</span>
                <span className="tableItem-title">
                  <RightOutlined
                    style={{
                      fontSize: "14px",
                      cursor: "pointer",
                      transform: vestInfoIsShow ? "rotate(90deg)" : "",
                    }}
                    onClick={() => {
                      checkVestInfo();
                    }}
                  />
                </span>
              </div>
              <div className="tableItem-line" />
            </div>
            <div
              className="vesting-Info"
              style={{ height: vestInfoIsShow ? "auto" : 0 }}
            >
              <Table
                columns={columns}
                loading={LockRecorAggregate.length === 0 ? true : false}
                dataSource={LockRecorAggregate}
                size="middle"
                pagination={paginationProps}
              />
            </div>
          </>
        )}
        {prushow === true ? (
          ""
        ) : (
          <div className="footer-button">
            <div
              className="footer-button-Item"
              onClick={() => {
                setIsModalOpen(true);
              }}
            >
              {`${t("Transfer Lock Ownership")}`}
            </div>
            <div
              className="footer-button-Item"
              onClick={() => {
                renounceLockOwnership();
              }}
            >
              {`${t("Renounce Lock Ownership")}`}
            </div>
            <>
              <div
                className="footer-button-Item"
                onClick={() => {
                  updateOnClick();
                }}
              >
                {`${t("Update")}`}
              </div>

              <div
                className="footer-button-Item"
                onClick={() => {
                  unlockOnClick();
                }}
              >
                {`${t("Unlock")}`} {Number(withdrawabl) > 0 ? `(${Number(withdrawabl)}${" "}${lockRecord.symbol})` : ""}
              </div>
            </>
          </div>
        )}

        <Modal
          title={`${t("Transfer Ownership")}`}
          open={isModalOpen}
          onOk={handleOk}
          onCancel={handleCancel}
        >
          <div className="ModalInputrel">
            <div className="ModalTile">{`${t("New Owner Address")}`}*</div>
            <div className="modalInput">
              <input
                type="text"
                placeholder={`${t("Please input token address")}`}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  modalInputOnCheng(e);
                }}
              />
            </div>
          </div>
        </Modal>
      </div>
    </div>
  );
};
export default LockInfo;
