import React, { useEffect, useState } from "react";
import { HashRouter, Routes, Route } from "react-router-dom";
import { Provider } from "react-redux";

import { store } from "./redux/store";
import About from "./Page/About";
import "./assets/common.scss";
import Header from "./Component/Header";
import Footer from "./Component/Footer";
import Team from "./Page/Team";
import Roadmap from "./Page/Roadmap";
import Tokenomics from "./Page/Tokenomics";
import Game from "./Page/Game";
import Home from "./Home";
import lisdata from "./data.json";
import i18n from "./language/config.js";
import { I18nextProvider, useTranslation } from "react-i18next";
import GetYourPlayer from "./Page/Game/GetYourPlayer";
import MyPlayer from "./Page/Game/MyPlayer";
import Merge from "./Page/Game/Merge";
import Forge from "./Page/Game/Forge";
import Extract from "./Page/Game/Extract";
import PVE from "./Page/Game/PVE";
import DailyMining from "./Page/Game/DailyMining";
import OpenChests from "./Page/Game/OpenChests";
import Leaderboard from "./Page/Game/Leaderboard";
import Referral from "./Page/Game/Referral";
import "antd/dist/antd.css";

function App() {
  const { t } = useTranslation();
  useEffect(() => {
    function resizeFont() {
      let width =
        document.documentElement.clientWidth || document.body.clientWidth;
      let dom = document.getElementsByTagName("html");
      dom[0].style.fontSize = (width / 1920) * 100 + "px";
    }
    resizeFont();
    window.onresize = resizeFont;
    const ldata = [];
    ldata.push(lisdata);
    localStorage.setItem("Lisrdata", JSON.stringify(ldata));
  }, []);

  const [lang, setLang] = useState(i18n.language);

  useEffect(() => {
    setLang(i18n.language);
    console.log(i18n.language);
  }, [i18n]);

  const children = [
    {
      name: "Get Your Player",
      path: "/get-your-player",
      element: <GetYourPlayer />,
    },
    {
      name: "MyPlayer",
      path: "/my-player",
      element: <MyPlayer />,
    },
    {
      name: "Merge",
      path: "/merge",
      element: <Merge />,
    },
    {
      name: "Extract",
      path: "/extract",
      element: <Extract />,
    },
    {
      name: "Forge",
      path: "/forge",
      element: <Forge />,
    },

    {
      name: "PVE",
      path: "/pve",
      element: <PVE />,
    },
    {
      name: "PVP",
      path: "/daily-mining",
      element: <DailyMining />,
    },
    {
      path: "/open-chests",
      name: "PVP betting",
      element: <OpenChests />,
    },
    {
      path: "/leader-board",
      name: "LeaderBoard",
      element: <Leaderboard />,
    },
    // {
    //   path: "/referral",
    //   name: "Referral",
    //   element: <Referral />,
    // },
  ].map((item) => {
    item.path = "/game" + item.path;
    item.name = t("game." + item.name);
    return item;
  });

  const routes = [
    {
      path: "/",
      name: t("header.home"),
      element: <Home />,
    },
    {
      path: "/about",
      name: t("header.about"),
      element: <About />,
    },
    {
      path: "/team",
      name: t("header.team"),
      element: <Team />,
    },
    {
      path: "/roadmap",
      name: t("header.roadmap"),
      element: <Roadmap />,
    },
    {
      path: "/tokenomics",
      name: t("header.tokenomics"),
      element: <Tokenomics />,
    },
    {
      path: "/game",
      name: t("header.game"),
      element: <Game children={children} />,
    },
  ];

  return (
    <>
      {/*<video src="/mp4.mp4" id="body-video" loop autoPlay muted/>*/}
      <div style={{ position: "relative", zIndex: "1", minHeight: "100vh" }}>
        <Provider store={store}>
          <HashRouter>
            <Header routes={routes} />
            <Routes>
              {routes.map((item, key) => {
                if (item.path === "/game") {
                  return (
                    <Route path={item.path} key={key} element={item.element}>
                      {children.map((item, key) => {
                        return (
                          <Route
                            path={item.path}
                            key={key}
                            element={item.element}
                          />
                        );
                      })}
                    </Route>
                  );
                } else {
                  return (
                    <Route path={item.path} key={key} element={item.element} />
                  );
                }
              })}
            </Routes>
            <Footer />
          </HashRouter>
        </Provider>
      </div>
    </>
  );
}

export default App;
