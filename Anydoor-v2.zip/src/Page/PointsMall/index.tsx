import React from "react";
import PropTypes from "prop-types";

const PointsMall = () => {
  return <div>积分商城</div>;
};

export default PointsMall;
