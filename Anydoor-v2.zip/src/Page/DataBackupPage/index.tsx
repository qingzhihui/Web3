import { Form, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import React from "react";
import "./index.css";

// 数据备份界面
const DataBackupPage: React.FC = () => {
  interface DataType {
    key: string;
    databaseName: string; //数据库名
    username: string; //用户名
    password: string; //密码
    volume: string; //容量
    backUp: string; //备份
    remarks: string; //备注
  }

  // 点击备份按钮
  const forbiddenjx = (record: any) => {
    return () => {
      console.log(record.key); // hello
      console.log("点击了备份");
    };
  };
  const data: DataType[] = [
    {
      key: "1",
      databaseName: "anyfoortrip_com",
      username: "username",
      password: "123456",
      volume: "未配置",
      backUp: "点击备份",
      remarks: "aefabvafa.com",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "数据库名",
      dataIndex: "databaseName",
      key: "databaseName",
    },
    {
      title: "用户名",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "密码",
      dataIndex: "password",
      key: "password",
    },
    {
      title: "容量",
      dataIndex: "volume",
      key: "volume",
    },
    {
      title: "备份",
      key: "backUp",
      render: (_, record) => (
        <Space size="middle">
          <a onClick={forbiddenjx(record)} href="#">
            {record.backUp}
          </a>{" "}
          |
          <a href="#" className="publicStyleA">
            <span>导入</span>
          </a>
        </Space>
      ),
    },
    {
      title: "备注",
      dataIndex: "remarks",
      key: "remarks",
      width:150,
    },
    {
      title: "操作",
      render: (_) => (
        <Space size="middle">
          <span onClick={tbaManageBtn} className="publicStyleA">
            管理&nbsp;&nbsp;&nbsp;|{" "}
          </span>
          <span onClick={tabPowerBtn} className="publicStyleA">
            权限&nbsp;&nbsp;&nbsp;|
          </span>
          <span onClick={tabToolBtn} className="publicStyleA">
            工具&nbsp;&nbsp;&nbsp;|
          </span>
          <span onClick={tabReworkPassBtn} className="publicStyleA">
            改密&nbsp;&nbsp;&nbsp;|
          </span>
          <span onClick={tabDeleteBtn} className="publicStyleA">
            删除
          </span>
        </Space>
      ),
    },
  ];
  // 管理按钮
  const tbaManageBtn = () => {
    console.log("点击了管理按钮");
  };
  // 权限按钮
  const tabPowerBtn = () => {
    console.log("点击了权限按钮");
  };
  // 工具按钮
  const tabToolBtn = () => {
    console.log("点击了工具按钮");
  };
  // 改密按钮
  const tabReworkPassBtn = () => {
    console.log("点击了改密按钮");
  };
  // 删除按钮
  const tabDeleteBtn = () => {
    console.log("点击了删除按钮");
  };

  return (
    <div>
      {/* 数据备份模板管理 */}
      <div className="wl_Box">
        <div className="wl_headerBox">
          <div className="wl_headerBox_thread"></div>
          <div className="wl_headerBox_Tit">&nbsp;&nbsp;&nbsp; 数据备份</div>
          {/* <div className='wl_Add_moban'>添加运费模板</div> */}
        </div>

        <div className="wl_tableBox">
          {/* scroll={{ x: 'max-content', y: 170 }}  */}
          <Table columns={columns} dataSource={data} />
        </div>
      </div>
    </div>
  );
};

export default DataBackupPage;
