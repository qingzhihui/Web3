import { differenceInterval } from "../../config/config";
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    cardCur: 0,
    swiperList: [{
      id: 0,
      url1: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start1.png',
      url2: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start2.png',
      url3: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start3.png'
    }, {
      id: 1,
      url1: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start4.png',
      url2: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start5.png',
      url3: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start6.png'
    }, {
      id: 2,
      url1: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start7.png',
      url2: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start8.png',
      url3: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start9.png'
    }, {
      id: 3,
      url1: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start10.png',
      url2: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start11.png',
      url3: 'https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/start12.png'
    }],
    startTime: "",
    EndTime: "",
    // 定位
    city: "",
    cityValue: '',
    dateNuer: 0,
    stepperProps: "",
    LoginTitle: "预定",
    roomNumer: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    //   key: 'KCNBZ-XTYW3-CC635-3J2NI-AEJG7-OXF3F'
    var childEle = this.selectComponent('#childEle');
    const perdate = differenceInterval(childEle.data.CalendarData[0], childEle.data.CalendarData[1]);
    this.setData({
      startTime: childEle.data.CalendarData[0],
      EndTime: childEle.data.CalendarData[1],
      dateNuer: perdate,
      stepperProps: childEle.data.stepperValue,
      roomNumer: childEle.data.roomNumer
    })
  },
  keFuButton(){
    // wx.openCustomerServiceChat({
    //   extInfo: {url: 'https://work.weixin.qq.com/kfid/kfc3e76250fea3df696?encScene=ENC9GcAL6Rv9o1ttdmK99HPNQP3RJMufX6aXFukCnceDVX1'},
    //   corpId: 'ww6a828cef76872a2d',
    //   success(res) {}
    // } )
  },
  TimeOnclick() {
    var childEle = this.selectComponent('#childEle');
    childEle.showPopup();
  },
  AddressProps(event: any) {
    this.setData({
      city: event
    })
  },
  send(e: any) {
    const perdate = differenceInterval(e.detail.date[0], e.detail.date[1]);
    this.setData({
      startTime: e.detail.date[0],
      EndTime: e.detail.date[1],
      dateNuer: perdate,
      stepperProps: e.detail.stepper,
      roomNumer: e.detail.roomNumer
    })
  },

  HotelShow() {
    const { startTime, EndTime } = this.data
    wx.navigateTo({
      url: `../Hotel/Hotel?startTime=${startTime}&EndTime=${EndTime}&roomNumer=${this.data.roomNumer}`
    })
  },
  cardSwiper(e: any) {
    this.setData({
      cardCur: e.detail.current
    })
  },
  FlightShow() {
    wx.navigateTo({
      url: "../Flight/Flight"
    })
  },

  TicketsScueSHow() {
    wx.navigateTo({
      url: "../TicketsScue/TicketsScue"
    })
  },
  SeckillSHow() {
    wx.navigateTo({
      url: "../Seckill/Seckill"
    })
  },
  BargainSHow() {
    wx.navigateTo({
      url: "../Bargain/Bargain"
    })
  },
  HotelSearchShow() {
    if (this.data.cityValue === "") {
      Toast.fail('请选择城市!');
    } else {
      wx.navigateTo({
        url: `../HotelSearch/HotelSearch?startTime=${this.data.startTime}&EndTime=${this.data.EndTime}&stepper=${this.data.stepperProps}&city=${this.data.city === "" ? this.data.cityValue : this.data.city}&roomNumer=${this.data.roomNumer}`
      })
    }

  },
  SetmealSHow() {
    wx.navigateTo({
      url: "../Setmeal/Setmeal"
    })
  },
  SunienPosne() {
    wx.navigateTo({
      url: `../Positio/Positio?city=${this.data.cityValue}`
    })
  },
  VisaBinta() {
    wx.navigateTo({
      url: "../Visage/Visage"
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    wx.getLocation({
      success(res) {
        // 纬度
        const latitude = res.latitude
        // 经度
        const longitude = res.longitude
        // 请求腾讯地图逆地址解析接口
        wx.request({
          url: `https://apis.map.qq.com/ws/geocoder/v1/?location=${latitude},${longitude}&key=KCNBZ-XTYW3-CC635-3J2NI-AEJG7-OXF3F`,
          success(res: any) {
            const { address_component } = res.data.result;
            that.setData({
              cityValue: address_component.city.split('市')[0]
            })
          },
        })
      }
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})