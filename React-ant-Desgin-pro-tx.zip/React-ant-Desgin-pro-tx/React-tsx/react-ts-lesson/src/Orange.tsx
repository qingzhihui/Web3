import React, { Component } from "react";

interface Iprops {
  name: string;
}
export default class Orange extends Component<Iprops> {
  render() {
    return <div>{this.props.name}</div>;
  }
}
