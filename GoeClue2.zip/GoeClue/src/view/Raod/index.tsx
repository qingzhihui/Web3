import React from 'react'
import './index.scss'
import Header from '../../components/Header'
import hook from "../../../src/assets/image/hook.png"


export default function raod() {
  return (
    <div className='raod-map'>
      <div className='raodmap'>
        <Header></Header>
        <div className='raodmap-middle'>
          <div className='title'><span>FOLLOWING ROADMAP</span></div>
          <div className='middle-card'>
            <div className='card q3'>
              <div className='card-date'>2022 Q4-1.1</div>
              <div>- Web Design</div>
              <div>- Visual & Game Design</div>
              <div>- Planning Gameplay</div>
              <div>- Develop Smart Contract</div>
              <div>- Building Community</div>
              {/* <div>- Online exchange</div> */}
              {/* <div>- Liquidity Trading Function</div> */}
            </div>
            <div className='card q4'>
              <div className='card-date'>2022 Q4-1.2</div>
              <div>- Alpha Test</div>
              <div>- IDO Sale</div>
              <div>- Community Promotion
              </div>
              <div>- Beta Test</div>
              <div>- Launch Marketing</div>
              <div>- Community AMA</div>
              <div>- Pre-sale INO</div>
              <div>- Whitelist INO Sale</div>
            </div>
            <div className='card q1'>
              <div className='card-date'>2022 Q4-1.3</div>
              <div>- IDO Whitelist</div>
              <div>- IDO</div>
              <div>- PancakeSwap</div>
              <div>- Start Mint</div>
              <div>- Farm Map</div>
              <div>- Launch Game</div>
              <div>- World Cup 2022 Battle</div>
              <div>- System</div>
              <div>- Shop</div>
              <div>- Staking</div>
            </div>
            <div className='card q2'>
              <div className='card-date'>2022 Q4-1.4</div>
              <div>- Manager NFT</div>
              <div>- Marketplace</div>
              <div>- Guild</div>
              <div>- Contact with Major Platforms</div>
            </div>
          </div>
        </div>
        <div className='raodmap-line'>
          <div className='sold'></div>
          <div className='sold'>
            <div><img src={hook} alt="" /></div>
          </div>
          <div className='dott'>
            <div className='border'></div>
          </div>
          <div className='dott'>
            <div className='border'></div>
          </div>
          <div className='dott'>
            <div className='border'></div>
          </div>
        </div>
        <div className='raodmap-footer'></div>
      </div>
    </div>
  )
}
