import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import { Button, Input, notification, Modal } from "antd";
import {
  EyeOutlined,
  CheckCircleOutlined,
  LoadingOutlined,
  SelectOutlined,
} from "@ant-design/icons";
import Header from "../../components/Header";
import Heues from "../../components/Heues";
import IMg from "../../assets/xusng.png";
import "./index.scss";
import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../../redux/Contract/contractFaHo";
import { Mint_ADDRESS, Mint_ABI } from "../../redux/Contract/mintContract";
import { PAIR_ABI } from "../../redux/Contract/pancakepair";
import { wben_ABI } from "../../redux/Contract/wbenjson";
import List from "../../redux/UsJson/Colest3.json";
import lo1 from "../../assets/logo_1.png";

declare const window: Window & { ethereum: any };

function Index() {
  const MINUTE_MS = 2000;
  const [address, serAddres] = useState("");
  const [showList, setShowList] = useState(List);
  const [inputValue, setInputValue] = useState(0);
  const [unShow, setunShow] = useState(false);
  const key = "updatable";
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [GogaoisModalOpen, GogaosetIsModalOpen] = useState(false);

  const handleOk = async (id: any) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const Contract = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      );
      const withs = await Contract.withdraw(id);
      openNotification2(
        "赎回中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      await withs.wait();
      openNotification2(
        "赎回成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      const pldata = await Contract.userInfo(id, address);
      const buList: any = [];
      showList.map((item: any) => {
        if (item.id == id) {
          item.lPdata = ethers.utils.formatEther(
            pldata.depositAmount.toString()
          );
        }
        buList.push(item);
      });
      setIsModalVisible(false);
      setTimeout(() => {
        setShowList(buList);
      }, 300);
    } catch (error: any) {
      setIsModalVisible(false);
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification2(
          "用户拒绝赎回.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
      }
    }
  };
  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const openNotification2 = (bindValue: any, durn: any, icon: any) => {
    notification.open({
      key,
      message: "提示",
      description: bindValue,
      duration: durn,
      icon: icon,
    });
  };
  const BueniSHow = (id: any) => {
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        if (item.binsShow == true) {
          item.binsShow = false;
        } else {
          item.binsShow = true;
        }
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };
  // 授权
  const approve = async (code: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const PAIRContract = new ethers.Contract(code, PAIR_ABI, signer);
    const balance = await PAIRContract.balanceOf(addr);
    console.log(ethers.utils.formatEther(balance.toString()));
    const apperov = await PAIRContract.approve(
      CONTRACT_ADDRESS,
      ethers.constants.MaxUint256
    );
    openNotification2(
      "授权中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await apperov.wait();
    const buList: any = [];
    showList.map((item: any) => {
      if (item.code == code) {
        item.show = 1;
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
    openNotification2(
      "授权成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
  };
  // 存款
  const deposit = async (id: any) => {
    // try {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const value = new BigNumber(inputValue)
      .times(new BigNumber(10).pow(18))
      .toFixed();
    const desite = await Contract.deposit(id, value.toString());
    openNotification2(
      "存款中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await desite.wait();
    openNotification2(
      "存款成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
    const pldata = await Contract.userInfo(id, address);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.lPdata = ethers.utils.formatEther(pldata.depositAmount.toString());
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };
  // 领取
  const claim = async (id: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const cladim = await Contract.claim(id);
    openNotification2(
      "领取中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await cladim.wait();
    openNotification2(
      "领取成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
  };
  // 最大值
  const BinCkmax = async (bianes: any, id: any) => {
    setInputValue(bianes);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = bianes;
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
    setunShow(true);
  };
  // 赎回
  const withdraw = async (id: any) => {
    setIsModalVisible(true);
  };
  const onCInput = (e: any, id: any) => {
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = e.target.value;
        setInputValue(e.target.value);
        const Shui = e.target.value || 0;
        if (Shui === 0) {
          setunShow(false);
        } else if (item.inputValue === 0) {
          setunShow(false);
        } else {
          setunShow(true);
        }
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };

  // 公告
  const GogaohandleCancel = () => {
    GogaosetIsModalOpen(false);
  };
  useEffect(() => {
    const ahsdr = localStorage.getItem("addr");
    if (ahsdr !== null && ahsdr !== undefined) {
      setTimeout(() => {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const LIbse: any = showList;
        showList.map(async (item: any) => {
          const address = await signer.getAddress();
          serAddres(address);
          const PAIRContract = new ethers.Contract(item.code, PAIR_ABI, signer);
          const usider = await PAIRContract.allowance(
            address,
            CONTRACT_ADDRESS
          );
          const Contract = new ethers.Contract(
            CONTRACT_ADDRESS,
            CONTRACT_ABI,
            signer
          );
          const bineof = await PAIRContract.balanceOf(address);
          const pldata = await Contract.userInfo(item.id, address);
          const pending = await Contract.pendingReward(item.id, address);
          const ContractToken1 = new ethers.Contract(
            item.token1,
            wben_ABI,
            signer
          );
          const ContractToken2 = new ethers.Contract(
            item.token2,
            wben_ABI,
            signer
          );
          const totalSupply = await PAIRContract.totalSupply();
          const bnbTotal1 = await ContractToken1.balanceOf(item.code);
          const decimals1 = await ContractToken1.decimals();
          const bnbTotal2 = await ContractToken2.balanceOf(item.code);
          const decimals2 = await ContractToken2.decimals();
          const lisne = await Contract.userInfo(item.id, address);
          let holdRatio1 =
            Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
          let userBnb1 = Number(bnbTotal1) * holdRatio1;
          let nukse1 = userBnb1 / 10 ** decimals1;
          let holdRatio2 =
            Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
          let userBnb2 = Number(bnbTotal2) * holdRatio2;
          let nukse2 = userBnb2 / 10 ** decimals2;
          // 总池
          const t1 = new Date().valueOf();
          const beins =
            t1.toString().slice(0, 3) +
            "," +
            t1.toString().slice(3, 6) +
            "," +
            t1.toString().slice(6, 9);
          if (
            Number(usider.toString()) == Number(ethers.constants.MaxUint256)
          ) {
            LIbse[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            LIbse[item.pid].lPdata = ethers.utils.formatEther(
              pldata.depositAmount.toString()
            );
            LIbse[item.pid].lPdataToken1 = String(nukse1.toFixed(10));
            LIbse[item.pid].lPdataToken2 = String(nukse2.toFixed(10));
            LIbse[item.pid].Pending = ethers.utils.formatEther(
              pending.toString()
            );
            LIbse[item.pid].pron1 = beins;
            LIbse[item.pid].show = 1;
          } else {
            LIbse[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            LIbse[item.pid].show = 0;
            LIbse[item.pid].pron1 = beins;
          }
        });
        setTimeout(() => {
          setShowList(LIbse);
        }, 500);
      }, 1000);
      // 切换钱包
      (window as any).ethereum.on(
        "accountsChanged",
        async function (accounts: any) {
          localStorage.setItem("addr", accounts[0]);
          setTimeout(() => {
            serAddres(accounts[0]);
            const provider = new ethers.providers.Web3Provider(window.ethereum);
            const signer = provider.getSigner();
            const LIbse: any = showList;
            showList.map(async (item: any) => {
              const PAIRContract = new ethers.Contract(
                item.code,
                PAIR_ABI,
                signer
              );
              const usider = await PAIRContract.allowance(
                accounts[0],
                CONTRACT_ADDRESS
              );
              const Contract = new ethers.Contract(
                CONTRACT_ADDRESS,
                CONTRACT_ABI,
                signer
              );
              const bineof = await PAIRContract.balanceOf(accounts[0]);
              const pldata = await Contract.userInfo(item.id, accounts[0]);
              const pending = await Contract.pendingReward(
                item.id,
                accounts[0]
              );

              const ContractToken1 = new ethers.Contract(
                item.token1,
                wben_ABI,
                signer
              );
              const ContractToken2 = new ethers.Contract(
                item.token2,
                wben_ABI,
                signer
              );
              let totalSupply = "";
              const ches2 = PAIRContract.totalSupply();
              ches2.then((res: any) => (totalSupply = res));
              let bnbTotalNum1 = "";
              let bnbTotal1 = ContractToken1.balanceOf(item.code);
              bnbTotal1.then((res: any) => (bnbTotalNum1 = res));
              const decimals1 = await ContractToken1.decimals();
              let bnbTotalNum2 = "";
              let bnbTotal2 = ContractToken2.balanceOf(item.code);
              bnbTotal2.then((res: any) => (bnbTotalNum2 = res));
              const decimals2 = await ContractToken2.decimals();
              const lisne = await Contract.userInfo(item.id, accounts[0]);
              let holdRatio1 =
                Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
              let userBnb1 = Number(bnbTotalNum1) * holdRatio1;
              let nukse1 = userBnb1 / 10 ** decimals1;
              let holdRatio2 =
                Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
              let userBnb2 = Number(bnbTotalNum2) * holdRatio2;
              let nukse2 = userBnb2 / 10 ** decimals2;
              if (
                Number(usider.toString()) == Number(ethers.constants.MaxUint256)
              ) {
                LIbse[item.pid].bianes = ethers.utils.formatEther(
                  bineof.toString()
                );
                LIbse[item.pid].lPdata = ethers.utils.formatEther(
                  pldata.depositAmount.toString()
                );
                LIbse[item.pid].lPdataToken1 = String(nukse1.toFixed(10));
                LIbse[item.pid].lPdataToken2 = String(nukse2.toFixed(10));
                LIbse[item.pid].Pending = ethers.utils.formatEther(
                  pending.toString()
                );
                LIbse[item.pid].show = 1;
              } else {
                LIbse[item.pid].bianes = ethers.utils.formatEther(
                  bineof.toString()
                );
                LIbse[item.pid].show = 0;
              }
            });
            setTimeout(() => {
              setShowList(LIbse);
            }, 500);
          }, 1000);
        }
      );
      const interval = setInterval(async () => {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const Listusn: any = showList;
        showList.map(async (item: any) => {
          const Contract = new ethers.Contract(
            CONTRACT_ADDRESS,
            CONTRACT_ABI,
            signer
          );
          const address = await signer.getAddress();
          const PAIRContract = new ethers.Contract(item.code, PAIR_ABI, signer);
          const usider = await PAIRContract.allowance(
            address,
            CONTRACT_ADDRESS
          );
          const pending = await Contract.pendingReward(item.id, address);
          const bineof = await PAIRContract.balanceOf(address);
          const pldata = await Contract.userInfo(item.id, address);
          const t1 = new Date().valueOf();
          const beins =
            t1.toString().slice(0, 3) +
            "," +
            t1.toString().slice(3, 6) +
            "," +
            t1.toString().slice(6, 9);
          if (
            Number(usider.toString()) == Number(ethers.constants.MaxUint256)
          ) {
            Listusn[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            Listusn[item.pid].lPdata = ethers.utils.formatEther(
              pldata.depositAmount.toString()
            );
            Listusn[item.pid].pron1 = beins;
            Listusn[item.pid].Pending = ethers.utils.formatEther(
              pending.toString()
            );
            Listusn[item.pid].show = 1;
          } else {
            Listusn[item.pid].show = 0;
            Listusn[item.pid].pron1 = beins;
          }
        });
        setTimeout(() => {
          setShowList(Listusn);
        }, 500);
      }, MINUTE_MS);
      return () => clearInterval(interval);
    }
  }, [inputValue, showList, address]);
  return (
    <div className="Frome">
      <Header />
      <div className="banNdr">
        <div className="sueeis">
          <div className="sueeis_title">分红工厂</div>
        </div>
        <div className="nsuroBIneg">
          {showList.map((item: any) => (
            <div className="NuserList" key={item.id}>
              <div className="listiem">
                <div className="nrqingh">
                  <div className="itemimg">
                    <img src={item.icons} alt="" />
                    <div className="utopm">
                      <img src={item.icon} alt="" />
                    </div>
                  </div>
                  <div className="itilei">
                    <div className="itilei_title">{item.name}</div>
                    <div className="itilei_tnr">
                      <a
                        target="_blank"
                        href={
                          "https://pancakeswap.finance/add/" +
                          item.token1 +
                          "/" +
                          item.token2
                        }
                      >
                        获取 {item.name} 池子
                        <EyeOutlined
                          style={{
                            color: "#ffc400",
                            fontSize: "16px",
                            marginLeft: "8px",
                          }}
                        />
                      </a>
                    </div>
                    <div className="itilei_fort">
                      <a
                        target="_blank"
                        href={
                          "https://bscscan.com/address/" + item.code + "#code"
                        }
                      >
                        查看合约
                        <SelectOutlined
                          style={{
                            color: "#ffc400",
                            fontSize: "16px",
                            marginLeft: "8px",
                          }}
                        />
                      </a>
                    </div>
                  </div>
                </div>
                <div className="nrqingh3">
                  <div className="itilei2">
                    {/*池子总量: {item.LpList || "0.0"} */}
                    {/* <div className="itilei2_nr">{item.LpList}%</div> */}
                    {/* <div className="itilei2_nr">年化利率</div> */}
                  </div>
                  {/* {item.pron1 || "0.0"} */}
                  {/*  <span>已入池</span> {item.name.split("/")[0]} */}
                  <div className="itilei2">
                    {/* <div className="itilei2_nr">{item.pron1 || "0.0"}</div> */}
                    {/* <div className="itilei2_nr">流动性</div> */}
                  </div>
                  {/* {item.pron2 || "0.0"}  */}
                  {/*   <span>已入池</span> {item.name.split("/")[1]} */}
                  {/* <div className="itilei2"> */}
                    {/* <div className="itilei2_nr">{item.pron2}</div> */}
                    {/* <div className="itilei2_nr">倍数</div> */}
                  {/* </div> */}
                  <div
                    className="dizhank"
                    onClick={() => {
                      BueniSHow(item.id);
                    }}
                  >
                    <img src={IMg} alt="" />
                  </div>
                </div>
              </div>
              {item.binsShow ? (
                <div className="listFoot">
                  <div className="nrui"></div>
                  <div className="sbeuin">
                    <div className="sbitem">
                      <div className="Butile">
                        <div className="yrucibui">
                          {" "}
                          <span>余额</span>：{item.bianes || "0.0"} {item.name}{" "}
                          LP
                        </div>
                        <div className="yruci">
                          {" "}
                          <span>已入池</span>：{item.lPdataToken1 || "0.0"}{" "}
                          {item.name.split("/")[0]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <span>已入池</span>： {item.lPdataToken2 || "0.0"}{" "}
                          {item.name.split("/")[1]}
                        </div>
                      </div>
                      <div className="nbudrki">
                        {item.show ? (
                          <div className="Bininput">
                            <Input
                              value={item.inputValue}
                              onChange={(e) => onCInput(e, item.id)}
                              type="text"
                              placeholder="0.0"
                            />
                            <div className="Binmax">
                              <Button
                                onClick={() => {
                                  BinCkmax(item.bianes, item.id);
                                }}
                              >
                                Max
                              </Button>
                            </div>
                          </div>
                        ) : (
                          ""
                        )}
                        <div className="Nusoer">
                          <div className="Numerbut">
                            {item.show ? (
                              <>
                                {item.inputValue !== "" && unShow ? (
                                  <Button
                                    onClick={() => {
                                      deposit(item.id);
                                    }}
                                  >
                                    存款
                                  </Button>
                                ) : (
                                  <div className="nuBut">
                                    <Button disabled>存款</Button>
                                  </div>
                                )}
                              </>
                            ) : (
                              <Button
                                onClick={() => {
                                  approve(item.code);
                                }}
                              >
                                授权
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="sbitem2">
                      {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                        <div className="item2nr">
                          <div className="Butile">
                            <div className="yruci">
                              <span> 已存款</span> ：{item.lPdata || "0"}{" "}
                              {item.name} LP
                            </div>
                          </div>
                          <div className="Nusoer">
                            <div className="soer_btn">
                              <Button
                                onClick={() => {
                                  withdraw(item.id);
                                }}
                              >
                                赎回
                              </Button>
                            </div>
                          </div>
                          <Modal
                            title="Tips"
                            width={400}
                            visible={isModalVisible}
                            okText="确认"
                            cancelText="取消"
                            centered
                            onOk={() => {
                              handleOk(item.id);
                            }}
                            onCancel={handleCancel}
                          >
                            <p>
                              注意：如果您执行撤回LP操作，您所支持社区长的票数会一并销毁，请确认是否继续？
                            </p>
                          </Modal>
                        </div>
                      ) : (
                        ""
                      )}
                      <div className="item2nr">
                        <div className="Butile">
                          <div className="yruci">
                            <span> 待领取</span>：{item.Pending || "0.0"} USDT
                          </div>
                        </div>
                        <div className="Nusoer">
                          <div className="soer_btn">
                            {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                              <Button
                                onClick={() => {
                                  claim(item.id);
                                }}
                              >
                                领取
                              </Button>
                            ) : (
                              <div className="nuBut">
                                <Button disabled>领取</Button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                ""
              )}
            </div>
          ))}
        </div>
        <div>
          <Modal
            title={
              <div className="ggoulei">
                <img src={lo1} />
                FISTDAO V1 跨链公告
              </div>
            }
            width={400}
            visible={GogaoisModalOpen}
            centered
            footer={null}
            onCancel={GogaohandleCancel}
          >
            <div className="GogaoLient">
              <div className="Gogaotilei">
                <div className="piserve">
                  <a href="https://v2.fistdao.finance" target="_blank">
                    FISTDAO V2 以太坊已经更新，是否访问
                    <button>跳转到 V2</button>
                  </a>
                </div>
                {/* <div className="Gogaosbueri">
                  各位玩家，大家好！
                  FISTDAO双链运行即将开启，为了确保所有玩家能够公平公开的参与到跨链中，我们决定开放3天跨链的时间，具体事项如下：
                </div>
                <div>10月13日14：00 开始，开放1000枚</div>
                <div>10月14日14：00 开始，开放1000枚</div>
                <div>10月15日14：00 开始，开放1000枚</div>
                <div className="goglier">操作流程：</div>
                <div>
                  打开BSC钱包，将FISTDAO转入官方指定的地址，
                  等待官方投放ERC链上的FISTDAO。转好FISDTDAO后，将BSC链的钱包助记词或私钥导入ERC链的钱包即可.
                </div>
                <div>
                  请要参与跨链的玩家做好准备!我们将在跨
                  链结束后在UniSwap开通交易，具体时间我
                  们会提前告知市场，请大家知悉!
                </div> */}

                {/* <div className="sbueirbGort">
                  <div className="siyaddr">{Gulieraddr}</div>
                  <div
                    onClick={() => {
                      liseurGOulei();
                    }}
                  >
                    {" "}
                    <SwitcherOutlined />
                  </div>
                </div> */}
              </div>
            </div>
          </Modal>
        </div>
      </div>
      <Heues />
    </div>
  );
}

export default Index;
