// pages/Seckill/Seckill.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    background: [{
      key: 1,
      image: "https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/room.png"
    }, {
      key: 2,
      image: "https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/Rectangle-13-2.png"
    }, {
      key: 3,
      image: "https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/prlan.png"
    }],
    indicatorDots: true,
    vertical: false,
    autoplay: true,
    interval: 3000,
    duration: 500,
    time: 180 * 60 * 60 * 1000,
    timeData: {},
    active: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },
  changeIndicatorDots() {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  onChange(e: any) {
    this.setData({
      timeData: e.detail,
    });
  },
  seckillDetailsShow() {
    wx.navigateTo({
      url: "../seckillDetails/seckillDetails"
    })
  },
  BookeDetailsShow(){
    wx.navigateTo({
      url: "../BookeDetails/BookeDetails"
    })
  },
  changeAutoplay() {
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  TabonChange(event: any) {
    console.log(event.detail.name);
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})