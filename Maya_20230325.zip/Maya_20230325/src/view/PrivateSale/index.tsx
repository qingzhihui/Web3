import React, { useState, useEffect, useTransition } from "react";
import "./index.scss";
import "./mobile.scss";
import Loading from "../../components/Loading";
import TokenContainer from "../../components/TokenContainer/index";
import {
  PrivateSalePropsType,
  getPrivateSaleArrayLength,
  getPrivateSaleArray,
  PrivateDataPienSers,
} from "../../hooks/PrivateSale";
import { Empty } from 'antd';
import { useTranslation } from "react-i18next";
declare const window: Window & { ethereum: any };
const PrivateSale: React.FC = () => {
  const [PriveList, setPriveList] = useState<PrivateSalePropsType[]>([]);
  const [presalesloading, setPresalesLoading] = useState<boolean>(false);
  const [isePending, setTransition] = useTransition();
  const { t } = useTranslation();

  const CurrencyContainerShow = async () => {
    try {
      setPresalesLoading(true);
      Promise.all([getPrivateSaleArrayLength(), getPrivateSaleArray()])
        .then(async (resolve) => {
          const getPrivateListData = await PrivateDataPienSers(
            resolve[0],
            resolve[1]
          );
          setTransition(() => {
            setPriveList((DataListItem: PrivateSalePropsType[]) => {
              return (DataListItem = getPrivateListData);
            });
            setPresalesLoading(false);
          });
          setPresalesLoading(false);
        })
        .catch((error) => {
          setPresalesLoading(false);
        });
    } catch (error) {
      setPresalesLoading(false);
    }
  };
  useEffect(() => { }, [PriveList]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        CurrencyContainerShow();
      }
    }

  }, []);
  return (
    <div className="privatesale">
      <div className="privatesale-content">
        <div className="privatesale-title">{`${t("Private Sale List")}`}</div>
        {presalesloading ? (
          <div className="presale-loading">
            <Loading></Loading>
          </div>
        ) : <>
          {PriveList.length > 0 ? (<TokenContainer tokenlist={PriveList} />) : <Empty description={false} />}
        </>}
      </div>
    </div>
  );
};

export default PrivateSale;
