const params = [
  {
    chainId: "0x61",
    chainName: "Binance Smart Chain Testnet",
    nativeCurrency: {
      name: "Binance Test Coin",
      symbol: "tBNB",
      decimals: 18,
    },
    blockExplorerUrls: ["https://testnet.bscscan.com"],
    rpcUrls: ["https://data-seed-prebsc-1-s1.binance.org:8545"],
  },
];

//   params: [
//     {
//       chainId: "0x38",
//       chainName: "Binance Smart Chain",
//       nativeCurrency: {
//         name: "Binance Coin",
//         symbol: "BNB",
//         decimals: 18,
//       },
//       blockExplorerUrls: ["https://bscscan.com"],
//       rpcUrls: ["https://bsc-dataseed3.binance.org"],
//     },
//   ],

export { params };
