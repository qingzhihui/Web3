//null 和 undefined有什么区别

// null 表示 no Object
// undefined 表示 no Value


console.log(typeof null)
console.log(typeof undefined)