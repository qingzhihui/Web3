import React, {useState, useEffect} from "react";
import "./index.scss";
import {MeReseItem} from "@/hooks/MeRese";
import Planelist from "@/components/Planelist";
import Hotelist from "@/components/Hotelist";
import TickeList from "@/components/Tickelist";

const MeRese = () => {
    const [usePrin, setUsePrin] = useState(1);
    return (
        <div className="MeRese">
            <div className="MeRese_nreo">
                <div className="MeRese_nreo_item">
                    <div className="MeRese_nreo_Rilei">
                        <div className="MeRese_Rilei_tile">My bookings</div>
                        <div className="MeRese_Rilei_nmro">
                            {MeReseItem.map((item: any) => (
                                <div
                                    key={item.key}
                                    className={[
                                        `Rilei_nmro_itme ${
                                            usePrin === item.key ? "Rilei_action" : ""
                                        }`,
                                    ].join(" ")}
                                    onClick={() => {
                                        setUsePrin(item.key);
                                    }}
                                >
                                    <div className="Rilei_nmro_image">
                                        <img
                                            src={require(`@/assets/image/${
                                                usePrin === item.key ? item.image_arr : item.image_box
                                            }`)}
                                            alt=""
                                        />
                                    </div>
                                    <div className="Rilei_nmro_title">{item.name}</div>
                                </div>
                            ))}
                        </div>
                    </div>
                    {
                        usePrin === 1 ? <div className="MeRese_nreo_prion">
                            <Planelist/>
                            <Hotelist/>
                            <TickeList/>
                        </div> : usePrin === 2 ? <div className="MeRese_nreo_prion">
                            <Planelist/>
                        </div> : usePrin === 3 ? <div className="MeRese_nreo_prion">
                            <Hotelist/>
                        </div> : <div className="MeRese_nreo_prion">
                            <TickeList/>
                        </div>
                    }
                </div>
            </div>
        </div>
    );
};

export default MeRese;
