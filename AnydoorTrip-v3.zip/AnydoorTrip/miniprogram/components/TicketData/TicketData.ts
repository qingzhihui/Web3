import { formatTimeTicket } from "../../utils/util";

// components/TimeConter/TimeConter.ts
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    msg: '我是子组件的值',
    showPopup: false,
    formatter(day: any) {
      const month = day.date.getMonth() + 1;
      const date = day.date.getDate();
      if (month === 5) {
        if (date === 1) {
          day.topInfo = '劳动节';
        } else if (date === 4) {
          day.topInfo = '五四青年节';
        } else if (date === 11) {
          day.text = '今天';
        }
      }
      if (day.type === 'start') {
        day.bottomInfo = '入住';
      } else if (day.type === 'end') {
        day.bottomInfo = '离店';
      }
      return day;
    },
    TimeUoer: "",
    weekdayUoer: "",
    stepperValue: 1,
    roomNumer: 0
  },

  /**
   * 组件的方法列表
   */
  methods: {
    showPopup() {
      this.setData({ showPopup: true });
    },
    onClose() {
      this.setData({ show: false });
    },
    onDisplay() {
      this.setData({ showPopup: true });
    },
    showPopuPonClose() {
      this.setData({ showPopup: false });
    },
    onChange(event: any) {
      this.setData({
        stepperValue: event.detail
      })
    },
    RoonChange(event: any) {
      this.setData({
        roomNumer: event.detail
      })
    },
    onConfirm() {
      var that = this
      this.triggerEvent('TicketSend', {
        TimeUoer: that.data.TimeUoer,
        weekdayUoer: that.data.weekdayUoer,
        stepperValue: that.data.stepperValue,
        roomNumer: that.data.roomNumer
      })

      this.setData({
        showPopup: false
      })
    },
    onSelect(e: any) {
      var timestamp = Date.parse(new Date(e.detail).toString())
      this.setData({
        TimeUoer: formatTimeTicket(new Date(timestamp)),
        weekdayUoer: this.getWeekByDate(timestamp)
      })
    },
    getWeekByDate(dates: any) {
      let show_day = new Array('周日', '周一', '周二', '周三', '周四', '周五', '周六');
      let date = new Date(dates);
      date.setDate(date.getDate());
      let day = date.getDay();
      return show_day[day];
    },
  },


  attached: function () {
    var timestamp = Date.parse(new Date().toString())
    const StarTimeItem = formatTimeTicket(new Date(timestamp))
    this.setData({
      TimeUoer: StarTimeItem,
      weekdayUoer: this.getWeekByDate(timestamp)
    })
  }
})
