import api from '../../config/api'
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    getList: [],
    beismShow: false,
    value: "",
    pageNum: 1,
    invalue: "加载更多"
  },



  // 搜索

  onChange(e) {
    this.setData({
      value: e.detail,
    });
  },
  onClick() {
    this.setData({
      pageNum: 1
    })
    this.attached("DownRefresh");
  },
  Hideclear() {
    this.setData({
      value: "",
      pageNum: 1
    })
    this.attached("DownRefresh");
  },
  onSearch() {
    console.log('123');
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const token = wx.getStorageSync('admin')
    if (token.userId == null) {
      this.setData({
        beismShow: true
      })
    } else {
      this.attached("init");
    }
  },
  goLogs: function () {
    wx.navigateTo({
      url: '/pages/logs/logs'
    })
  },
  onDetail: function (e) {
    wx.navigateTo({
      url: `../Descrion/Descrion?id=${e.currentTarget.dataset.id}&quarter=${e.currentTarget.dataset.item}`
    })
  },
  onOnesn: function (e) {
    wx.navigateTo({
      url: '../HienShow/HienShow'
    })
  },
  onPosdr: function (e) {
    wx.navigateTo({
      url: `../Pisbuer/Pisbuer?id=${e.currentTarget.dataset.id}`,
    })
  },


  // 被驳回
  beiBohuiClick(data) {
    const token = wx.getStorageSync('admin')
    const qid = data.currentTarget.dataset.item.questionnaireId;
    const tid = data.currentTarget.dataset.item.tid;
    const grade = data.currentTarget.dataset.item.grade;
      wx.navigateTo({
        url: `../Rebutsn/Rebutsn?id=${token.userId}&qid=${qid}&teamId=${tid}&grade=${grade}`
      })
  },
  // 待答题
  daiDatiClick() {
    console.log('123');
  },
  // 待确认
  daiQuneClick() {
    const token = wx.getStorageSync('admin')
    wx.navigateTo({
      url: `../HienShow/HienShow?id=${token.userId}`
    })
  },








  attached(type) {
    const token = wx.getStorageSync('admin')
    wx.showLoading({
      title: '加载中，请耐心等待..'
    });
    api._get('ums/umsQuestionnaireHistory/wcharHistory/', {
      orgId: token.orgId,
      userId: token.userId,
      pageNum: this.data.pageNum,
      pageSize: 6,
      keyword: this.data.value
    }).then(res => {
      this.setData({
        getList: res.data.list
      })
      wx.hideLoading();
      if (res.data.total == this.data.getList.length) {
        this.setData({
          invalue: '没有更多数据'
        })
      } else {
        this.setData({
          invalue: '加载更多'
        })
      }
      console.log(res);
      // 请求结束 关闭下拉
      if (type == "DownRefresh") {
        wx.stopPullDownRefresh();
      }
    }).catch(e => {
      console.log(e)
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const shibe = getApp().globalData.is_first_login;
    // console.log(shibe);
    // if (shibe == undefined) {
    //   console.log(shibe);
    // } else {

    this.setData({
      pageNum: 1
    })
    this.attached("onShow");
    // }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      pageNum: 1
    })
    wx.showLoading({
      title: '加载中，请耐心等待..'
    });
    const token = wx.getStorageSync('admin')
    api._get('ums/umsQuestionnaireHistory/wcharHistory/', {
      orgId: token.orgId,
      userId: token.userId,
      pageNum: 1,
      pageSize: 6,
      keyword: ''
    }).then(res => {
      this.setData({
        getList: res.data.list
      })
      wx.stopPullDownRefresh();
      if (res.data.total == this.data.getList.length) {
        this.setData({
          invalue: '没有更多数据'
        })
      } else {
        this.setData({
          invalue: '加载更多'
        })
      }
    }).catch(e => {
      console.log(e)
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.setData({
      pageNum: this.data.pageNum + 1
    })
    wx.showLoading({
      title: '加载中，请耐心等待..'
    });
    console.log(this.data.pageNum);
    const token = wx.getStorageSync('admin')
    api._get('ums/umsQuestionnaireHistory/wcharHistory/', {
      orgId: token.orgId,
      userId: token.userId,
      pageNum: this.data.pageNum,
      pageSize: 6,
      keyword: ''
    }).then(res => {
      console.log(res);
      if (res.data.total == this.data.getList.length) {
        this.setData({
          invalue: "没有更多数据"
        })
      } else {
        const Pleur = [...this.data.getList, ...res.data.list];
        this.setData({
          getList: Pleur
        })
      }
    }).catch(e => {
      console.log(e)
    })
  },

  /**
   * 用户点击右上角分享
   */

  onShareAppMessage: function () {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  },
})

