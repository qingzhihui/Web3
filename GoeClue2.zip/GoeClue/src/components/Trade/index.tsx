import React, { useState } from "react";
import { CloseCircleOutlined } from "@ant-design/icons";
import "./index.scss";

const Trade = () => {
  const [useli, setUseli] = useState(0);
  const [isTase, setisTase] = useState(false);
  const [isPisr, setisPisr] = useState(false);
  const [serNUsien, setserNUsien] = useState(0);
  const [serPusien, setserPusien] = useState(0);
  const teamonClick = () => {
    console.log("123");
    setisTase(true);
  };
  const pitchonClick = () => {
    setisPisr(true);
  };
  return (
    <div className="Trade">
      <div className="Trade_nro">
        <div className="Trade_title">
          <div className="Trade_rile">
            <div
              className={[
                `Trade_rile_item ${useli == 0 ? "paction" : ""}`,
              ].join("")}
              onClick={() => {
                setUseli(0);
              }}
            >
              Team
            </div>
            <div
              className={[
                `Trade_rile_item ${useli == 1 ? "paction" : ""}`,
              ].join("")}
              onClick={() => {
                setUseli(1);
              }}
            >
              Stadium
            </div>
          </div>
          <div className="Rlisoien">
            {useli == 0 ? (
              <button
                onClick={() => {
                  teamonClick();
                }}
              >
                <span>Sell my team</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  pitchonClick();
                }}
              >
                <span>Sell my pitch</span>
              </button>
            )}
          </div>
        </div>
        <div className="Trade_luien">
          {useli == 0 ? (
            <div className="Trade_tow">
              <div className="Trade_tow">
                <div className="Trade_tow_item">
                  <div className="tow_item2">
                    <img src={require("../../assets/image/t1.png")} alt="" />
                  </div>
                  <div className="tow_inro">
                    <div>TokID：2154263</div>
                    <div>Wallet address：</div>
                    <div>0xa1...f52cl7416</div>
                    <div className="pbuem">
                      <div>
                        Price：51463
                        <img
                          src={require("../../assets/image/doller.png")}
                          alt=""
                        />
                      </div>
                      <button>Buy</button>
                    </div>
                  </div>
                </div>
                <div className="Trade_tow_item">
                  <div className="tow_item2">
                    <img src={require("../../assets/image/t1.png")} alt="" />
                  </div>
                  <div className="tow_inro">
                    <div>TokID：2154263</div>
                    <div>Wallet address：</div>
                    <div>0xa1...f52cl7416</div>
                    <div className="pbuem">
                      <div>
                        Price：51463
                        <img
                          src={require("../../assets/image/doller.png")}
                          alt=""
                        />
                      </div>
                      <button>Buy</button>
                    </div>
                  </div>
                </div>
                <div className="Trade_tow_item">
                  <div className="tow_item2">
                    <img src={require("../../assets/image/t1.png")} alt="" />
                  </div>
                  <div className="tow_inro">
                    <div>TokID：2154263</div>
                    <div>Wallet address：</div>
                    <div>0xa1...f52cl7416</div>
                    <div className="pbuem">
                      <div>
                        Price：51463
                        <img
                          src={require("../../assets/image/doller.png")}
                          alt=""
                        />
                      </div>
                      <button>Buy</button>
                    </div>
                  </div>
                </div>
                <div className="Trade_tow_item">
                  <div className="tow_item2">
                    <img src={require("../../assets/image/t1.png")} alt="" />
                  </div>
                  <div className="tow_inro">
                    <div>TokID：2154263</div>
                    <div>Wallet address：</div>
                    <div>0xa1...f52cl7416</div>
                    <div className="pbuem">
                      <div>
                        Price：51463
                        <img
                          src={require("../../assets/image/doller.png")}
                          alt=""
                        />
                      </div>
                      <button>Buy</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="Trade_tow">
              <div className="Trade_tow_item">
                <div className="tow_item">
                  <img src={require("../../assets/image/stadium.png")} alt="" />
                </div>
                <div className="tow_inro">
                  <div>TokID：2154263</div>
                  <div>Wallet address：</div>
                  <div>0xa1...f52cl7416</div>
                  <div className="pbuem">
                    <div>
                      Price：51463
                      <img
                        src={require("../../assets/image/doller.png")}
                        alt=""
                      />
                    </div>
                    <button>Buy</button>
                  </div>
                </div>
              </div>
              <div className="Trade_tow_item">
                <div className="tow_item">
                  <img src={require("../../assets/image/stadium.png")} alt="" />
                </div>
                <div className="tow_inro">
                  <div>TokID：2154263</div>
                  <div>Wallet address：</div>
                  <div>0xa1...f52cl7416</div>
                  <div className="pbuem">
                    <div>
                      Price：51463
                      <img
                        src={require("../../assets/image/doller.png")}
                        alt=""
                      />
                    </div>
                    <button>Buy</button>
                  </div>
                </div>
              </div>
              <div className="Trade_tow_item">
                <div className="tow_item">
                  <img src={require("../../assets/image/stadium.png")} alt="" />
                </div>
                <div className="tow_inro">
                  <div>TokID：2154263</div>
                  <div>Wallet address：</div>
                  <div>0xa1...f52cl7416</div>
                  <div className="pbuem">
                    <div>
                      Price：51463
                      <img
                        src={require("../../assets/image/doller.png")}
                        alt=""
                      />
                    </div>
                    <button>Buy</button>
                  </div>
                </div>
              </div>
              <div className="Trade_tow_item">
                <div className="tow_item">
                  <img src={require("../../assets/image/stadium.png")} alt="" />
                </div>
                <div className="tow_inro">
                  <div>TokID：2154263</div>
                  <div>Wallet address：</div>
                  <div>0xa1...f52cl7416</div>
                  <div className="pbuem">
                    <div>
                      Price：51463
                      <img
                        src={require("../../assets/image/doller.png")}
                        alt=""
                      />
                    </div>
                    <button>Buy</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      {isTase ? (
        <div className="pserisTase">
          <div
            className="pserzhes"
            onClick={() => {
              setisTase(false);
            }}
          ></div>
          <div className="pserExchange">
            <div className="pserExchange_nro">
              <div className="pserNUsien">
                <div
                  className={[
                    `pserNUsien_item ${serPusien === 1 ? "pseractiom2" : ""}`,
                  ].join("")}
                  onClick={() => {
                    setserPusien(1);
                  }}
                >
                  <img src={require("../../assets/image/t1.png")} alt="" />
                </div>
                <div
                  className={[
                    `pserNUsien_item ${serPusien === 2 ? "pseractiom2" : ""}`,
                  ].join("")}
                  onClick={() => {
                    setserPusien(2);
                  }}
                >
                  <img src={require("../../assets/image/t2.png")} alt="" />
                </div>
                <div
                  className={[
                    `pserNUsien_item ${serPusien === 3 ? "pseractiom2" : ""}`,
                  ].join("")}
                  onClick={() => {
                    setserPusien(3);
                  }}
                >
                  <img src={require("../../assets/image/t3.png")} alt="" />
                </div>
              </div>
              <div className="pserFuner">
                <div className="pserFuner_input">
                  <div className="pserFuner_input_rpir">Get</div>
                  <div className="pserFuner_input_res">
                    <input type="text" />
                    <div className="pserFuner_input_ris">GLC</div>
                  </div>
                </div>
              </div>
              <div className="pserButon">
                <div className="psniernk">
                  <button
                    onClick={() => {
                      setisTase(false);
                    }}
                  >
                    取消
                  </button>
                  <button>出售</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      {isPisr ? (
        <div className="pserisTase">
          <div
            className="pserzhes"
            onClick={() => {
              setisPisr(false);
            }}
          ></div>
          <div className="pserExchange">
            <div className="pserExchange_nro">
              <div className="pserNUsien">
                <div
                  className={[
                    `pserNUsien_item ${serNUsien === 1 ? "pseractiom" : ""}`,
                  ].join("")}
                  onClick={() => {
                    setserNUsien(1);
                  }}
                >
                  <img
                    src={require("../../assets/image/setisTase3.png")}
                    alt=""
                  />
                </div>
                <div
                  className={[
                    `pserNUsien_item ${serNUsien === 2 ? "pseractiom" : ""}`,
                  ].join("")}
                  onClick={() => {
                    setserNUsien(2);
                  }}
                >
                  <img src={require("../../assets/image/stadium.png")} alt="" />
                </div>
                <div
                  className={[
                    `pserNUsien_item ${serNUsien === 3 ? "pseractiom" : ""}`,
                  ].join("")}
                  onClick={() => {
                    setserNUsien(3);
                  }}
                >
                  <img
                    src={require("../../assets/image/stadium2.png")}
                    alt=""
                  />
                </div>
              </div>
              <div className="pserFuner">
                <div className="pserFuner_input">
                  <div className="pserFuner_input_rpir">Get</div>
                  <div className="pserFuner_input_res">
                    <input type="text" />
                    <div className="pserFuner_input_ris">GLC</div>
                  </div>
                </div>
              </div>
              <div className="pserButon">
                <div className="psniernk">
                  <button
                    onClick={() => {
                      setisPisr(false);
                    }}
                  >
                    取消
                  </button>
                  <button>出售</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </div>
  );
};

export default Trade;
