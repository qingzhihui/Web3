import { ethers } from "ethers";

export function isAddress(address:string){
    if(ethers.utils.isAddress(address)){
        return true
    } else {
        return false
    }
}