import { Button, Popconfirm, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import { IAdmin } from '../index';
import styles from './index.module.css';

function ListArg(props: any) {
  const [dataSource, setDataSource] = useState(props);
  const columns: ColumnsType<IAdmin> = [
    {
      title: 'key',
      dataIndex: 'key',
      key: 'key',
      render: (text) => <a>{text}</a>,
    },
    {
      title: 'address',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: 'mnemonic',
      dataIndex: 'mnemonic',
      key: 'mnemonic',
    },
    {
      title: 'privateKey',
      dataIndex: 'privateKey',
      key: 'privateKey',
    },
    {
      title: 'Delete',
      key: 'operation',
      fixed: 'right',
      width: 100,
      render: (record: { key: React.Key }) =>
        dataSource.admin.length >= 1 ? (
          <Popconfirm title="确定要删除吗?" onConfirm={() => handleDelete(record.key)}>
            <Button type="primary">删除</Button>
          </Popconfirm>
        ) : null,
    },
  ];
  const handleDelete = (key: React.Key) => {
    const newData = dataSource.admin.filter((item: IAdmin) => item.key !== key);
    setDataSource({ admin: newData });
  };

  return (
    <div className={styles.tablues}>
      <Table
        columns={columns}
        bordered={true}
        dataSource={dataSource.admin}
        rowKey={(admin) => admin.key}
      />
    </div>
  );
}

export default ListArg;
