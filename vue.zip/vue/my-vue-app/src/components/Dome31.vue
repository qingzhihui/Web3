<template>

</template>

<script setup>
//css3 过度结束后事件多次触发

const dom = document.getElementById("item")

/*过度结束后执行这个函数*/
dom.addEventListener('transitionend', () => {
  console.log('123')
//  true
},{
  once:true //只触发一次
})
</script>

<style>

</style>
