import React, { useState, memo } from "react";

// Mastering React Memo(备忘录)

function Swatch({ color }: any) {
  console.log(`Swatch ${color}`);
  return (
    <div style={{ margin: 2, width: 75, height: 75, background: color }}></div>
  );
}
// memo是一个高阶组件，所以你给他一个组件，他包装他并且创建另一个组件，在这种情况下，他被称为备忘录样本
const MemoedSwatch = memo(Swatch);

const Index = () => {
  const [color, setColor] = useState("red");
  const Che= ()=>{

  }
  const [appRebderIndex, setAppRebderIndex] = useState(0);
  console.log(`App rendered ${appRebderIndex}`);
  return (
    <div>
      <div>
        <button onClick={() => setAppRebderIndex(appRebderIndex + 1)}>
          Re-Render App
        </button>
        <button onClick={() => setColor(color === "red" ? "blue" : "red")}>
          Change Color
        </button>
      </div>
      <div>
        <MemoedSwatch color={color} />
      </div>
    </div>
  );
};

export default Index;
