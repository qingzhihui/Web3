import {
  EthereumClient,
  w3mConnectors,
  w3mProvider,
} from "@web3modal/ethereum";
import { configureChains, createClient } from "wagmi";
import { arbitrum, mainnet, polygon } from "wagmi/chains";
const chains = [arbitrum, mainnet, polygon];
const projectId = "b98a412bd29c5618fe10c37180fa6813";
const { provider } = configureChains(chains, [w3mProvider({ projectId })]);
const wagmiClient = createClient({
  autoConnect: true,
  connectors: w3mConnectors({ projectId, version: 1, chains }),
  provider,
});
const ethereumClient = new EthereumClient(wagmiClient, chains);

export { projectId, ethereumClient };
