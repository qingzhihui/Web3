// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from 'C:/Users/AnyDoorTrip-05/Desktop/Lisersn/node_modules/umi/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@/components/PageLoading';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: '.umi__plugin-layout__Layout' */'C:/Users/AnyDoorTrip-05/Desktop/Lisersn/src/.umi/plugin-layout/Layout.tsx'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__index' */'@/pages/index'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/user",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__index' */'@/pages/user/index'), loading: LoadingComponent}),
        "name": "user",
        "icon": "smile",
        "exact": true
      },
      {
        "path": "/wrappers",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__wrappers__index' */'@/pages/wrappers/index'), loading: LoadingComponent}),
        "exact": false,
        "name": "wrappers",
        "icon": "crown"
      },
      {
        "path": "/ches",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__ches__index' */'@/pages/ches/index'), loading: LoadingComponent}),
        "exact": false,
        "name": "ches",
        "icon": "crown"
      },
      {
        "path": "/product",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__product__index' */'@/pages/product/index'), loading: LoadingComponent}),
        "exact": false,
        "name": "product",
        "icon": "crown"
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
