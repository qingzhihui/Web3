import React from "react";
import { Carousel } from "antd";
import { useTranslation, Trans } from "react-i18next";
import GrowingTopList from './GrowingTopList.json'
import GrowingBottomList from './GrowingBottomList.json'
import SuiteList from './SuiteTokenSaleList.json'
import "./index.scss";

const Home: React.FC = (props: any) => {
  const { t } = useTranslation();
  return (
    <div className="Home">
      <div className="HomeItem">
        <div className="HomeItem_tow">
          <div className="HomeItem_tow_leth">
            <div className="tow_leth_title">
              <div className="leth_title_wen1">
                {`${t("WELCOME TO MAYA")}`}
              </div>
              <div className="leth_title_wen2">ID:2320382</div>
            </div>
            <div className="tow_leth_nrot">
              <div className="leth_nrot_tox">
                <img src={require("../../assets/image/loge.png")} alt="" />
              </div>
              <div className="leth_nrot_nro">
                <div className="nrot_nro1">Brokln Simons</div>
                <div className="nrot_nro2">@broklinslam_75</div>
              </div>
            </div>
            <div className="tow_leth_fone">
              <div className="leth_fone_buie">
                <div className="fone_buie_nro1">
                  <div className="buie_nro_tow">{`${t("Soft/Hard")}`}</div>
                  <div className="buie_nro_tno">75,320 ETH</div>
                  <div className="buie_nro_fro">773.69 USD</div>
                </div>
                <div className="buie_nro_xing"></div>
                <div className="fone_buie_nro2">
                  <div className="buie_nro_tow">{`${t("Remaing Time")}`}</div>
                  <div className="buie_nro_tno">47:23:59</div>
                  {/* <div className="buie_nro_fro">{`${t("Hrs Mins Sec")}`}</div> */}
                </div>
              </div>
            </div>
            <div className="tow_leth_buot">
              <div className="leth_buot_wioeng">
                <img src={require("../../assets/image/itemicon.png")} alt="" />
              </div>
              <div className="leth_buot_wpri">
                <button>{`${t("View")}`}</button>
              </div>
            </div>
          </div>
          <div className="HomeItem_tow_rotr">
            <div className="tow_rotr_item">
              <Carousel>
                <div className="rotr_item_imge">
                  <img src={require("../../assets/image/t1.png")} alt="" />
                </div>
                <div className="rotr_item_imge">
                  <img src={require("../../assets/image/t1.png")} alt="" />
                </div>
                <div className="rotr_item_imge">
                  <img src={require("../../assets/image/t1.png")} alt="" />
                </div>
              </Carousel>
            </div>
          </div>
        </div>
        <div className="HomeItem_won">
          <div className="card">
            <div className="carditem">
              <div className="carditem_top">
                <div>
                  <img src={require("../../assets/image/card4.png")} alt="" />
                </div>
                <div className="top_title">
                  <div>$ 343.2M</div>
                  <div>{`${t("Total Liquidity Raised")}`}</div>
                </div>
              </div>
              <div className="carditem_bom">
                <div>
                  <img src={require("../../assets/image/xian1.png")} alt="" />
                </div>
              </div>
            </div>
            <div className="carditem">
              <div className="carditem_top">
                <div>
                  <img src={require("../../assets/image/card3.png")} alt="" />
                </div>
                <div className="top_title">
                  <div>13928</div>
                  <div>{`${t("Total Projects")}`}</div>
                </div>
              </div>
              <div className="carditem_bom">
                <div>
                  <img src={require("../../assets/image/xian4.png")} alt="" />
                </div>
              </div>
            </div>
            <div className="carditem">
              <div className="carditem_top">
                <div>
                  <img src={require("../../assets/image/card2.png")} alt="" />
                </div>
                <div className="top_title">
                  <div>1.4M</div>
                  <div>{`${t("Total Participants")}`}</div>
                </div>
              </div>
              <div className="carditem_bom">
                <div>
                  <img src={require("../../assets/image/xian2.png")} alt="" />
                </div>
              </div>
            </div>
            <div className="carditem">
              <div className="carditem_top">
                <div>
                  <img src={require("../../assets/image/card1.png")} alt="" />
                </div>
                <div className="top_title">
                  <div>$ 206.3M</div>
                  <div>{`${t("Total Values Locked")}`}</div>
                </div>
              </div>
              <div className="carditem_bom">
                <div>
                  <img src={require("../../assets/image/xian3.png")} alt="" />
                </div>
              </div>
            </div>
          </div>
          <div className="protocol">
            <div className="colletft">
              <div>{`${t("The Launchpad Protocol for Everyone !")}`}</div>
              <div>
                {`${t(
                  "MAYA helps everyone to create their own tokens and token sales in few seconds."
                )}`}
                <br />
                {`${t(
                  "Tokens created on MAYA will be verified and published on explorer websites."
                )}`}
              </div>
            </div>
            <div className="colright"> {`${t("Create Now")}`}</div>
          </div>
          <div className="tokensales">
            <div className="suite">{`${t(
              "A Suite of Tools for Token Sales"
            )}`}</div>
            <div className="suite_instructions">
              {`${t(
                "A suite of tools were built to help you create your own tokens and launchpads in a fast, simple and cheap way, with no prior code knowledge required and 100% decentralized!"
              )}`}
            </div>
            <div className="suite_cards">
              <div className="cards_top">
                {SuiteList.map((item: any) => (
                  <div className="homecards" key={item.name}>
                    <img
                      src={require("../../assets/image/suitecard.png")}
                      alt=""
                    />
                    <div className="name">{`${t(item.name)}`}</div>
                    <div className="avax">
                      {`${t(item.desc)}`}
                    </div>
                  </div>
                ))}
              </div>
              {/* <div className="cards_top">
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
              </div>
              <div className="cards_bom">
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
              </div> */}
            </div>
          </div>
          <div className="ecosystem">
            <div className="growing">{`${t(
              "A Growing Protocol Ecosystem"
            )}`}</div>
            <div className="finance">
              {`${t(
                "We build a suite of tools for the world of decentralized finance."
              )}`}
              {`${t(
                "MAYAMoon, MAYA, MAYAElon, MAYALock, MAYASwap, we MAYA everything!"
              )}`}
            </div>
            <div className="ecosystem-cards">
              <div className="cares2_top">
                {GrowingTopList.map((item: any) => (
                  <div className="homecards" key={item.name}>
                    <img
                      src={require("../../assets/image/suitecard.png")}
                      alt=""
                    />
                    <div className="name">{`${t(item.name)}`}</div>
                    <div className="avax">
                      {`${t(item.desc)}`}
                    </div>
                  </div>
                ))}
                {/* <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div> */}
              </div>
              <div className="cares2_bom">
                {GrowingBottomList.map((item: any) => (
                  <div className="homecards" key={item.name}>
                    <img
                      src={require("../../assets/image/suitecard.png")}
                      alt=""
                    />
                    <div className="name">{`${t(item.name)}`}</div>
                    <div className="avax">
                      {`${t(item.desc)}`}
                    </div>
                  </div>
                ))}
                {/* <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div>
                <div className="homecards">
                  <img
                    src={require("../../assets/image/suitecard.png")}
                    alt=""
                  />
                  <div className="name">{`${t("Standard")}`}</div>
                  <div className="avax">
                    {`${t(
                      "Mint standard tokens on ETH, BSC, AVAX, Fantom, Polygon."
                    )}`}
                  </div>
                </div> */}
              </div>
            </div>
            <div className="disclaimer">
              {`${t(
                "Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published."
              )}`}
            </div>
          </div>
          <div className="imgs">
            <img src={require("../../assets/image/homecat.png")} alt="" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
