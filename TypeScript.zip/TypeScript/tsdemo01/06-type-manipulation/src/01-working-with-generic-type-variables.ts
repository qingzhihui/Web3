function loggingIdentity<Type>(arg: Array<Type>): Type[] {
  console.log(arg.length);
  return arg;
}

loggingIdentity([100,200]);
