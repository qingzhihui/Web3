import { AntiBotABI, AntiBotAddress } from "./AntiBot";
import { InstancedContract } from "./config";

const AntiBotContract = InstancedContract(AntiBotAddress, AntiBotABI) as any;

const totalWhiteList = async (address: string) => {
  return await AntiBotContract.totalWhiteList(address);
};
const totalBlackList = async (address: string) => {
  return await AntiBotContract.totalBlackList(address);
};
const getWhiteList = async (address: string) => {
  return await AntiBotContract.getWhiteList(address);
};
const getBlackList = async (address: string) => {
  return await AntiBotContract.getBlackList(address);
};
const AntiBotStatePDate = async (address: string) => {
  const getTokenStatus = await AntiBotContract.getTokenStatus(address);
  return {
    ProteStatus: getTokenStatus.enabled,
    AmountLimit: getTokenStatus.amountLimit.toString(),
    TimeLimit: getTokenStatus.timeLimit.toString(),
    Blocksleft: getTokenStatus.leftBlocks.toString(),
    CurreBlock: getTokenStatus.currentBlock.toString(),
  };
};

const whitelistUsersData = async (address: any) => {
  return Promise.all([
    totalWhiteList(address),
    totalBlackList(address),
    getWhiteList(address),
    getBlackList(address),
    AntiBotStatePDate(address)
  ]).then((res) => {
    return res
  });
};

export {
    whitelistUsersData
};
