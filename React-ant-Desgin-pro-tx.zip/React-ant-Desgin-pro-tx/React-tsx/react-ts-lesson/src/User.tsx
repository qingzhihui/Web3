import React from "react";

function User() {
  const isAuth = false;
  //   if (!isAuth) {
  //     return <>unAuth</>;
  //   }
  const say = () => {
    return "say";
  };
  return (
    <div>
      {/* {isAuth ? "auth" : "unAuth"} */}
      {isAuth && say()}
    </div>
  );
}

export default User;
