import React, { useState, useContext, useEffect } from "react";
// React 18的新状态挂钩你从未听说过

const ThemeContext = React.createContext<any>(null);

const ThemeProvider = ({ children }: any) => {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };
  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

const ThemedButton = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);
  useEffect(()=>{
    console.log(ThemeContext);
    
  },[])
  return (
    <button
      style={{ backgroundColor: theme === "light" ? "white" : "black" }}
      onClick={toggleTheme}
    >
      {theme === "light" ? "Switch to Dark Theme" : "Switch to Light Theme"}
    </button>
  );
};

const Index = () => {
  return (
    <div>
      <ThemeProvider>
        <ThemedButton />
      </ThemeProvider>
    </div>
  );
};

export default Index;
