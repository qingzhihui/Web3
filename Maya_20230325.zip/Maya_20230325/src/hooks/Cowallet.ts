import NodeWalletConnect from "@walletconnect/node";
import WalletConnectQRCodeModal from "@walletconnect/qrcode-modal";
import { params } from "../utils/network";
declare const window: Window & { ethereum: any };

const MetamShow = async () => {
  const provider = window.ethereum;
  if(provider){
    const chainId = await provider.request({ method: "eth_chainId" });
    const binanceTestChainId = "0x61";
    if (chainId === binanceTestChainId) {
      try {
        const { ethereum } = window;
        if (!ethereum) {
          alert("Get MetaMask!");
          return;
        }
        const accounts = await ethereum.request({
          method: "eth_requestAccounts",
        });
        if (accounts[0]) {
          localStorage.setItem("MaYa_addr", accounts[0]);
          return accounts[0];
        }
      } catch (error) {
      }
    } else {
      try {
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: binanceTestChainId }],
        });
        connectWallet();
      } catch (switchError: any) {
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: params,
            });
          } catch (addError) {
            console.error(addError);
          }
        }
      }
    }
  } else {
    alert("Get MetaMask!");
  }
};
const connectWallet = async () => {
  try {
    const { ethereum } = window;
    if (!ethereum) {
      alert("Get MetaMask!");
      return;
    }
    const accounts = await ethereum.request({
      method: "eth_requestAccounts",
    });
    if (accounts[0]) {
      localStorage.setItem("MaYa_addr", accounts[0]);
    }
  } catch (error) {
  }
};
const connectWalletConnect = () => {
  try {
    const walletConnector = new NodeWalletConnect(
      {
        bridge: "https://bridge.walletconnect.org", // Required
      },
      {
        clientMeta: {
          description: "WalletConnect NodeJS Client",
          url: "https://nodejs.org/en/",
          icons: ["https://nodejs.org/static/images/logo.svg"],
          name: "WalletConnect",
        },
      }
    );
    if (!walletConnector.connected) {
      walletConnector.createSession().then(() => {
        const uri = walletConnector.uri;
        WalletConnectQRCodeModal.open(uri, () => {});
      });
    }
    walletConnector.on("connect", (error: any, payload: any) => {
      if (error) {
        throw error;
      }
      WalletConnectQRCodeModal.close();
      const { accounts, chainId } = payload.params[0];
      let myeth = accounts[0];
      localStorage.setItem("MaYa_addr", myeth);
      return accounts[0];
    });
  } catch (ex) {
  }
};



export { MetamShow, connectWalletConnect };
