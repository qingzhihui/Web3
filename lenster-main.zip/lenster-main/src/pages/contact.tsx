import Contact from '@components/Pages/Contact'

export default Contact
