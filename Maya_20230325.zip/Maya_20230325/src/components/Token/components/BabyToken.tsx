import React, { useEffect, useState } from "react";
import { Checkbox, Input, Form, Select } from "antd";
import type { CheckboxChangeEvent } from "antd/es/checkbox";
import "../../../styles/index.css";
import "../../../styles/mobile.css";
import styles from "../index.module.css";
import { BabyTokenList, DigitalInput, DisableDoubleCharacters, OptionList } from "../../../hooks/Token";
import { BabyTokenItem, RouterOptionItem } from "../../../state/TokenState";
import { useTranslation, Trans } from "react-i18next";
import { Constan } from "../../../config/constants/constants";
import { FormatUnitsConver, InstancedContract } from "../../../hooks/config";
import InputError from '../../InputError'
import { isAddress } from '../../../utils/address'
import { posInvFormat, floatformat } from "../../../utils/floatFormat";
import { BabyTokenError } from '../../../hooks/Errorhandle'
import { BigNumber } from "ethers";
import ButtonLoading from "../../ButtonLoading";
import { BabyTokenErrorInitState } from "../../../state/BabyTokenErrorState";
declare const window: Window & { ethereum: any };

const { Option } = Select;

interface BabyTokenProps {
  Token: string;
  loading: boolean;
  BodyAdd: (e: any) => void;
}
const BabyToken: React.FC<BabyTokenProps> = ({ Token, BodyAdd, loading }) => {
  const { t } = useTranslation();
  const [BabyNer, setBabyNer] = useState<BabyTokenList>(BabyTokenItem);
  const [flatFeeShow, setFlatFeeShow] = useState("");

  const [babyError, setBabyError] = useState<BabyTokenError>(BabyTokenErrorInitState)

  const setError = (key: string, value: boolean) => {
    setBabyError((olddata: BabyTokenError) => {
      return {
        ...olddata,
        [key]: value,
      }
    })
  }

  const isCreate = () => {
    if (
      !babyError.NameBlankError
      && !babyError.NameCharactersError
      && !babyError.SymbolBlankError
      && !babyError.SymbolCharactersError
      && !babyError.TotalSupplyBlankError
      && !babyError.TotalSupplyAmountError
      && !babyError.RewardTokenBlankError
      && !babyError.RewardTokenInvalidError
      && !babyError.DividendsBlankError
      && !babyError.DividendsMaxError
      && !babyError.RewardFeeBlankError
      && !babyError.RewardFeeMinError
      && !babyError.LiquidityFeeBlankError
      && !babyError.LiquidityFeeMinError
      && !babyError.MarketingFeeBlankError
      && !babyError.MarketingFeeMinError
      && !babyError.FeeOverError
      && !babyError.WalletBlankError
      && !babyError.WalletInvalidError
      && BabyNer.Name
      && BabyNer.Symbol
      && BabyNer.Supply
      && BabyNer.Router
      && BabyNer.RewardToken
      && BabyNer.Dividends
      && BabyNer.RewardFee
      && BabyNer.LiquidityFee
      && BabyNer.MarketingFee
      && BabyNer.Wallet
    ) {
      return true;
    } else {
      return false;
    }
  }

  const [form] = Form.useForm();
  const StandardCreateOnClikc = () => {
    BodyAdd({
      TokenPunie: Token,
      StandsData: BabyNer,
    });
  };
  const OnClickSelectCreate = (standarEvent: string) => {
    RouterOptionItem.filter((Opitem: OptionList) => {
      if (Opitem.value === standarEvent) {
        setBabyNer((olddata: BabyTokenList) => {
          return {
            ...olddata,
            Router: Opitem.value,
          };
        });
      }
    });
  };
  const NameValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DisableDoubleCharacters(e);
    if (inputChange !== undefined) {
      setBabyNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("NameBlankError", true)
        } else {
          setError("NameBlankError", false)
        }
        if (inputChange && inputChange.length < 2) {
          setError("NameCharactersError", true)
        } else {
          setError("NameCharactersError", false)
        }
        return {
          ...olddata,
          Name: inputChange,
        };
      })
    }
  };
  const SymbolValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DisableDoubleCharacters(e);
    if (inputChange !== undefined) {
      setBabyNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("SymbolBlankError", true)
        } else {
          setError("SymbolBlankError", false)
        }
        if (inputChange && inputChange.length < 2) {
          setError("SymbolCharactersError", true)
        } else {
          setError("SymbolCharactersError", false)
        }
        return {
          ...olddata,
          Symbol: inputChange,
        };
      });
    }
  };
  const SupplyValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setBabyNer((olddata: BabyTokenList) => {
      if (inputChange === '') {
        setError("TotalSupplyBlankError", true)
      } else {
        setError("TotalSupplyBlankError", false)
      }
      if (inputChange !== undefined && inputChange !== '') {
        if (BigNumber.from(inputChange).gte(BigNumber.from(10).pow(16))) {
          setError("TotalSupplyAmountError", true)
        } else {
          setError("TotalSupplyAmountError", false)
        }
      }
      if (inputChange && BabyNer.Dividends && Number(BabyNer.Dividends) > (Number(inputChange) * 0.001)) {
        setError("DividendsMaxError", true)
      } else if (inputChange && (BabyNer.Dividends === '' || BabyNer.Dividends === undefined)) {
        setError("DividendsMaxError", false)
      } else {
        setError("DividendsMaxError", false)
      }
      return {
        ...olddata,
        Supply: inputChange
      };
    });
  };
  const RewardTokenValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBabyNer((olddata: BabyTokenList) => {
      if (e.target.value === "") {
        setError("RewardTokenBlankError", true)
      } else {
        setError("RewardTokenBlankError", false)
      }
      if (!isAddress(e.target.value) && e.target.value) {
        setError("RewardTokenInvalidError", true)
      } else {
        setError("RewardTokenInvalidError", false)
      }
      return {
        ...olddata,
        RewardToken: e.target.value,
      };
    })
  };
  const DividendsValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    if (inputChange !== undefined) {
      setBabyNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("DividendsBlankError", true)
        } else {
          setError("DividendsBlankError", false)
        }
        if (inputChange && BabyNer.Supply && Number(inputChange) > (Number(BabyNer.Supply) * 0.001)) {
          setError("DividendsMaxError", true)
        } else if (inputChange && (BabyNer.Supply === '' || BabyNer.Supply === undefined)) {
          setError("DividendsMaxError", true)
        } else {
          setError("DividendsMaxError", false)
        }
        return {
          ...olddata,
          Dividends: inputChange
        };
      });
    }
  };
  const RewardFeeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setBabyNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("RewardFeeBlankError", true)
        } else {
          setError("RewardFeeBlankError", false)
        }
        if (inputChange && Number(inputChange) < 0.01) {
          setError("RewardFeeMinError", true)
        } else {
          setError("RewardFeeMinError", false)
        }
        if (inputChange && BabyNer.LiquidityFee && BabyNer.MarketingFee) {
          if (Number(inputChange) + Number(BabyNer.LiquidityFee) + Number(BabyNer.MarketingFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          RewardFee: inputChange
        };
      });
    }
  };
  const LiquidityFeeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setBabyNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("LiquidityFeeBlankError", true)
        } else {
          setError("LiquidityFeeBlankError", false)
        }
        if (inputChange && Number(inputChange) < 0.01) {
          setError("LiquidityFeeMinError", true)
        } else {
          setError("LiquidityFeeMinError", false)
        }
        if (inputChange && BabyNer.RewardFee && BabyNer.MarketingFee) {
          if (Number(inputChange) + Number(BabyNer.RewardFee) + Number(BabyNer.MarketingFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          LiquidityFee: inputChange
        };
      });
    }
  };
  const MarketingFeeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setBabyNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("MarketingFeeBlankError", true)
        } else {
          setError("MarketingFeeBlankError", false)
        }
        if (inputChange && Number(inputChange) < 0.01) {
          setError("MarketingFeeMinError", true)
        } else {
          setError("MarketingFeeMinError", false)
        }
        if (inputChange && BabyNer.RewardFee && BabyNer.LiquidityFee) {
          if (Number(inputChange) + Number(BabyNer.RewardFee) + Number(BabyNer.LiquidityFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          MarketingFee: inputChange
        };
      });
    }
  };
  const WalletValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      setBabyNer((olddata: BabyTokenList) => {
        if (e.target.value === '') {
          setError("WalletBlankError", true)
        } else {
          setError("WalletBlankError", false)
        }
        if (!isAddress(e.target.value) && e.target.value) {
          setError("WalletInvalidError", true)
        } else {
          setError("WalletInvalidError", false)
        }
        return {
          ...olddata,
          Wallet: e.target.value,
        };
      })
    }
  };
  const NameBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("NameBlankError", true)
      } else {
        setError("NameBlankError", false)
      }
      if (e.target.value && e.target.value.length < 2) {
        setError("NameCharactersError", true)
      } else {
        setError("NameCharactersError", false)
      }
    }
  };
  const SymbolBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("SymbolBlankError", true)
      } else {
        setError("SymbolBlankError", false)
      }
      if (e.target.value && e.target.value.length < 2) {
        setError("SymbolCharactersError", true)
      } else {
        setError("SymbolCharactersError", false)
      }
    }
  };
  const SupplyBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      setError("TotalSupplyBlankError", true)
    } else {
      setError("TotalSupplyBlankError", false)
    }
    if (e.target.value !== undefined && e.target.value !== '') {
      if (BigNumber.from(e.target.value).gte(BigNumber.from(10).pow(16))) {
        setError("TotalSupplyAmountError", true)
      } else {
        setError("TotalSupplyAmountError", false)
      }
    }
    if (e.target.value && BabyNer.Dividends && Number(BabyNer.Dividends) > (Number(e.target.value) * 0.001)) {
      setError("DividendsMaxError", true)
    } else if (e.target.value && (BabyNer.Dividends === '' || BabyNer.Dividends === undefined)) {
      setError("DividendsMaxError", false)
    } else {
      setError("DividendsMaxError", false)
    }
  }
  const RewardTokenBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === "") {
      setError("RewardTokenBlankError", true)
    } else {
      setError("RewardTokenBlankError", false)
    }
    if (!isAddress(e.target.value) && e.target.value) {
      setError("RewardTokenInvalidError", true)
    } else {
      setError("RewardTokenInvalidError", false)
    }
  };
  const DividendsBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("DividendsBlankError", true)
      } else {
        setError("DividendsBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 1) {
        setError("DividendsMinError", true)
      } else {
        setError("DividendsMinError", false)
      }
      if (e.target.value && BabyNer.Supply && Number(e.target.value) > (Number(BabyNer.Supply) * 0.001)) {
        setError("DividendsMaxError", true)
      } else {
        setError("DividendsMaxError", false)
      }
      if (e.target.value && BabyNer.Supply && Number(e.target.value) > (Number(BabyNer.Supply) * 0.001)) {
        setError("DividendsMaxError", true)
      } else if (e.target.value && (BabyNer.Supply === '' || BabyNer.Supply === undefined)) {
        setError("DividendsMaxError", true)
      } else {
        setError("DividendsMaxError", false)
      }

    }
  };
  const RewardFeeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("RewardFeeBlankError", true)
      } else {
        setError("RewardFeeBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 0.01) {
        setError("RewardFeeMinError", true)
      } else {
        setError("RewardFeeMinError", false)
      }
      if (e.target.value && BabyNer.LiquidityFee && BabyNer.MarketingFee) {
        if (Number(e.target.value) + Number(BabyNer.LiquidityFee) + Number(BabyNer.MarketingFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const LiquidityFeeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("LiquidityFeeBlankError", true)
      } else {
        setError("LiquidityFeeBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 0.01) {
        setError("LiquidityFeeMinError", true)
      } else {
        setError("LiquidityFeeMinError", false)
      }
      if (e.target.value && BabyNer.RewardFee && BabyNer.MarketingFee) {
        if (Number(e.target.value) + Number(BabyNer.RewardFee) + Number(BabyNer.MarketingFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const MarketingFeeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("MarketingFeeBlankError", true)
      } else {
        setError("MarketingFeeBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 0.01) {
        setError("MarketingFeeMinError", true)
      } else {
        setError("MarketingFeeMinError", false)
      }
      if (e.target.value && BabyNer.RewardFee && BabyNer.LiquidityFee) {
        if (Number(e.target.value) + Number(BabyNer.RewardFee) + Number(BabyNer.LiquidityFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const WalletBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("WalletBlankError", true)
      } else {
        setError("WalletBlankError", false)
      }
      if (!isAddress(e.target.value) && e.target.value) {
        setError("WalletInvalidError", true)
      } else {
        setError("WalletInvalidError", false)
      }
    }
  };
  const getCreateBabyTokenFlatFee = async () => {
    const BabyTokenFacctoryContract = InstancedContract(
      Constan[3].Address,
      Constan[3].Condebi
    ) as any;
    const flatFee = await BabyTokenFacctoryContract.flatFee();
    setFlatFeeShow(FormatUnitsConver(flatFee.toString(), 18))
  }
  useEffect(() => { }, [flatFeeShow]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        getCreateBabyTokenFlatFee();
      }
    }
  }, []);
  return (
    <div className="StandardToken">
      <div className={styles.tulieng}>
        <div className={styles.createfee}>{`${t("Token creation fee:")}`} {flatFeeShow || 0} BNB</div>
        <div className={styles.require}>{`${t("Name")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder={`${t("Ex: Ethereum")}`}
          className={styles.addrInput}
          value={BabyNer.Name as string}
          style={{ borderColor: babyError.NameBlankError || babyError.NameCharactersError ? '#f14668' : '' }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            NameValueChange(e);
          }}
          onBlur={(e) => {
            NameBlurChange(e);
          }}
        />
      </div>
      {babyError.NameBlankError ? <InputError title="Name cannot be blank" /> : ''}
      {babyError.NameCharactersError ? <InputError title="Name must be at least 2 characters" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Symbol")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder={`${t("Ex: ETH")}`}
          className={styles.addrInput}
          value={BabyNer.Symbol as string}
          style={{ borderColor: babyError.SymbolBlankError || babyError.SymbolCharactersError ? '#f14668' : '' }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            SymbolValueChange(e);
          }}
          onBlur={(e) => {
            SymbolBlurChange(e);
          }}
        />
      </div>
      {babyError.SymbolBlankError ? <InputError title="Symbol cannot be blank" /> : ''}
      {babyError.SymbolCharactersError ? <InputError title="Symbol must be at least 2 characters" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Total supply")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder="Ex: 100000000000"
          className={styles.addrInput}
          value={BabyNer.Supply as string}
          style={{ borderColor: babyError.TotalSupplyBlankError || babyError.TotalSupplyAmountError ? '#f14668' : '' }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            SupplyValueChange(e);
          }}
          onBlur={(e) => {
            SupplyBlurChange(e);
          }}
        />
      </div>
      {babyError.TotalSupplyBlankError ? <InputError title="Total supply cannot be blank" /> : ''}
      {babyError.TotalSupplyAmountError ? <InputError title="Invalid total supply" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Router")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Form form={form}>
          <Form.Item name="请选择对应的" rules={[{ required: true }]} initialValue={`${t("Pancakeswap")}`}>
            <Select
              placeholder={`${t("Select Router Exchange")}`}
              onChange={(value: string) => {
                OnClickSelectCreate(value);
              }}
              options={RouterOptionItem}
            >
              {RouterOptionItem.map((item: OptionList) => (
                <Option key={item.key} value={item.value}>
                  {item.label}
                </Option>
              ))}
            </Select>
          </Form.Item>
        </Form>
      </div>
      <div className={styles.auoieng}>
        <div className={styles.tulieng} style={{ width: '50%' }}>
          <div className={styles.require}>{`${t("Reward token")}`}<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder={`${t("Ex: 0x....")}`}
            className={styles.addrInput}
            value={BabyNer.RewardToken as string}
            style={{ borderColor: babyError.RewardTokenBlankError || babyError.RewardTokenInvalidError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              RewardTokenValueChange(e);
            }}
            onBlur={(e) => {
              RewardTokenBlurChange(e);
            }}
          />
        </div>
        <div className={styles.auolItem}>
          <div className={styles.require}>
            {`${t("Minimum token balance for dividends")}`} <span style={{ color: "#f95192" }}> *</span>
          </div>
          <Input
            placeholder={`${t("Ex: 100000000000")}`}
            value={BabyNer.Dividends as string}
            style={{ borderColor: babyError.DividendsBlankError || babyError.DividendsMaxError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              DividendsValueChange(e);
            }}
            onBlur={(e) => {
              DividendsBlurChange(e);
            }}
            className={styles.addrInput}
          />
        </div>
      </div>
      <div className="sbuyeisn">
        <div className="sbuyeisnItem">
          {babyError.RewardTokenBlankError ? <InputError title="Reward token cannot be blank" /> : ''}
          {babyError.RewardTokenInvalidError ? <InputError title="Invalid reward token" /> : ''}
        </div>
        <div className="sbuyeisnItem">
          {babyError.DividendsBlankError ? <InputError title="MinimumTokenBalanceForDividends cannot be blank" /> : ''}
          {babyError.DividendsMaxError ? <InputError title="MinimumTokenBalanceForDividends must be less than or equal 0.1% total supply" /> : ''}
        </div>
      </div>
      <div className={styles.auoieng}>
        <div className={styles.auolItem}>
          <div className={styles.require}>{`${t("Token reward fee")}`} (%)<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder="0 - 100"
            className={styles.addrInput}
            value={BabyNer.RewardFee as string}
            style={{ borderColor: babyError.RewardFeeBlankError || babyError.RewardFeeMinError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              RewardFeeValueChange(e);
            }}
            onBlur={(e) => {
              RewardFeeBlurChange(e);
            }}
          />
        </div>
        <div className={styles.auolItem}>
          <div className={styles.require}>{`${t("Auto add liquidity")}`} (%) <span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder="0 - 100"
            className={styles.addrInput}
            value={BabyNer.LiquidityFee as string}
            style={{ borderColor: babyError.LiquidityFeeBlankError || babyError.LiquidityFeeMinError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              LiquidityFeeValueChange(e);
            }}
            onBlur={(e) => {
              LiquidityFeeBlurChange(e);
            }}
          />
        </div>
      </div>
      <div className="sbuyeisn">
        <div className="sbuyeisnItem">
          {babyError.RewardFeeBlankError ? <InputError title="Token reward fee cannot be blank" /> : ''}
          {babyError.RewardFeeMinError ? <InputError title="Token reward fee must be greater than or equal to 0.01" /> : ''}
        </div>
        <div className="sbuyeisnItem">
          {babyError.LiquidityFeeBlankError ? <InputError title="Auto add liquidity cannot be blank" /> : ''}
          {babyError.LiquidityFeeMinError ? <InputError title="Auto add liquidity must be greater than or equal to 0.01" /> : ''}
        </div>
      </div>
      <div className={styles.auoieng}>
        <div className={styles.auolItem} >
          <div className={styles.require}>{`${t("Marketing fee")}`} (%) <span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder="0 - 100"
            className={styles.addrInput}
            value={BabyNer.MarketingFee as string}
            style={{ borderColor: babyError.MarketingFeeBlankError || babyError.MarketingFeeMinError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              MarketingFeeValueChange(e);
            }}
            onBlur={(e) => {
              MarketingFeeBlurChange(e);
            }}
          />
        </div>
        <div className={styles.tulieng} style={{ width: '50%' }}>
          <div className={styles.require}>{`${t("Marketing wallet")}`} <span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder={`${t("Ex: 0x....")}`}
            className={styles.addrInput}
            value={BabyNer.Wallet as string}
            style={{ borderColor: babyError.WalletBlankError || babyError.WalletInvalidError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              WalletValueChange(e);
            }}
            onBlur={(e) => {
              WalletBlurChange(e);
            }}
          />
        </div>
      </div>
      <div className="sbuyeisn">
        <div className="sbuyeisnItem">
          {babyError.MarketingFeeBlankError ? <InputError title="Marketing fee cannot be blank" /> : ''}
          {babyError.MarketingFeeMinError ? <InputError title="Marketing fee must be greater than or equal to 0.01" /> : ''}
          {babyError.FeeOverError ? <InputError title="Total fee is over 25%" /> : ''}
        </div>
        <div className="sbuyeisnItem">
          {babyError.WalletBlankError ? <InputError title="Marketing wallet cannot be blank" /> : ''}
          {babyError.WalletInvalidError ? <InputError title="Address is invalid" /> : ''}
        </div>
      </div>
      <div className={styles.tulieng}>
        <Checkbox
          onChange={(e: CheckboxChangeEvent) => {
            setBabyNer((olddata: BabyTokenList) => {
              return {
                ...olddata,
                UseAntiBot: e.target.checked,
              };
            });
          }}
          checked={BabyNer.UseAntiBot as boolean}
          style={{ lineHeight: "32px" }}
        >
          {`${t("Implement Maya Anti-Bot System?")}`}
        </Checkbox>
      </div>
      {isCreate() ? <button
        onClick={() => {
          StandardCreateOnClikc();
        }}
        className={`nextbtn ${styles.nextbtn}`}
      >
        {loading ? <ButtonLoading /> : ''}{`${t("Create token")}`}
      </button> : <button
        style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
        className={`nextbtn ${styles.nextbtn}`}
      >
        {`${t("Create token")}`}
      </button>}
    </div>
  );
};

export default BabyToken;
