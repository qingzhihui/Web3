import { Suspense } from "react";
import "./App.css";
import Index1 from "./components/index";
import Index2 from "./components/index2";
import Index3 from "./components/index3";

import {
  EthereumClient,
  modalConnectors,
  walletConnectProvider,
} from "@web3modal/ethereum";
import { Web3Button, Web3Modal } from "@web3modal/react";
import { configureChains, createClient, WagmiConfig } from "wagmi";
import { arbitrum, mainnet, polygon, goerli } from "wagmi/chains";
function App(_props: any) {
  // const id = useId();

  const chains = [arbitrum, mainnet, polygon, goerli];
  const { provider } = configureChains(chains, [
    walletConnectProvider({ projectId: "b98a412bd29c5618fe10c37180fa6813" }),
  ]);
  const wagmiClient = createClient({
    autoConnect: true,
    connectors: modalConnectors({
      projectId: "b98a412bd29c5618fe10c37180fa6813",
      version: "2", // or "2"
      appName: "web3Modal",
      chains,
    }),
    provider,
  });
  const ethereumClient = new EthereumClient(wagmiClient, chains);

  return (
    <div className="App">
      {/* <form className="App">
        <label htmlFor={"username-" + id}>UserName</label>
        <input id={"username-" + id} />
        <label htmlFor={"password" + id}>Password</label>
        <input id={"password" + id} />
      </form> */}
      {/* <Index1 /> */}

      {/* <Suspense fallback={<h1>Loading...</h1>}>
        <Index2 />
      </Suspense> */}
      <WagmiConfig client={wagmiClient}>
        <Web3Button />
      </WagmiConfig>
      <Web3Modal
        projectId="b98a412bd29c5618fe10c37180fa6813"
        ethereumClient={ethereumClient}
      />
      {/* <Index3 /> */}
    </div>
  );
}

export default App;
