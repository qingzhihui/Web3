/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect } from "react";
import "./index.scss";
import { Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import {
  FormatUnitsConver,
  InstancedContract,
  TimestampToTime,
} from "../../hooks/config";
import {
  CycleConversion,
  CycleBpsConversion,
  RecordDataInterface,
  LockInfoProps,
} from "../../hooks/LockRecordInfo";
import { useHistory } from "react-router-dom";
import { CreatelockABI, CreatelockAddress } from "../../hooks/Createlock";
import { useTranslation, Trans } from "react-i18next";
const paginationProps = {
  showSizeChanger: true,
  showQuickJumper: true,
  pageSize: 6,
};

const LockRecordInfo: React.FC = (props: any) => {
  let history = useHistory();
  const { t } = useTranslation();
  const [LockRecordata, setLockRecorData] = useState([]);
  const [LockInfo, setLockInfo] = useState<LockInfoProps>({
    TokenList: {},
    amount: "",
  });

  const columns: ColumnsType<RecordDataInterface> = [
    {
      title: `${t("Wallet")}`,
      dataIndex: "Wallet",
      render: (text) => (
        <div>{text.substring(0, 4) + "..." + text.substring(38, 42)}</div>
      ),
    },
    {
      title: `${t("Amount")}`,
      dataIndex: "Amount",
    },
    {
      title: `${t("UnlockTime")}`,
      dataIndex: "UnlockTime",
    },
    {
      title: `${t("Cycle (minutes)")}`,
      dataIndex: "Cycle",
    },
    {
      title: `${t("Cycle_Release")}(%)`,
      dataIndex: "Cycle_Release",
    },
    {
      title: "TGE(%)",
      dataIndex: "TGE",
    },
    {
      title: `${t("Action")}`,
      key: "action",
      render: (_, record) => (
        <button
          className="view"
          onClick={() => {
            ActionViewOnClick(record);
          }}
        >
          {`${t("view")}`}
        </button>
      ),
    },
  ];
  const getLocksForTokenData = async (address: string, decimals: number) => {
    const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
    const totalLockCountForToken = await Contract.totalLockCountForToken(
      address
    );
    const getLocksForToken = await Contract.getLocksForToken(
      address,
      0,
      totalLockCountForToken.toString()
    );
    const RecordData: RecordDataInterface[] = [];
    getLocksForToken.map(async (item: any, index: number) => {
      RecordData.push({
        key: index,
        Wallet: item.owner,
        TokenID: item.id.toString(),
        Amount: FormatUnitsConver(item.amount.toString(), decimals),
        UnlockTime: TimestampToTime(item.tgeDate.toString()),
        Cycle: CycleConversion(item.cycle.toString()),
        Cycle_Release: CycleBpsConversion(item.cycleBps.toString()),
        TGE: CycleBpsConversion(item.tgeBps.toString()),
      });
    });
    setTimeout(() => {
      let _OwnedItem = JSON.parse(JSON.stringify(RecordData));
      setLockRecorData((a: any) => {
        return _OwnedItem.length === 0 ? a : _OwnedItem;
      });
    }, 500);
  };
  const ActionViewOnClick = (data: any) => {
    history.push({
      pathname: "/LockInfo",
      state: {
        TokenID: data.TokenID,
        TokenAddress: LockInfo.TokenList.addres as string,
        Wallet: data.Wallet,
        obj:data
      },
    });
  };
  useEffect(() => {
    if (props.location.state != undefined) {
      const { TokenList, amount } = props.location.state;
      getLocksForTokenData(TokenList.addres, TokenList.decimals);
      setLockInfo((LockInfoprevState: any) => {
        return (LockInfoprevState = { TokenList, amount });
      });
    }
  }, []);

  return (
    <div className="lock-info">
      <div className="Info">
        <div className="updatelock-tableItem updatalock-title">{`${t("Lock Info")}`}</div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Current Lock Amount")}`}</span>
            <span className="tableItem-name ">
              {LockInfo.amount as string} MNM{" "}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Current Values Lock")}`}</span>
            <span className="tableItem-name ">$0</span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Address")}`}</span>
            <span className="tableItem-name TokenAddress">
              {LockInfo.TokenList.addres as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Name")}`}</span>
            <span className="tableItem-name">
              {LockInfo.TokenList.name as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Symbol")}`}</span>
            <span className="tableItem-title">
              {LockInfo.TokenList.symbol as string}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Token Decimals")}`}</span>
            <span className="tableItem-title">
              {LockInfo.TokenList.decimals as number}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
      </div>

      <div className="Record">
        <div className="updatelock-tableItem updatalock-title">{`${t("Lock Record")}`}</div>
        <Table
          columns={columns}
          loading={LockRecordata.length === 0 ? true : false}
          dataSource={LockRecordata}
          size="middle"
          pagination={paginationProps}
        />
      </div>
    </div>
  );
};
export default LockRecordInfo;
