import React, { useEffect, useState } from "react";
import "./index.scss";
import { Select, Switch, Table, Modal, Input } from "antd";
import { ExchangeItme, TokenItmeOlen } from "../../state/TokenState";
import { OptionList } from "../../hooks/Token";
import {
  AntiBotAddress,
  AntiBotABI,
  RouterABI,
  statusDataProps,
  configListProps,
  tmpListProps,
} from "../../hooks/AntiBot";
import { FormatUnitsConver, InstancedContract } from "../../hooks/config";
import { useTranslation, Trans } from "react-i18next";
import { whitelistUsersData } from "../../hooks/antibotPon";

interface BotPonProps {
  BlacKDataOne?: any;
  BlacKDataTwo?: any;
}

const AntibotPon: React.FC = (props: any) => {
  const { t } = useTranslation();
  const [proAddress, setProAddress] = useState<string>("");
  const [createDisplay, seTcreateDisplay] = useState<number>(0);
  const [createDisplay1, seTcreateDisplay1] = useState<number>(0);
  const [configList, setConfigList] = useState<configListProps>({});
  const [statusData, setStatusData] = useState<statusDataProps>({});
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [isModalOpen2, setIsModalOpen2] = useState<boolean>(false);
  const [TextArea1, setTextArea1] = useState<string>("");
  const [TextArea2, setTextArea2] = useState<string>("");
  const [key, setkey] = useState<number>(0);
  const [BotPonData, setBotPonData] = useState<BotPonProps>({});
  const [feeAmountShow, setFeeAmountShow] = useState<string>("");

  const { TextArea } = Input;
  const showModalAdd = (key: number) => {
    setIsModalOpen(true);
    setkey(key);
  };
  const showModalRemove = (key: number) => {
    setIsModalOpen2(true);
    setkey(key);
  };

  const handleOk = async () => {
    var tmpArl = (document.querySelector("#test") as HTMLInputElement).value;
    const tmpList = tmpArl.split(/\r*\n/);
    const AntiBotContract = InstancedContract(AntiBotAddress, AntiBotABI) as any;
    const whitelistUsers = await AntiBotContract.whitelistUsers(
      proAddress,
      true,
      tmpList
    ) as any;
    await whitelistUsers.wait();
    setTextArea1("");
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const handleOk2 = async () => {
    var tmpArl = (document.querySelector("#test2") as HTMLInputElement).value;
    const tmpList = tmpArl.split(/\r*\n/);
    const AntiBotContract = InstancedContract(AntiBotAddress, AntiBotABI) as any;
    const whitelistUsers = await AntiBotContract.whitelistUsers(
      proAddress,
      false,
      tmpList
    );
    await whitelistUsers.wait();
    setTextArea2("");
    setIsModalOpen2(false);
  };

  const handleCancel2 = () => {
    setIsModalOpen2(false);
  };

  const transfeRonChange = (checked: boolean) => {
    setConfigList((olddata: any) => {
      return {
        ...olddata,
        transfer: checked,
      };
    });
  };
  const { Option } = Select;
  const OnClickSelectCreate = (standarEvent: string) => {
    ExchangeItme.filter((Opitem: OptionList) => {
      if (Opitem.value === standarEvent) {
        seTcreateDisplay(Opitem.key);
        return Opitem;
      }
    });
    setConfigList((olddata: any) => {
      return {
        ...olddata,
        Exchange: standarEvent,
      };
    });
  };
  const OnClickTokenItmeOlen = (standarEvent: string) => {
    TokenItmeOlen.filter((Opitem: OptionList) => {
      if (Opitem.value === standarEvent) {
        seTcreateDisplay1(Opitem.key);
        return Opitem;
      }
    });
    setConfigList((olddata: any) => {
      return {
        ...olddata,
        Token: standarEvent,
      };
    });
  };
  const columns = [
    {
      title: `${t("No")}`,
      dataIndex: "No",
    },
    {
      title: `${t("Address")}`,
      dataIndex: "Address",
    },
  ];
  const SaveconfigonClick = async () => {
    const AntiBotContract = InstancedContract(AntiBotAddress, AntiBotABI) as any;
    const { Exchange, Token, Trade, Block, seconds, Disable } = configList;
    const RouterContract = InstancedContract(Exchange, RouterABI) as any;
    const factory = await RouterContract.factory();
    await AntiBotContract.setConfig(
      proAddress,
      Token,
      Exchange,
      factory,
      Trade,
      Block,
      seconds,
      Disable
    );
  };
  const whitelistUsersBlacklistUsers = async (ToeknAddress: any) => {
    const whitelistBlacklistData = await whitelistUsersData(ToeknAddress);
    const getWhiteitme = whitelistBlacklistData[2].toString().split(",");
    const getBlackitem = whitelistBlacklistData[3].toString().split(",");
    const getWhiteListData: any = [];
    for (let index = 0; index < Number(whitelistBlacklistData[0]); index++) {
      getWhiteListData.push({
        key: index,
        No: index + 1,
        Address: getWhiteitme[index],
      });
    }
    const getBlackListData: any = [];
    for (let index = 0; index < Number(whitelistBlacklistData[1]); index++) {
      getBlackListData.push({
        key: index,
        No: index + 1,
        Address: getBlackitem[index],
      });
    }
    setBotPonData((olddata: BotPonProps) => {
      return {
        ...olddata,
        BlacKDataOne: getWhiteListData,
        BlacKDataTwo: getBlackListData,
      };
    });
    setStatusData((olddata: any) => {
      return (olddata = whitelistBlacklistData[4]);
    });
  };

  const TextAreaonChangeAdd = (e: any) => {
    setTextArea1(e.target.value);
  };
  const getFeeAmount = async () => {
    const AntiBotContract = InstancedContract(AntiBotAddress, AntiBotABI) as any;
    const fundAmount = await AntiBotContract.fundAmount();
    setFeeAmountShow(FormatUnitsConver(fundAmount.toString(), 18))
  }
  const TextAreaonChangeRemove = (e: any) => {
    setTextArea2(e.target.value);
  };
  useEffect(() => { }, [BotPonData, feeAmountShow]);
  useEffect(() => {
    if (props.location.state != undefined) {
      const { inputValue } = props.location.state;
      setProAddress((state: string) => {
        return (state = inputValue);
      });
      whitelistUsersBlacklistUsers(inputValue);
      getFeeAmount();
    }
  }, []);

  return (
    <div className="antibotPon">
      <div className="antibotPon_item">
        <div className="antibo_item_pon">
          <div className="antiboLinet">
            <div className="antTilein_nro1">
              <div className="antTilein">
                <div>{`${t("Enable Maya Anti-bot")}`}</div>
              </div>
              <div className="antTiNurl">
                <div>
                  <button>{`${t("Disable MayaAntiBot")}`}</button>
                </div>
                <div>
                  <button>{`${t("Enable MayaAntiBot")}`}</button>
                </div>
              </div>
              <div className="antTiNurl_fonrt">
                <div>{`${t("At first time enable, You need to pay")}`}{feeAmountShow || 0} BNB</div>
              </div>
            </div>
            <div className="antTilein_nro2">
              <div className="lein_nro">{`${t("Status")}`}</div>
              <div className="lein_nroPosme">
                <div className="lein_nroPosme_item">
                  <div>{`${t("Protect Status")}`}</div>
                  <div>
                    {" "}
                    {(statusData.ProteStatus as boolean)
                      ? `${t("Under protection")}`
                      : `${t("Not activate")}`}
                  </div>
                </div>
                <div className="lein_nroPosme_item">
                  <div>{`${t("Amount Limit")}`}</div>
                  <div>{statusData.AmountLimit as string}</div>
                </div>
                <div className="lein_nroPosme_item">
                  <div>{`${t("Time Limit")}`}</div>
                  <div>{statusData.TimeLimit as string}</div>
                </div>
                <div className="lein_nroPosme_item">
                  <div>{`${t("Blocks left to disable")}`}</div>
                  <div>{statusData.Blocksleft as string}</div>
                </div>
                <div className="lein_nroPosme_item">
                  <div>{`${t("Current Block")}`}</div>
                  <div>{statusData.CurreBlock as string}</div>
                </div>
              </div>
            </div>
          </div>
          <div className="antiboReks">
            <div className="antiboReks_tile">{`${t(
              "Maya Anti-Bot config"
            )}`}</div>
            <div className="antiboReks_Nrile">
              <div className="Exchange">
                <div className="Exchange_item">
                  <div className="Exchange_item_title">
                    {`${t("Select Router Exchange")}`}
                  </div>
                  <div className="SelectLoe">
                    <Select
                      placeholder={`${t("Select Router Exchange")}`}
                      onChange={(value: string) => {
                        OnClickSelectCreate(value);
                      }}
                      allowClear
                    >
                      {ExchangeItme.map((item: OptionList) => (
                        <Option key={item.key} value={item.value}>
                          {/* 不翻译 */}
                          {item.label}
                        </Option>
                      ))}
                    </Select>
                  </div>
                </div>
                <div className="Exchange_item">
                  <div className="Exchange_item_title">{`${t(
                    "Select Pair Token"
                  )}`}</div>
                  <div className="SelectLoe">
                    <Select
                      placeholder={`${t("Select Pair Token")}`}
                      onChange={(value: string) => {
                        OnClickTokenItmeOlen(value);
                      }}
                      allowClear
                    >
                      {TokenItmeOlen.map((item: OptionList) => (
                        <Option key={item.key} value={item.value}>
                          {item.label}
                        </Option>
                      ))}
                    </Select>
                  </div>
                </div>
              </div>
              <div className="Exchange2">
                <div className="Exchange_item">
                  <div className="Exchange_item_title">
                    {`${t("Amount Limit Per Trade")}`}*
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder={`${t("Ex: 1000")}`}
                      value={configList.Trade}
                      onChange={(e) => {
                        setConfigList((olddata: any) => {
                          return {
                            ...olddata,
                            Trade: e.target.value,
                          };
                        });
                      }}
                    />
                  </div>
                </div>
                <div className="Exchange_item">
                  <div className="Exchange_item_title">
                    {`${t("Amount to Be Per Block")}`}*
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder={`${t("Ex: 100")}`}
                      value={configList.Block}
                      onChange={(e) => {
                        setConfigList((olddata: any) => {
                          return {
                            ...olddata,
                            Block: e.target.value,
                          };
                        });
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="Exchange3">
                <div className="Exchange_item">
                  <div className="Exchange_item_title">
                    {`${t("Time Limit Per Trade (second)")}`} *
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder={`${t("Ex: 30")}`}
                      value={configList.seconds}
                      onChange={(e) => {
                        setConfigList((olddata: any) => {
                          return {
                            ...olddata,
                            seconds: e.target.value,
                          };
                        });
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="Exchange3">
                <div className="Exchange_item">
                  <div className="Exchange_item_title">
                    {`${t("Block Number to Disable Anti-Bot")}`} (
                    {`${t("Listing is Block #1")}`})*
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder={`${t("Ex: 50")}`}
                      value={configList.Disable}
                      onChange={(e) => {
                        setConfigList((olddata: any) => {
                          return {
                            ...olddata,
                            Disable: e.target.value,
                          };
                        });
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="Exchange4">
                <Switch
                  defaultChecked
                  onChange={transfeRonChange}
                  checked={configList.transfer}
                />
                <div className="Disabletile">
                  {`${t("Disable contract transfer")}`}?
                </div>
              </div>
              <div className="SaveButone">
                <button
                  onClick={() => {
                    SaveconfigonClick();
                  }}
                >
                  {`${t("Save config")}`}
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="TIbleise">
          <Table
            dataSource={BotPonData.BlacKDataOne}
            columns={columns}
            title={() => (
              <div className="TableNrio">
                <div>{`${t("Blacklist")}`}</div>
                <div className="TableNrio_button">
                  <div className="TableNrio_button_item">
                    <button
                      onClick={() => {
                        showModalAdd(1);
                      }}
                    >
                      {`${t("Add user to blacklist")}`}
                    </button>
                  </div>
                  <div onClick={() => { }} className="TableNrio_button_item">
                    <button
                      onClick={() => {
                        showModalRemove(1);
                      }}
                    >
                      {`${t("Remove user from blacklist")}`}
                    </button>
                  </div>
                </div>
              </div>
            )}
          />
        </div>
        <div className="TIbleise">
          <Table
            dataSource={BotPonData.BlacKDataTwo}
            columns={columns}
            title={() => (
              <div className="TableNrio">
                <div>{`${t("Blacklist")}`}</div>
                <div className="TableNrio_button">
                  <div className="TableNrio_button_item">
                    <button
                      onClick={() => {
                        showModalAdd(2);
                      }}
                    >
                      {`${t("Add user to blacklist")}`}
                    </button>
                  </div>
                  <div className="TableNrio_button_item">
                    <button
                      onClick={() => {
                        showModalRemove(2);
                      }}
                    >
                      {`${t("Remove user from blacklist")}`}
                    </button>
                  </div>
                </div>
              </div>
            )}
          />
        </div>
      </div>
      <Modal
        title={`${t("Remove addresses from blacklist")}`}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <div>
          {/* <div className="useTile">{`${t("User")}`}</div> */}
          <TextArea
            rows={4}
            id="test"
            autoSize={{ minRows: 10, maxRows: 6 }}
            placeholder={`${t(
              "Insert address: separate with breaks line.Ex: 0x34E7f6A4d0BB1fa7aFe548582c47Df337FC337E6 0xd8Ebc66f0E3D638156D6F5eFAe9f43B1eBc113B10x968136BB860D9534aF1563a7c7BdDa02B1A979C2"
            )}`}
            value={TextArea1}
            onChange={(e) => {
              TextAreaonChangeAdd(e);
            }}
          />
        </div>
      </Modal>
      <Modal
        title={`${t("Remove addresses from blacklist")}`}
        open={isModalOpen2}
        onOk={handleOk2}
        onCancel={handleCancel2}
      >
        <div>
          {/* <div className="useTile">User</div> */}
          <TextArea
            rows={4}
            id="test2"
            autoSize={{ minRows: 10, maxRows: 6 }}
            placeholder={`${t(
              "Insert address: separate with breaks line.Ex: 0x34E7f6A4d0BB1fa7aFe548582c47Df337FC337E6 0xd8Ebc66f0E3D638156D6F5eFAe9f43B1eBc113B1 0x968136BB860D9534aF1563a7c7BdDa02B1A979C2"
            )}`}
            value={TextArea2}
            onChange={(e) => {
              TextAreaonChangeRemove(e);
            }}
          />
        </div>
      </Modal>
    </div>
  );
};

export default AntibotPon;
