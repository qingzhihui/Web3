import React, { useState } from 'react'
import { btnActive , btnDefault} from './config'
import './index.css'

import { useTranslation, Trans } from "react-i18next";

interface stepInterface {
    step: number;
    titleOne?:string,
    descOne?:string,
    titleTwo?:string
}

const RoadmapPC:React.FC<stepInterface> = ({step,titleOne,descOne,titleTwo}) => {
    const { t } = useTranslation();
    return (
        <div className="rmapmob">
            <div className="bottombtnArea">
                <div className="bottomBtn"
                style={step === 1 ? btnActive : btnDefault}>1</div>
                <div className="bottomBtn"
                style={step === 2 ? btnActive : btnDefault}>2</div>
                <div className="bottomBtn"
                style={step === 3 ? btnActive : btnDefault}>3</div>
                <div className="bottomBtn"
                style={step === 4 ? btnActive : btnDefault}>4</div>
            </div>
            <div className="bottomdescArea">
                <span className="bottom-title">
                    { step === 1 && <>
                        { titleOne ? `${t(titleOne)}` : `${t("Before you start")}`}
                    </> }
                    { step === 2 && <>
                        { titleTwo ? `${t(titleTwo)}` : `${t("Private Sale")}`}
                    </> }
                    { step === 3 && `${t("Add Additional Info")}` }
                    { step === 4 && `${t("Finish")}` }
                </span>
                <span className="bottom-desc">
                    { step === 1 && <>
                        {descOne ? `${t(descOne)}` : `${t("Input your awesome title and choose the currency")}`}
                    </> }
                    { step === 2 && `${t("Enter the launchpad information that you want to raise , that should be enter all details about your presale")}` }
                    { step === 3 && `${t("Let people know who you are")}` }
                    { step === 4 && `${t("Review your information")}` }
                </span>
            </div>
        </div>
    )
}

export default RoadmapPC