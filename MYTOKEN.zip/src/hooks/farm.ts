import { BigNumber } from "ethers";
import { FARM_ABI, FARM_ADDR } from "../config/abi/farmContract";
import { PAIR_ABI } from "../config/abi/pancakepair";
import { WBENJson } from "../config/abi/wbenjson";
import PoolToken from "../config/Pool.json";
import {
  FormatUnitsConver,
  InstancedContract,
  TokenNameDecimals,
  allowance,
} from "./config";

const balanceOfConter = async (code: any, address: any) => {
  const LPContract: any = InstancedContract(code, WBENJson);
  const balanceOf = await LPContract.balanceOf(address);
  const decimals = await LPContract.decimals();
  const balanceShow = FormatUnitsConver(balanceOf, decimals);
  return {
    balanceOf: balanceOf.toString(),
    balanceShow: balanceShow,
  };
};
const userInfoConter = async (pid: any, address: any, code: any) => {
  const LPContract: any = InstancedContract(code, WBENJson);
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const userInfo = await farmContract.userInfo(pid, address);
  const decimals = await LPContract.decimals();
  return {
    StakedLP: userInfo.depositAmount.toString(),
    StakedLPShow: FormatUnitsConver(
      userInfo.depositAmount.toString(),
      decimals
    ),
  };
};
const pendingMintingRewardConter = async (pid: any, address: any) => {
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const rewardToken = await farmContract.rewardToken();
  const RewardData = await TokenNameDecimals(rewardToken);
  const pendingMintingReward = await farmContract.pendingMintingReward(
    pid,
    address
  );
  return {
    drawValu: FormatUnitsConver(
      pendingMintingReward.toString(),
      RewardData.decimals
    ),
  };
};
const getUserTotalPartnerRewardConter = async (address: any) => {
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const getUserTotalPartnerReward =
    await farmContract.getUserTotalPartnerReward(address);
  const getUserTotalNodeReward = await farmContract.getUserTotalNodeReward(
    address
  );
  return {
    getUserTotalPartnerReward: getUserTotalPartnerReward.toString(),
    getUserTotalNodeReward: getUserTotalNodeReward.toString(),
  };
};
const pendingDividendRewardConter = async (pid: any, address: any) => {
  const farmContract: any = InstancedContract(FARM_ADDR, FARM_ABI);
  const pendingDividendReward = await await farmContract.pendingDividendReward(
    pid,
    address
  );
  return {
    pendingDividendReward: pendingDividendReward.toString(),
  };
};

const allowanceValConter = async (code: any, address: any) => {
  const allowanceVal = await allowance(code, address);
  const MaxUint256: BigNumber = BigNumber.from(
    "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
  );
  if (allowanceVal.eq(MaxUint256)) {
    return {
      show: true,
    };
  } else {
    return {
      show: false,
    };
  }
};

const wagmiState = () => {
  const colleState = localStorage.getItem("wagmi.connected");
  if (colleState !== null && colleState !== undefined) {
    return true;
  } else {
    return false;
  }
};

const tokenConter = async (
  token1: any,
  token2: any,
  code: any,
  id: any,
  address: any
) => {
  const Contracter: any = await InstancedContract(FARM_ADDR, FARM_ABI);
  const ContractToken1: any = await InstancedContract(token1, WBENJson);
  const ContractToken2: any = await InstancedContract(token2, WBENJson);
  const PAIRContract: any = await InstancedContract(code, PAIR_ABI);
  const totalSupply = await PAIRContract.totalSupply();
  const bnbTotal1 = await ContractToken1.balanceOf(code);
  const decimals1 = await ContractToken1.decimals();
  const bnbTotal2 = await ContractToken2.balanceOf(code);
  const decimals2 = await ContractToken2.decimals();
  const lisne = await Contracter.userInfo(id, address);
  let holdRatio1 = Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
  let userBnb1 = Number(bnbTotal1) * holdRatio1;
  let nukse1 = userBnb1 / 10 ** decimals1;
  let holdRatio2 = Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
  let userBnb2 = Number(bnbTotal2) * holdRatio2;
  let nukse2 = userBnb2 / 10 ** decimals2;
  const t1 = new Date().valueOf();
  const beins =
    t1.toString().slice(0, 3) +
    "," +
    t1.toString().slice(3, 6) +
    "," +
    t1.toString().slice(6, 9);
  return {
    lPdataToken1: nukse1,
    lPdataToken2: nukse2,
    pron1: beins,
  };
};

const DleiserPoers = () => {
  const data: any = [];
  PoolToken.map((item: any) => {
    item.balance = "";
    item.balanceShow = "0.0";
    item.StakedLP = "";
    item.StakedLPShow = "0.0";
    item.WeTalk1 = "";
    item.WeTalk2 = "";
    item.drawValu = "";
    item.dividend = "";
    item.show = false;
    data.push(item);
  });
  return data;
};

export {
  tokenConter,
  balanceOfConter,
  userInfoConter,
  pendingMintingRewardConter,
  getUserTotalPartnerRewardConter,
  pendingDividendRewardConter,
  allowanceValConter,
  wagmiState,
  DleiserPoers,
};
