import React, { useEffect, useState } from "react";
import "./index.scss";
import { useHistory } from "react-router-dom";
import { useTranslation } from "react-i18next";
import k1 from "../../assets/image/k1.png";
import k2 from "../../assets/image/k2.png";
import k3 from "../../assets/image/k3.png";
import k4 from "../../assets/image/k4.png";
import k5 from "../../assets/image/k5.png";

import lo1 from "../../assets/image/lo1.png";
import lo2 from "../../assets/image/lo2.png";
import lo3 from "../../assets/image/lo3.png";
import lo4 from "../../assets/image/lo4.png";
import lo5 from "../../assets/image/lo5.png";

function Heues(props: any) {
  let history = useHistory();
  const { t } = useTranslation();
  const [urler, setUrler] = useState("");

  const MenuList = [
    {
      key: "/HOME",
      label: t("HOME"),
      image: lo1,
      imgurl: k1,
    },

    {
      key: "/FARM",
      label: t("FARM"),
      image: lo2,
      imgurl: k2,
    },
    {
      key: "/NFT",
      label: t("NFT"),
      image: lo3,
      imgurl: k4,
    },
    {
      key: "/MARKET",
      label: t("MARKET"),
      image: lo5,
      imgurl: k3,
    },
    {
      key: "/Inveta",
      label: t("Inveta"),
      image: lo3,
      imgurl: k4,
    },
  ];
  const Biens = (key: any) => {
    history.push(key);
  };
  useEffect(() => {
    setUrler(props.burl);
  }, [props]);
  return (
    <div className="heues">
      <div className="nrolse">
        {MenuList.map((item, index) => (
          <div
            className={`nritem ${urler == item.key ? "luser" : ""}`}
            key={index}
            onClick={() => Biens(item.key)}
          >
            <img src={urler == item.key ? item.imgurl : item.image} alt="" />
            <div>{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Heues;
