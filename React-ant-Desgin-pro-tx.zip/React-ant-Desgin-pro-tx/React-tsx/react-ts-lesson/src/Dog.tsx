import React, { forwardRef, useEffect, useRef, useState,Ref } from "react";
import "./Cat.css";
const MyIput = forwardRef((props, ref: Ref<HTMLInputElement>) => (
  <input ref={ref} />
));
function Dog() {
  const dogRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    console.log(dogRef);
    if (dogRef.current) {
      dogRef.current.className = "dog";
    }
    console.log(dogRef.current);
  }, []);
  return (
    <div>
      <button
        onClick={() => {
          inputRef.current?.focus();
        }}
      >
        click
      </button>
      <MyIput ref={inputRef} />
      <div ref={dogRef}>dog</div>
    </div>
  );
}

export default Dog;
