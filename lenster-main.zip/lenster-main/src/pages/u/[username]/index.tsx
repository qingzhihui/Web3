import ViewProfile from '@components/Profile'

export default ViewProfile
