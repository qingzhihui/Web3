<template>
  <div>
      <dl>
        <dt>A</dt>
        <dd>Andore</dd>
        <dd>Bapele</dd>
        <dd>Csioem</dd>
        <dd>Dslene</dd>
        <dd>Esloen</dd>
        <dd>FInoel</dd>
        <dd>Gloeng</dd>
        <dd>Tekuen</dd>
        <dd>Psoine</dd>
      </dl>
      <dl>
        <dt>B</dt>
        <dd>Andore</dd>
        <dd>Bapele</dd>
        <dd>Csioem</dd>
        <dd>Dslene</dd>
        <dd>Esloen</dd>
        <dd>FInoel</dd>
        <dd>Gloeng</dd>
        <dd>Tekuen</dd>
        <dd>Psoine</dd>
      </dl>
      <dl>
        <dt>C</dt>
        <dd>Andore</dd>
        <dd>Bapele</dd>
        <dd>Csioem</dd>
        <dd>Dslene</dd>
        <dd>Esloen</dd>
        <dd>FInoel</dd>
        <dd>Gloeng</dd>
        <dd>Tekuen</dd>
        <dd>Psoine</dd>
      </dl>
  </div>
</template>

<script setup>

</script>

<style>
dt {
  background: #cccccc;
  position: sticky;
  top: 0;
  padding: 10px;
}
dd{
  padding: 10px;
  border: 1px solid #000;
}
dl{
  border: 1px solid red;
}

</style>
