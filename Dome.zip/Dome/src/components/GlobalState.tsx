import React from "react";
import { Text, TextInput, Stack } from "@mantine/core";
import { useQuery } from "react-query";
import client from "@/hooks/client";
import useSWR from "swr";

// Query
// const useRQSGlobalState = (key: any, initialData: any) => [
//   useQuery("sharedText", () => initialData, {
//     enabled: false,
//     initialData,
//   }).data,
//   (value: any) => client.setQueryData(key, value),
// ];

// SWR
const useSWRGlobalState = (key: any, initialData: any) => {
  const { data, mutate } = useSWR(key, () => initialData);
  return [
    data ?? initialData,
    (value: any) => {
      mutate(value, {
        revalidate: false,
      });
    },
  ];
};

const StateEditor = () => {
  // const [value, setValue] = useRQSGlobalState("sharedText", "");

  const [value, setValue] = useSWRGlobalState("sharedText", "");
  return (
    <TextInput value={value} onChange={(evt) => setValue(evt.target.value)} />
  );
};

const StateViewer = () => {
  // const [value] = useRQSGlobalState("sharedText", "");
  const [value] = useSWRGlobalState("sharedText", "");
  return <Text>{value}</Text>;
};

const GlobalState = () => {
  return (
    <Stack>
      <StateEditor />
      <StateViewer />
    </Stack>
  );
};

export default GlobalState;
