import { ethers } from "ethers";
import { PAIR_ABI } from "../config/abi/pancakepair";
import { WBENJson } from "../config/abi/wbenjson";
import { DataType } from "../view/Token/tokenLock";
import { InstancedContract, ObtainAddress, TokenNameDecimals } from "./config";
import { CreatelockABI, CreatelockAddress } from "./Createlock";

const getCumulativeLpTokenLockInfo = async () => {
  const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
  const allLpTokenLockedCount = await (Contract as any).allLpTokenLockedCount();
  var TokenItem: DataType[] = [];
  if (Number(allLpTokenLockedCount.toString()) > 0) {
    const getCumulativeLpTokenLockInfo =
      await Contract.getCumulativeLpTokenLockInfo(
        0,
        allLpTokenLockedCount.toString()
      );
    getCumulativeLpTokenLockInfo.map(async (item: any, index: number) => {
      const TokenData = await TokenNameDecimals(item.token);
      const PancakePairList = await TokenSymbolPancakePair(item.token);
      TokenItem.push({
        key: index,
        token: {
          name: TokenData.name,
          addres: item.token,
          symbol: TokenData.symbol,
          decimals: TokenData.decimals,
          balanceOf: TokenData.balanceOf,
          token0: PancakePairList.token0,
          token1: PancakePairList.token1,
          factory: PancakePairList.factory,
        },
        amount: ethers.utils.formatUnits(
          item.amount.toString(),
          TokenData.decimals
        ),
      });
    });
  }
  return TokenItem;
};

const lpLocksForUserPancakePair = async () => {
  const Contract = InstancedContract(CreatelockAddress, CreatelockABI) as any;
  const { address } = await ObtainAddress() as any;
  if(address){
    const lpLocksForUser = await Contract.lpLocksForUser(address);
    const ForUserItem: DataType[] = [];
    lpLocksForUser.map(async (item: any, index: number) => {
      const TokenData = await TokenNameDecimals(item.token);
      const PancakePairList = await TokenSymbolPancakePair(item.token);
      ForUserItem.push({
        key: index,
        token: {
          name: TokenData.name,
          addres: item.token,
          symbol: TokenData.symbol,
          decimals: TokenData.decimals,
          balanceOf: TokenData.balanceOf,
          token0: PancakePairList.token0,
          token1: PancakePairList.token1,
          factory: PancakePairList.factory,
        },
        amount: ethers.utils.formatUnits(
          item.amount.toString(),
          TokenData.decimals
        ),
      });
    });
    return ForUserItem;
  } else {
    return
  }
  
};

const TokenSymbolPancakePair = async (address: string) => {
  const Contract = InstancedContract(address, PAIR_ABI) as any;
  const factory = await Contract.factory();
  // token0Address
  const token0Address = await Contract.token0();
  const token0Contract = InstancedContract(token0Address, WBENJson) as any;
  const token0Symbol = await token0Contract.symbol();
  const token0Name = await token0Contract.name();
  // token1Address
  const token1Address = await Contract.token1();
  const token1Contract = InstancedContract(token1Address, WBENJson) as any;
  const token1Symbol = await token1Contract.symbol();
  const token1Name = await token1Contract.name();
  return {
    factory: factory,
    token0: {
      token0Name,
      token0Address,
      token0Symbol,
    },
    token1: {
      token1Name,
      token1Address,
      token1Symbol,
    },
  };
};

export { getCumulativeLpTokenLockInfo, lpLocksForUserPancakePair };
