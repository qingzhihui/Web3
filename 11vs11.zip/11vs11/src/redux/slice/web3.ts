import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface Web3State {
  chainId: number | null;
  account: string | null;
  provider: any | null;
  instance: any | null;
  tokenBalance: any | null;
}

const initialState: Web3State = {
  chainId: null,
  account: null,
  provider: null,
  instance: null,
  tokenBalance: [],
};

export const web3Slice = createSlice({
  name: "web3",
  initialState,
  reducers: {
    changeChainId: (state, action: PayloadAction<Web3State["chainId"]>) => {
      state.chainId = action.payload;
    },
    changeAccount: (state, action: PayloadAction<Web3State["account"]>) => {
      state.account = action.payload;
    },
    changeProvider: (state, action: PayloadAction<Web3State["provider"]>) => {
      state.provider = action.payload;
    },
    changeInstance: (state, action: PayloadAction<Web3State["instance"]>) => {
      state.instance = action.payload;
    },

    changeTokenBalance: (
      state,
      action: PayloadAction<Web3State["tokenBalance"]>
    ) => {
      state.tokenBalance = action.payload;
    },
  },
});

export const {
  changeAccount,
  changeChainId,
  changeProvider,
  changeInstance,
  changeTokenBalance,
} = web3Slice.actions;

export default web3Slice.reducer;
