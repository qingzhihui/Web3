import React, { Component } from "react";
import Header from "../../components/Header";
import bint from "../../assets/bint2.png";
import fx1 from "../../assets/fx1.png";
import fx2 from "../../assets/fx2.png";
import t1 from "../../assets/t1.png";
import t2 from "../../assets/t2.png";
import t3 from "../../assets/t3.png";
import t4 from "../../assets/t4.png";
import lof from "../../assets/lof.png";
import ztil from "../../assets/ztl.png";
import "./index.scss";
import { Carousel } from "antd";
import Heues from "../../components/Heues";

export default class index extends Component<any, any> {
  card: React.RefObject<any>;
  constructor(props: any) {
    super(props);
    this.card = React.createRef();
    this.state = {
      sbie: false,
    };
  }
  onChange = (currentSlide: number) => {
    console.log(currentSlide);
  };
  Showlbi = () => {
    this.setState({
      sbie: !this.state.sbie,
    });
  };
  sbueHide = () => {
    this.setState({
      sbie: !this.state.sbie,
    });
  };
  render() {
    return (
      <div className="minsskeul">
        <div className="mintite">
          <Header />
        </div>
        <div className="snuelise">
          <div className="mindtbei">
            <Carousel afterChange={this.onChange} ref={this.card}>
              <div className="minditme">
                <div
                  className="nsielnimg"
                  onClick={() => {
                    this.Showlbi();
                  }}
                >
                  <img src={bint} alt="" />
                  <div className="tubiali">
                    <img src={t1} alt="" />
                  </div>
                  <div className="tubiali2">
                    <img src={t2} alt="" />
                  </div>
                  <div className="tubiali3">
                    <img src={t3} alt="" />
                  </div>
                  <div className="tubiali4">
                    <img src={t4} alt="" />
                  </div>
                </div>
              </div>
              <div className="minditme">
                <div className="nsielnimg">
                  <img src={bint} alt="" />
                  <div className="tubiali">
                    <img src={t1} alt="" />
                  </div>
                  <div className="tubiali2">
                    <img src={t2} alt="" />
                  </div>
                  <div className="tubiali3">
                    <img src={t3} alt="" />
                  </div>
                  <div className="tubiali4">
                    <img src={t4} alt="" />
                  </div>
                </div>
              </div>
              <div className="minditme">
                <div className="nsielnimg">
                  <img src={bint} alt="" />
                  <div className="tubiali">
                    <img src={t1} alt="" />
                  </div>
                  <div className="tubiali2">
                    <img src={t2} alt="" />
                  </div>
                  <div className="tubiali3">
                    <img src={t3} alt="" />
                  </div>
                  <div className="tubiali4">
                    <img src={t4} alt="" />
                  </div>
                </div>
              </div>
              <div className="minditme">
                <div className="nsielnimg">
                  <img src={bint} alt="" />
                  <div className="tubiali">
                    <img src={t1} alt="" />
                  </div>
                  <div className="tubiali2">
                    <img src={t2} alt="" />
                  </div>
                  <div className="tubiali3">
                    <img src={t3} alt="" />
                  </div>
                  <div className="tubiali4">
                    <img src={t4} alt="" />
                  </div>
                </div>
              </div>
            </Carousel>
            <div className="suAnsr">
              <div className="anniur1">
                <img
                  src={fx1}
                  alt=""
                  onClick={() => {
                    this.card.current.prev();
                  }}
                />
              </div>
              <div className="anniur2">
                <img
                  src={fx2}
                  alt=""
                  onClick={() => {
                    this.card.current.next();
                  }}
                />
              </div>
            </div>
          </div>
        </div>
        {this.state.sbie == true ? (
          <div className="bsielis">
            <div
              className="sbieksie"
              onClick={() => {
                this.sbueHide();
              }}
            ></div>
            <div className="sbiuemn">
              <div className="sbiuemn_titlei">
                <img src={lof} alt="" />
              </div>
              <div className="nbrolis">
                <img src={t4} alt="" />
              </div>
              <div>
                <div className="zbiezho">
                  <img src={ztil} alt="" />
                </div>
                <div className="nrubsi">
                  "Unbank" a select player to make he/she lose access to entire
                  networth for next 3 rounds (no purchase, no upgrade)
                </div>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
        <Heues burl="/Market" />
      </div>
    );
  }
}
