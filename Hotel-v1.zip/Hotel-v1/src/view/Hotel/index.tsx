import React from 'react'

const Hotel = () => {
  return (
    <div>
      Hotel
    </div>
  )
}

export default Hotel
