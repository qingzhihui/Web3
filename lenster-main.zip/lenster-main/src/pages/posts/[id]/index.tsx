import ViewPost from '@components/Post'

export default ViewPost
