import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Farm from "../view/Farm";

class IndexRouter extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/Deposit" component={Farm} />
          <Redirect from="/" to="/Deposit" />
        </Switch>
      </Router>
    );
  }
}

export default IndexRouter;
