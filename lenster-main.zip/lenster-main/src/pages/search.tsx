import Search from '@components/Search'

export default Search
