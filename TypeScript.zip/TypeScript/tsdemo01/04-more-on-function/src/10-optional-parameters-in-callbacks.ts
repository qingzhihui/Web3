// 给回调函数里的index的参数编写一个可选的属性
function myForEach(arr: any[], callback: (arg: any, index?: number) => void) {
  for (let i = 0; i < arr.length; i++) {
    // callback(arr[i],i);
    callback(arr[i]);
  }
}
// myForEach([1,2,3],(a)=>console.log(a))
// myForEach([1,3,4],(a,i)=>console.log(a,i))

myForEach([1, 2, 3], (a, i) => {
    // console.log(i.toFixed());
    
});
