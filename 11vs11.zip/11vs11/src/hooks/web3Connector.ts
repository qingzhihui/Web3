import { useEffect, useCallback, useRef, useState } from "react";
import Web3Modal, { connectors } from "web3modal";
import useWeb3SubscribeProvider from "./web3SubscribeProvider";
import { getChainData, switchToBNB } from "../helpers/utilities";
import { ethers } from "ethers";
import axios from "axios";
import { useDispatch } from "react-redux";
import BigNumber from "bignumber.js";
import {
  changeAccount,
  changeChainId,
  changeProvider,
  changeInstance,
  changeTokenBalance,
} from "../redux/slice/web3";

import { useQuery } from "./useQuery";

import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../redux/Contract/SmartContract";
import { useGetWeb3 } from "./useGetWeb3";
import { supportedChainsID, supportedChains } from "../helpers/chains";
import { List } from "echarts";

const useWeb3Connector = () => {
  let web3Modal = useRef<Web3Modal>();
  const dispatch = useDispatch();
  const { chainId } = useGetWeb3();
  const query = useQuery();
  const { subscribeProvider, resetAll } = useWeb3SubscribeProvider();
  const [Lidata, setLidata] = useState([]);
  const [address, setAddress] = useState("");

  const getNetwork = useCallback(() => {
    if (!chainId || !supportedChainsID.includes(chainId ?? 0)) return undefined;
    return getChainData(chainId).network;
  }, [chainId]);

  const getProviderOptions = useCallback(() => {
    // const infuraId = process.env.REACT_APP_INFURA_ID;
    // console.log("infuraId", infuraId);
    const providerOptions = {};
    return providerOptions;
  }, []);

  useEffect(() => {
    web3Modal.current = new Web3Modal({
      network: getNetwork(),
      cacheProvider: true,
      providerOptions: getProviderOptions(),
    });
  }, [getNetwork, getProviderOptions]);

  useEffect(() => {
    if (
      web3Modal?.current?.cachedProvider &&
      supportedChainsID.includes(chainId ?? 0)
    ) {
      // onConnect();
    }
  }, [web3Modal, chainId]);

  const onConnect = async () => {
    if (typeof window.ethereum !== "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const addr = await signer.getAddress();
      const chainId = await signer.getChainId();
      setAddress(addr);
      const instance = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      );
      const balance = await instance.balanceOf(addr);
      const bel = ethers.utils.formatEther(balance);
      const nftAmount = new BigNumber(bel)
          .times(new BigNumber(10).pow(18))
          .toString();
      let tokenBalance: any = [];
      for (let i = 0; i < Number(nftAmount); i++) {
        const tokenId = await instance.tokenOfOwnerByIndex(addr, i);
        const playerData = await instance.playerDatas(tokenId);
        const basetokenUri = await instance.tokenURI(tokenId.toString());
        await fetch(basetokenUri)
          .then((response) => response.json())
          .then((data) => {
            const uri = data.image.slice(7);
            if (playerData.unbox === true) {
              tokenBalance.push({
                tokenId: tokenId.toString(),
                image: uri,
                cName: data.name,
                rarty: data.attributes[0].value,
                occ: data.attributes[1].value,
                speed: data.attributes[2].value,
                shoot: data.attributes[3].value,
                guard: data.attributes[4].value,
                save: data.attributes[5].value,
                lucky: data.attributes[6].value,
                reveal: true,
              });
            } 
            else if(playerData.unbox === false) {
              tokenBalance.push({
                tokenId: tokenId.toString(),
                image: data.image,
                cName: data.name,
              });
            }
          });
      }

      setAddress(addr);
      dispatch(changeAccount(addr));
      dispatch(changeChainId(chainId));
      dispatch(changeProvider(provider));
      dispatch(changeInstance(instance));
      dispatch(changeTokenBalance(tokenBalance));
    }
  };

  const onDisconnect = async () => {
    web3Modal.current?.clearCachedProvider();
    resetAll();
  };
  return { onConnect, onDisconnect };
};

export default useWeb3Connector;
