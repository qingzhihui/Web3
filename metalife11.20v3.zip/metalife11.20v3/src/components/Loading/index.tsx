import React from "react";
import "./index.css";
import { ReloadOutlined } from "@ant-design/icons";
const Index = () => {
  return (
    <div className="Loading">
      <ReloadOutlined spin style={{ fontSize: "40px", color: "#ffff" }} />
    </div>
  );
};

export default Index;
