<script setup lang="ts">
import { RouterLink, RouterView, useRouter } from 'vue-router'
const router = useRouter();

</script>
<template>
  <header>
    <div class="header">
      <div class="HeaderViewItem" v-for="(item, index) in router.options.routes" :key="index">
        <RouterLink :to="item.path">{{ item.name }}</RouterLink>
      </div>
    </div>
  </header>
  <RouterView />
</template>
<style scoped></style>
