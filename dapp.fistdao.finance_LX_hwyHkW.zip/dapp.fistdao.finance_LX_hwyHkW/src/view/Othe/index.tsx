import React from "react";
import "./index.scss";
import Header from "../../components/Header";
import Heues from "../../components/Heues";
import jto from "../../assets/jtol.png";
import { useHistory } from "react-router-dom";

function Index() {
  let history = useHistory();
  const xnudr = () => {
    history.push("/Farm");
  };
  const tInudr = () => {
    history.push("/Teleg");
  };
  return (
    <div className="other">
      <Header />
      <div className="thosuer">
        <div className="iuteuer">
          <div
            className="iuteuer_item"
            onClick={() => {
              xnudr();
            }}
          >
            <div>农场</div>
            <div className="bsuetrin">
              <img src={jto} alt="" />
            </div>
          </div>
          <a
            className="iuteuer_item"
            href="https://cloud-data-s2-images.fistdao.finance/FISTDAO-GO/StakingFarmAudit-min.pdf"
            target="_blank"
          >
            <div>审计报告</div>
            <div className="bsuetrin">
              <img src={jto} alt="" />
            </div>
          </a>
          {/* <div className="iuteuer_item">
            <div>帮助中心</div>
            <div className="bsuetrin">
              <img src={jto} alt="" />
            </div>
          </div>
          <div className="iuteuer_item">
            <div>推特</div>
            <div className="bsuetrin">
              <img src={jto} alt="" />
            </div>
          </div> */}
          <a
            className="iuteuer_item"
            href="https://t.me/fistdao1"
            target="_blank"
          >
            <div>电报</div>
            <div className="bsuetrin">
              <img src={jto} alt="" />
            </div>
          </a>
        </div>
      </div>
      <Heues />
    </div>
  );
}

export default Index;
