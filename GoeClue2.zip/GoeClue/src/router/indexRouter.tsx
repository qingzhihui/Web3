import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Home from "../view/Home";
import Game from "../view/Game";
import Details from "../view/Details";
import Raod from "../view/Raod";
import Have from "../view/Have";
import IDO from "../view/IDO";
import Invita from "../view/Invita";
import Court from "../view/Court";
import GePlayer from "../view/GePlayer";
import Mint from '../view/Mint'
class indexRouter extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/Home" component={Home} />
          <Route path="/Game" component={Game} />
          <Route path="/Details" component={Details} />
          <Route path="/Raod" component={Raod} />
          <Route path="/GetPlayer" component={GePlayer} />
          <Route path="/Have" component={Have} />
          <Route path="/IDO" component={IDO} />
          <Route path="/Invita" component={Invita} />
          <Route path="/Court" component={Court} />
          <Route path="/Mint" component={Mint} />
          <Redirect from="/" to="/Game" />
        </Switch>
      </Router>
    );
  }
}

export default indexRouter;
