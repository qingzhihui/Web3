import { DigitalConversion } from "../hooks/config";
import MultiSenderABI from "../config/abi/Multisend.json";
const MultiSenderAddress = "0xe754E907b0eDecDf70f76F963907aBc5234F64a1";
export { MultiSenderAddress, MultiSenderABI };

export interface IAdmin {
  id: number;
}
export interface ILisnt {
  key: React.Key;
  address: string;
  binale: string;
}

const TextareaData = (data: any, decimalsCal: number) => {
  const WalletArray: string[] = [];
  const QuantityArray: string[] = [];
  let totalAmount: number = 0;
  data.map((item: string) => {
    WalletArray.push(item.split(",")[0]);
    totalAmount = totalAmount + Number(item.split(",")[1]);
    const Bluelen = DigitalConversion(item.split(",")[1], decimalsCal);
    QuantityArray.push(Bluelen);
  });
  totalAmount = parseFloat(totalAmount.toPrecision(12));
  let Nisler: ILisnt[] = [];
  data.map((item: string, index: number) => {
    Nisler.push({
      key: index,
      address: WalletArray[index],
      binale: QuantityArray[index],
    });
  });
  return {
    WalletArray,
    QuantityArray,
    totalAmount
  };
};

const TotalCalculation = (data: any) => {
  data.splice(0, 1);
  const jsonArrData = data.map((item: any, index: any) => {
    let jsonObj: ILisnt = {
      key: index,
      address: item[0],
      binale: item[1].toString(),
    };
    return jsonObj;
  });
  const QuantityArray: string[] = [];
  const TextareaList = jsonArrData.map((item: any) => {
    QuantityArray.push(item.binale);
    return `${item.address},${item.binale}\n`;
  });
  return {
    QuantityArray,
    TextareaList,
  };
};
const Quantitgroup = (data: any) => {
  const blueList: any = [];
  data.map((item: any) => {
    blueList.push(Number(item));
  });
  var sum = 0;
  for (var i = 0; i < blueList.length; i++) {
    sum += blueList[i];
  }
  return sum;
};

export { Quantitgroup, TextareaData, TotalCalculation };
