import SomebodyAirdropABI from "../config/abi/SomebodyAirdrop.json";
import AirDropABI from "../config/abi/AirDrop.json";
const SomebodyAirdropAddress = "0x614649015e6dF530Cafed7da92157AD2Ad7fffB5";

export interface AirDropProps {
  AirdropAddress?: string;
  TokenAddress?: string;
  Name?: string;
  Symbol?: string;
  TotalTokens?: string;
}
export interface getAlloDataProps {
  address?: string;
  amount?: string;
}
export interface StartProps {
  start?: number;
  amount?: string;
  unlockedAmount?: string;
}
export interface InputVlueProps {
  SetVesting?: string;
  TGEpercent?: string;
  Cyclepercent?: string;
}

export { SomebodyAirdropABI, SomebodyAirdropAddress, AirDropABI };
