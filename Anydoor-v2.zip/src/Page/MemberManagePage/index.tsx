import { Image, Input, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { DeleteOutlined, FormOutlined } from "@ant-design/icons";

// 会员管理界面
const MemberManagePage = () => {
  interface DataType {
    key: React.Key;
    ID: number; //会员id
    userImg: string; //用户头像
    userNick: string; //用户昵称
    userOpenid: string; //用户openid
    createTime: string; //注册时间
    membershipLevel: string; //会员等级
    paymentH: number; //付费会员天数
    integral: number; //积分
    remainder: string; //余额
  }
  const data: DataType[] = [
    {
      key: 1,
      ID: 118,
      userImg:
        "https://img1.baidu.com/it/u=1984993866,886139931&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1679763600&t=f96448b65970f307ebe451847a2a0315",
      userNick: "微信用户",
      userOpenid: "op8Xh4nFTJ-h0GDEFVAwWVEDSH8",
      createTime: "2023-01-01",
      membershipLevel: "注册会员V1",
      paymentH: 1,
      integral: 9999,
      remainder: "9.87",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "ID",
      dataIndex: "ID",
      width:80,
    },
    {
      title: "用户头像",
      width:80,
      render: (_, record) => (
        <Space size="middle">
            <Image width={60} height={50} src={record.userImg} />
        </Space>
    ),
    },
    {
      title: "用户昵称",
      dataIndex: "userNick",
      width:120,
    },
    {
      title: "用户openid",
      dataIndex: "userOpenid",
      width:280,
    },
    {
      title: "注册时间",
      width:120,
      dataIndex: "createTime",
    },
    {
      title: "会员等级",
      width:120,
      dataIndex: "membershipLevel",
      render: (_text, record) => (
        <Space size="middle">
            <span className="member_grade">{_text}</span>
        </Space>
      ),
    },  
    {
      title: "付费会员天数",
      width:120,
      dataIndex: "paymentH",
    },
    {
      title: "积分",
      // width:120,
      dataIndex: "integral",
    },
    {
      title: "余额",
      // width:120,
      dataIndex: "remainder",
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
            <span className="memberCursor" onClick={uploadus(record)}><FormOutlined /></span>
            <span className="memberCursor" onClick={deleteus(record)}><DeleteOutlined /></span>
        </Space>
      ),
    },
  ];
  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 修改
  const uploadus = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };

  return (
    <div className="member_Box">
      <div className="member_headerBox">
        <div className="member_headerBox_thread"></div>
        <div className="member_headerBox_Tit">
          &nbsp;&nbsp;&nbsp; 会员列表
        </div>
        <div className="member_Add_moban">
          <div className="member_usernameInpuit">
            <Input placeholder="请输入昵称" />
          </div>
          <div className="member_seekBtn" onClick={adminSearch}>
            查找
          </div>
        </div>
      </div>

      <div className="member_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default MemberManagePage;
