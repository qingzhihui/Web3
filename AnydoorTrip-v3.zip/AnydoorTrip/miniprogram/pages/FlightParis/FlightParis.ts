import { ParisData, TParisStatePerve, SheetData } from "../../config/config"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    FigtData: ParisData,
    NrolLentData: SheetData,
    show: false,
    activeKey: 0,
    radio: '1',
    RentState: 1,
    figitem: {}
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options: any) {
    console.log(JSON.parse(options.data));

    this.setData({
      figitem: JSON.parse(options.data)
    })
  },
  onClickLeft() {
    wx.navigateBack({
      delta: -1
    })
  },
  ConfirmOnclick() {
    wx.navigateTo({
      url: '../FlightFilin/FlightFilin'
    })
  },
  onChange(event: any) {
    this.setData({
      radio: event.detail,
    });
  },
  FlightDataOnClick(e: any) {
    const prlData = TParisStatePerve(ParisData, Number(e.currentTarget.id))
    this.setData({
      FigtData: prlData
    })
  },
  ActionSheet() {
    this.setData({ show: true });
  },
  NrolLentOnClick(e: any) {
    const LentData = TParisStatePerve(SheetData, Number(e.currentTarget.id))
    this.setData({
      NrolLentData: LentData,
      RentState: Number(e.currentTarget.id)
    })
  },
  NrolonClose() {
    this.setData({ show: false });
  },
  NrolonClner() {
    this.setData({ show: false });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})