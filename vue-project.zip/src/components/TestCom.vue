<!-- 这个是组件 -->
<template>
    <div>
        <h2> 你好-我是black-郭</h2>
        <!-- 子组件显示父组件的参数 -->
        <p>信息:{{ info }}</p>
        <p>{{ time }}</p>
        <!-- 子组件给父组件抛出事件 -->
        <button @click="hander1Click">新增</button>
        <button @click="hander2Click">删除</button>
    </div>
</template>
<script lang="ts" setup>
import { defineProps } from 'vue'
let $myemit = defineEmits(['myAdd', 'myDel'])
let hander1Click = (): void => {
    $myemit('myAdd', '新增的数据')
}
let hander2Click = (): void => {
    $myemit('myDel', '删除的数据')
}
defineProps({
    info: {
        type: String,
        default: '----'
    },
    time: {
        type: String,
        default: '0分钟'
    },
})
</script>