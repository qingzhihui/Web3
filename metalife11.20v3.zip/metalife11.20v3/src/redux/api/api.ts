import { Meta_ADDRESS, Meta_ABI } from "../Contract/MetaContract";
import { PAIR_ABI } from "../Contract/pancakepair";
import { wben_ABI } from "../Contract/wbenjson";
const Meta: any = { Meta_ADDRESS, Meta_ABI };
const Pair: any = { PAIR_ABI,wben_ABI };
export { Meta, Pair };
