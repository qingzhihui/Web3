import type { NextApiRequest, NextApiResponse } from "next";

interface Post {
  id: number;
  title: string;
}
export default function post(
  req: NextApiRequest,
  res: NextApiResponse<Post[]>
) {
  const postList: Post[] = [];
  for (let index = 1; index < 10; index++) {
    postList.push({
      id: index,
      title: "title" + index,
    });
  }
  res.status(200).json(postList);
}
