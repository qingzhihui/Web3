import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { decrement } from "../../redux/counterSlice";
import { rows } from "../../hooks/data";
import { columns } from "../../hooks/data";
import { TableHeader } from "../../hooks/types";
import Addero from "../Addero";
import styles from "./index.module.css";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";

const Counter = () => {
  const count = useSelector((state: any) => state.counter.TodoStore);

  const dispatch = useDispatch();
  return (
    <div className={styles.Counter}>
      <div className={styles.Counter_Tiles}>
        <div className={styles.Counter_Luidr}>
          <Addero />
        </div>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                {columns.map((item: TableHeader) => {
                  return (
                    <TableCell key={item.field} align="center">
                      {item.headerName}
                    </TableCell>
                  );
                })}
              </TableRow>
            </TableHead>
            <TableBody>
              {count.map((row: any) => (
                <TableRow key={row.id}>
                  <TableCell align="center">{row.id}</TableCell>
                  <TableCell align="center">{row.name}</TableCell>
                  <TableCell align="center">{row.first}</TableCell>
                  <TableCell align="center">{row.sage}</TableCell>
                  <TableCell align="center">
                    {row.state === true ? "在校" : "离校"}
                  </TableCell>
                  <TableCell align="center">
                    <Button variant="outlined" onClick={()=>{
                      dispatch(decrement(row.id))
                    }}>删除</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
    </div>
  );
};

export default Counter;
