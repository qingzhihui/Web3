import "./index.scss"
import {Swiper, SwiperSlide} from "swiper/react"
import {Navigation} from "swiper";
import "swiper/css"
import img from "./img/CardPackItem_50.png"
import img1 from "./img/CardPackItem_1.png"
import img2 from "./img/CardPackItem_2.png"
import img3 from "./img/CardPackItem_3.png"
import img4 from "./img/CardPackItem_4.png"
import img5 from "./img/CardPackItem_5.png"
import {useNavigate} from "react-router-dom";
import {useTranslation} from "react-i18next";

export default function Hd() {
  const navigate = useNavigate()
  const {t} = useTranslation()
  function payNow() {
    navigate("game/get-your-player")
  }
  return (
    <div id="hd">
      <img className="pre" src="/img/pre.png" alt=""/>
      <img className="next" src="/img/next.png" alt=""/>
      <Swiper
        modules={[Navigation]}
        navigation={{
          prevEl: "#hd .pre",
          nextEl: "#hd .next"
        }}
        slidesPerView={1}
        loop
      >
        <div className="hd">
          <SwiperSlide className="item">
            <img className="primary" src={img} alt=""/>
            <div className="pay" onClick={() => payNow()}>{t("home.PAY NOW")}</div>
          </SwiperSlide>
          <SwiperSlide className="item">
            <img className="primary" src={img} alt=""/>
            <div className="pay" onClick={() => payNow()}>{t("home.PAY NOW")}</div>
          </SwiperSlide>
          <SwiperSlide className="item">
            <img className="primary" src={img} alt=""/>
            <div className="pay" onClick={() => payNow()}>{t("home.PAY NOW")}</div>
          </SwiperSlide>
          <SwiperSlide className="item">
            <img className="primary" src={img} alt=""/>
            <div className="pay" onClick={() => payNow()}>{t("home.PAY NOW")}</div>
          </SwiperSlide>
          <SwiperSlide className="item">
            <img className="primary" src={img} alt=""/>
            <div className="pay" onClick={() => payNow()}>{t("home.PAY NOW")}</div>
          </SwiperSlide>
        </div>
      </Swiper>
    </div>
  )
}