interface Points {
  x: number;
  y: number;
}
function printCoord3(pt: Points) {}
printCoord3({
  x: 100,
  y: 200,
});

// 接口扩展类型别名
// interface Animal {
//   name: string;
// }
// interface Bear extends Animal {
//   honey: boolean;
// }
// const bear: Bear = {
//   name: "winie",
//   honey: true,
// };

// console.log(bear.name)
// console.log(bear.honey)

// 类型别名type扩展（交叉扩展）
// type Animal = {
//   name: string;
// };
// type Bear = Animal & {
//   honey: boolean;
// };

// const bear: Bear = {
//   name: "winie",
//   honey: true,
// };

// console.log(bear.name)
// console.log(bear.honey)

// 接口向现有的类型中添加字段
// interface MyWindow {
//   count: number;
// }
// interface MyWindow {
//   title: string;
// }

// const w: MyWindow = {
//     count: 100,
//     title:'hello ts'
// }


// 类型别名type向现有的类型中添加字段
// 类型别名type创建后就不能进行扩展或者是不能通过同一个类型名称去进行扩展
// type MyWindow = {
//   count: number;
// }
// type MyWindow = {
//   title: string;
// }