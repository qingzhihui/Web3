import React, { useEffect, useState } from "react";
import "./index.scss";
import { EditOutlined, KeyOutlined } from "@ant-design/icons";
import { Progress, Input, Modal, Radio, Table, Statistic, Alert } from "antd";
import type { RadioChangeEvent } from "antd";
import { useHistory, useLocation } from "react-router-dom";
import ButtonLoading from "../../components/ButtonLoading";
import { AirDropABI } from "../../hooks/SomebodyAirdrop";
import { ethers } from "ethers";
import {
  DigitalConversion,
  FormatUnitsConver,
  InstancedContract,
  TokenNameDecimals,
} from "../../hooks/config";
import { TextareaData } from "../../hooks/MultiSender";
import {
  ContributorsProps,
  getAlloDataProps,
  PrivateSaleABI,
  PrivateSalePropsType,
  StartProps,
  StatusProps,
  vluesProps,
} from "../../hooks/PrivateSale";
import { useTranslation, Trans } from "react-i18next";
import { WBENJson } from "../../config/abi/wbenjson";
// import ButtonLoading from '../../components/ButtonLoading'
const { Countdown } = Statistic;
declare const window: Window & { ethereum: any };

const PrivateSaleCurrency: React.FC = (props: any) => {
  const { t } = useTranslation();
  let history = useHistory();
  const [data, setData] = useState<PrivateSalePropsType>({});
  const [TextArea1, setTextArea1] = useState<string>("");
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [Somedata, setSomedata] = useState<getAlloDataProps[]>([]);
  const [Allocation, setAllocation] = useState<StartProps>({});
  const [isModalOpenSetting, setisModalOpenSetting] = useState(false);
  const { TextArea } = Input;
  const [datePicker, setDatePicker] = useState<string>("");
  const [RadioValue, setRadioValue] = useState<number>(0);
  const [AddRemoleJudge, setAddRemoleJudge] = useState<string>("");
  const [TokenAddress, setTokenAddress] = useState<string>("");
  const [AmountValue, setAmountValue] = useState<string>("");
  const [maxInve, setMaxInve] = useState<string>("");
  const [privateSale, setPrivateSale] = useState<boolean>(false);
  const [wLUserCount, setWLUserCount] = useState<string>("");
  const [joinInfosState, setJoinInfosState] = useState(false);
  const [isModalContributors, setisModalContributors] =
    useState<boolean>(false);
  const [ContributorsData, setContributorsData] = useState<ContributorsProps[]>(
    []
  );
  const [settimeloading, setTimeLoading] = useState<boolean>(false)
  const [UserClaimAble, setUserClaimAble] = useState("");
  const { state } = useLocation<any>();
  const [StatusData, setStatusData] = useState<StatusProps>({});
  const [valueDate, setvalueDate] = useState<boolean>(false);
  const [vluesList, setvluesList] = useState<vluesProps>({});
  const [BnBShow, setBnBShow] = useState(true);
  const [cancel, setCancel] = useState(false);
  const [SaleType, setSaleType] = useState(0);
  const [buywithloading, setBuyWithLoading] = useState<boolean>(false);
  const [finalizeloading, setFinalizeLoading] = useState<boolean>(false);
  const [cancelpoolloading, setCancelPoolLoading] = useState<boolean>(false);
  const [claimloading, setClaimLoading] = useState<boolean>(false);
  const [investInfosPros, setinvestInfosPros] = useState("");
  const [Contributors, setContributors] = useState(false);
  const [ownerState, setOwnerState] = useState(false);
  const [FinalizeState, setFinalizeState] = useState(false);
  const [emergencyState, setEmergencyState] = useState(false);
  const [endTimeState, setendTimeState] = useState(false);
  const [disablewhiteloading, setDisableWhiteLoading] = useState<boolean>(false)
  const [currencySymbolShow, setCurrencySymbolShow] = useState("");
  // 现在的时间戳 数字类型 毫秒
  const date = Date.now();
  const SomebodyAirdropDataShow = async (data: any) => {
    const PrivateSaleConstaer = InstancedContract(data.address, PrivateSaleABI) as any;
    setData((dataState: PrivateSalePropsType) => {
      return (dataState = data);
    });
    const owner = await PrivateSaleConstaer.owner();
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    if (owner === address) {
      setOwnerState(true);
    } else {
      setOwnerState(false);
    }
    const whitelistPool = await PrivateSaleConstaer.privateSaleType();
    const startTime = await PrivateSaleConstaer.startTime();
    const checkIsWhitelisted = await PrivateSaleConstaer.checkIsWhitelisted(
      address
    );
    const clasate = await PrivateSaleConstaer.privateSaleState();
    const currency = await PrivateSaleConstaer.currency();
    let currencyDecimals = "18";
    let currencySymbol = "BNB";
    if (currency.toString() !== "0x0000000000000000000000000000000000000000") {
      const currencyContract = InstancedContract(currency, WBENJson) as any;
      currencyDecimals = await currencyContract.decimals();
      currencySymbol = await currencyContract.symbol();
    }
    setCurrencySymbolShow(currencySymbol);
    const unlockedAmount = await PrivateSaleConstaer.unlockedAmount();
    const raisedAmount = await PrivateSaleConstaer.raisedAmount();
    if (
      Number(whitelistPool.toString()) === 0 &&
      Number(startTime.toString()) * 1000 < date
    ) {
      setBnBShow(true);
    } else if (
      Number(whitelistPool.toString()) === 1 &&
      checkIsWhitelisted &&
      Number(startTime.toString()) * 1000 < date
    ) {
      setBnBShow(true);
    } else if (
      Number(whitelistPool.toString()) === 2 &&
      Number(startTime.toString()) * 1000 < date
    ) {
      setBnBShow(true);
    }

    if (
      Number(clasate.toString()) === 3 &&
      Number(FormatUnitsConver(unlockedAmount.toString(), currencyDecimals)) ==
      Number(FormatUnitsConver(raisedAmount.toString(), currencyDecimals))
    ) {
      setCancel(true);
    } else {
      setCancel(false);
    }
    const hardCap = await PrivateSaleConstaer.hardCap();
    const endTime = await PrivateSaleConstaer.endTime();
    const allInvestorCount = await PrivateSaleConstaer.allInvestorCount();
    if (Number(allInvestorCount.toString()) > 0) {
      setContributors(true);
    } else {
      setContributors(false);
    }
    if (
      (Number(clasate.toString()) === 1 &&
        endTime < Date &&
        Number(raisedAmount.toString()) < Number(hardCap.toString())) ||
      Number(clasate.toString()) === 2 ||
      Number(clasate.toString()) === 3
    ) {
      setFinalizeState(true);
    } else {
      setFinalizeState(false);
    }

    if (Number(whitelistPool.toString()) === 0) {
      setRadioValue(1);
      setSaleType(1);
    } else if (Number(whitelistPool.toString()) === 1) {
      setRadioValue(2);
      setSaleType(2);
    } else {
      setRadioValue(3);
      setSaleType(3);
    }
    const joinInfos = await PrivateSaleConstaer.investInfos(address);
    if (
      Number(joinInfos.totalInvestment.toString()) > 0 &&
      Number(clasate.toString()) === 1
    ) {
      setEmergencyState(true);
    } else if (
      Number(joinInfos.totalInvestment.toString()) > 0 &&
      Number(clasate.toString()) === 3
    ) {
      setJoinInfosState(true);
    } else {
      setEmergencyState(false);
      setJoinInfosState(false);
    }

    if (
      Number(clasate.toString()) === 1 &&
      Number(endTime.toString()) < date
    ) {
      setendTimeState(false);
    } else if (Number(raisedAmount.toString()) == Number(hardCap.toString())) {
      setendTimeState(false);
    } else if (Number(clasate.toString()) === 3) {
      setendTimeState(false);
    } else {
      setendTimeState(true);
    }
    const joinInfo = await PrivateSaleConstaer.investInfos(address);
    const withdrawableTokens = joinInfo.totalInvestment.toString();
    setUserClaimAble(withdrawableTokens);

    const allWLUserCount = await PrivateSaleConstaer.allWLUserCount();
    setWLUserCount(allWLUserCount.toString());
    const getAlloData: getAlloDataProps[] = [];
    if (Number(allWLUserCount.toString()) > 0) {
      for (let index = 0; index < Number(allWLUserCount.toString()); index++) {
        const getWLUsers = await PrivateSaleConstaer.getWLUsers(
          0,
          allWLUserCount.toString()
        );
        getAlloData.push({
          address: getWLUsers[index],
        });
      }
    }
    const hardcap = await PrivateSaleConstaer.hardCap();
    setSomedata((AlloDataprevState: getAlloDataProps[]) => {
      return (AlloDataprevState = getAlloData);
    });
    setAllocation((AllocationprevState: any) => {
      return (AllocationprevState = {
        start: Number(FormatUnitsConver(raisedAmount.toString(), 18)),
        amount: Number(FormatUnitsConver(hardcap.toString(), 18)).toString(),
      });
    });
    const maxInvest = await PrivateSaleConstaer.maxInvest();
    setMaxInve(FormatUnitsConver(maxInvest.toString(), 18));
    const privateSaleType = await PrivateSaleConstaer.privateSaleType();
    if (
      Number(privateSaleType.toString()) === 1 &&
      checkIsWhitelisted.toString() === "false"
    ) {
      setPrivateSale(true);
    }
    const privateSaleState = await PrivateSaleConstaer.privateSaleState();
    const minInvest = await PrivateSaleConstaer.minInvest();
    const investInfos = await PrivateSaleConstaer.investInfos(address);
    setinvestInfosPros(investInfos.totalInvestment.toString());
    setStatusData((prevStateData: StatusProps) => {
      return (prevStateData = {
        Status: privateSaleState.toString(),
        MinimumBuy: FormatUnitsConver(minInvest.toString(), 18),
        MaximumBuy: FormatUnitsConver(maxInvest.toString(), 18),
        Totalibutors: allInvestorCount.toString(),
        Youpurchased: FormatUnitsConver(
          investInfos.totalInvestment.toString(),
          18
        ),
      });
    });
  };

  const SettingBuotneOnclick = (data: any) => {
    setisModalOpenSetting(true);
  };

  // 弹框1
  const handleOk = async () => {
    var tmpArl = (document.querySelector("#test") as HTMLInputElement).value;
    const tmpList = tmpArl.split(/\r*\n/);
    const { decimals } = await TokenNameDecimals(vluesList.Address);
    const { WalletArray } = TextareaData(tmpList, decimals);
    const PrivateSaleContract = InstancedContract(TokenAddress, PrivateSaleABI) as any;
    if (AddRemoleJudge === "Add") {
      const setWhitelistUsers = await PrivateSaleContract.setWhitelistUsers(
        WalletArray
      );
    } else {
      const removeWhitelistUsers =
        await PrivateSaleContract.removeWhitelistUsers(WalletArray);
    }
    setTextArea1("");
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
    setvalueDate(false);
  };
  // 弹框3
  const handleOkSetting = async () => {
    const AirDropConstaer = InstancedContract(
      data.address as string,
      AirDropABI
    ) as any;
    const startAirDrop = await AirDropConstaer.startAirDrop(
      String(parseInt(datePicker))
    );
    await startAirDrop.wait();
    setisModalOpenSetting(false);
  };
  const handleCancelSetting = () => {
    setisModalOpenSetting(false);
    setvalueDate(false);
  };

  const TextAreaonChangeAdd = (e: any) => {
    setTextArea1(e.target.value);
  };
  const RadioOnChange = (e: RadioChangeEvent) => {
    setRadioValue(e.target.value);
    if (Number(e.target.value) === 1) {
      ModalOpenSettingOnCLiuc(0);
    } else if (Number(e.target.value) === 2) {
      ModalOpenSettingOnCLiuc(1);
    } else {
      setvalueDate(true);
      setisModalOpenSetting(true);
    }
  };
  const ModalOpenSettingOnCLiuc = async (Num: any) => {
    setDisableWhiteLoading(true)
    setTimeLoading(true)
    try {
      const PrivateSaleConstaer = InstancedContract(
        data.address as string,
        PrivateSaleABI
      ) as any;
      const setWhitelistPool = await PrivateSaleConstaer.setWhitelistPool(
        Num,
        "0x0000000000000000000000000000000000000000",
        0
      );
      await setWhitelistPool.wait()
      if (Num === 1) {
        setSaleType(1);
      } else {
        setSaleType(2);
      }
      setDisableWhiteLoading(false)
      setTimeLoading(false)
    } catch (error) {
      setTimeLoading(false)
      setDisableWhiteLoading(false)
    }
  };
  const setIsModalOpenOnClick = (data: any) => {
    setIsModalOpen(true);
    if (data === "Add") {
      setAddRemoleJudge("Add");
    } else {
      setAddRemoleJudge("Remove");
    }
  };
  const MaxOnclick = () => {
    setAmountValue(maxInve);
  };
  const BuywithOnClick = async (data: any) => {
    try {
      setBuyWithLoading(true);
      const PrivateSaleConstaer = InstancedContract(
        data.address,
        PrivateSaleABI
      ) as any;
      const realValue = DigitalConversion(AmountValue, 18);
      const contribute = await PrivateSaleConstaer.contribute(realValue, {
        value: realValue,
      });
      await contribute.wait();
      setBuyWithLoading(false);
    } catch (error) {
      setBuyWithLoading(false);
    }
  };
  const ContributorsClick = async (list: any) => {
    const PrivateSaleConstaer = InstancedContract(list.address, PrivateSaleABI) as any;
    const allInvestorCount = await PrivateSaleConstaer.allInvestorCount();
    const Contributors: ContributorsProps[] = [];
    if (Number(allInvestorCount.toString()) > 0) {
      for (
        let index = 0;
        index < Number(allInvestorCount.toString());
        index++
      ) {
        const getInvestors = await PrivateSaleConstaer.getInvestors(
          0,
          allInvestorCount.toString()
        );
        Contributors.push({
          key: index,
          No: index + 1,
          Address: getInvestors[index].user,
          Amount: FormatUnitsConver(
            getInvestors[index].totalInvestment.toString(),
            18
          ),
        });
      }
      setContributorsData((ContributorsDataState: ContributorsProps[]) => {
        return (ContributorsDataState = Contributors);
      });
      setisModalContributors(true);
    } else {
      setisModalContributors(true);
    }
  };
  const FinalizeOnClick = async () => {
    try {
      setFinalizeLoading(true);
      const PrivateSaleConstaer = InstancedContract(
        data.address as string,
        PrivateSaleABI
      ) as any;
      const finalize = await PrivateSaleConstaer.finalize();
      await finalize.wait();
      setFinalizeLoading(false);
    } catch (error) {
      setFinalizeLoading(false);
    }
  };
  const handleOkContributors = async () => { };
  const ClaimFundOnclick = async () => {
    try {
      setClaimLoading(true);
      const PrivateSaleConstaer = InstancedContract(
        data.address as string,
        PrivateSaleABI
      ) as any;
      const claimFund = await PrivateSaleConstaer.claimFund();
      await claimFund.wait();
      setClaimLoading(false);
    } catch (error) {
      setClaimLoading(false);
    }
  };
  const CancelPoolOnClick = async () => {
    try {
      setCancelPoolLoading(true);
      const PrivateSaleConstaer = InstancedContract(
        data.address as string,
        PrivateSaleABI
      ) as any;
      const cancel = await PrivateSaleConstaer.cancel();
      await cancel.wait();
      setCancelPoolLoading(false);
    } catch (error) {
      setCancelPoolLoading(false);
    }
  };
  const handleCancelContributors = () => {
    setisModalContributors(false);
  };
  const setWhitelistPoolOnclick = async () => {
    const PrivateSaleConstaer = InstancedContract(
      data.address as string,
      PrivateSaleABI
    ) as any;
    const { decimals } = await TokenNameDecimals(vluesList.Address);
    const setWhitelistPool = await PrivateSaleConstaer.setWhitelistPool(
      2,
      vluesList.Address,
      DigitalConversion(vluesList.Amount, decimals)
    );
    await setWhitelistPool.wait();
    setSaleType(3);
  };
  const EmergencyOnClikc = async () => {
    const PrivateSaleConstaer = InstancedContract(
      data.address as string,
      PrivateSaleABI
    ) as any;
    const emergencyWithdrawContribute =
      await PrivateSaleConstaer.emergencyWithdrawContribute();
  };
  const columns = [
    {
      title: `${t("No")}`,
      dataIndex: "No",
    },
    {
      title: `${t("Address")}`,
      dataIndex: "Address",
    },
    {
      title: `${t("Amount")}`,
      dataIndex: "Amount",
    },
  ];
  const editUpdataOnclick = () => {
    history.push({
      pathname: "/CreateUpdata",
      state: {
        urlName: "PrivateSaleCurrency",
        editUpdata: data,
      },
    });
  };
  const emergencyWithdrawContributeOnClick = async (data: any) => {
    try {
      setBuyWithLoading(true);
      const PrivateSaleConstaer = InstancedContract(
        data.address as string,
        PrivateSaleABI
      ) as any;
      const emergencyWithdrawContribute =
        await PrivateSaleConstaer.emergencyWithdrawContribute();
      await emergencyWithdrawContribute.wait();
      setBuyWithLoading(false);
    } catch (error) {
      setBuyWithLoading(false);
    }
  };
  const ClaimOnClick = async () => {
    const PrivateSaleConstaer = InstancedContract(
      data.address as string,
      PrivateSaleABI
    ) as any;
    const withdrawContribute = await PrivateSaleConstaer.withdrawContribute();
  };
  useEffect(() => {
    console.log(data);
    console.log(TokenAddress);
    console.log(Allocation);
    console.log(ContributorsData);
  }, [data, TokenAddress, Allocation, ContributorsData, currencySymbolShow]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          if (state.data != undefined) {
            const { data } = props.location.state;
            SomebodyAirdropDataShow(data);
            setTokenAddress((paStast: string) => {
              return (paStast = data.address);
            });
          } else {
            const { editUpdata } = props.location.state;
            SomebodyAirdropDataShow(editUpdata);
            setTokenAddress((paStast: string) => {
              return (paStast = editUpdata.address);
            });
          }
        }
      }
    }

  }, []);
  return (
    <div className="PrivateSaleCurrency">
      <div className="Somebody_introduce">
        <div className="introduce_left">
          <div className="name_title">
            <div className="nameimgs">
              <div className="heaimgs">
                <img src={require("../../assets/image/Frame.png")} alt="" />
              </div>
              <div>
                <div className="name">{data.Title}</div>
                <div className="imgs">
                  <img src={require("../../assets/image/icon1.png")} alt="" />
                  <img src={require("../../assets/image/icon2.png")} alt="" />
                  <img src={require("../../assets/image/icon3.png")} alt="" />
                  <img src={require("../../assets/image/icon4.png")} alt="" />
                  <img src={require("../../assets/image/icon5.png")} alt="" />
                  <img src={require("../../assets/image/icon6.png")} alt="" />
                  <img src={require("../../assets/image/icon7.png")} alt="" />
                  <img src={require("../../assets/image/icon8.png")} alt="" />
                </div>
              </div>
            </div>
            <div className="keystxt">
              <div className="key">
                <KeyOutlined />
              </div>
              <div
                className="edit"
                onClick={() => {
                  editUpdataOnclick();
                }}
              >
                <EditOutlined style={{ color: "#f95192" }} />
              </div>
            </div>
            <div className="up">
              {(Number(data.start) as number) > date
                ? `${t("Upcoming")}`
                : StatusData.Status === "1" &&
                  Number(data.raisedAmount) < Number(data.hardCap) &&
                  Number(data.end) < date
                  ? `${t("Sale Ended")}`
                  : StatusData.Status === "2"
                    ? `${t("Sale Ended")}`
                    : StatusData.Status === "3"
                      ? `${t("Canceled")}`
                      : Number(data.raisedAmount) === Number(data.hardCap)
                        ? `${t("Fiiled")}`
                        : `${t("Sale Live")}`}
            </div>
          </div>
          <div className="txts">
            <div className="txtcount">
              <div className="titletxt">{`${t("Private Sale Address")}`}</div>
              <div className="date">{data.address as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Soft Cap")}`}</div>
              <div className="date">{Number(data.softCap as string)}{" "}{currencySymbolShow}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Hard Cap")}`}</div>
              <div className="dateus">{Number(data.hardCap as string)}{" "}{currencySymbolShow}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t(
                "Private Sale Start Time"
              )}`}</div>
              <div className="datet">{data.startString as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Private Sale End Time")}`}</div>
              <div className="datet">{data.endString as string}</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t(
                "First Release For Project"
              )}`}</div>
              <div className="datet">{data.tgeBps as string}%</div>
            </div>
            <div className="txtcount">
              <div className="titletxt">{`${t("Vesting For Project")}`}</div>
              <div className="datet">
                {`${t("each")}`} {data.cycle as string}{" "}
                {`${t("minutes release")}`} {data.cycleBps as string}%
              </div>
            </div>
          </div>
        </div>
        <div className="introduce_right">
          <div className="intitle">
            {`${t("Make sure the website is mayasale.finance!")}`}
          </div>
          <div className="nusepoeiDate">
            <div className="sale-title">
              {Number(data.start) > date ? `${t("Sale Starts In")}` : ""}
              {Number(data.start) < date && Number(data.end) > date
                ? `${t("Sale Ends In")}`
                : ""}
              {Number(data.end) < date ? `${t("Sale Ended")}` : ""}
            </div>
            {Number(data.end) > date ? (
              <>
                <div className="nusePone">
                  {Number(data.start) > date ? (
                    <Countdown
                      value={Number(data.start)}
                      format="DD:HH:mm:ss"
                    />
                  ) : (
                    ""
                  )}
                  {Number(data.start) < date && Number(data.end) > date ? (
                    <Countdown value={Number(data.end)} format="DD:HH:mm:ss" />
                  ) : (
                    ""
                  )}
                </div>
              </>
            ) : (
              ""
            )}
          </div>
          <div className="progress">
            <Progress
              percent={
                ((Number(Allocation.start) / Number(Allocation.amount)) *
                  100) as number
              }
              showInfo={false}
            />
            <div className="progress_itmel">
              <div>0 BNB</div>
              <div>{Allocation.amount as string} BNB</div>
            </div>
          </div>
          <div className="progress_uitle"></div>
          {endTimeState ? (
            <div className="progress_input">
              <div className="progress_input_titler">
                {`${t("Amount")}`} ({`${t("max")}`}: {maxInve} BNB)
              </div>
              <div className="progress_input_input">
                <Input
                  placeholder="0.0"
                  value={AmountValue}
                  onChange={(e) => {
                    setAmountValue(e.target.value);
                  }}
                />
                <button
                  onClick={() => {
                    MaxOnclick();
                  }}
                >
                  {`${t("Max")}`}
                </button>
              </div>
              {RadioValue === 3 ? (
                <div className="intitle">
                  {`${t("Hold at least 1000 USDT to buy Buy with BNB")}`}
                </div>
              ) : (
                ""
              )}
              {privateSale ? (
                <div className="progress_input_button">
                  <Alert message={`${t("You are not in whitellist")}`} banner />
                </div>
              ) : (
                ""
              )}
              {BnBShow ? (
                <button
                  className="flaseBuen1"
                  onClick={() => {
                    BuywithOnClick(data);
                  }}
                >
                  {buywithloading ? <ButtonLoading /> : ""}{" "}
                  {`${t("Buy with BNB")}`}
                </button>
              ) : (
                <button className="flaseBuen2" disabled>
                  {buywithloading ? <ButtonLoading /> : ""}{" "}
                  {`${t("Buy with BNB")}`}
                </button>
              )}
              <div className="pnsuein_button">
                {joinInfosState ? (
                  <button
                    onClick={() => {
                      ClaimOnClick();
                    }}
                  >
                    {buywithloading ? <ButtonLoading /> : ""}{" "}
                    {`${t("withdrawContribute")}`} ({investInfosPros})
                  </button>
                ) : (
                  ""
                )}
                {emergencyState ? (
                  <button
                    onClick={() => {
                      emergencyWithdrawContributeOnClick(data);
                    }}
                  >
                    {buywithloading ? <ButtonLoading /> : ""}{" "}
                    {`${t("emergencyWithdrawContribute")}`} ({UserClaimAble})
                  </button>
                ) : (
                  ""
                )}
              </div>
              {RadioValue === 3 ? (
                <div className="progress_input_button">
                  <button
                    onClick={() => {
                      EmergencyOnClikc();
                    }}
                  >
                    {`${t("Emergency Withdraw")}`}
                  </button>
                </div>
              ) : (
                ""
              )}
            </div>
          ) : (
            ""
          )}
        </div>
      </div>

      <div className="Somebody_allocations">

        <div className="allocations">
          <div className="altitle">
            {`${t("Whitelist")}`}[{wLUserCount}]
          </div>
          {Somedata.map((data: getAlloDataProps, index: number) => (
            <div className="datatext" key={index}>
              <div className="one">{data.address}</div>
              <div className="ddateus">{data.amount}</div>
            </div>
          ))}
        </div>

        <div className="ownerzone">
          <div className="ownerzone_item">
            <div className="ownerzone_item_nrio">
              <div>{`${t("Status")}`}</div>
              <div>
                {(Number(data.start) as number) > date
                  ? `${t("Upcoming")}`
                  : StatusData.Status === "1" &&
                    Number(data.raisedAmount) < Number(data.hardCap) &&
                    Number(data.end) < date
                    ? `${t("Sale Ended")}`
                    : StatusData.Status === "2"
                      ? `${t("Sale Ended")}`
                      : StatusData.Status === "3"
                        ? `${t("Canceled")}`
                        : Number(data.raisedAmount) === Number(data.hardCap)
                          ? `${t("Fiiled")}`
                          : `${t("Sale Live")}`}
              </div>
            </div>
            <div className="ownerzone_item_nrio">
              <div>{`${t("Minimum Buy")}`}</div>
              <div>{Number(StatusData.MinimumBuy as string)}{" "}{currencySymbolShow}</div>
            </div>
            <div className="ownerzone_item_nrio">
              <div>{`${t("Maximum Buy")}`}</div>
              <div>{Number(StatusData.MaximumBuy as string)}{" "}{currencySymbolShow}</div>
            </div>
            <div className="ownerzone_item_nrio">
              <div>{`${t("Total Contributors")}`}</div>
              <div>{StatusData.Totalibutors as string}</div>
            </div>
            <div className="ownerzone_item_nrio">
              <div>{`${t("You purchased")}`}</div>
              <div>{Number(StatusData.Youpurchased as string)}{" "}{currencySymbolShow}</div>
            </div>
          </div>
          {/*  */}
          {ownerState ? (
            <div className="ownerzone_item">
              <div className="owntitle">{`${t("Owner Zone")}`}</div>
              <div className="owntitle_title">
                <div>{`${t("Sale Type")}`}</div>
              </div>
              <div className="owntitle_Reios">
                <Radio.Group onChange={RadioOnChange} value={RadioValue}>
                  <Radio value={1}>{`${t("Public")}`}</Radio>
                  <Radio value={2}>{`${t("Whitelist")}`}</Radio>
                  <Radio value={3}>{`${t("Public Anti-Bot")}`}</Radio>
                </Radio.Group>
              </div>
              {SaleType === 1 ? (
                ""
              ) : SaleType === 2 ? (
                <div className="warmreminder">
                  <button
                    onClick={() => {
                      setIsModalOpenOnClick("Add");
                    }}
                  >
                    {`${t("Add users to whitelist")}`}
                  </button>
                  <button
                    onClick={() => {
                      setIsModalOpenOnClick("Remove");
                    }}
                  >
                    {`${t("Remove users from whitelist")}`}
                  </button>
                  <button
                    onClick={() => {
                      ModalOpenSettingOnCLiuc(0);
                    }}
                  >
                    {disablewhiteloading ? <><ButtonLoading></ButtonLoading>{" "} {`${t("Setting time to public")}`}</> : `${t("Setting time to public")}`}
                    {/* {`${t("Setting time to public")}`} */}

                  </button>
                  {/* <button
                    onClick={() => {
                      ModalOpenSettingOnCLiuc(0);
                    }}
                  >
                    { disablewhiteloading ? <><ButtonLoading></ButtonLoading>{" "} {`${t("Disable whitelist")}`}</> : `${t("Disable whitelist")}`}
                  </button> */}
                </div>
              ) : (
                <div className="SettingBuotne">
                  <button
                    onClick={() => {
                      SettingBuotneOnclick(data);
                    }}
                  >
                    Setting Token Holding
                  </button>
                </div>
              )}

              <div className="action">
                <div className="actitle">{`${t("Pool Actions")}`}</div>
                {Contributors ? (
                  <button
                    onClick={() => {
                      ContributorsClick(data);
                    }}
                  >
                    {`${t("List of Contributors")}`}
                  </button>
                ) : (
                  ""
                )}
                {FinalizeState ? (
                  <button className="Pusiner">
                    {" "}
                    {finalizeloading ? <ButtonLoading /> : ""}{" "}
                    {`${t("Finalize")}`}
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      FinalizeOnClick();
                    }}
                  >
                    {finalizeloading ? <ButtonLoading /> : ""}{" "}
                    {`${t("Finalize")}`}
                  </button>
                )}
                {cancel ? (
                  <button
                    onClick={() => {
                      ClaimFundOnclick();
                    }}
                  >
                    {claimloading ? <ButtonLoading /> : ""}
                    {`${t("Claim Fund")}`}
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      CancelPoolOnClick();
                    }}
                  >
                    {cancelpoolloading ? <><ButtonLoading /> </> : ""}{" "}
                    {`${t("Cancel Pool")}`}
                  </button>
                )}
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
      <Modal
        title={`${AddRemoleJudge === "Add"
          ? `${t("Add users to whitelist")}`
          : `${t("Remove addresses from whitelist")}`
          }`}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <div>
          <div className="useTile">User{`${t("")}`}</div>
          <TextArea
            rows={4}
            id="test"
            autoSize={{ minRows: 10, maxRows: 6 }}
            placeholder={`${t(
              "Insert address: separate with breaks line.Ex: 0x34E7f6A4d0BB1fa7aFe548582c47Df337FC337E6 0xd8Ebc66f0E3D638156D6F5eFAe9f43B1eBc113B1 0x968136BB860D9534aF1563a7c7BdDa02B1A979C2"
            )}`}
            value={TextArea1}
            onChange={(e: any) => {
              TextAreaonChangeAdd(e);
            }}
          />
        </div>
      </Modal>
      <Modal
        title={`${t("Setting time to start")}`}
        open={isModalOpenSetting}
        onOk={handleOkSetting}
        onCancel={handleCancelSetting}
        footer={null}
      >
        <div className="sbuiePloe">
          <div className="intitle">
            {`${t(
              "Public with holding condition With this option you can control who can contribute to the pool. OnlyUsers who hold a minimum amount of token you suggest would beable to contribute"
            )}`}
          </div>
          <div className="InonmTole_tile">{`${t("Token Address")}`}</div>
          <div className="InonmTole">
            <Input
              placeholder={`${t("Please input token address")}`}
              value={vluesList.Address}
              onChange={(e) => {
                setvluesList((olddata: vluesProps) => {
                  return {
                    ...olddata,
                    Address: e.target.value,
                  };
                });
              }}
            />
          </div>
          <div className="InonmTole_tile">{`${t("Min Holding Amount")}`}</div>
          <div className="InonmTole">
            <Input
              placeholder={`${t("Ex: 1000")}`}
              value={vluesList.Amount}
              onChange={(e) => {
                setvluesList((olddata: vluesProps) => {
                  return {
                    ...olddata,
                    Amount: e.target.value,
                  };
                });
              }}
            />
          </div>
          <div className="AmountOnser">
            <button
              onClick={() => {
                setWhitelistPoolOnclick();
              }}
            >
              Save Settings
            </button>
          </div>
        </div>
      </Modal>
      <Modal
        title={`${t("Contributors")}`}
        open={isModalContributors}
        onOk={handleOkContributors}
        onCancel={handleCancelContributors}
        footer={null}
      >
        <Table dataSource={ContributorsData} columns={columns} />
        <div>
          <button>导出</button>
        </div>
      </Modal>
    </div>
  );
};
export default PrivateSaleCurrency;
