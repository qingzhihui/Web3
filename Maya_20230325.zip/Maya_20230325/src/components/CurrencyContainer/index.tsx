/* eslint-disable no-lone-blocks */
import React, { useEffect, useState } from "react";

import "./index.css";
import "./mobile.css";
import { message } from "antd";
import { useHistory } from "react-router-dom";
import { useTranslation, Trans } from "react-i18next";
import {
  CurrencyContainerProps,
  CurrencyContainerPropsType,
} from "../../hooks/propsInterface";
import { Empty } from 'antd';
declare const window: Window & { ethereum: any };
const CurrencyContainer: React.FC<CurrencyContainerProps> = ({
  currencylist,
}) => {
  let history = useHistory();
  const { t } = useTranslation();
  const [curclist, setCurrList] = useState<CurrencyContainerPropsType[]>([]);
  const [messageApi, contextHolder] = message.useMessage();

  const collectTip = (content: string) => {
    messageApi.open({
      type: "success",
      content: content,
    });
  };

  const setCollectStatus = (id: number) => {
    let tklist: any = [];
    let tipContent: string;
    curclist.map((item: any, index: number) => {
      if (index === id) {
        if (item.isCollect) {
          tipContent = "取消收藏";
        } else {
          tipContent = "收藏成功";
        }
        item.isCollect = !item.isCollect;
        {
          collectTip(tipContent);
        }
      }
      tklist.push(item);
    });
    setTimeout(() => {
      setCurrList(tklist);
    }, 100);
  };
  const ViewAirdroponCLick = (item: any) => {
    history.push({
      pathname: "/SomebodyAirdrop",
      state: {
        data: item,
      },
    });
  };

  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        setCurrList((data: CurrencyContainerPropsType[]) => {
          return (data = currencylist);
        });
      }
    }
  }, [curclist, currencylist]);

  return (
    <div className="currencyDataArea">
      {contextHolder}
      {
        curclist.length > 0 ? <>
          {
            curclist.map((item: any, index: number) => (
              <div className="currencyDataItem" key={index}>
                <div className="currencyImageArea">
                  <div
                    className="collectRound"
                    onClick={() => {
                      setCollectStatus(index);
                    }}
                  >
                    <img
                      src={require(`../../assets/image/notCollect.png`)}
                      alt=""
                      className="collectLogo"
                      style={{
                        filter: item.isCollect
                          ? "sepia(1) saturate(4) hue-rotate(295deg)"
                          : "grayscale(100%)",
                      }}
                    />
                  </div>
                  <div className="catRound">
                    <img
                      src={require(`../../assets/image/airdrop-dataLogo.png`)}
                      alt=""
                      className="airdrop-bottomCat"
                    />
                  </div>
                  <img
                    src={require(`../../assets/image/airdrop-image01.png`)}
                    alt=""
                    className="currencyImage"
                  />
                </div>

                {/* <div className="planes">Interconnected Planes</div> */}
                <div className="tokenInfo">
                  <div className="tokenInfo-item">
                    <div className="tokenInfo-title">{item.name}</div>
                  </div>
                  <div className="tokenInfo-line" />
                  <div className="tokenInfo-item">
                    {/* <div className="tokeninfo-title">{`${t("Sale Starts In")}`}</div> */}
                    <div className="tokeninfo-name">{item.details}</div>
                  </div>
                </div>

                <div className="tokenData">
                  <div className="tokenDataItem">
                    <span className="total">{`${t("Total Token")}`}</span>
                    <span className="totalnum">{Number(item.totalToken)}{" "}{item.name}</span>
                  </div>
                  <div className="tokenDataItem">
                    <span className="total">{`${t("Participants")}`}</span>
                    <span className="totalnum">{item.Participants}</span>
                  </div>
                </div>
                <div className="currency-bottombtn">
                  {
                    Number(item.userClaimedTokens) === Number(item.totalAllocationTokens) && Number(item.userClaimedTokens) > 0 && Number(item.totalAllocationTokens) > 0 ? (
                      <button className="currency-button cancelbtn">
                        <div className="cancelRound" />
                        {`${t("Ended")}`}
                      </button>
                    ) : item.status === "1" && Number(item.userClaimedTokens) < Number(item.totalAllocationTokens) ? (
                      <button className="currency-button savebtn">
                        <div className="saveRound" />
                        {`${t("Live")}`}
                      </button>
                    ) : item.status === "2" ? (
                      <button className="currency-button cancelbtn">
                        <div className="cancelRound" />
                        {`${t("Canceled")}`}
                      </button>
                    ) : (<button className="currency-button comingbtn">
                      <div className="comingRound" />
                      {`${t("Upcoming")}`}
                    </button>)
                  }
                  <button
                    className="currency-button viewbtn"
                    onClick={() => {
                      ViewAirdroponCLick(item);
                    }}
                  >
                    {`${t("View Airdrop")}`}
                  </button>
                </div>
              </div>
            ))
          }
        </> : <Empty description={false} />
      }
    </div>
  );
};

export default CurrencyContainer;
