import { LaunchpadProps } from "../hooks/launchpad";

const LaunchpadValueInitState: LaunchpadProps = {
    routeName: "Lauchpad",
    inputValue: "",
    Radiovalue: "0x0000000000000000000000000000000000000000",
    FeeOptions: "500,0",
    ListingOptions: "true",
    FeeTokenSymbol: "BNB",
    FeeTokenDecimals: 18,
    IcoTokenSymbol: "",
    IcoTokenDecimals: 0,
};

export {
    LaunchpadValueInitState
};