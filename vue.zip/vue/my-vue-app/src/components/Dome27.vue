<template>
</template>

<script setup>
var loading = document.querySelector('.loading')

//建立观察者
var ob = new IntersectionObserver(function (entries) {
  var entry = entries[0];
  console.log(entry)
  if (entry.isIntersecting && !isLoading) {
    mome()
    console.log('加载更多')
  }
}, {
  thresholds: 0.1
})

function mome(){
  console.log('123')
}
//观察者
ob.observe(loading)

</script>

<style>
</style>
