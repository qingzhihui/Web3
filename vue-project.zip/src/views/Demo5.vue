<template>
  <span>123</span>
</template>
<script lang="ts">
import { reactive } from 'vue'
export default {

  setup() {

    const someObject = reactive({})
    return {
      someObject
    }
  },

  mounted() {
    const newObject = { name: '123' }
    this.someObject = newObject
    console.log(this.someObject)
  }
}
</script>
<style scoped></style>