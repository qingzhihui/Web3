export interface AIpser {
  id?: number;
  url?: string;
  att?: string;
  phy?: string;
  tal?: string;
  def?: string;
  rarity?: string;
  rarbei?: string;
}

const prin = [
  "ItemOne",
  "ItemTwo",
  "ItemThree",
  "ItemFour",
  "ItemFive",
  "ItemSix",
  "ItemSeven",
  "ItemEight",
  "ItemNine",
  "ItemTen",
  "ItemEleven"
];

export default prin;
