<template>
  <div class="c1">
    ches
  </div>
</template>

<script setup>
import {h} from "vue";

var dom = document.querySelector(".c1");
console.log(dom)

var key = dom.textKeyword.value.trim();
var reg;
if (key) {
  reg = new RegExp(key, 'g')
}
var name = h.cname;
if (reg) {
  name = name.replace(reg, function (key) {
    return `<em>${key}</em>`
  })
}

//鼠标抬起事件
window.onmouseup = function () {
  console.log('123')
}
//键盘抬起事件
const pressedCode = new Set();
window.onkeydown = function (e) {
  const code = keyMap[e.key]
  if (code && !pressedCode.has(code)) {
    console.log(code)
    pressedCode.add(code)
  }
}

</script>

<style>

</style>
