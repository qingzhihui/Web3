import React, { useEffect, useState } from "react";
import { Checkbox, Input, Form, Select } from "antd";
import type { CheckboxChangeEvent } from "antd/es/checkbox";
import "../../../styles/index.css";
import "../../../styles/mobile.css";
import styles from "../index.module.css";
import {
  ConterTokenList,
  DigitalInput,
  DisableDoubleCharacters,
  OptionList,
} from "../../../hooks/Token";
import { isAddress } from "../../../utils/address";
import { ConterTokenItem, RouterOptionItem } from "../../../state/TokenState";
import { useTranslation, Trans } from "react-i18next";
import { Constan } from "../../../config/constants/constants";
import { FormatUnitsConver, InstancedContract } from "../../../hooks/config";
import InputError from '../../InputError'
import { floatformat, posInvFormat } from '../../../utils/floatFormat'
import { GeneratorTokenError } from '../../../hooks/Errorhandle'
import { BigNumber } from "ethers";
import ButtonLoading from "../../ButtonLoading";
import { GeneratorTokenErrorInitState } from "../../../state/GeneratorTokenErrorState";
declare const window: Window & { ethereum: any };

const { Option } = Select;

interface GeneratorProps {
  Token: string;
  loading: boolean;
  GeneratorAdd: (e: any) => void;
}
const GeneratorToken: React.FC<GeneratorProps> = ({ Token, GeneratorAdd, loading }) => {
  const { t } = useTranslation();
  const [generatorNer, setGeneratorNer] = useState<ConterTokenList>(ConterTokenItem);
  const [flatFeeShow, setFlatFeeShow] = useState("");

  const [generateTokenError, setGeneratError] = useState<GeneratorTokenError>(GeneratorTokenErrorInitState)

  const setError = (key: string, value: boolean) => {
    setGeneratError((olddata: GeneratorTokenError) => {
      return {
        ...olddata,
        [key]: value
      }
    })
  }

  const isCreated = () => {
    if (generatorNer.Wallet || generatorNer.MarketingFee) {
      if (
        !generateTokenError.NameBlankError
        && !generateTokenError.NameCharactersError
        && !generateTokenError.SymbolBlankError
        && !generateTokenError.SymbolCharactersError
        && !generateTokenError.TotalSupplyBlankError
        && !generateTokenError.TotalSupplyAmountError
        && !generateTokenError.YieldBlankError
        && !generateTokenError.YieldMinError
        && !generateTokenError.YieldMaxError
        && !generateTokenError.LiquidityBlankError
        && !generateTokenError.LiquidityMinError
        && !generateTokenError.LiquidityMaxError
        && !generateTokenError.AddressBlankError
        && !generateTokenError.AddressInvalidError
        && !generateTokenError.PercentBlankError
        && !generateTokenError.PercentMinError
        && !generateTokenError.PercentMaxError
        && !generateTokenError.FeeOverError
        && generatorNer.Name
        && generatorNer.Symbol
        && generatorNer.Supply
        && generatorNer.Router
        && generatorNer.YieldFee
        && generatorNer.LiquidityFee
        && generatorNer.Wallet
        && generatorNer.MarketingFee
      ) {
        return true;
      } else {
        return false;
      }
    } else {
      if (
        !generateTokenError.NameBlankError
        && !generateTokenError.NameCharactersError
        && !generateTokenError.SymbolBlankError
        && !generateTokenError.SymbolCharactersError
        && !generateTokenError.TotalSupplyBlankError
        && !generateTokenError.TotalSupplyAmountError
        && !generateTokenError.YieldBlankError
        && !generateTokenError.YieldMinError
        && !generateTokenError.YieldMaxError
        && !generateTokenError.LiquidityBlankError
        && !generateTokenError.LiquidityMinError
        && !generateTokenError.LiquidityMaxError
        && !generateTokenError.FeeOverError
        && generatorNer.Name
        && generatorNer.Symbol
        && generatorNer.Supply
        && generatorNer.Router
        && generatorNer.YieldFee
        && generatorNer.LiquidityFee
      ) {
        return true;
      } else {
        return false;
      }
    }
  }

  const [form] = Form.useForm();
  const StandardCreateOnClikc = () => {
    GeneratorAdd({
      TokenPunie: Token,
      StandsData: generatorNer,
    });
  };
  const OnClickSelectCreate = (standarEvent: string) => {
    RouterOptionItem.filter((Opitem: OptionList) => {
      if (Opitem.value === standarEvent) {
        setGeneratorNer((olddata: ConterTokenList) => {
          return {
            ...olddata,
            Router: Opitem.value,
          };
        });
      }
    });
  };
  const NameValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DisableDoubleCharacters(e);
    if (inputChange !== undefined) {
      setGeneratorNer((olddata: ConterTokenList) => {
        if (inputChange === '') {
          setError("NameBlankError", true)
        } else {
          setError("NameBlankError", false)
        }
        if (inputChange && inputChange.length < 2) {
          setError("NameCharactersError", true)
        } else {
          setError("NameCharactersError", false)
        }
        return {
          ...olddata,
          Name: inputChange,
        };
      })
    }
  };
  const SymbolValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DisableDoubleCharacters(e);
    if (inputChange !== undefined) {
      setGeneratorNer((olddata: ConterTokenList) => {
        if (inputChange === '') {
          setError("SymbolBlankError", true)
        } else {
          setError("SymbolBlankError", false)
        }
        if (inputChange && inputChange.length < 2) {
          setError("SymbolCharactersError", true)
        } else {
          setError("SymbolCharactersError", false)
        }
        return {
          ...olddata,
          Symbol: inputChange,
        };
      });
    }
  };
  const SupplyValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setGeneratorNer((olddata: ConterTokenList) => {
      if (inputChange === '') {
        setError("TotalSupplyBlankError", true)
      } else {
        setError("TotalSupplyBlankError", false)
      }
      if (inputChange !== undefined && inputChange !== '') {
        if (BigNumber.from(inputChange).gte(BigNumber.from(10).pow(25))) {
          setError("TotalSupplyAmountError", true)
        } else {
          setError("TotalSupplyAmountError", false)
        }
      }
      return {
        ...olddata,
        Supply: inputChange
      };
    });
  };
  const YieldValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setGeneratorNer((olddata: ConterTokenList) => {
        if (inputChange === '') {
          setError("YieldBlankError", true)
        } else {
          setError("YieldBlankError", false)
        }
        if (inputChange && Number(inputChange) < 0.01) {
          setError("YieldMinError", true)
        } else {
          setError("YieldMinError", false)
        }
        if (inputChange && Number(inputChange) > 25) {
          setError("YieldMaxError", true)
        } else {
          setError("YieldMaxError", false)
        }
        if (inputChange && generatorNer.LiquidityFee && generatorNer.MarketingFee) {
          if (Number(inputChange) + Number(generatorNer.LiquidityFee) + Number(generatorNer.MarketingFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else if (inputChange && generatorNer.LiquidityFee) {
          if (Number(inputChange) + Number(generatorNer.LiquidityFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          YieldFee: inputChange
        };
      });
    }
  };
  const LiquidityValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setGeneratorNer((olddata: ConterTokenList) => {
        if (inputChange === '') {
          setError("LiquidityBlankError", true)
        } else {
          setError("LiquidityBlankError", false)
        }
        if (inputChange && Number(inputChange) < 0.01) {
          setError("LiquidityMinError", true)
        } else {
          setError("LiquidityMinError", false)
        }
        if (inputChange && Number(inputChange) > 25) {
          setError("LiquidityMaxError", true)
        } else {
          setError("LiquidityMaxError", false)
        }
        if (inputChange && generatorNer.YieldFee && generatorNer.MarketingFee) {
          if (Number(inputChange) + Number(generatorNer.YieldFee) + Number(generatorNer.MarketingFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else if (inputChange && generatorNer.YieldFee) {
          if (Number(inputChange) + Number(generatorNer.YieldFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          LiquidityFee: inputChange
        };
      });
    }
  };
  const AddressValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setGeneratorNer((olddata: ConterTokenList) => {
      if (!isAddress(e.target.value) && e.target.value) {
        setError("AddressInvalidError", true)
      } else {
        setError("AddressInvalidError", false)
      }
      if (e.target.value && generatorNer.MarketingFee) {
        setError("PercentBlankError", false)
        setError("AddressBlankError", false)
      }
      if ((e.target.value === '' || e.target.value === undefined) && (generatorNer.MarketingFee === '' || generatorNer.MarketingFee === undefined)) {
        setError("PercentBlankError", false)
        setError("AddressBlankError", false)
      }
      if ((e.target.value === '' || e.target.value === undefined) && generatorNer.MarketingFee !== '' && generatorNer.MarketingFee !== undefined) {
        setError("AddressBlankError", true)
      } else {
        setError("AddressBlankError", false)
      }
      if ((generatorNer.MarketingFee === '' || generatorNer.MarketingFee === undefined) && e.target.value !== '' && e.target.value !== undefined) {
        setError("PercentBlankError", true)
      } else {
        setError("PercentBlankError", false)
      }
      return {
        ...olddata,
        Wallet: e.target.value,
      };
    })
  };
  const MarketingFeeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    setGeneratorNer((olddata: ConterTokenList) => {
      if (inputChange && generatorNer.Wallet) {
        setError("PercentBlankError", false)
        setError("AddressBlankError", false)
      }
      if ((inputChange === '' || inputChange === undefined) && (generatorNer.Wallet === '' || generatorNer.Wallet === undefined)) {
        setError("PercentBlankError", false)
        setError("AddressBlankError", false)
      }
      if ((inputChange === '' || inputChange === undefined) && generatorNer.Wallet !== '' && generatorNer.Wallet !== undefined) {
        setError("PercentBlankError", true)
      } else {
        setError("PercentBlankError", false)
      }
      if ((generatorNer.Wallet === '' || generatorNer.Wallet === undefined) && inputChange !== '' && inputChange !== undefined) {
        setError("AddressBlankError", true)
      } else {
        setError("AddressBlankError", false)
      }
      if (inputChange && Number(inputChange) < 1) {
        setError("PercentMinError", true)
      } else {
        setError("PercentMinError", false)
      }
      if (inputChange && Number(inputChange) > 25) {
        setError("PercentMaxError", true)
      } else {
        setError("PercentMaxError", false)
      }
      if (inputChange && generatorNer.YieldFee && generatorNer.LiquidityFee) {
        if (Number(inputChange) + Number(generatorNer.YieldFee) + Number(generatorNer.LiquidityFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else if (generatorNer.YieldFee && generatorNer.LiquidityFee) {
        if (Number(generatorNer.YieldFee) + Number(generatorNer.YieldFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
      return {
        ...olddata,
        MarketingFee: inputChange
      };
    });
  };
  const NameBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("NameBlankError", true)
      } else {
        setError("NameBlankError", false)
      }
      if (e.target.value && e.target.value.length < 2) {
        setError("NameCharactersError", true)
      } else {
        setError("NameCharactersError", false)
      }
    }
  };
  const SymbolBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("SymbolBlankError", true)
      } else {
        setError("SymbolBlankError", false)
      }
      if (e.target.value && e.target.value.length < 2) {
        setError("SymbolCharactersError", true)
      } else {
        setError("SymbolCharactersError", false)
      }
    }
  };
  const SupplyBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      setError("TotalSupplyBlankError", true)
    } else {
      setError("TotalSupplyBlankError", false)
    }
    if (e.target.value !== undefined && e.target.value !== '') {
      if (BigNumber.from(e.target.value).gte(BigNumber.from(10).pow(25))) {
        setError("TotalSupplyAmountError", true)
      } else {
        setError("TotalSupplyAmountError", false)
      }
    }
  }
  const YieldBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("YieldBlankError", true)
      } else {
        setError("YieldBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 0.01) {
        setError("YieldMinError", true)
      } else {
        setError("YieldMinError", false)
      }
      if (e.target.value && Number(e.target.value) > 25) {
        setError("YieldMaxError", true)
      } else {
        setError("YieldMaxError", false)
      }
      if (e.target.value && generatorNer.LiquidityFee && generatorNer.MarketingFee) {
        if (Number(e.target.value) + Number(generatorNer.LiquidityFee) + Number(generatorNer.MarketingFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else if (e.target.value && generatorNer.LiquidityFee) {
        if (Number(e.target.value) + Number(generatorNer.LiquidityFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const LiquidityBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("LiquidityBlankError", true)
      } else {
        setError("LiquidityBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 0.01) {
        setError("LiquidityMinError", true)
      } else {
        setError("LiquidityMinError", false)
      }
      if (e.target.value && Number(e.target.value) > 25) {
        setError("LiquidityMaxError", true)
      } else {
        setError("LiquidityMaxError", false)
      }
      if (e.target.value && generatorNer.YieldFee && generatorNer.MarketingFee) {
        if (Number(e.target.value) + Number(generatorNer.YieldFee) + Number(generatorNer.MarketingFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else if (e.target.value && generatorNer.YieldFee) {
        if (Number(e.target.value) + Number(generatorNer.YieldFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const AddressBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isAddress(e.target.value) && e.target.value) {
      setError("AddressInvalidError", true)
    } else {
      setError("AddressInvalidError", false)
    }
    if (e.target.value && generatorNer.MarketingFee) {
      setError("PercentBlankError", false)
      setError("AddressBlankError", false)
    }
    if ((e.target.value === '' || e.target.value === undefined) && (generatorNer.MarketingFee === '' || generatorNer.MarketingFee === undefined)) {
      setError("PercentBlankError", false)
      setError("AddressBlankError", false)
    }
    if ((e.target.value === '' || e.target.value === undefined) && generatorNer.MarketingFee !== '' && generatorNer.MarketingFee !== undefined) {
      setError("AddressBlankError", true)
    } else {
      setError("AddressBlankError", false)
    }
    if ((generatorNer.MarketingFee === '' || generatorNer.MarketingFee === undefined) && e.target.value !== '' && e.target.value !== undefined) {
      setError("PercentBlankError", true)
    } else {
      setError("PercentBlankError", false)
    }
  };
  const MarketingFeeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value && generatorNer.Wallet) {
      setError("PercentBlankError", false)
      setError("AddressBlankError", false)
    }
    if ((e.target.value === '' || e.target.value === undefined) && (generatorNer.Wallet === '' || generatorNer.Wallet === undefined)) {
      setError("PercentBlankError", false)
      setError("AddressBlankError", false)
    }
    if ((e.target.value === '' || e.target.value === undefined) && generatorNer.Wallet !== '' && generatorNer.Wallet !== undefined) {
      setError("PercentBlankError", true)
    } else {
      setError("PercentBlankError", false)
    }
    if ((generatorNer.Wallet === '' || generatorNer.Wallet === undefined) && e.target.value !== '' && e.target.value !== undefined) {
      setError("AddressBlankError", true)
    } else {
      setError("AddressBlankError", false)
    }
    if (e.target.value && Number(e.target.value) < 1) {
      setError("PercentMinError", true)
    } else {
      setError("PercentMinError", false)
    }
    if (e.target.value && Number(e.target.value) > 25) {
      setError("PercentMaxError", true)
    } else {
      setError("PercentMaxError", false)
    }
    if (e.target.value && generatorNer.YieldFee && generatorNer.LiquidityFee) {
      if (Number(e.target.value) + Number(generatorNer.YieldFee) + Number(generatorNer.LiquidityFee) > 25) {
        setError("FeeOverError", true)
      } else {
        setError("FeeOverError", false)
      }
    } else if (generatorNer.YieldFee && generatorNer.LiquidityFee) {
      if (Number(generatorNer.YieldFee) + Number(generatorNer.YieldFee) > 25) {
        setError("FeeOverError", true)
      } else {
        setError("FeeOverError", false)
      }
    } else {
      setError("FeeOverError", false)
    }

  };
  const getCreateLGTokenFlatFee = async () => {
    const LGTokenFacctoryContract = InstancedContract(
      Constan[1].Address,
      Constan[1].Condebi
    ) as any;
    const flatFee = await LGTokenFacctoryContract.flatFee();
    setFlatFeeShow(FormatUnitsConver(flatFee.toString(), 18))
  }
  useEffect(() => { }, [flatFeeShow]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        getCreateLGTokenFlatFee();
      }
    }
  }, []);
  return (
    <div className="StandardToken">
      <div className={styles.tulieng}>
        <div className={styles.createfee}>{`${t("Token creation fee:")}`} {flatFeeShow || 0} BNB</div>
        <div className={styles.require}>{`${t("Name")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder={`${t("Ex: Ethereum")}`}
          className={styles.addrInput}
          value={generatorNer.Name as string}
          style={{ borderColor: generateTokenError.NameBlankError || generateTokenError.NameCharactersError ? '#f14668' : '' }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            NameValueChange(e);
          }}
          onBlur={(e) => {
            NameBlurChange(e);
          }}
        />
      </div>
      {generateTokenError.NameBlankError ? <InputError title="Name cannot be blank" /> : ''}
      {generateTokenError.NameCharactersError ? <InputError title="Name must be at least 2 characters" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Symbol")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder={`${t("Ex: ETH")}`}
          className={styles.addrInput}
          value={generatorNer.Symbol as string}
          style={{ borderColor: generateTokenError.SymbolBlankError || generateTokenError.SymbolCharactersError ? '#f14668' : '' }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            SymbolValueChange(e);
          }}
          onBlur={(e) => {
            SymbolBlurChange(e);
          }}
        />
      </div>
      {generateTokenError.SymbolBlankError ? <InputError title="Symbol cannot be blank" /> : ''}
      {generateTokenError.SymbolCharactersError ? <InputError title="Symbol must be at least 2 characters" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Total supply")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder={`${t("Ex: 100000000000")}`}
          className={styles.addrInput}
          value={generatorNer.Supply as string}
          style={{ borderColor: generateTokenError.TotalSupplyBlankError || generateTokenError.TotalSupplyAmountError ? '#f14668' : '' }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            SupplyValueChange(e);
          }}
          onBlur={(e) => {
            SupplyBlurChange(e);
          }}
        />
      </div>
      {generateTokenError.TotalSupplyBlankError ? <InputError title="Total supply cannot be blank" /> : ''}
      {generateTokenError.TotalSupplyAmountError ? <InputError title="Invalid total supply" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Router")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Form form={form}>
          <Form.Item name="请选择对应的" rules={[{ required: true }]} initialValue={`${t("Pancakeswap")}`}>
            <Select
              placeholder={`${t("Select Router Exchange")}`}
              onChange={(value: string) => {
                OnClickSelectCreate(value);
              }}
              options={RouterOptionItem}
            >
              {RouterOptionItem.map((item: OptionList) => (
                <Option key={item.key} value={item.value}>
                  {item.label}
                </Option>
              ))}
            </Select>
          </Form.Item>
        </Form>
      </div>
      <div className={styles.auoieng}>
        <div className={styles.auolItem}>
          <div className={styles.require}>
            {`${t("Transaction fee to generate yield")}`} (%)<span style={{ color: "#f95192" }}> *</span>
          </div>
          <Input
            placeholder={`${t("Ex: 2")}`}
            className={styles.addrInput}
            value={generatorNer.YieldFee as string}
            style={{ borderColor: generateTokenError.YieldBlankError || generateTokenError.YieldMinError || generateTokenError.YieldMaxError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              YieldValueChange(e);
            }}
            onBlur={(e) => {
              YieldBlurChange(e);
            }}
          />
        </div>
        <div className={styles.auolItem}>
          <div className={styles.require}>
            {`${t("Transaction fee to generate liquidity")}`} (%)<span style={{ color: "#f95192" }}> *</span>
          </div>
          <Input
            placeholder={`${t("Ex: 3")}`}
            className={styles.addrInput}
            value={generatorNer.LiquidityFee as string}
            style={{ borderColor: generateTokenError.LiquidityBlankError || generateTokenError.LiquidityMinError || generateTokenError.LiquidityMaxError ? '#f14668' : '' }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              LiquidityValueChange(e);
            }}
            onBlur={(e) => {
              LiquidityBlurChange(e);
            }}
          />
        </div>
      </div>
      <div className="sbuyeisn">
        <div className="sbuyeisnItem">
          {generateTokenError.YieldBlankError ? <InputError title="TaxFeeBps cannot be blank" /> : ''}
          {generateTokenError.YieldMinError ? <InputError title="TaxFeeBps must be greater than or equal to 0.01" /> : ''}
          {generateTokenError.YieldMaxError ? <InputError title="TaxFeeBps must be less than or equal to 25" /> : ''}
        </div>
        <div className="sbuyeisnItem">
          {generateTokenError.LiquidityBlankError ? <InputError title="LiquidityFeeBps cannot be blank" /> : ''}
          {generateTokenError.LiquidityMinError ? <InputError title="LiquidityFeeBps must be greater than or equal to 0.01" /> : ''}
          {generateTokenError.LiquidityMaxError ? <InputError title="LiquidityFeeBps must be less than or equal to 25" /> : ''}
        </div>
      </div>
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Charity/Marketing address")}`}</div>
        <Input
          placeholder={`${t("Ex: 0x....")}`}
          className={styles.addrInput}
          style={{ borderColor: generateTokenError.AddressInvalidError ? '#f14668' : '' }}
          value={generatorNer.Wallet as string}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            AddressValueChange(e);
          }}
          onBlur={(e) => {
            AddressBlurChange(e);
          }}
        />
        {generateTokenError.AddressBlankError ? <InputError title="When the charity percent is not blank, the charity address  cannot be blank" /> : ''}
        {generateTokenError.AddressInvalidError ? <InputError title="Address is invalid" /> : ''}
      </div>
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Charity/Marketing percent")}`} (%)</div>
        <Input
          placeholder="0 - 25"
          className={styles.addrInput}
          value={generatorNer.MarketingFee as string}
          style={{ borderColor: generateTokenError.PercentMinError || generateTokenError.PercentMaxError || generateTokenError.FeeOverError ? '#f14668' : '' }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            MarketingFeeValueChange(e);
          }}
          onBlur={(e) => {
            MarketingFeeBlurChange(e)
          }}
        />
      </div>
      {generateTokenError.PercentBlankError ? <InputError title="charityBps cannot be blank" /> : ''}
      {generateTokenError.PercentMinError ? <InputError title="charityBps must be greater than or equal to 1" /> : ''}
      {generateTokenError.PercentMaxError ? <InputError title="charityBps must be less than or equal to 25" /> : ''}
      {generateTokenError.FeeOverError ? <InputError title="Total fee is over 25%" /> : ''}
      <div className={styles.tulieng}>
        <Checkbox
          onChange={(e: CheckboxChangeEvent) => {
            setGeneratorNer((olddata: ConterTokenList) => {
              return {
                ...olddata,
                UseAntiBot: e.target.checked,
              };
            });
          }}
          checked={generatorNer.UseAntiBot as boolean}
          style={{ lineHeight: "32px" }}
        >
          {`${t("Implement Maya Anti-Bot System?")}`}
        </Checkbox>
      </div>
      {isCreated() ? <button
        onClick={() => {
          StandardCreateOnClikc();
        }}
        className={`nextbtn ${styles.nextbtn}`}
      >
        {loading ? <ButtonLoading /> : ''}{`${t("Create token")}`}
      </button> : <button
        style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
        className={`nextbtn ${styles.nextbtn}`}
      >
        {`${t("Create token")}`}
      </button>}
    </div>
  );
};

export default GeneratorToken;
