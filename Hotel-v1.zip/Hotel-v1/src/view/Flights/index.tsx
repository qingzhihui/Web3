import React from "react";

const Flights = () => {
  return <div>Flights</div>;
};

export default Flights;
