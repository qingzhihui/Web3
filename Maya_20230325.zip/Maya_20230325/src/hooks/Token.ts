declare const window: Window & { ethereum: any };
export interface ConterTokenList {
  Name?: string;
  Symbol?: string;
  Decimals?: string;
  Supply?: string;
  Router?: string;
  YieldFee?: string;
  LiquidityFee?: string;
  Wallet?: string;
  MarketingFee?: string;
  UseAntiBot?: boolean;
}

export interface BabyTokenList {
  Name?: string;
  Symbol?: string;
  Supply?: string;
  Router?: string;
  RewardToken?: string;
  Dividends?: string;
  RewardFee?: string;
  LiquidityFee?: string;
  BuyBackFee?: string;
  ReflectionFee?: string;
  MarketingFee?: string;
  Wallet?: string;
  UseAntiBot?: boolean;
}

export interface OptionList {
  key: number;
  value: string;
  label: string;
}

const dividendTracker = "0x3e9dB8eEB92Ef9B1FA3144a87285e427412aF629";

const DigitalInput = (e: React.ChangeEvent<HTMLInputElement>) => {
  return e.target.value.replace(/[^\d]/g, '').replace(/^[0]+/,'');
};

const DisableDoubleCharacters = (e: React.ChangeEvent<HTMLInputElement>) => {
  return e.target.value.replace(/[^\x00-\xff]/g, "");
}

const toStringValue = (value: any) => {
  return value.toString();
};

export { DigitalInput, dividendTracker, toStringValue, DisableDoubleCharacters };
