import React, { useEffect, useState } from "react";
import { Input, Radio, Space } from "antd";
import type { RadioChangeEvent } from "antd";
import "./index.css";
import "./mobile.css";
import { useHistory, useLocation } from "react-router-dom";
import RoadmapPC from "../../components/RoadmapPC";
import RoadmapMobile from "../../components/RoadmapMobile";
import { useTranslation, Trans } from "react-i18next";
import { Lineg } from "../../hooks/config";
import { SpaceItem } from "../../hooks/Sale";
import InputError from '../../components/InputError'
import { LaunchpadProps } from "../../hooks/launchpad";
declare const window: Window & { ethereum: any };
const Sale: React.FC = () => {
  let history = useHistory();
  const { t } = useTranslation();
  const { state } = useLocation<any>();
  const [createfee, setCreateFee] = useState(1);
  const [LauchpadList, setLauchpadList] = useState<LaunchpadProps>({
    routeName: "Sale",
    inputValue: "",
    Radiovalue: "0x0000000000000000000000000000000000000000",
  });
  const [userName, setUserName] = useState("");

  const RadioOnChange = (e: RadioChangeEvent) => {
    setLauchpadList((olddata: LaunchpadProps) => {
      return {
        ...olddata,
        Radiovalue: e.target.value,
      };
    });
    const coName = SpaceItem.filter((item: any) => {
      return item.value === e.target.value;
    });
    setUserName((state: any) => {
      return (state = coName[0].label);
    });
  };
  const NextSaleOnClick = () => {
    if (state != undefined) {
      if (state.inputValue != undefined) {
        history.push({
          pathname: "/WhiteList",
          state: LauchpadList,
        });
      } else {
        history.push({
          pathname: "/WhiteList",
          state: state,
        });
      }
    } else {
      history.push({
        pathname: "/WhiteList",
        state: LauchpadList,
      });
    }
  };
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          if (state.inputValue != undefined) {
            setLauchpadList((stateDate: LaunchpadProps) => {
              return (stateDate = state);
            });
          } else if (state.PoleieData != undefined) {
            setLauchpadList((stateDate: LaunchpadProps) => {
              return (stateDate = state.PoleieData);
            });
          } else {
            setLauchpadList((stateDate: LaunchpadProps) => {
              return (stateDate = state.data.PoleieData);
            });
          }
        }
      }
    }

  }, [state]);

  const [errorshow, setErrorShow] = useState<boolean>(false)

  const [isexec, setIsExec] = useState<boolean>(false)

  const judgeTitle = (value: string) => {
    if (value && value !== undefined && value !== '') {
      setErrorShow(false)
      setIsExec(true)
    } else {
      setIsExec(false)
      setErrorShow(true)
    }
  }

  useEffect(() => {
    if (LauchpadList.inputValue && LauchpadList.inputValue !== undefined && LauchpadList.inputValue !== '') {
      setIsExec(true)
    } else {
      setIsExec(false)
    }
  }, [LauchpadList.inputValue])

  const renderTable = () => {
    return (
      <div className="saleTable">
        <div className="title">{`${t("Create Private Sale")}`}</div>
        <div className="subtitle">(*) {`${t("is required field.")}`}</div>
        <div className="titleword">
          {`${t("Title")}`}
          <span style={{ color: "#F95192" }}> *</span>
        </div>
        <input
          className="saleInput"
          value={LauchpadList.inputValue}
          onChange={(e) => {
            setLauchpadList((olddata: LaunchpadProps) => {
              return {
                ...olddata,
                inputValue: e.target.value,
              };
            });
          }}
          placeholder={`${t("Ex: This is my private sale")}`}
          style={{ borderColor: errorshow ? '#F95192' : '' }}
          onBlur={(e) => { judgeTitle(e.target.value) }}
        />
        {errorshow ? <InputError title="Invalid title" /> : ''}
        <div className="tip">
          {`${t("Pool creation fee")}`}: {createfee || 0} BNB
        </div>
        <div className="currTitle">{`${t("Currency")}`}</div>
        <div>
          <Radio.Group onChange={RadioOnChange} value={LauchpadList.Radiovalue}>
            <Space direction="vertical">
              <Radio value={"0x0000000000000000000000000000000000000000"}>
                BNB
              </Radio>
              <Radio value={"0xF03E0Fc04757184ff64A58385d5553F661878f1A"}>
                BUSD
              </Radio>
              <Radio value={"0xF03E0Fc04757184ff64A58385d5553F661878f1B"}>
                USDT
              </Radio>
              <Radio value={"0xF03E0Fc04757184ff64A58385d5553F661878f1C"}>
                USDC
              </Radio>
            </Space>
          </Radio.Group>
        </div>
        <div className="paywith-text">
          {`${t("Users will pay with")}`}{" "}
          {LauchpadList.Radiovalue ===
            "0x0000000000000000000000000000000000000000"
            ? "BNB"
            : LauchpadList.Radiovalue ===
              "0xF03E0Fc04757184ff64A58385d5553F661878f1A"
              ? "BUSD"
              : LauchpadList.Radiovalue ===
                "0xF03E0Fc04757184ff64A58385d5553F661878f1B"
                ? "USDT"
                : LauchpadList.Radiovalue ===
                  "0xF03E0Fc04757184ff64A58385d5553F661878f1C"
                  ? "USDC"
                  : ""}{" "}
          {`${t("for your token")}`}
        </div>
        {/* <button
          className="nextBtn"
          onClick={() => {
            NextSaleOnClick();
          }}
        >
          {`${t("Next")}`}
        </button> */}
        {isexec ? <button
          className="nextBtn"
          onClick={() => {
            NextSaleOnClick();
          }}
        >
          {`${t("Next")}`}
        </button> : <button
          className="nextBtn"
          style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
        >
          {`${t("Next")}`}
        </button>}
      </div>
    );
  };
  const renderPCContent = () => {
    return (
      <div className="salePCContent">
        {renderTable()}
        <img
          src={require(`../../assets/image/Antibot-cat.png`)}
          className="pagePCcat"
          alt=""
        />
        <RoadmapPC step={1} />
        <div className="disclaimer">
          {`${t(
            "Disclaimer: The information provided shall not in any way constitute a recommendation as to whether you should invest in any product discussed. We accept no liability for any loss occasioned to any person acting or refraining from action as a result of any material provided or published."
          )}`}
        </div>
      </div>
    );
  };
  const renderMobileConetnt = () => {
    return (
      <div className="saleMobileContent">
        {renderTable()}
        <RoadmapMobile step={1}/>
        <img
          src={require(`../../assets/image/Antibot-cat.png`)}
          alt=""
          className="mobileBottomCat"
        />
      </div>
    );
  };

  return (
    <div className="sale">
      {renderPCContent()}
      {renderMobileConetnt()}
    </div>
  );
};

export default Sale;
