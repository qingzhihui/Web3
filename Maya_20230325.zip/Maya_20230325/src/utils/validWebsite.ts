export function validWebsiteUrL(flag:string,url:string){
    let websiteReg:any
    if(flag !== 'LogoUrl' && flag !== 'Website'){
        // 除去前两个以外 允许传入空值
        if(!url || url === undefined || url === ''){
            return true
        }
    }
    switch (flag){
        case "Facebook":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://facebook.com(/[a-zA-Z0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
        case "Twitter":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://twitter.com(/[a-zA-Z0-9%&=\?\-_]+)*$`)
            return false
        case "Github":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://github.com(/[a-zA-Z0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
        case "Telegram":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://t.me(/[a-zA-Z0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
        case "Instagram":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://instagram.com(/[a-zA-Z0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
        case "Discord":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://t.me(/[a-zA-Z0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
        case "Youtube":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://www.youtube.com/watch?([a-zA-Z0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
        case "Reddit":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://reddit.com(/[a-zA-Z0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
        case "LogoUrl":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://images.youwant.io/.*([a-zA-Z0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
        case "Website":
            // eslint-disable-next-line no-useless-escape
            websiteReg = RegExp(`^(https)://.*(/[a-zA-Z.0-9%&=\?\-_]+)*$`)
            return websiteReg.test(url)
    }
}

