import {
  FormatUnitsConver,
  InstancedContract,
  TimestampToTime,
  TokenNameDecimals,
} from "./config";
import {
  LaunchPadABI,
  LaunchPadFactoryABI,
  LaunchPadFactoryAddress,
} from "./launchpad";
import { CycleBpsConversion, CycleConversion } from "./LockRecordInfo";
import { PrivateSalePropsType } from "./PrivateSale";

const TokenfeeTokenUrle = "0x0000000000000000000000000000000000000000";

export const LaunchPadFactoryContract = InstancedContract(
  LaunchPadFactoryAddress,
  LaunchPadFactoryABI
) as any;
const getPoolArrayLength = async () => {
  return await LaunchPadFactoryContract.getPoolArrayLength();
};

const getPoolsGetdata = async () => {
  return await LaunchPadFactoryContract.getPools();
};
const getLaunchpadInfo = async (Address: string) => {
  const ArrayContract = InstancedContract(Address, LaunchPadABI) as any;
  return await ArrayContract.getLaunchpadInfo();
};

const geticoToken = async (Address: string) => {
  const ArrayContract = InstancedContract(Address, LaunchPadABI) as any;
  const icoToken = await ArrayContract.icoToken();
  const liquidityPercent = await ArrayContract.liquidityPercent();
  const lpLockTime = await ArrayContract.lpLockTime();
  const presaleRate = await ArrayContract.presaleRate();
  return {
    icoToken,
    liquidityPercent,
    lpLockTime,
    presaleRate,
  };
};
const dataPromise = (Address: string) => {
  return Promise.all([getLaunchpadInfo(Address), geticoToken(Address)]).then(
    (res) => {
      return res;
    }
  );
};
const feeTokendecimalsPeon = async (feeToken: any) => {
  var feeTokendecimals = 18;
  if (feeToken !== TokenfeeTokenUrle) {
    const feeTokenContract = await TokenNameDecimals(feeToken);
    feeTokendecimals = feeTokenContract.decimals;
  }
  return feeTokendecimals;
};

const percentConter = (raisedAmount: any, hardCap: any) => {
  let percent =
    Number(raisedAmount.toString()) / Number(hardCap.toString() * 100);
  return Number(percent.toFixed(2));
};

const SaleDataPienSers = async (SersNumber: number, SersData: string[]) => {
  const getPrivateListData: PrivateSalePropsType[] = [];
  for (let index = 0; index < SersNumber; index++) {
    const getPrelinstSaleData = await dataPromise(SersData[index]);
    const feeTokendecimals = await feeTokendecimalsPeon(
      getPrelinstSaleData[0].feeToken
    );
    const icoTokenContract = await TokenNameDecimals(
      getPrelinstSaleData[1].icoToken
    );
    const percent = percentConter(
      getPrelinstSaleData[0].raisedAmount,
      getPrelinstSaleData[0].hardCap
    );
    getPrivateListData.push({
      Title: icoTokenContract.name,
      tgeBps: "0",
      cycle: "0",
      cycleBps: "0",
      raisedAmount: FormatUnitsConver(
        getPrelinstSaleData[0].raisedAmount.toString(),
        feeTokendecimals
      ),
      softCap: FormatUnitsConver(
        getPrelinstSaleData[0].softCap.toString(),
        feeTokendecimals
      ),
      hardCap: FormatUnitsConver(
        getPrelinstSaleData[0].hardCap.toString(),
        feeTokendecimals
      ),
      Progress: percent,
      start: (
        Number(getPrelinstSaleData[0].startTime.toString()) * 1000
      ).toString(),
      startString: TimestampToTime(getPrelinstSaleData[0].startTime.toString()),
      endString: TimestampToTime(getPrelinstSaleData[0].endTime.toString()),
      end: (
        Number(getPrelinstSaleData[0].endTime.toString()) * 1000
      ).toString(),
      status: getPrelinstSaleData[0].state.toString(),
      address: SersData[index],
      presaleRate: FormatUnitsConver(
        getPrelinstSaleData[1].presaleRate,
        icoTokenContract.decimals
      ),
      liquidityPercent: CycleBpsConversion(
        getPrelinstSaleData[1].liquidityPercent
      ).toString(),
      lpLockTime: CycleConversion(getPrelinstSaleData[1].lpLockTime).toString(),
    });
  }
  return getPrivateListData;
};

export {
  percentConter,
  geticoToken,
  getPoolArrayLength,
  getPoolsGetdata,
  getLaunchpadInfo,
  dataPromise,
  TokenfeeTokenUrle,
  SaleDataPienSers,
  feeTokendecimalsPeon
};
