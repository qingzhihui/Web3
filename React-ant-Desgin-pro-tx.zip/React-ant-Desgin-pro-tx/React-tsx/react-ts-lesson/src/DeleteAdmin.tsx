import React from "react";
import { IAdmin } from "./AdminList";
interface IProps {
  admin: IAdmin;
  onDelete: (admin: IAdmin) => void;
}
function DeleteAdmin({ admin, onDelete }: IProps) {
  return (
    <div>
      <button
        onClick={() => {
          onDelete(admin);
        }}
      >
        删除
      </button>
    </div>
  );
}

export default DeleteAdmin;
