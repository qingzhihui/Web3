import { Button, Form, Input, Modal, Select, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import React, { useState } from "react";
import "./index.css";

import { DeleteOutlined, FormOutlined } from "@ant-design/icons";

// 邮箱配置界面
const MailboxSettings: React.FC = () => {
  const { TextArea } = Input;
  const [isUpdajx, setUpdajx] = useState(false);

  const ceshi = {
    ceshi1: {},
  };

  //创建选择的邮箱
  // const [isMailbox,setMailbox] = useState();

  interface DataType {
    key: string;
    templateCode: string;
    templateTitle: string;
    templateCont: string;
    status: string;
  }

  // 提交
  const submitData = (values: any) => {
    console.log("提交的数据", values);
    console.log("下拉选择机密方式数据:", values.encryption);
  };

  // 添加邮箱模板--提交
  const submitData1 = (values: any) => {
    console.log("Success:", values);
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log("Failed:", errorInfo);
  };
  // 点击禁用按钮
  const forbiddenjx = (record: any) => {
    return () => {
      console.log(record.key); // hello
      console.log("点击了禁用");
    };
  };

  // 删除邮箱配置操作
  const deletejx = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key); // hello
      // console.log
    };
  };

  // 表格数据
  const data: DataType[] = [
    {
      key: "1",
      templateCode: "TM001", //模板编码
      templateTitle: "邮箱变更通知", //模板标题
      templateCont: "邮箱已变更为..", //模板内容
      status: "点击禁用", //模板状态
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "模板编码",
      dataIndex: "templateCode",
      render: (templateCode) => <a>{templateCode}</a>,
    },
    {
      title: "模板标题",
      dataIndex: "templateTitle",
    },
    {
      title: "模板内容",
      dataIndex: "templateCont",
    },
    {
      title: "状态",
      render: (_, record) => (
        <Space size="middle">
          <a onClick={forbiddenjx(record)} className="clickDisable" href="#">
            {record.status}
          </a>
        </Space>
      ),
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="yx_pubcursor" onClick={uploadjx(record)}>
            <FormOutlined />
          </span>
          <span className="yx_pubcursor" onClick={deletejx(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 下拉选择框-加密方式-内容
  const options1 = [
    {
      value: 1,
      label: "bats64",
    },
    {
      value: 2,
      label: "md5",
    },
  ];

  // 下拉选择-加密方式---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };

  // 点击X关闭
  const handleCancel = () => {
    setUpdajx(false);
  };

  // 修改邮箱配置操作
  const uploadjx = (record: any) => {
    return () => {
      console.log("获取选中修改的数据", record);
      ceshi.ceshi1 = JSON.stringify(record);
      console.log("ceshi.ceshi1", typeof ceshi.ceshi1);
      // setMailbox(record);
      setUpdajx(true);

      // console.log
    };
  };

  return (
    <div className="yx_daBox">
      {/* 邮箱配置 */}
      <div className="yx_Box">
        <div className="yx_headerBox">
          <div className="yx_headerBox_thread"></div>
          <div className="yx_headerBox_Tit">&nbsp;&nbsp;&nbsp;邮箱配置</div>
        </div>
        <div className="yx_inputBox">
          <Form
            name="basic"
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 16 }}
            style={{ maxWidth: 600 }}
            initialValues={{ remember: true }}
            onFinish={submitData}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
          >
            <Form.Item label="主机Host" name="engineHost">
              <Input placeholder="请输入主机Host" />
            </Form.Item>
            <Form.Item label="用户名" name="username">
              <Input placeholder="请输入用户名" />
            </Form.Item>
            <Form.Item label="密码" name="password">
              <Input.Password placeholder="请输入密码" />
            </Form.Item>
            <Form.Item label="端口Port" name="port">
              <Input placeholder="请输入端口Port" />
            </Form.Item>
            <Form.Item label="加密方式" name="encryption">
              <Select
                labelInValue
                style={{ width: 120 }}
                onChange={handleChange1}
                options={options1}
              />
            </Form.Item>
            <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
              <Button
                className="yx_btn"
                size="middle"
                type="primary"
                htmlType="submit"
              >
                提交
              </Button>
            </Form.Item>
          </Form>
        </div>
      </div>
      {/* 邮件模板管理 */}
      <div className="yj_box">
        <div className="yj_headerBox">
          <div className="yj_headerBox_thread"></div>
          <div className="yj_headerBox_Tit">&nbsp;&nbsp;&nbsp;邮箱配置</div>
          <div className="yj_Add_moban">添加邮箱模板</div>
        </div>

        <div className="yj_tableBox">
          <Table
            columns={columns}
            dataSource={data}
            scroll={{ x: "max-content", y: 170 }}
          />
        </div>
        {/* 邮箱配置内容编辑 */}
        <Modal
          className="yxUploadCont"
          footer={[null]}
          open={isUpdajx}
          onCancel={handleCancel}
        >
          <div className="yx_headerBox">
            <div className="yx_headerBox_thread"></div>
            <div className="yx_headerBox_Tit">&nbsp;&nbsp;&nbsp;邮箱配置</div>
          </div>
          <div className="yxUploadCont_Box">
            <Form
              name="basic"
              labelCol={{ span: 6 }}
              wrapperCol={{ span: 18 }}
              style={{ maxWidth: 600 }}
              initialValues={{ remember: true }}
              onFinish={submitData1}
              onFinishFailed={onFinishFailed}
              autoComplete="off"
            >
              <Form.Item label="模板编码" name="templateCode">
                {/* defaultValue='' */}
                <Input placeholder="例如：TM*****,TM0001" />
              </Form.Item>

              <Form.Item label="标题" name="title">
                <Input placeholder="请输入模板标题" />
              </Form.Item>

              <Form.Item label="邮箱模板内容" name="mailboxTemplateContent">
                <TextArea
                  rows={4}
                  placeholder="例如：***邮箱已经变更为***邮箱，配置{@param1}邮箱已经变更为{@param2}邮箱"
                />
              </Form.Item>

              <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                <Button
                  className="yx_btn"
                  size="middle"
                  type="primary"
                  htmlType="submit"
                >
                  提交
                </Button>
              </Form.Item>
            </Form>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default MailboxSettings;
