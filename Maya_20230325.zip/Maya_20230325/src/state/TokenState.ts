import { ConterTokenList, OptionList, BabyTokenList } from "../hooks/Token";

const ConterTokenItem: ConterTokenList = {
  Name: "",
  Symbol: undefined,
  Decimals: undefined,
  Supply: undefined,
  Router: "0xD99D1c33F9fC3444f8101754aBC46c52416550D1",
  YieldFee: undefined,
  LiquidityFee: undefined,
  Wallet: "",
  MarketingFee: undefined,
  UseAntiBot: false,
};

const BabyTokenItem: BabyTokenList = {
  Name: "",
  Symbol: undefined,
  Supply: undefined,
  Router: "0xD99D1c33F9fC3444f8101754aBC46c52416550D1",
  RewardToken: "",
  Dividends: "",
  RewardFee:"",
  BuyBackFee: "",
  ReflectionFee: "",
  LiquidityFee: "",
  MarketingFee: "",
  Wallet: "",
  UseAntiBot: false,
};

// Token
let OptionItem: OptionList[] = [
  {
    key: 0,
    label: "Standard Token",
    value: "0x2b5f92bdc92dc7fa989c228ff3311424d4002710",
  },
  {
    key: 1,
    label: "Liquidity Generator Token",
    value: "0x4194cf08aff43d1e05c6aef0f5832683beb73647",
  },
  {
    key: 2,
    label: "Baby Token",
    value: "0xe9acdb08bfb21cd7081f13e997998a519065103d",
  },
  {
    key: 3,
    label: "Buyback Baby Token",
    value: "0x8a35a1dfc1c60ee7b0ce5aee7c4140013d42cd1e",
  },
];
// Router
let RouterOptionItem: OptionList[] = [
  {
    key: 0,
    label: "Pancakeswap",
    value: "0xD99D1c33F9fC3444f8101754aBC46c52416550D1",
  },
  {
    key: 1,
    label: "ApeSwap",
    value: "3",
  },
  {
    key: 2,
    label: "MDex",
    value: "4",
  },
  {
    key: 3,
    label: "BiSwap",
    value: "5",
  },
  {
    key: 4,
    label: "KnightSwap",
    value: "6",
  },
  {
    key: 5,
    label: "PinkSwap",
    value: "7",
  },
];

const ExchangeItme: OptionList[] = [
  {
    key: 0,
    label: "Pancakeswap",
    value: "0xD99D1c33F9fC3444f8101754aBC46c52416550D1",
  },
  {
    key: 1,
    label: "PinkSwap",
    value: "7",
  },
];
const TokenItmeOlen: OptionList[] = [
  {
    key: 0,
    label: "BNB",
    value: "0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd",
  },
];

export {
  ConterTokenItem,
  OptionItem,
  RouterOptionItem,
  BabyTokenItem,
  ExchangeItme,
  TokenItmeOlen,
};
