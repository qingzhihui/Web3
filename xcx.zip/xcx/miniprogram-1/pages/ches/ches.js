// pages/ches/ches.js
import api from '../../config/api'
import datapro from '../../config/t.js'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    vicondata: [],
    // 数据
    radio: '0',
    activeNames: ['0'],
    activeNames2: ['0'],
    show2: false,
    show3: false,
    show4: false,
    shistate: 0,

    // 案例笔记
    anid: "",
    value: "",
    message4: "",
    Chadata: [],

    // 佐证
    // 一级
    questionnaireId: 1,
    // 二级
    uestionnaireTwoId: "",
    // 选项id
    optionTableId: "",
    // 佐证内容
    message: "",
    // 用户id
    // adminId: 84,
    // 题目id
    subjectId: "",
    // 添加的id
    musid: "",
    // 展示用户信息
    Beinlist: {},
    // 用户数据
    anBine: {},
    // 问卷ID
    Qusersid: "",
    // 团队ID
    TeamId: "",
    lustr: false,
    BueleList: [],
    beinse: 0,
    Dvalue: "",
    touchShow: true,
    beishow: false,
    //是否触发提交问卷操作 默认不触发
    isSubmint: 0,
    id: null, // 提交表编号
    tabsShow: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      vicondata: datapro[0].data
    })
  },
  onChangeTabs(event) {
    console.log(event);
    this.setData({
      active: event.detail.index
    })
    if (event.detail.index >= this.data.vicondata.length) {
      this.setData({
        tabsShow: true
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  Anlishow(e) {
    this.setData({
      show3: true,
      anid: e.currentTarget.dataset.id
    });
  },
  onChange2(event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  onTulier() {
    this.setData({
      active: this.data.active - 1
    })
    if (this.data.active < this.data.vicondata.length) {
      this.setData({
        tabsShow: false
      })
    }
  },
  onTulierbut() {
    this.setData({
      active: this.data.active + 1
    })
    if (this.data.active >= this.data.vicondata.length) {
      this.setData({
        tabsShow: true
      })
    } else {
      this.setData({
        tabsShow: false
      })
    }
  },
  onReady() {

  },
  onChange(event) {
    this.setData({
      uestionnaireTwoId: event.currentTarget.dataset.item,
      subjectId: event.currentTarget.dataset.id,
    })
    this.data.vicondata.map((item) => {
      if (item.id == event.currentTarget.dataset.id) {
        item.umsOptionTables.map((msg) => {
          if (msg.id == parseInt(event.detail.split(',')[1])) {
            this.setData({
              optionTableId: event.detail.split(',')[1]
            })
            if (msg.identification == true) {
              setTimeout(() => {
                this.setData({
                  radio: event.detail,
                  show2: true,
                });
              }, 100)
            } else {
              this.setData({
                radio: event.detail.split(',')[0],
                show2: false,
              });
            }
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  Lisbeani() {
    this.data.Chadata.map((item) => {
      this.setData({
        message: item.content
      })
    })
  },
  Anlshow4(e) {
    this.setData({
      show4: true
    })
    api._get(`ums/umsCaseNotes/selectCaseNoteById/${this.data.anBine.userId}/${e.currentTarget.dataset.id}`).then(res => {
      const biem = [];
      res.data.map((item) => {
        item.createTime = item.createTime.split('T')[0]
        biem.push(item)
      })
      this.setData({
        Chadata: biem
      })
    }).catch(e => {
      console.log(e)
    })
    this.setData({
      show4: true
    })

  },
})