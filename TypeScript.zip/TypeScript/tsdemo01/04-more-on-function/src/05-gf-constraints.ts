function longest<Type extends { length: number }>(a: Type, b: Type) {
  if (a.length >= b.length) {
    return a;
  } else {
    return b;
  }
}
const longerArray = longest([1, 2], [2, 3, 4]);

const longerString = longest("felix", "lu");

// 错误
// const notOk = longest(10, 100);
