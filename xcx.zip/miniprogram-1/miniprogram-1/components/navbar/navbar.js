// components/navbar/navbar.js
const app = getApp();
import api from '../../config/api'
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    store_name: "正向践行价值观行为提升评价系统",
    navHeight: app.globalData.navHeight, //导航栏高度
    navTop: app.globalData.navTop, //导航栏距顶部距离
    navObj: app.globalData.navObj, //胶囊的高度
    navObjWid: app.globalData.navObjWid, //胶囊宽度+距右距离
    imlog: "",
  },

  /**
   * 组件的方法列表
   */
  methods: {

  },
  attached: function () {
    const adingList = wx.getStorageSync('admin')
    if(adingList.userId!==null){
      api._get(`ums/umdLogoManagement/wcGetLogo/${adingList.userId}`).then(res => {
        if (res.data == '') {
          this.setData({
            imlog: '../../asstes/image/kss.png'
          })
        } else {
          this.setData({
            imlog: res.data
          })
        }
      }).catch(e => {
        console.log(e);
      })
    }
  },
})