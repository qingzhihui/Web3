import React, { Component, useState } from 'react';
import "./index.css"
import { Button, Checkbox, Form, Input, Radio } from 'antd';
import { Modal, Upload } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { RcFile, UploadProps } from 'antd/es/upload';
import type { UploadFile } from 'antd/es/upload/interface';

// 首页导航配置界面




const HomePageNavigation: React.FC = () => {
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [fileList, setFileList] = useState<UploadFile[]>([

    ]);

    const handleCancel = () => setPreviewOpen(false);

    // 提交数据
    const submitData = (values: any) => {
        console.log("获取到的数据",values)
    };

    const onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };

    const getBase64 = (file: RcFile): Promise<string> =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }

        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };

    const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>{
        setFileList(newFileList);
        console.log("获取上传的图片名", newFileList[0])
    }

    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );
    return (
        <div className='hoem_Box'>
            <div className='hoem_headerBox'>
                <div className='hoem_headerBox_thread'></div>
                <div className='hoem_headerBox_Tit'>&nbsp;&nbsp;&nbsp;首页导航配置</div>
            </div>
            <div className='hoem_inputBox'>
                <Form
                    name="basic"
                    labelCol={{ span: 5 }}
                    wrapperCol={{ span: 18 }}
                    style={{ maxWidth: 600 }}
                    initialValues={{ remember: true }}
                    onFinish={submitData}
                    onFinishFailed={onFinishFailed}
                    autoComplete="off"
                >
                    <Form.Item label="名称" name="username">
                        <Input placeholder="请输入名称!" />
                    </Form.Item>
                    <Form.Item label="界面路径" name="interfacePath">
                        <Input placeholder="请输入界面路径!" />
                    </Form.Item>

                    {/* 图片上传 */}
                    <Form.Item label="导航图标" name="logo">
                        <Upload
                            action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                            listType="picture-card"
                            fileList={fileList}
                            onPreview={handlePreview}
                            onChange={handleChange}
                        >
                            {fileList.length >= 1 ? null : uploadButton}
                        </Upload>
                        <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                            <img alt="example" style={{ width: '100%' }} src={previewImage} />
                        </Modal>
                    </Form.Item>

                    <Form.Item label="底部菜单" name="bottomMenu">
                        <Input placeholder="请输入底部菜单!" />
                    </Form.Item>

                    <Form.Item label="是否启用" name="enabledOrNot">
                        <Radio.Group>
                            <Radio value="apple"> 启用 </Radio>
                            <Radio value="pear"> 禁用 </Radio>
                        </Radio.Group>
                    </Form.Item>

                    <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                        <Button className='hoem_btn' size="middle" type="primary" htmlType="submit">提交</Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    )
}

export default HomePageNavigation;