import Hd from "../../Component/Hd";
import "./index.scss"
import Title from "../../Component/Title";
import {useEffect, useRef} from "react";
import {init} from "echarts"
import {useTranslation} from "react-i18next";


export default function Tokenomics() {
  let charts1 = useRef(null)
  const {t} = useTranslation()
  const charts1Data = [
    {name: "play the game to get", value: 80,},
    {name: "Marketing", value: 10,},
    {name: "team", value: 4.45,},
    {name: "prize pool", value: 0.1},
    {name: "Operation", value: 5},
    {name: "liquidity", value: 0.6},
    {name: "IGO", value: 0.25},
    {name: "Pre-sale", value: 0.2},
  ].map(item => {
    return {
      ...item,
      name: t("TOKENOMICS."+item.name)
    }
  })
  useEffect(() => {
    const width = document.body.clientWidth
    setTimeout(() => {
      if (charts1.current) {
        init(charts1.current).setOption({
          color: [
            {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                offset: 0, color: '#f28e26' // 0% 处的颜色
              }, {
                offset: 1, color: '#fd6640' // 100% 处的颜色
              }],
            },
            {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                offset: 0, color: '#fedc45' // 0% 处的颜色
              }, {
                offset: 1, color: '#fb7099' // 100% 处的颜色
              }],
            },
            {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                offset: 0, color: '#fad126' // 0% 处的颜色
              }, {
                offset: 1, color: '#ff554f' // 100% 处的颜色
              }],
            },
            {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                offset: 0, color: '#fd7a61' // 0% 处的颜色
              }, {
                offset: 1, color: '#7b7694' // 100% 处的颜色
              }],
            },
          ],
          series: [
            {
              type: 'pie',
              avoidLabelOverlap: false,
              radius: ['50%', '95%'],
              itemStyle: {
                borderRadius: 10,
                borderWidth: 5,
                borderColor: "#131922"
              },
              label: {
                show: false,
                position: 'center'
              },
              emphasis: {
                label: {
                  show: true,
                  fontSize: '16',
                  fontWeight: 'bold',
                  formatter: "{b}\n\n{c}%"
                }
              },
              labelLine: {
                show: false
              },
              data: [
                ...charts1Data
              ]
            }
          ]
        })
      }
    }, 500)
  }, [])
  return (
    <div id="tokenomics">
      <Title title="TOKENOMICS"/>
      <h1>
        {t("TOKENOMICS.FBW is the governance token of the football world.")}
        <br/>
        {t("TOKENOMICS.In the game, synthesizing new players, forging equipment and signing up for PVP all need to consume FBW, and most of these tokens will be burned. FBW can be purchased at pancakeswap or acquired in game PVP.")}
      </h1>
      <div className="charts1">
        <div className="left">
          {charts1Data.map((item, key) => {
            return (<div className="left-item" key={key}>
              <div className="line" style={{width: item.value + "%"}}/>
              <h1>{item.name} {item.value}%</h1>
            </div>)
          })}
        </div>
        <div className="right">
          <div ref={charts1} className="charts"/>
        </div>
      </div>
    </div>
  )
}