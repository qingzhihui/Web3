import React from 'react'

const AsyncComponent = () => {
  return (
    <div>AsyncComponent</div>
  )
}

export default AsyncComponent