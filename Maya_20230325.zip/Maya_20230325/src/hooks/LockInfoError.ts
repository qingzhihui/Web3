export interface LockError{
    tokenAddrError?:boolean,
    ownerAddrError?:boolean,
    amountError?:boolean,
    lockupError?:boolean,
    TGEpercentError?:boolean,
    cycleError?:boolean,
    cycleReleaseError?:boolean
}

