import Create from '@components/Community/Create'

export default Create
