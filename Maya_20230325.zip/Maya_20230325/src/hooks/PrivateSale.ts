import PrivateSaleABI from "../config/abi/PrivateSale.json";
import {
  FormatUnitsConver,
  InstancedContract,
  TimestampToTime,
} from "./config";
import { CycleBpsConversion, CycleConversion } from "./LockRecordInfo";
import { feeTokendecimalsPeon, percentConter } from "./Presale";
import { PrivateSaleFactoryABI, PrivateSaleFactoryAddress } from "./Sale";

export interface PrivateSalePropsType {
  Title?: string;
  tgeBps?: string;
  cycle?: string;
  cycleBps?: string;
  raisedAmount?: string;
  softCap?: string;
  hardCap?: string;
  Progress?: number;
  start?: string;
  end?: string;
  status?: number;
  address?: string;
  liquidityPercent?: string;
  lpLockTime?: string;
  presaleRate?: string;
  startString?: string;
  endString?: string;
}

export interface getAlloDataProps {
  address?: string;
  amount?: string;
}
export interface StartProps {
  start?: number;
  amount?: string;
  unlockedAmount?: string;
}
export interface ContributorsProps {
  key?: number;
  No?: number;
  Address?: string;
  Amount?: string;
}
export interface StatusProps {
  Status?: string;
  MinimumBuy?: string;
  MaximumBuy?: string;
  Totalibutors?: string;
  Youpurchased?: string;
  raisedAmount?: string;
}
export interface vluesProps {
  Address?: string;
  Amount?: string;
}

export const PrivateSaleContract = InstancedContract(
  PrivateSaleFactoryAddress,
  PrivateSaleFactoryABI
) as any;

const getPrivateSaleArrayLength = async () => {
  return await PrivateSaleContract.getPrivateSaleArrayLength();
};

const getPrivateSaleArray = async () => {
  return await PrivateSaleContract.getPrivateSaleArray();
};
const gettgeBps = async (PrivateContract: any) => {
  return await PrivateContract.tgeBps();
};
const getcycle = async (PrivateContract: any) => {
  return await PrivateContract.cycle();
};
const getcycleBps = async (PrivateContract: any) => {
  return await PrivateContract.cycleBps();
};
const getsoftCap = async (PrivateContract: any) => {
  return await PrivateContract.softCap();
};
const gethardCap = async (PrivateContract: any) => {
  return await PrivateContract.hardCap();
};
const getraisedAmount = async (PrivateContract: any) => {
  return await PrivateContract.raisedAmount();
};
const getStartTime = async (PrivateContract: any) => {
  return await PrivateContract.startTime();
};
const getendTime = async (PrivateContract: any) => {
  return await PrivateContract.endTime();
};
const getprivateSaleState = async (PrivateContract: any) => {
  return await PrivateContract.privateSaleState();
};
const getprivateSaleDetail = async (PrivateContract: any) => {
  return await PrivateContract.privateSaleDetail();
};
const feeTokenContract = async (PrivateContract: any) => {
  return await PrivateContract.currency();
};

const PrivatePromise = async (Address: string) => {
  const PrivateContract = InstancedContract(Address, PrivateSaleABI);
  return Promise.all([
    gettgeBps(PrivateContract),
    getcycle(PrivateContract),
    getcycleBps(PrivateContract),
    getsoftCap(PrivateContract),
    gethardCap(PrivateContract),
    getraisedAmount(PrivateContract),
    getStartTime(PrivateContract),
    getendTime(PrivateContract),
    getprivateSaleState(PrivateContract),
    getprivateSaleDetail(PrivateContract),
    feeTokenContract(PrivateContract),
  ]).then((res) => {
    return res;
  });
};
const PrivateDataPienSers = async (SersNumber: number, SersData: string[]) => {
  const getPrivateListData: PrivateSalePropsType[] = [];
  for (let index = 0; index < SersNumber; index++) {
    const getPrivateSaleData = await PrivatePromise(SersData[index]);
    const feeTokendecimals = await feeTokendecimalsPeon(
      getPrivateSaleData[10].toString()
    );
    const percent = percentConter(
      getPrivateSaleData[5].toString(),
      getPrivateSaleData[4].toString()
    );
    getPrivateListData.push({
      Title: getPrivateSaleData[9].split(",")[0],
      tgeBps: CycleBpsConversion(getPrivateSaleData[0].toString()).toString(),
      cycle: CycleConversion(getPrivateSaleData[1].toString()).toString(),
      cycleBps: CycleBpsConversion(getPrivateSaleData[2].toString()).toString(),
      softCap: FormatUnitsConver(getPrivateSaleData[3].toString(), 18),
      hardCap: FormatUnitsConver(getPrivateSaleData[4].toString(), 18),
      Progress: percent,
      start: (Number(getPrivateSaleData[6].toString()) * 1000).toString(),
      startString: TimestampToTime(getPrivateSaleData[6].toString()),
      endString: TimestampToTime(getPrivateSaleData[7].toString()),
      end: (Number(getPrivateSaleData[7].toString()) * 1000).toString(),
      status: getPrivateSaleData[8].toString(),
      raisedAmount: FormatUnitsConver(
        getPrivateSaleData[5].toString(),
        feeTokendecimals
      ),
      address: SersData[index],
    });
  }
  return getPrivateListData;
};

export {
  PrivateSaleABI,
  getPrivateSaleArrayLength,
  getPrivateSaleArray,
  PrivateDataPienSers,
};
