import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
const Home = React.lazy(() => import("../Page/Home"));
const SystemSettings = React.lazy(() => import("../Page/SystemSettings"));
const DatabaseConfigurationPage = React.lazy(
  () => import("../Page/DatabaseConfigurationPage")
);
const BasicSettingsPage = React.lazy(() => import("../Page/BasicSettingsPage"));
const PaymentSettings = React.lazy(() => import("../Page/PaymentSettings"));
const MailboxSettings = React.lazy(() => import("../Page/MailboxSettings"));
const Messagenotification = React.lazy(
  () => import("../Page/Messagenotification")
);
const HomePageNavigation = React.lazy(
  () => import("../Page/HomePageNavigation")
);
const SharePosterDesign = React.lazy(() => import("../Page/SharePosterDesign"));
const LogisticsFreightTemplate = React.lazy(
  () => import("../Page/LogisticsFreightTemplate")
);
const DataBackupPage = React.lazy(() => import("../Page/DataBackupPage"));
const RoleEmployeePower = React.lazy(() => import("../Page/RoleEmployeePower"));
const AdminManage = React.lazy(() => import("../Page/AdminManage"));
const UserManage = React.lazy(() => import("../Page/UserManage"));
const RoleManagement = React.lazy(() => import("../Page/RoleManagement"));
const PermissionManagement = React.lazy(
  () => import("../Page/PermissionManagement")
);
const EssayNotes = React.lazy(() => import("../Page/EssayNotes"));
const EssayClassifyManag = React.lazy(
  () => import("../Page/EssayClassifyManag")
);
const EssayDiscussManag = React.lazy(() => import("../Page/EssayDiscussManag"));
const AdvertisingManag = React.lazy(() => import("../Page/AdvertisingManag"));
const HotelManagement = React.lazy(() => import("../Page/HotelManagement"));
const HotelType = React.lazy(() => import("../Page/HotelType"));
const HotelList = React.lazy(() => import("../Page/HotelList"));
const AddHotel = React.lazy(() => import("../Page/AddHotel"));
const HotelGatherManage = React.lazy(() => import("../Page/HotelGatherManage"));
const HotelDataSinicization = React.lazy(
  () => import("../Page/HotelDataSinicization")
);
const CheckInManage = React.lazy(() => import("../Page/CheckInManage"));
const Management = React.lazy(() => import("../Page/Management"));
const Performance = React.lazy(() => import("../Page/Performance"));
const HotelPackage = React.lazy(() => import("../Page/HotelPackage"));
const MemberManagement = React.lazy(() => import("../Page/MemberManagement"));
const MemberManagePage = React.lazy(() => import("../Page/MemberManagePage"));
const PaidMember = React.lazy(() => import("../Page/PaidMember"));
const OrderManagement = React.lazy(() => import("../Page/OrderManagement"));
const HotelOrdersPage = React.lazy(() => import("../Page/HotelOrdersPage"));
const PackageOrder = React.lazy(() => import("../Page/PackageOrder"));
const MallOrder = React.lazy(() => import("../Page/MallOrder"));
const AfterSalesOrders = React.lazy(() => import("../Page/AfterSalesOrders"));
const OrderJournal = React.lazy(() => import("../Page/OrderJournal"));
const DistributionSystem = React.lazy(
  () => import("../Page/DistributionSystem")
);
const DistributionBasePz = React.lazy(
  () => import("../Page/DistributionBasePz")
);
const DistributorOrders = React.lazy(() => import("../Page/DistributorOrders"));
const DistributorListPage = React.lazy(
  () => import("../Page/DistributorListPage")
);
const DistributorWithdrawal = React.lazy(
  () => import("../Page/DistributorWithdrawal")
);
const DistributionRankings = React.lazy(
  () => import("../Page/DistributionRankings")
);
const MarketingActivities = React.lazy(
  () => import("../Page/MarketingActivities")
);
const EssayManagPage = React.lazy(() => import("../Page/EssayManagPage"));
const CouponPage = React.lazy(() => import("../Page/CouponPage"));
const FlashSale = React.lazy(() => import("../Page/FlashSale"));
const Rushtourse = React.lazy(() => import("../Page/Rushtourse"));
const Grourcase = React.lazy(() => import("../Page/Grourcase"));
const SeaMane = React.lazy(() => import("../Page/SeaMane"));
const PointsMall = React.lazy(() => import("../Page/PointsMall"));
const Passentick = React.lazy(() => import("../Page/Passentick"));
const NoPasen = React.lazy(() => import("../Page/404"));
const Login = React.lazy(() => import("../Page/Login"));
const ForgotPasswordPage = React.lazy(
  () => import("../Page/ForgotPasswordPage")
);
const Admin = React.lazy(() => import("../Page/Admin"));

const IndexRouter = () => {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/Login" />} />
      <Route path="/Login" element={<Login />} />
      <Route path="/Admin" element={<Admin />}>
        <Route index element={<Home />} />
        <Route path="/Admin/SystemSettings" element={<SystemSettings />}>
          <Route index element={<DatabaseConfigurationPage />} />
          <Route path="BasicSettingsPage" element={<BasicSettingsPage />} />
          <Route path="PaymentSettings" element={<PaymentSettings />} />
          <Route path="MailboxSettings" element={<MailboxSettings />} />
          <Route path="Messagenotification" element={<Messagenotification />} />
          <Route path="HomePageNavigation" element={<HomePageNavigation />} />
          <Route path="SharePosterDesign" element={<SharePosterDesign />} />
          <Route
            path="LogisticsFreightTemplate"
            element={<LogisticsFreightTemplate />}
          />
          <Route path="DataBackupPage" element={<DataBackupPage />} />
        </Route>
        <Route path="/Admin/RoleEmployeePower" element={<RoleEmployeePower />}>
          <Route index element={<AdminManage />} />
          <Route path="UserManage" element={<UserManage />} />
          <Route path="RoleManagement" element={<RoleManagement />} />
          <Route
            path="PermissionManagement"
            element={<PermissionManagement />}
          />
        </Route>
        <Route path="/Admin/EssayNotes" element={<EssayNotes />}>
          <Route index element={<EssayManagPage />} />
          <Route path="EssayClassifyManag" element={<EssayClassifyManag />} />
          <Route path="EssayDiscussManag" element={<EssayDiscussManag />} />
          <Route path="AdvertisingManag" element={<AdvertisingManag />} />
        </Route>
        <Route path="/Admin/HotelManagement" element={<HotelManagement />}>
          <Route index element={<HotelType />} />
          <Route path="HotelList" element={<HotelList />} />
          <Route path="AddHotel" element={<AddHotel />} />
          <Route path="HotelGatherManage" element={<HotelGatherManage />} />
          <Route
            path="HotelDataSinicization"
            element={<HotelDataSinicization />}
          />
          <Route path="CheckInManage" element={<CheckInManage />} />
          <Route path="Management" element={<Management />} />
        </Route>
        <Route path="/Admin/Performance" element={<Performance />} />
        <Route path="/Admin/HotelPackage" element={<HotelPackage />} />
        <Route path="/Admin/MemberManagement" element={<MemberManagement />}>
          <Route index element={<MemberManagePage />} />
          <Route path="PaidMember" element={<PaidMember />} />
        </Route>
        <Route path="/Admin/OrderManagement" element={<OrderManagement />}>
          <Route index element={<HotelOrdersPage />} />
          <Route path="PackageOrder" element={<PackageOrder />} />
          <Route path="MallOrder" element={<MallOrder />} />
          <Route path="AfterSalesOrders" element={<AfterSalesOrders />} />
          <Route path="OrderJournal" element={<OrderJournal />} />
        </Route>
        <Route
          path="/Admin/DistributionSystem"
          element={<DistributionSystem />}
        >
          <Route index element={<DistributionBasePz />} />
          <Route path="DistributorOrders" element={<DistributorOrders />} />
          <Route path="DistributorListPage" element={<DistributorListPage />} />
          <Route
            path="DistributorWithdrawal"
            element={<DistributorWithdrawal />}
          />
          <Route
            path="DistributionRankings"
            element={<DistributionRankings />}
          />
        </Route>
        <Route
          path="/Admin/MarketingActivities"
          element={<MarketingActivities />}
        >
          <Route index element={<CouponPage />} />
          <Route path="FlashSale" element={<FlashSale />} />
          <Route path="Rushtourse" element={<Rushtourse />} />
          <Route path="Grourcase" element={<Grourcase />} />
          <Route path="SeaMane" element={<SeaMane />} />
        </Route>
        <Route path="/Admin/PointsMall" element={<PointsMall />} />
        <Route path="/Admin/Passentick" element={<Passentick />} />
        <Route path="/Admin/404" element={<NoPasen />} />
        <Route path="*" element={<Navigate to="/404" />} />
      </Route>
      <Route path="/Anydoor" element={<Navigate to="/Admin" />} />
      <Route path="/ForgotPasswordPage" element={<ForgotPasswordPage />} />
    </Routes>
  );
};

export default IndexRouter;
