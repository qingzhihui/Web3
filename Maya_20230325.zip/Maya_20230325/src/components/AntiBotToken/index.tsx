import React, { useEffect, useState } from "react";
import { Form, Select } from "antd";
import { ethers } from "ethers";
import "../../styles/index.css";
import "../../styles/mobile.css";
import styles from "./index.module.css";
import { OptionList, dividendTracker } from "../../hooks/Token";
import { InstancedContract, DigitalConversion } from "../../hooks/config";
import { OptionItem } from "../../state/TokenState";
import StandardToken from "../Token/components/StandardToken";
import GeneratorToken from "../Token/components/GeneratorToken";
import BabyToken from "../Token/components/BabyToken";
import BuybackToken from "../Token/components/BuybackToken";
import { useTranslation, Trans } from "react-i18next";
import {
  Constan,
  AntiBotContract,
  AntiBotstandardTokenFactory,
  AntiBotstandardFactoryABI,
  AntiBotLGFactory,
  AntiBotLGFactoryABI,
  AntiBotBabyTokenFactory,
  AntiBotBabyTokenFactoryABI,
  AntiBotBuybackBabyFactory,
  AntiBotBuybackBabyFactoryABI,
} from "../../config/constants/constants";
import { PercentConversion } from "../../hooks/Createlock";

declare const window: Window & { ethereum: any };

const { Option } = Select;

interface BabyTokenProps {
  Createclick: (e: any) => void;
}
const AntiBotToken: React.FC<BabyTokenProps> = ({ Createclick }) => {
  const { t } = useTranslation();
  const [toekn, setToekn] = useState<string>("");
  const [createDisplay, seTcreateDisplay] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false)
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  let signer: any
  if (provider) {
    signer = provider.getSigner();
  }

  const [form] = Form.useForm();
  const StandardonClick = async (event: any) => {
    if (signer) {
      const ContractItem = Constan.filter((item: any) => {
        return item.Address === event.TokenPunie;
      });
      if (event.StandsData.UseAntiBot) {
        try {
          setLoading(true)
          const AntiBotStandardContract = InstancedContract(
            AntiBotstandardTokenFactory,
            AntiBotstandardFactoryABI
          ) as any;
          const flatFee = await AntiBotStandardContract.flatFee();
          const create = await AntiBotStandardContract.create(
            event.StandsData.Name,
            event.StandsData.Symbol,
            event.StandsData.Decimals,
            DigitalConversion(
              event.StandsData.Supply,
              event.StandsData.Decimals
            ),
            AntiBotContract,
            { value: flatFee }
          );
          await create.wait()
          setLoading(false)
        } catch (error) {
          setLoading(false)
        }
      } else {
        try {
          setLoading(true)
          const StandardTokenFactoryContract = InstancedContract(
            ContractItem[0].Address,
            ContractItem[0].Condebi
          ) as any;
          const flatFee = await StandardTokenFactoryContract.flatFee();
          const create = await StandardTokenFactoryContract.create(
            event.StandsData.Name,
            event.StandsData.Symbol,
            event.StandsData.Decimals,
            DigitalConversion(
              event.StandsData.Supply,
              event.StandsData.Decimals
            ),
            { value: flatFee }
          );
          await create.wait()
          setLoading(false)
        } catch (error) {
          setLoading(false)
        }
      }
    }
  };
  const GeneratorClick = async (event: any) => {
    if (signer) {
      const ContractItem = Constan.filter((item: any) => {
        return item.Address === event.TokenPunie;
      });
      if (event.StandsData.UseAntiBot) {
        try {
          setLoading(true)
          const AntiBotLGTokenFactoryContract = InstancedContract(
            AntiBotLGFactory,
            AntiBotLGFactoryABI
          ) as any;
          const flatFee = await AntiBotLGTokenFactoryContract.flatFee();
          let charityAddress;
          let charityPercent;
          if (event.StandsData.Wallet === '' || event.StandsData.Wallet === undefined) {
            charityAddress = "0x0000000000000000000000000000000000000000"
          } else {
            charityAddress = event.StandsData.Wallet;
          }
          if (event.StandsData.MarketingFee === '' || event.StandsData.MarketingFee === undefined) {
            charityPercent = "0"
          } else {
            charityPercent = event.StandsData.MarketingFee;
          }
          const create = await AntiBotLGTokenFactoryContract.create(
            event.StandsData.Name,
            event.StandsData.Symbol,
            DigitalConversion(event.StandsData.Supply, 9),
            event.StandsData.Router,
            charityAddress,
            PercentConversion(event.StandsData.YieldFee).toString(),
            PercentConversion(event.StandsData.LiquidityFee).toString(),
            PercentConversion(charityPercent).toString(),
            AntiBotContract,
            { value: flatFee }
          );
          await create.wait()
          setLoading(false)
        } catch (error) {
          setLoading(false)
        }
      } else {
        try {
          setLoading(true)
          const LGTokenFactoryContract = InstancedContract(
            ContractItem[0].Address,
            ContractItem[0].Condebi
          ) as any;
          const flatFee = await LGTokenFactoryContract.flatFee();
          let charityAddress;
          let charityPercent;
          if (event.StandsData.Wallet === '' || event.StandsData.Wallet === undefined) {
            charityAddress = "0x0000000000000000000000000000000000000000"
          } else {
            charityAddress = event.StandsData.Wallet;
          }
          if (event.StandsData.MarketingFee === '' || event.StandsData.MarketingFee === undefined) {
            charityPercent = "0"
          } else {
            charityPercent = event.StandsData.MarketingFee;
          }
          const create = await LGTokenFactoryContract.create(
            event.StandsData.Name,
            event.StandsData.Symbol,
            DigitalConversion(event.StandsData.Supply, 9),
            event.StandsData.Router,
            charityAddress,
            PercentConversion(event.StandsData.YieldFee).toString(),
            PercentConversion(event.StandsData.LiquidityFee).toString(),
            PercentConversion(charityPercent).toString(),
            { value: flatFee }
          );
          await create.wait()
          setLoading(false)
        } catch (error) {
          setLoading(false)
        }
      }
    }
  };
  const BodyClick = async (event: any) => {
    if (signer) {
      try {
        setLoading(true)
        const ContractItem = Constan.filter((item: any) => {
          return item.Address === event.TokenPunie;
        });
        if (event.StandsData.UseAntiBot) {
          const AntiBotBabyTokenFactoryContract = InstancedContract(
            AntiBotBabyTokenFactory,
            AntiBotBabyTokenFactoryABI
          ) as any;
          const flatFee = await AntiBotBabyTokenFactoryContract.flatFee();
          const address = await signer.getAddress();
          const create = await AntiBotBabyTokenFactoryContract.create(
            address,
            event.StandsData.Name,
            event.StandsData.Symbol,
            DigitalConversion(event.StandsData.Supply, 18),
            [
              event.StandsData.RewardToken,
              event.StandsData.Router,
              event.StandsData.Wallet,
              dividendTracker,
            ],
            [
              event.StandsData.RewardFee,
              event.StandsData.LiquidityFee,
              event.StandsData.MarketingFee,
            ],
            DigitalConversion(event.StandsData.Dividends, 18),
            AntiBotContract,
            { value: flatFee }
          );
          await create.wait()
          setLoading(false)
        } else {
          const BabyTokenFactoryContract = InstancedContract(
            ContractItem[0].Address,
            ContractItem[0].Condebi
          ) as any;
          const flatFee = await BabyTokenFactoryContract.flatFee();
          const address = await signer.getAddress();
          const create = await BabyTokenFactoryContract.create(
            address,
            event.StandsData.Name,
            event.StandsData.Symbol,
            DigitalConversion(event.StandsData.Supply, 18),
            [
              event.StandsData.RewardToken,
              event.StandsData.Router,
              event.StandsData.Wallet,
              dividendTracker,
            ],
            [
              event.StandsData.RewardFee,
              event.StandsData.LiquidityFee,
              event.StandsData.MarketingFee,
            ],
            DigitalConversion(event.StandsData.Dividends, 18),
            { value: flatFee }
          );
          await create.wait()
          setLoading(false)
        }
      } catch (error) {
        setLoading(false)
      }
    }
  };
  const BuybackClick = async (event: any) => {
    if (signer) {
      try {
        setLoading(true)
        const ContractItem = Constan.filter((item: any) => {
          return item.Address === event.TokenPunie;
        });
        if (event.StandsData.UseAntiBot) {
          const AntiBotBuybackTokenFactoryContract = InstancedContract(
            AntiBotBuybackBabyFactory,
            AntiBotBuybackBabyFactoryABI
          ) as any;
          const flatFee = await AntiBotBuybackTokenFactoryContract.flatFee();
          const create = await AntiBotBuybackTokenFactoryContract.create(
            event.StandsData.Name,
            event.StandsData.Symbol,
            DigitalConversion(event.StandsData.Supply, 18),
            event.StandsData.RewardToken,
            event.StandsData.Router,
            [
              PercentConversion(event.StandsData.LiquidityFee),
              PercentConversion(event.StandsData.BuyBackFee),
              PercentConversion(event.StandsData.ReflectionFee),
              PercentConversion(event.StandsData.MarketingFee),
              10000,
            ],
            AntiBotContract,
            { value: flatFee }
          );
          await create.wait()
          setLoading(false)
        } else {
          setLoading(true)
          const BuybackTokenFactoryContract = InstancedContract(
            ContractItem[0].Address,
            ContractItem[0].Condebi
          ) as any;
          const flatFee = await BuybackTokenFactoryContract.flatFee();
          const create = await BuybackTokenFactoryContract.create(
            event.StandsData.Name,
            event.StandsData.Symbol,
            DigitalConversion(event.StandsData.Supply, 18),
            event.StandsData.RewardToken,
            event.StandsData.Router,
            [
              PercentConversion(event.StandsData.LiquidityFee),
              PercentConversion(event.StandsData.BuyBackFee),
              PercentConversion(event.StandsData.ReflectionFee),
              PercentConversion(event.StandsData.MarketingFee),
              10000,
            ],
            { value: flatFee }
          );
          await create.wait()
          setLoading(false)
        }
      } catch (error) {
        setLoading(false)
      }
    }
  };
  const CreateContent = (Createkey: Number) => {
    switch (Createkey) {
      case 0:
        return <StandardToken Token={toekn} StandardonAdd={StandardonClick} loading={loading} />;
      case 1:
        return <GeneratorToken Token={toekn} GeneratorAdd={GeneratorClick} loading={loading} />;
      case 2:
        return <BabyToken Token={toekn} BodyAdd={BodyClick} loading={loading} />;
      case 3:
        return <BuybackToken Token={toekn} BuybackAdd={BuybackClick} loading={loading} />;
      default:
    }
  };
  const OnClickSelectCreate = (standarEvent: string) => {
    OptionItem.filter((Opitem: OptionList) => {
      if (Opitem.value === standarEvent) {
        seTcreateDisplay(Opitem.key);
        return Opitem;
      }
    });
    setToekn(standarEvent);
  };
  useEffect(() => { }, [createDisplay]);
  return (
    <div className={styles.create} style={{ height: "600px" }}>
      <div className={styles.requireTitle}>(*){`${t("is required field.")}`}</div>
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Token Type")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Form form={form}>
          <Form.Item name="请选择对应的" rules={[{ required: true }]}>
            <Select
              placeholder={`${t("Select Token Type")}`}
              onChange={(value: string) => {
                OnClickSelectCreate(value);
              }}
              allowClear
            >
              {OptionItem.map((item: OptionList) => (
                <Option key={item.key} value={item.value}>
                  {`${t(item.label)}`}
                </Option>
              ))}
            </Select>
          </Form.Item>
        </Form>
        {CreateContent(createDisplay)}
      </div>
    </div>
  );
};

export default AntiBotToken;
