import React, { useEffect, useState } from "react";
import "./index.scss";
import { Button, notification } from "antd";
import { ethers } from "ethers";
import Header from "../../components/Header";
import bing from "../../assets/buing.png";
import Heues from "../../components/Heues";
import { VOTE_ADDRESS, VOTE_ABI } from "../../redux/Contract/voteContract";
import { CheckCircleOutlined, LoadingOutlined } from "@ant-design/icons";
import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../../redux/Contract/contractApp";
import List from "../../redux/UsJson/Colest.json";
import Item from "antd/lib/list/Item";
declare const window: Window & { ethereum: any };

function Index() {
  const [pendsBuels, setPendsBuels] = useState([]);
  const key = "updatable";

  const openNotification2 = (bindValue: any, durn: any, icon: any) => {
    notification.open({
      key,
      message: "Tips",
      description: bindValue,
      duration: durn,
      icon: icon,
    });
  };
  const Nusbeis = async (id: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const voteContract = new ethers.Contract(VOTE_ADDRESS, VOTE_ABI, signer);
    const viuet = await voteContract.claim(id);
    openNotification2(
      "领取中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await viuet.wait();
    openNotification2(
      "领取成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
    privote();
  };

  const privote = async () => {
    const Buelsit: any = [];
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const voteContract = new ethers.Contract(VOTE_ADDRESS, VOTE_ABI, signer);
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    List.map(async (item: any) => {
      const pendingVotes = await voteContract.getPendingVotes(item.id, addr);
      const pldata = await Contract.userInfo(item.id, addr);
      const votes = await voteContract.getTotalClaimedVotes(addr);
      Buelsit.push({
        id: item.id,
        code: item.code,
        Lp:
          parseFloat(ethers.utils.formatEther(pendingVotes.toString())),
        lpnur: ethers.utils.formatEther(pldata.depositAmount.toString()),
        votes:
          parseFloat(ethers.utils.formatEther(votes.toString())),
        name: item.name,
      });
    });

    setTimeout(() => {
      // const buie: any = [];
      // Buelsit.map(async (item: any) => {
      //   if (item.id == 2) {
      //     const pendingVotes = await voteContract.getPendingVotes(
      //       item.id,
      //       addr
      //     );
      //     item.Lp =
      //       parseFloat(ethers.utils.formatEther(pendingVotes.toString())) *
      //       100000000;
      //   }
      //   buie.push(item);
      // });
      // setTimeout(() => {
      //   setPendsBuels(buie);
      // }, 500);
      const busei = Buelsit.filter((msg: any) => {
        return (msg.id == 0);
      });

      // setPendsBuels(Buelsit);
      setPendsBuels(busei);
    }, 1000);
  };
  useEffect(() => {
    const ahsdr = localStorage.getItem("addr");
    if (ahsdr !== null && ahsdr !== undefined) {
      privote();
    }
  }, []);
  return (
    <div className="Vote">
      <Header />
      <div className="sbyeri">
        {pendsBuels.length !== 0 ? (
          <>
            {pendsBuels.map((item: any) => (
              <div className="bsueing" key={item.id}>
                <div className="bsue_title">
                  领取选票
                  <div className="iteNuer">{item.name} LP</div>
                </div>
                <div className="luneri">
                  <div className="luitem1">
                    <div className="nsuebig">
                      <img src={bing} alt="" />
                      <span>质押数量</span>
                      <div className="nuspro">
                        {item.code.substring(0, 4) +
                          "..." +
                          item.code.substring(38, 42)}
                      </div>
                    </div>
                    <div className="nusjk">{item.lpnur}</div>
                  </div>
                  <div className="luitem2">
                    <div className="nsuebig">
                      <img src={bing} alt="" />
                      <span>可领票数</span>
                    </div>
                    <div className="nusjk">{item.Lp}</div>
                  </div>
                  <div className="luitem1">
                    <div className="nsuebig">
                      <img src={bing} alt="" />
                      <span>已领票数</span>
                    </div>
                    <div className="nusjk">{item.votes}</div>
                  </div>
                </div>
                <div className="butone">
                  {item.Lp > 0 ? (
                    <Button
                      onClick={() => {
                        Nusbeis(item.id);
                      }}
                    >
                      领取
                    </Button>
                  ) : (
                    <div className="nuBut">
                      <Button disabled>领取</Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </>
        ) : (
          <div className="bsueing">
            <div className="bsue_title">领取选票</div>
            <div className="luneri">
              <div className="luitem1">
                <div className="nsuebig">
                  <img src={bing} alt="" />
                  <span>质押数量</span>
                  <div className="nuspro">
                    {/* {item.code.substring(0, 4) +
                            "..." +
                            item.code.substring(38, 42)} */}
                    0x00...000
                  </div>
                </div>
                <div className="nusjk">0.0</div>
              </div>
              <div className="luitem2">
                <div className="nsuebig">
                  <img src={bing} alt="" />
                  <span>可领票数</span>
                </div>
                <div className="nusjk">0.0</div>
              </div>
              <div className="luitem1">
                <div className="nsuebig">
                  <img src={bing} alt="" />
                  <span>已领票数</span>
                </div>
                <div className="nusjk">0.0</div>
              </div>
            </div>
            <div className="butone">
              <div className="nuBut">
                <Button disabled>领取</Button>
              </div>
            </div>
          </div>
        )}
      </div>
      <Heues />
    </div>
  );
}

export default Index;
