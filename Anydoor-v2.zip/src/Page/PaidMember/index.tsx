import {
  Button,
  Checkbox,
  Col,
  Form,
  Input,
  Modal,
  Radio,
  Row,
  Select,
  SelectProps,
  Space,
  Table,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";
import PaidMemberList from "./PaidMemberList";

import { DeleteOutlined, FormOutlined } from "@ant-design/icons";
import { CheckboxValueType } from "antd/es/checkbox/Group";
import { createRef, useState } from "react";

// 付费会员界面
const PaidMember = () => {
  const [isPaidMemberList, setPaidMemberList] = useState(false);
  const [isReviseTableData, setReviseTableData] = useState(false);

  const FormRef = createRef<any>();

  // 付费会员办理记录--对话框关闭
  const PaidMemberListClose = () => {
    setPaidMemberList(false);
  };
  // 修改表格数据--关闭
  const ReviseTableDataClose = () => {
    setReviseTableData(false);
  };

  interface DataType {
    key: number;
    paidMemberName: string; //付费会员名称
    sellingPrice: string; //销售价格
    billingMethod: string; //计费方式
    dealWithPeopleNum: number; //办理人数
    status: string; //状态
    createTime: string; //创建时间
  }
  const data: DataType[] = [
    {
      key: 1,
      paidMemberName: "黄金会员",
      sellingPrice: "1.00",
      billingMethod: "按自然月",
      dealWithPeopleNum: 2,
      status: "点击禁用",
      createTime: "2023-01-01",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "付费会员名称",
      dataIndex: "paidMemberName",
      // width:80,
    },
    {
      title: "销售价格",
      dataIndex: "sellingPrice",
      // width:120,
    },
    {
      title: "计费方式",
      dataIndex: "billingMethod",
      // width:280,
    },
    {
      title: "办理人数",
      width: 120,
      dataIndex: "dealWithPeopleNum",
    },
    {
      title: "状态",
      // width:120,
      dataIndex: "status",
      render: (_text, record) => (
        <Space size="middle">
          <span className="statusBorder" onClick={clickForbidden(record)}>
            {_text}
          </span>
        </Space>
      ),
    },
    {
      title: "创建时间",
      // width:120,
      dataIndex: "createTime",
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="memberCursor" onClick={uploadus(record)}>
            <FormOutlined />
          </span>
          <span className="memberCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];
  // 下拉选择框-会员类型-内容
  const options1 = [
    {
      value: "1",
      label: "白银",
    },
    {
      value: "2",
      label: "黄金",
    },
  ];

  // 下拉选择-会员类型---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log("会员类型", value);
  };
  // 下拉选择框-会员打折-内容
  const options2 = [
    {
      value: "1",
      label: "打折",
    },
    {
      value: "2",
      label: "不打折",
    },
  ];

  // 下拉选择-会员类型---选中内容
  const handleChange2 = (value: { value: string; label: React.ReactNode }) => {
    console.log("会员类型", value);
  };
  // 多选选中内容
  const onSelected = (checkedValues: CheckboxValueType[]) => {
    console.log("多选中的内容 = ", checkedValues);
  };

  const options3: SelectProps["options"] = [];

  const handleChange3 = (value: string) => {
    console.log(`selected ${value}`);
  };
  // 点击付费会员办理记录
  const ClickPaidMemberList = () => {
    console.log("点击了付费会员办理记录");
    setPaidMemberList(true);
  };

  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 修改
  const uploadus = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record.key);
      setReviseTableData(true);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };

  // 点击禁用
  const clickForbidden = (record: any) => {
    return () => {
      console.log("点击了禁用");
      console.log(record.key);
    };
  };

  //  修改-提交按钮
  const onReviseSubmitBtn = (values: any) => {
    console.log("修改提交的数据", values);
    FormRef.current.resetFields();
  };

  return (
    <div className="member_Box">
      <div className="member_headerBox">
        <div className="member_headerBox_thread"></div>
        <div className="member_headerBox_Tit">&nbsp;&nbsp;&nbsp; 付费会员</div>
        <div className="member_Add_moban">
          {/* <div className="member_usernameInpuit">
            <Input placeholder="请输入昵称" />
          </div> */}
          <div className="member_seekBtn" onClick={ClickPaidMemberList}>
            付费会员办理记录
          </div>
          {/* 付费会员办理记录--对话框显示 */}
          <Modal
            className="member_dialogBox"
            footer={[null]}
            open={isPaidMemberList}
            onCancel={PaidMemberListClose}
          >
            <PaidMemberList />
          </Modal>
          <div className="member_seekBtn" onClick={adminSearch}>
            添加会员配置信息
          </div>
        </div>
      </div>

      <div className="member_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
        {/* 修改 */}
        <Modal
          className="member_dialogBox"
          footer={[null]}
          open={isReviseTableData}
          onCancel={ReviseTableDataClose}
        >
          <div className="member_headerBox">
            <div className="member_headerBox_thread"></div>
            <div className="member_headerBox_Tit">
              &nbsp;&nbsp;&nbsp; 付费会员
            </div>
          </div>
          <div className="member_tableBox">
            <Form
              name="basic"
              ref={FormRef}
              labelCol={{ span: 7 }}
              wrapperCol={{ span: 17 }}
              style={{ maxWidth: 700 }}
              initialValues={{ remember: true }}
              onFinish={onReviseSubmitBtn}
              autoComplete="off"
            >
              <Form.Item label="付费会员类型" name="paidMemberType">
                <Select
                  placeholder="请选择"
                  labelInValue
                  style={{ width: 120 }}
                  onChange={handleChange1}
                  options={options1}
                />
              </Form.Item>
              <Form.Item label="套餐价格" name="packagePrice">
                <Input placeholder="请填写套餐价格" />
              </Form.Item>
              <Form.Item label="计费方式" name="billingMethod">
                <Radio.Group>
                  <Radio value="1"> 按自然月 </Radio>
                  <Radio value="2"> 按周期 </Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item label="计费周期" name="BillingCycle">
                <Input placeholder="请选择计费周期,如:30,表示30天" />
              </Form.Item>
              <Form.Item label="会员则扣" name="Deduction">
                <Select
                  placeholder="请选择"
                  labelInValue
                  style={{ width: 120 }}
                  onChange={handleChange2}
                  options={options2}
                />
              </Form.Item>
              <Form.Item label="会员服务" name="memberServices">
                <Checkbox.Group style={{ width: "100%" }} onChange={onSelected}>
                  <Row>
                    <Col span={12}>
                      <Checkbox value="免费早餐-最多2份/间">
                        免费早餐-最多2份/间
                      </Checkbox>
                    </Col>
                    <Col span={12}>
                      <Checkbox value="积分奖励-1元积2分">
                        积分奖励-1元积2分
                      </Checkbox>
                    </Col>
                    <Col span={12}>
                      <Checkbox value="积分奖励-1元积1.5分">
                        积分奖励-1元积1.5分
                      </Checkbox>
                    </Col>
                    <Col span={12}>
                      <Checkbox value="积分奖励-1元积1.2分">
                        积分奖励-1元积1.2分
                      </Checkbox>
                    </Col>
                    <Col span={12}>
                      <Checkbox value="延迟退房-40次/年">
                        延迟退房-40次/年
                      </Checkbox>
                    </Col>
                    <Col span={12}>
                      <Checkbox value="免费升级-8次/年">
                        免费升级-8次/年
                      </Checkbox>
                    </Col>
                    <Col span={12}>
                      <Checkbox value="预定保留-23点">预定保留-23点</Checkbox>
                    </Col>
                  </Row>
                </Checkbox.Group>
              </Form.Item>
              <Form.Item label="添加首次购买获得的优惠价" name="coupon">
                <Select
                  mode="tags"
                  style={{ width: "100%" }}
                  placeholder="Tags Mode"
                  onChange={handleChange3}
                  options={options3}
                />
              </Form.Item>
              <Form.Item label="首次购买赠送积分" name="integral">
                <Input placeholder="请填写首次购买赠送积分" />
              </Form.Item>
              <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                <Button
                  className="Gather_btn"
                  size="middle"
                  type="primary"
                  htmlType="submit"
                >
                  提交
                </Button>
              </Form.Item>
            </Form>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default PaidMember;
