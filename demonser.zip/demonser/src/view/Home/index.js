import { ethers } from "ethers";
import React, { useEffect, useState } from "react";
import "./index.scss";
import loges from "../../assets/enlues/jss.png";
import gb from "../../assets/gb.png";
import toxing from "../../assets/toxiang.png";
import luby from "../../assets/lbuy.png";
import maoti from "../../assets/maoti.png";
import WalletConnect from "../../assets/Wallet.png";
import guangb from "../../assets/gb.png";
import c1 from "../../assets/cf.gif";
import c2 from "../../assets/cf2.png";
import c3 from "../../assets/cf3.png";
import WalletConnectProvider from "@walletconnect/web3-provider";
import { withRouter } from "react-router-dom";
import { ShakeHard, ShakeVertical, ShakeHorizontal } from "reshake";
import Lodeing from "../../components/Lodeing";


import { Web3Provider } from "@ethersproject/providers";

function Home(props) {
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState("");
  const [display, setdisplay] = useState(false);
  const [logshow, setLogshow] = useState(false);
  const [web3Library, setWeb3Library] = React.useState();
  const [web3Account, setWeb3Account] = React.useState();
  const [walletConnectProvider, setWalletConnectProvider] = React.useState();
  const [lsLoading, setlsLoading] = useState(true);
  const [dohuShow, setdohuShow] = useState(true);
  const [videoe, setVideoe] = useState(false);

  let currentAccount = null;
  const sliensds = () => {
    setdisplay(true);
  };
  const Showlu = () => {
    setdisplay(false);
  };
  const initSwitch = async () => {
    const provider = window.ethereum;
    const chainId = await provider.request({ method: "eth_chainId" });
    const binanceTestChainId = "0x4";
    if (chainId === binanceTestChainId) {
      console.log("Bravo!, you are on the correct network");
      initConnection();
      setdisplay(false);
    } else {
      console.log("oulalal, switch to the correct network");
      try {
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: binanceTestChainId }],
        });
        console.log("You have succefully switched to Rinkeby Test network");
        initConnection();
      } catch (switchError) {
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [
                {
                  chainId: "0x4",
                  chainName: "Rinkeby - Testnet",
                  nativeCurrency: {
                    name: "Rinkeby",
                    symbol: "RIN",
                    decimals: 18,
                  },
                  blockExplorerUrls: ["https://rinkeby.etherscan.io/"],
                  rpcUrls: [
                    "https://rinkeby.infura.io/v3/55d040fb60064deaa7acc8e320d99bd4/",
                  ],
                },
              ],
            });
          } catch (addError) {
            console.error(addError);
          }
        }
        console.log("Failed to switch to the network");
      }
    }
  };
  const initConnection = async () => {
    if (typeof window.ethereum !== "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const addr = await signer.getAddress();
      setAddress(addr);
      sessionStorage.setItem("addr", addr);
      const bal = await provider.getBalance(addr);
      setBalance(ethers.utils.formatEther(bal));
      console.log(ethers.utils.formatEther(bal));
      setdisplay(false);
      console.log("You have connected your wallet");
    } else {
      console.log("Please install metamask.");
    }
  };
  const disconnect = async () => {
    window.location.reload();
  };
  const linseu = () => {
    setLogshow(true);
  };
  const locStubKun = () => {
    setLogshow(false);
  };
  const Sguanbi = () => {
    setdisplay(false);
  };
  const connectWaletConnect = async () => {
    try {
      const RPC_URLS = {
        1: "https://mainnet.infura.io/v3/55d040fb60064deaa7acc8e320d99bd4",
        4: "https://rinkeby.infura.io/v3/55d040fb60064deaa7acc8e320d99bd4",
      };
      const provider = new WalletConnectProvider({
        rpc: {
          1: RPC_URLS[1],
          4: RPC_URLS[4],
        },
        qrcode: true,
        pollingInterval: 15000,
      });
      setWalletConnectProvider(provider);
      const accounts = await provider.enable();
      const account = accounts[0];

      const library = new Web3Provider(provider, "any");
      setWeb3Library(library);
      setWeb3Account(account);
    } catch (ex) {
      console.log(ex);
    }
  };
  const handleAccountsChanged = (accounts) => {
    if (accounts.length === 0) {
      console.log("Please connect to Rinkeby Chain Wallet.");
    } else if (accounts[0] !== currentAccount) {
      currentAccount = accounts[0];
      setAddress(currentAccount);
      setdisplay(false);
    }
  };
  const initBinance = () => {
    window.BinanceChain.request({ method: "eth_requestAccounts" })
      .then(handleAccountsChanged)
      .catch((err) => {
        if (err.code === 4001) {
          console.log("Please connect to MetaMask.");
        } else {
          console.error(err);
        }
      });
  };
  const liebaiM3 = () => {
    props.history.push("/mint");
  };
  const liebaAubi = () => {
    props.history.push("/about");
  };
  window.onload = function () {
    var cfeng = document.querySelector(".cfeng");
    cfeng.onclick = function () {
      cfeng.style.webkitAnimation = "move 3s";
    };
    cfeng.addEventListener(
      "webkitAnimationEnd",
      function () {
        setdohuShow(false);
      },
      false
    );
  };
  const videoHide = () => {
    setVideoe(false);
  };
  const videoShow = () => {
    console.log("123");
    setVideoe(true);
  };
  useEffect(() => {
    setTimeout(() => {
      setlsLoading(false);
      if (dohuShow) {
        setdohuShow(false);
      } else {
        setdohuShow(false);
      }
    }, 1500);
    const width = document.documentElement.clientWidth;
    const height = document.documentElement.clientHeight;
    if (width < height) {
      setdohuShow(false);
    }
  }, []);

  return (
    <div className="LiGHeadr">
      {lsLoading ? (
        <Lodeing />
      ) : (
        <>
          <div className="Header">
            <div className="tobuhai">
              <div className="toblift">
                <ShakeHard>
                  <div className="nuselu1">
                    <a href="https://twitter.com/rektclubnft" target="_blank">
                      <button className="button1"></button>
                    </a>
                  </div>
                </ShakeHard>
                <ShakeHard>
                  <div
                    className="nuselu1"
                    onClick={() => {
                      videoShow();
                    }}
                  >
                    <button className="button2"></button>
                  </div>
                </ShakeHard>
                <ShakeHard>
                  <div className="nuselu1">
                    <a href="https://opensea.io/" target="_blank">
                      <button className="button3"></button>
                    </a>
                  </div>
                </ShakeHard>
              </div>
              <div className="nbses">
                {dohuShow ? (
                  <div className="dato">
                    <div className="wdpting">
                      <img src={c3} alt="" />
                    </div>
                    <div className="cfeng" id="cfeng">
                      <img src={c1} alt="" />
                    </div>
                    <div className="cfeng2">
                      <img src={c2} alt="" />
                    </div>
                  </div>
                ) : (
                  <div className="lsisnsjpw">
                    <div className="lsliner1">
                      <div className="guago"></div>
                      <div
                        className="liner"
                        onClick={() => {
                          liebaAubi();
                        }}
                      >
                        <div className="liner_zlie"></div>
                      </div>
                    </div>

                    <div className="linerzho">
                      <ShakeVertical>
                        <img src={loges} />
                      </ShakeVertical>
                    </div>

                    <div className="lsliner2">
                      <div className="guago"></div>
                      <div
                        className="liner2"
                        onClick={() => {
                          liebaiM3();
                        }}
                      >
                        <div className="liner_zlie2"></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="toblret">
                <div className="iteusfelo">
                  {address == "" ? (
                    <div className="itbtnns">
                      <ShakeHorizontal>
                        <button onClick={() => sliensds()}></button>
                      </ShakeHorizontal>
                    </div>
                  ) : (
                    <div className="itbtnns">
                      <div className="itbtnro">
                        <div className="itbtnroimg">
                          <img src={toxing} alt="" />
                        </div>
                        <div className="itbtnrotuil">
                          <span>
                            {address.substring(0, 4) +
                              "..." +
                              address.substring(38, 42)}
                          </span>
                        </div>
                        <div
                          className="itbtnrokul"
                          onClick={() => {
                            disconnect();
                          }}
                        >
                          <span>DISCONNECT</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                {display ? (
                  <div className="dabuos">
                    <div className="sinuyse" onClick={() => Showlu()}></div>
                    <div className="siebsi">
                      <div className="lsiens">
                        <div className="suebxedu">
                          <img src={luby} alt="" />
                          <img src={loges} alt="" />
                        </div>

                        <div className="tipoens" onClick={() => Sguanbi()}>
                          <img src={guangb} alt="" />
                        </div>
                      </div>
                      <div className="lsibki">
                        <div className="slienus" onClick={() => initSwitch()}>
                          <div className="stilo">
                            <img src={maoti} alt="" />
                          </div>
                          <div className="stilotil">
                            <span>MetaMask</span>
                          </div>
                        </div>
                        <div
                          className="slienus"
                          onClick={() => connectWaletConnect()}
                        >
                          <div className="stilo">
                            <img src={WalletConnect} alt="" />
                          </div>
                          <div className="stilotil">
                            <span>WalletConnect</span>
                          </div>
                        </div>

                        {/* {logshow ? (
                      <>
                        <div className="slienus" onClick={() => initBinance()}>
                          <div className="stilo">
                            <img src={Binance} />
                          </div>
                          <div className="stilotil">
                            <span>Binance Wallet</span>
                          </div>
                        </div>
                        <div className="slienus" onClick={() => initSwitch()}>
                          <div className="stilo">
                            <img src={Token} />
                          </div>
                          <div className="stilotil">
                            <span>TokenPocket</span>
                          </div>
                        </div>
                        <div className="slienus" onClick={() => locStubKun()}>
                          <div className="stiloslis">
                            <img src={shoqin} />
                          </div>
                          <div className="stilotil">
                            <span>Put away</span>
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className="slienus" onClick={() => linseu()}>
                        <div className="stiloslis">
                          <img src={Gduole} />
                        </div>
                        <div className="stilotil">
                          <span>More</span>
                        </div>
                      </div>
                    )} */}
                      </div>
                    </div>
                  </div>
                ) : (
                  ""
                )}
              </div>
            </div>
            <div className="liebsub">
              <div className="liebai1">
                <div className="biej"></div>
                <div className="bsub1"></div>
                <div className="bsub2">{/* <img src={plseimg} /> */}</div>
                <div className="bsub3"></div>
                <div className="bsub4"></div>
              </div>
              <div className="liebai2">
                <div className="liebaiM1"></div>
                <div className="liebaiM2"></div>
                <div
                  className="liebaiM3"
                  onClick={() => {
                    liebaiM3();
                  }}
                ></div>
                <div className="liebaiM4"></div>
              </div>
              <div className="liebai3">
                <div className="liebaiS1"></div>
                <div className="liebaiS3"></div>
                <div className="liebaiS2"></div>
                <div className="liebaiS4"></div>
              </div>
              <div className="relisert">
                <span>ABOUT EMOER</span>
              </div>
            </div>
          </div>
          {videoe ? (
            <div className="snueeLOser">
              <div className="suelsie">
                <div className="snuelsie">
                  <div className="snuelsie_letf">
                    <img src={luby} alt="" />
                    <div className="ssineimg">
                      <img src={loges} alt="" />
                    </div>
                  </div>
                  <div
                    className="snuelsie_reft"
                    onClick={() => {
                      videoHide();
                    }}
                  >
                    <img src={gb} alt="" />
                  </div>
                </div>
                <iframe
                  width="100%"
                  height="500px"
                  src="https://www.youtube.com/embed/37ljM86tdOc"
                  title="REKTCLUB"
                  frameborder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowfullscreen
                ></iframe>
              </div>
            </div>
          ) : (
            ""
          )}
        </>
      )}
    </div>
  );
}
export default withRouter(Home);
