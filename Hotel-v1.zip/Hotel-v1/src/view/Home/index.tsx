import React from "react";

function Home() {
  return (
    <div>
      <div>Home</div>
    </div>
  );
}

export default Home;
