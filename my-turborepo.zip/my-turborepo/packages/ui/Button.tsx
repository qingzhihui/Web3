import * as React from "react";

export const Button = () => {
  return <button>Boop</button>;
};
