// vue 源码中的一个函数

/*
* 从 x 到 y,数据是否发生了变化
* */

// x值为1，y的值为2   （1-2有变化返回true）
// x:{a:1} y{x:3} x到y有变化又返回true
// x:{a:1} x:{a:1} 如果相同就要看他们是不是同一个对象地址，
// 是同一个地址的话就返回false没有变化，相反不是同一个地址就返回true 表示有变化
export function hasChanged(x, y) {
    if (x === y) {
        return x === 0 && 1 / x !== 1 / y;
    } else {
        return x === x || y === y;
    }
}