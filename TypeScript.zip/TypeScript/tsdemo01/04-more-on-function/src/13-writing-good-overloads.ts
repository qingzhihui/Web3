// // 重載签名
// function len(s: string): number;
// function len(arr: any[]): number;

// // 实现签名
// function len(x: any) {
//   return x.length;
// }

function len(x:any[] | string){
    return x.length
}
len("hello");
len([1, 2, 3]);
len(Math.random() > 0.5 ? "hello" : [4, 5, 6]);
