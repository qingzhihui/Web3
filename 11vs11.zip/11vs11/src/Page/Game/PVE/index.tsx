import "./index.scss"
import {Swiper, SwiperSlide} from "swiper/react";
import {Navigation} from "swiper";
import i1 from "./img/striker.png"
import i2 from "./img/Midfield.png"
import i3 from "./img/Defender.png"
import i4 from "./img/Goalkeeper.png"

export default function PVE() {
  return (
    <>
    <div style={{
      marginTop: "25px",
      display: "flex",
      justifyContent: "center"
    }}>
      <button className="common-btn">COMMING SOON</button>
    </div>
    <div id="pve">
      <div style={{display: "none"}} className="list">
        <img src="/img/pre.png" className="pre" alt=""/>
        <img src="/img/next.png" className="next" alt=""/>
        <Swiper
          slidesPerView={1}
          spaceBetween={15}
          modules={[Navigation]}
          navigation={{
            prevEl: "#pve .pre",
            nextEl: "#pve .next"
          }}
          breakpoints={{
            900: {
              slidesPerView: 2
            }
          }}
        >
          <SwiperSlide className="item">
            <div className="top-tip">Lv1 - lv5</div>
            <div className="title">
              <div className="left">Striker</div>
              <div className="right">
                <img src="/img/BABY.webp" alt=""/>
                <img src="/img/milk_light.webp" alt=""/>
                <img src="/img/KEY.webp" alt=""/>
              </div>
            </div>
            <img src={i1} alt=""/>
            <div className="p">
              The first groups of Dark Force on planet are those Swans? They are not the normal ones!! We heard that Black Swan would bring bad lucks and destroy the whole planet’s fatality. Let’s fight against the Black Swans!
            </div>
            <div className="p">
              Possible Enemies: Young Black Swan, Grown Black Swan, King of Black Swans
            </div>
            <div className="p">
              Loot Items: MILK, Player, Keys
            </div>
            <div className="common-btn">Choose</div>
          </SwiperSlide>
          <SwiperSlide className="item">
            <div className="top-tip">Lv1 - lv5</div>
            <div className="title">
              <div className="left">Midfield</div>
              <div className="right">
                <img src="/img/BABY.webp" alt=""/>
                <img src="/img/milk_light.webp" alt=""/>
                <img src="/img/KEY.webp" alt=""/>
              </div>
            </div>
            <img src={i2} alt=""/>
            <div className="p">
              The first groups of Dark Force on planet are those Swans? They are not the normal ones!! We heard that Black Swan would bring bad lucks and destroy the whole planet’s fatality. Let’s fight against the Black Swans!
            </div>
            <div className="p">
              Possible Enemies: Young Black Swan, Grown Black Swan, King of Black Swans
            </div>
            <div className="p">
              Loot Items: MILK, Player, Keys
            </div>
            <div className="common-btn">Choose</div>
          </SwiperSlide>
          <SwiperSlide className="item">
            <div className="top-tip">Lv1 - lv5</div>
            <div className="title">
              <div className="left">Defender</div>
              <div className="right">
                <img src="/img/BABY.webp" alt=""/>
                <img src="/img/milk_light.webp" alt=""/>
                <img src="/img/KEY.webp" alt=""/>
              </div>
            </div>
            <img src={i3} alt=""/>
            <div className="p">
              The first groups of Dark Force on planet are those Swans? They are not the normal ones!! We heard that Black Swan would bring bad lucks and destroy the whole planet’s fatality. Let’s fight against the Black Swans!
            </div>
            <div className="p">
              Possible Enemies: Young Black Swan, Grown Black Swan, King of Black Swans
            </div>
            <div className="p">
              Loot Items: MILK, Player, Keys
            </div>
            <div className="common-btn">Choose</div>
          </SwiperSlide>
          <SwiperSlide className="item">
            <div className="top-tip">Lv1 - lv5</div>
            <div className="title">
              <div className="left">Goalkeeper</div>
              <div className="right">
                <img src="/img/BABY.webp" alt=""/>
                <img src="/img/milk_light.webp" alt=""/>
                <img src="/img/KEY.webp" alt=""/>
              </div>
            </div>
            <img src={i4} alt=""/>
            <div className="p">
              The first groups of Dark Force on planet are those Swans? They are not the normal ones!! We heard that Black Swan would bring bad lucks and destroy the whole planet’s fatality. Let’s fight against the Black Swans!
            </div>
            <div className="p">
              Possible Enemies: Young Black Swan, Grown Black Swan, King of Black Swans
            </div>
            <div className="p">
              Loot Items: MILK, Player, Keys
            </div>
            <div className="common-btn">Choose</div>
          </SwiperSlide>
        </Swiper>
      </div>
    </div>
    </>
  )
}