import { ILisnt } from "./MultiSender";
const ArrayspLitting = (dataArrays: any) => {
  const data: ILisnt[] = [];
  dataArrays.map((item: any, index: number) => {
    data.push({
      key: index,
      address: item.split(",")[0],
      binale: item.split(",")[1],
    });
  });
  return data;
};

export { ArrayspLitting };
