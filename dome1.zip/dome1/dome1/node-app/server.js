const express = require("express");
const app = express();

var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var WXBizDataCrypt = require("./WXBizDataCrypt");
var axios = require("axios");

app.get("/", (req, res) => {
  res.send("Hello World !");
});
app.get("/v1/getPhoneNumber", async function (req, res) {
  let { iv, encryptedData, appid, secret, code } = req.query;
  let result = await axios({
    url:
      "https://api.weixin.qq.com/sns/jscode2session?appid=" +
      appid +
      "&secret=" +
      secret +
      "&js_code=" +
      code +
      "&grant_type=authorization_code",
    method: "GET",
  });
  var pc = new WXBizDataCrypt(appid, result.data.session_key);
    var data = pc.decryptData(encryptedData, iv);
  console.log(pc);
  res.send({ value: data });
});

const port = process.env.PORT || 5000;

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
