/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect } from "react";
import "./index.scss";
import { Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import {
  FormatUnitsConver,
  InstancedContract,
  TimestampToTime,
} from "../../hooks/config";
import {
  CycleConversion,
  CycleBpsConversion,
  RecordDataInterface,
  LockInfoProps,
} from "../../hooks/LockRecordInfo";
import { useHistory } from "react-router-dom";
import { CreatelockABI, CreatelockAddress } from "../../hooks/Createlock";
import { Token0Props, Token1Props } from "../../hooks/lpLockInfo";
import { useTranslation, Trans } from "react-i18next";
const paginationProps = {
  showSizeChanger: true,
  showQuickJumper: true,
  pageSize: 6,
};


const lpLocksRecord: React.FC = (props: any) => {
  let history = useHistory();
  const { t } = useTranslation();
  const [LockRecordata, setLockRecorData] = useState([]);
  const [LockInfo, setLockInfo] = useState<any>({});
  const [Token0, setToken0] = useState<Token0Props>({});
  const [Token1, setToken1] = useState<Token1Props>({});
  const [amount,setAmount] = useState("")

  const columns: ColumnsType<RecordDataInterface> = [
    {
      title: `${t("Wallet")}`,
      dataIndex: "Wallet",
      render: (text) => (
        <div>{text.substring(0, 4) + "..." + text.substring(38, 42)}</div>
      ),
    },
    {
      title: `${t("Amount")}`,
      dataIndex: "Amount",
    },
    {
      title: `${t("UnlockTime")}`,
      dataIndex: "UnlockTime",
    },
    {
      title: `${t("Cycle (minutes)")}`,
      dataIndex: "Cycle",
    },
    {
      title: `${t("Cycle_Release")}(%)`,
      dataIndex: "Cycle_Release",
    },
    {
      title: "TGE(%)",
      dataIndex: "TGE",
    },
    {
      title: `${t("Action")}`,
      key: "action",
      render: (_, record) => (
        <button
          className="view"
          onClick={() => {
            ActionViewOnClick(record);
          }}
        >
          {`${t("view")}`}
        </button>
      ),
    },
  ];
  const getLocksForTokenData = async (address: string, decimals: number) => {
    const Contract = InstancedContract(CreatelockAddress, CreatelockABI)  as any;
    const totalLockCountForToken = await Contract.totalLockCountForToken(
      address
    );
    const getLocksForToken = await Contract.getLocksForToken(
      address,
      0,
      totalLockCountForToken.toString()
    );
    const RecordData: RecordDataInterface[] = [];
    getLocksForToken.map(async (item: any, index: number) => {
      RecordData.push({
        key: index,
        Wallet: item.owner,
        TokenID: item.id.toString(),
        Amount: FormatUnitsConver(item.amount.toString(), decimals),
        UnlockTime: TimestampToTime(item.tgeDate.toString()),
        Cycle: CycleConversion(item.cycle.toString()),
        unlockt:item.tgeDate.toString(),
        Cycle_Release: CycleBpsConversion(item.cycleBps.toString()),
        TGE: CycleBpsConversion(item.tgeBps.toString()),
      });
    });
    setTimeout(() => {
      let _OwnedItem = JSON.parse(JSON.stringify(RecordData));
      setLockRecorData((a: any) => {
        return _OwnedItem.length === 0 ? a : _OwnedItem;
      });
    }, 500);
  };
  const ActionViewOnClick = (data: any) => {
    history.push({
      pathname: "/lpLockInfo",
      state: {
        TokenID: data.TokenID,
        TokenAddress: LockInfo.addres as string,
        Wallet: data.Wallet,
        LockInfo: LockInfo,
        Unlock: data.unlockt
      },
    });
  };
  useEffect(() => {
    if (props.location.state != undefined) {
      const { TokenList, amount } = props.location.state;
      const { token0, token1 } = TokenList;
      setToken0((Token0prevState: any) => {
        return (Token0prevState = token0);
      });
      setToken1((Tokens1prevState: any) => {
        return (Tokens1prevState = token1);
      });
      getLocksForTokenData(TokenList.addres, TokenList.decimals);
      setLockInfo((LockInfoprevState: any) => {
        return (LockInfoprevState = TokenList);
      });
      setAmount((AmountState: any) => {
        return (AmountState = amount);
      })
    }
  }, []);

  return (
    <div className="lock-info">
      <div className="Info">
        <div className="updatelock-tableItem updatalock-title">{`${t("Lock Info")}`}111</div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Current Lock Amount")}`}</span>
            <span className="tableItem-name ">
              {amount || ""} LP{" "}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Current Values Lock")}`}</span>
            <span className="tableItem-name ">$0</span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Liquidity Address")}`}</span>
            <span className="tableItem-name TokenAddress">
              {(LockInfo.addres as string) || ""}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("Pair Name")}`}</span>
            <span className="tableItem-name">
              {(Token0.token0Symbol as string) || ""} /{" "}
              {(Token1.token1Symbol as string) || ""}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
        <div className="updatelock-tableItem">
          <div className="tableItem-text">
            <span className="tableItem-title">{`${t("factory address")}`}</span>
            <span className="tableItem-title">
              {(LockInfo.factory as string) || ""}
            </span>
          </div>
          <div className="tableItem-line" />
        </div>
      </div>

      <div className="Record">
        <div className="updatelock-tableItem updatalock-title">{`${t("Lock Record")}`}</div>
        <Table
          columns={columns}
          loading={LockRecordata.length === 0 ? true : false}
          dataSource={LockRecordata}
          size="middle"
          pagination={paginationProps}
        />
      </div>
    </div>
  );
};
export default lpLocksRecord;
