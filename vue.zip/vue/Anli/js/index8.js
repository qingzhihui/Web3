//可组合的散列数值


//使用二进制位(不同的二进制位来表达不同的权限)

// 1.表达权限
//可新增
const CREATE = 0b0001;
//可删除
const DELETE = 0b0010;
//可修改
const UPDATE = 0b0100;
// 可预览详情
const DETAIL = 0b1000;
// 结合使用或运算
const result = CREATE | DELETE | DETAIL;
console.log(result.toString(2))


// 2.判断权限(依然使用二进制远算)
console.log((result & DELETE) === DELETE);
console.log(result & DELETE);
console.log(0b0010)


//思考题
// 怎么删除权限