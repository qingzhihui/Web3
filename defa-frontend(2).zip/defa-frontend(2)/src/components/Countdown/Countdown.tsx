import React, { useState, useRef, useEffect, Fragment } from 'react'
import moment from 'moment'
import { useTranslation } from 'contexts/Localization'
// 组件四、时间组件
const Countdown = (props: any) => {
  const { t } = useTranslation()
  const [current, setTime] = useState('0 天 0 时 0 分 0 秒')
  const [days, setdays] = useState('')
  const [hours, sethours] = useState('')
  const [minutes, setminutes] = useState('0 天 0 时 0 分 0 秒')
  const [seconds, setseconds] = useState('')
  const timerID: any = useRef()
  const deadLine = moment(props.nalei)
  const deadLineTime = deadLine.diff(moment())
  let durationTime = moment.duration(deadLineTime)
  let isArrived = deadLineTime < 0

  useEffect(() => {
    timerID.current = setInterval(() => {
      let arriveTime = `${durationTime.days()} 天 ${durationTime.hours()} 时 ${durationTime.minutes()} 分 ${durationTime.seconds()} 秒`
      setdays(`${durationTime.days()}`)
      sethours(`${durationTime.hours()}`)
      setminutes(`${durationTime.minutes()}`)
      setseconds(`${durationTime.seconds()}`)
      if (!isArrived) {
        durationTime = moment.duration(deadLine.diff(moment()))
        setTime(() => arriveTime) // make pretty
      }
    }, 1000)
  }, [])

  useEffect(() => {
    if (isArrived) {
      clearInterval(timerID.current)
    }
  })
  // <div>{current} 后开放</div>
  return (
    <div>
      {days} <Fragment> {t('Days')} </Fragment>
      {hours} <Fragment> {t('Hous')} </Fragment>
      {minutes}
      <Fragment> {t('Mins')} </Fragment>
      {seconds} <Fragment> {t('Second')} </Fragment> {t('Opened')}
    </div>
  )
}

export default Countdown
