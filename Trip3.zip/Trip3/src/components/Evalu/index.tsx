import React from 'react'
import './index.scss'

export default function index() {
  return (
    <div className='evalu'>
      <div className='evalutop'>
        <div className='evaluinfo'>
          <img src={require('@/assets/image/ellipse.png')} alt="" />
          <div>
            <div className='name'>Matt Galligan</div>
            <div className='evdate'>Published on November 11, 2022</div>
          </div>
        </div>
        <div className='evalubut'><img src={require('@/assets/image/diamond.png')} alt="" /> 5.0 / 5</div>
      </div>
      <div className='evalumiddle'>It's a super hotel. We originally booked a room for 3 days. We stayed for 6 days. The hotel helped upgrade different room types. Before check-in, we turned on the heating and air purifier in the room. Once we entered the room, it was warm and there was no smell. Thanks to the little brothers and sisters of the hotel for allowing us to spend a few days of happiness and peace of mind. Next time I will choose Aman Summer Palace.</div>
      <div className='evaluimgs'>
        <img src={require('@/assets/image/evaluimg.png')} alt="" />
        <img src={require('@/assets/image/evaluimg.png')} alt="" />
        <img src={require('@/assets/image/evaluimg.png')} alt="" />
        <img src={require('@/assets/image/evaluimg.png')} alt="" />
      </div>
    </div>
  )
}
