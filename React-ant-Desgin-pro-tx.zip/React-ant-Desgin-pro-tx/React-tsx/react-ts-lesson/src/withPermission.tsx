import React, { Component, ComponentType } from "react";
interface IPermission {
  permission: string;
}
const permissionSet = new Set(["add", "delete"]);
function withPermission<T>(Permissions: ComponentType<T & IPermission>) {
  return class extends Component<T & IPermission> {
    render(): React.ReactNode {
      return (
        <>
          {permissionSet.has(this.props.permission) ? (
            <Permissions {...this.props} />
          ) : null}
        </>
      );
    }
  };
}

export default withPermission;
