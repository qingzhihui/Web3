<template>

</template>

<script setup>
// $0.scrollTo(0,100)
</script>

<style>
html {
  scroll-behavior: smooth;
}
</style>
