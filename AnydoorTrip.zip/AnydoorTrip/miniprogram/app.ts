// app.ts
App<IAppOption>({
  globalData: {},
  onLaunch() {
  },
})