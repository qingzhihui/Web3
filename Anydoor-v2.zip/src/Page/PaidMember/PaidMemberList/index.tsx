import { Space, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import "./index.css";

// 付费会员对话框
const PaidMemberList = () => {
  interface DataType2 {
    key: number;
    username: string; //用户名
    grade: string; //会员等级
    purchaseTime: string; //购买时间
    termOfValidity: string; //有效期至
  }
  const data2: DataType2[] = [
    {
      key: 1,
      username: "微信用户123",
      grade: "黄金会员",
      purchaseTime: "2023-01-01 00:00:00",
      termOfValidity: "2023-02-01 00:00:00",
    },
  ];

  const columns2: ColumnsType<DataType2> = [
    {
      title: "用户名",
      dataIndex: "username",
      // width:80,
    },
    {
      title: "会员等级",
      dataIndex: "grade",
      // width:120,
    },
    {
      title: "购买时间",
      dataIndex: "purchaseTime",
      // width:280,
    },
    {
      title: "有效期至",
      //   width: 120,
      dataIndex: "termOfValidity",
    },
  ];
  return (
    <div>
      <div className="pmlHeaderBox">
        <div className="pmlHeaderBoxThread"></div>
        <div className="pmlMemberHeaderBoxTit">&nbsp;&nbsp;&nbsp; 付费会员</div>
      </div>
      <div className="pmlTableBox">
        <Table
          columns={columns2}
          dataSource={data2}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default PaidMemberList;
