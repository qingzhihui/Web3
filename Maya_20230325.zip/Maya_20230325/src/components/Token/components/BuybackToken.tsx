import React, { useEffect, useState } from "react";
import { Checkbox, Input, Form, Select } from "antd";
import type { CheckboxChangeEvent } from "antd/es/checkbox";
import "../../../styles/index.css";
import "../../../styles/mobile.css";
import styles from "../index.module.css";
import {
  BabyTokenList,
  DigitalInput,
  DisableDoubleCharacters,
  OptionList
} from "../../../hooks/Token";
import { isAddress } from "../../../utils/address";
import { BabyTokenItem, RouterOptionItem } from "../../../state/TokenState";
import { useTranslation, Trans } from "react-i18next";
import { Constan } from "../../../config/constants/constants";
import { FormatUnitsConver, InstancedContract } from "../../../hooks/config";
import InputError from "../../InputError";
import { floatformat, posInvFormat } from "../../../utils/floatFormat";
import { BuybackTokenError } from "../../../hooks/Errorhandle";
import { BigNumber, ethers } from "ethers";
import ButtonLoading from "../../ButtonLoading";
import { BuybackTokenErrorInitState } from "../../../state/BuybackTokenErrorState";
declare const window: Window & { ethereum: any };

const { Option } = Select;

interface BabackTokenProps {
  Token: string;
  loading: boolean;
  BuybackAdd: (e: any) => void;
}
const BabackTokenProps: React.FC<BabackTokenProps> = ({ Token, BuybackAdd, loading }) => {
  const { t } = useTranslation();
  const [BuybackNer, setBuybackNer] = useState<BabyTokenList>(BabyTokenItem);
  const [flatFeeShow, setFlatFeeShow] = useState("");
  //Liquidity Fee
  const [buyBackError, setBuyBackError] = useState<BuybackTokenError>(BuybackTokenErrorInitState);

  const setError = (key: string, value: boolean) => {
    setBuyBackError((olddata: BuybackTokenError) => {
      return {
        ...olddata,
        [key]: value,
      };
    });
  };

  const isCreated = () => {
    if (
      !buyBackError.NameBlankError
      && !buyBackError.NameCharactersError
      && !buyBackError.SymbolBlankError
      && !buyBackError.SymbolCharactersError
      && !buyBackError.TotalSupplyBlankError
      && !buyBackError.TotalSupplyAmountError
      && !buyBackError.RewardTokenBlankError
      && !buyBackError.RewardTokenInvalidError
      && !buyBackError.LiquidityFeeBlankError
      && !buyBackError.LiquidityFeeMinError
      && !buyBackError.BuybackFeeBlankError
      && !buyBackError.BuybackFeeMinError
      && !buyBackError.ReflectionFeeBlankError
      && !buyBackError.ReflectionFeeMinError
      && !buyBackError.MarketingFeeBlankError
      && !buyBackError.MarketingFeeMinError
      && !buyBackError.FeeOverError
      && BuybackNer.Name
      && BuybackNer.Symbol
      && BuybackNer.Supply
      && BuybackNer.Router
      && BuybackNer.RewardToken
      && BuybackNer.LiquidityFee
      && BuybackNer.BuyBackFee
      && BuybackNer.ReflectionFee
      && BuybackNer.MarketingFee
    ) {
      return true
    } else {
      return false
    }
  }

  const [form] = Form.useForm();
  const StandardCreateOnClikc = () => {
    BuybackAdd({
      TokenPunie: Token,
      StandsData: BuybackNer,
    });
  };
  const OnClickSelectCreate = (standarEvent: string) => {
    RouterOptionItem.filter((Opitem: OptionList) => {
      if (Opitem.value === standarEvent) {
        setBuybackNer((olddata: BabyTokenList) => {
          return {
            ...olddata,
            Router: Opitem.value,
          };
        });
      }
    });
  };
  const NameValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DisableDoubleCharacters(e);
    if (inputChange !== undefined) {
      setBuybackNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("NameBlankError", true)
        } else {
          setError("NameBlankError", false)
        }
        if (inputChange && inputChange.length < 2) {
          setError("NameCharactersError", true)
        } else {
          setError("NameCharactersError", false)
        }
        return {
          ...olddata,
          Name: inputChange,
        };
      })
    }
  };
  const SymbolValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DisableDoubleCharacters(e);
    if (inputChange !== undefined) {
      setBuybackNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("SymbolBlankError", true)
        } else {
          setError("SymbolBlankError", false)
        }
        if (inputChange && inputChange.length < 2) {
          setError("SymbolCharactersError", true)
        } else {
          setError("SymbolCharactersError", false)
        }
        return {
          ...olddata,
          Symbol: inputChange,
        };
      });
    }
  };
  const SupplyValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = DigitalInput(e);
    setBuybackNer((olddata: BabyTokenList) => {
      if (inputChange === '') {
        setError("TotalSupplyBlankError", true)
      } else {
        setError("TotalSupplyBlankError", false)
      }
      if (inputChange !== undefined && inputChange !== '') {
        if (BigNumber.from(inputChange).gte(BigNumber.from(10).pow(25))) {
          setError("TotalSupplyAmountError", true)
        } else {
          setError("TotalSupplyAmountError", false)
        }
      }
      return {
        ...olddata,
        Supply: inputChange
      };
    });
  };
  const RewardTokenValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBuybackNer((olddata: BabyTokenList) => {
      if (e.target.value === "") {
        setError("RewardTokenBlankError", true)
      } else {
        setError("RewardTokenBlankError", false)
      }
      if (!isAddress(e.target.value) && e.target.value) {
        setError("RewardTokenInvalidError", true)
      } else {
        setError("RewardTokenInvalidError", false)
      }
      return {
        ...olddata,
        RewardToken: e.target.value,
      };
    })
  };
  const LiquidityFeeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setBuybackNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("LiquidityFeeBlankError", true)
        } else {
          setError("LiquidityFeeBlankError", false)
        }
        if (inputChange && Number(inputChange) < 0.01) {
          setError("LiquidityFeeMinError", true)
        } else {
          setError("LiquidityFeeMinError", false)
        }
        if (inputChange && BuybackNer.BuyBackFee && BuybackNer.MarketingFee) {
          if (Number(inputChange) + Number(BuybackNer.BuyBackFee) + Number(BuybackNer.ReflectionFee) + Number(BuybackNer.MarketingFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          LiquidityFee: inputChange
        };
      });
    }
  };
  const BuybackFeeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setBuybackNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("BuybackFeeBlankError", true)
        } else {
          setError("BuybackFeeBlankError", false)
        }
        if (inputChange && Number(inputChange) < 0.01) {
          setError("BuybackFeeMinError", true)
        } else {
          setError("BuybackFeeMinError", false)
        }
        if (inputChange && BuybackNer.BuyBackFee && BuybackNer.MarketingFee) {
          if (Number(inputChange) + Number(BuybackNer.LiquidityFee) + Number(BuybackNer.ReflectionFee) + Number(BuybackNer.MarketingFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          BuyBackFee: inputChange
        };
      });
    }
  };
  const ReflectionFeeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setBuybackNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("ReflectionFeeBlankError", true)
        } else {
          setError("ReflectionFeeBlankError", false)
        }
        if (inputChange && Number(inputChange) < 1) {
          setError("ReflectionFeeMinError", true)
        } else {
          setError("ReflectionFeeMinError", false)
        }
        if (inputChange && BuybackNer.BuyBackFee && BuybackNer.LiquidityFee) {
          if (Number(inputChange) + Number(BuybackNer.LiquidityFee) + Number(BuybackNer.BuyBackFee) + Number(BuybackNer.MarketingFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          ReflectionFee: inputChange
        };
      });
    }
  };
  const MarketingFeeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputChange = floatformat(e.target.value);
    if (inputChange !== undefined) {
      setBuybackNer((olddata: BabyTokenList) => {
        if (inputChange === '') {
          setError("MarketingFeeBlankError", true)
        } else {
          setError("MarketingFeeBlankError", false)
        }
        if (inputChange && Number(inputChange) < 1) {
          setError("MarketingFeeMinError", true)
        } else {
          setError("MarketingFeeMinError", false)
        }
        if (inputChange && BuybackNer.BuyBackFee && BuybackNer.LiquidityFee) {
          if (Number(inputChange) + Number(BuybackNer.BuyBackFee) + Number(BuybackNer.LiquidityFee) + Number(BuybackNer.ReflectionFee) > 25) {
            setError("FeeOverError", true)
          } else {
            setError("FeeOverError", false)
          }
        } else {
          setError("FeeOverError", false)
        }
        return {
          ...olddata,
          MarketingFee: inputChange
        };
      });
    }
  };
  const NameBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("NameBlankError", true)
      } else {
        setError("NameBlankError", false)
      }
      if (e.target.value && e.target.value.length < 2) {
        setError("NameCharactersError", true)
      } else {
        setError("NameCharactersError", false)
      }
    }
  };
  const SymbolBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("SymbolBlankError", true)
      } else {
        setError("SymbolBlankError", false)
      }
      if (e.target.value && e.target.value.length < 2) {
        setError("SymbolCharactersError", true)
      } else {
        setError("SymbolCharactersError", false)
      }
    }
  };
  const SupplyBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      setError("TotalSupplyBlankError", true)
    } else {
      setError("TotalSupplyBlankError", false)
    }
    if (e.target.value !== undefined && e.target.value !== '') {
      if (BigNumber.from(e.target.value).gte(BigNumber.from(10).pow(25))) {
        setError("TotalSupplyAmountError", true)
      } else {
        setError("TotalSupplyAmountError", false)
      }
    }
  }
  const RewardTokenBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === "") {
      setError("RewardTokenBlankError", true)
    } else {
      setError("RewardTokenBlankError", false)
    }
    if (!isAddress(e.target.value) && e.target.value) {
      setError("RewardTokenInvalidError", true)
    } else {
      setError("RewardTokenInvalidError", false)
    }
  };
  const LiquidityFeeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("LiquidityFeeBlankError", true)
      } else {
        setError("LiquidityFeeBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 0.01) {
        setError("LiquidityFeeMinError", true)
      } else {
        setError("LiquidityFeeMinError", false)
      }
      if (e.target.value && BuybackNer.BuyBackFee && BuybackNer.MarketingFee) {
        if (Number(e.target.value) + Number(BuybackNer.BuyBackFee) + Number(BuybackNer.ReflectionFee) + Number(BuybackNer.MarketingFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const BuybackFeeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("BuybackFeeBlankError", true)
      } else {
        setError("BuybackFeeBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 0.01) {
        setError("BuybackFeeMinError", true)
      } else {
        setError("BuybackFeeMinError", false)
      }
      if (e.target.value && BuybackNer.BuyBackFee && BuybackNer.MarketingFee) {
        if (Number(e.target.value) + Number(BuybackNer.LiquidityFee) + Number(BuybackNer.ReflectionFee) + Number(BuybackNer.MarketingFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const ReflectionFeeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("ReflectionFeeBlankError", true)
      } else {
        setError("ReflectionFeeBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 1) {
        setError("ReflectionFeeMinError", true)
      } else {
        setError("ReflectionFeeMinError", false)
      }
      if (e.target.value && BuybackNer.BuyBackFee && BuybackNer.LiquidityFee) {
        if (Number(e.target.value) + Number(BuybackNer.LiquidityFee) + Number(BuybackNer.BuyBackFee) + Number(BuybackNer.MarketingFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const MarketingFeeBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== undefined) {
      if (e.target.value === '') {
        setError("MarketingFeeBlankError", true)
      } else {
        setError("MarketingFeeBlankError", false)
      }
      if (e.target.value && Number(e.target.value) < 1) {
        setError("MarketingFeeMinError", true)
      } else {
        setError("MarketingFeeMinError", false)
      }
      if (e.target.value && BuybackNer.BuyBackFee && BuybackNer.LiquidityFee) {
        if (Number(e.target.value) + Number(BuybackNer.BuyBackFee) + Number(BuybackNer.LiquidityFee) + Number(BuybackNer.ReflectionFee) > 25) {
          setError("FeeOverError", true)
        } else {
          setError("FeeOverError", false)
        }
      } else {
        setError("FeeOverError", false)
      }
    }
  };
  const getCreateBuybackTokenFlatFee = async () => {
    const BuybackTokenFacctoryContract = InstancedContract(
      Constan[0].Address,
      Constan[0].Condebi
    ) as any;
    const flatFee = await BuybackTokenFacctoryContract.flatFee();
    setFlatFeeShow(FormatUnitsConver(flatFee.toString(), 18));
  };
  useEffect(() => { }, [flatFeeShow]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        getCreateBuybackTokenFlatFee();
      }
    }
  }, []);
  return (
    <div className="StandardToken">
      <div className={styles.tulieng}>
        <div className={styles.createfee}>{`${t("Token creation fee:")}`} {flatFeeShow || 0} BNB</div>
        <div className={styles.require}>{`${t("Name")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder={`${t("Ex: Ethereum")}`}
          className={styles.addrInput}
          value={BuybackNer.Name as string}
          style={{ borderColor: buyBackError.NameBlankError || buyBackError.NameCharactersError ? "#f14668" : "" }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            NameValueChange(e);
          }}
          onBlur={(e) => {
            NameBlurChange(e);
          }}
        />
      </div>
      {buyBackError.NameBlankError ? <InputError title="Name cannot be blank" /> : ''}
      {buyBackError.NameCharactersError ? <InputError title="Name must be at least 2 characters" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Symbol")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder={`${t("Ex: ETH")}`}
          className={styles.addrInput}
          value={BuybackNer.Symbol as string}
          style={{ borderColor: buyBackError.SymbolBlankError || buyBackError.SymbolCharactersError ? "#f14668" : "" }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            SymbolValueChange(e);
          }}
          onBlur={(e) => {
            SymbolBlurChange(e);
          }}
        />
      </div>
      {buyBackError.SymbolBlankError ? <InputError title="Symbol cannot be blank" /> : ''}
      {buyBackError.SymbolCharactersError ? <InputError title="Symbol must be at least 2 characters" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>{`${t("Total supply")}`}<span style={{ color: "#f95192" }}> *</span></div>
        <Input
          placeholder={`${t("Ex: 100000000000")}`}
          className={styles.addrInput}
          value={BuybackNer.Supply as string}
          style={{ borderColor: buyBackError.TotalSupplyBlankError || buyBackError.TotalSupplyAmountError ? "#f14668" : "" }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            SupplyValueChange(e);
          }}
          onBlur={(e) => {
            SupplyBlurChange(e);
          }}
        />
      </div>
      {buyBackError.TotalSupplyBlankError ? <InputError title="Total supply cannot be blank" /> : ''}
      {buyBackError.TotalSupplyAmountError ? <InputError title="Invalid total supply" /> : ''}
      <div className={styles.tulieng}>
        <div className={styles.require}>
          {`${t("Router")}`}
          <span style={{ color: "#f95192" }}> *</span>
        </div>
        <Form form={form}>
          <Form.Item name="请选择对应的" rules={[{ required: true }]} initialValue={`${t("Pancakeswap")}`}>
            <Select
              placeholder={`${t("Select Router Exchange")}`}
              onChange={(value: string) => {
                OnClickSelectCreate(value);
              }}
              options={RouterOptionItem}
            >
              {RouterOptionItem.map((item: OptionList) => (
                <Option key={item.key} value={item.value}>
                  {item.label}
                </Option>
              ))}
            </Select>
          </Form.Item>
        </Form>
      </div>
      <div className={styles.auoieng}>
        <div className={styles.tulieng} style={{ width: "50%" }}>
          <div className={styles.require}>{`${t("Reward token")}`}<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder={`${t("Ex: 0x....")}`}
            value={BuybackNer.RewardToken as string}
            style={{ borderColor: buyBackError.RewardTokenBlankError || buyBackError.RewardTokenInvalidError ? "#f14668" : "" }}
            className={styles.addrInput}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              RewardTokenValueChange(e);
            }}
            onBlur={(e) => {
              RewardTokenBlurChange(e);
            }}
          />
        </div>
        <div className={styles.auolItem}>
          <div className={styles.require}>{`${t("Liquidity Fee")}`} (%)<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder="0 - 100"
            className={styles.addrInput}
            value={BuybackNer.LiquidityFee as string}
            style={{ borderColor: buyBackError.LiquidityFeeBlankError || buyBackError.LiquidityFeeMinError ? "#f14668" : "" }}
            onChangeCapture={(e: React.ChangeEvent<HTMLInputElement>) => {
              LiquidityFeeValueChange(e);
            }}
            onBlur={(e) => {
              LiquidityFeeBlurChange(e);
            }}
          />
        </div>
      </div>
      <div className="sbuyeisn">
        <div className="sbuyeisnItem">
          {buyBackError.RewardTokenBlankError ? <InputError title="Reward token cannot be blank" /> : ''}
          {buyBackError.RewardTokenInvalidError ? <InputError title="Invalid reward token" /> : ''}
        </div>
        <div className="sbuyeisnItem">
          {buyBackError.LiquidityFeeBlankError ? <InputError title="Liquidity Fee cannot be blank" /> : ''}
          {buyBackError.LiquidityFeeMinError ? <InputError title="Liquidity Fee must be greater than or equal to 0.01" /> : ''}
        </div>
      </div>
      <div className={styles.auoieng}>
        <div className={styles.auolItem}>
          <div className={styles.require}>{`${t("Buyback Fee")}`} (%)<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder="0 - 100"
            className={styles.addrInput}
            style={{ borderColor: buyBackError.BuybackFeeBlankError || buyBackError.BuybackFeeMinError ? "#f14668" : "" }}
            value={BuybackNer.BuyBackFee as string}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              BuybackFeeValueChange(e);
            }}
            onBlur={(e) => {
              BuybackFeeBlurChange(e);
            }}
          />
        </div>
        <div className={styles.auolItem}>
          <div className={styles.require}>{`${t("Reflection Fee")}`} (%)<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder="0 - 100"
            className={styles.addrInput}
            value={BuybackNer.ReflectionFee as string}
            style={{ borderColor: buyBackError.ReflectionFeeBlankError || buyBackError.ReflectionFeeMinError ? "#f14668" : "" }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              ReflectionFeeValueChange(e);
            }}
            onBlur={(e) => {
              ReflectionFeeBlurChange(e);
            }}
          />
        </div>
      </div>
      <div className="sbuyeisn">
        <div className="sbuyeisnItem">
          {buyBackError.BuybackFeeBlankError ? <InputError title="Buyback Fee cannot be blank" /> : ''}
          {buyBackError.BuybackFeeMinError ? <InputError title="Buyback Fee must be greater than or equal to 0.01" /> : ''}
        </div>
        <div className="sbuyeisnItem">
          {buyBackError.ReflectionFeeBlankError ? <InputError title="Reflection Fee cannot be blank" /> : ''}
          {buyBackError.ReflectionFeeMinError ? <InputError title="Reflection Fee must be greater than or equal to 0.01" /> : ''}
        </div>
      </div>
      <div className={styles.auoieng}>
        <div className={styles.auolItem}>
          <div className={styles.require}>{`${t("Marketing fee")}`} (%)<span style={{ color: "#f95192" }}> *</span></div>
          <Input
            placeholder="0 - 100"
            className={styles.addrInput}
            value={BuybackNer.MarketingFee as string}
            style={{ borderColor: buyBackError.MarketingFeeBlankError || buyBackError.MarketingFeeMinError ? "#f14668" : "" }}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              MarketingFeeValueChange(e);
            }}
            onBlur={(e: React.ChangeEvent<HTMLInputElement>) => {
              MarketingFeeBlurChange(e);
            }}
          />
        </div>
      </div>
      {buyBackError.MarketingFeeBlankError ? <InputError title="Marketing Fee cannot be blank" /> : ''}
      {buyBackError.MarketingFeeMinError ? <InputError title="Marketing Fee must be greater than or equal to 0.01" /> : ''}
      {buyBackError.FeeOverError ? <InputError title="Liquidity Fee + Buyback Fee + Reflection Fee + Marketing Fee must be less than or equal to 25%" /> : ''}
      <div className={styles.tulieng}>
        <Checkbox
          onChange={(e: CheckboxChangeEvent) => {
            setBuybackNer((olddata: BabyTokenList) => {
              return {
                ...olddata,
                UseAntiBot: e.target.checked,
              };
            });
          }}
          checked={BuybackNer.UseAntiBot as boolean}
          style={{ lineHeight: "32px" }}
        >
          {`${t("Implement Maya Anti-Bot System?")}`}
        </Checkbox>
      </div>
      {isCreated() ? <button
        onClick={() => {
          StandardCreateOnClikc();
        }}
        className={`nextbtn ${styles.nextbtn}`}
      >
        {loading ? <ButtonLoading /> : ''}{`${t("Create token")}`}
      </button> : <button
        style={{ cursor: 'not-allowed', backgroundColor: '#999' }}
        className={`nextbtn ${styles.nextbtn}`}
      >
        {`${t("Create token")}`}
      </button>}
    </div>
  );
};

export default BabackTokenProps;
