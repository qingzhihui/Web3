import { Tree } from "antd";
import "./index.css";

// 分销基础配置界面
const AdministratorsPage = () => {
  const treeData = [
    {
      title: "文章管理",
      key: "1",
      children: [
        {
          title: "新增",
          key: "1-1",
        },
        {
          title: "修改",
          key: "1-2",
        },
        {
          title: "删除",
          key: "1-3",
        },
        {
          title: "详情",
          key: "1-4",
        },
      ],
    },
    {
      title: "文章各类管理",
      key: "2",
      children: [
        {
          title: "新增",
          key: "2-1",
        },
        {
          title: "修改",
          key: "2-2",
        },
        {
          title: "删除",
          key: "2-3",
        },
        {
          title: "详情",
          key: "2-4",
        },
      ],
    },
    {
      title: "文章评论管理",
      key: "3",
      children: [
        {
          title: "新增",
          key: "3-1",
        },
        {
          title: "修改",
          key: "3-2",
        },
        {
          title: "删除",
          key: "3-3",
        },
        {
          title: "详情",
          key: "3-4",
        },
      ],
    },
  ];
  // 指定选中数据
  const defaultCheckedKeys:any = [
    '1-1','1-3'
  ]
  // 指定展开数据
  const defaultExpandedKeys:any=[
    '2',
  ]

  const onSelect = (selectedKeys: React.Key[], info: any) => {
    console.log("selected", selectedKeys, info);
  };
  const onCheck = (checkedKeys:any, info: any) => {
    console.log("onCheck", checkedKeys, info);
  };

  return (
    <div>
      <Tree
        checkable
        defaultExpandedKeys={defaultExpandedKeys}
        // defaultSelectedKeys={[ '1-1']}
        defaultCheckedKeys={defaultCheckedKeys}
        onSelect={onSelect}
        onCheck={onCheck}
        treeData={treeData}
      />
    </div>
  );
};

export default AdministratorsPage;
