import { StandardTokenError } from "../hooks/Errorhandle";

const StandardTokenErrorInitState: StandardTokenError = {
    NameCharactersError: false,
    NameBlankError: false,
    SymbolCharactersError: false,
    SymbolBlankError: false,
    DecimalsBlankError: false,
    DecimalsMinError: false,
    DecimalsMaxError: false,
    TotalSupplyBlankError: false,
    TotalSupplyAmountError: false,
};

export {
    StandardTokenErrorInitState
};