import Communities from '@components/Community/Communities'

export default Communities
