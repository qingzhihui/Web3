import { useState } from "react";
import type { MenuProps } from "antd";
import { Button, Dropdown, Menu, Space } from "antd";
import { useTranslation, Trans } from "react-i18next";
import puse from "../../assets/image/zhuang.png";
import i18n from "../../i18n";
import "./index.scss";

const International = () => {
  const [handelvoice, setHandelvoice] = useState("中文");
  const { t } = useTranslation();
  const Meslei = [
    {
      label: "中文",
      key: "1",
    },
    {
      label: "English",
      key: "2",
    },
  ];
  const handleMenuClick: MenuProps["onClick"] = (e) => {
    setHandelvoice(Meslei[Number(e.key) - 1].label);
    if (e.key == "1") {
      i18n.changeLanguage("zh-CN");
    } else {
      i18n.changeLanguage("en");
    }
  };
  const menu = <Menu onClick={handleMenuClick} items={Meslei} />;
  return (
    <div className="spiineosr">
      <div className="sapeien">
        <Dropdown
          overlay={menu}
          placement="bottom"
          arrow={{ pointAtCenter: true }}
        >
          <Button>
            <Space>
              <div className="speriise">
                <img src={puse} alt="" />
                <div className="psoduenxc">{handelvoice}</div>
              </div>
            </Space>
          </Button>
        </Dropdown>
      </div>
    </div>
  );
};

export default International;
