import React, { useEffect } from "react";
import "./index.scss";
import { useHistory } from "react-router-dom";
import Item from "antd/lib/list/Item";

function Heues(props: any) {
  let history = useHistory();
  const MenuList = [
    {
      key: "/Home",
      label: "HOME",
    },
    {
      key: "/About",
      label: "ABOUT",
    },
    {
      key: "/Mint",
      label: "MINT",
    },
    {
      key: "/Game",
      label: "GAME",
    },
    {
      key: "/Rank",
      label: "RANK",
    },
    {
      key: "/Market",
      label: "MARKET",
    },
  ];
  const Biens = (key: any) => {
    history.push(key);
  };
  useEffect(() => {
    const delbe: HTMLCollectionOf<Element> = document.getElementsByClassName(
      "nritem"
    ) as HTMLCollectionOf<Element>;
    const BUskliu = Array.prototype.slice.call(delbe);
    const kulie = props.burl.slice(1, 7).toUpperCase();
    BUskliu.map((item: any) => {
      if (item.innerText == kulie) {
        item.className += " beis";
      }
    });
  }, []);
  return (
    <div className="heues">
      <div className="nrolse">
        {MenuList.map((item, index) => (
          <div className="nritem" key={index} onClick={() => Biens(item.key)}>
            {item.label}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Heues;
