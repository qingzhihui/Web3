import { formatTime } from "../../../utils/util";
Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多 slot 支持
  },
  /**
   * 监听器
  */
  observers: {
  },

  /**
   * 组件的属性列表
   */
  properties: {
    dataList:{
      type: Array,
      observer: "mapDataList"
    },
    height: {
      type: String
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    portrait: '../../../asstes/image/378.png'
  },

  /**
   * 组件的方法列表
   */
  methods: {
    mapDataList: function () {
      let data = this.data.dataList;
      data.forEach(element => {        
        element.time = formatTime(new Date(element.time))
      });
      this.setData({
        dataList: data
      });   
    }
  }
})
