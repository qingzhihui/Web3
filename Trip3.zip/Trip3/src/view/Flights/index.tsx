import React from 'react'
import './index.scss'
import { Input, Select } from 'antd';

export default function index() {
  const handleChange = (value: string) => {
    console.log(`selected ${value}`);
  };

  return (
    <div className='flights'>
      <div className='flightscard'>
        <div className='flightsimgs'>
          <div className='address'>Beijing ----- Paris</div>
          <div className='departure'>1 Adult  |  All departure/arrival times are in local time</div>
        </div>
        <div className='flightsdepart'>
          <div className='departtop'>
            <button>Depart</button>
            <div>Wed, December 14 | Beijing Capital International Airport T3 - Paris Charles de Gaulle Airport T2E</div>
          </div>
          <div className='departbuttom'>
            <div className='buttomone'>
              <img src={require('@/assets/image/IMAGE8.png')} alt="" />
              <div>
                <div className='time'>13:30-17:40</div>
                <div className='addresss'>Air China</div>
              </div>
            </div>
            <div className='buttomtwo'>
              <img src={require('@/assets/image/lock.png')} alt="" />
              <div>11h10m</div>
            </div>
            <div className='buttomthree'>
              <div className='threetop'>Nonstop</div>
              <div className='threebuttom'>PEK - CDG</div>
            </div>
            <div className='buttomfour'>
              <img src={require('@/assets/image/pepicons.png')} alt="" />
              <img src={require('@/assets/image/fluent.png')} alt="" />
              <img src={require('@/assets/image/youtube.png')} alt="" />
            </div>
          </div>
        </div>
        <div className='flightsdates'>
          <div className='datesleft'>
            <div className='top'>
              <span>Dec 14</span>
              <span>13:30</span>
              <div></div>
              <span>PEK Beijing Capital International Airport T3</span>
            </div>
            <div className='middle'>
              <span>11h10m</span>
            </div>
            <div className='buttom'>
              <span>Dec 14</span>
              <span>13:30</span>
              <div></div>
              <span>PEK Beijing Capital International Airport T3</span>
            </div>
          </div>
          <div className='datesright'>
            <img src={require('@/assets/image/IMAGE8.png')} alt="" />
            <span>Air China CA933</span>
          </div>
        </div>
        <div className='passengers'>
          <div className='passengers_title'>Passengers</div>
          <div className='ticket'>
            <div>1. Adult Ticket</div>
            <div>
              <img src={require('@/assets/image/mingcute.png')} alt="" />
              <span>Clear</span>
            </div>
          </div>
          <div className='inputs'>
            <div>
              <Input placeholder="Last name" bordered={false} />
            </div>
            <div>
              <Input placeholder="First & middle name" bordered={false} />
            </div>
            <div>
              <Input placeholder="Gender" bordered={false} />
              <img src={require('@/assets/image/arrow.png')} alt="" />
            </div>
            <div>
              <Input placeholder="Date of birth" bordered={false} />
              <img src={require('@/assets/image/inputsdate.png')} alt="" />
            </div>
            <div>
              <Input placeholder="Nationality" bordered={false} />
              <img src={require('@/assets/image/arrow.png')} alt="" />
            </div>
            <div>
              <Input placeholder="ID Type" bordered={false} />
              <img src={require('@/assets/image/arrow.png')} alt="" />
            </div>
            <div>
              <Input placeholder="ID number" bordered={false} />
            </div>
            <div>
              <Input placeholder="ID Expiration Date(Optional）" bordered={false} />
              <img src={require('@/assets/image/inputsdate.png')} alt="" />
            </div>
          </div>
          <div className='addk'>
            <img src={require('@/assets/image/symbols.png')} alt="" />
            <span>Add an Adult</span>
          </div>
        </div>
        <div className='contact_details'>
          <div className='details_title'>Contact Details</div>
          <div className='details_inputs'>
            <div className='input'>
              <Input placeholder="Last name" bordered={false} />
            </div>
            <div className='input'>
              <Input placeholder="Last name" bordered={false} />
            </div>
            <div className='input'>
              <Select
                defaultValue="+86"
                style={{ width: 70 }}
                onChange={handleChange}
                bordered={false}
                options={[
                  {
                    value: '+86',
                    label: '+86',
                  },
                ]}
              />
              <Input placeholder="Last name" bordered={false} />
            </div>
          </div>
        </div>
        <div className='price_details'>
          <div className='price_left'>
            <div className='pricetitle'>Price Details</div>
            <div className='info'>
              <div className='tiitle_info'>Fare</div>
              <div className='tiitle_info'>$ 4460  x1</div>
            </div>
            <div className='info'>
              <div className='tiitle_info'>Taxes & fees</div>
              <div className='tiitle_info'>$ 1020</div>
            </div>
          </div>
          <div className='price_right'>
            <div>Total $ 5,480</div>
            <button>Select</button>
          </div>
        </div>
      </div>
    </div>
  )
}
