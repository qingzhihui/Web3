import React from 'react';

const SupportAdmin = () => {
  return (
    <div>Support Admin</div>
  );
}

export default SupportAdmin;
