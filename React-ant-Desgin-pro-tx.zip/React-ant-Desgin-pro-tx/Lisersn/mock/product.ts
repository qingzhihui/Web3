import { Request, Response } from 'express';
function getProductList(req: Request, res: Response) {
  const productList: API.Product[] = [];
  for (let i = 1; i < 20; i++) {
    productList.push({
      id: i,
      name: 'produce' + i,
    });
  }
  res.json(productList)
}
export default {
  '/api/product/list': getProductList,
};
