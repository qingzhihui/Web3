import React, { useState } from "react";
import "antd/dist/antd.less";
import "./App.css";
import IndexRouter from "./router/indexRouter";

function App() {
  const [ches, setChes] = useState(0);
  const chge = () => {
    setChes(ches + 1);
  };
  return (
    <div className="App">
      {/* <IndexRouter /> */}
      {ches}
      <button
        onClick={() => {
          chge();
        }}
      >
        ches
      </button>
    </div>
  );
}

export default App;
