import React, { Suspense } from "react";

// 异步加载组件的函数
const AsyncComponent = React.lazy(() => import("../components/AsyncComponent"));

function App() {
  return (
    <div>
      <h5>Hello, React Suspense API and TypeScript!</h5>
      <Suspense fallback={<div>Loading...</div>}>
        <AsyncComponent />
      </Suspense>
    </div>
  );
}

export default App;
