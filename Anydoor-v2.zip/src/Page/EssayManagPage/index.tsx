import {
    DeleteOutlined, FormOutlined
} from '@ant-design/icons';
import { Space, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import "./index.css";


// 文章管理界面
const EssayManagPage = () => {

    interface DataType {
        key: number;
        publisherNickname: string; // 发布人昵称
        categoryName: string; // 分类名称
        title: string;        // 标题
        label: string;        // 标签
        content: string;      // 内容
        readNumber: number;   // 阅读数
        LikeYouNumber: Number;// 点赞数
        RelatedGoods: string; // 关联商品
        wineshop: string;     // 酒店
        grade: string;        // 评分 
        publishTime: string   // 发布时间
    }

    const data: DataType[] = [
        {
            key: 1,
            publisherNickname: '张三',
            categoryName: "美食",
            title: '美食推荐',
            label: "美食、咖啡厅、酒店",
            content: '一起吃饭',
            readNumber: 0,
            LikeYouNumber: 0,
            RelatedGoods: "啤酒",
            wineshop: "xxx酒店",
            grade: "总分4,环境4,服务4",
            publishTime: '2023-03-21',
        },
    ];

    const columns: ColumnsType<DataType> = [
        {
            title: '发布人昵称',
            dataIndex: 'publisherNickname',
            key: 'publisherNickname',
            width: 120,
        },
        {
            title: '分类名称',
            dataIndex: 'categoryName',
            key: 'categoryName',
            width: 120,
        },
        {
            title: '标题',
            dataIndex: 'title',
            key: 'title',
            width: 120,
        },
        {
            title: '标签',
            dataIndex: 'label',
            key: 'label',
            width: 120,
        },
        {
            title: '内容',
            dataIndex: 'content',
            key: 'content',
            width: 120,
        },
        {
            title: '阅读数',
            dataIndex: 'readNumber',
            key: 'readNumber',
            width: 100,
        },
        {
            title: '点赞数',
            dataIndex: 'LikeYouNumber',
            key: 'LikeYouNumber',
            width: 100,
        },
        {
            title: '关联商品/酒店',
            width: 200,
            render: (_, record) => (
                <Space size="middle">
                    <span>{record.RelatedGoods}</span>/
                    <span>{record.wineshop}</span>
                </Space>
            ),
        },
        {
            title: '评分',
            dataIndex: 'grade',
            key: 'grade',
            width: 120,
        },
        {
            title: '发布时间',
            dataIndex: 'publishTime',
            key: 'publishTime',
            width: 150,
        },
        {
            title: '操作',
            key: 'action',
            render: (_, record) => (
                <Space size="middle">
                    <span className='Ess_publicCursor' onClick={uploadus(record)}><FormOutlined /></span>
                    <span className='Ess_publicCursor' onClick={deleteus(record)}><DeleteOutlined /></span>
                </Space>
            ),
        },
    ];

    // 修改
    const uploadus = (record: any) => {
        return () => {
            console.log("点击了修改");
            console.log(record.key);
        }
    }
    // 删除
    const deleteus = (record: any) => {
        return () => {
            console.log("点击了删除");
            console.log(record.key);
        }
    }

    return (
        <div className='Ess_Box'>
            <div className='Ess_headerBox'>
                <div className='Ess_headerBox_thread'></div>
                <div className='Ess_headerBox_Tit'>&nbsp;&nbsp;&nbsp; 文章管理</div>
            </div>

            <div className='Ess_tableBox'>
                <Table columns={columns} dataSource={data} />
            </div>
        </div>
    )
}

export default EssayManagPage;