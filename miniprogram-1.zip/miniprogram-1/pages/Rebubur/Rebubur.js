// pages/Reports/Reports.js
import api from '../../config/api'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    radio: '0',
    message3: "",
    message4: "",
    show3: false,
    listKuData: [],
    arrLIne: {},
    tid: "",
    zid: "",
    quid: "",
    zuh: "请点击确认无异，如不确定，三天后自动确认。",
    bshow: true,
  },
  onClickLeft() {
    wx.navigateBack({
      url: '../HienShow/HienShow',
    })
  },
  onChange(event) {
    if ((event.detail == 2)) {
      setTimeout(() => {
        this.setData({
          radio: event.detail,
          dinping: true,
        });
      }, 300)
    } else {
      setTimeout(() => {
        this.setData({
          radio: event.detail,
          dinping: false,
        });
      }, 300)
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //ums/umsEvidence/selectReportNewInfo/{questionnaireId}/{userId}/{teamId}
    api._get(`ums/umsEvidence/selectReportNewInfo/${options.id}/${options.tid}/${options.zid}`).then(res => {
      this.setData({
        listKuData: res.data,
        zid: options.zid,
        tid: options.tid,
        quid: options.id
      })
      api._get(`ums/umsSubmission/selectSubmissionStatus/${options.id}/${options.tid}/${options.zid}`).then(res => {
        if(res.data.status == true){
          this.setData({
            zuh: '已归档',
            bshow: false
          })
        }else{
          this.setData({
            zuh: `${res.data.unitValue}自动确认。`,
            bshow: true
          })
        }
      }).catch(e => {
        console.log(e);
      })
    }).catch(e => {
      console.log(e);
    })
    api._get(`ums/umsEvidence/selectReport/${options.id}/${options.tid}/${options.zid}`).then(res => {
      this.setData({
        arrLIne: res.data,
      })
    }).catch(e => {
      console.log(e);
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  },
  Anlishow(e) {
    api._get(`ums/umsEvidence/selectEvidenceInfo/${this.data.zid}/${e.currentTarget.dataset.id}/${this.data.tid}`).then(res => {
      this.setData({
        message3: res.data[0].content
      })
    }).catch(e => {
      console.log(e);
    })
    this.setData({
      show3: true
    });
  },
  onClose3() {
    this.setData({
      show3: false
    });
  }
})