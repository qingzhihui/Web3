import { useRouter } from "next/router";

export default function EditPost() {
  const router = useRouter();
  const { id } = router.query;

  return <p>Edit post: {id}</p>;
}
