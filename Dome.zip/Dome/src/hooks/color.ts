import _ from "lodash";

export function Swatch(color: any) {
  console.log(`Swatch: ${color}`);
  return `Swatch: ${color}`;
}

const memoedSwatch = _.memoize(Swatch);
// memoedSwatch("red");
// memoedSwatch("blue");
// memoedSwatch("red");
// memoedSwatch("blue");

const createSatch = () => {
  const prev: any = {
    color: null,
    result: null,
  };
  return (color: any) => {
    if (color === prev.color) {
      return prev.result;
    }
    prev.color = color;
    prev.result = Swatch(color);
    return prev.result;
  };
};
const swatch1 = createSatch();
const swatch2 = createSatch();

swatch1("red");
swatch1("blue");
swatch2("red");
swatch2("blue");

