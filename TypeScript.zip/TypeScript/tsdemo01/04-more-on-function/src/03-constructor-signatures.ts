// class Ctor {
//   s: string;
//   constructor(s: string) {
//     this.s = s;
//   }
// }
// type SomConstructor = {
//   new (s: string): Ctor;
// };

// function fn(ctor:SomConstructor){
//   return new ctor('hello')
// }

// const f = fn(Ctor)
// console.log(f.s);

interface CallIrConstructor {
  new (s: string): Date;
  (n?: number): number;
}

function fn(date:CallIrConstructor){
    let d = new date('2021-12-20')
    let n = date(100)
}
