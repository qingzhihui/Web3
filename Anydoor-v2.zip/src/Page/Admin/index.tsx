import React, { Suspense } from "react";
import { Outlet } from "react-router-dom";
import Header from "../../components/Header";
import Loading from "../../components/Loading";
import NavLeft from "../../components/NavLeft";

const Admin = () => {
  return (
    <div className="container">
      <div className="nav-left">
        <NavLeft />
      </div>
      <div className="main">
        <Header />
        <div className="content">
          <Suspense fallback={<Loading />}>
            <Outlet />
          </Suspense>
        </div>
      </div>
    </div>
  );
};

export default Admin;
