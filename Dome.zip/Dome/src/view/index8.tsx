import React, { useEffect, useLayoutEffect, useState } from "react";
// 你可能做了反作用钩

const Index = () => {
  const [text, setText] = useState("hello");

  useLayoutEffect(() => {
    console.log("effect2");
    return () => {
      console.log("destory2");
    };
  });
  useEffect(() => {
    console.log("effect1");
    return () => {
      console.log("destory1");
    };
  });
  return <div></div>;
};

export default Index;
