/// <reference types="react-scripts" />
interface Window {
  [propName: string]: any;
}