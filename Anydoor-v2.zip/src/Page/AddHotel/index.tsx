import { Input, Form, Select, Cascader, SelectProps, Button } from "antd";
import "./index.css";
import AddHotelUpload1 from './AddHotelUpload1'
import AddHotelUpload2 from './AddHotelUpload2'


// const [parentCount, setParentCountt] = useState<[]>([]);

const getuploadData1 = (val:any) => {
    // setParentCountt(val);
    console.log("传过来上传信息1",val)
};
const getuploadData2 = (val:any) => {
    // setParentCountt(val);
    console.log("传过来上传信息2",val)
};



// 添加酒店界面
const AddHotel = () => {

    const { TextArea } = Input;
    interface Option {
        value: string | number;
        label: string;
        children?: Option[];
    }

    // 下拉选择框-支付方式-内容
    const options1 = [
        {
            value: '1',
            label: '微信',
        },
        {
            value: '2',
            label: '支付宝',
        },
        {
            value: '3',
            label: '银行',
        },
    ]

    // 下拉选择-支付方式---选中内容
    const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
        console.log(value);
    };



    // 地区选择数据
    const options2: Option[] = [
        {
            value: '中国',
            label: '中国',
            children: [
                {
                    value: '广东省',
                    label: '广东省',
                    children: [
                        {
                            value: '珠海市',
                            label: '珠海市',
                        },
                    ],
                },
            ],
        },
    ];

    // 地区选中内容
    const onChange2 = (value: any[]) => {
        console.log(value);
    };

    // 下拉选择框-酒店状态-内容
    const options3 = [
        {
            value: '1',
            label: '正常',
        },
        {
            value: '2',
            label: '停业',
        },
    ]

    // 下拉选择-酒店状态---选中内容
    const handleChange3 = (value: { value: string; label: React.ReactNode }) => {
        console.log(value);
    };

    // 下拉选择框-酒店分类-内容
    const options4 = [
        {
            value: '1',
            label: '明宿',
        },
        {
            value: '2',
            label: '豪华',
        },
    ]

    // 下拉选择-酒店分类---选中内容
    const handleChange4 = (value: { value: string; label: React.ReactNode }) => {
        console.log(value);
    };

    const options5 = [
        {
            label: 120,
            value: '舒服',
        },
        {
            label: 120,
            value: '舒适',
        },
        {
            label: 120,
            value: '皇宫',
        }
    ]



    const handleChange5 = (value: string[]) => {
        console.log(`selected ${value}`);
    };

    // 提交
    const addHotel = (values: any) => {
        console.log('提交的数据:', values);
    };

    const onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };

    return (
        <div className='addHotel_Box'>
            <div className='addHotel_headerBox'>
                <div className='addHotel_headerBox_thread'></div>
                <div className='addHotel_headerBox_Tit'>&nbsp;&nbsp;&nbsp; 添加酒店</div>
            </div>
            <Form
                // name="basic"
                labelCol={{ span: 6 }}
                wrapperCol={{ span: 14 }}
                style={{ maxWidth: 2500 }}
                initialValues={{ remember: true }}
                onFinish={addHotel}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
            >
                <div className="addHotel_inputDaBox">
                    <div className="addHotel_inputheader">
                        {/* 左 */}
                        <div className="addHotel_inputDaBoxleft">
                            <Form.Item label="酒店id" name="hotelId">
                                <Input placeholder="请输入酒店id" />
                            </Form.Item>
                            <Form.Item label="酒店中文名称" name="hotelChinese">
                                <Input placeholder="酒店中文名称" />
                            </Form.Item>
                            <Form.Item label="酒店logo" name="hotelLogo">
                                <AddHotelUpload1 getupload1={getuploadData1}/>
                            </Form.Item>
                            <Form.Item label="开业时间" name="startTime">
                                <Input placeholder="请输入开业时间" />
                            </Form.Item>
                            <Form.Item label="酒店详细地址" name="hotelAddress">
                                <Input placeholder="请输入酒店详细地址" />
                            </Form.Item>
                            <Form.Item label="酒店标签" name="hotellable">
                                <Input placeholder="请填写酒店标签，如地铁站旁|大学城附近" />
                            </Form.Item>
                            <Form.Item label="办理入住时间段" name="EntryTime">
                                <Input placeholder="请按入住时间00:00-退房时间00:00格式填写" />
                            </Form.Item>
                            <Form.Item label="支付方式" name="zfWay">
                                <Select
                                    labelInValue
                                    defaultValue={{ value: '1', label: '微信' }}
                                    style={{ width: 120 }}
                                    onChange={handleChange1}
                                    options={options1}
                                />
                            </Form.Item>
                            <Form.Item label="酒店介绍" name="hotelIntroduce">
                                <TextArea rows={4} />
                            </Form.Item>
                        </div>
                        {/* 右 */}
                        <div className="addHotel_inputDaBoxright">
                            <Form.Item label="酒店分类" name="hotelClassify">
                                <Select
                                    labelInValue
                                    defaultValue={{ value: '1', label: '名宿' }}
                                    style={{ width: 120 }}
                                    onChange={handleChange4}
                                    options={options4}
                                />
                            </Form.Item>
                            <Form.Item label="酒店英文名称" name="hotelEnglishName">
                                <Input placeholder="请输入酒店英文名称" />
                            </Form.Item>
                            <Form.Item label="酒店宣传图" name="hotelImg">
                                <AddHotelUpload2 getupload2={getuploadData2}/>
                            </Form.Item>
                            <Form.Item label="地区" name="area">
                                <Cascader options={options2} onChange={onChange2} placeholder="请选择地区" />
                            </Form.Item>
                            <Form.Item label="腾讯地图坐标" name="mapCoordinates">
                                <Input placeholder="请输入腾讯地图坐标" />
                            </Form.Item>
                            <Form.Item label="酒店设施" name="hotelInstallation">
                                <Input placeholder="请输入酒店设施" />
                            </Form.Item>
                            <Form.Item label="酒店联系电话" name="hotelphone">
                                <Input placeholder="请输入酒店设施" />
                            </Form.Item>
                            <Form.Item label="房型管理" name="houseFormMange">
                                <div className="addHotel_fangxXngBtn">一键采集api房型</div>
                                <Select
                                    mode="multiple"
                                    allowClear
                                    style={{ width: '100%' }}
                                    placeholder="Please select"
                                    defaultValue={['a10', 'c12']}
                                    onChange={handleChange5}
                                    options={options5}
                                />

                            </Form.Item>
                            <Form.Item label="酒店状态" name="hotelStatus">
                                <Select
                                    labelInValue
                                    defaultValue={{ value: '1', label: '正常' }}
                                    style={{ width: 120 }}
                                    onChange={handleChange3}
                                    options={options3}
                                />
                            </Form.Item>
                        </div>

                    </div>
                    
                    <Form.Item wrapperCol={{ offset: 12, span: 12 }}>
                        <Button className='btn' size="middle" type="primary" htmlType="submit">提交</Button>
                    </Form.Item>
                </div>
            </Form>
        </div>
    )
}

export default AddHotel;