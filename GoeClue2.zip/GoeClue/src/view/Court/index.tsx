import React, { useEffect, useState } from "react";
import "./index.scss";
import { useHistory } from "react-router-dom";
import Header from "../../components/Header";
import { ethers } from "ethers";
import {
  CloseCircleOutlined,
  RedoOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";
import {
  invite_ADDRESS,
  invite_ABI,
} from "../../redux/Contract/inviteContract";
import { GIC_ADDRESS, GIC_ABI } from "../../redux/Contract/GlContract.js";
import { token_ABI } from "../../redux/Contract/tokenContract";
declare const window: Window & { ethereum: any };

const Court = () => {
  const [usePri, setUsePri] = useState(false);
  const [isExchange, setisExchange] = useState(false);
  const [buisner, setBuisner] = useState(0);
  const [isBindenge, setisBindenge] = useState(false);
  const [address, setWalletAccount] = useState("");
  const [pinput, setPinput] = useState("");
  const [inputn, setinputn] = useState("");
  const [inputo, setinputo] = useState("");
  const [allowance, setallowance] = useState(true);
  const [iceFor, seticeFor] = useState("");
  const [binder1, setBinder1] = useState("");
  const [binder2, setBinder2] = useState("");
  const [prins, setPrins] = useState(true);
  const [isTimese, setisTimese] = useState(false);
  const [oreTime, setoreTime] = useState({
    gontime: "",
    oreTime: 1,
  });
  let history = useHistory();
  const GameShowMarket = () => {
    history.push("/GetPlayer");
  };
  const GameShowHave = () => {
    history.push("/Have");
  };
  const GameShowLInk = () => {
    history.push("/Invita");
  };
  const GameShowGemo = () => {
    history.push("/Game");
  };
  const Bindshow = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const adres = await signer.getAddress();
    const inviteContract = new ethers.Contract(
      invite_ADDRESS,
      invite_ABI,
      signer
    );
    const Binhow = await inviteContract.verifyBinding(adres);
    if (Binhow == false) {
      setisBindenge(true);
    } else {
      setisBindenge(false);
    }
  };
  const showHide2 = () => {
    setisTimese(false);
  };
  const Clerpes = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const adres = await signer.getAddress();
    const GLcContract = new ethers.Contract(GIC_ADDRESS, GIC_ABI, signer);
    const purchaseTokenAddress = await GLcContract.usdt();
    const purchaseTokenContract = new ethers.Contract(
      purchaseTokenAddress,
      token_ABI,
      signer
    );
    const allowance = await purchaseTokenContract.allowance(adres, GIC_ADDRESS);
    const amountPro = ethers.utils.parseEther("1");
    if (prins) {
      const priceForUsdtIn = await GLcContract.priceForUsdtIn(amountPro);
      const priceFor = ethers.utils.formatUnits(priceForUsdtIn.toString(), 18);
      seticeFor(Number(priceFor).toFixed(5));
    } else {
      const priceForUsdtOut = await GLcContract.priceForUsdtOut(amountPro);
      const priceFor = ethers.utils.formatUnits(priceForUsdtOut.toString(), 18);
      seticeFor(Number(priceFor).toFixed(5));
    }

    const usdt = await GLcContract.usdt();
    const USDTConnres = new ethers.Contract(usdt, token_ABI, signer);
    const balanceOf1 = await USDTConnres.balanceOf(adres);
    const balanceOf2 = await GLcContract.balanceOf(adres);
    const balanceOfshow1 = ethers.utils.formatUnits(balanceOf1, 18);
    const balanceOfshow2 = ethers.utils.formatUnits(balanceOf2, 18);
    setBinder1(Number(balanceOfshow1).toFixed(5));
    setBinder2(Number(balanceOfshow2).toFixed(5));
    if (allowance.toString() === "0") {
      setallowance(true);
    } else {
      setallowance(false);
    }
  };
  const BindeonClick = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const inviteContract = new ethers.Contract(
        invite_ADDRESS,
        invite_ABI,
        signer
      );
      const bind = await inviteContract.bind(pinput);
      setoreTime({ gontime: "绑定中...", oreTime: 1 });
      setisTimese(true);
      await bind.wait();
      setisBindenge(false);
      setoreTime({ gontime: "绑定成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "绑定失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const BuyonClick = async () => {
    try {
      const Iouser = ethers.utils.parseEther(inputo);
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const GLcContract = new ethers.Contract(GIC_ADDRESS, GIC_ABI, signer);
      const buyCoin = await GLcContract.buyCoin(Iouser);
      setoreTime({ gontime: "买入中...", oreTime: 1 });
      setisTimese(true);
      setisExchange(false);
      await buyCoin.wait();
      setoreTime({ gontime: "买入成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
        setisExchange(true);
      }, 2000);
      setinputn("");
      setinputo("");
    } catch (error) {
      setoreTime({ gontime: "买入失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
        setisExchange(true);
      }, 2000);
    }
  };
  const BuyonAller = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const GLcContract = new ethers.Contract(GIC_ADDRESS, GIC_ABI, signer);
      const purchaseTokenAddress = await GLcContract.usdt();
      const purchaseTokenContract = new ethers.Contract(
        purchaseTokenAddress,
        token_ABI,
        signer
      );
      const approve = await purchaseTokenContract.approve(
        GIC_ADDRESS,
        ethers.constants.MaxUint256
      );
      setoreTime({ gontime: "授权中", oreTime: 1 });
      setisTimese(true);
      await approve.wait();
      setallowance(false);
      setoreTime({ gontime: "授权成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "授权失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const Conversion = async (value: any) => {
    if (value !== "") {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const GLcContract = new ethers.Contract(GIC_ADDRESS, GIC_ABI, signer);
      const usdt = await GLcContract.usdt();
      const amouninput = ethers.utils.parseEther(value);
      if (prins) {
        const path: any = [usdt, GIC_ADDRESS];
        const getPriceOut = await GLcContract.getPriceOut(amouninput, path);
        const priceNum = ethers.utils.formatUnits(
          getPriceOut[1].toString(),
          18
        );
        setinputo(Number(priceNum).toString());
      } else {
        const path: any = [GIC_ADDRESS, usdt];
        const getPriceOut = await GLcContract.getPriceIn(amouninput, path);
        const priceNum = ethers.utils.formatUnits(
          getPriceOut[0].toString(),
          18
        );
        setinputo(Number(priceNum).toString());
      }
    } else {
      setinputo("");
    }
  };
  const Conversion2 = async (value: any) => {
    if (value !== "") {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const GLcContract = new ethers.Contract(GIC_ADDRESS, GIC_ABI, signer);
      const usdt = await GLcContract.usdt();
      const amouninput = ethers.utils.parseEther(value);
      if (prins) {
        const path: any = [usdt, GIC_ADDRESS];
        const getPriceOut = await GLcContract.getPriceIn(amouninput, path);
        const priceNum = ethers.utils.formatUnits(
          getPriceOut[0].toString(),
          18
        );
        setinputn(Number(priceNum).toString());
      } else {
        const path: any = [GIC_ADDRESS, usdt];
        const getPriceOut = await GLcContract.getPriceOut(amouninput, path);
        const priceNum = ethers.utils.formatUnits(
          getPriceOut[1].toString(),
          18
        );
        setinputn(Number(priceNum).toString());
      }
    } else {
      setinputn("");
    }
  };
  const setinputnOnChen = (e: any) => {
    setinputn(e.target.value);
    Conversion(e.target.value);
  };
  const llerinow = () => {
    return (
      <>
        <div className="Exchange_title">
          <div className="psoejn">
            <img src={require("../../assets/image/BNB.png")} alt="" />
            <div>USDT</div>
          </div>
          <div className="Bindfed">余额：{binder1}</div>
        </div>
        <div className="BusierINpt">
          <input
            type="text"
            value={inputn}
            placeholder="Please enter"
            onChange={(e) => {
              setinputnOnChen(e);
            }}
          />
        </div>
      </>
    );
  };
  const llerinow2 = () => {
    return (
      <>
        <div className="Exchange_title">
          <div className="psoejn">
            <img src={require("../../assets/image/IMAGE.png")} alt="" />
            <div>COIN</div>
          </div>
          <div className="Bindfed">余额：{binder2}</div>
        </div>
        <div className="BusierINpt">
          <input
            type="text"
            value={inputo}
            placeholder="Please enter"
            onChange={(e) => {
              setinputoOnChen(e);
            }}
          />
        </div>
      </>
    );
  };
  const setinputoOnChen = (e: any) => {
    setinputo(e.target.value);
    Conversion2(e.target.value);
  };
  const SELLClick = async () => {
    try {
      const Iouser = ethers.utils.parseEther(inputo);
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const GLcContract = new ethers.Contract(GIC_ADDRESS, GIC_ABI, signer);
      const sellCoin = await GLcContract.sellCoin(Iouser);
      setoreTime({ gontime: "卖出中...", oreTime: 1 });
      setisTimese(true);
      setisExchange(false);
      await sellCoin.wait();
      setoreTime({ gontime: "卖出成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
        setisExchange(true);
      }, 2000);
      setinputn("");
      setinputo("");
    } catch (error) {
      setoreTime({ gontime: "卖出失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
        setisExchange(true);
      }, 2000);
    }
  };
  useEffect(() => {
    const address = localStorage.getItem("Cone_addr");
    if (address !== null && address !== undefined) {
      setWalletAccount(address);
      Bindshow();
      Clerpes();
    } else {
      setWalletAccount("");
    }
  }, [prins]);
  return (
    <>
      <div className="CourtPsoer">
        <div className="husieniWE">
          <Header />
        </div>
        <div className="Court">
          <div className="Court_nro">
            <div className="Court_nro_left">
              <img src={require("../../assets/image/11.png")} alt="" />
            </div>
            <div className="Court_nro_cneder">
              <div
                className={[
                  `cneder_item1 ${buisner == 1 ? "actpio" : ""}`,
                ].join()}
                onClick={() => {
                  setBuisner(1);
                }}
              >
                <div className="cneder_item_puinser">3/5</div>
                <div
                  className={[
                    `item_puinser_ire ${buisner == 1 ? "actpioCLii" : ""}`,
                  ].join()}
                >
                  Wild Court
                </div>
                <div className="item_puinser_fonter">
                  <div>1 VS 1</div>
                  <div>anyone can enter the showdown</div>
                </div>
              </div>
              <div
                className={[
                  `cneder_item2 ${buisner == 2 ? "actpio" : ""}`,
                ].join()}
                onClick={() => {
                  setBuisner(2);
                }}
              >
                <div className="cneder_item_puinser">3/5</div>
                <div
                  className={[
                    `item_puinser_ire ${buisner == 2 ? "actpioCLii" : ""}`,
                  ].join()}
                >
                  Pro Stadium
                </div>
                <div className="item_puinser_fonter">
                  <div>Team</div>
                  <div>Surcharge</div>
                </div>
              </div>
              <div
                className={[
                  `cneder_item3 ${buisner == 3 ? "actpio" : ""}`,
                ].join()}
                onClick={() => {
                  setBuisner(3);
                }}
              >
                {usePri ? (
                  <div className="cneder_item_puinser">3/5</div>
                ) : (
                  <div className="cneder_item_shuo"></div>
                )}
                <div
                  className={[
                    `item_puinser_ire ${buisner == 3 ? "actpioCLii" : ""}`,
                  ].join()}
                >
                  Private Pitch
                </div>
                <div className="item_puinser_fonter">
                  <div>Team</div>
                  <div>player setup fee</div>
                </div>
              </div>
            </div>
            <div className="Court_nro_reft">
              <img src={require("../../assets/image/999999 1.png")} alt="" />
            </div>
          </div>
          <div className="Cputernr">
            <div className="Cputernr_ripo">
              <div
                className="Cputernr_ripo_item"
                onClick={() => {
                  GameShowMarket();
                }}
              >
                <img
                  src={require("../../assets/image/tabler_brand-appgallery.png")}
                  alt=""
                />
                <div>Market</div>
              </div>
              <div
                className="Cputernr_ripo_item"
                onClick={() => {
                  GameShowHave();
                }}
              >
                <img
                  src={require("../../assets/image/akar-icons_shipping-box-01.png")}
                  alt=""
                />
                <div>NFT</div>
              </div>
              <div
                className="Cputernr_ripo_item"
                onClick={() => {
                  GameShowGemo();
                }}
              >
                <img src={require("../../assets/image/busien.png")} alt="" />
                <div>Create</div>
              </div>
              <div
                className="Cputernr_ripo_item"
                onClick={() => {
                  GameShowLInk();
                }}
              >
                <img src={require("../../assets/image/invita.png")} alt="" />
                <div>Link</div>
              </div>
              <div className="Contter">
                <div className="title_nuri">
                  <div className="title_nuri_img">
                    <img src={require("../../assets/image/IMAGE.png")} alt="" />
                  </div>
                  <div className="title_nuri_ntor">
                    <span>{binder2}</span>
                  </div>
                  <div
                    className="title_nuri_ifro"
                    onClick={() => {
                      setisExchange(true);
                    }}
                  >
                    <img
                      src={require("../../assets/image/Group4388.png")}
                      alt=""
                    />
                  </div>
                </div>
              </div>
            </div>
            <button className="Insutoe" onClick={() => {}}></button>
          </div>
        </div>
      </div>

      {/* 兑换代币 */}
      {isExchange ? (
        <div className="pserExchange">
          <div
            className="pserzhes"
            onClick={() => {
              setisExchange(false);
            }}
          ></div>
          <div className="pserExchange">
            <div className="pserExchange_title">
              <div>购买代币</div>
              <div
                className="cposien"
                onClick={() => {
                  setisExchange(false);
                }}
              >
                <CloseCircleOutlined
                  style={{
                    fontSize: "30px",
                  }}
                />
              </div>
            </div>
            <div className="pserExchange_nro">
              {prins ? llerinow() : llerinow2()}
              <div className="Bunioser">
                <img
                  src={require("../../assets/image/xibiao.png")}
                  alt=""
                  onClick={() => {
                    setPrins(!prins);
                  }}
                />
              </div>
              {prins ? llerinow2() : llerinow()}
              <div className="Busnuer">
                <span>{iceFor} USDT≈1</span>{" "}
                <img src={require("../../assets/image/IMAGE.png")} alt="" />
              </div>
              <div className="Buotn">
                {allowance ? (
                  <button
                    onClick={() => {
                      BuyonAller();
                    }}
                  >
                    授权
                  </button>
                ) : (
                  <>
                    {prins ? (
                      <button
                        onClick={() => {
                          BuyonClick();
                        }}
                      >
                        BUY
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          SELLClick();
                        }}
                      >
                        SELL
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      {/* 绑定 */}
      {isBindenge ? (
        <div className="pserExchange">
          <div
            className="pserzhes"
            onClick={() => {
              setisBindenge(false);
            }}
          ></div>
          <div className="pserPusienr">
            <div className="pioseseroie">
              <input
                value={pinput}
                onChange={(e) => {
                  setPinput(e.target.value);
                }}
                type="text"
                placeholder="输入邀请人钱包"
              />
              <button
                onClick={() => {
                  BindeonClick();
                }}
              >
                绑定
              </button>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      {/* 提示 */}
      {isTimese ? (
        <div className="pserExbuse">
          <div className="pserzhes"></div>
          <div className="pserTise">
            <div className="pserExchange_nro">
              <div className="nriopsr">
                <div className="logding">
                  {(oreTime as any).oreTime === 1 ? (
                    <RedoOutlined spin className="Luiisnr" />
                  ) : (oreTime as any).oreTime === 2 ? (
                    <CheckCircleOutlined className="Luiisnr" />
                  ) : (
                    <CloseCircleOutlined className="Luiisnr" />
                  )}
                </div>
                <div className="Ptimeb">{(oreTime as any).gontime}</div>
              </div>
              <div
                className="gbuiengkum"
                onClick={() => {
                  showHide2();
                }}
              >
                <CloseCircleOutlined
                  style={{
                    color: "#ffff",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  );
};

export default Court;
