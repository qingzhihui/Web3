import { Image, Input, Select, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { DeleteOutlined, AlignCenterOutlined } from "@ant-design/icons";

// 酒店订单界面
const HotelOrdersPage = () => {
  interface DataType {
    key: React.Key;
    orderNumber: string; //订单号
    userNick: string; //用户昵称
    userImg: string; //用户头像
    hotelName:string // 酒店名称
    occupant: string // 入住人
    numberOfRooms: string //房间数
    dateOfCheckIn:string // 入住日期
    checkOut:string // 退房日期
    occupancyType:string //入住房型
    numberOfBreakfast:string // 早餐数量
    hotelTotalPrice: string // 酒店总价格
  }
  const data: DataType[] = [
    {
      key: 1,
      orderNumber: "111654947818",
      userNick: "微信用户",
      userImg: "https://img1.baidu.com/it/u=1984993866,886139931&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1679763600&t=f96448b65970f307ebe451847a2a0315",
      hotelName: "珠海xxxx酒店",
      occupant: "光头强",
      numberOfRooms: "1",
      dateOfCheckIn: "2022-01-01",
      checkOut: "2022-02-01",
      occupancyType: "豪华房",
      numberOfBreakfast: "1",
      hotelTotalPrice:"3437.00"
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "订单号",
      dataIndex: "orderNumber",
      width: 120,
    },
    {
      title: "用户昵称",
      dataIndex: "userNick",
      width: 120,
    },
    {
      title: "用户头像",
      width: 80,
      render: (_, record) => (
        <Space size="middle">
          <Image width={60} height={50} src={record.userImg} />
        </Space>
      ),
    },

    {
      title: "酒店名称",
      dataIndex: "hotelName",
      width: 120,
    },
    {
      title: "入住人",
      width: 80,
      dataIndex: "occupant",
    },
    {
      title: "房间数",
      width: 80,
      dataIndex: "numberOfRooms",
    },
    {
      title: "入住日期/退房日期",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
         <span>{record.dateOfCheckIn}</span>—<span>{record.checkOut}</span>
        </Space>
      ),
    },
    {
      title: "入住房型",
      // width: 120,
      dataIndex: "occupancyType",
    },
    {
      title: "早餐数量",
      width:100,
      dataIndex: "numberOfBreakfast",
    },
    {
      title: "酒店总价格",
      // width:120,
      dataIndex: "hotelTotalPrice",
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <span className="hot_order_memberCursor" onClick={lookover(record)}>
            {/* <FormOutlined /> */}
            <AlignCenterOutlined />
          </span>
          <span className="hot_order_memberCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 头部下拉选择框-内容
  const options1 = [
    {
      value: "1",
      label: "全部",
    },
    {
      value: "2",
      label: "部分",
    },
  ];

  // 头部下拉选择框-内容---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log(value);
  };
  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 查看
  const lookover = (record: any) => {
    return () => {
      console.log("点击了查看");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };

  return (
    <div className="hot_order_Box">
      <div className="hot_order_headerBox">
        <div className="hot_order_headerBox_thread"></div>
        <div className="hot_order_headerBox_Tit">&nbsp;&nbsp;&nbsp; 酒店订单</div>
        <div className="hot_order_Add_moban">
          <div className="hot_order_seekBtn" onClick={adminSearch}>
            <Select
              labelInValue
              defaultValue={{ value: "1", label: "全部" }}
              style={{ width: 120 }}
              onChange={handleChange1}
              options={options1}
            />
          </div>
        </div>
      </div>

      <div className="hot_order_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default HotelOrdersPage;
