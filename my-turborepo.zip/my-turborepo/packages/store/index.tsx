import { create } from "zustand";

export type Movie = {
  title: string;
  image: string;
};

export const useStore = create<{
  movies: Movie[];
  addMovie: (movie: Movie) => void;
}>((set: any) => ({
  movies: [],
  addMovie: (movie: any) =>
    set((state: any) => ({
      movies: [...state.movies, movie],
    })),
}));
