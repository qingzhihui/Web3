
// 不使用接口（匿名方式）
// function greetm(person: { name: string; age: number }) {
//   return "Hello" + person.name;
// }


// 接口方式
// interface Person {
//   name: string;
//   age: number;
// }

// function greetm(person:Person){
//     return "Hello" + person.name;
// }


// 类型别名
type Person = {
    name:string,
    age:number
}
function greetm(person:Person){
    return "Hello" + person.name;
}

