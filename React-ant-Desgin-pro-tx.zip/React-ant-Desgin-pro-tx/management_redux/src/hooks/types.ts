export interface Todo {
  id: number;
  name: string;
  sage: number;
  first: string;
  state: boolean;
}

export interface TodoStore {
  todos: Todo[];
}


export interface TableHeader {
  field: number;
  headerName: string;
}
