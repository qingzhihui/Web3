import React from "react";

function IDO() {
  const cheser = () => {
  };
  return (
    <div>
      Invitation
      <button
        onClick={() => {
          cheser();
        }}
      >
        ches
      </button>
    </div>
  );
}

export default IDO;
