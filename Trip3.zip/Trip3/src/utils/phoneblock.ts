export const PhoneBlock: any = [
    {
        key: "1",
        label: "+86",
    },
    {
        key: "2",
        label: "+852",
    },
    {
        key: "3",
        label: "+853",
    },
    {
        key: "4",
        label: "+886",
    }
];
