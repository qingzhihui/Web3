import React, { Component } from "react";

class Lee2 extends Component {
  constructor(props: any) {
    super(props);
    this.say = this.say.bind(this);
  }
  say() {
    console.log("say");
  }
  say1 = () => {
    console.log("say1");
  };
  say2 = (str: string) => {
    console.log(str);
  };
  render() {
    return (
      <div>
        <button onClick={this.say}>click</button>
        <br />
        <button onClick={this.say1}>click1</button>
        <br />
        <button
          onClick={() => {
            this.say2("syc2");
          }}
        >
          click2
        </button>
      </div>
    );
  }
}

export default Lee2;
