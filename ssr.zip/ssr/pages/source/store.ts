function createStore(initialState: any) {
  let currentState = initialState;
  const listeners = new Set();
  let isInitialized: boolean = false;
  return {
    getState: () => currentState,
    setState: (newState: any) => {
      currentState = newState;
      listeners.forEach((listener: any) => listener(createStore));
    },
    subscribe: (listener: any) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    serverInitialize: (initialState: any) => {
      if (!isInitialized) {
        currentState = initialState;
        isInitialized = true;
      }
    },
  };
}

const store = createStore({
  value1: 0,
  value2: 0,
});

export default store;
