import React, { useState } from 'react';
import type { RadioChangeEvent } from 'antd';
import { Radio } from 'antd';
import './index.scss'
import Eventcard from '@/components/Eventcard'

export default function Index() {
  const [value, setValue] = useState(1);
  const [selects, setSelects] = useState(1);

  const onChange = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue(e.target.value);
  };
  return (
    <div className='evening'>
      <div className='eveningtop'>
        <div className='toptitle'>
          <div className='titlegood'>
            <div className='good'>Hi,good evening!</div>
            <div className='flightstart'>Start your new flight journey here!</div>
          </div>
          <img src={require('@/assets/image/group69.png')} alt="" />
        </div>
        <div className='topbuttom'>
          <div className='oneway'>
            <div className={selects === 1 ? "select" : ''} onClick={() => { setSelects(1) }}>One-way</div>
            <div className={selects === 2 ? "select" : ''} onClick={() => { setSelects(2) }}>Round-trip</div>
          </div>
          <div className='evencity'>
            <div className='citytop'>
              <img src={require('@/assets/image/tablerbrand.png')} alt="" />
              <div className='addrname'>departure city</div>
              <div className='addr'>Bei jing</div>
            </div>
            <div className='citybuttom'>
              <img src={require('@/assets/image/tablermap.png')} alt="" />
              <div className='addrname'>arrival city</div>
              <div className='addr'>Paris</div>
              <div className='imgs'><img src={require('@/assets/image/group70.png')} alt="" /></div>
            </div>
          </div>
          <div className='eventdates'>
            <img src={require('@/assets/image/ph.png')} alt="" />
            <div>Friday, December 9, 2022</div>
          </div>
          <div className='eventadd'>
            <img src={require('@/assets/image/user.png')} alt="" />
            <div className='oneadd'>
              <div className='name'>aldult</div>
              <div className='addr'>
                <div>-</div>
                <div>0</div>
                <div>+</div>
              </div>
            </div>
            <div className='twoadd'>
              <div className='name'>aldult</div>
              <div className='addr'>
                <div>-</div>
                <div>0</div>
                <div>+</div>
              </div>
            </div>
          </div>
          <div className='eventseleked'>
            <img src={require('@/assets/image/tablerarmchair.png')} alt="" />
            <Radio.Group onChange={onChange} value={value}>
              <Radio value={1}>first class</Radio>
              <Radio value={2}>business class</Radio>
              <Radio value={3}>economy class</Radio>
            </Radio.Group>
          </div>
          <div className='eventbut'>INQUIRE</div>
        </div>
      </div>
      <div className='eveningbuttom'>
        <div className='countent'>
          <div className='eventtitle'>Popular routes</div>
          <Eventcard />
          <Eventcard />
          <Eventcard />
        </div>
      </div>
    </div>
  )
}
