import { createRouter, createWebHistory } from "vue-router";
import HomeView from "@/views/Home.vue";
import AboutView from "@/views/About.vue";
import DemoView from "@/views/Demo9.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "首页",
      component: HomeView,
    },
    {
      path: "/about",
      name: "关于",
      component: AboutView,
    },
    {
      path: "/demo",
      name: "案例",
      component: DemoView,
    },
  ],
});

export default router;
