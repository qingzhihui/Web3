import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { Modal } from "antd";
import NodeWalletConnect from "@walletconnect/node";
import WalletConnectQRCodeModal from "@walletconnect/qrcode-modal";
import type { MenuProps } from "antd";
import { Trans } from "react-i18next";
import { Button, Dropdown, Menu, Space } from "antd";
import { ExportOutlined } from "@ant-design/icons";
import MetamaskLogo from "../../assets/image/MetamaskLogo.png";
import TokenPocketLogo from "../../assets/image/TokenPocketLogo.png";
import WalletConnectLogo from "../../assets/image/WalletConnectLogo.png";
import loge from "../../assets/image/loge.png";
import puse from "../../assets/image/zhuang.png";
import { ethers } from "ethers";
import "./index.css";
import i18n from "../../i18n";
declare const window: Window & { ethereum: any };

export default function Header(props: { MsgIndex?: string; address?: string }) {
  const Meslei = [
    {
      label: "繁体",
      key: "1",
    },
    {
      label: "English",
      key: "2",
    },
  ];
  const Mespuser = [
    {
      label: (
        <div className="pserivkie">
          <div className="pserivkie_title">
            {" "}
            <Trans>Disconnect</Trans>
          </div>
          <div className="pserivkie_loger">
            {" "}
            <ExportOutlined style={{ fontSize: "16px" }} />
          </div>
        </div>
      ),
      key: "1",
    },
  ];
  const [headIndex, setheadIndex] = useState(0);
  const [connectModal, setConnectModal] = useState(false);
  const [WalletAccount, setWalletAccount] = useState("");
  const [handelvoice, setHandelvoice] = useState("繁体");
  const history = useHistory();
  const setHeadTabIndex = (index: number, url: string) => {
    setheadIndex(index);
    history.push(`/${url}`);
  };

  // 切换网络
  const MetamShow = async () => {
    const provider = window.ethereum;
    const chainId = await provider.request({ method: "eth_chainId" });
    const binanceTestChainId = "0x61";
    if (chainId === binanceTestChainId) {
      connectWallet();
    } else {
      try {
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: binanceTestChainId }],
        });
        console.log(
          "You have succefully switched to Binance Smart Chain Testnet"
        );
        connectWallet();
      } catch (switchError: any) {
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [
                {
                  chainId: "0x61",
                  chainName: "Binance Smart Chain Testnet",
                  nativeCurrency: {
                    name: "Binance Test Coin",
                    symbol: "tBNB",
                    decimals: 18,
                  },
                  blockExplorerUrls: ["https://testnet.bscscan.com"],
                  rpcUrls: ["https://data-seed-prebsc-1-s1.binance.org:8545"],
                },
              ],
            });
          } catch (addError) {
            console.error(addError);
          }
        }
        console.log("Failed to switch to the network");
      }
    }
  };
  const connectWallet = async () => {
    try {
      const { ethereum } = window;
      if (!ethereum) {
        alert("Get MetaMask!");
        return;
      }
      const accounts = await ethereum.request({
        method: "eth_requestAccounts",
      });
      if (accounts[0]) {
        localStorage.setItem("Meat_addr", accounts[0]);
        setWalletAccount(accounts[0]);
        setConnectModal(false);
      }
    } catch (error) {
      console.log(error);
    }
  };
  const connectWalletConnect = () => {
    try {
      const walletConnector = new NodeWalletConnect(
        {
          bridge: "https://bridge.walletconnect.org", // Required
        },
        {
          clientMeta: {
            description: "WalletConnect NodeJS Client",
            url: "https://nodejs.org/en/",
            icons: ["https://nodejs.org/static/images/logo.svg"],
            name: "WalletConnect",
          },
        }
      );
      if (!walletConnector.connected) {
        walletConnector.createSession().then(() => {
          const uri = walletConnector.uri;
          WalletConnectQRCodeModal.open(uri, () => {
            console.log("QR Code Modal closed");
          });
        });
      }
      walletConnector.on("connect", (error: any, payload: any) => {
        if (error) {
          throw error;
        }
        WalletConnectQRCodeModal.close();
        const { accounts, chainId } = payload.params[0];
        console.log("链ID ", chainId);
        let myeth = accounts[0];
        localStorage.setItem("Meat_addr", myeth);
        let wallet = myeth.slice(0, 6) + "..." + myeth.slice(-4);
        console.log("wallet address ", wallet);
      });
    } catch (ex) {
      console.log(ex);
    }
  };
  const handleMenuClick: MenuProps["onClick"] = (e) => {
    setHandelvoice(Meslei[Number(e.key) - 1].label);
    if (e.key == "1") {
      i18n.changeLanguage("zh-tw");
    } else {
      i18n.changeLanguage("en");
    }
  };
  const handleMenuClickPuier: MenuProps["onClick"] = (e) => {
    if (e.key == "1") {
      setWalletAccount("");
      window.localStorage.clear();
    }
  };
  const menu = <Menu onClick={handleMenuClick} items={Meslei} />;
  const menuPuier = <Menu onClick={handleMenuClickPuier} items={Mespuser} />;
  useEffect(() => {
    const addr = localStorage.getItem("Meat_addr");
    if (addr !== null && addr !== undefined) {
      setheadIndex(Number(props.MsgIndex));
      setWalletAccount(addr);
      if(i18n.language === "en"){
        setHandelvoice('English')
      }else{
        setHandelvoice('繁体')
      }
      
    } else {
      setheadIndex(Number(props.MsgIndex));
      MetamShow();
    }
  }, [props, headIndex]);
  useEffect(() => {
    (window as any).ethereum.on(
      "accountsChanged",
      async function (accounts: any) {
        localStorage.setItem("Meat_addr", accounts[0]);
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        setWalletAccount(accounts[0]);
      }
    );
  }, [WalletAccount]);
  return (
    <div className="Headerpser">
      <div className="HeaderPage">
        <div className="headTitle">
          <img src={loge} alt="" />
        </div>
        <div className="HeaderButtonArea">
          <div
            className="buttonArea"
            role="button"
            tabIndex={0}
            onKeyDown={() => {
              setHeadTabIndex(1, "HOME");
            }}
            onClick={() => {
              setHeadTabIndex(1, "HOME");
            }}
          >
            {/* {t("HOME")} */}
            <div className="buttonText">
              <Trans>HOME</Trans>
            </div>
            <div
              className="buttonLine"
              style={{
                background: headIndex === 1 ? "#fff" : "transparent",
              }}
            />
          </div>

          <div
            className="buttonArea"
            role="button"
            tabIndex={0}
            onKeyDown={() => {
              setHeadTabIndex(2, "FARM");
            }}
            onClick={() => {
              setHeadTabIndex(2, "FARM");
            }}
          >
            <div className="buttonText">
              <Trans>FARM</Trans>
            </div>
            <div
              className="buttonLine"
              style={{ background: headIndex === 2 ? "#fff" : "transparent" }}
            />
          </div>

          <div
            className="buttonArea"
            role="button"
            tabIndex={0}
            onKeyDown={() => {
              setHeadTabIndex(3, "NFT");
            }}
            onClick={() => {
              setHeadTabIndex(3, "NFT");
            }}
          >
            <div className="buttonText">
              <Trans>NFT</Trans>
            </div>
            <div
              className="buttonLine"
              style={{ background: headIndex === 3 ? "#fff" : "transparent" }}
            />
          </div>

          <div
            className="buttonArea"
            role="button"
            tabIndex={0}
            onKeyDown={() => {
              setHeadTabIndex(5, "MARKET");
            }}
            onClick={() => {
              setHeadTabIndex(5, "MARKET");
            }}
          >
            <div className="buttonText">
              <Trans>MARKET</Trans>
            </div>
            <div
              className="buttonLine"
              style={{
                background: headIndex === 5 ? "#fff" : "transparent",
              }}
            />
          </div>

          <div
            className="buttonArea"
            role="button"
            tabIndex={0}
            onKeyDown={() => {
              setHeadTabIndex(4, "Inveta");
            }}
            onClick={() => {
              setHeadTabIndex(4, "Inveta");
            }}
          >
            <div className="buttonText">
              <Trans>Inveta</Trans>
            </div>
            <div
              className="buttonLine"
              style={{ background: headIndex === 4 ? "#fff" : "transparent" }}
            />
          </div>
        </div>
        <Modal
          title=" "
          width={450}
          open={connectModal}
          onOk={() => {
            setConnectModal(true);
          }}
          onCancel={() => {
            setConnectModal(false);
          }}
          centered={true}
          footer={null}
        >
          <div className="modalContent">
            <span className="connectTitle">
              <Trans>Connect Wallet</Trans>
            </span>
            <div
              className="connectbtnItem"
              onClick={() => {
                MetamShow();
              }}
            >
              <img src={MetamaskLogo} alt="" />
              <span>MetaMask</span>
            </div>
            <div
              className="connectbtnItem"
              onClick={() => {
                MetamShow();
              }}
            >
              <img src={TokenPocketLogo} alt="" />
              <span>Token Pocket</span>
            </div>
            <div
              className="connectbtnItem"
              onClick={() => {
               connectWalletConnect();
              }}
            >
              <img src={WalletConnectLogo} alt="" />
              <span>WalletConnect</span>
            </div>
          </div>
        </Modal>
        <div className="speiuise">
          <div className="sapeien">
            <Dropdown
              overlay={menu}
              placement="bottom"
              arrow={{ pointAtCenter: true }}
            >
              <Button>
                <Space>
                  <div className="speriise">
                    <img src={puse} alt="" />
                    <div className="psoduenxc">{handelvoice}</div>
                  </div>
                </Space>
              </Button>
            </Dropdown>
          </div>
          {WalletAccount === "" && (
            <button
              className="connectbtn"
              style={{ cursor: "pointer" }}
              onClick={() => {
                setConnectModal(true);
              }}
            >
              <Trans>Connect Wallet</Trans>
            </button>
          )}
          {WalletAccount !== "" && (
            <Dropdown
              overlay={menuPuier}
              placement="bottomRight"
              arrow={{ pointAtCenter: true }}
            >
              <div className="speirbbse">
                <div className="rieier">
                  {" "}
                  {WalletAccount.substring(0, 4) +
                    "..." +
                    WalletAccount.substring(38, 42)}
                </div>
              </div>
            </Dropdown>
          )}
        </div>
      </div>
    </div>
  );
}
