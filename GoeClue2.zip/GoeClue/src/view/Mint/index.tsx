import React, { useEffect, useState } from "react";
import "./index.scss";
import { ethers } from "ethers";
import { useHistory } from "react-router-dom";
import {
  playerNFT_ADDRESS,
  playerNFT_ABI,
} from "../../redux/Contract/playerNFTContract";
import Header from '../../components/Header'
import { token_ABI } from "../../redux/Contract/tokenContract";
import userbox from "../../assets/image/userbox.png";
declare const window: Window & { ethereum: any };


const Mint = () => {
  const [ShowBren, setShowBren] = useState(true);
  const [isTimese, setisTimese] = useState(false);
  const [steNume, setsteNume] = useState(1);
  let history = useHistory();
  const [oreTime, setoreTime] = useState({
    gontime: "",
    oreTime: 1,
  });
  const AlperClikc = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const playerNFTContract = new ethers.Contract(
        playerNFT_ADDRESS,
        playerNFT_ABI,
        signer
      );
      const purchaseTokenAddress = await playerNFTContract.purchaseToken();
      const purchaseTokenContract = new ethers.Contract(
        purchaseTokenAddress,
        token_ABI,
        signer
      );
      const approve = await purchaseTokenContract.approve(
        playerNFT_ADDRESS,
        ethers.constants.MaxUint256
      );
      setoreTime({ gontime: "授权中", oreTime: 1 });
      setisTimese(true);
      await approve.wait();
      setShowBren(false);
      setoreTime({ gontime: "授权成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "授权失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const MintonClikc = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const playerNFTContract = new ethers.Contract(
        playerNFT_ADDRESS,
        playerNFT_ABI,
        signer
      );
      const Minte = await playerNFTContract.mint(steNume, { gasLimit: 650000 });
      setoreTime({ gontime: "购买中...", oreTime: 1 });
      setisTimese(true);
      await Minte.wait();
      setShowBren(false);
      setoreTime({ gontime: "购买成功", oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: "购买失败", oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  return (
    <div className="mint">
        <Header />
        <div className="pminte">
        <div className="gp-contain__mint">
        <div className="mint_players">
          <div className="count">
            <div>
              <img src={userbox} alt="" />
            </div>
            <div className="parlty">
              <div className="front">Rarity:</div>
              <div className="nrsr">N 70% R 15% SR 9% SSR 5% UR 1%</div>
            </div>
            <div className="price">
              <div className="front"> Price:</div>
              <div className="nrsr">
                150
                <div className="doller" />
              </div>
            </div>
            <div className="calculator">
              <div className="sub">-</div>
              <div className="num">1</div>
              <div className="sub">+</div>
            </div>
            <div className="footer"></div>
          </div>
        </div>
        <div className="mintioe">
          {ShowBren ? (
            <button
              onClick={() => {
                AlperClikc();
              }}
            >
              授权
            </button>
          ) : (
            <button
              onClick={() => {
                MintonClikc();
              }}
            >
              MINT
            </button>
          )}
        </div>
        <div className="mint_title">
          The total has 4 types of farmer boxes, each level of the farmer box
          can open one farmer with a specific rarity in rate. Don't miss the
          chance to own the farmer have more efficiency and make a great FCC
          reward! Note: The INO Farmer Box can be open when the game officially
          launches, before that you can check how many boxes you have bought at
          the bottom of the page, the Inventory column.
        </div>
      </div>
        </div>
    </div>
  );
};

export default Mint;
