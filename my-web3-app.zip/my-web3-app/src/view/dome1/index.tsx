import React, { useEffect, useState } from "react";
import { init, LpdateShow } from "./web3Client";
declare const window: Window & { ethereum: any };

function Dome1() {
  const [mined, setMinted] = useState(false);

  useEffect(()=>{
    init()
  },[])
  const lpDateonClick = () => {
    LpdateShow()
      .then((res: any) => {
        console.log(res);
        setMinted(true);
      })
      .catch((err: any) => {
        console.log(err);
      });
  };
  return (
    <div className="App">
      {!mined ? (
        <button
          onClick={() => {
            lpDateonClick();
          }}
        >
          Mint token
        </button>
      ) : (
        <p>Token minted successfully!</p>
      )}
    </div>
  );
}

export default Dome1;
