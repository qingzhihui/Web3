import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import tabler_droplet_share from "../../assets/image/tabler_droplet-share.png";
import FooterGenera from "../../components/FooterGenera";
import ico1 from "../../assets/image/ico1.png";
import ico2 from "../../assets/image/ico2.png";
import ico3 from "../../assets/image/ico3.png";
import ico4 from "../../assets/image/ico4.png";
import flab from "../../assets/image/flab.png";

import ofter1 from "../../assets/image/Edit.png";
import ofter2 from "../../assets/image/Info.png";
import ofter3 from "../../assets/image/Profile.png";

import "./index.scss";
import "./mobile.scss";
import { FooterComponent } from "../../styles/styles";
import { onScroll } from "../../hooks/config";

const Home = () => {
  const { t } = useTranslation();
  useEffect(() => {}, []);

  return (
    <div className="Home">
      <div className="HomeContent" id={"longTable"} onScroll={onScroll}>
        <div className="HomeComponentPlonks">
          <div className="HomeContentItem">
            <div className="HomeComponentBuien">
              <div className="HomeComponentBuienItem">
                <div className="HomeComponentBuienValine">
                  <div className="BuienItemValiue">
                    {`${t("Empowering VR to enhance people's lives.")}`}
                  </div>
                  <div className="BuienItemButtonBox">
                    <div className="BuienItemButton">
                      <button> {`${t("GET STARTED")}`}</button>
                    </div>
                    <div className="BuienItemButton BuienItemButton2">
                      <button>
                        {`${t("LEARN MORE")}`}
                        <img src={tabler_droplet_share} alt="" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="HomeComponentBuienItem2"></div>
            </div>
          </div>
          <div className="HomeComponentWorks">
            <div className="HomeWorksHowDev">
              <div className="HomeWorksHow">
                <div className="HomeWorksTitle">{`${t("How it Works")}`}</div>
                <div className="HomeWorksRole">
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico1} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">
                      {`${t("Set up your Wallet")}`}
                    </div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "Once you've set up your wallet of choice, connect it to OpenSeaby clicking the NFT Marketplacein the top right corner."
                      )}`}
                    </div>
                  </div>
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico2} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">
                      {`${t("Create your Collection")}`}
                    </div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "Click Create and set up your collection. Add social links, a description, profile & banner images, and set a secondary sales fee."
                      )}`}
                    </div>
                  </div>
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico3} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">
                      {`${t("Add your NFTs")}`}
                    </div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "Upload your work (image, video, audio, or 3D art), add a title and description, and customize your NFTs with properties, stats"
                      )}`}
                    </div>
                  </div>
                  <div className="HomeWorksProleItem">
                    <div className="HomeWorksProleItemImage">
                      <img src={ico4} alt="" />
                    </div>
                    <div className="HomeWorksProleItemTitle">
                      {`${t("List them for Sale")}`}
                    </div>
                    <div className="HomeWorksProleItemValue">
                      {`${t(
                        "Choose between auctions, fixed-price listings, and declining-price listings. You choose how you want to sell your NFTs!"
                      )}`}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="HomeWorksSpecieDev">
              <div className="HomeComponentSpecie">
                <div className="HomeSpecieLength">
                  <div className="HomeSpecieLengthItem">
                    <div className="HomeSpecieLengthItemTitle">
                      {`${t("Specialist with Over12+ Years of Experience")}`}
                    </div>
                    <div className="HomeSpecieLengthItemValue">
                      {`${t(
                        "Cursus sit amet dictum sit amet justo donec enim. Auctor neque vitae tempus quam pellentesque nec nam aliquam sem. Morbi tincidunt augue interdum velit euismod in pellentesque. Quam vulputate dignissim suspendisse in est ante in. Dolor morbi non arcu risus quis varius quam quisque id. Eu lobortis elementum nibh tellus molestie nunc non. Dui nunc mattis enim ut tellus elementum."
                      )}`}
                    </div>
                  </div>
                </div>
                <div className="HomeSpecieRental">
                  <img src={flab} alt="" />
                </div>
              </div>
            </div>
            <div className="HomeComponentFooterDev">
              <div className="HomeComponentFooter">
                <div className="HomeComponentFooterTitle">
                  {`${t("Top Our Service Highlight")}`}
                </div>
                <div className="HomeComponentFooterVine">
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={ofter1} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemTitle">
                      {`${t("Clear Rules & Visible Effect")}`}
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      {`${t(
                        "Dignissim enim sit amet venenatis urna cursus eget nunc scelerisque amet risus nullam eget felis eget nunc lobortis."
                      )}`}
                    </div>
                  </div>
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={ofter2} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemTitle">
                      {`${t("We Embody Creativity")}`}
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      {`${t(
                        "Commodo ullamcorper a lacus vestibulum sed arcu non odio euismod pellentesque diam volutpat commodo sed egestas."
                      )}`}
                    </div>
                  </div>
                  <div className="HomeComponentFooterItem">
                    <div className="HomeComponentFooterItemImage">
                      <img src={ofter3} alt="" />
                    </div>
                    <div className="HomeComponentFooterItemTitle">
                      {`${t("Hello, We Passionate Team")}`}
                    </div>
                    <div className="HomeComponentFooterItemValue">
                      {`${t(
                        "Auctor augue mauris augue neque gravida in fermentum. Viverra vitae congue eu consequat et odio varius sit amet mattis vulputate ."
                      )}`}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <FooterComponent>
            <FooterGenera />
          </FooterComponent>
        </div>
      </div>
    </div>
  );
};

export default Home;
