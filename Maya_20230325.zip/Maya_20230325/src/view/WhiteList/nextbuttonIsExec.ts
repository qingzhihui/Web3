import { WhitelistProps } from "../../hooks/launchpad";
import { CreateLaunchpadError } from "../../hooks/Errorhandle";

// 未点击usevest状态下
const NotUseVestIsNext = (WhitelistData: WhitelistProps) => {
    if (WhitelistData.prerate
        && WhitelistData.softcap
        && WhitelistData.hardcap
        && WhitelistData.minbuy
        && WhitelistData.maxbuy
        && WhitelistData.liquidity
        && WhitelistData.listingrate
        && WhitelistData.lockup
        && WhitelistData.Starttime
        && WhitelistData.Endtime) {
        return true
    } else {
        return false
    }
}

// 点击usevest状态下
const UseVestIsNext = (WhitelistData: WhitelistProps) => {
    if (NotUseVestIsNext(WhitelistData)
        && WhitelistData.firstrelease
        && WhitelistData.vestperiod
        && WhitelistData.pretokencycle) {
        return true
    } else {
        return false
    }
}

const PrivateSaleIsNext = (WhitelistData: WhitelistProps) => {
    if ((WhitelistData.softcap)
        && (WhitelistData.hardcap)
        && (WhitelistData.minbuy)
        && (WhitelistData.maxbuy)
        && (WhitelistData.firstrelease)
        && (WhitelistData.vestperiod)
        && (WhitelistData.pretokencycle)
        && (WhitelistData.Starttime)
        && (WhitelistData.Endtime)) {
        return true
    } else {
        return false
    }
}

const errorJudgement = (url: unknown, CreateLaunchpadError: CreateLaunchpadError, usevest: boolean) => {
    switch (url) {
        // 启动板页面进入页面
        case "Lauchpad":
            // 选择了vest
            if (usevest) {
                if (!CreateLaunchpadError.TokenAddressBlankError
                    && !CreateLaunchpadError.TokenAddressInvalidError
                    && !CreateLaunchpadError.PresaleRateBlankError
                    && !CreateLaunchpadError.PresaleRatePositiveError
                    && !CreateLaunchpadError.SoftCapBlankError
                    && !CreateLaunchpadError.SoftCapPositiveError
                    && !CreateLaunchpadError.SoftCapMinError
                    && !CreateLaunchpadError.SoftCapMaxError
                    && !CreateLaunchpadError.HardCapBlankError
                    && !CreateLaunchpadError.HardCapPositiveError
                    && !CreateLaunchpadError.MinimumBuyBlankError
                    && !CreateLaunchpadError.MinimumBuyPositiveError
                    && !CreateLaunchpadError.MinimumBuyMaxError
                    && !CreateLaunchpadError.MaximumBuyBlankError
                    && !CreateLaunchpadError.MaximumBuyPositiveError
                    && !CreateLaunchpadError.LiquidityBlankError
                    && !CreateLaunchpadError.LiquidityMinError
                    && !CreateLaunchpadError.LiquidityMaxError
                    && !CreateLaunchpadError.ListingRateBlankError
                    && !CreateLaunchpadError.ListingRatePositiveError
                    && !CreateLaunchpadError.StartTimeBlankError
                    && !CreateLaunchpadError.StartTimeMinError
                    && !CreateLaunchpadError.StartTimeMaxError
                    && !CreateLaunchpadError.EndTimeBlankError
                    && !CreateLaunchpadError.EndTimeMinError
                    && !CreateLaunchpadError.LockupTimeBlankError
                    && !CreateLaunchpadError.LockupTimeMinError
                    && !CreateLaunchpadError.FirstReleaseBlankError
                    && !CreateLaunchpadError.VestingPeriodBlankError
                    && !CreateLaunchpadError.PresaleTokenBlankError
                    && !CreateLaunchpadError.FeeOverError) {
                    return true
                } else {
                    return false
                }
            } else {
                if (!CreateLaunchpadError.TokenAddressBlankError
                    && !CreateLaunchpadError.TokenAddressInvalidError
                    && !CreateLaunchpadError.PresaleRateBlankError
                    && !CreateLaunchpadError.PresaleRatePositiveError
                    && !CreateLaunchpadError.SoftCapBlankError
                    && !CreateLaunchpadError.SoftCapPositiveError
                    && !CreateLaunchpadError.SoftCapMinError
                    && !CreateLaunchpadError.SoftCapMaxError
                    && !CreateLaunchpadError.HardCapBlankError
                    && !CreateLaunchpadError.HardCapPositiveError
                    && !CreateLaunchpadError.MinimumBuyBlankError
                    && !CreateLaunchpadError.MinimumBuyPositiveError
                    && !CreateLaunchpadError.MinimumBuyMaxError
                    && !CreateLaunchpadError.MaximumBuyBlankError
                    && !CreateLaunchpadError.MaximumBuyPositiveError
                    && !CreateLaunchpadError.LiquidityBlankError
                    && !CreateLaunchpadError.LiquidityMinError
                    && !CreateLaunchpadError.LiquidityMaxError
                    && !CreateLaunchpadError.ListingRateBlankError
                    && !CreateLaunchpadError.ListingRatePositiveError
                    && !CreateLaunchpadError.StartTimeBlankError
                    && !CreateLaunchpadError.StartTimeMinError
                    && !CreateLaunchpadError.StartTimeMaxError
                    && !CreateLaunchpadError.EndTimeBlankError
                    && !CreateLaunchpadError.EndTimeMinError
                    && !CreateLaunchpadError.LockupTimeBlankError
                    && !CreateLaunchpadError.LockupTimeMinError) {
                    return true
                } else {
                    return false
                }
            }

        // 私人售卖页面进入
        case "Sale":
            if (!CreateLaunchpadError.TitleBlankError
                && !CreateLaunchpadError.SoftCapBlankError
                && !CreateLaunchpadError.SoftCapPositiveError
                && !CreateLaunchpadError.SoftCapMinError
                && !CreateLaunchpadError.SoftCapMaxError
                && !CreateLaunchpadError.HardCapBlankError
                && !CreateLaunchpadError.HardCapPositiveError
                && !CreateLaunchpadError.MinimumBuyBlankError
                && !CreateLaunchpadError.MinimumBuyPositiveError
                && !CreateLaunchpadError.MinimumBuyMaxError
                && !CreateLaunchpadError.MaximumBuyBlankError
                && !CreateLaunchpadError.MaximumBuyPositiveError
                && !CreateLaunchpadError.StartTimeBlankError
                && !CreateLaunchpadError.StartTimeMinError
                && !CreateLaunchpadError.StartTimeMaxError
                && !CreateLaunchpadError.EndTimeBlankError
                && !CreateLaunchpadError.EndTimeMinError
                && !CreateLaunchpadError.FirstReleaseBlankError
                && !CreateLaunchpadError.VestingPeriodBlankError
                && !CreateLaunchpadError.PresaleTokenBlankError
                && !CreateLaunchpadError.FeeOverError) {
                return true
            } else {
                return false
            }
    }
}

export function isNext(CreateLaunchpadError: CreateLaunchpadError, url: unknown, usevest: boolean, WhitelistData: WhitelistProps) {
    switch (url) {
        // 启动板页面进入
        case "Lauchpad":
            // 是否使用vest
            if (usevest) {
                if (NotUseVestIsNext(WhitelistData) && UseVestIsNext(WhitelistData) && errorJudgement(url, CreateLaunchpadError, usevest)) {
                    return true
                } else {
                    return false
                }
            } else {
                return (NotUseVestIsNext(WhitelistData) && errorJudgement(url, CreateLaunchpadError, usevest))
            }
        // 私人售卖页面进入
        case "Sale":
            return (PrivateSaleIsNext(WhitelistData) && errorJudgement(url, CreateLaunchpadError, usevest))
    }
}