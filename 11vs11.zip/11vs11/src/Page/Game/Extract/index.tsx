import { useEffect, useState } from "react";
import "./indexs.scss";
import ches from "./ches.png";
import { message } from "antd";
import { ethers } from "ethers";
import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../../../redux/Contract/SmartContract";

import {
  EQUIPMENT_ABI,
  EQUIPMENT_ADDRESS,
} from "../../../redux/Contract/equipmentContract";

import {
  EQUIPMENTFRA_ABI,
  EQUIPMENTFRA_ADDRESS,
} from "../../../redux/Contract/equipmentFragment";

import { FBW_ABI, FBW_ADDRESS } from "../../../redux/Contract/fbwContract";

import BigNumber from "bignumber.js";
import sbeu from "./merge-plus.png";

export default function Merge() {
  const [liShow, setliShow] = useState(false);
  const [address, setAddress] = useState("");
  const [tokenBaLiost, setTokenBaLiost] = useState([]);
  const [tiekm1, setTiekm1] = useState("");
  const [tiimg, setTiimg] = useState("");
  const [Bueshow, setBueshow] = useState(false);
  const [tokenBalan, setTokenBalan] = useState([]);
  const BewngShow = () => {
    setliShow(true);
  };
  const liNSEShow = () => {
    setliShow(false);
  };
  const tokenList = (image: string, id: string) => {
    setTiekm1(id);
    setTiimg(`https://metadata.rektclub.org/ipfs/` + image);
    const duslit = tokenBaLiost;
    duslit.map((item: any) => {
      if (item.tokenId == id) {
        item.reutener = false;
      } else {
        item.reutener = true;
      }
    });
    setTokenBaLiost(duslit);
    setliShow(false);
  };
  const Deklus = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const playerins = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const equipmefent = new ethers.Contract(
      EQUIPMENTFRA_ADDRESS,
      EQUIPMENTFRA_ABI,
      signer
    );
    const equipmences = new ethers.Contract(
      EQUIPMENT_ADDRESS,
      EQUIPMENT_ABI,
      signer
    );
    const fbwinstance = new ethers.Contract(FBW_ADDRESS, FBW_ABI, signer);
    const linkapue = await equipmefent.allowance(addr, EQUIPMENT_ADDRESS);
    const fbwapprove = await fbwinstance.allowance(addr, EQUIPMENT_ADDRESS);
    const playerappro = await playerins.isApprovedForAll(
      addr,
      EQUIPMENT_ADDRESS
    );
    if (playerappro == false) {
      const pappro = await playerins.setApprovalForAll(EQUIPMENT_ADDRESS, true);
      await pappro.wait();
    }
    if (Number(ethers.utils.formatEther(linkapue)) < 300) {
      const apuern = await equipmefent.approve(
        EQUIPMENT_ADDRESS,
        ethers.constants.MaxUint256
      );
      await apuern.wait();
    }
    if (Number(ethers.utils.formatEther(fbwapprove)) < 100) {
      const selos = await fbwinstance.approve(
        EQUIPMENT_ADDRESS,
        ethers.constants.MaxUint256
      );
      await selos.wait();
    }

    try {
      const extractc = await equipmences.extract(tiekm1, { gasLimit: 500000 });
      await extractc.wait();
      const equbalance = await equipmences.balanceOf(addr);
      const lastEquipment = await equipmences.tokenOfOwnerByIndex(
        addr,
        equbalance - 1
      );
      const xytokenid = Number(lastEquipment.toString());
      const quipdata = await equipmences.equipmentDatas(xytokenid);
      console.log(quipdata.addPoint.toString());
      const xytokenuri = await equipmences.tokenURI(xytokenid);
      let tokenBalance: any = [];
      await fetch(xytokenuri)
        .then((response) => response.json())
        .then((data) => {
          const uri = data.image.slice(7);
          tokenBalance.push({
            tokenId: xytokenid.toString(),
            image: uri,
            name: data.name,
            series: data.attributes[0].value,
            class: data.attributes[1].value,
            starlevel: data.attributes[2].value,
            addPoint: quipdata.addPoint.toString()
          });
        });
      setTokenBalan(tokenBalance);
      setBueshow(true);
      setTiimg("");
    } catch (error: any) {
      const beinug = error.data.message.split(":");
      message.error(beinug[2]);
    }
  };
  const porksuerHide = () => {
    setBueshow(false);
  };
  useEffect(() => {
    const Buens = async () => {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const instances = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      );
      const addr = await signer.getAddress();
      setAddress(addr);
      const balance = await instances.balanceOf(addr);
      const bel = ethers.utils.formatEther(balance);
      const nftAmount = new BigNumber(bel)
        .times(new BigNumber(10).pow(18))
        .toString();
      let tokenBalance: any = [];
      for (let i = 0; i < Number(nftAmount); i++) {
        const tokenId = await instances.tokenOfOwnerByIndex(addr, i);
        const playerData = await instances.playerDatas(tokenId);
        const basetokenUri = await instances.tokenURI(tokenId.toString());
        await fetch(basetokenUri)
          .then((response) => response.json())
          .then((data) => {
            const uri = data.image.slice(7);
            if (playerData.unbox === true) {
              tokenBalance.push({
                tokenId: tokenId.toString(),
                image: uri,
                name: data.name,
                rarty: data.attributes[0].value,
                occ: data.attributes[1].value,
                speed: data.attributes[2].value,
                shoot: data.attributes[3].value,
                guard: data.attributes[4].value,
                save: data.attributes[5].value,
                lucky: data.attributes[6].value,
                reveal: true,
                reutener: true,
              });
            } else if (playerData.unbox === false) {
              tokenBalance.push({
                tokenId: tokenId.toString(),
                image: data.image,
                name: data.name,
              });
            }
          });
      }
      setTokenBaLiost(tokenBalance);
    };
    Buens();
  }, [tokenBalan]);
  return (
    <>
      <div
        style={{
          marginTop: "25px",
          display: "flex",
          justifyContent: "center",
        }}
      >
        {/* <button className="common-btn">COMMING SOON</button> */}
      </div>
      <div id="merge2">
        <div className="top">
          <div className="addBox">
            <h1>MAIN Player</h1>
            <div className="box">
              <div
                className="black"
                onClick={() => {
                  BewngShow();
                }}
              >
                <img src={tiimg || sbeu} alt="" />
              </div>
            </div>
          </div>
        </div>
        <button
          className="common-btn"
          onClick={() => {
            Deklus();
          }}
        >
          Extract
        </button>
        {/* 弹框 */}
        {liShow ? (
          <div className="prodios">
            <div className="nsieln">
              <div className="bsuetile">
                <span>我的NFT</span>
              </div>
              <div className="plises">
                {tokenBaLiost.map((item: any) => (
                  <div key={item.tokenId}>
                    {item.reutener == true ? (
                      <div
                        className="nsieln_item"
                        onClick={() => {
                          tokenList(item.image, item.tokenId);
                        }}
                      >
                        <div className="item_title">{item.name}</div>
                        <div className="iteList">
                          <div className="ite_ledrt">
                            <img
                              src={
                                `https://metadata.rektclub.org/ipfs/` +
                                item.image
                              }
                              alt=""
                            />
                          </div>
                          <div className="ite_rest">
                            <div className="bsn">
                              Properties：<span>{item.rarty}</span>
                            </div>
                            <div className="bsn">
                              Speed：<span>{item.speed}</span>
                            </div>
                            <div className="bsn">
                              Shoot：<span>{item.shoot}</span>
                            </div>
                            <div className="bsn">
                              Guard：<span>{item.guard}</span>
                            </div>
                            <div className="bsn">
                              Save：<span>{item.save}</span>
                            </div>
                            <div className="bsn">
                              Lucky：<span>{item.lucky}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                ))}
              </div>
              <div
                className="gubaie"
                onClick={() => {
                  liNSEShow();
                }}
              >
                关闭
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
        {/* nrto */}
        {Bueshow ? (
          <div className="Nubyer">
            {tokenBalan.map((item: any) => (
              <div className="Bueio" key={item.tokenId}>
                <div className="nsieln_item">
                  <div className="item_title">{item.name}</div>
                  <div className="iteList">
                    <div className="ite_ledrt">
                      <img
                        src={`https://metadata.rektclub.org/ipfs/` + item.image}
                        alt=""
                      />
                    </div>
                    <div className="ite_rest">
                      <div className="bsn">
                        Series：<span>{item.series}</span>
                      </div>
                      <div className="bsn">
                        Type：<span>{item.class}</span>
                      </div>
                      <div className="bsn">
                        Star Level：<span>{item.starlevel}</span>
                      </div>
                      <div className="bsn">
                        Add Point：<span>{item.addPoint}</span>
                      </div>
                    </div>
                  </div>
                  <div className="porksuer" onClick={()=>{
                  porksuerHide()
                }}>X</div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
}
