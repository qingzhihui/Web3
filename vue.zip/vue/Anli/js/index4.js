// 零宽字符(可以做隐藏零宽字符和水印)

var account1 = "随风而去",
    account2 = "随风而去";

console.log(account1===account2);
console.log(account1.length,account2.length);

