import React, { useState } from "react";
import ReactDOM from "react-dom";

const Modal: React.FC<{ onClose: () => void; children: any }> = ({
  onClose,
  children,
}) => {
  const [isOpen, setIsOpen] = useState(true);

  const handleClose = () => {
    setIsOpen(false);
    onClose();
  };

  return isOpen
    ? ReactDOM.createPortal(
        <div className="modal-overlay" onClick={handleClose}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            {children}
          </div>
        </div>,
        document.body
      )
    : null;
};

const Index = () => {
  const [showModal, setShowModal] = useState(false);

  const handleShowModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div>
      <button onClick={handleShowModal}>Show Modal</button>
      {showModal && (
        <Modal onClose={handleCloseModal}>
          <h1>Modal Title</h1>
          <p>Modal content goes here.</p>
        </Modal>
      )}
    </div>
  );
};

export default Index;
