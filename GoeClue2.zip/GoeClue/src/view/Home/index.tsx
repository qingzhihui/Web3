import React, { useEffect, useState } from "react";
import "./index.scss";
import Header from "../../components/Header";
import { useHistory } from "react-router-dom";

import players1 from "../../../src/assets/image/11.png";
import min from "../../../src/assets/image/nmsie.gif";
import players2 from "../../../src/assets/image/999999 1.png";
import Frame from "../../../src/assets/image/Frame.png";
import fq from "../../../src/assets/image/fq.png";
import father from "../../../src/assets/image/12499462881.png";
import son1 from "../../../src/assets/image/12499462892.png";
import son2 from "../../../src/assets/image/12499462903.png";
import target from "../../../src/assets/image/22223325.png";
import crown from "../../../src/assets/image/crown.png";
import smallfather from "../../../src/assets/image/1249946286-1.png";
import fram from "../../../src/assets/image/Fram.png";
import stadium from "../../../src/assets/image/stadium.png";
import stadium2 from "../../../src/assets/image/stadium2.png";
import players3 from "../../../src/assets/image/players3.png";
import { CloseCircleOutlined, PlusCircleOutlined } from "@ant-design/icons";
import Telegram from "../../../src/assets/image/Telegram-Negative.png";
import Twitter from "../../../src/assets/image/Twitter-Negative.png";
import YouTube from "../../../src/assets/image/YouTube-Negative.png";
import LOGO from "../../../src/assets/image/LOGO_10_1.png";
import market from "../../../src/assets/image/market.png";
import gecko from "../../../src/assets/image/gecko.png";
import radar from "../../../src/assets/image/radar.png";
import pancakeswap from "../../../src/assets/image/pancakeswap.png";
import binance from "../../../src/assets/image/binance.jpg";
import tofu from "../../../src/assets/image/tofu.png";
import gala from "../../../src/assets/image/gala.png";

interface Ranking {
  player: string;
  earned: string;
  spent: string;
  change: string;
  race: string;
  castle: string;
}

const weeks: Ranking[] = [
  { player: 'Chris', earned: '4518', spent: '210', change: '11', race: 'Trolls', castle: 'Altar of Elders' },
  { player: 'Antony', earned: '222', spent: '111', change: '11', race: '111', castle: '111' },
  { player: 'Justin', earned: '333', spent: '111', change: '11', race: '111', castle: '111' },
  { player: 'Jarvis', earned: '444', spent: '111', change: '11', race: '111', castle: '111' },
  { player: 'Max', earned: '5555', spent: '111', change: '11', race: '111', castle: '111' }
]

export default function Index() {
  let history = useHistory();
  const [list, setlist] = useState<Ranking[]>(weeks)
  const [isOpen, setisOpen] = useState(false)
  const [choose, setChoose] = useState('weekly')

  const chse = (choose_date: string) => {
    setChoose(choose_date)
    if (choose_date == 'weekly') {
      const weeks: Ranking[] = [
        { player: 'Chris', earned: '111', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Antony', earned: '222', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Justin', earned: '333', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Jarvis', earned: '444', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Max', earned: '5555', spent: '111', change: '11', race: '111', castle: '111' }
      ]
      setlist(weeks)
    } else if (choose_date == "monthly") {
      const weeks: Ranking[] = [
        { player: 'Lucas', earned: '666', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Simon', earned: '777', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'James', earned: '888', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Marco', earned: '999', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Daniel', earned: '10101', spent: '111', change: '11', race: '111', castle: '111' }
      ]
      setlist(weeks)
    } else {
      const weeks: Ranking[] = [
        { player: 'Scott', earned: '1111', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'George', earned: '2222', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Christina', earned: '3333', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Emma', earned: '11444', spent: '111', change: '11', race: '111', castle: '111' },
        { player: 'Vanessa', earned: '1111', spent: '111', change: '11', race: '111', castle: '111' }
      ]
      setlist(weeks)
    }
  }
  const renderweekly = () => {

    return (
      <table className="from_pc">
        <thead className="from-header">
          <tr>
            <th>PLAYER</th>
            <th>EARNED</th>
            <th>SPENT</th>
            <th>CHANGE</th>
            <th>RACE</th>
            <th>CASTLE</th>
          </tr>
        </thead>
        <tbody className="from-body">
          {
            list.map((item, index) => (
              <tr key={index}>
                <td className="body-1">
                  {
                    index === 0 ? (
                      <div className="crown">
                        <img src={crown} alt="" />
                      </div>
                    ) : (
                      <div className="num">{index + 1}</div>
                    )
                  }

                  <div className="people">
                    <img src={smallfather} alt="" />
                  </div>
                  <div className="name">{item.player}</div>
                </td>
                <td className="after_five">{item.earned}</td>
                <td className="after_five">{item.spent}</td>
                <td className="rising after_five">{item.change}%</td>
                <td className="after_five">{item.race}</td>
                <td className="after_five">{item.castle}</td>
              </tr>
            ))
          }
        </tbody>
      </table>



    )

  }
  const rendermonthly = () => {

    return (
      <table className="from_pc">
        <thead className="from-header">
          <tr>
            <th>PLAYER</th>
            <th>EARNED</th>
            <th>SPENT</th>
            <th>CHANGE</th>
            <th>RACE</th>
            <th>CASTLE</th>
          </tr>
        </thead>
        <tbody className="from-body">
          {
            list.map((item, index) => (
              <tr key={index}>
                <td className="body-1">
                  {
                    index === 0 ? (
                      <div className="crown">
                        <img src={crown} alt="" />
                      </div>
                    ) : (
                      <div className="num">{index + 1}</div>
                    )
                  }

                  <div className="people">
                    <img src={smallfather} alt="" />
                  </div>
                  <div className="name">{item.player}</div>
                </td>
                <td className="after_five">{item.earned}</td>
                <td className="after_five">{item.spent}</td>
                <td className="rising after_five">{item.change}%</td>
                <td className="after_five">{item.race}</td>
                <td className="after_five">{item.castle}</td>
              </tr>
            ))
          }
        </tbody>
      </table>

    )

  }
  const renderall_time = () => {
    return (
      <table className="from_pc">
        <thead className="from-header">
          <tr>
            <th>PLAYER</th>
            <th>EARNED</th>
            <th>SPENT</th>
            <th>CHANGE</th>
            <th>RACE</th>
            <th>CASTLE</th>
          </tr>
        </thead>
        <tbody className="from-body">
          {
            list.map((item, index) => (
              <tr key={index}>
                <td className="body-1">
                  {
                    index === 0 ? (
                      <div className="crown">
                        <img src={crown} alt="" />
                      </div>
                    ) : (
                      <div className="num">{index + 1}</div>
                    )
                  }

                  <div className="people">
                    <img src={smallfather} alt="" />
                  </div>
                  <div className="name">{item.player}</div>
                </td>
                <td className="after_five">{item.earned}</td>
                <td className="after_five">{item.spent}</td>
                <td className="rising after_five">{item.change}%</td>
                <td className="after_five">{item.race}</td>
                <td className="after_five">{item.castle}</td>
              </tr>
            ))
          }
        </tbody>
      </table>

    )

  }




  const readmore = () => {
    history.push("/GetPlayer")
  }
  const game = () => {
    history.push("/Court")
  }
  const showHide = () => {
    setisOpen(false)
  }
  const watchvideo = () => {
    setisOpen(true)
  }

  return (
    <div className="home">
      <div className="opsieo">
        <Header />
        {/*  id="Anchor" */}
        <div className="home-middle_pc">
          <div className="middle-top">
            <div className="players1">
              <img src={players1} alt="" />
            </div>
            <div className="min">
              <div className="trophy">
                <img src={min} alt="" />
              </div>
              <div className="fq">
                <img src={fq} alt="" />
              </div>
            </div>
            <div className="players2">
              {" "}
              <img src={players2} alt="" />
            </div>
          </div>

          <div className="middle-bottom">
            <div className="button">
              <div className="watch" onClick={() => { watchvideo() }}>
                <div>
                  <img src={YouTube} alt="" />
                </div>
                <div>Watch video</div>
              </div>
              <div className="app" onClick={() => { game() }}>Launch APP</div>
            </div>
            <div className="protect">
              Protect your team, upgrade your players and win PVP battles!
            </div>
          </div>
        </div>
        <div className="home-middle_mobile">
          <div className="above">
            <div className="min">
              <img src={min} alt="" />
            </div>
            <div className="fq">
              <img src={fq} alt="" />
            </div>
          </div>
          <div className="home-midd">
            <div className="butt">
              <div className="watch" onClick={() => { watchvideo() }}>
                <div>
                  <img src={YouTube} alt="" />
                </div>
                <div>Watch video</div>
              </div>
              <div className="app" onClick={() => { game() }}>Launch APP</div>
            </div>
            <div className="protect">
              Protect your team, upgrade your players and win PVP battles!
            </div>
          </div>
          <div className="footer">
            <div className="players1">
              <img src={players1} alt="" />
            </div>
            <div className="players2">
              <img src={players2} alt="" />
            </div>
          </div>
        </div>
        <div className="creer" id="Anchor">
          <div className="title">About us</div>
          <div className="instructions">
            Goalie Club is a decentralized,
            trustworthy, intelligent gaming competition platform!
          </div>
          <div className="card">
            <div className="son1">
              <div className="img_son1">
                <img src={son1} alt="" />
              </div>
              <div className="name">George</div>
            </div>
            <div className="father">
              <div className="img_father">
                <img src={father} alt="" />
              </div>
              <div className="name">Chris</div>
              <div className="eros">
                Eros in cursus turpis mas Faucibus purus in massa tempor feugit
              </div>
              <div>
                <img src={target} alt="" />
              </div>
            </div>
            <div className="son2">
              <div className="img_son2">
                <img src={son2} alt="" />
              </div>
              <div className="name">Jarvis</div>
            </div>
          </div>
        </div>

        <div className="tower">
          <div className="content">
            <div className="title">Hot Players Leaderboard</div>
            <div className="choose">
              <div className={[`wma ${choose === 'weekly' ? 'selected' : ''}`].join('')} onClick={() => { chse('weekly') }}>Weekly</div>
              <div className={[`wma ${choose === 'monthly' ? 'selected' : ''}`].join('')} onClick={() => { chse('monthly') }}>Monthly</div>
              <div className={[`wma ${choose === 'all_time' ? 'selected' : ''}`].join('')} onClick={() => { chse('all_time') }}>All Time</div>
            </div>
            {choose === 'weekly' ? renderweekly() : (
              choose === 'monthly' ? rendermonthly() : renderall_time()
            )}
          </div>
        </div>

        <div className="expand">
          <div className="count">
            <div className="expand-head">
              <div className="pand">Unlock your stadium</div>
              <div className="erc">
                Buy more stadiums to win the game!
              </div>
            </div>
            <div className="expand-footer">
              <div className="footer-left">
                <div className="nucesd">There are three kinds of stadiums: wild stadiums, official stadiums, private stadiums. In PK mode, you can rent official stadiums or buy private stadiums. Private stadiums can be rented when the players are not playing a game, with fifteen players can form a team.</div>
                <div className="butt" onClick={() => { readmore() }}>
                  <div>
                    <img src={fram} alt="" />
                  </div>
                  <div>READ MORE</div>
                </div>
              </div>
              <div className="footer-right">
                <div className="card-left">
                  <div>
                    <img src={stadium} alt="" />
                  </div>
                  <div className="news">NEWS & UPGRADES</div>
                </div>
                <div className="card-right">
                  <div>
                    <img src={stadium2} alt="" />
                  </div>
                  <div className="news">RED & ARROW EVENT</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="home-footer">
          <div className="count">
            <div className="footer-left">
              <div>
                <img src={players3} alt="" />
              </div>
            </div>
            <div className="footer-right">
              <div className="keep">Keep In Touch</div>
              <div className="sub">
                Subscribe to our newsletter and never miss any of our updates.
              </div>
              <div className="butt">
                <div><a href="mailto:contact@goalie.club" target="_top">your@mail.here</a></div>
                <div onClick={() => { game() }}>PLAY NOW</div>
              </div>
            </div>
          </div>
        </div>

        <div className="rules">
          <div className="count">
            <div className="count-on">
              <div className="on-left">
                <div className="partners"><img src={market} alt="" /><a href="https://coinmarketcap.com/" target="_blank">CoinMarketCap</a></div>
                <div className="partners"><img src={gecko} alt="" /><a href="https://coingecko.com/" target="_blank">CoinGecko</a></div>
                <div className="partners"><img src={radar} alt="" /><a href="https://dappradar.com/" target="_blank">DappRadar</a></div>
                <div className="partners"><img src={pancakeswap} alt="" /><a href="https://pancakeswap.finance/" target="_blank">Pancakeswap</a></div>
                <div className="partners"><img src={binance} alt="" /><a href="https://binance.com/" target="_blank">Binance</a></div>
                <div className="partners"><img src={tofu} alt="" /><a href="https://tofunft.com/" target="_blank">TOFU</a></div>
                <div className="partners"><img src={gala} alt="" /><a href="https://app.gala.games/" target="_blank">GALA</a></div>
              </div>
              <div className="on-right"><img src={LOGO} alt="" /></div>
            </div>
            <div className="count-under">
              <div className="ico">
                <div><img src={Telegram} alt="" /></div>
                <div><img src={Twitter} alt="" /></div>
                <div><img src={YouTube} alt="" /></div>
              </div>
              <div className="date">2022 Goalie Club. All rights reserved.</div>
            </div>
          </div>
        </div>

        {
          isOpen ? (
            <div className="psershowpro">
              <div
                className="pserzhes"
                onClick={() => {
                  showHide();
                }}
              ></div>
              <div className="pserNro">
                <div className="nusiero">
                  <div className="gbNiuero">
                    <iframe width="1280" height="720" src="https://www.youtube.com/embed/-DD8PcdE_d0" title="轻柔的音乐，镇静神经，愉悦心灵——治愈心脏和血管的音乐" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" ></iframe>
                  </div>
                  <div
                    className="gbuieng"
                    onClick={() => {
                      showHide();
                    }}
                  >
                    <CloseCircleOutlined
                      style={{
                        color: "#ffff",
                        fontSize: "22px",
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          ) : (
            ""
          )
        }
      </div>

    </div>

  );
}
