import React, { useState, useEffect } from "react";
import { w3cwebsocket as WebSocket } from "websocket";

interface Message {
  type: string;
  data: any;
}

function App() {
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    const client = new WebSocket("ws://localhost:8080");

    client.onopen = () => {
      console.log("WebSocket Client Connected");
    };

    client.onmessage = (message: any) => {
      const parsedMessage: Message = JSON.parse(message.data.toString());
      setMessages((prevMessages) => [...prevMessages, parsedMessage]);
    };

    client.onclose = () => {
      console.log("WebSocket Client Disconnected");
    };

    return () => {
      client.close();
    };
  }, []);

  return (
    <div>
      <h1>Real-time Data Example</h1>
      <ul>
        {messages.map((message, index) => (
          <li key={index}>{message.data}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
