// pages/ches/ches.js
import api from '../../config/api'
import datapro from '../../config/t.js'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    vicondata: [],
    touch: false,
    touchStartTime: 0, //触摸开始时间
    touchEndTime: 0, // 触摸结束时间
    touchEbutn: "下一题",
    show: "",
    setea: 0,
    tabsShow: false,


    // 数据
    radio: '0',
    activeNames: ['0'],
    activeNames2: ['0'],
    show2: false,
    show3: false,
    show4: false,

    // 案例笔记
    anid: "",
    value: "",
    message4: "",
    Chadata: [],

    // 佐证
    // 二级
    uestionnaireTwoId: "",
    // 选项id
    optionTableId: "",
    // 佐证内容
    message: "",
    // 用户id
    adminId: '',
    // 题目id
    subjectId: "",
    // 添加的id
    musid: "",
    radio3: '',


    // 确认自评信息
    radio2: '',
    message2: "",
    quetitle: "",
    queName: '',

    message3: "",
    message4: "",
    dinping: false,
    bohueo: false,
    show4: false,
    value: "",
    // 展示用户信息
    Beinlist: {},
    // 下级ID
    ShauserId: "",
    // 确认无异
    lisneID: '',
    // 问卷ID
    Qusersid: "",
    // 团队ID
    TeamId: "",
    dufelns: [],
    BueleList: [],
    lustr: false,
    questireTwoId: "",
    tmuid: "",
    Dvalue: "",
    touchShow: true,
    grade: "",
    beishow:true,
    id: null, // 提交表编号
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(datapro[0].data);
    this.setData({
      vicondata: datapro[0].data
    })
  },
  onChangeTabs(event) {
    console.log(event);
    this.setData({
      active: event.detail.index
    })
    if (event.detail.index >= this.data.vicondata.length) {
      this.setData({
        tabsShow: true
      })
    }
  },
  onCloseShow(e) {
    var that = this;
    if (Number(this.data.grade) == 1) {
      this.setData({
        show: true
      });
      console.log('123');
    } else {
      console.log('123');
      this.setData({
        show: true
      });
    }
  },

  onChange3(event) {
    if ((event.detail == 1)) {
      setTimeout(() => {
        this.setData({
          radio3: event.detail,
          dinping: true,
          bohueo: false
        });
      }, 300)
    } else {
      setTimeout(() => {
        this.setData({
          radio3: event.detail,
          bohueo: true,
          dinping: false,
        });
      }, 300)
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  Anlishow(e) {
    this.setData({
      show3: true,
      anid: e.currentTarget.dataset.id
    });
  },
  onChange2(event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  onTulier() {
    this.setData({
      active: this.data.active - 1
    })
    if (this.data.active < this.data.vicondata.length) {
      this.setData({
        tabsShow: false
      })
    }
  },
  onTulierbut() {
    this.setData({
      active: this.data.active + 1
    })
    if (this.data.active >= this.data.vicondata.length) {
      this.setData({
        tabsShow: true
      })
    } else {
      this.setData({
        tabsShow: false
      })
    }
  },
  onReady() {

  },
  onChange(event) {
    this.setData({
      uestionnaireTwoId: event.currentTarget.dataset.item,
      subjectId: event.currentTarget.dataset.id,
    })
    this.data.vicondata.map((item) => {
      if (item.id == event.currentTarget.dataset.id) {
        item.umsOptionTables.map((msg) => {
          if (msg.id == parseInt(event.detail.split(',')[1])) {
            this.setData({
              optionTableId: event.detail.split(',')[1]
            })
            if (msg.identification == true) {
              setTimeout(() => {
                this.setData({
                  radio: event.detail,
                  show2: true,
                });
              }, 100)
            } else {
              this.setData({
                radio: event.detail.split(',')[0],
                show2: false,
              });
            }
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  Lisbeani() {
    this.data.Chadata.map((item) => {
      this.setData({
        message: item.content
      })
    })
  },
  Anlshow4(e) {
    this.setData({
      show4: true
    })
    api._get(`ums/umsCaseNotes/selectCaseNoteById/${this.data.anBine.userId}/${e.currentTarget.dataset.id}`).then(res => {
      const biem = [];
      res.data.map((item) => {
        item.createTime = item.createTime.split('T')[0]
        biem.push(item)
      })
      this.setData({
        Chadata: biem
      })
    }).catch(e => {
      console.log(e)
    })
    this.setData({
      show4: true
    })

  },
})