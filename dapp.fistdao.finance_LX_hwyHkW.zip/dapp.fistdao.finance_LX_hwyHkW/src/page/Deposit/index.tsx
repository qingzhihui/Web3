import React, { useEffect, useMemo, useState } from "react";
import { ethers } from "ethers";
import BigNumber from "bignumber.js";
import { Button, Input, notification, Modal, Tabs } from "antd";
import { CheckCircleOutlined, LoadingOutlined } from "@ant-design/icons";
import Header2 from "../../components/Header2";
import "./index.scss";
import {
  CONTRACT_ABI,
  CONTRACT_ADDRESS,
} from "../../redux/Contract/contractApp2";
import { PAIR_ABI } from "../../redux/Contract/pancakepair";
import { wben_ABI } from "../../redux/Contract/wbenjson";
import List from "../../redux/UsJson/Colest2.json";

declare const window: Window & { ethereum: any };

function Index() {
  const MINUTE_MS = 1000;
  const [address, serAddres] = useState("");
  const [showList, setShowList] = useState(List);
  const [inputValue, setInputValue] = useState(0);
  const [unShow, setunShow] = useState(false);
  const key = "updatable";
  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleOk = async (id: any) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const Contract = new ethers.Contract(
        CONTRACT_ADDRESS,
        CONTRACT_ABI,
        signer
      );
      const withs = await Contract.withdraw(id);
      openNotification2(
        "取回中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setIsModalVisible(false);
      await withs.wait();
      openNotification2(
        "取回成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      const pldata = await Contract.userInfo(id, address);
      const buList: any = [];
      showList.map((item: any) => {
        if (item.id == id) {
          item.lPdata = ethers.utils.formatEther(
            pldata.depositAmount.toString()
          );
        }
        buList.push(item);
      });
      setInputValue(0);
      setIsModalVisible(false);
      setTimeout(() => {
        setShowList(buList);
      }, 300);
    } catch (error: any) {
      setIsModalVisible(false);
      if (JSON.parse(JSON.stringify(error)).code == "ACTION_REJECTED") {
        openNotification2(
          "用户拒绝取回.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
      }
    }
  };
  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const openNotification2 = (bindValue: any, durn: any, icon: any) => {
    notification.open({
      key,
      message: "提示",
      description: bindValue,
      duration: durn,
      icon: icon,
    });
  };
  // 授权
  const approve = async (code: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const PAIRContract = new ethers.Contract(code, PAIR_ABI, signer);
    const balance = await PAIRContract.balanceOf(addr);
    const apperov = await PAIRContract.approve(
      CONTRACT_ADDRESS,
      ethers.constants.MaxUint256
    );
    openNotification2(
      "授权中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await apperov.wait();
    const buList: any = [];
    showList.map((item: any) => {
      if (item.code == code) {
        item.show = true;
      }
      buList.push(item);
    });
    setTimeout(() => {
      let _buList = JSON.parse(JSON.stringify(buList));
      setShowList(_buList);
    }, 300);
    openNotification2(
      "授权成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
  };
  // 质押
  const deposit = async (id: any) => {
    // try {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const value = new BigNumber(inputValue)
      .times(new BigNumber(10).pow(18))
      .toFixed();
    const desite = await Contract.deposit(id, value.toString());
    openNotification2(
      "存款中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await desite.wait();
    openNotification2(
      "存款成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
    const pldata = await Contract.userInfo(id, address);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.lPdata = ethers.utils.formatEther(pldata.depositAmount.toString());
        item.inputValue = "";
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };
  // 领取
  const claim = async (id: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const Contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      CONTRACT_ABI,
      signer
    );
    const cladim = await Contract.claim(id);
    openNotification2(
      "领取中...",
      0,
      <LoadingOutlined style={{ color: "#ffc400" }} />
    );
    await cladim.wait();
    openNotification2(
      "领取成功.",
      2,
      <CheckCircleOutlined style={{ color: "#ffc400" }} />
    );
  };
  // 最大值
  const BinCkmax = async (bianes: any, id: any) => {
    setInputValue(bianes);
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = bianes;
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
    setunShow(true);
  };
  // 赎回
  const withdraw = async (id: any) => {
    setIsModalVisible(true);
  };
  const onCInput = (e: any, id: any) => {
    const buList: any = [];
    showList.map((item: any) => {
      if (item.id == id) {
        item.inputValue = e.target.value;
        setInputValue(e.target.value);
        const Shui = e.target.value || 0;
        if (Shui === 0) {
          setunShow(false);
        } else if (item.inputValue === 0) {
          setunShow(false);
        } else {
          setunShow(true);
        }
      }
      buList.push(item);
    });
    setTimeout(() => {
      setShowList(buList);
    }, 300);
  };
  useEffect(() => {
    const ahsdr = localStorage.getItem("addr");
    if (ahsdr !== null && ahsdr !== undefined) {
      setTimeout(() => {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const LIbse: any = showList;
        showList.map(async (item: any) => {
          const address = await signer.getAddress();
          serAddres(address);
          const PAIRContract = new ethers.Contract(item.code, PAIR_ABI, signer);
          const usider = await PAIRContract.allowance(
            address,
            CONTRACT_ADDRESS
          );
          const Contract = new ethers.Contract(
            CONTRACT_ADDRESS,
            CONTRACT_ABI,
            signer
          );
          const bineof = await PAIRContract.balanceOf(address);
          const pldata = await Contract.userInfo(item.id, address);
          const pending = await Contract.pendingReward(item.id, address);

          const ContractToken1 = new ethers.Contract(
            item.token1,
            wben_ABI,
            signer
          );
          const ContractToken2 = new ethers.Contract(
            item.token2,
            wben_ABI,
            signer
          );
          const totalSupply = await PAIRContract.totalSupply();
          const bnbTotal1 = await ContractToken1.balanceOf(item.code);
          const decimals1 = await ContractToken1.decimals();
          const bnbTotal2 = await ContractToken2.balanceOf(item.code);
          const decimals2 = await ContractToken2.decimals();
          const lisne = await Contract.userInfo(item.id, address);
          let holdRatio1 =
            Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
          let userBnb1 = Number(bnbTotal1) * holdRatio1;
          let nukse1 = userBnb1 / 10 ** decimals1;
          let holdRatio2 =
            Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
          let userBnb2 = Number(bnbTotal2) * holdRatio2;
          let nukse2 = userBnb2 / 10 ** decimals2;
          if (
            Number(usider.toString()) == Number(ethers.constants.MaxUint256)
          ) {
            LIbse[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            LIbse[item.pid].lPdata = ethers.utils.formatEther(
              pldata.depositAmount.toString()
            );
            LIbse[item.pid].lPdataToken1 = String(nukse1.toFixed(10));
            LIbse[item.pid].lPdataToken2 = String(nukse2.toFixed(10));
            LIbse[item.pid].Pending = ethers.utils.formatEther(
              pending.toString()
            );
            LIbse[item.pid].show = true;
          } else {
            LIbse[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            LIbse[item.pid].show = false;
          }
        });
        setTimeout(() => {
          let _LIbse = JSON.parse(JSON.stringify(LIbse));
          setShowList(_LIbse);
        }, 300);
      }, 300);
      // 切换钱包
      (window as any).ethereum.on(
        "accountsChanged",
        async function (accounts: any) {
          localStorage.setItem("addr", accounts[0]);
          setTimeout(() => {
            serAddres(accounts[0]);
            const provider = new ethers.providers.Web3Provider(window.ethereum);
            const signer = provider.getSigner();
            const LIbse: any = showList;
            showList.map(async (item: any) => {
              const PAIRContract = new ethers.Contract(
                item.code,
                PAIR_ABI,
                signer
              );
              const usider = await PAIRContract.allowance(
                accounts[0],
                CONTRACT_ADDRESS
              );
              const Contract = new ethers.Contract(
                CONTRACT_ADDRESS,
                CONTRACT_ABI,
                signer
              );
              const bineof = await PAIRContract.balanceOf(accounts[0]);
              const pldata = await Contract.userInfo(item.id, accounts[0]);
              const pending = await Contract.pendingReward(
                item.id,
                accounts[0]
              );

              const ContractToken1 = new ethers.Contract(
                item.token1,
                wben_ABI,
                signer
              );
              const ContractToken2 = new ethers.Contract(
                item.token2,
                wben_ABI,
                signer
              );
              let totalSupply = "";
              const ches2 = PAIRContract.totalSupply();
              ches2.then((res: any) => (totalSupply = res));
              let bnbTotalNum1 = "";
              let bnbTotal1 = ContractToken1.balanceOf(item.code);
              bnbTotal1.then((res: any) => (bnbTotalNum1 = res));
              const decimals1 = await ContractToken1.decimals();
              let bnbTotalNum2 = "";
              let bnbTotal2 = ContractToken2.balanceOf(item.code);
              bnbTotal2.then((res: any) => (bnbTotalNum2 = res));
              const decimals2 = await ContractToken2.decimals();
              const lisne = await Contract.userInfo(item.id, accounts[0]);
              let holdRatio1 =
                Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
              let userBnb1 = Number(bnbTotalNum1) * holdRatio1;
              let nukse1 = userBnb1 / 10 ** decimals1;
              let holdRatio2 =
                Number(lisne.depositAmount) / (Number(totalSupply) - 1000);
              let userBnb2 = Number(bnbTotalNum2) * holdRatio2;
              let nukse2 = userBnb2 / 10 ** decimals2;
              if (
                Number(usider.toString()) == Number(ethers.constants.MaxUint256)
              ) {
                LIbse[item.pid].bianes = ethers.utils.formatEther(
                  bineof.toString()
                );
                LIbse[item.pid].lPdata = ethers.utils.formatEther(
                  pldata.depositAmount.toString()
                );
                LIbse[item.pid].lPdataToken1 = String(nukse1.toFixed(10));
                LIbse[item.pid].lPdataToken2 = String(nukse2.toFixed(10));
                LIbse[item.pid].Pending = ethers.utils.formatEther(
                  pending.toString()
                );
                LIbse[item.pid].show = true;
              } else {
                LIbse[item.pid].bianes = ethers.utils.formatEther(
                  bineof.toString()
                );
                LIbse[item.pid].show = false;
              }
            });
            setTimeout(() => {
              let _LIbse = JSON.parse(JSON.stringify(LIbse));
              setShowList(_LIbse);
            }, 300);
          }, 1000);
        }
      );
      const interval = setInterval(async () => {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const Listusn: any = showList;
        showList.map(async (item: any) => {
          const Contract = new ethers.Contract(
            CONTRACT_ADDRESS,
            CONTRACT_ABI,
            signer
          );
          const address = await signer.getAddress();
          const PAIRContract = new ethers.Contract(item.code, PAIR_ABI, signer);
          const usider = await PAIRContract.allowance(
            address,
            CONTRACT_ADDRESS
          );
          const pending = await Contract.pendingReward(item.id, address);
          const bineof = await PAIRContract.balanceOf(address);
          const pldata = await Contract.userInfo(item.id, address);
          if (
            Number(usider.toString()) == Number(ethers.constants.MaxUint256)
          ) {
            Listusn[item.pid].bianes = ethers.utils.formatEther(
              bineof.toString()
            );
            Listusn[item.pid].lPdata = ethers.utils.formatEther(
              pldata.depositAmount.toString()
            );
            Listusn[item.pid].Pending = ethers.utils.formatEther(
              pending.toString()
            );
            Listusn[item.pid].show = true;
          } else {
            Listusn[item.pid].show = false;
          }
        });
        setTimeout(() => {
          let _Listusn = JSON.parse(JSON.stringify(Listusn));
          setShowList(_Listusn);
        }, 300);
      }, MINUTE_MS);
      return () => clearInterval(interval);
    }
  }, [inputValue, address]);
  return (
    <div className="Frome2">
      <Header2 />
      <div className="banNdr">
        <div className="sueeis">
          <div className="sueeis_title">分红工厂</div>
        </div>
        <div className="nsuroBIneg">
          {showList.map((item: any) => (
            <div className="NuserList2" key={item.id}>
              <div className="Lisndter">
                <Tabs defaultActiveKey="1">
                  <Tabs.TabPane tab="存入LP分红" key="1">
                    <div className="NusierItem">
                      <div className="Butile">
                        <div className="yruci">
                          {" "}
                          <div className="tilei">已入池：</div>
                          {item.lPdataToken1 || "0.0"} {item.name.split("/")[0]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">已入池：</div>{" "}
                          {item.lPdataToken2 > 0 &&
                          item.lPdataToken2 < 0.0000000001
                            ? "< 0.0000000001"
                            : item.lPdataToken2 || "0.0"}
                          {item.name.split("/")[1]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">余额：</div>
                          {item.bianes || "0.0"} {item.name} LP
                        </div>
                      </div>
                      <div className="nbudrki">
                        {item.show ? (
                          <div className="Bininput">
                            <Input
                              value={item.inputValue}
                              onChange={(e) => onCInput(e, item.id)}
                              type="text"
                              placeholder="0.0"
                            />
                            <div className="Binmax">
                              <Button
                                onClick={() => {
                                  BinCkmax(item.bianes, item.id);
                                }}
                              >
                                Max
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="Bininput">
                            <Input disabled type="text" placeholder="0.0" />
                            <div className="Binmax">
                              {" "}
                              <div className="nuBut">
                                <Button disabled>Max</Button>
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="Nusoer">
                          <div className="Numerbut">
                            {item.show ? (
                              <>
                                {item.inputValue !== "" && unShow ? (
                                  <Button
                                    onClick={() => {
                                      deposit(item.id);
                                    }}
                                  >
                                    存款
                                  </Button>
                                ) : (
                                  <div className="nuBut">
                                    <Button disabled>存款</Button>
                                  </div>
                                )}
                              </>
                            ) : (
                              <Button
                                onClick={() => {
                                  approve(item.code);
                                }}
                              >
                                授权
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tabs.TabPane>
                  <Tabs.TabPane tab="取回LP" key="2">
                    <div className="NusierItem2">
                      <div className="Butile">
                        <div className="yruci">
                          {" "}
                          <div className="tilei">已入池：</div>
                          {item.lPdataToken1 || "0.0"} {item.name.split("/")[0]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">已入池：</div>{" "}
                          {item.lPdataToken2 || "0.0"} {item.name.split("/")[1]}
                        </div>
                        <div className="yruci">
                          {" "}
                          <div className="tilei">余额：</div>
                          {item.bianes || "0.0"} {item.name} LP
                        </div>
                      </div>
                      {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                        <div className="item2nr">
                          <div className="Butile">
                            <div className="yruci">
                              <span> 已存款</span> ：{item.lPdata || "0"}{" "}
                              {item.name} LP
                            </div>
                          </div>
                          <div className="Nusoer">
                            <div className="soer_btn">
                              <Button
                                onClick={() => {
                                  withdraw(item.id);
                                }}
                              >
                                取回
                              </Button>
                            </div>
                          </div>
                          <Modal
                            title="Tips"
                            width={400}
                            visible={isModalVisible}
                            okText="确认"
                            cancelText="取消"
                            centered
                            onOk={() => {
                              handleOk(item.id);
                            }}
                            onCancel={handleCancel}
                          >
                            <p>请确认是否取回？</p>
                          </Modal>
                        </div>
                      ) : (
                        <div className="item2nrs">
                          <div className="Butile">
                            <div className="yruci">
                              <span> 暂无存款 LP</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </Tabs.TabPane>
                </Tabs>
              </div>
              <div className="Lisndter_2use">
                <div className="item2nr">
                  <div className="Butile">
                    <div className="yruci">
                      <div className="tilei"> 待领取分红：</div>
                      {item.Pending || "0.0"} ETH
                    </div>
                  </div>
                  <div className="Nusoer">
                    <div className="soer_btn">
                      {item.lPdata !== "0.0" && item.lPdata !== "" ? (
                        <Button
                          onClick={() => {
                            claim(item.id);
                          }}
                        >
                          领取
                        </Button>
                      ) : (
                        <div className="nuBut">
                          <Button disabled>领取</Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* <Heues /> */}
    </div>
  );
}

export default Index;
