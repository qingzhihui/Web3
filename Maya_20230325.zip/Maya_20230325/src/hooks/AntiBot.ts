import AntiBotABI from "../config/abi/AntiBotPink.json";
import RouterABI from "../config/abi/Router.json";
import { AirPrcoABI, AirPrcoAddress, NextTokenABI } from "./Airprcopy";
import {
  FormatUnitsConver,
  InstancedContract,
  TokenNameDecimals,
} from "./config";
const AntiBotAddress = "0x207E9e4f3F8bBc79b20B2FEF586267cEB0a676D2";

export interface tmpListProps {
  key: number;
  No: number;
  Address: string;
}
export interface configListProps {
  Exchange?: string;
  Token?: string;
  Trade?: string;
  Block?: string;
  seconds?: string;
  Disable?: string;
  transfer?: boolean;
}
export interface statusDataProps {
  ProteStatus?: boolean;
  AmountLimit?: string;
  TimeLimit?: string;
  Blocksleft?: string;
  CurreBlock?: string;
}

const getAirDropArray = async () => {
  const Contract = InstancedContract(AirPrcoAddress, AirPrcoABI) as any;
  return await Contract.getAirDropArray();
};

const airDropToken = async (NextContract: any) => {
  const airDropToken = await NextContract.airDropToken();
  const TokenContract = await TokenNameDecimals(airDropToken);
  return {
    airDropToken,
    TokenContract,
  };
};
const airDropState = async (NextContract: any) => {
  return await NextContract.airDropState();
};

const totalAllocationTokens = async (NextContract: any) => {
  return await NextContract.totalAllocationTokens();
};
const userClaimedTokens = async (NextContract: any) => {
  return await NextContract.userClaimedTokens();
};
const allAllocationCount = async (NextContract: any) => {
  return await NextContract.allAllocationCount();
};
const details = async (NextContract: any) => {
  return await NextContract.details();
};
const owner = async (NextContract: any) => {
  return await NextContract.owner();
};
const allocationInfos = async (address: string, NextContract: any) => {
  return await NextContract.allocationInfos(address);
};

const DropTokenLins = async (TokenAddress: string, addres: string) => {
  const NextTokenContract = InstancedContract(TokenAddress, NextTokenABI) as any;
  return Promise.all([
    airDropToken(NextTokenContract),
    airDropState(NextTokenContract),
    totalAllocationTokens(NextTokenContract),
    userClaimedTokens(NextTokenContract),
    allAllocationCount(NextTokenContract),
    details(NextTokenContract),
    owner(NextTokenContract),
    allocationInfos(addres, NextTokenContract),
  ]).then((res) => {
    return res;
  });
};
const AirdropDate = (allocaData: any, AirDropArray: string) => {
  return {
    name: allocaData[0].TokenContract.symbol,
    totalToken: FormatUnitsConver(
      allocaData[2].toString(),
      allocaData[0].TokenContract.decimals
    ),
    Participants: allocaData[4].toString(),
    status: allocaData[1].toString(),
    isCollect: true,
    address: allocaData[0].airDropToken,
    details: allocaData[5].split(",")[0],
    userClaimedTokens: FormatUnitsConver(
      allocaData[3].toString(),
      allocaData[0].TokenContract.decimals
    ),
    totalAllocationTokens: FormatUnitsConver(
      allocaData[2].toString(),
      allocaData[0].TokenContract.decimals
    ),
    AirDropArray: AirDropArray,
    amount: allocaData[7].amount,
    owner: allocaData[6],
  };
};
const AirDropDataPienSers = async (AirDropArray: any, AirDropAdre: any) => {
  const Pulein: any = [];
  const mylist: any = [];
  const createlist: any = [];
  for (let i = 0; i < AirDropArray.length; i++) {
    const TokenData = await DropTokenLins(AirDropArray[i], AirDropAdre.address);
    const AirDropDataArray = AirdropDate(TokenData, AirDropArray[i]);
    Pulein.push(AirDropDataArray);
    if (Number(AirDropDataArray.amount.toString()) > 0) {
      mylist.push(AirDropDataArray);
    }
    if (AirDropAdre.address === AirDropDataArray.owner) {
      createlist.push(AirDropDataArray);
    }
  }
  return {
    Pulein,
    mylist,
    createlist,
  };
};

export {
  AntiBotAddress,
  AntiBotABI,
  RouterABI,
  getAirDropArray,
  AirDropDataPienSers,
};
