import React, { useEffect, useState } from "react";
import "./index.scss";
import { Pagination, Empty } from "antd";
import { useHistory } from "react-router-dom";
import type { ColumnsType } from "antd/es/table";
import group3 from "../../assets/image/Group3.png";
import IMAGE5 from "../../assets/image/IMAGE5.png";
import Frame from "../../assets/image/Frame.png";
import {
  getCumulativeLpTokenLockInfo,
  lpLocksForUserPancakePair,
} from "../../hooks/Liquidity";
import Loading from '../../components/Loading'
import { DataType } from "../Token/tokenLock";
import { useTranslation, Trans } from "react-i18next";
declare const window: Window & { ethereum: any };

const paginationProps = {
  showSizeChanger: true,
  showQuickJumper: true,
  pageSize: 6,
};

const Index: React.FC = () => {
  let history = useHistory();
  const { t } = useTranslation();
  const [allandlockstyle, setAllandlockstyle] = useState<string>("All");
  const [alloading, setAllLoading] = useState<boolean>(false)
  const [myloading, setMyLoading] = useState<boolean>(false)
  const [getCumulativeALL, setGetCumulativeALL] = useState<DataType[]>([]);
  const [lpLocksForUserMY, setlpLocksForUserMY] = useState<DataType[]>([]);

  const allandlock = (page: string) => {
    setAllandlockstyle(page);
  };
  const getCumulativeLpLockInfo = async () => {
    try {
      const getCumulativeLpData = await getCumulativeLpTokenLockInfo();
      setTimeout(() => {
        let _OwnedItem = JSON.parse(JSON.stringify(getCumulativeLpData));
        // 关闭读取
        setGetCumulativeALL((parentValue: any) => {
          setAllLoading(false)
          return _OwnedItem.length === 0 ? parentValue : _OwnedItem;
        });
      }, 1000);
    } catch (error) {
      setAllLoading(false)
    }
  };
  const getlpLocksForUserPancakePair = async () => {
    try {
      const lpLocksForUserData = await lpLocksForUserPancakePair();
      setTimeout(() => {
        let _OwnedItem = JSON.parse(JSON.stringify(lpLocksForUserData));
        setlpLocksForUserMY((parentValue: any) => {
          setMyLoading(false)
          return _OwnedItem.length === 0 ? parentValue : _OwnedItem;
        });
      }, 1000);
    } catch (error) {
      setMyLoading(false)
    }
  };

  const getlpLocksForUserOnCLikc = async (data: DataType) => {
    history.push({
      pathname: "/lpLocksRecord",
      state: {
        TokenList: data.token,
        amount: data.amount,
      },
    });
  };
  useEffect(() => { }, [getCumulativeALL, lpLocksForUserMY]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        // 开启all读取动画
        setAllLoading(true)
        setMyLoading(true)
        getCumulativeLpLockInfo();
        getlpLocksForUserPancakePair();
      }
    }
  }, []);
  return (
    <div className="Liquidity">
      <div className="Liquidity_countent">
        <div className="search">
          <input
            type="text"
            placeholder={`${t("Search by token addess or lp address...")}`}
          />
        </div>
        <div className="allandlock">
          <div
            className={`all ${allandlockstyle === "All" ? "selected" : null}`}
            onClick={() => {
              allandlock("All");
            }}
          >
            {`${t("All")}`}
          </div>
          <div
            className={`lock ${allandlockstyle === "lock" ? "selected" : null}`}
            onClick={() => {
              allandlock("lock");
            }}
          >
            {`${t("My lock")}`}
          </div>
        </div>
        <div className="from_date">
          <div className="date_header">
            <div className="title">{`${t("Liquidity token")}`}</div>
            <div className="title">{`${t("Amount")}`}</div>
            <div className="title">{`${t("View")}`}</div>
          </div>
          {allandlockstyle === "All" ?
            <>
              {alloading ? <div className="liquLoading"><Loading /></div> :
                ((
                  <div className="soalieAll">
                    {getCumulativeALL.map((item: DataType, index: number) => (
                      <div className="date_item" key={index}>
                        <div className="token">
                          <div className="imgtwo">
                            <img src={Frame} alt="" />
                            <img src={IMAGE5} alt="" />
                          </div>
                          <div className="information">
                            <div className="BNB">
                              {item.token.token0.token0Name}/
                              {item.token.token1.token1Name}
                            </div>
                            <div className="WBNB">
                              {item.token.token0.token0Symbol}/
                              {item.token.token1.token1Symbol}
                            </div>
                          </div>
                        </div>
                        <div className="amount">{item.amount}</div>
                        <div
                          className="view"
                          onClick={() => {
                            getlpLocksForUserOnCLikc(item);
                          }}
                        >
                          {`${t("view")}`}
                        </div>
                      </div>
                    ))}
                  </div>
                ))
              }
            </> :
            <>
              {myloading ? <div className="liquLoading"><Loading /></div> : ((
                <div className="soalieAll">
                  {lpLocksForUserMY.map((item: DataType, index: number) => (
                    <div className="date_item" key={index}>
                      <div className="token">
                        <div className="imgtwo">
                          <img src={Frame} alt="" />
                          <img src={IMAGE5} alt="" />
                        </div>
                        <div className="information">
                          <div className="BNB">
                            {item.token.token0.token0Name}/
                            {item.token.token1.token1Name}
                          </div>
                          <div className="WBNB">
                            {item.token.token0.token0Symbol}/
                            {item.token.token1.token1Symbol}
                          </div>
                        </div>
                      </div>
                      <div className="amount">{item.amount}</div>
                      <div className="view" onClick={() => {
                        getlpLocksForUserOnCLikc(item);
                      }}>{`${t("view")}`}</div>
                    </div>
                  ))}
                </div>
              ))}
            </>
          }
        </div>
        { allandlockstyle === "All" ?
          <Pagination total={getCumulativeALL.length} pageSize={6} /> : <Pagination total={lpLocksForUserMY.length} pageSize={6} />
        }

      </div>
      <div className="imgs">
        <img src={group3} alt="" />
      </div>
    </div>
  );
};
export default Index;
