import React, { useState, useEffect, useRef, useCallback } from "react";

function usePrevious<T>(value: T) {
  const ref = useRef<T>();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}

function useDebounce<T>(value: T, delay: number) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(timer);
    };
  }, [value, delay]);
  return debouncedValue;
}

function useWindowSize() {
  const [size, setSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return size;
}

function Index() {
  const [count, setCount] = useState(0);
  const [name, setName] = useState("");
  const previousCount = usePrevious(count);
  const debouncedName = useDebounce(name, 500);
  const windowSize = useWindowSize();

  const handleIncrement = useCallback(() => {
    setCount(count + 1);
  }, [count]);

  const handleNameChange = useCallback((event: any) => {
    setName(event.target.value);
  }, []);

  return (
    <div>
      <h1>React Hooks Advanced Example</h1>
      <p>Count: {count}</p>
      <p>Previous count: {previousCount}</p>
      <button onClick={handleIncrement}>Increment</button>
      <p>Name: {name}</p>
      <input type="text" value={name} onChange={handleNameChange} />
      <p>Debounced name: {debouncedName}</p>
      <p>
        Window size: {windowSize.width} x {windowSize.height}
      </p>
    </div>
  );
}

export default Index;
