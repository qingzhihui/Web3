module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/router-context":
/*!**************************************************************!*\
  !*** external "next/dist/next-server/lib/router-context.js" ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router-context.js");

/***/ }),

/***/ "./components/PokemonFilter.jsx":
/*!**************************************!*\
  !*** ./components/PokemonFilter.jsx ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ "@emotion/styled");
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mobx-react */ "mobx-react");
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/store */ "./src/store.js");
var _jsxFileName = "E:\\Study\\React\\day-17\\components\\PokemonFilter.jsx";
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;




const Input = _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default.a.input`
  width: 100%;
  padding: 0.2rem;
  font-size: large;
`;

const PokemonFilter = () => {
  return __jsx(Input, {
    type: "text",
    value: _src_store__WEBPACK_IMPORTED_MODULE_3__["default"].filter,
    onChange: evt => _src_store__WEBPACK_IMPORTED_MODULE_3__["default"].setFilter(evt.target.value),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 5
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(PokemonFilter));

/***/ }),

/***/ "./components/PokemonInfo.jsx":
/*!************************************!*\
  !*** ./components/PokemonInfo.jsx ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mobx-react */ "mobx-react");
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _src_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../src/store */ "./src/store.js");
var _jsxFileName = "E:\\Study\\React\\day-17\\components\\PokemonInfo.jsx";
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;




const PokemonInfo = () => {
  return _src_store__WEBPACK_IMPORTED_MODULE_2__["default"].selectedPokemon ? __jsx("div", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 5
    }
  }, __jsx("h2", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }
  }, _src_store__WEBPACK_IMPORTED_MODULE_2__["default"].selectedPokemon.name.english), __jsx("table", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }
  }, __jsx("tbody", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 9
    }
  }, Object.keys(_src_store__WEBPACK_IMPORTED_MODULE_2__["default"].selectedPokemon.base).map(key => __jsx("tr", {
    key: key,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 13
    }
  }, __jsx("td", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 15
    }
  }, key), __jsx("td", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 15
    }
  }, _src_store__WEBPACK_IMPORTED_MODULE_2__["default"].selectedPokemon.base[key])))))) : null;
};

/* harmony default export */ __webpack_exports__["default"] = (Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(PokemonInfo));

/***/ }),

/***/ "./components/PokemonRow.jsx":
/*!***********************************!*\
  !*** ./components/PokemonRow.jsx ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _src_pokemonType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/pokemonType */ "./src/pokemonType.js");
var _jsxFileName = "E:\\Study\\React\\day-17\\components\\PokemonRow.jsx";
var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;






const PokemonRow = ({
  pokemon,
  onClick
}) => __jsx(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, __jsx("tr", {
  key: pokemon.id,
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }
}, __jsx("td", {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 7
  }
}, __jsx(next_link__WEBPACK_IMPORTED_MODULE_0___default.a, {
  href: `/pokemon/${pokemon.id}`,
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 9
  }
}, __jsx("a", {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 11
  }
}, pokemon.name.english))), __jsx("td", {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 7
  }
}, pokemon.type.join(", ")), __jsx("td", {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 7
  }
}, __jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Button"], {
  variant: "contained",
  color: "primary",
  onClick: () => onClick(pokemon),
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 9
  }
}, "More Information"))));

PokemonRow.propTypes = {
  pokemon: _src_pokemonType__WEBPACK_IMPORTED_MODULE_4__["default"]
};
/* harmony default export */ __webpack_exports__["default"] = (PokemonRow);

/***/ }),

/***/ "./components/PokemonTable.jsx":
/*!*************************************!*\
  !*** ./components/PokemonTable.jsx ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mobx-react */ "mobx-react");
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _PokemonRow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PokemonRow */ "./components/PokemonRow.jsx");
/* harmony import */ var _src_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/store */ "./src/store.js");
var _jsxFileName = "E:\\Study\\React\\day-17\\components\\PokemonTable.jsx";
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;





function PokemonTable() {
  return __jsx("table", {
    width: "100%",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 5
    }
  }, __jsx("tbody", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }
  }, _src_store__WEBPACK_IMPORTED_MODULE_3__["default"].pokemon.filter(({
    name: {
      english
    }
  }) => english.toLocaleLowerCase().includes(_src_store__WEBPACK_IMPORTED_MODULE_3__["default"].filter.toLocaleLowerCase())).slice(0, 20).map(pokemon => __jsx(_PokemonRow__WEBPACK_IMPORTED_MODULE_2__["default"], {
    key: pokemon.id,
    pokemon: pokemon,
    onClick: pokemon => _src_store__WEBPACK_IMPORTED_MODULE_3__["default"].setSelectedPokemon(pokemon),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }
  }))));
}

/* harmony default export */ __webpack_exports__["default"] = (Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(PokemonTable));

/***/ }),

/***/ "./node_modules/next/dist/client/link.js":
/*!***********************************************!*\
  !*** ./node_modules/next/dist/client/link.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ../next-server/lib/router/router */ "./node_modules/next/dist/next-server/lib/router/router.js");

var _router2 = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

let cachedObserver;
const listeners = new Map();
const IntersectionObserver = false ? undefined : null;
const prefetched = {};

function getObserver() {
  // Return shared instance of IntersectionObserver if already created
  if (cachedObserver) {
    return cachedObserver;
  } // Only create shared IntersectionObserver if supported in browser


  if (!IntersectionObserver) {
    return undefined;
  }

  return cachedObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!listeners.has(entry.target)) {
        return;
      }

      const cb = listeners.get(entry.target);

      if (entry.isIntersecting || entry.intersectionRatio > 0) {
        cachedObserver.unobserve(entry.target);
        listeners.delete(entry.target);
        cb();
      }
    });
  }, {
    rootMargin: '200px'
  });
}

const listenToIntersections = (el, cb) => {
  const observer = getObserver();

  if (!observer) {
    return () => {};
  }

  observer.observe(el);
  listeners.set(el, cb);
  return () => {
    try {
      observer.unobserve(el);
    } catch (err) {
      console.error(err);
    }

    listeners.delete(el);
  };
};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router.isLocalURL)(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (true) {
      // rethrow to show invalid URL errors
      throw err;
    }
  }); // Join on an invalid URI character

  prefetched[href + '%' + as] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
  event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router.isLocalURL)(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null) {
    scroll = as.indexOf('#') < 0;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow
  }).then(success => {
    if (!success) return;

    if (scroll) {
      window.scrollTo(0, 0);
      document.body.focus();
    }
  });
}

function Link(props) {
  if (true) {
    function createPropError(args) {
      return new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + (false ? undefined : ''));
    } // TypeScript trick for type-guarding:


    const requiredPropsGuard = {
      href: true
    };
    const requiredProps = Object.keys(requiredPropsGuard);
    requiredProps.forEach(key => {
      if (key === 'href') {
        if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: props[key] === null ? 'null' : typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // TypeScript trick for type-guarding:

    const optionalPropsGuard = {
      as: true,
      replace: true,
      scroll: true,
      shallow: true,
      passHref: true,
      prefetch: true
    };
    const optionalProps = Object.keys(optionalPropsGuard);
    optionalProps.forEach(key => {
      if (key === 'as') {
        if (props[key] && typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: typeof props[key]
          });
        }
      } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'prefetch') {
        if (props[key] != null && typeof props[key] !== 'boolean') {
          throw createPropError({
            key,
            expected: '`boolean`',
            actual: typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // This hook is in a conditional but that is ok because `process.env.NODE_ENV` never changes
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const hasWarned = _react.default.useRef(false);

    if (props.prefetch && !hasWarned.current) {
      hasWarned.current = true;
      console.warn('Next.js auto-prefetches automatically based on viewport. The prefetch attribute is no longer needed. More: https://err.sh/vercel/next.js/prefetch-true-deprecated');
    }
  }

  const p = props.prefetch !== false;

  const [childElm, setChildElm] = _react.default.useState();

  const router = (0, _router2.useRouter)();
  const pathname = router && router.pathname || '/';

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router.resolveHref)(pathname, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router.resolveHref)(pathname, props.as) : resolvedAs || resolvedHref
    };
  }, [pathname, props.href, props.as]);

  _react.default.useEffect(() => {
    if (p && IntersectionObserver && childElm && childElm.tagName && (0, _router.isLocalURL)(href)) {
      // Join on an invalid URI character
      const isPrefetched = prefetched[href + '%' + as];

      if (!isPrefetched) {
        return listenToIntersections(childElm, () => {
          prefetch(router, href, as);
        });
      }
    }
  }, [p, childElm, href, as, router]);

  let {
    children,
    replace,
    shallow,
    scroll
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  const child = _react.Children.only(children);

  const childProps = {
    ref: el => {
      if (el) setChildElm(el);

      if (child && typeof child === 'object' && child.ref) {
        if (typeof child.ref === 'function') child.ref(el);else if (typeof child.ref === 'object') {
          child.ref.current = el;
        }
      }
    },
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll);
      }
    }
  };

  if (p) {
    childProps.onMouseEnter = e => {
      if (!(0, _router.isLocalURL)(href)) return;

      if (child.props && typeof child.props.onMouseEnter === 'function') {
        child.props.onMouseEnter(e);
      }

      prefetch(router, href, as, {
        priority: true
      });
    };
  } // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    childProps.href = (0, _router.addBasePath)((0, _router.addLocale)(as, router && router.locale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/client/normalize-trailing-slash.js":
/*!*******************************************************************!*\
  !*** ./node_modules/next/dist/client/normalize-trailing-slash.js ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? undefined : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "./node_modules/next/dist/client/router.js":
/*!*************************************************!*\
  !*** ./node_modules/next/dist/client/router.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router2 = _interopRequireWildcard(__webpack_require__(/*! ../next-server/lib/router/router */ "./node_modules/next/dist/next-server/lib/router/router.js"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__(/*! ../next-server/lib/router-context */ "../next-server/lib/router-context");

var _withRouter = _interopRequireDefault(__webpack_require__(/*! ./with-router */ "./node_modules/next/dist/client/with-router.js"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router[property]) ? [] : {}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/with-router.js":
/*!******************************************************!*\
  !*** ./node_modules/next/dist/client/with-router.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (true) {
    const name = ComposedComponent.displayName || ComposedComponent.name || 'Unknown';
    WithRouterWrapper.displayName = `withRouter(${name})`;
  }

  return WithRouterWrapper;
}

/***/ }),

/***/ "./node_modules/next/dist/compiled/path-to-regexp/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/next/dist/compiled/path-to-regexp/index.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Tokenize input string.
 */
function lexer(str) {
    var tokens = [];
    var i = 0;
    while (i < str.length) {
        var char = str[i];
        if (char === "*" || char === "+" || char === "?") {
            tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
            continue;
        }
        if (char === "\\") {
            tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
            continue;
        }
        if (char === "{") {
            tokens.push({ type: "OPEN", index: i, value: str[i++] });
            continue;
        }
        if (char === "}") {
            tokens.push({ type: "CLOSE", index: i, value: str[i++] });
            continue;
        }
        if (char === ":") {
            var name = "";
            var j = i + 1;
            while (j < str.length) {
                var code = str.charCodeAt(j);
                if (
                // `0-9`
                (code >= 48 && code <= 57) ||
                    // `A-Z`
                    (code >= 65 && code <= 90) ||
                    // `a-z`
                    (code >= 97 && code <= 122) ||
                    // `_`
                    code === 95) {
                    name += str[j++];
                    continue;
                }
                break;
            }
            if (!name)
                throw new TypeError("Missing parameter name at " + i);
            tokens.push({ type: "NAME", index: i, value: name });
            i = j;
            continue;
        }
        if (char === "(") {
            var count = 1;
            var pattern = "";
            var j = i + 1;
            if (str[j] === "?") {
                throw new TypeError("Pattern cannot start with \"?\" at " + j);
            }
            while (j < str.length) {
                if (str[j] === "\\") {
                    pattern += str[j++] + str[j++];
                    continue;
                }
                if (str[j] === ")") {
                    count--;
                    if (count === 0) {
                        j++;
                        break;
                    }
                }
                else if (str[j] === "(") {
                    count++;
                    if (str[j + 1] !== "?") {
                        throw new TypeError("Capturing groups are not allowed at " + j);
                    }
                }
                pattern += str[j++];
            }
            if (count)
                throw new TypeError("Unbalanced pattern at " + i);
            if (!pattern)
                throw new TypeError("Missing pattern at " + i);
            tokens.push({ type: "PATTERN", index: i, value: pattern });
            i = j;
            continue;
        }
        tokens.push({ type: "CHAR", index: i, value: str[i++] });
    }
    tokens.push({ type: "END", index: i, value: "" });
    return tokens;
}
/**
 * Parse a string for the raw tokens.
 */
function parse(str, options) {
    if (options === void 0) { options = {}; }
    var tokens = lexer(str);
    var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a;
    var defaultPattern = "[^" + escapeString(options.delimiter || "/#?") + "]+?";
    var result = [];
    var key = 0;
    var i = 0;
    var path = "";
    var tryConsume = function (type) {
        if (i < tokens.length && tokens[i].type === type)
            return tokens[i++].value;
    };
    var mustConsume = function (type) {
        var value = tryConsume(type);
        if (value !== undefined)
            return value;
        var _a = tokens[i], nextType = _a.type, index = _a.index;
        throw new TypeError("Unexpected " + nextType + " at " + index + ", expected " + type);
    };
    var consumeText = function () {
        var result = "";
        var value;
        // tslint:disable-next-line
        while ((value = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR"))) {
            result += value;
        }
        return result;
    };
    while (i < tokens.length) {
        var char = tryConsume("CHAR");
        var name = tryConsume("NAME");
        var pattern = tryConsume("PATTERN");
        if (name || pattern) {
            var prefix = char || "";
            if (prefixes.indexOf(prefix) === -1) {
                path += prefix;
                prefix = "";
            }
            if (path) {
                result.push(path);
                path = "";
            }
            result.push({
                name: name || key++,
                prefix: prefix,
                suffix: "",
                pattern: pattern || defaultPattern,
                modifier: tryConsume("MODIFIER") || ""
            });
            continue;
        }
        var value = char || tryConsume("ESCAPED_CHAR");
        if (value) {
            path += value;
            continue;
        }
        if (path) {
            result.push(path);
            path = "";
        }
        var open = tryConsume("OPEN");
        if (open) {
            var prefix = consumeText();
            var name_1 = tryConsume("NAME") || "";
            var pattern_1 = tryConsume("PATTERN") || "";
            var suffix = consumeText();
            mustConsume("CLOSE");
            result.push({
                name: name_1 || (pattern_1 ? key++ : ""),
                pattern: name_1 && !pattern_1 ? defaultPattern : pattern_1,
                prefix: prefix,
                suffix: suffix,
                modifier: tryConsume("MODIFIER") || ""
            });
            continue;
        }
        mustConsume("END");
    }
    return result;
}
exports.parse = parse;
/**
 * Compile a string to a template function for the path.
 */
function compile(str, options) {
    return tokensToFunction(parse(str, options), options);
}
exports.compile = compile;
/**
 * Expose a method for transforming tokens into the path function.
 */
function tokensToFunction(tokens, options) {
    if (options === void 0) { options = {}; }
    var reFlags = flags(options);
    var _a = options.encode, encode = _a === void 0 ? function (x) { return x; } : _a, _b = options.validate, validate = _b === void 0 ? true : _b;
    // Compile all the tokens into regexps.
    var matches = tokens.map(function (token) {
        if (typeof token === "object") {
            return new RegExp("^(?:" + token.pattern + ")$", reFlags);
        }
    });
    return function (data) {
        var path = "";
        for (var i = 0; i < tokens.length; i++) {
            var token = tokens[i];
            if (typeof token === "string") {
                path += token;
                continue;
            }
            var value = data ? data[token.name] : undefined;
            var optional = token.modifier === "?" || token.modifier === "*";
            var repeat = token.modifier === "*" || token.modifier === "+";
            if (Array.isArray(value)) {
                if (!repeat) {
                    throw new TypeError("Expected \"" + token.name + "\" to not repeat, but got an array");
                }
                if (value.length === 0) {
                    if (optional)
                        continue;
                    throw new TypeError("Expected \"" + token.name + "\" to not be empty");
                }
                for (var j = 0; j < value.length; j++) {
                    var segment = encode(value[j], token);
                    if (validate && !matches[i].test(segment)) {
                        throw new TypeError("Expected all \"" + token.name + "\" to match \"" + token.pattern + "\", but got \"" + segment + "\"");
                    }
                    path += token.prefix + segment + token.suffix;
                }
                continue;
            }
            if (typeof value === "string" || typeof value === "number") {
                var segment = encode(String(value), token);
                if (validate && !matches[i].test(segment)) {
                    throw new TypeError("Expected \"" + token.name + "\" to match \"" + token.pattern + "\", but got \"" + segment + "\"");
                }
                path += token.prefix + segment + token.suffix;
                continue;
            }
            if (optional)
                continue;
            var typeOfMessage = repeat ? "an array" : "a string";
            throw new TypeError("Expected \"" + token.name + "\" to be " + typeOfMessage);
        }
        return path;
    };
}
exports.tokensToFunction = tokensToFunction;
/**
 * Create path match function from `path-to-regexp` spec.
 */
function match(str, options) {
    var keys = [];
    var re = pathToRegexp(str, keys, options);
    return regexpToFunction(re, keys, options);
}
exports.match = match;
/**
 * Create a path match function from `path-to-regexp` output.
 */
function regexpToFunction(re, keys, options) {
    if (options === void 0) { options = {}; }
    var _a = options.decode, decode = _a === void 0 ? function (x) { return x; } : _a;
    return function (pathname) {
        var m = re.exec(pathname);
        if (!m)
            return false;
        var path = m[0], index = m.index;
        var params = Object.create(null);
        var _loop_1 = function (i) {
            // tslint:disable-next-line
            if (m[i] === undefined)
                return "continue";
            var key = keys[i - 1];
            if (key.modifier === "*" || key.modifier === "+") {
                params[key.name] = m[i].split(key.prefix + key.suffix).map(function (value) {
                    return decode(value, key);
                });
            }
            else {
                params[key.name] = decode(m[i], key);
            }
        };
        for (var i = 1; i < m.length; i++) {
            _loop_1(i);
        }
        return { path: path, index: index, params: params };
    };
}
exports.regexpToFunction = regexpToFunction;
/**
 * Escape a regular expression string.
 */
function escapeString(str) {
    return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
/**
 * Get the flags for a regexp from the options.
 */
function flags(options) {
    return options && options.sensitive ? "" : "i";
}
/**
 * Pull out keys from a regexp.
 */
function regexpToRegexp(path, keys) {
    if (!keys)
        return path;
    // Use a negative lookahead to match only capturing groups.
    var groups = path.source.match(/\((?!\?)/g);
    if (groups) {
        for (var i = 0; i < groups.length; i++) {
            keys.push({
                name: i,
                prefix: "",
                suffix: "",
                modifier: "",
                pattern: ""
            });
        }
    }
    return path;
}
/**
 * Transform an array into a regexp.
 */
function arrayToRegexp(paths, keys, options) {
    var parts = paths.map(function (path) { return pathToRegexp(path, keys, options).source; });
    return new RegExp("(?:" + parts.join("|") + ")", flags(options));
}
/**
 * Create a path regexp from string input.
 */
function stringToRegexp(path, keys, options) {
    return tokensToRegexp(parse(path, options), keys, options);
}
/**
 * Expose a function for taking tokens and returning a RegExp.
 */
function tokensToRegexp(tokens, keys, options) {
    if (options === void 0) { options = {}; }
    var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function (x) { return x; } : _d;
    var endsWith = "[" + escapeString(options.endsWith || "") + "]|$";
    var delimiter = "[" + escapeString(options.delimiter || "/#?") + "]";
    var route = start ? "^" : "";
    // Iterate over the tokens and create our regexp string.
    for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
        var token = tokens_1[_i];
        if (typeof token === "string") {
            route += escapeString(encode(token));
        }
        else {
            var prefix = escapeString(encode(token.prefix));
            var suffix = escapeString(encode(token.suffix));
            if (token.pattern) {
                if (keys)
                    keys.push(token);
                if (prefix || suffix) {
                    if (token.modifier === "+" || token.modifier === "*") {
                        var mod = token.modifier === "*" ? "?" : "";
                        route += "(?:" + prefix + "((?:" + token.pattern + ")(?:" + suffix + prefix + "(?:" + token.pattern + "))*)" + suffix + ")" + mod;
                    }
                    else {
                        route += "(?:" + prefix + "(" + token.pattern + ")" + suffix + ")" + token.modifier;
                    }
                }
                else {
                    route += "(" + token.pattern + ")" + token.modifier;
                }
            }
            else {
                route += "(?:" + prefix + suffix + ")" + token.modifier;
            }
        }
    }
    if (end) {
        if (!strict)
            route += delimiter + "?";
        route += !options.endsWith ? "$" : "(?=" + endsWith + ")";
    }
    else {
        var endToken = tokens[tokens.length - 1];
        var isEndDelimited = typeof endToken === "string"
            ? delimiter.indexOf(endToken[endToken.length - 1]) > -1
            : // tslint:disable-next-line
                endToken === undefined;
        if (!strict) {
            route += "(?:" + delimiter + "(?=" + endsWith + "))?";
        }
        if (!isEndDelimited) {
            route += "(?=" + delimiter + "|" + endsWith + ")";
        }
    }
    return new RegExp(route, flags(options));
}
exports.tokensToRegexp = tokensToRegexp;
/**
 * Normalize the given path string, returning a regular expression.
 *
 * An empty array can be passed in for the keys, which will hold the
 * placeholder key descriptions. For example, using `/user/:id`, `keys` will
 * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
 */
function pathToRegexp(path, keys, options) {
    if (path instanceof RegExp)
        return regexpToRegexp(path, keys);
    if (Array.isArray(path))
        return arrayToRegexp(path, keys, options);
    return stringToRegexp(path, keys, options);
}
exports.pathToRegexp = pathToRegexp;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/mitt.js":
/*!********************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/mitt.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/router.js":
/*!*****************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/router.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.markLoadingError = markLoadingError;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../client/normalize-trailing-slash */ "./node_modules/next/dist/client/normalize-trailing-slash.js");

var _denormalizePagePath = __webpack_require__(/*! ../../server/denormalize-page-path */ "./node_modules/next/dist/next-server/server/denormalize-page-path.js");

var _mitt = _interopRequireDefault(__webpack_require__(/*! ../mitt */ "./node_modules/next/dist/next-server/lib/mitt.js"));

var _utils = __webpack_require__(/*! ../utils */ "./node_modules/next/dist/next-server/lib/utils.js");

var _isDynamic = __webpack_require__(/*! ./utils/is-dynamic */ "./node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js");

var _parseRelativeUrl = __webpack_require__(/*! ./utils/parse-relative-url */ "./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js");

var _querystring = __webpack_require__(/*! ./utils/querystring */ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js");

var _resolveRewrites = _interopRequireDefault(__webpack_require__(/*! ./utils/resolve-rewrites */ "./node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites.js"));

var _routeMatcher = __webpack_require__(/*! ./utils/route-matcher */ "./node_modules/next/dist/next-server/lib/router/utils/route-matcher.js");

var _routeRegex = __webpack_require__(/*! ./utils/route-regex */ "./node_modules/next/dist/next-server/lib/router/utils/route-regex.js");

var _escapePathDelimiters = _interopRequireDefault(__webpack_require__(/*! ./utils/escape-path-delimiters */ "./node_modules/next/dist/next-server/lib/router/utils/escape-path-delimiters.js"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
/* global __NEXT_DATA__ */
// tslint:disable:no-console


const basePath = "/introducing-react-17" || false;

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(prefix) : `${prefix}${path}` : path;
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function hasBasePath(path) {
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  return path.slice(basePath.length) || '/';
}
/**
* Detects whether a given url is routable by the Next.js router (browser only).
*/


function isLocalURL(url) {
  if (url.startsWith('/')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils.getLocationOrigin)();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex.getRouteRegex)(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher.getRouteMatcher)(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && ( // Interpolate group into data URL if present
    interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map(_escapePathDelimiters.default).join('/') : (0, _escapePathDelimiters.default)(value)) || '/');
  })) {
    interpolatedRoute = ''; // did not satisfy all requirements
    // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(currentPath, href, resolveAs) {
  // we use a dummy base url for relative urls
  const base = new URL(currentPath, 'http://n');
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href);

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils.formatWithValidation)({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

const PAGE_LOAD_ERROR = Symbol('PAGE_LOAD_ERROR');

function markLoadingError(err) {
  return Object.defineProperty(err, PAGE_LOAD_ERROR, {});
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  return {
    url: addBasePath(resolveHref(router.pathname, url)),
    as: as ? addBasePath(resolveHref(router.pathname, as)) : as
  };
}

const manualScrollRestoration =  false && false;

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      markLoadingError(err);
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    initialStyleSheets,
    err,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;
    this._shallow = void 0;
    this.locale = void 0;
    this.locales = void 0;
    this.defaultLocale = void 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      if (!state.__N) {
        return;
      }

      const {
        url,
        as,
        options
      } = state;
      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as, Object.assign({}, options, {
        shallow: options.shallow && this._shallow
      }));
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        styleSheets: initialStyleSheets,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: [
        /* /_app does not need its stylesheets managed */
      ]
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    this.asPath = // @ts-ignore this is temporarily global (attached to window)
    (0, _isDynamic.isDynamicRoute)(_pathname) && __NEXT_DATA__.autoExport ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as = url, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as = url, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options) {
    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute);
    }

    as = addLocale(as, this.locale, this.defaultLocale);
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route]);
      Router.events.emit('hashChangeComplete', as);
      return true;
    } // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to


    const pages = await this.pageLoader.getPageList();
    const {
      __rewrites: rewrites
    } = await this.pageLoader.promisedBuildManifest;
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname,
      query
    } = parsed;
    parsed = this._resolveHref(parsed, pages);

    if (parsed.pathname !== pathname) {
      pathname = parsed.pathname;
      url = (0, _utils.formatWithValidation)(parsed);
    } // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1


    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname; // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url

    if (!this.urlIsNew(cleanedAs)) {
      method = 'replaceState';
    }

    let route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
    const {
      shallow = false
    } = options; // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly

    let resolvedAs = as;

    if (true) {
      resolvedAs = (0, _resolveRewrites.default)((0, _parseRelativeUrl.parseRelativeUrl)(as).pathname, pages, basePath, rewrites, query, p => this._resolveHref({
        pathname: p
      }, pages).pathname);

      if (resolvedAs !== as) {
        const potentialHref = (0, _normalizeTrailingSlash.removePathTrailingSlash)(this._resolveHref(Object.assign({}, parsed, {
          pathname: resolvedAs
        }), pages, false).pathname); // if this directly matches a page we need to update the href to
        // allow the correct page chunk to be loaded

        if (pages.includes(potentialHref)) {
          route = potentialHref;
          pathname = potentialHref;
          parsed.pathname = pathname;
          url = (0, _utils.formatWithValidation)(parsed);
        }
      }
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const parsedAs = (0, _parseRelativeUrl.parseRelativeUrl)(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (true) {
            console.warn(`${shouldInterpolate ? `Interpolating href` : `Mismatching \`as\` and \`href\``} failed to manually provide ` + `the params: ${missingParams.join(', ')} in the \`href\`'s \`query\``);
          }

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://err.sh/vercel/next.js/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils.formatWithValidation)(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as);

    try {
      const routeInfo = await this.getRouteInfo(route, pathname, query, as, shallow);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props && props.pageProps && props.pageProps.__N_REDIRECT) {
        const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
        // client-navigation if it is falling back to hard navigation if
        // it's not

        if (destination.startsWith('/')) {
          const parsedHref = (0, _parseRelativeUrl.parseRelativeUrl)(destination);

          this._resolveHref(parsedHref, pages);

          if (pages.includes(parsedHref.pathname)) {
            return this.change('replaceState', destination, destination, options);
          }
        }

        window.location.href = destination;
        return new Promise(() => {});
      }

      Router.events.emit('beforeHistoryChange', as);
      this.changeState(method, url, addLocale(as, this.locale, this.defaultLocale), options);

      if (true) {
        const appComp = this.components['/_app'].Component;
        window.next.isPrerendered = appComp.getInitialProps === appComp.origGetInitialProps && !routeInfo.Component.getInitialProps;
      }

      await this.set(route, pathname, query, cleanedAs, routeInfo).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (true) {
      if (typeof window.history === 'undefined') {
        console.error(`Warning: window.history is not available.`);
        return;
      }

      if (typeof window.history[method] === 'undefined') {
        console.error(`Warning: window.history.${method} is not available`);
        return;
      }
    }

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if (PAGE_LOAD_ERROR in err || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      const {
        page: Component,
        styleSheets
      } = await this.fetchComponent('/_error');
      const routeInfo = {
        Component,
        styleSheets,
        err,
        error: err
      };

      try {
        routeInfo.props = await this.getInitialProps(Component, {
          err,
          pathname,
          query
        });
      } catch (gipErr) {
        console.error('Error in error page `getInitialProps`: ', gipErr);
        routeInfo.props = {};
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, shallow = false) {
    try {
      const cachedRouteInfo = this.components[route];

      if (shallow && cachedRouteInfo && this.route === route) {
        return cachedRouteInfo;
      }

      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (true) {
        const {
          isValidElementType
        } = __webpack_require__(/*! react-is */ "react-is");

        if (!isValidElementType(Component)) {
          throw new Error(`The default export is not a React Component in page: "${pathname}"`);
        }
      }

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), delBasePath(as), __N_SSG, this.locale, this.defaultLocale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as);
    }
  }

  set(route, pathname, query, as, data) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value

    if (hash === '') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }

  _resolveHref(parsedHref, pages, applyBasePath = true) {
    const {
      pathname
    } = parsedHref;
    const cleanPathname = (0, _normalizeTrailingSlash.removePathTrailingSlash)((0, _denormalizePagePath.denormalizePagePath)(applyBasePath ? delBasePath(pathname) : pathname));

    if (cleanPathname === '/404' || cleanPathname === '/_error') {
      return parsedHref;
    } // handle resolving href for dynamic routes


    if (!pages.includes(cleanPathname)) {
      // eslint-disable-next-line array-callback-return
      pages.some(page => {
        if ((0, _isDynamic.isDynamicRoute)(page) && (0, _routeRegex.getRouteRegex)(page).re.test(cleanPathname)) {
          parsedHref.pathname = applyBasePath ? addBasePath(page) : page;
          return true;
        }
      });
    }

    return parsedHref;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname
    } = parsed;
    const pages = await this.pageLoader.getPageList();
    parsed = this._resolveHref(parsed, pages);

    if (parsed.pathname !== pathname) {
      pathname = parsed.pathname;
      url = (0, _utils.formatWithValidation)(parsed);
    } // Prefetch is not supported in development mode because it would trigger on-demand-entries


    if (true) {
      return;
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
    await Promise.all([this.pageLoader.prefetchData(url, asPath, this.locale, this.defaultLocale), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if (false) {}

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    return fetchNextData(dataHref, this.isSsr);
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as);
      this.clc();
      this.clc = null;
    }
  }

  notify(data) {
    return this.sub(data, this.components['/_app'].Component);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/escape-path-delimiters.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/escape-path-delimiters.js ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = escapePathDelimiters; // escape delimiters used by path-to-regexp

function escapePathDelimiters(segment) {
  return segment.replace(/[/#?]/g, char => encodeURIComponent(char));
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/format-url.js":
/*!***************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/format-url.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var querystring = _interopRequireWildcard(__webpack_require__(/*! ./querystring */ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
} // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    query = String(querystring.urlQueryToSearchParams(query));
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js":
/*!***************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;

var _utils = __webpack_require__(/*! ../../utils */ "./node_modules/next/dist/next-server/lib/utils.js");

var _querystring = __webpack_require__(/*! ./querystring */ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js");

const DUMMY_BASE = new URL(true ? 'http://n' : undefined);
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected with one exception, in the browser, absolute urls that are on
* the current origin will be parsed as relative
*/

function parseRelativeUrl(url, base) {
  const resolvedBase = base ? new URL(base, DUMMY_BASE) : DUMMY_BASE;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin,
    protocol
  } = new URL(url, resolvedBase);

  if (origin !== DUMMY_BASE.origin || protocol !== 'http:' && protocol !== 'https:') {
    throw new Error('invariant: invalid relative URL');
  }

  return {
    pathname,
    query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
    search,
    hash,
    href: href.slice(DUMMY_BASE.origin.length)
  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/path-match.js":
/*!***************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/path-match.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.__esModule = true;
exports.pathToRegexp = exports.default = exports.customRouteMatcherOptions = exports.matcherOptions = void 0;

var pathToRegexp = _interopRequireWildcard(__webpack_require__(/*! next/dist/compiled/path-to-regexp */ "./node_modules/next/dist/compiled/path-to-regexp/index.js"));

exports.pathToRegexp = pathToRegexp;

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

const matcherOptions = {
  sensitive: false,
  delimiter: '/'
};
exports.matcherOptions = matcherOptions;

const customRouteMatcherOptions = _objectSpread(_objectSpread({}, matcherOptions), {}, {
  strict: true
});

exports.customRouteMatcherOptions = customRouteMatcherOptions;

var _default = (customRoute = false) => {
  return path => {
    const keys = [];
    const matcherRegex = pathToRegexp.pathToRegexp(path, keys, customRoute ? customRouteMatcherOptions : matcherOptions);
    const matcher = pathToRegexp.regexpToFunction(matcherRegex, keys);
    return (pathname, params) => {
      const res = pathname == null ? false : matcher(pathname);

      if (!res) {
        return false;
      }

      if (customRoute) {
        for (const key of keys) {
          // unnamed params should be removed as they
          // are not allowed to be used in the destination
          if (typeof key.name === 'number') {
            delete res.params[key.name];
          }
        }
      }

      return _objectSpread(_objectSpread({}, params), res.params);
    };
  };
};

exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/prepare-destination.js":
/*!************************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/prepare-destination.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.__esModule = true;
exports.default = prepareDestination;

var _querystring = __webpack_require__(/*! ./querystring */ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js");

var _parseRelativeUrl = __webpack_require__(/*! ./parse-relative-url */ "./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js");

var pathToRegexp = _interopRequireWildcard(__webpack_require__(/*! next/dist/compiled/path-to-regexp */ "./node_modules/next/dist/compiled/path-to-regexp/index.js"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

function prepareDestination(destination, params, query, appendParamsToQuery, basePath) {
  let parsedDestination = {};

  if (destination.startsWith('/')) {
    parsedDestination = (0, _parseRelativeUrl.parseRelativeUrl)(destination);
  } else {
    const {
      pathname,
      searchParams,
      hash,
      hostname,
      port,
      protocol,
      search,
      href
    } = new URL(destination);
    parsedDestination = {
      pathname,
      query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
      hash,
      protocol,
      hostname,
      port,
      search,
      href
    };
  }

  const destQuery = parsedDestination.query;
  const destPath = `${parsedDestination.pathname}${parsedDestination.hash || ''}`;
  const destPathParamKeys = [];
  pathToRegexp.pathToRegexp(destPath, destPathParamKeys);
  const destPathParams = destPathParamKeys.map(key => key.name);
  let destinationCompiler = pathToRegexp.compile(destPath, // we don't validate while compiling the destination since we should
  // have already validated before we got to this point and validating
  // breaks compiling destinations with named pattern params from the source
  // e.g. /something:hello(.*) -> /another/:hello is broken with validation
  // since compile validation is meant for reversing and not for inserting
  // params from a separate path-regex into another
  {
    validate: false
  });
  let newUrl; // update any params in query values

  for (const [key, strOrArray] of Object.entries(destQuery)) {
    let value = Array.isArray(strOrArray) ? strOrArray[0] : strOrArray;

    if (value) {
      // the value needs to start with a forward-slash to be compiled
      // correctly
      value = `/${value}`;
      const queryCompiler = pathToRegexp.compile(value, {
        validate: false
      });
      value = queryCompiler(params).substr(1);
    }

    destQuery[key] = value;
  } // add path params to query if it's not a redirect and not
  // already defined in destination query or path


  const paramKeys = Object.keys(params);

  if (appendParamsToQuery && !paramKeys.some(key => destPathParams.includes(key))) {
    for (const key of paramKeys) {
      if (!(key in destQuery)) {
        destQuery[key] = params[key];
      }
    }
  }

  const shouldAddBasePath = destination.startsWith('/') && basePath;

  try {
    newUrl = `${shouldAddBasePath ? basePath : ''}${destinationCompiler(params)}`;
    const [pathname, hash] = newUrl.split('#');
    parsedDestination.pathname = pathname;
    parsedDestination.hash = `${hash ? '#' : ''}${hash || ''}`;
    delete parsedDestination.search;
  } catch (err) {
    if (err.message.match(/Expected .*? to not repeat, but got an array/)) {
      throw new Error(`To use a multi-match in the destination you must add \`*\` at the end of the param name to signify it should repeat. https://err.sh/vercel/next.js/invalid-multi-match`);
    }

    throw err;
  } // Query merge order lowest priority to highest
  // 1. initial URL query values
  // 2. path segment values
  // 3. destination specified query values


  parsedDestination.query = _objectSpread(_objectSpread({}, query), parsedDestination.query);
  return {
    newUrl,
    parsedDestination
  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js":
/*!****************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/querystring.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;
exports.urlQueryToSearchParams = urlQueryToSearchParams;
exports.assign = assign;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

function stringifyUrlQueryParam(param) {
  if (typeof param === 'string' || typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
    return String(param);
  } else {
    return '';
  }
}

function urlQueryToSearchParams(urlQuery) {
  const result = new URLSearchParams();
  Object.entries(urlQuery).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(item => result.append(key, stringifyUrlQueryParam(item)));
    } else {
      result.set(key, stringifyUrlQueryParam(value));
    }
  });
  return result;
}

function assign(target, ...searchParamsList) {
  searchParamsList.forEach(searchParams => {
    Array.from(searchParams.keys()).forEach(key => target.delete(key));
    searchParams.forEach((value, key) => target.append(key, value));
  });
  return target;
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = resolveRewrites;

var _pathMatch = _interopRequireDefault(__webpack_require__(/*! ./path-match */ "./node_modules/next/dist/next-server/lib/router/utils/path-match.js"));

var _prepareDestination = _interopRequireDefault(__webpack_require__(/*! ./prepare-destination */ "./node_modules/next/dist/next-server/lib/router/utils/prepare-destination.js"));

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../../client/normalize-trailing-slash */ "./node_modules/next/dist/client/normalize-trailing-slash.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const customRouteMatcher = (0, _pathMatch.default)(true);

function resolveRewrites(asPath, pages, basePath, rewrites, query, resolveHref) {
  if (!pages.includes(asPath)) {
    for (const rewrite of rewrites) {
      const matcher = customRouteMatcher(rewrite.source);
      const params = matcher(asPath);

      if (params) {
        if (!rewrite.destination) {
          // this is a proxied rewrite which isn't handled on the client
          break;
        }

        const destRes = (0, _prepareDestination.default)(rewrite.destination, params, query, true, rewrite.basePath === false ? '' : basePath);
        asPath = destRes.parsedDestination.pathname;
        Object.assign(query, destRes.parsedDestination.query);

        if (pages.includes((0, _normalizeTrailingSlash.removePathTrailingSlash)(asPath))) {
          // check if we now match a page as this means we are done
          // resolving the rewrites
          break;
        } // check if we match a dynamic-route, if so we break the rewrites chain


        const resolvedHref = resolveHref(asPath);

        if (resolvedHref !== asPath && pages.includes(resolvedHref)) {
          break;
        }
      }
    }
  }

  return asPath;
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/route-matcher.js":
/*!******************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/route-matcher.js ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/route-regex.js":
/*!****************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/route-regex.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/utils.js":
/*!*********************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/utils.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__(/*! ./router/utils/format-url */ "./node_modules/next/dist/next-server/lib/router/utils/format-url.js");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (true) {
    var _App$prototype;

    if ((_App$prototype = App.prototype) == null ? void 0 : _App$prototype.getInitialProps) {
      const message = `"${getDisplayName(App)}.getInitialProps()" is defined as an instance method - visit https://err.sh/vercel/next.js/get-initial-props-as-an-instance-method for more information.`;
      throw new Error(message);
    }
  } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (true) {
    if (Object.keys(props).length === 0 && !ctx.ctx) {
      console.warn(`${getDisplayName(App)} returned an empty object from \`getInitialProps\`. This de-optimizes and prevents automatic static optimization. https://err.sh/vercel/next.js/empty-object-getInitialProps`);
    }
  }

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (true) {
    if (url !== null && typeof url === 'object') {
      Object.keys(url).forEach(key => {
        if (urlObjectKeys.indexOf(key) === -1) {
          console.warn(`Unknown key passed via urlObject into url.format: ${key}`);
        }
      });
    }
  }

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "./node_modules/next/dist/next-server/server/denormalize-page-path.js":
/*!****************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/server/denormalize-page-path.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.__esModule=true;exports.normalizePathSep=normalizePathSep;exports.denormalizePagePath=denormalizePagePath;function normalizePathSep(path){return path.replace(/\\/g,'/');}function denormalizePagePath(page){page=normalizePathSep(page);if(page.startsWith('/index/')){page=page.slice(6);}else if(page==='/index'){page='/';}return page;}
//# sourceMappingURL=denormalize-page-path.js.map

/***/ }),

/***/ "./node_modules/next/link.js":
/*!***********************************!*\
  !*** ./node_modules/next/link.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/link */ "./node_modules/next/dist/client/link.js")


/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ../helpers/typeof */ "./node_modules/next/node_modules/@babel/runtime/helpers/typeof.js");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/typeof.js":
/*!*************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/typeof.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ "@emotion/styled");
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_PokemonInfo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/PokemonInfo */ "./components/PokemonInfo.jsx");
/* harmony import */ var _components_PokemonFilter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/PokemonFilter */ "./components/PokemonFilter.jsx");
/* harmony import */ var _components_PokemonTable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/PokemonTable */ "./components/PokemonTable.jsx");
/* harmony import */ var _src_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../src/store */ "./src/store.js");
var _jsxFileName = "E:\\Study\\React\\day-17\\pages\\index.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;






const Title = _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default.a.h1`
  text-align: center;
`;
const PageContainer = _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default.a.div`
  margin: auto;
  width: 800px;
  padding-top: 1em;
`;
const TwoColumnLayout = _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default.a.div`
  display: grid;
  grid-template-columns: 80% 20%;
  grid-column-gap: 1rem;
`;

const Home = () => {
  return __jsx(PageContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 5
    }
  }, __jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["CssBaseline"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }
  }), __jsx(Title, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }
  }, "Pokemon Search"), __jsx(TwoColumnLayout, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }
  }, __jsx("div", {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 9
    }
  }, __jsx(_components_PokemonFilter__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 11
    }
  }), __jsx(_components_PokemonTable__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 11
    }
  })), __jsx(_components_PokemonInfo__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 9
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Home);

/***/ }),

/***/ "./src/pokemon.json":
/*!**************************!*\
  !*** ./src/pokemon.json ***!
  \**************************/
/*! exports provided: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, default */
/***/ (function(module) {

module.exports = JSON.parse("[{\"id\":1,\"name\":{\"english\":\"Bulbasaur\",\"japanese\":\"フシギダネ\",\"chinese\":\"妙蛙种子\",\"french\":\"Bulbizarre\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":45,\"Attack\":49,\"Defense\":49,\"Sp. Attack\":65,\"Sp. Defense\":65,\"Speed\":45}},{\"id\":2,\"name\":{\"english\":\"Ivysaur\",\"japanese\":\"フシギソウ\",\"chinese\":\"妙蛙草\",\"french\":\"Herbizarre\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":60,\"Attack\":62,\"Defense\":63,\"Sp. Attack\":80,\"Sp. Defense\":80,\"Speed\":60}},{\"id\":3,\"name\":{\"english\":\"Venusaur\",\"japanese\":\"フシギバナ\",\"chinese\":\"妙蛙花\",\"french\":\"Florizarre\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":80,\"Attack\":82,\"Defense\":83,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":80}},{\"id\":4,\"name\":{\"english\":\"Charmander\",\"japanese\":\"ヒトカゲ\",\"chinese\":\"小火龙\",\"french\":\"Salamèche\"},\"type\":[\"Fire\"],\"base\":{\"HP\":39,\"Attack\":52,\"Defense\":43,\"Sp. Attack\":60,\"Sp. Defense\":50,\"Speed\":65}},{\"id\":5,\"name\":{\"english\":\"Charmeleon\",\"japanese\":\"リザード\",\"chinese\":\"火恐龙\",\"french\":\"Reptincel\"},\"type\":[\"Fire\"],\"base\":{\"HP\":58,\"Attack\":64,\"Defense\":58,\"Sp. Attack\":80,\"Sp. Defense\":65,\"Speed\":80}},{\"id\":6,\"name\":{\"english\":\"Charizard\",\"japanese\":\"リザードン\",\"chinese\":\"喷火龙\",\"french\":\"Dracaufeu\"},\"type\":[\"Fire\",\"Flying\"],\"base\":{\"HP\":78,\"Attack\":84,\"Defense\":78,\"Sp. Attack\":109,\"Sp. Defense\":85,\"Speed\":100}},{\"id\":7,\"name\":{\"english\":\"Squirtle\",\"japanese\":\"ゼニガメ\",\"chinese\":\"杰尼龟\",\"french\":\"Carapuce\"},\"type\":[\"Water\"],\"base\":{\"HP\":44,\"Attack\":48,\"Defense\":65,\"Sp. Attack\":50,\"Sp. Defense\":64,\"Speed\":43}},{\"id\":8,\"name\":{\"english\":\"Wartortle\",\"japanese\":\"カメール\",\"chinese\":\"卡咪龟\",\"french\":\"Carabaffe\"},\"type\":[\"Water\"],\"base\":{\"HP\":59,\"Attack\":63,\"Defense\":80,\"Sp. Attack\":65,\"Sp. Defense\":80,\"Speed\":58}},{\"id\":9,\"name\":{\"english\":\"Blastoise\",\"japanese\":\"カメックス\",\"chinese\":\"水箭龟\",\"french\":\"Tortank\"},\"type\":[\"Water\"],\"base\":{\"HP\":79,\"Attack\":83,\"Defense\":100,\"Sp. Attack\":85,\"Sp. Defense\":105,\"Speed\":78}},{\"id\":10,\"name\":{\"english\":\"Caterpie\",\"japanese\":\"キャタピー\",\"chinese\":\"绿毛虫\",\"french\":\"Chenipan\"},\"type\":[\"Bug\"],\"base\":{\"HP\":45,\"Attack\":30,\"Defense\":35,\"Sp. Attack\":20,\"Sp. Defense\":20,\"Speed\":45}},{\"id\":11,\"name\":{\"english\":\"Metapod\",\"japanese\":\"トランセル\",\"chinese\":\"铁甲蛹\",\"french\":\"Chrysacier\"},\"type\":[\"Bug\"],\"base\":{\"HP\":50,\"Attack\":20,\"Defense\":55,\"Sp. Attack\":25,\"Sp. Defense\":25,\"Speed\":30}},{\"id\":12,\"name\":{\"english\":\"Butterfree\",\"japanese\":\"バタフリー\",\"chinese\":\"巴大蝶\",\"french\":\"Papilusion\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":60,\"Attack\":45,\"Defense\":50,\"Sp. Attack\":90,\"Sp. Defense\":80,\"Speed\":70}},{\"id\":13,\"name\":{\"english\":\"Weedle\",\"japanese\":\"ビードル\",\"chinese\":\"独角虫\",\"french\":\"Aspicot\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":40,\"Attack\":35,\"Defense\":30,\"Sp. Attack\":20,\"Sp. Defense\":20,\"Speed\":50}},{\"id\":14,\"name\":{\"english\":\"Kakuna\",\"japanese\":\"コクーン\",\"chinese\":\"铁壳蛹\",\"french\":\"Coconfort\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":45,\"Attack\":25,\"Defense\":50,\"Sp. Attack\":25,\"Sp. Defense\":25,\"Speed\":35}},{\"id\":15,\"name\":{\"english\":\"Beedrill\",\"japanese\":\"スピアー\",\"chinese\":\"大针蜂\",\"french\":\"Dardargnan\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":65,\"Attack\":90,\"Defense\":40,\"Sp. Attack\":45,\"Sp. Defense\":80,\"Speed\":75}},{\"id\":16,\"name\":{\"english\":\"Pidgey\",\"japanese\":\"ポッポ\",\"chinese\":\"波波\",\"french\":\"Roucool\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":40,\"Attack\":45,\"Defense\":40,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":56}},{\"id\":17,\"name\":{\"english\":\"Pidgeotto\",\"japanese\":\"ピジョン\",\"chinese\":\"比比鸟\",\"french\":\"Roucoups\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":63,\"Attack\":60,\"Defense\":55,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":71}},{\"id\":18,\"name\":{\"english\":\"Pidgeot\",\"japanese\":\"ピジョット\",\"chinese\":\"大比鸟\",\"french\":\"Roucarnage\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":83,\"Attack\":80,\"Defense\":75,\"Sp. Attack\":70,\"Sp. Defense\":70,\"Speed\":101}},{\"id\":19,\"name\":{\"english\":\"Rattata\",\"japanese\":\"コラッタ\",\"chinese\":\"小拉达\",\"french\":\"Rattata\"},\"type\":[\"Normal\"],\"base\":{\"HP\":30,\"Attack\":56,\"Defense\":35,\"Sp. Attack\":25,\"Sp. Defense\":35,\"Speed\":72}},{\"id\":20,\"name\":{\"english\":\"Raticate\",\"japanese\":\"ラッタ\",\"chinese\":\"拉达\",\"french\":\"Rattatac\"},\"type\":[\"Normal\"],\"base\":{\"HP\":55,\"Attack\":81,\"Defense\":60,\"Sp. Attack\":50,\"Sp. Defense\":70,\"Speed\":97}},{\"id\":21,\"name\":{\"english\":\"Spearow\",\"japanese\":\"オニスズメ\",\"chinese\":\"烈雀\",\"french\":\"Piafabec\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":40,\"Attack\":60,\"Defense\":30,\"Sp. Attack\":31,\"Sp. Defense\":31,\"Speed\":70}},{\"id\":22,\"name\":{\"english\":\"Fearow\",\"japanese\":\"オニドリル\",\"chinese\":\"大嘴雀\",\"french\":\"Rapasdepic\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":65,\"Attack\":90,\"Defense\":65,\"Sp. Attack\":61,\"Sp. Defense\":61,\"Speed\":100}},{\"id\":23,\"name\":{\"english\":\"Ekans\",\"japanese\":\"アーボ\",\"chinese\":\"阿柏蛇\",\"french\":\"Abo\"},\"type\":[\"Poison\"],\"base\":{\"HP\":35,\"Attack\":60,\"Defense\":44,\"Sp. Attack\":40,\"Sp. Defense\":54,\"Speed\":55}},{\"id\":24,\"name\":{\"english\":\"Arbok\",\"japanese\":\"アーボック\",\"chinese\":\"阿柏怪\",\"french\":\"Arbok\"},\"type\":[\"Poison\"],\"base\":{\"HP\":60,\"Attack\":95,\"Defense\":69,\"Sp. Attack\":65,\"Sp. Defense\":79,\"Speed\":80}},{\"id\":25,\"name\":{\"english\":\"Pikachu\",\"japanese\":\"ピカチュウ\",\"chinese\":\"皮卡丘\",\"french\":\"Pikachu\"},\"type\":[\"Electric\"],\"base\":{\"HP\":35,\"Attack\":55,\"Defense\":40,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":90}},{\"id\":26,\"name\":{\"english\":\"Raichu\",\"japanese\":\"ライチュウ\",\"chinese\":\"雷丘\",\"french\":\"Raichu\"},\"type\":[\"Electric\"],\"base\":{\"HP\":60,\"Attack\":90,\"Defense\":55,\"Sp. Attack\":90,\"Sp. Defense\":80,\"Speed\":110}},{\"id\":27,\"name\":{\"english\":\"Sandshrew\",\"japanese\":\"サンド\",\"chinese\":\"穿山鼠\",\"french\":\"Sabelette\"},\"type\":[\"Ground\"],\"base\":{\"HP\":50,\"Attack\":75,\"Defense\":85,\"Sp. Attack\":20,\"Sp. Defense\":30,\"Speed\":40}},{\"id\":28,\"name\":{\"english\":\"Sandslash\",\"japanese\":\"サンドパン\",\"chinese\":\"穿山王\",\"french\":\"Sablaireau\"},\"type\":[\"Ground\"],\"base\":{\"HP\":75,\"Attack\":100,\"Defense\":110,\"Sp. Attack\":45,\"Sp. Defense\":55,\"Speed\":65}},{\"id\":29,\"name\":{\"english\":\"Nidoran♀\",\"japanese\":\"ニドラン♀\",\"chinese\":\"尼多兰\",\"french\":\"Nidoran♀\"},\"type\":[\"Poison\"],\"base\":{\"HP\":55,\"Attack\":47,\"Defense\":52,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":41}},{\"id\":30,\"name\":{\"english\":\"Nidorina\",\"japanese\":\"ニドリーナ\",\"chinese\":\"尼多娜\",\"french\":\"Nidorina\"},\"type\":[\"Poison\"],\"base\":{\"HP\":70,\"Attack\":62,\"Defense\":67,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":56}},{\"id\":31,\"name\":{\"english\":\"Nidoqueen\",\"japanese\":\"ニドクイン\",\"chinese\":\"尼多后\",\"french\":\"Nidoqueen\"},\"type\":[\"Poison\",\"Ground\"],\"base\":{\"HP\":90,\"Attack\":92,\"Defense\":87,\"Sp. Attack\":75,\"Sp. Defense\":85,\"Speed\":76}},{\"id\":32,\"name\":{\"english\":\"Nidoran♂\",\"japanese\":\"ニドラン♂\",\"chinese\":\"尼多朗\",\"french\":\"Nidoran♂\"},\"type\":[\"Poison\"],\"base\":{\"HP\":46,\"Attack\":57,\"Defense\":40,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":50}},{\"id\":33,\"name\":{\"english\":\"Nidorino\",\"japanese\":\"ニドリーノ\",\"chinese\":\"尼多力诺\",\"french\":\"Nidorino\"},\"type\":[\"Poison\"],\"base\":{\"HP\":61,\"Attack\":72,\"Defense\":57,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":65}},{\"id\":34,\"name\":{\"english\":\"Nidoking\",\"japanese\":\"ニドキング\",\"chinese\":\"尼多王\",\"french\":\"Nidoking\"},\"type\":[\"Poison\",\"Ground\"],\"base\":{\"HP\":81,\"Attack\":102,\"Defense\":77,\"Sp. Attack\":85,\"Sp. Defense\":75,\"Speed\":85}},{\"id\":35,\"name\":{\"english\":\"Clefairy\",\"japanese\":\"ピッピ\",\"chinese\":\"皮皮\",\"french\":\"Mélofée\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":70,\"Attack\":45,\"Defense\":48,\"Sp. Attack\":60,\"Sp. Defense\":65,\"Speed\":35}},{\"id\":36,\"name\":{\"english\":\"Clefable\",\"japanese\":\"ピクシー\",\"chinese\":\"皮可西\",\"french\":\"Mélodelfe\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":95,\"Attack\":70,\"Defense\":73,\"Sp. Attack\":95,\"Sp. Defense\":90,\"Speed\":60}},{\"id\":37,\"name\":{\"english\":\"Vulpix\",\"japanese\":\"ロコン\",\"chinese\":\"六尾\",\"french\":\"Goupix\"},\"type\":[\"Fire\"],\"base\":{\"HP\":38,\"Attack\":41,\"Defense\":40,\"Sp. Attack\":50,\"Sp. Defense\":65,\"Speed\":65}},{\"id\":38,\"name\":{\"english\":\"Ninetales\",\"japanese\":\"キュウコン\",\"chinese\":\"九尾\",\"french\":\"Feunard\"},\"type\":[\"Fire\"],\"base\":{\"HP\":73,\"Attack\":76,\"Defense\":75,\"Sp. Attack\":81,\"Sp. Defense\":100,\"Speed\":100}},{\"id\":39,\"name\":{\"english\":\"Jigglypuff\",\"japanese\":\"プリン\",\"chinese\":\"胖丁\",\"french\":\"Rondoudou\"},\"type\":[\"Normal\",\"Fairy\"],\"base\":{\"HP\":115,\"Attack\":45,\"Defense\":20,\"Sp. Attack\":45,\"Sp. Defense\":25,\"Speed\":20}},{\"id\":40,\"name\":{\"english\":\"Wigglytuff\",\"japanese\":\"プクリン\",\"chinese\":\"胖可丁\",\"french\":\"Grodoudou\"},\"type\":[\"Normal\",\"Fairy\"],\"base\":{\"HP\":140,\"Attack\":70,\"Defense\":45,\"Sp. Attack\":85,\"Sp. Defense\":50,\"Speed\":45}},{\"id\":41,\"name\":{\"english\":\"Zubat\",\"japanese\":\"ズバット\",\"chinese\":\"超音蝠\",\"french\":\"Nosferapti\"},\"type\":[\"Poison\",\"Flying\"],\"base\":{\"HP\":40,\"Attack\":45,\"Defense\":35,\"Sp. Attack\":30,\"Sp. Defense\":40,\"Speed\":55}},{\"id\":42,\"name\":{\"english\":\"Golbat\",\"japanese\":\"ゴルバット\",\"chinese\":\"大嘴蝠\",\"french\":\"Nosferalto\"},\"type\":[\"Poison\",\"Flying\"],\"base\":{\"HP\":75,\"Attack\":80,\"Defense\":70,\"Sp. Attack\":65,\"Sp. Defense\":75,\"Speed\":90}},{\"id\":43,\"name\":{\"english\":\"Oddish\",\"japanese\":\"ナゾノクサ\",\"chinese\":\"走路草\",\"french\":\"Mystherbe\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":45,\"Attack\":50,\"Defense\":55,\"Sp. Attack\":75,\"Sp. Defense\":65,\"Speed\":30}},{\"id\":44,\"name\":{\"english\":\"Gloom\",\"japanese\":\"クサイハナ\",\"chinese\":\"臭臭花\",\"french\":\"Ortide\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":60,\"Attack\":65,\"Defense\":70,\"Sp. Attack\":85,\"Sp. Defense\":75,\"Speed\":40}},{\"id\":45,\"name\":{\"english\":\"Vileplume\",\"japanese\":\"ラフレシア\",\"chinese\":\"霸王花\",\"french\":\"Rafflesia\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":75,\"Attack\":80,\"Defense\":85,\"Sp. Attack\":110,\"Sp. Defense\":90,\"Speed\":50}},{\"id\":46,\"name\":{\"english\":\"Paras\",\"japanese\":\"パラス\",\"chinese\":\"派拉斯\",\"french\":\"Paras\"},\"type\":[\"Bug\",\"Grass\"],\"base\":{\"HP\":35,\"Attack\":70,\"Defense\":55,\"Sp. Attack\":45,\"Sp. Defense\":55,\"Speed\":25}},{\"id\":47,\"name\":{\"english\":\"Parasect\",\"japanese\":\"パラセクト\",\"chinese\":\"派拉斯特\",\"french\":\"Parasect\"},\"type\":[\"Bug\",\"Grass\"],\"base\":{\"HP\":60,\"Attack\":95,\"Defense\":80,\"Sp. Attack\":60,\"Sp. Defense\":80,\"Speed\":30}},{\"id\":48,\"name\":{\"english\":\"Venonat\",\"japanese\":\"コンパン\",\"chinese\":\"毛球\",\"french\":\"Mimitoss\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":60,\"Attack\":55,\"Defense\":50,\"Sp. Attack\":40,\"Sp. Defense\":55,\"Speed\":45}},{\"id\":49,\"name\":{\"english\":\"Venomoth\",\"japanese\":\"モルフォン\",\"chinese\":\"摩鲁蛾\",\"french\":\"Aéromite\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":70,\"Attack\":65,\"Defense\":60,\"Sp. Attack\":90,\"Sp. Defense\":75,\"Speed\":90}},{\"id\":50,\"name\":{\"english\":\"Diglett\",\"japanese\":\"ディグダ\",\"chinese\":\"地鼠\",\"french\":\"Taupiqueur\"},\"type\":[\"Ground\"],\"base\":{\"HP\":10,\"Attack\":55,\"Defense\":25,\"Sp. Attack\":35,\"Sp. Defense\":45,\"Speed\":95}},{\"id\":51,\"name\":{\"english\":\"Dugtrio\",\"japanese\":\"ダグトリオ\",\"chinese\":\"三地鼠\",\"french\":\"Triopikeur\"},\"type\":[\"Ground\"],\"base\":{\"HP\":35,\"Attack\":100,\"Defense\":50,\"Sp. Attack\":50,\"Sp. Defense\":70,\"Speed\":120}},{\"id\":52,\"name\":{\"english\":\"Meowth\",\"japanese\":\"ニャース\",\"chinese\":\"喵喵\",\"french\":\"Miaouss\"},\"type\":[\"Normal\"],\"base\":{\"HP\":40,\"Attack\":45,\"Defense\":35,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":90}},{\"id\":53,\"name\":{\"english\":\"Persian\",\"japanese\":\"ペルシアン\",\"chinese\":\"猫老大\",\"french\":\"Persian\"},\"type\":[\"Normal\"],\"base\":{\"HP\":65,\"Attack\":70,\"Defense\":60,\"Sp. Attack\":65,\"Sp. Defense\":65,\"Speed\":115}},{\"id\":54,\"name\":{\"english\":\"Psyduck\",\"japanese\":\"コダック\",\"chinese\":\"可达鸭\",\"french\":\"Psykokwak\"},\"type\":[\"Water\"],\"base\":{\"HP\":50,\"Attack\":52,\"Defense\":48,\"Sp. Attack\":65,\"Sp. Defense\":50,\"Speed\":55}},{\"id\":55,\"name\":{\"english\":\"Golduck\",\"japanese\":\"ゴルダック\",\"chinese\":\"哥达鸭\",\"french\":\"Akwakwak\"},\"type\":[\"Water\"],\"base\":{\"HP\":80,\"Attack\":82,\"Defense\":78,\"Sp. Attack\":95,\"Sp. Defense\":80,\"Speed\":85}},{\"id\":56,\"name\":{\"english\":\"Mankey\",\"japanese\":\"マンキー\",\"chinese\":\"猴怪\",\"french\":\"Férosinge\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":40,\"Attack\":80,\"Defense\":35,\"Sp. Attack\":35,\"Sp. Defense\":45,\"Speed\":70}},{\"id\":57,\"name\":{\"english\":\"Primeape\",\"japanese\":\"オコリザル\",\"chinese\":\"火暴猴\",\"french\":\"Colossinge\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":65,\"Attack\":105,\"Defense\":60,\"Sp. Attack\":60,\"Sp. Defense\":70,\"Speed\":95}},{\"id\":58,\"name\":{\"english\":\"Growlithe\",\"japanese\":\"ガーディ\",\"chinese\":\"卡蒂狗\",\"french\":\"Caninos\"},\"type\":[\"Fire\"],\"base\":{\"HP\":55,\"Attack\":70,\"Defense\":45,\"Sp. Attack\":70,\"Sp. Defense\":50,\"Speed\":60}},{\"id\":59,\"name\":{\"english\":\"Arcanine\",\"japanese\":\"ウインディ\",\"chinese\":\"风速狗\",\"french\":\"Arcanin\"},\"type\":[\"Fire\"],\"base\":{\"HP\":90,\"Attack\":110,\"Defense\":80,\"Sp. Attack\":100,\"Sp. Defense\":80,\"Speed\":95}},{\"id\":60,\"name\":{\"english\":\"Poliwag\",\"japanese\":\"ニョロモ\",\"chinese\":\"蚊香蝌蚪\",\"french\":\"Ptitard\"},\"type\":[\"Water\"],\"base\":{\"HP\":40,\"Attack\":50,\"Defense\":40,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":90}},{\"id\":61,\"name\":{\"english\":\"Poliwhirl\",\"japanese\":\"ニョロゾ\",\"chinese\":\"蚊香君\",\"french\":\"Têtarte\"},\"type\":[\"Water\"],\"base\":{\"HP\":65,\"Attack\":65,\"Defense\":65,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":90}},{\"id\":62,\"name\":{\"english\":\"Poliwrath\",\"japanese\":\"ニョロボン\",\"chinese\":\"蚊香泳士\",\"french\":\"Tartard\"},\"type\":[\"Water\",\"Fighting\"],\"base\":{\"HP\":90,\"Attack\":95,\"Defense\":95,\"Sp. Attack\":70,\"Sp. Defense\":90,\"Speed\":70}},{\"id\":63,\"name\":{\"english\":\"Abra\",\"japanese\":\"ケーシィ\",\"chinese\":\"凯西\",\"french\":\"Abra\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":25,\"Attack\":20,\"Defense\":15,\"Sp. Attack\":105,\"Sp. Defense\":55,\"Speed\":90}},{\"id\":64,\"name\":{\"english\":\"Kadabra\",\"japanese\":\"ユンゲラー\",\"chinese\":\"勇基拉\",\"french\":\"Kadabra\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":40,\"Attack\":35,\"Defense\":30,\"Sp. Attack\":120,\"Sp. Defense\":70,\"Speed\":105}},{\"id\":65,\"name\":{\"english\":\"Alakazam\",\"japanese\":\"フーディン\",\"chinese\":\"胡地\",\"french\":\"Alakazam\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":55,\"Attack\":50,\"Defense\":45,\"Sp. Attack\":135,\"Sp. Defense\":95,\"Speed\":120}},{\"id\":66,\"name\":{\"english\":\"Machop\",\"japanese\":\"ワンリキー\",\"chinese\":\"腕力\",\"french\":\"Machoc\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":70,\"Attack\":80,\"Defense\":50,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":35}},{\"id\":67,\"name\":{\"english\":\"Machoke\",\"japanese\":\"ゴーリキー\",\"chinese\":\"豪力\",\"french\":\"Machopeur\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":80,\"Attack\":100,\"Defense\":70,\"Sp. Attack\":50,\"Sp. Defense\":60,\"Speed\":45}},{\"id\":68,\"name\":{\"english\":\"Machamp\",\"japanese\":\"カイリキー\",\"chinese\":\"怪力\",\"french\":\"Mackogneur\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":90,\"Attack\":130,\"Defense\":80,\"Sp. Attack\":65,\"Sp. Defense\":85,\"Speed\":55}},{\"id\":69,\"name\":{\"english\":\"Bellsprout\",\"japanese\":\"マダツボミ\",\"chinese\":\"喇叭芽\",\"french\":\"Chétiflor\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":50,\"Attack\":75,\"Defense\":35,\"Sp. Attack\":70,\"Sp. Defense\":30,\"Speed\":40}},{\"id\":70,\"name\":{\"english\":\"Weepinbell\",\"japanese\":\"ウツドン\",\"chinese\":\"口呆花\",\"french\":\"Boustiflor\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":65,\"Attack\":90,\"Defense\":50,\"Sp. Attack\":85,\"Sp. Defense\":45,\"Speed\":55}},{\"id\":71,\"name\":{\"english\":\"Victreebel\",\"japanese\":\"ウツボット\",\"chinese\":\"大食花\",\"french\":\"Empiflor\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":80,\"Attack\":105,\"Defense\":65,\"Sp. Attack\":100,\"Sp. Defense\":70,\"Speed\":70}},{\"id\":72,\"name\":{\"english\":\"Tentacool\",\"japanese\":\"メノクラゲ\",\"chinese\":\"玛瑙水母\",\"french\":\"Tentacool\"},\"type\":[\"Water\",\"Poison\"],\"base\":{\"HP\":40,\"Attack\":40,\"Defense\":35,\"Sp. Attack\":50,\"Sp. Defense\":100,\"Speed\":70}},{\"id\":73,\"name\":{\"english\":\"Tentacruel\",\"japanese\":\"ドククラゲ\",\"chinese\":\"毒刺水母\",\"french\":\"Tentacruel\"},\"type\":[\"Water\",\"Poison\"],\"base\":{\"HP\":80,\"Attack\":70,\"Defense\":65,\"Sp. Attack\":80,\"Sp. Defense\":120,\"Speed\":100}},{\"id\":74,\"name\":{\"english\":\"Geodude\",\"japanese\":\"イシツブテ\",\"chinese\":\"小拳石\",\"french\":\"Racaillou\"},\"type\":[\"Rock\",\"Ground\"],\"base\":{\"HP\":40,\"Attack\":80,\"Defense\":100,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":20}},{\"id\":75,\"name\":{\"english\":\"Graveler\",\"japanese\":\"ゴローン\",\"chinese\":\"隆隆石\",\"french\":\"Gravalanch\"},\"type\":[\"Rock\",\"Ground\"],\"base\":{\"HP\":55,\"Attack\":95,\"Defense\":115,\"Sp. Attack\":45,\"Sp. Defense\":45,\"Speed\":35}},{\"id\":76,\"name\":{\"english\":\"Golem\",\"japanese\":\"ゴローニャ\",\"chinese\":\"隆隆岩\",\"french\":\"Grolem\"},\"type\":[\"Rock\",\"Ground\"],\"base\":{\"HP\":80,\"Attack\":120,\"Defense\":130,\"Sp. Attack\":55,\"Sp. Defense\":65,\"Speed\":45}},{\"id\":77,\"name\":{\"english\":\"Ponyta\",\"japanese\":\"ポニータ\",\"chinese\":\"小火马\",\"french\":\"Ponyta\"},\"type\":[\"Fire\"],\"base\":{\"HP\":50,\"Attack\":85,\"Defense\":55,\"Sp. Attack\":65,\"Sp. Defense\":65,\"Speed\":90}},{\"id\":78,\"name\":{\"english\":\"Rapidash\",\"japanese\":\"ギャロップ\",\"chinese\":\"烈焰马\",\"french\":\"Galopa\"},\"type\":[\"Fire\"],\"base\":{\"HP\":65,\"Attack\":100,\"Defense\":70,\"Sp. Attack\":80,\"Sp. Defense\":80,\"Speed\":105}},{\"id\":79,\"name\":{\"english\":\"Slowpoke\",\"japanese\":\"ヤドン\",\"chinese\":\"呆呆兽\",\"french\":\"Ramoloss\"},\"type\":[\"Water\",\"Psychic\"],\"base\":{\"HP\":90,\"Attack\":65,\"Defense\":65,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":15}},{\"id\":80,\"name\":{\"english\":\"Slowbro\",\"japanese\":\"ヤドラン\",\"chinese\":\"呆壳兽\",\"french\":\"Flagadoss\"},\"type\":[\"Water\",\"Psychic\"],\"base\":{\"HP\":95,\"Attack\":75,\"Defense\":110,\"Sp. Attack\":100,\"Sp. Defense\":80,\"Speed\":30}},{\"id\":81,\"name\":{\"english\":\"Magnemite\",\"japanese\":\"コイル\",\"chinese\":\"小磁怪\",\"french\":\"Magnéti\"},\"type\":[\"Electric\",\"Steel\"],\"base\":{\"HP\":25,\"Attack\":35,\"Defense\":70,\"Sp. Attack\":95,\"Sp. Defense\":55,\"Speed\":45}},{\"id\":82,\"name\":{\"english\":\"Magneton\",\"japanese\":\"レアコイル\",\"chinese\":\"三合一磁怪\",\"french\":\"Magnéton\"},\"type\":[\"Electric\",\"Steel\"],\"base\":{\"HP\":50,\"Attack\":60,\"Defense\":95,\"Sp. Attack\":120,\"Sp. Defense\":70,\"Speed\":70}},{\"id\":83,\"name\":{\"english\":\"Farfetch'd\",\"japanese\":\"カモネギ\",\"chinese\":\"大葱鸭\",\"french\":\"Canarticho\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":52,\"Attack\":90,\"Defense\":55,\"Sp. Attack\":58,\"Sp. Defense\":62,\"Speed\":60}},{\"id\":84,\"name\":{\"english\":\"Doduo\",\"japanese\":\"ドードー\",\"chinese\":\"嘟嘟\",\"french\":\"Doduo\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":35,\"Attack\":85,\"Defense\":45,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":75}},{\"id\":85,\"name\":{\"english\":\"Dodrio\",\"japanese\":\"ドードリオ\",\"chinese\":\"嘟嘟利\",\"french\":\"Dodrio\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":60,\"Attack\":110,\"Defense\":70,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":110}},{\"id\":86,\"name\":{\"english\":\"Seel\",\"japanese\":\"パウワウ\",\"chinese\":\"小海狮\",\"french\":\"Otaria\"},\"type\":[\"Water\"],\"base\":{\"HP\":65,\"Attack\":45,\"Defense\":55,\"Sp. Attack\":45,\"Sp. Defense\":70,\"Speed\":45}},{\"id\":87,\"name\":{\"english\":\"Dewgong\",\"japanese\":\"ジュゴン\",\"chinese\":\"白海狮\",\"french\":\"Lamantine\"},\"type\":[\"Water\",\"Ice\"],\"base\":{\"HP\":90,\"Attack\":70,\"Defense\":80,\"Sp. Attack\":70,\"Sp. Defense\":95,\"Speed\":70}},{\"id\":88,\"name\":{\"english\":\"Grimer\",\"japanese\":\"ベトベター\",\"chinese\":\"臭泥\",\"french\":\"Tadmorv\"},\"type\":[\"Poison\"],\"base\":{\"HP\":80,\"Attack\":80,\"Defense\":50,\"Sp. Attack\":40,\"Sp. Defense\":50,\"Speed\":25}},{\"id\":89,\"name\":{\"english\":\"Muk\",\"japanese\":\"ベトベトン\",\"chinese\":\"臭臭泥\",\"french\":\"Grotadmorv\"},\"type\":[\"Poison\"],\"base\":{\"HP\":105,\"Attack\":105,\"Defense\":75,\"Sp. Attack\":65,\"Sp. Defense\":100,\"Speed\":50}},{\"id\":90,\"name\":{\"english\":\"Shellder\",\"japanese\":\"シェルダー\",\"chinese\":\"大舌贝\",\"french\":\"Kokiyas\"},\"type\":[\"Water\"],\"base\":{\"HP\":30,\"Attack\":65,\"Defense\":100,\"Sp. Attack\":45,\"Sp. Defense\":25,\"Speed\":40}},{\"id\":91,\"name\":{\"english\":\"Cloyster\",\"japanese\":\"パルシェン\",\"chinese\":\"刺甲贝\",\"french\":\"Crustabri\"},\"type\":[\"Water\",\"Ice\"],\"base\":{\"HP\":50,\"Attack\":95,\"Defense\":180,\"Sp. Attack\":85,\"Sp. Defense\":45,\"Speed\":70}},{\"id\":92,\"name\":{\"english\":\"Gastly\",\"japanese\":\"ゴース\",\"chinese\":\"鬼斯\",\"french\":\"Fantominus\"},\"type\":[\"Ghost\",\"Poison\"],\"base\":{\"HP\":30,\"Attack\":35,\"Defense\":30,\"Sp. Attack\":100,\"Sp. Defense\":35,\"Speed\":80}},{\"id\":93,\"name\":{\"english\":\"Haunter\",\"japanese\":\"ゴースト\",\"chinese\":\"鬼斯通\",\"french\":\"Spectrum\"},\"type\":[\"Ghost\",\"Poison\"],\"base\":{\"HP\":45,\"Attack\":50,\"Defense\":45,\"Sp. Attack\":115,\"Sp. Defense\":55,\"Speed\":95}},{\"id\":94,\"name\":{\"english\":\"Gengar\",\"japanese\":\"ゲンガー\",\"chinese\":\"耿鬼\",\"french\":\"Ectoplasma\"},\"type\":[\"Ghost\",\"Poison\"],\"base\":{\"HP\":60,\"Attack\":65,\"Defense\":60,\"Sp. Attack\":130,\"Sp. Defense\":75,\"Speed\":110}},{\"id\":95,\"name\":{\"english\":\"Onix\",\"japanese\":\"イワーク\",\"chinese\":\"大岩蛇\",\"french\":\"Onix\"},\"type\":[\"Rock\",\"Ground\"],\"base\":{\"HP\":35,\"Attack\":45,\"Defense\":160,\"Sp. Attack\":30,\"Sp. Defense\":45,\"Speed\":70}},{\"id\":96,\"name\":{\"english\":\"Drowzee\",\"japanese\":\"スリープ\",\"chinese\":\"催眠貘\",\"french\":\"Soporifik\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":60,\"Attack\":48,\"Defense\":45,\"Sp. Attack\":43,\"Sp. Defense\":90,\"Speed\":42}},{\"id\":97,\"name\":{\"english\":\"Hypno\",\"japanese\":\"スリーパー\",\"chinese\":\"引梦貘人\",\"french\":\"Hypnomade\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":85,\"Attack\":73,\"Defense\":70,\"Sp. Attack\":73,\"Sp. Defense\":115,\"Speed\":67}},{\"id\":98,\"name\":{\"english\":\"Krabby\",\"japanese\":\"クラブ\",\"chinese\":\"大钳蟹\",\"french\":\"Krabby\"},\"type\":[\"Water\"],\"base\":{\"HP\":30,\"Attack\":105,\"Defense\":90,\"Sp. Attack\":25,\"Sp. Defense\":25,\"Speed\":50}},{\"id\":99,\"name\":{\"english\":\"Kingler\",\"japanese\":\"キングラー\",\"chinese\":\"巨钳蟹\",\"french\":\"Krabboss\"},\"type\":[\"Water\"],\"base\":{\"HP\":55,\"Attack\":130,\"Defense\":115,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":75}},{\"id\":100,\"name\":{\"english\":\"Voltorb\",\"japanese\":\"ビリリダマ\",\"chinese\":\"霹雳电球\",\"french\":\"Voltorbe\"},\"type\":[\"Electric\"],\"base\":{\"HP\":40,\"Attack\":30,\"Defense\":50,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":100}},{\"id\":101,\"name\":{\"english\":\"Electrode\",\"japanese\":\"マルマイン\",\"chinese\":\"顽皮雷弹\",\"french\":\"Électrode\"},\"type\":[\"Electric\"],\"base\":{\"HP\":60,\"Attack\":50,\"Defense\":70,\"Sp. Attack\":80,\"Sp. Defense\":80,\"Speed\":150}},{\"id\":102,\"name\":{\"english\":\"Exeggcute\",\"japanese\":\"タマタマ\",\"chinese\":\"蛋蛋\",\"french\":\"Noeunoeuf\"},\"type\":[\"Grass\",\"Psychic\"],\"base\":{\"HP\":60,\"Attack\":40,\"Defense\":80,\"Sp. Attack\":60,\"Sp. Defense\":45,\"Speed\":40}},{\"id\":103,\"name\":{\"english\":\"Exeggutor\",\"japanese\":\"ナッシー\",\"chinese\":\"椰蛋树\",\"french\":\"Noadkoko\"},\"type\":[\"Grass\",\"Psychic\"],\"base\":{\"HP\":95,\"Attack\":95,\"Defense\":85,\"Sp. Attack\":125,\"Sp. Defense\":75,\"Speed\":55}},{\"id\":104,\"name\":{\"english\":\"Cubone\",\"japanese\":\"カラカラ\",\"chinese\":\"卡拉卡拉\",\"french\":\"Osselait\"},\"type\":[\"Ground\"],\"base\":{\"HP\":50,\"Attack\":50,\"Defense\":95,\"Sp. Attack\":40,\"Sp. Defense\":50,\"Speed\":35}},{\"id\":105,\"name\":{\"english\":\"Marowak\",\"japanese\":\"ガラガラ\",\"chinese\":\"嘎啦嘎啦\",\"french\":\"Ossatueur\"},\"type\":[\"Ground\"],\"base\":{\"HP\":60,\"Attack\":80,\"Defense\":110,\"Sp. Attack\":50,\"Sp. Defense\":80,\"Speed\":45}},{\"id\":106,\"name\":{\"english\":\"Hitmonlee\",\"japanese\":\"サワムラー\",\"chinese\":\"飞腿郎\",\"french\":\"Kicklee\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":50,\"Attack\":120,\"Defense\":53,\"Sp. Attack\":35,\"Sp. Defense\":110,\"Speed\":87}},{\"id\":107,\"name\":{\"english\":\"Hitmonchan\",\"japanese\":\"エビワラー\",\"chinese\":\"快拳郎\",\"french\":\"Tygnon\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":50,\"Attack\":105,\"Defense\":79,\"Sp. Attack\":35,\"Sp. Defense\":110,\"Speed\":76}},{\"id\":108,\"name\":{\"english\":\"Lickitung\",\"japanese\":\"ベロリンガ\",\"chinese\":\"大舌头\",\"french\":\"Excelangue\"},\"type\":[\"Normal\"],\"base\":{\"HP\":90,\"Attack\":55,\"Defense\":75,\"Sp. Attack\":60,\"Sp. Defense\":75,\"Speed\":30}},{\"id\":109,\"name\":{\"english\":\"Koffing\",\"japanese\":\"ドガース\",\"chinese\":\"瓦斯弹\",\"french\":\"Smogo\"},\"type\":[\"Poison\"],\"base\":{\"HP\":40,\"Attack\":65,\"Defense\":95,\"Sp. Attack\":60,\"Sp. Defense\":45,\"Speed\":35}},{\"id\":110,\"name\":{\"english\":\"Weezing\",\"japanese\":\"マタドガス\",\"chinese\":\"双弹瓦斯\",\"french\":\"Smogogo\"},\"type\":[\"Poison\"],\"base\":{\"HP\":65,\"Attack\":90,\"Defense\":120,\"Sp. Attack\":85,\"Sp. Defense\":70,\"Speed\":60}},{\"id\":111,\"name\":{\"english\":\"Rhyhorn\",\"japanese\":\"サイホーン\",\"chinese\":\"独角犀牛\",\"french\":\"Rhinocorne\"},\"type\":[\"Ground\",\"Rock\"],\"base\":{\"HP\":80,\"Attack\":85,\"Defense\":95,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":25}},{\"id\":112,\"name\":{\"english\":\"Rhydon\",\"japanese\":\"サイドン\",\"chinese\":\"钻角犀兽\",\"french\":\"Rhinoféros\"},\"type\":[\"Ground\",\"Rock\"],\"base\":{\"HP\":105,\"Attack\":130,\"Defense\":120,\"Sp. Attack\":45,\"Sp. Defense\":45,\"Speed\":40}},{\"id\":113,\"name\":{\"english\":\"Chansey\",\"japanese\":\"ラッキー\",\"chinese\":\"吉利蛋\",\"french\":\"Leveinard\"},\"type\":[\"Normal\"],\"base\":{\"HP\":250,\"Attack\":5,\"Defense\":5,\"Sp. Attack\":35,\"Sp. Defense\":105,\"Speed\":50}},{\"id\":114,\"name\":{\"english\":\"Tangela\",\"japanese\":\"モンジャラ\",\"chinese\":\"蔓藤怪\",\"french\":\"Saquedeneu\"},\"type\":[\"Grass\"],\"base\":{\"HP\":65,\"Attack\":55,\"Defense\":115,\"Sp. Attack\":100,\"Sp. Defense\":40,\"Speed\":60}},{\"id\":115,\"name\":{\"english\":\"Kangaskhan\",\"japanese\":\"ガルーラ\",\"chinese\":\"袋兽\",\"french\":\"Kangourex\"},\"type\":[\"Normal\"],\"base\":{\"HP\":105,\"Attack\":95,\"Defense\":80,\"Sp. Attack\":40,\"Sp. Defense\":80,\"Speed\":90}},{\"id\":116,\"name\":{\"english\":\"Horsea\",\"japanese\":\"タッツー\",\"chinese\":\"墨海马\",\"french\":\"Hypotrempe\"},\"type\":[\"Water\"],\"base\":{\"HP\":30,\"Attack\":40,\"Defense\":70,\"Sp. Attack\":70,\"Sp. Defense\":25,\"Speed\":60}},{\"id\":117,\"name\":{\"english\":\"Seadra\",\"japanese\":\"シードラ\",\"chinese\":\"海刺龙\",\"french\":\"Hypocéan\"},\"type\":[\"Water\"],\"base\":{\"HP\":55,\"Attack\":65,\"Defense\":95,\"Sp. Attack\":95,\"Sp. Defense\":45,\"Speed\":85}},{\"id\":118,\"name\":{\"english\":\"Goldeen\",\"japanese\":\"トサキント\",\"chinese\":\"角金鱼\",\"french\":\"Poissirène\"},\"type\":[\"Water\"],\"base\":{\"HP\":45,\"Attack\":67,\"Defense\":60,\"Sp. Attack\":35,\"Sp. Defense\":50,\"Speed\":63}},{\"id\":119,\"name\":{\"english\":\"Seaking\",\"japanese\":\"アズマオウ\",\"chinese\":\"金鱼王\",\"french\":\"Poissoroy\"},\"type\":[\"Water\"],\"base\":{\"HP\":80,\"Attack\":92,\"Defense\":65,\"Sp. Attack\":65,\"Sp. Defense\":80,\"Speed\":68}},{\"id\":120,\"name\":{\"english\":\"Staryu\",\"japanese\":\"ヒトデマン\",\"chinese\":\"海星星\",\"french\":\"Stari\"},\"type\":[\"Water\"],\"base\":{\"HP\":30,\"Attack\":45,\"Defense\":55,\"Sp. Attack\":70,\"Sp. Defense\":55,\"Speed\":85}},{\"id\":121,\"name\":{\"english\":\"Starmie\",\"japanese\":\"スターミー\",\"chinese\":\"宝石海星\",\"french\":\"Staross\"},\"type\":[\"Water\",\"Psychic\"],\"base\":{\"HP\":60,\"Attack\":75,\"Defense\":85,\"Sp. Attack\":100,\"Sp. Defense\":85,\"Speed\":115}},{\"id\":122,\"name\":{\"english\":\"Mr. Mime\",\"japanese\":\"バリヤード\",\"chinese\":\"魔墙人偶\",\"french\":\"M. Mime\"},\"type\":[\"Psychic\",\"Fairy\"],\"base\":{\"HP\":40,\"Attack\":45,\"Defense\":65,\"Sp. Attack\":100,\"Sp. Defense\":120,\"Speed\":90}},{\"id\":123,\"name\":{\"english\":\"Scyther\",\"japanese\":\"ストライク\",\"chinese\":\"飞天螳螂\",\"french\":\"Insécateur\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":70,\"Attack\":110,\"Defense\":80,\"Sp. Attack\":55,\"Sp. Defense\":80,\"Speed\":105}},{\"id\":124,\"name\":{\"english\":\"Jynx\",\"japanese\":\"ルージュラ\",\"chinese\":\"迷唇姐\",\"french\":\"Lippoutou\"},\"type\":[\"Ice\",\"Psychic\"],\"base\":{\"HP\":65,\"Attack\":50,\"Defense\":35,\"Sp. Attack\":115,\"Sp. Defense\":95,\"Speed\":95}},{\"id\":125,\"name\":{\"english\":\"Electabuzz\",\"japanese\":\"エレブー\",\"chinese\":\"电击兽\",\"french\":\"Élektek\"},\"type\":[\"Electric\"],\"base\":{\"HP\":65,\"Attack\":83,\"Defense\":57,\"Sp. Attack\":95,\"Sp. Defense\":85,\"Speed\":105}},{\"id\":126,\"name\":{\"english\":\"Magmar\",\"japanese\":\"ブーバー\",\"chinese\":\"鸭嘴火兽\",\"french\":\"Magmar\"},\"type\":[\"Fire\"],\"base\":{\"HP\":65,\"Attack\":95,\"Defense\":57,\"Sp. Attack\":100,\"Sp. Defense\":85,\"Speed\":93}},{\"id\":127,\"name\":{\"english\":\"Pinsir\",\"japanese\":\"カイロス\",\"chinese\":\"凯罗斯\",\"french\":\"Scarabrute\"},\"type\":[\"Bug\"],\"base\":{\"HP\":65,\"Attack\":125,\"Defense\":100,\"Sp. Attack\":55,\"Sp. Defense\":70,\"Speed\":85}},{\"id\":128,\"name\":{\"english\":\"Tauros\",\"japanese\":\"ケンタロス\",\"chinese\":\"肯泰罗\",\"french\":\"Tauros\"},\"type\":[\"Normal\"],\"base\":{\"HP\":75,\"Attack\":100,\"Defense\":95,\"Sp. Attack\":40,\"Sp. Defense\":70,\"Speed\":110}},{\"id\":129,\"name\":{\"english\":\"Magikarp\",\"japanese\":\"コイキング\",\"chinese\":\"鲤鱼王\",\"french\":\"Magicarpe\"},\"type\":[\"Water\"],\"base\":{\"HP\":20,\"Attack\":10,\"Defense\":55,\"Sp. Attack\":15,\"Sp. Defense\":20,\"Speed\":80}},{\"id\":130,\"name\":{\"english\":\"Gyarados\",\"japanese\":\"ギャラドス\",\"chinese\":\"暴鲤龙\",\"french\":\"Léviator\"},\"type\":[\"Water\",\"Flying\"],\"base\":{\"HP\":95,\"Attack\":125,\"Defense\":79,\"Sp. Attack\":60,\"Sp. Defense\":100,\"Speed\":81}},{\"id\":131,\"name\":{\"english\":\"Lapras\",\"japanese\":\"ラプラス\",\"chinese\":\"拉普拉斯\",\"french\":\"Lokhlass\"},\"type\":[\"Water\",\"Ice\"],\"base\":{\"HP\":130,\"Attack\":85,\"Defense\":80,\"Sp. Attack\":85,\"Sp. Defense\":95,\"Speed\":60}},{\"id\":132,\"name\":{\"english\":\"Ditto\",\"japanese\":\"メタモン\",\"chinese\":\"百变怪\",\"french\":\"Métamorph\"},\"type\":[\"Normal\"],\"base\":{\"HP\":48,\"Attack\":48,\"Defense\":48,\"Sp. Attack\":48,\"Sp. Defense\":48,\"Speed\":48}},{\"id\":133,\"name\":{\"english\":\"Eevee\",\"japanese\":\"イーブイ\",\"chinese\":\"伊布\",\"french\":\"Évoli\"},\"type\":[\"Normal\"],\"base\":{\"HP\":55,\"Attack\":55,\"Defense\":50,\"Sp. Attack\":45,\"Sp. Defense\":65,\"Speed\":55}},{\"id\":134,\"name\":{\"english\":\"Vaporeon\",\"japanese\":\"シャワーズ\",\"chinese\":\"水伊布\",\"french\":\"Aquali\"},\"type\":[\"Water\"],\"base\":{\"HP\":130,\"Attack\":65,\"Defense\":60,\"Sp. Attack\":110,\"Sp. Defense\":95,\"Speed\":65}},{\"id\":135,\"name\":{\"english\":\"Jolteon\",\"japanese\":\"サンダース\",\"chinese\":\"雷伊布\",\"french\":\"Voltali\"},\"type\":[\"Electric\"],\"base\":{\"HP\":65,\"Attack\":65,\"Defense\":60,\"Sp. Attack\":110,\"Sp. Defense\":95,\"Speed\":130}},{\"id\":136,\"name\":{\"english\":\"Flareon\",\"japanese\":\"ブースター\",\"chinese\":\"火伊布\",\"french\":\"Pyroli\"},\"type\":[\"Fire\"],\"base\":{\"HP\":65,\"Attack\":130,\"Defense\":60,\"Sp. Attack\":95,\"Sp. Defense\":110,\"Speed\":65}},{\"id\":137,\"name\":{\"english\":\"Porygon\",\"japanese\":\"ポリゴン\",\"chinese\":\"多边兽\",\"french\":\"Porygon\"},\"type\":[\"Normal\"],\"base\":{\"HP\":65,\"Attack\":60,\"Defense\":70,\"Sp. Attack\":85,\"Sp. Defense\":75,\"Speed\":40}},{\"id\":138,\"name\":{\"english\":\"Omanyte\",\"japanese\":\"オムナイト\",\"chinese\":\"菊石兽\",\"french\":\"Amonita\"},\"type\":[\"Rock\",\"Water\"],\"base\":{\"HP\":35,\"Attack\":40,\"Defense\":100,\"Sp. Attack\":90,\"Sp. Defense\":55,\"Speed\":35}},{\"id\":139,\"name\":{\"english\":\"Omastar\",\"japanese\":\"オムスター\",\"chinese\":\"多刺菊石兽\",\"french\":\"Amonistar\"},\"type\":[\"Rock\",\"Water\"],\"base\":{\"HP\":70,\"Attack\":60,\"Defense\":125,\"Sp. Attack\":115,\"Sp. Defense\":70,\"Speed\":55}},{\"id\":140,\"name\":{\"english\":\"Kabuto\",\"japanese\":\"カブト\",\"chinese\":\"化石盔\",\"french\":\"Kabuto\"},\"type\":[\"Rock\",\"Water\"],\"base\":{\"HP\":30,\"Attack\":80,\"Defense\":90,\"Sp. Attack\":55,\"Sp. Defense\":45,\"Speed\":55}},{\"id\":141,\"name\":{\"english\":\"Kabutops\",\"japanese\":\"カブトプス\",\"chinese\":\"镰刀盔\",\"french\":\"Kabutops\"},\"type\":[\"Rock\",\"Water\"],\"base\":{\"HP\":60,\"Attack\":115,\"Defense\":105,\"Sp. Attack\":65,\"Sp. Defense\":70,\"Speed\":80}},{\"id\":142,\"name\":{\"english\":\"Aerodactyl\",\"japanese\":\"プテラ\",\"chinese\":\"化石翼龙\",\"french\":\"Ptéra\"},\"type\":[\"Rock\",\"Flying\"],\"base\":{\"HP\":80,\"Attack\":105,\"Defense\":65,\"Sp. Attack\":60,\"Sp. Defense\":75,\"Speed\":130}},{\"id\":143,\"name\":{\"english\":\"Snorlax\",\"japanese\":\"カビゴン\",\"chinese\":\"卡比兽\",\"french\":\"Ronflex\"},\"type\":[\"Normal\"],\"base\":{\"HP\":160,\"Attack\":110,\"Defense\":65,\"Sp. Attack\":65,\"Sp. Defense\":110,\"Speed\":30}},{\"id\":144,\"name\":{\"english\":\"Articuno\",\"japanese\":\"フリーザー\",\"chinese\":\"急冻鸟\",\"french\":\"Artikodin\"},\"type\":[\"Ice\",\"Flying\"],\"base\":{\"HP\":90,\"Attack\":85,\"Defense\":100,\"Sp. Attack\":95,\"Sp. Defense\":125,\"Speed\":85}},{\"id\":145,\"name\":{\"english\":\"Zapdos\",\"japanese\":\"サンダー\",\"chinese\":\"闪电鸟\",\"french\":\"Électhor\"},\"type\":[\"Electric\",\"Flying\"],\"base\":{\"HP\":90,\"Attack\":90,\"Defense\":85,\"Sp. Attack\":125,\"Sp. Defense\":90,\"Speed\":100}},{\"id\":146,\"name\":{\"english\":\"Moltres\",\"japanese\":\"ファイヤー\",\"chinese\":\"火焰鸟\",\"french\":\"Sulfura\"},\"type\":[\"Fire\",\"Flying\"],\"base\":{\"HP\":90,\"Attack\":100,\"Defense\":90,\"Sp. Attack\":125,\"Sp. Defense\":85,\"Speed\":90}},{\"id\":147,\"name\":{\"english\":\"Dratini\",\"japanese\":\"ミニリュウ\",\"chinese\":\"迷你龙\",\"french\":\"Minidraco\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":41,\"Attack\":64,\"Defense\":45,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":50}},{\"id\":148,\"name\":{\"english\":\"Dragonair\",\"japanese\":\"ハクリュー\",\"chinese\":\"哈克龙\",\"french\":\"Draco\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":61,\"Attack\":84,\"Defense\":65,\"Sp. Attack\":70,\"Sp. Defense\":70,\"Speed\":70}},{\"id\":149,\"name\":{\"english\":\"Dragonite\",\"japanese\":\"カイリュー\",\"chinese\":\"快龙\",\"french\":\"Dracolosse\"},\"type\":[\"Dragon\",\"Flying\"],\"base\":{\"HP\":91,\"Attack\":134,\"Defense\":95,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":80}},{\"id\":150,\"name\":{\"english\":\"Mewtwo\",\"japanese\":\"ミュウツー\",\"chinese\":\"超梦\",\"french\":\"Mewtwo\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":106,\"Attack\":110,\"Defense\":90,\"Sp. Attack\":154,\"Sp. Defense\":90,\"Speed\":130}},{\"id\":151,\"name\":{\"english\":\"Mew\",\"japanese\":\"ミュウ\",\"chinese\":\"梦幻\",\"french\":\"Mew\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":100,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":100}},{\"id\":152,\"name\":{\"english\":\"Chikorita\",\"japanese\":\"チコリータ\",\"chinese\":\"菊草叶\",\"french\":\"Germignon\"},\"type\":[\"Grass\"],\"base\":{\"HP\":45,\"Attack\":49,\"Defense\":65,\"Sp. Attack\":49,\"Sp. Defense\":65,\"Speed\":45}},{\"id\":153,\"name\":{\"english\":\"Bayleef\",\"japanese\":\"ベイリーフ\",\"chinese\":\"月桂叶\",\"french\":\"Macronium\"},\"type\":[\"Grass\"],\"base\":{\"HP\":60,\"Attack\":62,\"Defense\":80,\"Sp. Attack\":63,\"Sp. Defense\":80,\"Speed\":60}},{\"id\":154,\"name\":{\"english\":\"Meganium\",\"japanese\":\"メガニウム\",\"chinese\":\"大竺葵\",\"french\":\"Méganium\"},\"type\":[\"Grass\"],\"base\":{\"HP\":80,\"Attack\":82,\"Defense\":100,\"Sp. Attack\":83,\"Sp. Defense\":100,\"Speed\":80}},{\"id\":155,\"name\":{\"english\":\"Cyndaquil\",\"japanese\":\"ヒノアラシ\",\"chinese\":\"火球鼠\",\"french\":\"Héricendre\"},\"type\":[\"Fire\"],\"base\":{\"HP\":39,\"Attack\":52,\"Defense\":43,\"Sp. Attack\":60,\"Sp. Defense\":50,\"Speed\":65}},{\"id\":156,\"name\":{\"english\":\"Quilava\",\"japanese\":\"マグマラシ\",\"chinese\":\"火岩鼠\",\"french\":\"Feurisson\"},\"type\":[\"Fire\"],\"base\":{\"HP\":58,\"Attack\":64,\"Defense\":58,\"Sp. Attack\":80,\"Sp. Defense\":65,\"Speed\":80}},{\"id\":157,\"name\":{\"english\":\"Typhlosion\",\"japanese\":\"バクフーン\",\"chinese\":\"火暴兽\",\"french\":\"Typhlosion\"},\"type\":[\"Fire\"],\"base\":{\"HP\":78,\"Attack\":84,\"Defense\":78,\"Sp. Attack\":109,\"Sp. Defense\":85,\"Speed\":100}},{\"id\":158,\"name\":{\"english\":\"Totodile\",\"japanese\":\"ワニノコ\",\"chinese\":\"小锯鳄\",\"french\":\"Kaiminus\"},\"type\":[\"Water\"],\"base\":{\"HP\":50,\"Attack\":65,\"Defense\":64,\"Sp. Attack\":44,\"Sp. Defense\":48,\"Speed\":43}},{\"id\":159,\"name\":{\"english\":\"Croconaw\",\"japanese\":\"アリゲイツ\",\"chinese\":\"蓝鳄\",\"french\":\"Crocrodil\"},\"type\":[\"Water\"],\"base\":{\"HP\":65,\"Attack\":80,\"Defense\":80,\"Sp. Attack\":59,\"Sp. Defense\":63,\"Speed\":58}},{\"id\":160,\"name\":{\"english\":\"Feraligatr\",\"japanese\":\"オーダイル\",\"chinese\":\"大力鳄\",\"french\":\"Aligatueur\"},\"type\":[\"Water\"],\"base\":{\"HP\":85,\"Attack\":105,\"Defense\":100,\"Sp. Attack\":79,\"Sp. Defense\":83,\"Speed\":78}},{\"id\":161,\"name\":{\"english\":\"Sentret\",\"japanese\":\"オタチ\",\"chinese\":\"尾立\",\"french\":\"Fouinette\"},\"type\":[\"Normal\"],\"base\":{\"HP\":35,\"Attack\":46,\"Defense\":34,\"Sp. Attack\":35,\"Sp. Defense\":45,\"Speed\":20}},{\"id\":162,\"name\":{\"english\":\"Furret\",\"japanese\":\"オオタチ\",\"chinese\":\"大尾立\",\"french\":\"Fouinar\"},\"type\":[\"Normal\"],\"base\":{\"HP\":85,\"Attack\":76,\"Defense\":64,\"Sp. Attack\":45,\"Sp. Defense\":55,\"Speed\":90}},{\"id\":163,\"name\":{\"english\":\"Hoothoot\",\"japanese\":\"ホーホー\",\"chinese\":\"咕咕\",\"french\":\"Hoothoot\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":60,\"Attack\":30,\"Defense\":30,\"Sp. Attack\":36,\"Sp. Defense\":56,\"Speed\":50}},{\"id\":164,\"name\":{\"english\":\"Noctowl\",\"japanese\":\"ヨルノズク\",\"chinese\":\"猫头夜鹰\",\"french\":\"Noarfang\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":100,\"Attack\":50,\"Defense\":50,\"Sp. Attack\":86,\"Sp. Defense\":96,\"Speed\":70}},{\"id\":165,\"name\":{\"english\":\"Ledyba\",\"japanese\":\"レディバ\",\"chinese\":\"芭瓢虫\",\"french\":\"Coxy\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":40,\"Attack\":20,\"Defense\":30,\"Sp. Attack\":40,\"Sp. Defense\":80,\"Speed\":55}},{\"id\":166,\"name\":{\"english\":\"Ledian\",\"japanese\":\"レディアン\",\"chinese\":\"安瓢虫\",\"french\":\"Coxyclaque\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":55,\"Attack\":35,\"Defense\":50,\"Sp. Attack\":55,\"Sp. Defense\":110,\"Speed\":85}},{\"id\":167,\"name\":{\"english\":\"Spinarak\",\"japanese\":\"イトマル\",\"chinese\":\"圆丝蛛\",\"french\":\"Mimigal\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":40,\"Attack\":60,\"Defense\":40,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":30}},{\"id\":168,\"name\":{\"english\":\"Ariados\",\"japanese\":\"アリアドス\",\"chinese\":\"阿利多斯\",\"french\":\"Migalos\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":70,\"Attack\":90,\"Defense\":70,\"Sp. Attack\":60,\"Sp. Defense\":70,\"Speed\":40}},{\"id\":169,\"name\":{\"english\":\"Crobat\",\"japanese\":\"クロバット\",\"chinese\":\"叉字蝠\",\"french\":\"Nostenfer\"},\"type\":[\"Poison\",\"Flying\"],\"base\":{\"HP\":85,\"Attack\":90,\"Defense\":80,\"Sp. Attack\":70,\"Sp. Defense\":80,\"Speed\":130}},{\"id\":170,\"name\":{\"english\":\"Chinchou\",\"japanese\":\"チョンチー\",\"chinese\":\"灯笼鱼\",\"french\":\"Loupio\"},\"type\":[\"Water\",\"Electric\"],\"base\":{\"HP\":75,\"Attack\":38,\"Defense\":38,\"Sp. Attack\":56,\"Sp. Defense\":56,\"Speed\":67}},{\"id\":171,\"name\":{\"english\":\"Lanturn\",\"japanese\":\"ランターン\",\"chinese\":\"电灯怪\",\"french\":\"Lanturn\"},\"type\":[\"Water\",\"Electric\"],\"base\":{\"HP\":125,\"Attack\":58,\"Defense\":58,\"Sp. Attack\":76,\"Sp. Defense\":76,\"Speed\":67}},{\"id\":172,\"name\":{\"english\":\"Pichu\",\"japanese\":\"ピチュー\",\"chinese\":\"皮丘\",\"french\":\"Pichu\"},\"type\":[\"Electric\"],\"base\":{\"HP\":20,\"Attack\":40,\"Defense\":15,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":60}},{\"id\":173,\"name\":{\"english\":\"Cleffa\",\"japanese\":\"ピィ\",\"chinese\":\"皮宝宝\",\"french\":\"Mélo\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":50,\"Attack\":25,\"Defense\":28,\"Sp. Attack\":45,\"Sp. Defense\":55,\"Speed\":15}},{\"id\":174,\"name\":{\"english\":\"Igglybuff\",\"japanese\":\"ププリン\",\"chinese\":\"宝宝丁\",\"french\":\"Toudoudou\"},\"type\":[\"Normal\",\"Fairy\"],\"base\":{\"HP\":90,\"Attack\":30,\"Defense\":15,\"Sp. Attack\":40,\"Sp. Defense\":20,\"Speed\":15}},{\"id\":175,\"name\":{\"english\":\"Togepi\",\"japanese\":\"トゲピー\",\"chinese\":\"波克比\",\"french\":\"Togepi\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":35,\"Attack\":20,\"Defense\":65,\"Sp. Attack\":40,\"Sp. Defense\":65,\"Speed\":20}},{\"id\":176,\"name\":{\"english\":\"Togetic\",\"japanese\":\"トゲチック\",\"chinese\":\"波克基古\",\"french\":\"Togetic\"},\"type\":[\"Fairy\",\"Flying\"],\"base\":{\"HP\":55,\"Attack\":40,\"Defense\":85,\"Sp. Attack\":80,\"Sp. Defense\":105,\"Speed\":40}},{\"id\":177,\"name\":{\"english\":\"Natu\",\"japanese\":\"ネイティ\",\"chinese\":\"天然雀\",\"french\":\"Natu\"},\"type\":[\"Psychic\",\"Flying\"],\"base\":{\"HP\":40,\"Attack\":50,\"Defense\":45,\"Sp. Attack\":70,\"Sp. Defense\":45,\"Speed\":70}},{\"id\":178,\"name\":{\"english\":\"Xatu\",\"japanese\":\"ネイティオ\",\"chinese\":\"天然鸟\",\"french\":\"Xatu\"},\"type\":[\"Psychic\",\"Flying\"],\"base\":{\"HP\":65,\"Attack\":75,\"Defense\":70,\"Sp. Attack\":95,\"Sp. Defense\":70,\"Speed\":95}},{\"id\":179,\"name\":{\"english\":\"Mareep\",\"japanese\":\"メリープ\",\"chinese\":\"咩利羊\",\"french\":\"Wattouat\"},\"type\":[\"Electric\"],\"base\":{\"HP\":55,\"Attack\":40,\"Defense\":40,\"Sp. Attack\":65,\"Sp. Defense\":45,\"Speed\":35}},{\"id\":180,\"name\":{\"english\":\"Flaaffy\",\"japanese\":\"モココ\",\"chinese\":\"茸茸羊\",\"french\":\"Lainergie\"},\"type\":[\"Electric\"],\"base\":{\"HP\":70,\"Attack\":55,\"Defense\":55,\"Sp. Attack\":80,\"Sp. Defense\":60,\"Speed\":45}},{\"id\":181,\"name\":{\"english\":\"Ampharos\",\"japanese\":\"デンリュウ\",\"chinese\":\"电龙\",\"french\":\"Pharamp\"},\"type\":[\"Electric\"],\"base\":{\"HP\":90,\"Attack\":75,\"Defense\":85,\"Sp. Attack\":115,\"Sp. Defense\":90,\"Speed\":55}},{\"id\":182,\"name\":{\"english\":\"Bellossom\",\"japanese\":\"キレイハナ\",\"chinese\":\"美丽花\",\"french\":\"Joliflor\"},\"type\":[\"Grass\"],\"base\":{\"HP\":75,\"Attack\":80,\"Defense\":95,\"Sp. Attack\":90,\"Sp. Defense\":100,\"Speed\":50}},{\"id\":183,\"name\":{\"english\":\"Marill\",\"japanese\":\"マリル\",\"chinese\":\"玛力露\",\"french\":\"Marill\"},\"type\":[\"Water\",\"Fairy\"],\"base\":{\"HP\":70,\"Attack\":20,\"Defense\":50,\"Sp. Attack\":20,\"Sp. Defense\":50,\"Speed\":40}},{\"id\":184,\"name\":{\"english\":\"Azumarill\",\"japanese\":\"マリルリ\",\"chinese\":\"玛力露丽\",\"french\":\"Azumarill\"},\"type\":[\"Water\",\"Fairy\"],\"base\":{\"HP\":100,\"Attack\":50,\"Defense\":80,\"Sp. Attack\":60,\"Sp. Defense\":80,\"Speed\":50}},{\"id\":185,\"name\":{\"english\":\"Sudowoodo\",\"japanese\":\"ウソッキー\",\"chinese\":\"树才怪‎\",\"french\":\"Simularbre\"},\"type\":[\"Rock\"],\"base\":{\"HP\":70,\"Attack\":100,\"Defense\":115,\"Sp. Attack\":30,\"Sp. Defense\":65,\"Speed\":30}},{\"id\":186,\"name\":{\"english\":\"Politoed\",\"japanese\":\"ニョロトノ\",\"chinese\":\"蚊香蛙皇\",\"french\":\"Tarpaud\"},\"type\":[\"Water\"],\"base\":{\"HP\":90,\"Attack\":75,\"Defense\":75,\"Sp. Attack\":90,\"Sp. Defense\":100,\"Speed\":70}},{\"id\":187,\"name\":{\"english\":\"Hoppip\",\"japanese\":\"ハネッコ\",\"chinese\":\"毽子草\",\"french\":\"Granivol\"},\"type\":[\"Grass\",\"Flying\"],\"base\":{\"HP\":35,\"Attack\":35,\"Defense\":40,\"Sp. Attack\":35,\"Sp. Defense\":55,\"Speed\":50}},{\"id\":188,\"name\":{\"english\":\"Skiploom\",\"japanese\":\"ポポッコ\",\"chinese\":\"毽子花\",\"french\":\"Floravol\"},\"type\":[\"Grass\",\"Flying\"],\"base\":{\"HP\":55,\"Attack\":45,\"Defense\":50,\"Sp. Attack\":45,\"Sp. Defense\":65,\"Speed\":80}},{\"id\":189,\"name\":{\"english\":\"Jumpluff\",\"japanese\":\"ワタッコ\",\"chinese\":\"毽子棉\",\"french\":\"Cotovol\"},\"type\":[\"Grass\",\"Flying\"],\"base\":{\"HP\":75,\"Attack\":55,\"Defense\":70,\"Sp. Attack\":55,\"Sp. Defense\":95,\"Speed\":110}},{\"id\":190,\"name\":{\"english\":\"Aipom\",\"japanese\":\"エイパム\",\"chinese\":\"长尾怪手\",\"french\":\"Capumain\"},\"type\":[\"Normal\"],\"base\":{\"HP\":55,\"Attack\":70,\"Defense\":55,\"Sp. Attack\":40,\"Sp. Defense\":55,\"Speed\":85}},{\"id\":191,\"name\":{\"english\":\"Sunkern\",\"japanese\":\"ヒマナッツ\",\"chinese\":\"向日种子\",\"french\":\"Tournegrin\"},\"type\":[\"Grass\"],\"base\":{\"HP\":30,\"Attack\":30,\"Defense\":30,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":30}},{\"id\":192,\"name\":{\"english\":\"Sunflora\",\"japanese\":\"キマワリ\",\"chinese\":\"向日花怪\",\"french\":\"Héliatronc\"},\"type\":[\"Grass\"],\"base\":{\"HP\":75,\"Attack\":75,\"Defense\":55,\"Sp. Attack\":105,\"Sp. Defense\":85,\"Speed\":30}},{\"id\":193,\"name\":{\"english\":\"Yanma\",\"japanese\":\"ヤンヤンマ\",\"chinese\":\"蜻蜻蜓\",\"french\":\"Yanma\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":65,\"Attack\":65,\"Defense\":45,\"Sp. Attack\":75,\"Sp. Defense\":45,\"Speed\":95}},{\"id\":194,\"name\":{\"english\":\"Wooper\",\"japanese\":\"ウパー\",\"chinese\":\"乌波\",\"french\":\"Axoloto\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":55,\"Attack\":45,\"Defense\":45,\"Sp. Attack\":25,\"Sp. Defense\":25,\"Speed\":15}},{\"id\":195,\"name\":{\"english\":\"Quagsire\",\"japanese\":\"ヌオー\",\"chinese\":\"沼王\",\"french\":\"Maraiste\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":95,\"Attack\":85,\"Defense\":85,\"Sp. Attack\":65,\"Sp. Defense\":65,\"Speed\":35}},{\"id\":196,\"name\":{\"english\":\"Espeon\",\"japanese\":\"エーフィ\",\"chinese\":\"太阳伊布\",\"french\":\"Mentali\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":65,\"Attack\":65,\"Defense\":60,\"Sp. Attack\":130,\"Sp. Defense\":95,\"Speed\":110}},{\"id\":197,\"name\":{\"english\":\"Umbreon\",\"japanese\":\"ブラッキー\",\"chinese\":\"月亮伊布\",\"french\":\"Noctali\"},\"type\":[\"Dark\"],\"base\":{\"HP\":95,\"Attack\":65,\"Defense\":110,\"Sp. Attack\":60,\"Sp. Defense\":130,\"Speed\":65}},{\"id\":198,\"name\":{\"english\":\"Murkrow\",\"japanese\":\"ヤミカラス\",\"chinese\":\"黑暗鸦\",\"french\":\"Cornèbre\"},\"type\":[\"Dark\",\"Flying\"],\"base\":{\"HP\":60,\"Attack\":85,\"Defense\":42,\"Sp. Attack\":85,\"Sp. Defense\":42,\"Speed\":91}},{\"id\":199,\"name\":{\"english\":\"Slowking\",\"japanese\":\"ヤドキング\",\"chinese\":\"呆呆王\",\"french\":\"Roigada\"},\"type\":[\"Water\",\"Psychic\"],\"base\":{\"HP\":95,\"Attack\":75,\"Defense\":80,\"Sp. Attack\":100,\"Sp. Defense\":110,\"Speed\":30}},{\"id\":200,\"name\":{\"english\":\"Misdreavus\",\"japanese\":\"ムウマ\",\"chinese\":\"梦妖\",\"french\":\"Feuforêve\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":60,\"Sp. Attack\":85,\"Sp. Defense\":85,\"Speed\":85}},{\"id\":201,\"name\":{\"english\":\"Unown\",\"japanese\":\"アンノーン\",\"chinese\":\"未知图腾\",\"french\":\"Zarbi\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":48,\"Attack\":72,\"Defense\":48,\"Sp. Attack\":72,\"Sp. Defense\":48,\"Speed\":48}},{\"id\":202,\"name\":{\"english\":\"Wobbuffet\",\"japanese\":\"ソーナンス\",\"chinese\":\"果然翁\",\"french\":\"Qulbutoké\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":190,\"Attack\":33,\"Defense\":58,\"Sp. Attack\":33,\"Sp. Defense\":58,\"Speed\":33}},{\"id\":203,\"name\":{\"english\":\"Girafarig\",\"japanese\":\"キリンリキ\",\"chinese\":\"麒麟奇\",\"french\":\"Girafarig\"},\"type\":[\"Normal\",\"Psychic\"],\"base\":{\"HP\":70,\"Attack\":80,\"Defense\":65,\"Sp. Attack\":90,\"Sp. Defense\":65,\"Speed\":85}},{\"id\":204,\"name\":{\"english\":\"Pineco\",\"japanese\":\"クヌギダマ\",\"chinese\":\"榛果球\",\"french\":\"Pomdepik\"},\"type\":[\"Bug\"],\"base\":{\"HP\":50,\"Attack\":65,\"Defense\":90,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":15}},{\"id\":205,\"name\":{\"english\":\"Forretress\",\"japanese\":\"フォレトス\",\"chinese\":\"佛烈托斯\",\"french\":\"Foretress\"},\"type\":[\"Bug\",\"Steel\"],\"base\":{\"HP\":75,\"Attack\":90,\"Defense\":140,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":40}},{\"id\":206,\"name\":{\"english\":\"Dunsparce\",\"japanese\":\"ノコッチ\",\"chinese\":\"土龙弟弟\",\"french\":\"Insolourdo\"},\"type\":[\"Normal\"],\"base\":{\"HP\":100,\"Attack\":70,\"Defense\":70,\"Sp. Attack\":65,\"Sp. Defense\":65,\"Speed\":45}},{\"id\":207,\"name\":{\"english\":\"Gligar\",\"japanese\":\"グライガー\",\"chinese\":\"天蝎\",\"french\":\"Scorplane\"},\"type\":[\"Ground\",\"Flying\"],\"base\":{\"HP\":65,\"Attack\":75,\"Defense\":105,\"Sp. Attack\":35,\"Sp. Defense\":65,\"Speed\":85}},{\"id\":208,\"name\":{\"english\":\"Steelix\",\"japanese\":\"ハガネール\",\"chinese\":\"大钢蛇\",\"french\":\"Steelix\"},\"type\":[\"Steel\",\"Ground\"],\"base\":{\"HP\":75,\"Attack\":85,\"Defense\":200,\"Sp. Attack\":55,\"Sp. Defense\":65,\"Speed\":30}},{\"id\":209,\"name\":{\"english\":\"Snubbull\",\"japanese\":\"ブルー\",\"chinese\":\"布鲁\",\"french\":\"Snubbull\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":60,\"Attack\":80,\"Defense\":50,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":30}},{\"id\":210,\"name\":{\"english\":\"Granbull\",\"japanese\":\"グランブル\",\"chinese\":\"布鲁皇\",\"french\":\"Granbull\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":90,\"Attack\":120,\"Defense\":75,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":45}},{\"id\":211,\"name\":{\"english\":\"Qwilfish\",\"japanese\":\"ハリーセン\",\"chinese\":\"千针鱼\",\"french\":\"Qwilfish\"},\"type\":[\"Water\",\"Poison\"],\"base\":{\"HP\":65,\"Attack\":95,\"Defense\":85,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":85}},{\"id\":212,\"name\":{\"english\":\"Scizor\",\"japanese\":\"ハッサム\",\"chinese\":\"巨钳螳螂\",\"french\":\"Cizayox\"},\"type\":[\"Bug\",\"Steel\"],\"base\":{\"HP\":70,\"Attack\":130,\"Defense\":100,\"Sp. Attack\":55,\"Sp. Defense\":80,\"Speed\":65}},{\"id\":213,\"name\":{\"english\":\"Shuckle\",\"japanese\":\"ツボツボ\",\"chinese\":\"壶壶\",\"french\":\"Caratroc\"},\"type\":[\"Bug\",\"Rock\"],\"base\":{\"HP\":20,\"Attack\":10,\"Defense\":230,\"Sp. Attack\":10,\"Sp. Defense\":230,\"Speed\":5}},{\"id\":214,\"name\":{\"english\":\"Heracross\",\"japanese\":\"ヘラクロス\",\"chinese\":\"赫拉克罗斯\",\"french\":\"Scarhino\"},\"type\":[\"Bug\",\"Fighting\"],\"base\":{\"HP\":80,\"Attack\":125,\"Defense\":75,\"Sp. Attack\":40,\"Sp. Defense\":95,\"Speed\":85}},{\"id\":215,\"name\":{\"english\":\"Sneasel\",\"japanese\":\"ニューラ\",\"chinese\":\"狃拉\",\"french\":\"Farfuret\"},\"type\":[\"Dark\",\"Ice\"],\"base\":{\"HP\":55,\"Attack\":95,\"Defense\":55,\"Sp. Attack\":35,\"Sp. Defense\":75,\"Speed\":115}},{\"id\":216,\"name\":{\"english\":\"Teddiursa\",\"japanese\":\"ヒメグマ\",\"chinese\":\"熊宝宝\",\"french\":\"Teddiursa\"},\"type\":[\"Normal\"],\"base\":{\"HP\":60,\"Attack\":80,\"Defense\":50,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":40}},{\"id\":217,\"name\":{\"english\":\"Ursaring\",\"japanese\":\"リングマ\",\"chinese\":\"圈圈熊\",\"french\":\"Ursaring\"},\"type\":[\"Normal\"],\"base\":{\"HP\":90,\"Attack\":130,\"Defense\":75,\"Sp. Attack\":75,\"Sp. Defense\":75,\"Speed\":55}},{\"id\":218,\"name\":{\"english\":\"Slugma\",\"japanese\":\"マグマッグ\",\"chinese\":\"熔岩虫\",\"french\":\"Limagma\"},\"type\":[\"Fire\"],\"base\":{\"HP\":40,\"Attack\":40,\"Defense\":40,\"Sp. Attack\":70,\"Sp. Defense\":40,\"Speed\":20}},{\"id\":219,\"name\":{\"english\":\"Magcargo\",\"japanese\":\"マグカルゴ\",\"chinese\":\"熔岩蜗牛\",\"french\":\"Volcaropod\"},\"type\":[\"Fire\",\"Rock\"],\"base\":{\"HP\":60,\"Attack\":50,\"Defense\":120,\"Sp. Attack\":90,\"Sp. Defense\":80,\"Speed\":30}},{\"id\":220,\"name\":{\"english\":\"Swinub\",\"japanese\":\"ウリムー\",\"chinese\":\"小山猪\",\"french\":\"Marcacrin\"},\"type\":[\"Ice\",\"Ground\"],\"base\":{\"HP\":50,\"Attack\":50,\"Defense\":40,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":50}},{\"id\":221,\"name\":{\"english\":\"Piloswine\",\"japanese\":\"イノムー\",\"chinese\":\"长毛猪\",\"french\":\"Cochignon\"},\"type\":[\"Ice\",\"Ground\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":80,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":50}},{\"id\":222,\"name\":{\"english\":\"Corsola\",\"japanese\":\"サニーゴ\",\"chinese\":\"太阳珊瑚\",\"french\":\"Corayon\"},\"type\":[\"Water\",\"Rock\"],\"base\":{\"HP\":65,\"Attack\":55,\"Defense\":95,\"Sp. Attack\":65,\"Sp. Defense\":95,\"Speed\":35}},{\"id\":223,\"name\":{\"english\":\"Remoraid\",\"japanese\":\"テッポウオ\",\"chinese\":\"铁炮鱼\",\"french\":\"Rémoraid\"},\"type\":[\"Water\"],\"base\":{\"HP\":35,\"Attack\":65,\"Defense\":35,\"Sp. Attack\":65,\"Sp. Defense\":35,\"Speed\":65}},{\"id\":224,\"name\":{\"english\":\"Octillery\",\"japanese\":\"オクタン\",\"chinese\":\"章鱼桶\",\"french\":\"Octillery\"},\"type\":[\"Water\"],\"base\":{\"HP\":75,\"Attack\":105,\"Defense\":75,\"Sp. Attack\":105,\"Sp. Defense\":75,\"Speed\":45}},{\"id\":225,\"name\":{\"english\":\"Delibird\",\"japanese\":\"デリバード\",\"chinese\":\"信使鸟\",\"french\":\"Cadoizo\"},\"type\":[\"Ice\",\"Flying\"],\"base\":{\"HP\":45,\"Attack\":55,\"Defense\":45,\"Sp. Attack\":65,\"Sp. Defense\":45,\"Speed\":75}},{\"id\":226,\"name\":{\"english\":\"Mantine\",\"japanese\":\"マンタイン\",\"chinese\":\"巨翅飞鱼\",\"french\":\"Démanta\"},\"type\":[\"Water\",\"Flying\"],\"base\":{\"HP\":85,\"Attack\":40,\"Defense\":70,\"Sp. Attack\":80,\"Sp. Defense\":140,\"Speed\":70}},{\"id\":227,\"name\":{\"english\":\"Skarmory\",\"japanese\":\"エアームド\",\"chinese\":\"盔甲鸟\",\"french\":\"Airmure\"},\"type\":[\"Steel\",\"Flying\"],\"base\":{\"HP\":65,\"Attack\":80,\"Defense\":140,\"Sp. Attack\":40,\"Sp. Defense\":70,\"Speed\":70}},{\"id\":228,\"name\":{\"english\":\"Houndour\",\"japanese\":\"デルビル\",\"chinese\":\"戴鲁比\",\"french\":\"Malosse\"},\"type\":[\"Dark\",\"Fire\"],\"base\":{\"HP\":45,\"Attack\":60,\"Defense\":30,\"Sp. Attack\":80,\"Sp. Defense\":50,\"Speed\":65}},{\"id\":229,\"name\":{\"english\":\"Houndoom\",\"japanese\":\"ヘルガー\",\"chinese\":\"黑鲁加\",\"french\":\"Démolosse\"},\"type\":[\"Dark\",\"Fire\"],\"base\":{\"HP\":75,\"Attack\":90,\"Defense\":50,\"Sp. Attack\":110,\"Sp. Defense\":80,\"Speed\":95}},{\"id\":230,\"name\":{\"english\":\"Kingdra\",\"japanese\":\"キングドラ\",\"chinese\":\"刺龙王\",\"french\":\"Hyporoi\"},\"type\":[\"Water\",\"Dragon\"],\"base\":{\"HP\":75,\"Attack\":95,\"Defense\":95,\"Sp. Attack\":95,\"Sp. Defense\":95,\"Speed\":85}},{\"id\":231,\"name\":{\"english\":\"Phanpy\",\"japanese\":\"ゴマゾウ\",\"chinese\":\"小小象\",\"french\":\"Phanpy\"},\"type\":[\"Ground\"],\"base\":{\"HP\":90,\"Attack\":60,\"Defense\":60,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":40}},{\"id\":232,\"name\":{\"english\":\"Donphan\",\"japanese\":\"ドンファン\",\"chinese\":\"顿甲\",\"french\":\"Donphan\"},\"type\":[\"Ground\"],\"base\":{\"HP\":90,\"Attack\":120,\"Defense\":120,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":50}},{\"id\":233,\"name\":{\"english\":\"Porygon2\",\"japanese\":\"ポリゴン２\",\"chinese\":\"多边兽Ⅱ\",\"french\":\"Porygon2\"},\"type\":[\"Normal\"],\"base\":{\"HP\":85,\"Attack\":80,\"Defense\":90,\"Sp. Attack\":105,\"Sp. Defense\":95,\"Speed\":60}},{\"id\":234,\"name\":{\"english\":\"Stantler\",\"japanese\":\"オドシシ\",\"chinese\":\"惊角鹿\",\"french\":\"Cerfrousse\"},\"type\":[\"Normal\"],\"base\":{\"HP\":73,\"Attack\":95,\"Defense\":62,\"Sp. Attack\":85,\"Sp. Defense\":65,\"Speed\":85}},{\"id\":235,\"name\":{\"english\":\"Smeargle\",\"japanese\":\"ドーブル\",\"chinese\":\"图图犬\",\"french\":\"Queulorior\"},\"type\":[\"Normal\"],\"base\":{\"HP\":55,\"Attack\":20,\"Defense\":35,\"Sp. Attack\":20,\"Sp. Defense\":45,\"Speed\":75}},{\"id\":236,\"name\":{\"english\":\"Tyrogue\",\"japanese\":\"バルキー\",\"chinese\":\"无畏小子\",\"french\":\"Debugant\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":35,\"Attack\":35,\"Defense\":35,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":35}},{\"id\":237,\"name\":{\"english\":\"Hitmontop\",\"japanese\":\"カポエラー\",\"chinese\":\"战舞郎\",\"french\":\"Kapoera\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":50,\"Attack\":95,\"Defense\":95,\"Sp. Attack\":35,\"Sp. Defense\":110,\"Speed\":70}},{\"id\":238,\"name\":{\"english\":\"Smoochum\",\"japanese\":\"ムチュール\",\"chinese\":\"迷唇娃\",\"french\":\"Lippouti\"},\"type\":[\"Ice\",\"Psychic\"],\"base\":{\"HP\":45,\"Attack\":30,\"Defense\":15,\"Sp. Attack\":85,\"Sp. Defense\":65,\"Speed\":65}},{\"id\":239,\"name\":{\"english\":\"Elekid\",\"japanese\":\"エレキッド\",\"chinese\":\"电击怪\",\"french\":\"Élekid\"},\"type\":[\"Electric\"],\"base\":{\"HP\":45,\"Attack\":63,\"Defense\":37,\"Sp. Attack\":65,\"Sp. Defense\":55,\"Speed\":95}},{\"id\":240,\"name\":{\"english\":\"Magby\",\"japanese\":\"ブビィ\",\"chinese\":\"鸭嘴宝宝\",\"french\":\"Magby\"},\"type\":[\"Fire\"],\"base\":{\"HP\":45,\"Attack\":75,\"Defense\":37,\"Sp. Attack\":70,\"Sp. Defense\":55,\"Speed\":83}},{\"id\":241,\"name\":{\"english\":\"Miltank\",\"japanese\":\"ミルタンク\",\"chinese\":\"大奶罐\",\"french\":\"Écrémeuh\"},\"type\":[\"Normal\"],\"base\":{\"HP\":95,\"Attack\":80,\"Defense\":105,\"Sp. Attack\":40,\"Sp. Defense\":70,\"Speed\":100}},{\"id\":242,\"name\":{\"english\":\"Blissey\",\"japanese\":\"ハピナス\",\"chinese\":\"幸福蛋\",\"french\":\"Leuphorie\"},\"type\":[\"Normal\"],\"base\":{\"HP\":255,\"Attack\":10,\"Defense\":10,\"Sp. Attack\":75,\"Sp. Defense\":135,\"Speed\":55}},{\"id\":243,\"name\":{\"english\":\"Raikou\",\"japanese\":\"ライコウ\",\"chinese\":\"雷公\",\"french\":\"Raikou\"},\"type\":[\"Electric\"],\"base\":{\"HP\":90,\"Attack\":85,\"Defense\":75,\"Sp. Attack\":115,\"Sp. Defense\":100,\"Speed\":115}},{\"id\":244,\"name\":{\"english\":\"Entei\",\"japanese\":\"エンテイ\",\"chinese\":\"炎帝\",\"french\":\"Entei\"},\"type\":[\"Fire\"],\"base\":{\"HP\":115,\"Attack\":115,\"Defense\":85,\"Sp. Attack\":90,\"Sp. Defense\":75,\"Speed\":100}},{\"id\":245,\"name\":{\"english\":\"Suicune\",\"japanese\":\"スイクン\",\"chinese\":\"水君\",\"french\":\"Suicune\"},\"type\":[\"Water\"],\"base\":{\"HP\":100,\"Attack\":75,\"Defense\":115,\"Sp. Attack\":90,\"Sp. Defense\":115,\"Speed\":85}},{\"id\":246,\"name\":{\"english\":\"Larvitar\",\"japanese\":\"ヨーギラス\",\"chinese\":\"幼基拉斯\",\"french\":\"Embrylex\"},\"type\":[\"Rock\",\"Ground\"],\"base\":{\"HP\":50,\"Attack\":64,\"Defense\":50,\"Sp. Attack\":45,\"Sp. Defense\":50,\"Speed\":41}},{\"id\":247,\"name\":{\"english\":\"Pupitar\",\"japanese\":\"サナギラス\",\"chinese\":\"沙基拉斯\",\"french\":\"Ymphect\"},\"type\":[\"Rock\",\"Ground\"],\"base\":{\"HP\":70,\"Attack\":84,\"Defense\":70,\"Sp. Attack\":65,\"Sp. Defense\":70,\"Speed\":51}},{\"id\":248,\"name\":{\"english\":\"Tyranitar\",\"japanese\":\"バンギラス\",\"chinese\":\"班基拉斯\",\"french\":\"Tyranocif\"},\"type\":[\"Rock\",\"Dark\"],\"base\":{\"HP\":100,\"Attack\":134,\"Defense\":110,\"Sp. Attack\":95,\"Sp. Defense\":100,\"Speed\":61}},{\"id\":249,\"name\":{\"english\":\"Lugia\",\"japanese\":\"ルギア\",\"chinese\":\"洛奇亚\",\"french\":\"Lugia\"},\"type\":[\"Psychic\",\"Flying\"],\"base\":{\"HP\":106,\"Attack\":90,\"Defense\":130,\"Sp. Attack\":90,\"Sp. Defense\":154,\"Speed\":110}},{\"id\":250,\"name\":{\"english\":\"Ho-Oh\",\"japanese\":\"ホウオウ\",\"chinese\":\"凤王\",\"french\":\"Ho-Oh\"},\"type\":[\"Fire\",\"Flying\"],\"base\":{\"HP\":106,\"Attack\":130,\"Defense\":90,\"Sp. Attack\":110,\"Sp. Defense\":154,\"Speed\":90}},{\"id\":251,\"name\":{\"english\":\"Celebi\",\"japanese\":\"セレビィ\",\"chinese\":\"时拉比\",\"french\":\"Celebi\"},\"type\":[\"Psychic\",\"Grass\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":100,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":100}},{\"id\":252,\"name\":{\"english\":\"Treecko\",\"japanese\":\"キモリ\",\"chinese\":\"木守宫\",\"french\":\"Arcko\"},\"type\":[\"Grass\"],\"base\":{\"HP\":40,\"Attack\":45,\"Defense\":35,\"Sp. Attack\":65,\"Sp. Defense\":55,\"Speed\":70}},{\"id\":253,\"name\":{\"english\":\"Grovyle\",\"japanese\":\"ジュプトル\",\"chinese\":\"森林蜥蜴\",\"french\":\"Massko\"},\"type\":[\"Grass\"],\"base\":{\"HP\":50,\"Attack\":65,\"Defense\":45,\"Sp. Attack\":85,\"Sp. Defense\":65,\"Speed\":95}},{\"id\":254,\"name\":{\"english\":\"Sceptile\",\"japanese\":\"ジュカイン\",\"chinese\":\"蜥蜴王\",\"french\":\"Jungko\"},\"type\":[\"Grass\"],\"base\":{\"HP\":70,\"Attack\":85,\"Defense\":65,\"Sp. Attack\":105,\"Sp. Defense\":85,\"Speed\":120}},{\"id\":255,\"name\":{\"english\":\"Torchic\",\"japanese\":\"アチャモ\",\"chinese\":\"火稚鸡\",\"french\":\"Poussifeu\"},\"type\":[\"Fire\"],\"base\":{\"HP\":45,\"Attack\":60,\"Defense\":40,\"Sp. Attack\":70,\"Sp. Defense\":50,\"Speed\":45}},{\"id\":256,\"name\":{\"english\":\"Combusken\",\"japanese\":\"ワカシャモ\",\"chinese\":\"力壮鸡\",\"french\":\"Galifeu\"},\"type\":[\"Fire\",\"Fighting\"],\"base\":{\"HP\":60,\"Attack\":85,\"Defense\":60,\"Sp. Attack\":85,\"Sp. Defense\":60,\"Speed\":55}},{\"id\":257,\"name\":{\"english\":\"Blaziken\",\"japanese\":\"バシャーモ\",\"chinese\":\"火焰鸡\",\"french\":\"Braségali\"},\"type\":[\"Fire\",\"Fighting\"],\"base\":{\"HP\":80,\"Attack\":120,\"Defense\":70,\"Sp. Attack\":110,\"Sp. Defense\":70,\"Speed\":80}},{\"id\":258,\"name\":{\"english\":\"Mudkip\",\"japanese\":\"ミズゴロウ\",\"chinese\":\"水跃鱼\",\"french\":\"Gobou\"},\"type\":[\"Water\"],\"base\":{\"HP\":50,\"Attack\":70,\"Defense\":50,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":40}},{\"id\":259,\"name\":{\"english\":\"Marshtomp\",\"japanese\":\"ヌマクロー\",\"chinese\":\"沼跃鱼\",\"french\":\"Flobio\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":70,\"Attack\":85,\"Defense\":70,\"Sp. Attack\":60,\"Sp. Defense\":70,\"Speed\":50}},{\"id\":260,\"name\":{\"english\":\"Swampert\",\"japanese\":\"ラグラージ\",\"chinese\":\"巨沼怪\",\"french\":\"Laggron\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":100,\"Attack\":110,\"Defense\":90,\"Sp. Attack\":85,\"Sp. Defense\":90,\"Speed\":60}},{\"id\":261,\"name\":{\"english\":\"Poochyena\",\"japanese\":\"ポチエナ\",\"chinese\":\"土狼犬\",\"french\":\"Medhyèna\"},\"type\":[\"Dark\"],\"base\":{\"HP\":35,\"Attack\":55,\"Defense\":35,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":35}},{\"id\":262,\"name\":{\"english\":\"Mightyena\",\"japanese\":\"グラエナ\",\"chinese\":\"大狼犬\",\"french\":\"Grahyèna\"},\"type\":[\"Dark\"],\"base\":{\"HP\":70,\"Attack\":90,\"Defense\":70,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":70}},{\"id\":263,\"name\":{\"english\":\"Zigzagoon\",\"japanese\":\"ジグザグマ\",\"chinese\":\"蛇纹熊\",\"french\":\"Zigzaton\"},\"type\":[\"Normal\"],\"base\":{\"HP\":38,\"Attack\":30,\"Defense\":41,\"Sp. Attack\":30,\"Sp. Defense\":41,\"Speed\":60}},{\"id\":264,\"name\":{\"english\":\"Linoone\",\"japanese\":\"マッスグマ\",\"chinese\":\"直冲熊\",\"french\":\"Linéon\"},\"type\":[\"Normal\"],\"base\":{\"HP\":78,\"Attack\":70,\"Defense\":61,\"Sp. Attack\":50,\"Sp. Defense\":61,\"Speed\":100}},{\"id\":265,\"name\":{\"english\":\"Wurmple\",\"japanese\":\"ケムッソ\",\"chinese\":\"刺尾虫\",\"french\":\"Chenipotte\"},\"type\":[\"Bug\"],\"base\":{\"HP\":45,\"Attack\":45,\"Defense\":35,\"Sp. Attack\":20,\"Sp. Defense\":30,\"Speed\":20}},{\"id\":266,\"name\":{\"english\":\"Silcoon\",\"japanese\":\"カラサリス\",\"chinese\":\"甲壳茧\",\"french\":\"Armulys\"},\"type\":[\"Bug\"],\"base\":{\"HP\":50,\"Attack\":35,\"Defense\":55,\"Sp. Attack\":25,\"Sp. Defense\":25,\"Speed\":15}},{\"id\":267,\"name\":{\"english\":\"Beautifly\",\"japanese\":\"アゲハント\",\"chinese\":\"狩猎凤蝶\",\"french\":\"Charmillon\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":60,\"Attack\":70,\"Defense\":50,\"Sp. Attack\":100,\"Sp. Defense\":50,\"Speed\":65}},{\"id\":268,\"name\":{\"english\":\"Cascoon\",\"japanese\":\"マユルド\",\"chinese\":\"盾甲茧\",\"french\":\"Blindalys\"},\"type\":[\"Bug\"],\"base\":{\"HP\":50,\"Attack\":35,\"Defense\":55,\"Sp. Attack\":25,\"Sp. Defense\":25,\"Speed\":15}},{\"id\":269,\"name\":{\"english\":\"Dustox\",\"japanese\":\"ドクケイル\",\"chinese\":\"毒粉蛾\",\"french\":\"Papinox\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":60,\"Attack\":50,\"Defense\":70,\"Sp. Attack\":50,\"Sp. Defense\":90,\"Speed\":65}},{\"id\":270,\"name\":{\"english\":\"Lotad\",\"japanese\":\"ハスボー\",\"chinese\":\"莲叶童子\",\"french\":\"Nénupiot\"},\"type\":[\"Water\",\"Grass\"],\"base\":{\"HP\":40,\"Attack\":30,\"Defense\":30,\"Sp. Attack\":40,\"Sp. Defense\":50,\"Speed\":30}},{\"id\":271,\"name\":{\"english\":\"Lombre\",\"japanese\":\"ハスブレロ\",\"chinese\":\"莲帽小童\",\"french\":\"Lombre\"},\"type\":[\"Water\",\"Grass\"],\"base\":{\"HP\":60,\"Attack\":50,\"Defense\":50,\"Sp. Attack\":60,\"Sp. Defense\":70,\"Speed\":50}},{\"id\":272,\"name\":{\"english\":\"Ludicolo\",\"japanese\":\"ルンパッパ\",\"chinese\":\"乐天河童\",\"french\":\"Ludicolo\"},\"type\":[\"Water\",\"Grass\"],\"base\":{\"HP\":80,\"Attack\":70,\"Defense\":70,\"Sp. Attack\":90,\"Sp. Defense\":100,\"Speed\":70}},{\"id\":273,\"name\":{\"english\":\"Seedot\",\"japanese\":\"タネボー\",\"chinese\":\"橡实果\",\"french\":\"Grainipiot\"},\"type\":[\"Grass\"],\"base\":{\"HP\":40,\"Attack\":40,\"Defense\":50,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":30}},{\"id\":274,\"name\":{\"english\":\"Nuzleaf\",\"japanese\":\"コノハナ\",\"chinese\":\"长鼻叶\",\"french\":\"Pifeuil\"},\"type\":[\"Grass\",\"Dark\"],\"base\":{\"HP\":70,\"Attack\":70,\"Defense\":40,\"Sp. Attack\":60,\"Sp. Defense\":40,\"Speed\":60}},{\"id\":275,\"name\":{\"english\":\"Shiftry\",\"japanese\":\"ダーテング\",\"chinese\":\"狡猾天狗\",\"french\":\"Tengalice\"},\"type\":[\"Grass\",\"Dark\"],\"base\":{\"HP\":90,\"Attack\":100,\"Defense\":60,\"Sp. Attack\":90,\"Sp. Defense\":60,\"Speed\":80}},{\"id\":276,\"name\":{\"english\":\"Taillow\",\"japanese\":\"スバメ\",\"chinese\":\"傲骨燕\",\"french\":\"Nirondelle\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":40,\"Attack\":55,\"Defense\":30,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":85}},{\"id\":277,\"name\":{\"english\":\"Swellow\",\"japanese\":\"オオスバメ\",\"chinese\":\"大王燕\",\"french\":\"Hélédelle\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":60,\"Attack\":85,\"Defense\":60,\"Sp. Attack\":75,\"Sp. Defense\":50,\"Speed\":125}},{\"id\":278,\"name\":{\"english\":\"Wingull\",\"japanese\":\"キャモメ\",\"chinese\":\"长翅鸥\",\"french\":\"Goélise\"},\"type\":[\"Water\",\"Flying\"],\"base\":{\"HP\":40,\"Attack\":30,\"Defense\":30,\"Sp. Attack\":55,\"Sp. Defense\":30,\"Speed\":85}},{\"id\":279,\"name\":{\"english\":\"Pelipper\",\"japanese\":\"ペリッパー\",\"chinese\":\"大嘴鸥\",\"french\":\"Bekipan\"},\"type\":[\"Water\",\"Flying\"],\"base\":{\"HP\":60,\"Attack\":50,\"Defense\":100,\"Sp. Attack\":95,\"Sp. Defense\":70,\"Speed\":65}},{\"id\":280,\"name\":{\"english\":\"Ralts\",\"japanese\":\"ラルトス\",\"chinese\":\"拉鲁拉丝\",\"french\":\"Tarsal\"},\"type\":[\"Psychic\",\"Fairy\"],\"base\":{\"HP\":28,\"Attack\":25,\"Defense\":25,\"Sp. Attack\":45,\"Sp. Defense\":35,\"Speed\":40}},{\"id\":281,\"name\":{\"english\":\"Kirlia\",\"japanese\":\"キルリア\",\"chinese\":\"奇鲁莉安\",\"french\":\"Kirlia\"},\"type\":[\"Psychic\",\"Fairy\"],\"base\":{\"HP\":38,\"Attack\":35,\"Defense\":35,\"Sp. Attack\":65,\"Sp. Defense\":55,\"Speed\":50}},{\"id\":282,\"name\":{\"english\":\"Gardevoir\",\"japanese\":\"サーナイト\",\"chinese\":\"沙奈朵\",\"french\":\"Gardevoir\"},\"type\":[\"Psychic\",\"Fairy\"],\"base\":{\"HP\":68,\"Attack\":65,\"Defense\":65,\"Sp. Attack\":125,\"Sp. Defense\":115,\"Speed\":80}},{\"id\":283,\"name\":{\"english\":\"Surskit\",\"japanese\":\"アメタマ\",\"chinese\":\"溜溜糖球\",\"french\":\"Arakdo\"},\"type\":[\"Bug\",\"Water\"],\"base\":{\"HP\":40,\"Attack\":30,\"Defense\":32,\"Sp. Attack\":50,\"Sp. Defense\":52,\"Speed\":65}},{\"id\":284,\"name\":{\"english\":\"Masquerain\",\"japanese\":\"アメモース\",\"chinese\":\"雨翅蛾\",\"french\":\"Maskadra\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":70,\"Attack\":60,\"Defense\":62,\"Sp. Attack\":100,\"Sp. Defense\":82,\"Speed\":80}},{\"id\":285,\"name\":{\"english\":\"Shroomish\",\"japanese\":\"キノココ\",\"chinese\":\"蘑蘑菇\",\"french\":\"Balignon\"},\"type\":[\"Grass\"],\"base\":{\"HP\":60,\"Attack\":40,\"Defense\":60,\"Sp. Attack\":40,\"Sp. Defense\":60,\"Speed\":35}},{\"id\":286,\"name\":{\"english\":\"Breloom\",\"japanese\":\"キノガッサ\",\"chinese\":\"斗笠菇\",\"french\":\"Chapignon\"},\"type\":[\"Grass\",\"Fighting\"],\"base\":{\"HP\":60,\"Attack\":130,\"Defense\":80,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":70}},{\"id\":287,\"name\":{\"english\":\"Slakoth\",\"japanese\":\"ナマケロ\",\"chinese\":\"懒人獭\",\"french\":\"Parecool\"},\"type\":[\"Normal\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":60,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":30}},{\"id\":288,\"name\":{\"english\":\"Vigoroth\",\"japanese\":\"ヤルキモノ\",\"chinese\":\"过动猿\",\"french\":\"Vigoroth\"},\"type\":[\"Normal\"],\"base\":{\"HP\":80,\"Attack\":80,\"Defense\":80,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":90}},{\"id\":289,\"name\":{\"english\":\"Slaking\",\"japanese\":\"ケッキング\",\"chinese\":\"请假王\",\"french\":\"Monaflèmit\"},\"type\":[\"Normal\"],\"base\":{\"HP\":150,\"Attack\":160,\"Defense\":100,\"Sp. Attack\":95,\"Sp. Defense\":65,\"Speed\":100}},{\"id\":290,\"name\":{\"english\":\"Nincada\",\"japanese\":\"ツチニン\",\"chinese\":\"土居忍士\",\"french\":\"Ningale\"},\"type\":[\"Bug\",\"Ground\"],\"base\":{\"HP\":31,\"Attack\":45,\"Defense\":90,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":40}},{\"id\":291,\"name\":{\"english\":\"Ninjask\",\"japanese\":\"テッカニン\",\"chinese\":\"铁面忍者\",\"french\":\"Ninjask\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":61,\"Attack\":90,\"Defense\":45,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":160}},{\"id\":292,\"name\":{\"english\":\"Shedinja\",\"japanese\":\"ヌケニン\",\"chinese\":\"脱壳忍者\",\"french\":\"Munja\"},\"type\":[\"Bug\",\"Ghost\"],\"base\":{\"HP\":1,\"Attack\":90,\"Defense\":45,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":40}},{\"id\":293,\"name\":{\"english\":\"Whismur\",\"japanese\":\"ゴニョニョ\",\"chinese\":\"咕妞妞\",\"french\":\"Chuchmur\"},\"type\":[\"Normal\"],\"base\":{\"HP\":64,\"Attack\":51,\"Defense\":23,\"Sp. Attack\":51,\"Sp. Defense\":23,\"Speed\":28}},{\"id\":294,\"name\":{\"english\":\"Loudred\",\"japanese\":\"ドゴーム\",\"chinese\":\"吼爆弹\",\"french\":\"Ramboum\"},\"type\":[\"Normal\"],\"base\":{\"HP\":84,\"Attack\":71,\"Defense\":43,\"Sp. Attack\":71,\"Sp. Defense\":43,\"Speed\":48}},{\"id\":295,\"name\":{\"english\":\"Exploud\",\"japanese\":\"バクオング\",\"chinese\":\"爆音怪\",\"french\":\"Brouhabam\"},\"type\":[\"Normal\"],\"base\":{\"HP\":104,\"Attack\":91,\"Defense\":63,\"Sp. Attack\":91,\"Sp. Defense\":73,\"Speed\":68}},{\"id\":296,\"name\":{\"english\":\"Makuhita\",\"japanese\":\"マクノシタ\",\"chinese\":\"幕下力士\",\"french\":\"Makuhita\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":72,\"Attack\":60,\"Defense\":30,\"Sp. Attack\":20,\"Sp. Defense\":30,\"Speed\":25}},{\"id\":297,\"name\":{\"english\":\"Hariyama\",\"japanese\":\"ハリテヤマ\",\"chinese\":\"铁掌力士\",\"french\":\"Hariyama\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":144,\"Attack\":120,\"Defense\":60,\"Sp. Attack\":40,\"Sp. Defense\":60,\"Speed\":50}},{\"id\":298,\"name\":{\"english\":\"Azurill\",\"japanese\":\"ルリリ\",\"chinese\":\"露力丽\",\"french\":\"Azurill\"},\"type\":[\"Normal\",\"Fairy\"],\"base\":{\"HP\":50,\"Attack\":20,\"Defense\":40,\"Sp. Attack\":20,\"Sp. Defense\":40,\"Speed\":20}},{\"id\":299,\"name\":{\"english\":\"Nosepass\",\"japanese\":\"ノズパス\",\"chinese\":\"朝北鼻\",\"french\":\"Tarinor\"},\"type\":[\"Rock\"],\"base\":{\"HP\":30,\"Attack\":45,\"Defense\":135,\"Sp. Attack\":45,\"Sp. Defense\":90,\"Speed\":30}},{\"id\":300,\"name\":{\"english\":\"Skitty\",\"japanese\":\"エネコ\",\"chinese\":\"向尾喵\",\"french\":\"Skitty\"},\"type\":[\"Normal\"],\"base\":{\"HP\":50,\"Attack\":45,\"Defense\":45,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":50}},{\"id\":301,\"name\":{\"english\":\"Delcatty\",\"japanese\":\"エネコロロ\",\"chinese\":\"优雅猫\",\"french\":\"Delcatty\"},\"type\":[\"Normal\"],\"base\":{\"HP\":70,\"Attack\":65,\"Defense\":65,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":90}},{\"id\":302,\"name\":{\"english\":\"Sableye\",\"japanese\":\"ヤミラミ\",\"chinese\":\"勾魂眼\",\"french\":\"Ténéfix\"},\"type\":[\"Dark\",\"Ghost\"],\"base\":{\"HP\":50,\"Attack\":75,\"Defense\":75,\"Sp. Attack\":65,\"Sp. Defense\":65,\"Speed\":50}},{\"id\":303,\"name\":{\"english\":\"Mawile\",\"japanese\":\"クチート\",\"chinese\":\"大嘴娃\",\"french\":\"Mysdibule\"},\"type\":[\"Steel\",\"Fairy\"],\"base\":{\"HP\":50,\"Attack\":85,\"Defense\":85,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":50}},{\"id\":304,\"name\":{\"english\":\"Aron\",\"japanese\":\"ココドラ\",\"chinese\":\"可可多拉\",\"french\":\"Galekid\"},\"type\":[\"Steel\",\"Rock\"],\"base\":{\"HP\":50,\"Attack\":70,\"Defense\":100,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":30}},{\"id\":305,\"name\":{\"english\":\"Lairon\",\"japanese\":\"コドラ\",\"chinese\":\"可多拉\",\"french\":\"Galegon\"},\"type\":[\"Steel\",\"Rock\"],\"base\":{\"HP\":60,\"Attack\":90,\"Defense\":140,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":40}},{\"id\":306,\"name\":{\"english\":\"Aggron\",\"japanese\":\"ボスゴドラ\",\"chinese\":\"波士可多拉\",\"french\":\"Galeking\"},\"type\":[\"Steel\",\"Rock\"],\"base\":{\"HP\":70,\"Attack\":110,\"Defense\":180,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":50}},{\"id\":307,\"name\":{\"english\":\"Meditite\",\"japanese\":\"アサナン\",\"chinese\":\"玛沙那\",\"french\":\"Méditikka\"},\"type\":[\"Fighting\",\"Psychic\"],\"base\":{\"HP\":30,\"Attack\":40,\"Defense\":55,\"Sp. Attack\":40,\"Sp. Defense\":55,\"Speed\":60}},{\"id\":308,\"name\":{\"english\":\"Medicham\",\"japanese\":\"チャーレム\",\"chinese\":\"恰雷姆\",\"french\":\"Charmina\"},\"type\":[\"Fighting\",\"Psychic\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":75,\"Sp. Attack\":60,\"Sp. Defense\":75,\"Speed\":80}},{\"id\":309,\"name\":{\"english\":\"Electrike\",\"japanese\":\"ラクライ\",\"chinese\":\"落雷兽\",\"french\":\"Dynavolt\"},\"type\":[\"Electric\"],\"base\":{\"HP\":40,\"Attack\":45,\"Defense\":40,\"Sp. Attack\":65,\"Sp. Defense\":40,\"Speed\":65}},{\"id\":310,\"name\":{\"english\":\"Manectric\",\"japanese\":\"ライボルト\",\"chinese\":\"雷电兽\",\"french\":\"Élecsprint\"},\"type\":[\"Electric\"],\"base\":{\"HP\":70,\"Attack\":75,\"Defense\":60,\"Sp. Attack\":105,\"Sp. Defense\":60,\"Speed\":105}},{\"id\":311,\"name\":{\"english\":\"Plusle\",\"japanese\":\"プラスル\",\"chinese\":\"正电拍拍\",\"french\":\"Posipi\"},\"type\":[\"Electric\"],\"base\":{\"HP\":60,\"Attack\":50,\"Defense\":40,\"Sp. Attack\":85,\"Sp. Defense\":75,\"Speed\":95}},{\"id\":312,\"name\":{\"english\":\"Minun\",\"japanese\":\"マイナン\",\"chinese\":\"负电拍拍\",\"french\":\"Négapi\"},\"type\":[\"Electric\"],\"base\":{\"HP\":60,\"Attack\":40,\"Defense\":50,\"Sp. Attack\":75,\"Sp. Defense\":85,\"Speed\":95}},{\"id\":313,\"name\":{\"english\":\"Volbeat\",\"japanese\":\"バルビート\",\"chinese\":\"电萤虫\",\"french\":\"Muciole\"},\"type\":[\"Bug\"],\"base\":{\"HP\":65,\"Attack\":73,\"Defense\":75,\"Sp. Attack\":47,\"Sp. Defense\":85,\"Speed\":85}},{\"id\":314,\"name\":{\"english\":\"Illumise\",\"japanese\":\"イルミーゼ\",\"chinese\":\"甜甜萤\",\"french\":\"Lumivole\"},\"type\":[\"Bug\"],\"base\":{\"HP\":65,\"Attack\":47,\"Defense\":75,\"Sp. Attack\":73,\"Sp. Defense\":85,\"Speed\":85}},{\"id\":315,\"name\":{\"english\":\"Roselia\",\"japanese\":\"ロゼリア\",\"chinese\":\"毒蔷薇\",\"french\":\"Rosélia\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":50,\"Attack\":60,\"Defense\":45,\"Sp. Attack\":100,\"Sp. Defense\":80,\"Speed\":65}},{\"id\":316,\"name\":{\"english\":\"Gulpin\",\"japanese\":\"ゴクリン\",\"chinese\":\"溶食兽\",\"french\":\"Gloupti\"},\"type\":[\"Poison\"],\"base\":{\"HP\":70,\"Attack\":43,\"Defense\":53,\"Sp. Attack\":43,\"Sp. Defense\":53,\"Speed\":40}},{\"id\":317,\"name\":{\"english\":\"Swalot\",\"japanese\":\"マルノーム\",\"chinese\":\"吞食兽\",\"french\":\"Avaltout\"},\"type\":[\"Poison\"],\"base\":{\"HP\":100,\"Attack\":73,\"Defense\":83,\"Sp. Attack\":73,\"Sp. Defense\":83,\"Speed\":55}},{\"id\":318,\"name\":{\"english\":\"Carvanha\",\"japanese\":\"キバニア\",\"chinese\":\"利牙鱼\",\"french\":\"Carvanha\"},\"type\":[\"Water\",\"Dark\"],\"base\":{\"HP\":45,\"Attack\":90,\"Defense\":20,\"Sp. Attack\":65,\"Sp. Defense\":20,\"Speed\":65}},{\"id\":319,\"name\":{\"english\":\"Sharpedo\",\"japanese\":\"サメハダー\",\"chinese\":\"巨牙鲨\",\"french\":\"Sharpedo\"},\"type\":[\"Water\",\"Dark\"],\"base\":{\"HP\":70,\"Attack\":120,\"Defense\":40,\"Sp. Attack\":95,\"Sp. Defense\":40,\"Speed\":95}},{\"id\":320,\"name\":{\"english\":\"Wailmer\",\"japanese\":\"ホエルコ\",\"chinese\":\"吼吼鲸\",\"french\":\"Wailmer\"},\"type\":[\"Water\"],\"base\":{\"HP\":130,\"Attack\":70,\"Defense\":35,\"Sp. Attack\":70,\"Sp. Defense\":35,\"Speed\":60}},{\"id\":321,\"name\":{\"english\":\"Wailord\",\"japanese\":\"ホエルオー\",\"chinese\":\"吼鲸王\",\"french\":\"Wailord\"},\"type\":[\"Water\"],\"base\":{\"HP\":170,\"Attack\":90,\"Defense\":45,\"Sp. Attack\":90,\"Sp. Defense\":45,\"Speed\":60}},{\"id\":322,\"name\":{\"english\":\"Numel\",\"japanese\":\"ドンメル\",\"chinese\":\"呆火驼\",\"french\":\"Chamallot\"},\"type\":[\"Fire\",\"Ground\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":40,\"Sp. Attack\":65,\"Sp. Defense\":45,\"Speed\":35}},{\"id\":323,\"name\":{\"english\":\"Camerupt\",\"japanese\":\"バクーダ\",\"chinese\":\"喷火驼\",\"french\":\"Camérupt\"},\"type\":[\"Fire\",\"Ground\"],\"base\":{\"HP\":70,\"Attack\":100,\"Defense\":70,\"Sp. Attack\":105,\"Sp. Defense\":75,\"Speed\":40}},{\"id\":324,\"name\":{\"english\":\"Torkoal\",\"japanese\":\"コータス\",\"chinese\":\"煤炭龟\",\"french\":\"Chartor\"},\"type\":[\"Fire\"],\"base\":{\"HP\":70,\"Attack\":85,\"Defense\":140,\"Sp. Attack\":85,\"Sp. Defense\":70,\"Speed\":20}},{\"id\":325,\"name\":{\"english\":\"Spoink\",\"japanese\":\"バネブー\",\"chinese\":\"跳跳猪\",\"french\":\"Spoink\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":60,\"Attack\":25,\"Defense\":35,\"Sp. Attack\":70,\"Sp. Defense\":80,\"Speed\":60}},{\"id\":326,\"name\":{\"english\":\"Grumpig\",\"japanese\":\"ブーピッグ\",\"chinese\":\"噗噗猪\",\"french\":\"Groret\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":80,\"Attack\":45,\"Defense\":65,\"Sp. Attack\":90,\"Sp. Defense\":110,\"Speed\":80}},{\"id\":327,\"name\":{\"english\":\"Spinda\",\"japanese\":\"パッチール\",\"chinese\":\"晃晃斑\",\"french\":\"Spinda\"},\"type\":[\"Normal\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":60,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":60}},{\"id\":328,\"name\":{\"english\":\"Trapinch\",\"japanese\":\"ナックラー\",\"chinese\":\"大颚蚁\",\"french\":\"Kraknoix\"},\"type\":[\"Ground\"],\"base\":{\"HP\":45,\"Attack\":100,\"Defense\":45,\"Sp. Attack\":45,\"Sp. Defense\":45,\"Speed\":10}},{\"id\":329,\"name\":{\"english\":\"Vibrava\",\"japanese\":\"ビブラーバ\",\"chinese\":\"超音波幼虫\",\"french\":\"Vibraninf\"},\"type\":[\"Ground\",\"Dragon\"],\"base\":{\"HP\":50,\"Attack\":70,\"Defense\":50,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":70}},{\"id\":330,\"name\":{\"english\":\"Flygon\",\"japanese\":\"フライゴン\",\"chinese\":\"沙漠蜻蜓\",\"french\":\"Libégon\"},\"type\":[\"Ground\",\"Dragon\"],\"base\":{\"HP\":80,\"Attack\":100,\"Defense\":80,\"Sp. Attack\":80,\"Sp. Defense\":80,\"Speed\":100}},{\"id\":331,\"name\":{\"english\":\"Cacnea\",\"japanese\":\"サボネア\",\"chinese\":\"刺球仙人掌\",\"french\":\"Cacnea\"},\"type\":[\"Grass\"],\"base\":{\"HP\":50,\"Attack\":85,\"Defense\":40,\"Sp. Attack\":85,\"Sp. Defense\":40,\"Speed\":35}},{\"id\":332,\"name\":{\"english\":\"Cacturne\",\"japanese\":\"ノクタス\",\"chinese\":\"梦歌仙人掌\",\"french\":\"Cacturne\"},\"type\":[\"Grass\",\"Dark\"],\"base\":{\"HP\":70,\"Attack\":115,\"Defense\":60,\"Sp. Attack\":115,\"Sp. Defense\":60,\"Speed\":55}},{\"id\":333,\"name\":{\"english\":\"Swablu\",\"japanese\":\"チルット\",\"chinese\":\"青绵鸟\",\"french\":\"Tylton\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":45,\"Attack\":40,\"Defense\":60,\"Sp. Attack\":40,\"Sp. Defense\":75,\"Speed\":50}},{\"id\":334,\"name\":{\"english\":\"Altaria\",\"japanese\":\"チルタリス\",\"chinese\":\"七夕青鸟\",\"french\":\"Altaria\"},\"type\":[\"Dragon\",\"Flying\"],\"base\":{\"HP\":75,\"Attack\":70,\"Defense\":90,\"Sp. Attack\":70,\"Sp. Defense\":105,\"Speed\":80}},{\"id\":335,\"name\":{\"english\":\"Zangoose\",\"japanese\":\"ザングース\",\"chinese\":\"猫鼬斩\",\"french\":\"Mangriff\"},\"type\":[\"Normal\"],\"base\":{\"HP\":73,\"Attack\":115,\"Defense\":60,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":90}},{\"id\":336,\"name\":{\"english\":\"Seviper\",\"japanese\":\"ハブネーク\",\"chinese\":\"饭匙蛇\",\"french\":\"Séviper\"},\"type\":[\"Poison\"],\"base\":{\"HP\":73,\"Attack\":100,\"Defense\":60,\"Sp. Attack\":100,\"Sp. Defense\":60,\"Speed\":65}},{\"id\":337,\"name\":{\"english\":\"Lunatone\",\"japanese\":\"ルナトーン\",\"chinese\":\"月石\",\"french\":\"Séléroc\"},\"type\":[\"Rock\",\"Psychic\"],\"base\":{\"HP\":90,\"Attack\":55,\"Defense\":65,\"Sp. Attack\":95,\"Sp. Defense\":85,\"Speed\":70}},{\"id\":338,\"name\":{\"english\":\"Solrock\",\"japanese\":\"ソルロック\",\"chinese\":\"太阳岩\",\"french\":\"Solaroc\"},\"type\":[\"Rock\",\"Psychic\"],\"base\":{\"HP\":90,\"Attack\":95,\"Defense\":85,\"Sp. Attack\":55,\"Sp. Defense\":65,\"Speed\":70}},{\"id\":339,\"name\":{\"english\":\"Barboach\",\"japanese\":\"ドジョッチ\",\"chinese\":\"泥泥鳅\",\"french\":\"Barloche\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":50,\"Attack\":48,\"Defense\":43,\"Sp. Attack\":46,\"Sp. Defense\":41,\"Speed\":60}},{\"id\":340,\"name\":{\"english\":\"Whiscash\",\"japanese\":\"ナマズン\",\"chinese\":\"鲶鱼王\",\"french\":\"Barbicha\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":110,\"Attack\":78,\"Defense\":73,\"Sp. Attack\":76,\"Sp. Defense\":71,\"Speed\":60}},{\"id\":341,\"name\":{\"english\":\"Corphish\",\"japanese\":\"ヘイガニ\",\"chinese\":\"龙虾小兵\",\"french\":\"Écrapince\"},\"type\":[\"Water\"],\"base\":{\"HP\":43,\"Attack\":80,\"Defense\":65,\"Sp. Attack\":50,\"Sp. Defense\":35,\"Speed\":35}},{\"id\":342,\"name\":{\"english\":\"Crawdaunt\",\"japanese\":\"シザリガー\",\"chinese\":\"铁螯龙虾\",\"french\":\"Colhomard\"},\"type\":[\"Water\",\"Dark\"],\"base\":{\"HP\":63,\"Attack\":120,\"Defense\":85,\"Sp. Attack\":90,\"Sp. Defense\":55,\"Speed\":55}},{\"id\":343,\"name\":{\"english\":\"Baltoy\",\"japanese\":\"ヤジロン\",\"chinese\":\"天秤偶\",\"french\":\"Balbuto\"},\"type\":[\"Ground\",\"Psychic\"],\"base\":{\"HP\":40,\"Attack\":40,\"Defense\":55,\"Sp. Attack\":40,\"Sp. Defense\":70,\"Speed\":55}},{\"id\":344,\"name\":{\"english\":\"Claydol\",\"japanese\":\"ネンドール\",\"chinese\":\"念力土偶\",\"french\":\"Kaorine\"},\"type\":[\"Ground\",\"Psychic\"],\"base\":{\"HP\":60,\"Attack\":70,\"Defense\":105,\"Sp. Attack\":70,\"Sp. Defense\":120,\"Speed\":75}},{\"id\":345,\"name\":{\"english\":\"Lileep\",\"japanese\":\"リリーラ\",\"chinese\":\"触手百合\",\"french\":\"Lilia\"},\"type\":[\"Rock\",\"Grass\"],\"base\":{\"HP\":66,\"Attack\":41,\"Defense\":77,\"Sp. Attack\":61,\"Sp. Defense\":87,\"Speed\":23}},{\"id\":346,\"name\":{\"english\":\"Cradily\",\"japanese\":\"ユレイドル\",\"chinese\":\"摇篮百合\",\"french\":\"Vacilys\"},\"type\":[\"Rock\",\"Grass\"],\"base\":{\"HP\":86,\"Attack\":81,\"Defense\":97,\"Sp. Attack\":81,\"Sp. Defense\":107,\"Speed\":43}},{\"id\":347,\"name\":{\"english\":\"Anorith\",\"japanese\":\"アノプス\",\"chinese\":\"太古羽虫\",\"french\":\"Anorith\"},\"type\":[\"Rock\",\"Bug\"],\"base\":{\"HP\":45,\"Attack\":95,\"Defense\":50,\"Sp. Attack\":40,\"Sp. Defense\":50,\"Speed\":75}},{\"id\":348,\"name\":{\"english\":\"Armaldo\",\"japanese\":\"アーマルド\",\"chinese\":\"太古盔甲\",\"french\":\"Armaldo\"},\"type\":[\"Rock\",\"Bug\"],\"base\":{\"HP\":75,\"Attack\":125,\"Defense\":100,\"Sp. Attack\":70,\"Sp. Defense\":80,\"Speed\":45}},{\"id\":349,\"name\":{\"english\":\"Feebas\",\"japanese\":\"ヒンバス\",\"chinese\":\"丑丑鱼\",\"french\":\"Barpau\"},\"type\":[\"Water\"],\"base\":{\"HP\":20,\"Attack\":15,\"Defense\":20,\"Sp. Attack\":10,\"Sp. Defense\":55,\"Speed\":80}},{\"id\":350,\"name\":{\"english\":\"Milotic\",\"japanese\":\"ミロカロス\",\"chinese\":\"美纳斯\",\"french\":\"Milobellus\"},\"type\":[\"Water\"],\"base\":{\"HP\":95,\"Attack\":60,\"Defense\":79,\"Sp. Attack\":100,\"Sp. Defense\":125,\"Speed\":81}},{\"id\":351,\"name\":{\"english\":\"Castform\",\"japanese\":\"ポワルン\",\"chinese\":\"飘浮泡泡\",\"french\":\"Morphéo\"},\"type\":[\"Normal\"],\"base\":{\"HP\":70,\"Attack\":70,\"Defense\":70,\"Sp. Attack\":70,\"Sp. Defense\":70,\"Speed\":70}},{\"id\":352,\"name\":{\"english\":\"Kecleon\",\"japanese\":\"カクレオン\",\"chinese\":\"变隐龙\",\"french\":\"Kecleon\"},\"type\":[\"Normal\"],\"base\":{\"HP\":60,\"Attack\":90,\"Defense\":70,\"Sp. Attack\":60,\"Sp. Defense\":120,\"Speed\":40}},{\"id\":353,\"name\":{\"english\":\"Shuppet\",\"japanese\":\"カゲボウズ\",\"chinese\":\"怨影娃娃\",\"french\":\"Polichombr\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":44,\"Attack\":75,\"Defense\":35,\"Sp. Attack\":63,\"Sp. Defense\":33,\"Speed\":45}},{\"id\":354,\"name\":{\"english\":\"Banette\",\"japanese\":\"ジュペッタ\",\"chinese\":\"诅咒娃娃\",\"french\":\"Branette\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":64,\"Attack\":115,\"Defense\":65,\"Sp. Attack\":83,\"Sp. Defense\":63,\"Speed\":65}},{\"id\":355,\"name\":{\"english\":\"Duskull\",\"japanese\":\"ヨマワル\",\"chinese\":\"夜巡灵\",\"french\":\"Skelénox\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":20,\"Attack\":40,\"Defense\":90,\"Sp. Attack\":30,\"Sp. Defense\":90,\"Speed\":25}},{\"id\":356,\"name\":{\"english\":\"Dusclops\",\"japanese\":\"サマヨール\",\"chinese\":\"彷徨夜灵\",\"french\":\"Téraclope\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":40,\"Attack\":70,\"Defense\":130,\"Sp. Attack\":60,\"Sp. Defense\":130,\"Speed\":25}},{\"id\":357,\"name\":{\"english\":\"Tropius\",\"japanese\":\"トロピウス\",\"chinese\":\"热带龙\",\"french\":\"Tropius\"},\"type\":[\"Grass\",\"Flying\"],\"base\":{\"HP\":99,\"Attack\":68,\"Defense\":83,\"Sp. Attack\":72,\"Sp. Defense\":87,\"Speed\":51}},{\"id\":358,\"name\":{\"english\":\"Chimecho\",\"japanese\":\"チリーン\",\"chinese\":\"风铃铃\",\"french\":\"Éoko\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":75,\"Attack\":50,\"Defense\":80,\"Sp. Attack\":95,\"Sp. Defense\":90,\"Speed\":65}},{\"id\":359,\"name\":{\"english\":\"Absol\",\"japanese\":\"アブソル\",\"chinese\":\"阿勃梭鲁\",\"french\":\"Absol\"},\"type\":[\"Dark\"],\"base\":{\"HP\":65,\"Attack\":130,\"Defense\":60,\"Sp. Attack\":75,\"Sp. Defense\":60,\"Speed\":75}},{\"id\":360,\"name\":{\"english\":\"Wynaut\",\"japanese\":\"ソーナノ\",\"chinese\":\"小果然\",\"french\":\"Okéoké\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":95,\"Attack\":23,\"Defense\":48,\"Sp. Attack\":23,\"Sp. Defense\":48,\"Speed\":23}},{\"id\":361,\"name\":{\"english\":\"Snorunt\",\"japanese\":\"ユキワラシ\",\"chinese\":\"雪童子\",\"french\":\"Stalgamin\"},\"type\":[\"Ice\"],\"base\":{\"HP\":50,\"Attack\":50,\"Defense\":50,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":50}},{\"id\":362,\"name\":{\"english\":\"Glalie\",\"japanese\":\"オニゴーリ\",\"chinese\":\"冰鬼护\",\"french\":\"Oniglali\"},\"type\":[\"Ice\"],\"base\":{\"HP\":80,\"Attack\":80,\"Defense\":80,\"Sp. Attack\":80,\"Sp. Defense\":80,\"Speed\":80}},{\"id\":363,\"name\":{\"english\":\"Spheal\",\"japanese\":\"タマザラシ\",\"chinese\":\"海豹球\",\"french\":\"Obalie\"},\"type\":[\"Ice\",\"Water\"],\"base\":{\"HP\":70,\"Attack\":40,\"Defense\":50,\"Sp. Attack\":55,\"Sp. Defense\":50,\"Speed\":25}},{\"id\":364,\"name\":{\"english\":\"Sealeo\",\"japanese\":\"トドグラー\",\"chinese\":\"海魔狮\",\"french\":\"Phogleur\"},\"type\":[\"Ice\",\"Water\"],\"base\":{\"HP\":90,\"Attack\":60,\"Defense\":70,\"Sp. Attack\":75,\"Sp. Defense\":70,\"Speed\":45}},{\"id\":365,\"name\":{\"english\":\"Walrein\",\"japanese\":\"トドゼルガ\",\"chinese\":\"帝牙海狮\",\"french\":\"Kaimorse\"},\"type\":[\"Ice\",\"Water\"],\"base\":{\"HP\":110,\"Attack\":80,\"Defense\":90,\"Sp. Attack\":95,\"Sp. Defense\":90,\"Speed\":65}},{\"id\":366,\"name\":{\"english\":\"Clamperl\",\"japanese\":\"パールル\",\"chinese\":\"珍珠贝\",\"french\":\"Coquiperl\"},\"type\":[\"Water\"],\"base\":{\"HP\":35,\"Attack\":64,\"Defense\":85,\"Sp. Attack\":74,\"Sp. Defense\":55,\"Speed\":32}},{\"id\":367,\"name\":{\"english\":\"Huntail\",\"japanese\":\"ハンテール\",\"chinese\":\"猎斑鱼\",\"french\":\"Serpang\"},\"type\":[\"Water\"],\"base\":{\"HP\":55,\"Attack\":104,\"Defense\":105,\"Sp. Attack\":94,\"Sp. Defense\":75,\"Speed\":52}},{\"id\":368,\"name\":{\"english\":\"Gorebyss\",\"japanese\":\"サクラビス\",\"chinese\":\"樱花鱼\",\"french\":\"Rosabyss\"},\"type\":[\"Water\"],\"base\":{\"HP\":55,\"Attack\":84,\"Defense\":105,\"Sp. Attack\":114,\"Sp. Defense\":75,\"Speed\":52}},{\"id\":369,\"name\":{\"english\":\"Relicanth\",\"japanese\":\"ジーランス\",\"chinese\":\"古空棘鱼\",\"french\":\"Relicanth\"},\"type\":[\"Water\",\"Rock\"],\"base\":{\"HP\":100,\"Attack\":90,\"Defense\":130,\"Sp. Attack\":45,\"Sp. Defense\":65,\"Speed\":55}},{\"id\":370,\"name\":{\"english\":\"Luvdisc\",\"japanese\":\"ラブカス\",\"chinese\":\"爱心鱼\",\"french\":\"Lovdisc\"},\"type\":[\"Water\"],\"base\":{\"HP\":43,\"Attack\":30,\"Defense\":55,\"Sp. Attack\":40,\"Sp. Defense\":65,\"Speed\":97}},{\"id\":371,\"name\":{\"english\":\"Bagon\",\"japanese\":\"タツベイ\",\"chinese\":\"宝贝龙\",\"french\":\"Draby\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":45,\"Attack\":75,\"Defense\":60,\"Sp. Attack\":40,\"Sp. Defense\":30,\"Speed\":50}},{\"id\":372,\"name\":{\"english\":\"Shelgon\",\"japanese\":\"コモルー\",\"chinese\":\"甲壳龙\",\"french\":\"Drackhaus\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":65,\"Attack\":95,\"Defense\":100,\"Sp. Attack\":60,\"Sp. Defense\":50,\"Speed\":50}},{\"id\":373,\"name\":{\"english\":\"Salamence\",\"japanese\":\"ボーマンダ\",\"chinese\":\"暴飞龙\",\"french\":\"Drattak\"},\"type\":[\"Dragon\",\"Flying\"],\"base\":{\"HP\":95,\"Attack\":135,\"Defense\":80,\"Sp. Attack\":110,\"Sp. Defense\":80,\"Speed\":100}},{\"id\":374,\"name\":{\"english\":\"Beldum\",\"japanese\":\"ダンバル\",\"chinese\":\"铁哑铃\",\"french\":\"Terhal\"},\"type\":[\"Steel\",\"Psychic\"],\"base\":{\"HP\":40,\"Attack\":55,\"Defense\":80,\"Sp. Attack\":35,\"Sp. Defense\":60,\"Speed\":30}},{\"id\":375,\"name\":{\"english\":\"Metang\",\"japanese\":\"メタング\",\"chinese\":\"金属怪\",\"french\":\"Métang\"},\"type\":[\"Steel\",\"Psychic\"],\"base\":{\"HP\":60,\"Attack\":75,\"Defense\":100,\"Sp. Attack\":55,\"Sp. Defense\":80,\"Speed\":50}},{\"id\":376,\"name\":{\"english\":\"Metagross\",\"japanese\":\"メタグロス\",\"chinese\":\"巨金怪\",\"french\":\"Métalosse\"},\"type\":[\"Steel\",\"Psychic\"],\"base\":{\"HP\":80,\"Attack\":135,\"Defense\":130,\"Sp. Attack\":95,\"Sp. Defense\":90,\"Speed\":70}},{\"id\":377,\"name\":{\"english\":\"Regirock\",\"japanese\":\"レジロック\",\"chinese\":\"雷吉洛克\",\"french\":\"Regirock\"},\"type\":[\"Rock\"],\"base\":{\"HP\":80,\"Attack\":100,\"Defense\":200,\"Sp. Attack\":50,\"Sp. Defense\":100,\"Speed\":50}},{\"id\":378,\"name\":{\"english\":\"Regice\",\"japanese\":\"レジアイス\",\"chinese\":\"雷吉艾斯\",\"french\":\"Regice\"},\"type\":[\"Ice\"],\"base\":{\"HP\":80,\"Attack\":50,\"Defense\":100,\"Sp. Attack\":100,\"Sp. Defense\":200,\"Speed\":50}},{\"id\":379,\"name\":{\"english\":\"Registeel\",\"japanese\":\"レジスチル\",\"chinese\":\"雷吉斯奇鲁\",\"french\":\"Registeel\"},\"type\":[\"Steel\"],\"base\":{\"HP\":80,\"Attack\":75,\"Defense\":150,\"Sp. Attack\":75,\"Sp. Defense\":150,\"Speed\":50}},{\"id\":380,\"name\":{\"english\":\"Latias\",\"japanese\":\"ラティアス\",\"chinese\":\"拉帝亚斯\",\"french\":\"Latias\"},\"type\":[\"Dragon\",\"Psychic\"],\"base\":{\"HP\":80,\"Attack\":80,\"Defense\":90,\"Sp. Attack\":110,\"Sp. Defense\":130,\"Speed\":110}},{\"id\":381,\"name\":{\"english\":\"Latios\",\"japanese\":\"ラティオス\",\"chinese\":\"拉帝欧斯\",\"french\":\"Latios\"},\"type\":[\"Dragon\",\"Psychic\"],\"base\":{\"HP\":80,\"Attack\":90,\"Defense\":80,\"Sp. Attack\":130,\"Sp. Defense\":110,\"Speed\":110}},{\"id\":382,\"name\":{\"english\":\"Kyogre\",\"japanese\":\"カイオーガ\",\"chinese\":\"盖欧卡\",\"french\":\"Kyogre\"},\"type\":[\"Water\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":90,\"Sp. Attack\":150,\"Sp. Defense\":140,\"Speed\":90}},{\"id\":383,\"name\":{\"english\":\"Groudon\",\"japanese\":\"グラードン\",\"chinese\":\"固拉多\",\"french\":\"Groudon\"},\"type\":[\"Ground\"],\"base\":{\"HP\":100,\"Attack\":150,\"Defense\":140,\"Sp. Attack\":100,\"Sp. Defense\":90,\"Speed\":90}},{\"id\":384,\"name\":{\"english\":\"Rayquaza\",\"japanese\":\"レックウザ\",\"chinese\":\"烈空坐\",\"french\":\"Rayquaza\"},\"type\":[\"Dragon\",\"Flying\"],\"base\":{\"HP\":105,\"Attack\":150,\"Defense\":90,\"Sp. Attack\":150,\"Sp. Defense\":90,\"Speed\":95}},{\"id\":385,\"name\":{\"english\":\"Jirachi\",\"japanese\":\"ジラーチ\",\"chinese\":\"基拉祈\",\"french\":\"Jirachi\"},\"type\":[\"Steel\",\"Psychic\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":100,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":100}},{\"id\":386,\"name\":{\"english\":\"Deoxys\",\"japanese\":\"デオキシス\",\"chinese\":\"代欧奇希斯\",\"french\":\"Deoxys\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":50,\"Attack\":150,\"Defense\":50,\"Sp. Attack\":150,\"Sp. Defense\":50,\"Speed\":150}},{\"id\":387,\"name\":{\"english\":\"Turtwig\",\"japanese\":\"ナエトル\",\"chinese\":\"草苗龟\",\"french\":\"Tortipouss\"},\"type\":[\"Grass\"],\"base\":{\"HP\":55,\"Attack\":68,\"Defense\":64,\"Sp. Attack\":45,\"Sp. Defense\":55,\"Speed\":31}},{\"id\":388,\"name\":{\"english\":\"Grotle\",\"japanese\":\"ハヤシガメ\",\"chinese\":\"树林龟\",\"french\":\"Boskara\"},\"type\":[\"Grass\"],\"base\":{\"HP\":75,\"Attack\":89,\"Defense\":85,\"Sp. Attack\":55,\"Sp. Defense\":65,\"Speed\":36}},{\"id\":389,\"name\":{\"english\":\"Torterra\",\"japanese\":\"ドダイトス\",\"chinese\":\"土台龟\",\"french\":\"Torterra\"},\"type\":[\"Grass\",\"Ground\"],\"base\":{\"HP\":95,\"Attack\":109,\"Defense\":105,\"Sp. Attack\":75,\"Sp. Defense\":85,\"Speed\":56}},{\"id\":390,\"name\":{\"english\":\"Chimchar\",\"japanese\":\"ヒコザル\",\"chinese\":\"小火焰猴\",\"french\":\"Ouisticram\"},\"type\":[\"Fire\"],\"base\":{\"HP\":44,\"Attack\":58,\"Defense\":44,\"Sp. Attack\":58,\"Sp. Defense\":44,\"Speed\":61}},{\"id\":391,\"name\":{\"english\":\"Monferno\",\"japanese\":\"モウカザル\",\"chinese\":\"猛火猴\",\"french\":\"Chimpenfeu\"},\"type\":[\"Fire\",\"Fighting\"],\"base\":{\"HP\":64,\"Attack\":78,\"Defense\":52,\"Sp. Attack\":78,\"Sp. Defense\":52,\"Speed\":81}},{\"id\":392,\"name\":{\"english\":\"Infernape\",\"japanese\":\"ゴウカザル\",\"chinese\":\"烈焰猴\",\"french\":\"Simiabraz\"},\"type\":[\"Fire\",\"Fighting\"],\"base\":{\"HP\":76,\"Attack\":104,\"Defense\":71,\"Sp. Attack\":104,\"Sp. Defense\":71,\"Speed\":108}},{\"id\":393,\"name\":{\"english\":\"Piplup\",\"japanese\":\"ポッチャマ\",\"chinese\":\"波加曼\",\"french\":\"Tiplouf\"},\"type\":[\"Water\"],\"base\":{\"HP\":53,\"Attack\":51,\"Defense\":53,\"Sp. Attack\":61,\"Sp. Defense\":56,\"Speed\":40}},{\"id\":394,\"name\":{\"english\":\"Prinplup\",\"japanese\":\"ポッタイシ\",\"chinese\":\"波皇子\",\"french\":\"Prinplouf\"},\"type\":[\"Water\"],\"base\":{\"HP\":64,\"Attack\":66,\"Defense\":68,\"Sp. Attack\":81,\"Sp. Defense\":76,\"Speed\":50}},{\"id\":395,\"name\":{\"english\":\"Empoleon\",\"japanese\":\"エンペルト\",\"chinese\":\"帝王拿波\",\"french\":\"Pingoléon\"},\"type\":[\"Water\",\"Steel\"],\"base\":{\"HP\":84,\"Attack\":86,\"Defense\":88,\"Sp. Attack\":111,\"Sp. Defense\":101,\"Speed\":60}},{\"id\":396,\"name\":{\"english\":\"Starly\",\"japanese\":\"ムックル\",\"chinese\":\"姆克儿\",\"french\":\"Étourmi\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":40,\"Attack\":55,\"Defense\":30,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":60}},{\"id\":397,\"name\":{\"english\":\"Staravia\",\"japanese\":\"ムクバード\",\"chinese\":\"姆克鸟\",\"french\":\"Étourvol\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":55,\"Attack\":75,\"Defense\":50,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":80}},{\"id\":398,\"name\":{\"english\":\"Staraptor\",\"japanese\":\"ムクホーク\",\"chinese\":\"姆克鹰\",\"french\":\"Étouraptor\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":85,\"Attack\":120,\"Defense\":70,\"Sp. Attack\":50,\"Sp. Defense\":60,\"Speed\":100}},{\"id\":399,\"name\":{\"english\":\"Bidoof\",\"japanese\":\"ビッパ\",\"chinese\":\"大牙狸\",\"french\":\"Keunotor\"},\"type\":[\"Normal\"],\"base\":{\"HP\":59,\"Attack\":45,\"Defense\":40,\"Sp. Attack\":35,\"Sp. Defense\":40,\"Speed\":31}},{\"id\":400,\"name\":{\"english\":\"Bibarel\",\"japanese\":\"ビーダル\",\"chinese\":\"大尾狸\",\"french\":\"Castorno\"},\"type\":[\"Normal\",\"Water\"],\"base\":{\"HP\":79,\"Attack\":85,\"Defense\":60,\"Sp. Attack\":55,\"Sp. Defense\":60,\"Speed\":71}},{\"id\":401,\"name\":{\"english\":\"Kricketot\",\"japanese\":\"コロボーシ\",\"chinese\":\"圆法师\",\"french\":\"Crikzik\"},\"type\":[\"Bug\"],\"base\":{\"HP\":37,\"Attack\":25,\"Defense\":41,\"Sp. Attack\":25,\"Sp. Defense\":41,\"Speed\":25}},{\"id\":402,\"name\":{\"english\":\"Kricketune\",\"japanese\":\"コロトック\",\"chinese\":\"音箱蟀\",\"french\":\"Mélokrik\"},\"type\":[\"Bug\"],\"base\":{\"HP\":77,\"Attack\":85,\"Defense\":51,\"Sp. Attack\":55,\"Sp. Defense\":51,\"Speed\":65}},{\"id\":403,\"name\":{\"english\":\"Shinx\",\"japanese\":\"コリンク\",\"chinese\":\"小猫怪\",\"french\":\"Lixy\"},\"type\":[\"Electric\"],\"base\":{\"HP\":45,\"Attack\":65,\"Defense\":34,\"Sp. Attack\":40,\"Sp. Defense\":34,\"Speed\":45}},{\"id\":404,\"name\":{\"english\":\"Luxio\",\"japanese\":\"ルクシオ\",\"chinese\":\"勒克猫\",\"french\":\"Luxio\"},\"type\":[\"Electric\"],\"base\":{\"HP\":60,\"Attack\":85,\"Defense\":49,\"Sp. Attack\":60,\"Sp. Defense\":49,\"Speed\":60}},{\"id\":405,\"name\":{\"english\":\"Luxray\",\"japanese\":\"レントラー\",\"chinese\":\"伦琴猫\",\"french\":\"Luxray\"},\"type\":[\"Electric\"],\"base\":{\"HP\":80,\"Attack\":120,\"Defense\":79,\"Sp. Attack\":95,\"Sp. Defense\":79,\"Speed\":70}},{\"id\":406,\"name\":{\"english\":\"Budew\",\"japanese\":\"スボミー\",\"chinese\":\"含羞苞\",\"french\":\"Rozbouton\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":40,\"Attack\":30,\"Defense\":35,\"Sp. Attack\":50,\"Sp. Defense\":70,\"Speed\":55}},{\"id\":407,\"name\":{\"english\":\"Roserade\",\"japanese\":\"ロズレイド\",\"chinese\":\"罗丝雷朵\",\"french\":\"Roserade\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":60,\"Attack\":70,\"Defense\":65,\"Sp. Attack\":125,\"Sp. Defense\":105,\"Speed\":90}},{\"id\":408,\"name\":{\"english\":\"Cranidos\",\"japanese\":\"ズガイドス\",\"chinese\":\"头盖龙\",\"french\":\"Kranidos\"},\"type\":[\"Rock\"],\"base\":{\"HP\":67,\"Attack\":125,\"Defense\":40,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":58}},{\"id\":409,\"name\":{\"english\":\"Rampardos\",\"japanese\":\"ラムパルド\",\"chinese\":\"战槌龙\",\"french\":\"Charkos\"},\"type\":[\"Rock\"],\"base\":{\"HP\":97,\"Attack\":165,\"Defense\":60,\"Sp. Attack\":65,\"Sp. Defense\":50,\"Speed\":58}},{\"id\":410,\"name\":{\"english\":\"Shieldon\",\"japanese\":\"タテトプス\",\"chinese\":\"盾甲龙\",\"french\":\"Dinoclier\"},\"type\":[\"Rock\",\"Steel\"],\"base\":{\"HP\":30,\"Attack\":42,\"Defense\":118,\"Sp. Attack\":42,\"Sp. Defense\":88,\"Speed\":30}},{\"id\":411,\"name\":{\"english\":\"Bastiodon\",\"japanese\":\"トリデプス\",\"chinese\":\"护城龙\",\"french\":\"Bastiodon\"},\"type\":[\"Rock\",\"Steel\"],\"base\":{\"HP\":60,\"Attack\":52,\"Defense\":168,\"Sp. Attack\":47,\"Sp. Defense\":138,\"Speed\":30}},{\"id\":412,\"name\":{\"english\":\"Burmy\",\"japanese\":\"ミノムッチ\",\"chinese\":\"结草儿\",\"french\":\"Cheniti\"},\"type\":[\"Bug\"],\"base\":{\"HP\":40,\"Attack\":29,\"Defense\":45,\"Sp. Attack\":29,\"Sp. Defense\":45,\"Speed\":36}},{\"id\":413,\"name\":{\"english\":\"Wormadam\",\"japanese\":\"ミノマダム\",\"chinese\":\"结草贵妇\",\"french\":\"Cheniselle\"},\"type\":[\"Bug\",\"Grass\"],\"base\":{\"HP\":60,\"Attack\":59,\"Defense\":85,\"Sp. Attack\":79,\"Sp. Defense\":105,\"Speed\":36}},{\"id\":414,\"name\":{\"english\":\"Mothim\",\"japanese\":\"ガーメイル\",\"chinese\":\"绅士蛾\",\"french\":\"Papilord\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":70,\"Attack\":94,\"Defense\":50,\"Sp. Attack\":94,\"Sp. Defense\":50,\"Speed\":66}},{\"id\":415,\"name\":{\"english\":\"Combee\",\"japanese\":\"ミツハニー\",\"chinese\":\"三蜜蜂\",\"french\":\"Apitrini\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":30,\"Attack\":30,\"Defense\":42,\"Sp. Attack\":30,\"Sp. Defense\":42,\"Speed\":70}},{\"id\":416,\"name\":{\"english\":\"Vespiquen\",\"japanese\":\"ビークイン\",\"chinese\":\"蜂女王\",\"french\":\"Apireine\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":70,\"Attack\":80,\"Defense\":102,\"Sp. Attack\":80,\"Sp. Defense\":102,\"Speed\":40}},{\"id\":417,\"name\":{\"english\":\"Pachirisu\",\"japanese\":\"パチリス\",\"chinese\":\"帕奇利兹\",\"french\":\"Pachirisu\"},\"type\":[\"Electric\"],\"base\":{\"HP\":60,\"Attack\":45,\"Defense\":70,\"Sp. Attack\":45,\"Sp. Defense\":90,\"Speed\":95}},{\"id\":418,\"name\":{\"english\":\"Buizel\",\"japanese\":\"ブイゼル\",\"chinese\":\"泳圈鼬\",\"french\":\"Mustébouée\"},\"type\":[\"Water\"],\"base\":{\"HP\":55,\"Attack\":65,\"Defense\":35,\"Sp. Attack\":60,\"Sp. Defense\":30,\"Speed\":85}},{\"id\":419,\"name\":{\"english\":\"Floatzel\",\"japanese\":\"フローゼル\",\"chinese\":\"浮潜鼬\",\"french\":\"Mustéflott\"},\"type\":[\"Water\"],\"base\":{\"HP\":85,\"Attack\":105,\"Defense\":55,\"Sp. Attack\":85,\"Sp. Defense\":50,\"Speed\":115}},{\"id\":420,\"name\":{\"english\":\"Cherubi\",\"japanese\":\"チェリンボ\",\"chinese\":\"樱花宝\",\"french\":\"Ceribou\"},\"type\":[\"Grass\"],\"base\":{\"HP\":45,\"Attack\":35,\"Defense\":45,\"Sp. Attack\":62,\"Sp. Defense\":53,\"Speed\":35}},{\"id\":421,\"name\":{\"english\":\"Cherrim\",\"japanese\":\"チェリム\",\"chinese\":\"樱花儿\",\"french\":\"Ceriflor\"},\"type\":[\"Grass\"],\"base\":{\"HP\":70,\"Attack\":60,\"Defense\":70,\"Sp. Attack\":87,\"Sp. Defense\":78,\"Speed\":85}},{\"id\":422,\"name\":{\"english\":\"Shellos\",\"japanese\":\"カラナクシ\",\"chinese\":\"无壳海兔\",\"french\":\"Sancoki\"},\"type\":[\"Water\"],\"base\":{\"HP\":76,\"Attack\":48,\"Defense\":48,\"Sp. Attack\":57,\"Sp. Defense\":62,\"Speed\":34}},{\"id\":423,\"name\":{\"english\":\"Gastrodon\",\"japanese\":\"トリトドン\",\"chinese\":\"海兔兽\",\"french\":\"Tritosor\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":111,\"Attack\":83,\"Defense\":68,\"Sp. Attack\":92,\"Sp. Defense\":82,\"Speed\":39}},{\"id\":424,\"name\":{\"english\":\"Ambipom\",\"japanese\":\"エテボース\",\"chinese\":\"双尾怪手\",\"french\":\"Capidextre\"},\"type\":[\"Normal\"],\"base\":{\"HP\":75,\"Attack\":100,\"Defense\":66,\"Sp. Attack\":60,\"Sp. Defense\":66,\"Speed\":115}},{\"id\":425,\"name\":{\"english\":\"Drifloon\",\"japanese\":\"フワンテ\",\"chinese\":\"飘飘球\",\"french\":\"Baudrive\"},\"type\":[\"Ghost\",\"Flying\"],\"base\":{\"HP\":90,\"Attack\":50,\"Defense\":34,\"Sp. Attack\":60,\"Sp. Defense\":44,\"Speed\":70}},{\"id\":426,\"name\":{\"english\":\"Drifblim\",\"japanese\":\"フワライド\",\"chinese\":\"随风球\",\"french\":\"Grodrive\"},\"type\":[\"Ghost\",\"Flying\"],\"base\":{\"HP\":150,\"Attack\":80,\"Defense\":44,\"Sp. Attack\":90,\"Sp. Defense\":54,\"Speed\":80}},{\"id\":427,\"name\":{\"english\":\"Buneary\",\"japanese\":\"ミミロル\",\"chinese\":\"卷卷耳\",\"french\":\"Laporeille\"},\"type\":[\"Normal\"],\"base\":{\"HP\":55,\"Attack\":66,\"Defense\":44,\"Sp. Attack\":44,\"Sp. Defense\":56,\"Speed\":85}},{\"id\":428,\"name\":{\"english\":\"Lopunny\",\"japanese\":\"ミミロップ\",\"chinese\":\"长耳兔\",\"french\":\"Lockpin\"},\"type\":[\"Normal\"],\"base\":{\"HP\":65,\"Attack\":76,\"Defense\":84,\"Sp. Attack\":54,\"Sp. Defense\":96,\"Speed\":105}},{\"id\":429,\"name\":{\"english\":\"Mismagius\",\"japanese\":\"ムウマージ\",\"chinese\":\"梦妖魔\",\"french\":\"Magirêve\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":60,\"Sp. Attack\":105,\"Sp. Defense\":105,\"Speed\":105}},{\"id\":430,\"name\":{\"english\":\"Honchkrow\",\"japanese\":\"ドンカラス\",\"chinese\":\"乌鸦头头\",\"french\":\"Corboss\"},\"type\":[\"Dark\",\"Flying\"],\"base\":{\"HP\":100,\"Attack\":125,\"Defense\":52,\"Sp. Attack\":105,\"Sp. Defense\":52,\"Speed\":71}},{\"id\":431,\"name\":{\"english\":\"Glameow\",\"japanese\":\"ニャルマー\",\"chinese\":\"魅力喵\",\"french\":\"Chaglam\"},\"type\":[\"Normal\"],\"base\":{\"HP\":49,\"Attack\":55,\"Defense\":42,\"Sp. Attack\":42,\"Sp. Defense\":37,\"Speed\":85}},{\"id\":432,\"name\":{\"english\":\"Purugly\",\"japanese\":\"ブニャット\",\"chinese\":\"东施喵\",\"french\":\"Chaffreux\"},\"type\":[\"Normal\"],\"base\":{\"HP\":71,\"Attack\":82,\"Defense\":64,\"Sp. Attack\":64,\"Sp. Defense\":59,\"Speed\":112}},{\"id\":433,\"name\":{\"english\":\"Chingling\",\"japanese\":\"リーシャン\",\"chinese\":\"铃铛响\",\"french\":\"Korillon\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":45,\"Attack\":30,\"Defense\":50,\"Sp. Attack\":65,\"Sp. Defense\":50,\"Speed\":45}},{\"id\":434,\"name\":{\"english\":\"Stunky\",\"japanese\":\"スカンプー\",\"chinese\":\"臭鼬噗\",\"french\":\"Moufouette\"},\"type\":[\"Poison\",\"Dark\"],\"base\":{\"HP\":63,\"Attack\":63,\"Defense\":47,\"Sp. Attack\":41,\"Sp. Defense\":41,\"Speed\":74}},{\"id\":435,\"name\":{\"english\":\"Skuntank\",\"japanese\":\"スカタンク\",\"chinese\":\"坦克臭鼬\",\"french\":\"Moufflair\"},\"type\":[\"Poison\",\"Dark\"],\"base\":{\"HP\":103,\"Attack\":93,\"Defense\":67,\"Sp. Attack\":71,\"Sp. Defense\":61,\"Speed\":84}},{\"id\":436,\"name\":{\"english\":\"Bronzor\",\"japanese\":\"ドーミラー\",\"chinese\":\"铜镜怪\",\"french\":\"Archéomire\"},\"type\":[\"Steel\",\"Psychic\"],\"base\":{\"HP\":57,\"Attack\":24,\"Defense\":86,\"Sp. Attack\":24,\"Sp. Defense\":86,\"Speed\":23}},{\"id\":437,\"name\":{\"english\":\"Bronzong\",\"japanese\":\"ドータクン\",\"chinese\":\"青铜钟\",\"french\":\"Archéodong\"},\"type\":[\"Steel\",\"Psychic\"],\"base\":{\"HP\":67,\"Attack\":89,\"Defense\":116,\"Sp. Attack\":79,\"Sp. Defense\":116,\"Speed\":33}},{\"id\":438,\"name\":{\"english\":\"Bonsly\",\"japanese\":\"ウソハチ\",\"chinese\":\"盆才怪\",\"french\":\"Manzaï\"},\"type\":[\"Rock\"],\"base\":{\"HP\":50,\"Attack\":80,\"Defense\":95,\"Sp. Attack\":10,\"Sp. Defense\":45,\"Speed\":10}},{\"id\":439,\"name\":{\"english\":\"Mime Jr.\",\"japanese\":\"マネネ\",\"chinese\":\"魔尼尼\",\"french\":\"Mime Jr\"},\"type\":[\"Psychic\",\"Fairy\"],\"base\":{\"HP\":20,\"Attack\":25,\"Defense\":45,\"Sp. Attack\":70,\"Sp. Defense\":90,\"Speed\":60}},{\"id\":440,\"name\":{\"english\":\"Happiny\",\"japanese\":\"ピンプク\",\"chinese\":\"小福蛋\",\"french\":\"Ptiravi\"},\"type\":[\"Normal\"],\"base\":{\"HP\":100,\"Attack\":5,\"Defense\":5,\"Sp. Attack\":15,\"Sp. Defense\":65,\"Speed\":30}},{\"id\":441,\"name\":{\"english\":\"Chatot\",\"japanese\":\"ペラップ\",\"chinese\":\"聒噪鸟\",\"french\":\"Pijako\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":76,\"Attack\":65,\"Defense\":45,\"Sp. Attack\":92,\"Sp. Defense\":42,\"Speed\":91}},{\"id\":442,\"name\":{\"english\":\"Spiritomb\",\"japanese\":\"ミカルゲ\",\"chinese\":\"花岩怪\",\"french\":\"Spiritomb\"},\"type\":[\"Ghost\",\"Dark\"],\"base\":{\"HP\":50,\"Attack\":92,\"Defense\":108,\"Sp. Attack\":92,\"Sp. Defense\":108,\"Speed\":35}},{\"id\":443,\"name\":{\"english\":\"Gible\",\"japanese\":\"フカマル\",\"chinese\":\"圆陆鲨\",\"french\":\"Griknot\"},\"type\":[\"Dragon\",\"Ground\"],\"base\":{\"HP\":58,\"Attack\":70,\"Defense\":45,\"Sp. Attack\":40,\"Sp. Defense\":45,\"Speed\":42}},{\"id\":444,\"name\":{\"english\":\"Gabite\",\"japanese\":\"ガバイト\",\"chinese\":\"尖牙陆鲨\",\"french\":\"Carmache\"},\"type\":[\"Dragon\",\"Ground\"],\"base\":{\"HP\":68,\"Attack\":90,\"Defense\":65,\"Sp. Attack\":50,\"Sp. Defense\":55,\"Speed\":82}},{\"id\":445,\"name\":{\"english\":\"Garchomp\",\"japanese\":\"ガブリアス\",\"chinese\":\"烈咬陆鲨\",\"french\":\"Carchacrok\"},\"type\":[\"Dragon\",\"Ground\"],\"base\":{\"HP\":108,\"Attack\":130,\"Defense\":95,\"Sp. Attack\":80,\"Sp. Defense\":85,\"Speed\":102}},{\"id\":446,\"name\":{\"english\":\"Munchlax\",\"japanese\":\"ゴンベ\",\"chinese\":\"小卡比兽\",\"french\":\"Goinfrex\"},\"type\":[\"Normal\"],\"base\":{\"HP\":135,\"Attack\":85,\"Defense\":40,\"Sp. Attack\":40,\"Sp. Defense\":85,\"Speed\":5}},{\"id\":447,\"name\":{\"english\":\"Riolu\",\"japanese\":\"リオル\",\"chinese\":\"利欧路\",\"french\":\"Riolu\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":40,\"Attack\":70,\"Defense\":40,\"Sp. Attack\":35,\"Sp. Defense\":40,\"Speed\":60}},{\"id\":448,\"name\":{\"english\":\"Lucario\",\"japanese\":\"ルカリオ\",\"chinese\":\"路卡利欧\",\"french\":\"Lucario\"},\"type\":[\"Fighting\",\"Steel\"],\"base\":{\"HP\":70,\"Attack\":110,\"Defense\":70,\"Sp. Attack\":115,\"Sp. Defense\":70,\"Speed\":90}},{\"id\":449,\"name\":{\"english\":\"Hippopotas\",\"japanese\":\"ヒポポタス\",\"chinese\":\"沙河马\",\"french\":\"Hippopotas\"},\"type\":[\"Ground\"],\"base\":{\"HP\":68,\"Attack\":72,\"Defense\":78,\"Sp. Attack\":38,\"Sp. Defense\":42,\"Speed\":32}},{\"id\":450,\"name\":{\"english\":\"Hippowdon\",\"japanese\":\"カバルドン\",\"chinese\":\"河马兽\",\"french\":\"Hippodocus\"},\"type\":[\"Ground\"],\"base\":{\"HP\":108,\"Attack\":112,\"Defense\":118,\"Sp. Attack\":68,\"Sp. Defense\":72,\"Speed\":47}},{\"id\":451,\"name\":{\"english\":\"Skorupi\",\"japanese\":\"スコルピ\",\"chinese\":\"钳尾蝎\",\"french\":\"Rapion\"},\"type\":[\"Poison\",\"Bug\"],\"base\":{\"HP\":40,\"Attack\":50,\"Defense\":90,\"Sp. Attack\":30,\"Sp. Defense\":55,\"Speed\":65}},{\"id\":452,\"name\":{\"english\":\"Drapion\",\"japanese\":\"ドラピオン\",\"chinese\":\"龙王蝎\",\"french\":\"Drascore\"},\"type\":[\"Poison\",\"Dark\"],\"base\":{\"HP\":70,\"Attack\":90,\"Defense\":110,\"Sp. Attack\":60,\"Sp. Defense\":75,\"Speed\":95}},{\"id\":453,\"name\":{\"english\":\"Croagunk\",\"japanese\":\"グレッグル\",\"chinese\":\"不良蛙\",\"french\":\"Cradopaud\"},\"type\":[\"Poison\",\"Fighting\"],\"base\":{\"HP\":48,\"Attack\":61,\"Defense\":40,\"Sp. Attack\":61,\"Sp. Defense\":40,\"Speed\":50}},{\"id\":454,\"name\":{\"english\":\"Toxicroak\",\"japanese\":\"ドクロッグ\",\"chinese\":\"毒骷蛙\",\"french\":\"Coatox\"},\"type\":[\"Poison\",\"Fighting\"],\"base\":{\"HP\":83,\"Attack\":106,\"Defense\":65,\"Sp. Attack\":86,\"Sp. Defense\":65,\"Speed\":85}},{\"id\":455,\"name\":{\"english\":\"Carnivine\",\"japanese\":\"マスキッパ\",\"chinese\":\"尖牙笼\",\"french\":\"Vortente\"},\"type\":[\"Grass\"],\"base\":{\"HP\":74,\"Attack\":100,\"Defense\":72,\"Sp. Attack\":90,\"Sp. Defense\":72,\"Speed\":46}},{\"id\":456,\"name\":{\"english\":\"Finneon\",\"japanese\":\"ケイコウオ\",\"chinese\":\"荧光鱼\",\"french\":\"Écayon\"},\"type\":[\"Water\"],\"base\":{\"HP\":49,\"Attack\":49,\"Defense\":56,\"Sp. Attack\":49,\"Sp. Defense\":61,\"Speed\":66}},{\"id\":457,\"name\":{\"english\":\"Lumineon\",\"japanese\":\"ネオラント\",\"chinese\":\"霓虹鱼\",\"french\":\"Luminéon\"},\"type\":[\"Water\"],\"base\":{\"HP\":69,\"Attack\":69,\"Defense\":76,\"Sp. Attack\":69,\"Sp. Defense\":86,\"Speed\":91}},{\"id\":458,\"name\":{\"english\":\"Mantyke\",\"japanese\":\"タマンタ\",\"chinese\":\"小球飞鱼\",\"french\":\"Babimanta\"},\"type\":[\"Water\",\"Flying\"],\"base\":{\"HP\":45,\"Attack\":20,\"Defense\":50,\"Sp. Attack\":60,\"Sp. Defense\":120,\"Speed\":50}},{\"id\":459,\"name\":{\"english\":\"Snover\",\"japanese\":\"ユキカブリ\",\"chinese\":\"雪笠怪\",\"french\":\"Blizzi\"},\"type\":[\"Grass\",\"Ice\"],\"base\":{\"HP\":60,\"Attack\":62,\"Defense\":50,\"Sp. Attack\":62,\"Sp. Defense\":60,\"Speed\":40}},{\"id\":460,\"name\":{\"english\":\"Abomasnow\",\"japanese\":\"ユキノオー\",\"chinese\":\"暴雪王\",\"french\":\"Blizzaroi\"},\"type\":[\"Grass\",\"Ice\"],\"base\":{\"HP\":90,\"Attack\":92,\"Defense\":75,\"Sp. Attack\":92,\"Sp. Defense\":85,\"Speed\":60}},{\"id\":461,\"name\":{\"english\":\"Weavile\",\"japanese\":\"マニューラ\",\"chinese\":\"玛狃拉\",\"french\":\"Dimoret\"},\"type\":[\"Dark\",\"Ice\"],\"base\":{\"HP\":70,\"Attack\":120,\"Defense\":65,\"Sp. Attack\":45,\"Sp. Defense\":85,\"Speed\":125}},{\"id\":462,\"name\":{\"english\":\"Magnezone\",\"japanese\":\"ジバコイル\",\"chinese\":\"自爆磁怪\",\"french\":\"Magnézone\"},\"type\":[\"Electric\",\"Steel\"],\"base\":{\"HP\":70,\"Attack\":70,\"Defense\":115,\"Sp. Attack\":130,\"Sp. Defense\":90,\"Speed\":60}},{\"id\":463,\"name\":{\"english\":\"Lickilicky\",\"japanese\":\"ベロベルト\",\"chinese\":\"大舌舔\",\"french\":\"Coudlangue\"},\"type\":[\"Normal\"],\"base\":{\"HP\":110,\"Attack\":85,\"Defense\":95,\"Sp. Attack\":80,\"Sp. Defense\":95,\"Speed\":50}},{\"id\":464,\"name\":{\"english\":\"Rhyperior\",\"japanese\":\"ドサイドン\",\"chinese\":\"超甲狂犀\",\"french\":\"Rhinastoc\"},\"type\":[\"Ground\",\"Rock\"],\"base\":{\"HP\":115,\"Attack\":140,\"Defense\":130,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":40}},{\"id\":465,\"name\":{\"english\":\"Tangrowth\",\"japanese\":\"モジャンボ\",\"chinese\":\"巨蔓藤\",\"french\":\"Bouldeneu\"},\"type\":[\"Grass\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":125,\"Sp. Attack\":110,\"Sp. Defense\":50,\"Speed\":50}},{\"id\":466,\"name\":{\"english\":\"Electivire\",\"japanese\":\"エレキブル\",\"chinese\":\"电击魔兽\",\"french\":\"Élekable\"},\"type\":[\"Electric\"],\"base\":{\"HP\":75,\"Attack\":123,\"Defense\":67,\"Sp. Attack\":95,\"Sp. Defense\":85,\"Speed\":95}},{\"id\":467,\"name\":{\"english\":\"Magmortar\",\"japanese\":\"ブーバーン\",\"chinese\":\"鸭嘴炎兽\",\"french\":\"Maganon\"},\"type\":[\"Fire\"],\"base\":{\"HP\":75,\"Attack\":95,\"Defense\":67,\"Sp. Attack\":125,\"Sp. Defense\":95,\"Speed\":83}},{\"id\":468,\"name\":{\"english\":\"Togekiss\",\"japanese\":\"トゲキッス\",\"chinese\":\"波克基斯\",\"french\":\"Togekiss\"},\"type\":[\"Fairy\",\"Flying\"],\"base\":{\"HP\":85,\"Attack\":50,\"Defense\":95,\"Sp. Attack\":120,\"Sp. Defense\":115,\"Speed\":80}},{\"id\":469,\"name\":{\"english\":\"Yanmega\",\"japanese\":\"メガヤンマ\",\"chinese\":\"远古巨蜓\",\"french\":\"Yanmega\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":86,\"Attack\":76,\"Defense\":86,\"Sp. Attack\":116,\"Sp. Defense\":56,\"Speed\":95}},{\"id\":470,\"name\":{\"english\":\"Leafeon\",\"japanese\":\"リーフィア\",\"chinese\":\"叶伊布\",\"french\":\"Phyllali\"},\"type\":[\"Grass\"],\"base\":{\"HP\":65,\"Attack\":110,\"Defense\":130,\"Sp. Attack\":60,\"Sp. Defense\":65,\"Speed\":95}},{\"id\":471,\"name\":{\"english\":\"Glaceon\",\"japanese\":\"グレイシア\",\"chinese\":\"冰伊布\",\"french\":\"Givrali\"},\"type\":[\"Ice\"],\"base\":{\"HP\":65,\"Attack\":60,\"Defense\":110,\"Sp. Attack\":130,\"Sp. Defense\":95,\"Speed\":65}},{\"id\":472,\"name\":{\"english\":\"Gliscor\",\"japanese\":\"グライオン\",\"chinese\":\"天蝎王\",\"french\":\"Scorvol\"},\"type\":[\"Ground\",\"Flying\"],\"base\":{\"HP\":75,\"Attack\":95,\"Defense\":125,\"Sp. Attack\":45,\"Sp. Defense\":75,\"Speed\":95}},{\"id\":473,\"name\":{\"english\":\"Mamoswine\",\"japanese\":\"マンムー\",\"chinese\":\"象牙猪\",\"french\":\"Mammochon\"},\"type\":[\"Ice\",\"Ground\"],\"base\":{\"HP\":110,\"Attack\":130,\"Defense\":80,\"Sp. Attack\":70,\"Sp. Defense\":60,\"Speed\":80}},{\"id\":474,\"name\":{\"english\":\"Porygon-Z\",\"japanese\":\"ポリゴンＺ\",\"chinese\":\"多边兽Ｚ\",\"french\":\"Porygon-Z\"},\"type\":[\"Normal\"],\"base\":{\"HP\":85,\"Attack\":80,\"Defense\":70,\"Sp. Attack\":135,\"Sp. Defense\":75,\"Speed\":90}},{\"id\":475,\"name\":{\"english\":\"Gallade\",\"japanese\":\"エルレイド\",\"chinese\":\"艾路雷朵\",\"french\":\"Gallame\"},\"type\":[\"Psychic\",\"Fighting\"],\"base\":{\"HP\":68,\"Attack\":125,\"Defense\":65,\"Sp. Attack\":65,\"Sp. Defense\":115,\"Speed\":80}},{\"id\":476,\"name\":{\"english\":\"Probopass\",\"japanese\":\"ダイノーズ\",\"chinese\":\"大朝北鼻\",\"french\":\"Tarinorme\"},\"type\":[\"Rock\",\"Steel\"],\"base\":{\"HP\":60,\"Attack\":55,\"Defense\":145,\"Sp. Attack\":75,\"Sp. Defense\":150,\"Speed\":40}},{\"id\":477,\"name\":{\"english\":\"Dusknoir\",\"japanese\":\"ヨノワール\",\"chinese\":\"黑夜魔灵\",\"french\":\"Noctunoir\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":45,\"Attack\":100,\"Defense\":135,\"Sp. Attack\":65,\"Sp. Defense\":135,\"Speed\":45}},{\"id\":478,\"name\":{\"english\":\"Froslass\",\"japanese\":\"ユキメノコ\",\"chinese\":\"雪妖女\",\"french\":\"Momartik\"},\"type\":[\"Ice\",\"Ghost\"],\"base\":{\"HP\":70,\"Attack\":80,\"Defense\":70,\"Sp. Attack\":80,\"Sp. Defense\":70,\"Speed\":110}},{\"id\":479,\"name\":{\"english\":\"Rotom\",\"japanese\":\"ロトム\",\"chinese\":\"洛托姆\",\"french\":\"Motisma\"},\"type\":[\"Electric\",\"Ghost\"],\"base\":{\"HP\":50,\"Attack\":50,\"Defense\":77,\"Sp. Attack\":95,\"Sp. Defense\":77,\"Speed\":91}},{\"id\":480,\"name\":{\"english\":\"Uxie\",\"japanese\":\"ユクシー\",\"chinese\":\"由克希\",\"french\":\"Créhelf\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":75,\"Attack\":75,\"Defense\":130,\"Sp. Attack\":75,\"Sp. Defense\":130,\"Speed\":95}},{\"id\":481,\"name\":{\"english\":\"Mesprit\",\"japanese\":\"エムリット\",\"chinese\":\"艾姆利多\",\"french\":\"Créfollet\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":80,\"Attack\":105,\"Defense\":105,\"Sp. Attack\":105,\"Sp. Defense\":105,\"Speed\":80}},{\"id\":482,\"name\":{\"english\":\"Azelf\",\"japanese\":\"アグノム\",\"chinese\":\"亚克诺姆\",\"french\":\"Créfadet\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":75,\"Attack\":125,\"Defense\":70,\"Sp. Attack\":125,\"Sp. Defense\":70,\"Speed\":115}},{\"id\":483,\"name\":{\"english\":\"Dialga\",\"japanese\":\"ディアルガ\",\"chinese\":\"帝牙卢卡\",\"french\":\"Dialga\"},\"type\":[\"Steel\",\"Dragon\"],\"base\":{\"HP\":100,\"Attack\":120,\"Defense\":120,\"Sp. Attack\":150,\"Sp. Defense\":100,\"Speed\":90}},{\"id\":484,\"name\":{\"english\":\"Palkia\",\"japanese\":\"パルキア\",\"chinese\":\"帕路奇亚\",\"french\":\"Palkia\"},\"type\":[\"Water\",\"Dragon\"],\"base\":{\"HP\":90,\"Attack\":120,\"Defense\":100,\"Sp. Attack\":150,\"Sp. Defense\":120,\"Speed\":100}},{\"id\":485,\"name\":{\"english\":\"Heatran\",\"japanese\":\"ヒードラン\",\"chinese\":\"席多蓝恩\",\"french\":\"Heatran\"},\"type\":[\"Fire\",\"Steel\"],\"base\":{\"HP\":91,\"Attack\":90,\"Defense\":106,\"Sp. Attack\":130,\"Sp. Defense\":106,\"Speed\":77}},{\"id\":486,\"name\":{\"english\":\"Regigigas\",\"japanese\":\"レジギガス\",\"chinese\":\"雷吉奇卡斯\",\"french\":\"Regigigas\"},\"type\":[\"Normal\"],\"base\":{\"HP\":110,\"Attack\":160,\"Defense\":110,\"Sp. Attack\":80,\"Sp. Defense\":110,\"Speed\":100}},{\"id\":487,\"name\":{\"english\":\"Giratina\",\"japanese\":\"ギラティナ\",\"chinese\":\"骑拉帝纳\",\"french\":\"Giratina\"},\"type\":[\"Ghost\",\"Dragon\"],\"base\":{\"HP\":150,\"Attack\":100,\"Defense\":120,\"Sp. Attack\":100,\"Sp. Defense\":120,\"Speed\":90}},{\"id\":488,\"name\":{\"english\":\"Cresselia\",\"japanese\":\"クレセリア\",\"chinese\":\"克雷色利亚\",\"french\":\"Cresselia\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":120,\"Attack\":70,\"Defense\":120,\"Sp. Attack\":75,\"Sp. Defense\":130,\"Speed\":85}},{\"id\":489,\"name\":{\"english\":\"Phione\",\"japanese\":\"フィオネ\",\"chinese\":\"霏欧纳\",\"french\":\"Phione\"},\"type\":[\"Water\"],\"base\":{\"HP\":80,\"Attack\":80,\"Defense\":80,\"Sp. Attack\":80,\"Sp. Defense\":80,\"Speed\":80}},{\"id\":490,\"name\":{\"english\":\"Manaphy\",\"japanese\":\"マナフィ\",\"chinese\":\"玛纳霏\",\"french\":\"Manaphy\"},\"type\":[\"Water\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":100,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":100}},{\"id\":491,\"name\":{\"english\":\"Darkrai\",\"japanese\":\"ダークライ\",\"chinese\":\"达克莱伊\",\"french\":\"Darkrai\"},\"type\":[\"Dark\"],\"base\":{\"HP\":70,\"Attack\":90,\"Defense\":90,\"Sp. Attack\":135,\"Sp. Defense\":90,\"Speed\":125}},{\"id\":492,\"name\":{\"english\":\"Shaymin\",\"japanese\":\"シェイミ\",\"chinese\":\"谢米\",\"french\":\"Shaymin\"},\"type\":[\"Grass\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":100,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":100}},{\"id\":493,\"name\":{\"english\":\"Arceus\",\"japanese\":\"アルセウス\",\"chinese\":\"阿尔宙斯\",\"french\":\"Arceus\"},\"type\":[\"Normal\"],\"base\":{\"HP\":120,\"Attack\":120,\"Defense\":120,\"Sp. Attack\":120,\"Sp. Defense\":120,\"Speed\":120}},{\"id\":494,\"name\":{\"english\":\"Victini\",\"japanese\":\"ビクティニ\",\"chinese\":\"比克提尼\",\"french\":\"Victini\"},\"type\":[\"Psychic\",\"Fire\"],\"base\":{\"HP\":100,\"Attack\":100,\"Defense\":100,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":100}},{\"id\":495,\"name\":{\"english\":\"Snivy\",\"japanese\":\"ツタージャ\",\"chinese\":\"藤藤蛇\",\"french\":\"Vipélierre\"},\"type\":[\"Grass\"],\"base\":{\"HP\":45,\"Attack\":45,\"Defense\":55,\"Sp. Attack\":45,\"Sp. Defense\":55,\"Speed\":63}},{\"id\":496,\"name\":{\"english\":\"Servine\",\"japanese\":\"ジャノビー\",\"chinese\":\"青藤蛇\",\"french\":\"Lianaja\"},\"type\":[\"Grass\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":75,\"Sp. Attack\":60,\"Sp. Defense\":75,\"Speed\":83}},{\"id\":497,\"name\":{\"english\":\"Serperior\",\"japanese\":\"ジャローダ\",\"chinese\":\"君主蛇\",\"french\":\"Majaspic\"},\"type\":[\"Grass\"],\"base\":{\"HP\":75,\"Attack\":75,\"Defense\":95,\"Sp. Attack\":75,\"Sp. Defense\":95,\"Speed\":113}},{\"id\":498,\"name\":{\"english\":\"Tepig\",\"japanese\":\"ポカブ\",\"chinese\":\"暖暖猪\",\"french\":\"Gruikui\"},\"type\":[\"Fire\"],\"base\":{\"HP\":65,\"Attack\":63,\"Defense\":45,\"Sp. Attack\":45,\"Sp. Defense\":45,\"Speed\":45}},{\"id\":499,\"name\":{\"english\":\"Pignite\",\"japanese\":\"チャオブー\",\"chinese\":\"炒炒猪\",\"french\":\"Grotichon\"},\"type\":[\"Fire\",\"Fighting\"],\"base\":{\"HP\":90,\"Attack\":93,\"Defense\":55,\"Sp. Attack\":70,\"Sp. Defense\":55,\"Speed\":55}},{\"id\":500,\"name\":{\"english\":\"Emboar\",\"japanese\":\"エンブオー\",\"chinese\":\"炎武王\",\"french\":\"Roitiflam\"},\"type\":[\"Fire\",\"Fighting\"],\"base\":{\"HP\":110,\"Attack\":123,\"Defense\":65,\"Sp. Attack\":100,\"Sp. Defense\":65,\"Speed\":65}},{\"id\":501,\"name\":{\"english\":\"Oshawott\",\"japanese\":\"ミジュマル\",\"chinese\":\"水水獭\",\"french\":\"Moustillon\"},\"type\":[\"Water\"],\"base\":{\"HP\":55,\"Attack\":55,\"Defense\":45,\"Sp. Attack\":63,\"Sp. Defense\":45,\"Speed\":45}},{\"id\":502,\"name\":{\"english\":\"Dewott\",\"japanese\":\"フタチマル\",\"chinese\":\"双刃丸\",\"french\":\"Mateloutre\"},\"type\":[\"Water\"],\"base\":{\"HP\":75,\"Attack\":75,\"Defense\":60,\"Sp. Attack\":83,\"Sp. Defense\":60,\"Speed\":60}},{\"id\":503,\"name\":{\"english\":\"Samurott\",\"japanese\":\"ダイケンキ\",\"chinese\":\"大剑鬼\",\"french\":\"Clamiral\"},\"type\":[\"Water\"],\"base\":{\"HP\":95,\"Attack\":100,\"Defense\":85,\"Sp. Attack\":108,\"Sp. Defense\":70,\"Speed\":70}},{\"id\":504,\"name\":{\"english\":\"Patrat\",\"japanese\":\"ミネズミ\",\"chinese\":\"探探鼠\",\"french\":\"Ratentif\"},\"type\":[\"Normal\"],\"base\":{\"HP\":45,\"Attack\":55,\"Defense\":39,\"Sp. Attack\":35,\"Sp. Defense\":39,\"Speed\":42}},{\"id\":505,\"name\":{\"english\":\"Watchog\",\"japanese\":\"ミルホッグ\",\"chinese\":\"步哨鼠\",\"french\":\"Miradar\"},\"type\":[\"Normal\"],\"base\":{\"HP\":60,\"Attack\":85,\"Defense\":69,\"Sp. Attack\":60,\"Sp. Defense\":69,\"Speed\":77}},{\"id\":506,\"name\":{\"english\":\"Lillipup\",\"japanese\":\"ヨーテリー\",\"chinese\":\"小约克\",\"french\":\"Ponchiot\"},\"type\":[\"Normal\"],\"base\":{\"HP\":45,\"Attack\":60,\"Defense\":45,\"Sp. Attack\":25,\"Sp. Defense\":45,\"Speed\":55}},{\"id\":507,\"name\":{\"english\":\"Herdier\",\"japanese\":\"ハーデリア\",\"chinese\":\"哈约克\",\"french\":\"Ponchien\"},\"type\":[\"Normal\"],\"base\":{\"HP\":65,\"Attack\":80,\"Defense\":65,\"Sp. Attack\":35,\"Sp. Defense\":65,\"Speed\":60}},{\"id\":508,\"name\":{\"english\":\"Stoutland\",\"japanese\":\"ムーランド\",\"chinese\":\"长毛狗\",\"french\":\"Mastouffe\"},\"type\":[\"Normal\"],\"base\":{\"HP\":85,\"Attack\":110,\"Defense\":90,\"Sp. Attack\":45,\"Sp. Defense\":90,\"Speed\":80}},{\"id\":509,\"name\":{\"english\":\"Purrloin\",\"japanese\":\"チョロネコ\",\"chinese\":\"扒手猫\",\"french\":\"Chacripan\"},\"type\":[\"Dark\"],\"base\":{\"HP\":41,\"Attack\":50,\"Defense\":37,\"Sp. Attack\":50,\"Sp. Defense\":37,\"Speed\":66}},{\"id\":510,\"name\":{\"english\":\"Liepard\",\"japanese\":\"レパルダス\",\"chinese\":\"酷豹\",\"french\":\"Léopardus\"},\"type\":[\"Dark\"],\"base\":{\"HP\":64,\"Attack\":88,\"Defense\":50,\"Sp. Attack\":88,\"Sp. Defense\":50,\"Speed\":106}},{\"id\":511,\"name\":{\"english\":\"Pansage\",\"japanese\":\"ヤナップ\",\"chinese\":\"花椰猴\",\"french\":\"Feuillajou\"},\"type\":[\"Grass\"],\"base\":{\"HP\":50,\"Attack\":53,\"Defense\":48,\"Sp. Attack\":53,\"Sp. Defense\":48,\"Speed\":64}},{\"id\":512,\"name\":{\"english\":\"Simisage\",\"japanese\":\"ヤナッキー\",\"chinese\":\"花椰猿\",\"french\":\"Feuiloutan\"},\"type\":[\"Grass\"],\"base\":{\"HP\":75,\"Attack\":98,\"Defense\":63,\"Sp. Attack\":98,\"Sp. Defense\":63,\"Speed\":101}},{\"id\":513,\"name\":{\"english\":\"Pansear\",\"japanese\":\"バオップ\",\"chinese\":\"爆香猴\",\"french\":\"Flamajou\"},\"type\":[\"Fire\"],\"base\":{\"HP\":50,\"Attack\":53,\"Defense\":48,\"Sp. Attack\":53,\"Sp. Defense\":48,\"Speed\":64}},{\"id\":514,\"name\":{\"english\":\"Simisear\",\"japanese\":\"バオッキー\",\"chinese\":\"爆香猿\",\"french\":\"Flamoutan\"},\"type\":[\"Fire\"],\"base\":{\"HP\":75,\"Attack\":98,\"Defense\":63,\"Sp. Attack\":98,\"Sp. Defense\":63,\"Speed\":101}},{\"id\":515,\"name\":{\"english\":\"Panpour\",\"japanese\":\"ヒヤップ\",\"chinese\":\"冷水猴\",\"french\":\"Flotajou\"},\"type\":[\"Water\"],\"base\":{\"HP\":50,\"Attack\":53,\"Defense\":48,\"Sp. Attack\":53,\"Sp. Defense\":48,\"Speed\":64}},{\"id\":516,\"name\":{\"english\":\"Simipour\",\"japanese\":\"ヒヤッキー\",\"chinese\":\"冷水猿\",\"french\":\"Flotoutan\"},\"type\":[\"Water\"],\"base\":{\"HP\":75,\"Attack\":98,\"Defense\":63,\"Sp. Attack\":98,\"Sp. Defense\":63,\"Speed\":101}},{\"id\":517,\"name\":{\"english\":\"Munna\",\"japanese\":\"ムンナ\",\"chinese\":\"食梦梦\",\"french\":\"Munna\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":76,\"Attack\":25,\"Defense\":45,\"Sp. Attack\":67,\"Sp. Defense\":55,\"Speed\":24}},{\"id\":518,\"name\":{\"english\":\"Musharna\",\"japanese\":\"ムシャーナ\",\"chinese\":\"梦梦蚀\",\"french\":\"Mushana\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":116,\"Attack\":55,\"Defense\":85,\"Sp. Attack\":107,\"Sp. Defense\":95,\"Speed\":29}},{\"id\":519,\"name\":{\"english\":\"Pidove\",\"japanese\":\"マメパト\",\"chinese\":\"豆豆鸽\",\"french\":\"Poichigeon\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":50,\"Attack\":55,\"Defense\":50,\"Sp. Attack\":36,\"Sp. Defense\":30,\"Speed\":43}},{\"id\":520,\"name\":{\"english\":\"Tranquill\",\"japanese\":\"ハトーボー\",\"chinese\":\"咕咕鸽\",\"french\":\"Colombeau\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":62,\"Attack\":77,\"Defense\":62,\"Sp. Attack\":50,\"Sp. Defense\":42,\"Speed\":65}},{\"id\":521,\"name\":{\"english\":\"Unfezant\",\"japanese\":\"ケンホロウ\",\"chinese\":\"高傲雉鸡\",\"french\":\"Déflaisan\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":80,\"Attack\":115,\"Defense\":80,\"Sp. Attack\":65,\"Sp. Defense\":55,\"Speed\":93}},{\"id\":522,\"name\":{\"english\":\"Blitzle\",\"japanese\":\"シママ\",\"chinese\":\"斑斑马\",\"french\":\"Zébibron\"},\"type\":[\"Electric\"],\"base\":{\"HP\":45,\"Attack\":60,\"Defense\":32,\"Sp. Attack\":50,\"Sp. Defense\":32,\"Speed\":76}},{\"id\":523,\"name\":{\"english\":\"Zebstrika\",\"japanese\":\"ゼブライカ\",\"chinese\":\"雷电斑马\",\"french\":\"Zéblitz\"},\"type\":[\"Electric\"],\"base\":{\"HP\":75,\"Attack\":100,\"Defense\":63,\"Sp. Attack\":80,\"Sp. Defense\":63,\"Speed\":116}},{\"id\":524,\"name\":{\"english\":\"Roggenrola\",\"japanese\":\"ダンゴロ\",\"chinese\":\"石丸子\",\"french\":\"Nodulithe\"},\"type\":[\"Rock\"],\"base\":{\"HP\":55,\"Attack\":75,\"Defense\":85,\"Sp. Attack\":25,\"Sp. Defense\":25,\"Speed\":15}},{\"id\":525,\"name\":{\"english\":\"Boldore\",\"japanese\":\"ガントル\",\"chinese\":\"地幔岩\",\"french\":\"Géolithe\"},\"type\":[\"Rock\"],\"base\":{\"HP\":70,\"Attack\":105,\"Defense\":105,\"Sp. Attack\":50,\"Sp. Defense\":40,\"Speed\":20}},{\"id\":526,\"name\":{\"english\":\"Gigalith\",\"japanese\":\"ギガイアス\",\"chinese\":\"庞岩怪\",\"french\":\"Gigalithe\"},\"type\":[\"Rock\"],\"base\":{\"HP\":85,\"Attack\":135,\"Defense\":130,\"Sp. Attack\":60,\"Sp. Defense\":80,\"Speed\":25}},{\"id\":527,\"name\":{\"english\":\"Woobat\",\"japanese\":\"コロモリ\",\"chinese\":\"滚滚蝙蝠\",\"french\":\"Chovsourir\"},\"type\":[\"Psychic\",\"Flying\"],\"base\":{\"HP\":65,\"Attack\":45,\"Defense\":43,\"Sp. Attack\":55,\"Sp. Defense\":43,\"Speed\":72}},{\"id\":528,\"name\":{\"english\":\"Swoobat\",\"japanese\":\"ココロモリ\",\"chinese\":\"心蝙蝠\",\"french\":\"Rhinolove\"},\"type\":[\"Psychic\",\"Flying\"],\"base\":{\"HP\":67,\"Attack\":57,\"Defense\":55,\"Sp. Attack\":77,\"Sp. Defense\":55,\"Speed\":114}},{\"id\":529,\"name\":{\"english\":\"Drilbur\",\"japanese\":\"モグリュー\",\"chinese\":\"螺钉地鼠\",\"french\":\"Rototaupe\"},\"type\":[\"Ground\"],\"base\":{\"HP\":60,\"Attack\":85,\"Defense\":40,\"Sp. Attack\":30,\"Sp. Defense\":45,\"Speed\":68}},{\"id\":530,\"name\":{\"english\":\"Excadrill\",\"japanese\":\"ドリュウズ\",\"chinese\":\"龙头地鼠\",\"french\":\"Minotaupe\"},\"type\":[\"Ground\",\"Steel\"],\"base\":{\"HP\":110,\"Attack\":135,\"Defense\":60,\"Sp. Attack\":50,\"Sp. Defense\":65,\"Speed\":88}},{\"id\":531,\"name\":{\"english\":\"Audino\",\"japanese\":\"タブンネ\",\"chinese\":\"差不多娃娃\",\"french\":\"Nanméouïe\"},\"type\":[\"Normal\"],\"base\":{\"HP\":103,\"Attack\":60,\"Defense\":86,\"Sp. Attack\":60,\"Sp. Defense\":86,\"Speed\":50}},{\"id\":532,\"name\":{\"english\":\"Timburr\",\"japanese\":\"ドッコラー\",\"chinese\":\"搬运小匠\",\"french\":\"Charpenti\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":75,\"Attack\":80,\"Defense\":55,\"Sp. Attack\":25,\"Sp. Defense\":35,\"Speed\":35}},{\"id\":533,\"name\":{\"english\":\"Gurdurr\",\"japanese\":\"ドテッコツ\",\"chinese\":\"铁骨土人\",\"french\":\"Ouvrifier\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":85,\"Attack\":105,\"Defense\":85,\"Sp. Attack\":40,\"Sp. Defense\":50,\"Speed\":40}},{\"id\":534,\"name\":{\"english\":\"Conkeldurr\",\"japanese\":\"ローブシン\",\"chinese\":\"修建老匠\",\"french\":\"Bétochef\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":105,\"Attack\":140,\"Defense\":95,\"Sp. Attack\":55,\"Sp. Defense\":65,\"Speed\":45}},{\"id\":535,\"name\":{\"english\":\"Tympole\",\"japanese\":\"オタマロ\",\"chinese\":\"圆蝌蚪\",\"french\":\"Tritonde\"},\"type\":[\"Water\"],\"base\":{\"HP\":50,\"Attack\":50,\"Defense\":40,\"Sp. Attack\":50,\"Sp. Defense\":40,\"Speed\":64}},{\"id\":536,\"name\":{\"english\":\"Palpitoad\",\"japanese\":\"ガマガル\",\"chinese\":\"蓝蟾蜍\",\"french\":\"Batracné\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":75,\"Attack\":65,\"Defense\":55,\"Sp. Attack\":65,\"Sp. Defense\":55,\"Speed\":69}},{\"id\":537,\"name\":{\"english\":\"Seismitoad\",\"japanese\":\"ガマゲロゲ\",\"chinese\":\"蟾蜍王\",\"french\":\"Crapustule\"},\"type\":[\"Water\",\"Ground\"],\"base\":{\"HP\":105,\"Attack\":95,\"Defense\":75,\"Sp. Attack\":85,\"Sp. Defense\":75,\"Speed\":74}},{\"id\":538,\"name\":{\"english\":\"Throh\",\"japanese\":\"ナゲキ\",\"chinese\":\"投摔鬼\",\"french\":\"Judokrak\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":120,\"Attack\":100,\"Defense\":85,\"Sp. Attack\":30,\"Sp. Defense\":85,\"Speed\":45}},{\"id\":539,\"name\":{\"english\":\"Sawk\",\"japanese\":\"ダゲキ\",\"chinese\":\"打击鬼\",\"french\":\"Karaclée\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":75,\"Attack\":125,\"Defense\":75,\"Sp. Attack\":30,\"Sp. Defense\":75,\"Speed\":85}},{\"id\":540,\"name\":{\"english\":\"Sewaddle\",\"japanese\":\"クルミル\",\"chinese\":\"虫宝包\",\"french\":\"Larveyette\"},\"type\":[\"Bug\",\"Grass\"],\"base\":{\"HP\":45,\"Attack\":53,\"Defense\":70,\"Sp. Attack\":40,\"Sp. Defense\":60,\"Speed\":42}},{\"id\":541,\"name\":{\"english\":\"Swadloon\",\"japanese\":\"クルマユ\",\"chinese\":\"宝包茧\",\"french\":\"Couverdure\"},\"type\":[\"Bug\",\"Grass\"],\"base\":{\"HP\":55,\"Attack\":63,\"Defense\":90,\"Sp. Attack\":50,\"Sp. Defense\":80,\"Speed\":42}},{\"id\":542,\"name\":{\"english\":\"Leavanny\",\"japanese\":\"ハハコモリ\",\"chinese\":\"保姆虫\",\"french\":\"Manternel\"},\"type\":[\"Bug\",\"Grass\"],\"base\":{\"HP\":75,\"Attack\":103,\"Defense\":80,\"Sp. Attack\":70,\"Sp. Defense\":80,\"Speed\":92}},{\"id\":543,\"name\":{\"english\":\"Venipede\",\"japanese\":\"フシデ\",\"chinese\":\"百足蜈蚣\",\"french\":\"Venipatte\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":30,\"Attack\":45,\"Defense\":59,\"Sp. Attack\":30,\"Sp. Defense\":39,\"Speed\":57}},{\"id\":544,\"name\":{\"english\":\"Whirlipede\",\"japanese\":\"ホイーガ\",\"chinese\":\"车轮球\",\"french\":\"Scobolide\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":40,\"Attack\":55,\"Defense\":99,\"Sp. Attack\":40,\"Sp. Defense\":79,\"Speed\":47}},{\"id\":545,\"name\":{\"english\":\"Scolipede\",\"japanese\":\"ペンドラー\",\"chinese\":\"蜈蚣王\",\"french\":\"Brutapode\"},\"type\":[\"Bug\",\"Poison\"],\"base\":{\"HP\":60,\"Attack\":100,\"Defense\":89,\"Sp. Attack\":55,\"Sp. Defense\":69,\"Speed\":112}},{\"id\":546,\"name\":{\"english\":\"Cottonee\",\"japanese\":\"モンメン\",\"chinese\":\"木棉球\",\"french\":\"Doudouvet\"},\"type\":[\"Grass\",\"Fairy\"],\"base\":{\"HP\":40,\"Attack\":27,\"Defense\":60,\"Sp. Attack\":37,\"Sp. Defense\":50,\"Speed\":66}},{\"id\":547,\"name\":{\"english\":\"Whimsicott\",\"japanese\":\"エルフーン\",\"chinese\":\"风妖精\",\"french\":\"Farfaduvet\"},\"type\":[\"Grass\",\"Fairy\"],\"base\":{\"HP\":60,\"Attack\":67,\"Defense\":85,\"Sp. Attack\":77,\"Sp. Defense\":75,\"Speed\":116}},{\"id\":548,\"name\":{\"english\":\"Petilil\",\"japanese\":\"チュリネ\",\"chinese\":\"百合根娃娃\",\"french\":\"Chlorobule\"},\"type\":[\"Grass\"],\"base\":{\"HP\":45,\"Attack\":35,\"Defense\":50,\"Sp. Attack\":70,\"Sp. Defense\":50,\"Speed\":30}},{\"id\":549,\"name\":{\"english\":\"Lilligant\",\"japanese\":\"ドレディア\",\"chinese\":\"裙儿小姐\",\"french\":\"Fragilady\"},\"type\":[\"Grass\"],\"base\":{\"HP\":70,\"Attack\":60,\"Defense\":75,\"Sp. Attack\":110,\"Sp. Defense\":75,\"Speed\":90}},{\"id\":550,\"name\":{\"english\":\"Basculin\",\"japanese\":\"バスラオ\",\"chinese\":\"野蛮鲈鱼\",\"french\":\"Bargantua\"},\"type\":[\"Water\"],\"base\":{\"HP\":70,\"Attack\":92,\"Defense\":65,\"Sp. Attack\":80,\"Sp. Defense\":55,\"Speed\":98}},{\"id\":551,\"name\":{\"english\":\"Sandile\",\"japanese\":\"メグロコ\",\"chinese\":\"黑眼鳄\",\"french\":\"Mascaïman\"},\"type\":[\"Ground\",\"Dark\"],\"base\":{\"HP\":50,\"Attack\":72,\"Defense\":35,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":65}},{\"id\":552,\"name\":{\"english\":\"Krokorok\",\"japanese\":\"ワルビル\",\"chinese\":\"混混鳄\",\"french\":\"Escroco\"},\"type\":[\"Ground\",\"Dark\"],\"base\":{\"HP\":60,\"Attack\":82,\"Defense\":45,\"Sp. Attack\":45,\"Sp. Defense\":45,\"Speed\":74}},{\"id\":553,\"name\":{\"english\":\"Krookodile\",\"japanese\":\"ワルビアル\",\"chinese\":\"流氓鳄\",\"french\":\"Crocorible\"},\"type\":[\"Ground\",\"Dark\"],\"base\":{\"HP\":95,\"Attack\":117,\"Defense\":80,\"Sp. Attack\":65,\"Sp. Defense\":70,\"Speed\":92}},{\"id\":554,\"name\":{\"english\":\"Darumaka\",\"japanese\":\"ダルマッカ\",\"chinese\":\"火红不倒翁\",\"french\":\"Darumarond\"},\"type\":[\"Fire\"],\"base\":{\"HP\":70,\"Attack\":90,\"Defense\":45,\"Sp. Attack\":15,\"Sp. Defense\":45,\"Speed\":50}},{\"id\":555,\"name\":{\"english\":\"Darmanitan\",\"japanese\":\"ヒヒダルマ\",\"chinese\":\"达摩狒狒\",\"french\":\"Darumacho\"},\"type\":[\"Fire\"],\"base\":{\"HP\":105,\"Attack\":140,\"Defense\":55,\"Sp. Attack\":30,\"Sp. Defense\":55,\"Speed\":95}},{\"id\":556,\"name\":{\"english\":\"Maractus\",\"japanese\":\"マラカッチ\",\"chinese\":\"沙铃仙人掌\",\"french\":\"Maracachi\"},\"type\":[\"Grass\"],\"base\":{\"HP\":75,\"Attack\":86,\"Defense\":67,\"Sp. Attack\":106,\"Sp. Defense\":67,\"Speed\":60}},{\"id\":557,\"name\":{\"english\":\"Dwebble\",\"japanese\":\"イシズマイ\",\"chinese\":\"石居蟹\",\"french\":\"Crabicoque\"},\"type\":[\"Bug\",\"Rock\"],\"base\":{\"HP\":50,\"Attack\":65,\"Defense\":85,\"Sp. Attack\":35,\"Sp. Defense\":35,\"Speed\":55}},{\"id\":558,\"name\":{\"english\":\"Crustle\",\"japanese\":\"イワパレス\",\"chinese\":\"岩殿居蟹\",\"french\":\"Crabaraque\"},\"type\":[\"Bug\",\"Rock\"],\"base\":{\"HP\":70,\"Attack\":105,\"Defense\":125,\"Sp. Attack\":65,\"Sp. Defense\":75,\"Speed\":45}},{\"id\":559,\"name\":{\"english\":\"Scraggy\",\"japanese\":\"ズルッグ\",\"chinese\":\"滑滑小子\",\"french\":\"Baggiguane\"},\"type\":[\"Dark\",\"Fighting\"],\"base\":{\"HP\":50,\"Attack\":75,\"Defense\":70,\"Sp. Attack\":35,\"Sp. Defense\":70,\"Speed\":48}},{\"id\":560,\"name\":{\"english\":\"Scrafty\",\"japanese\":\"ズルズキン\",\"chinese\":\"头巾混混\",\"french\":\"Baggaïd\"},\"type\":[\"Dark\",\"Fighting\"],\"base\":{\"HP\":65,\"Attack\":90,\"Defense\":115,\"Sp. Attack\":45,\"Sp. Defense\":115,\"Speed\":58}},{\"id\":561,\"name\":{\"english\":\"Sigilyph\",\"japanese\":\"シンボラー\",\"chinese\":\"象征鸟\",\"french\":\"Cryptéro\"},\"type\":[\"Psychic\",\"Flying\"],\"base\":{\"HP\":72,\"Attack\":58,\"Defense\":80,\"Sp. Attack\":103,\"Sp. Defense\":80,\"Speed\":97}},{\"id\":562,\"name\":{\"english\":\"Yamask\",\"japanese\":\"デスマス\",\"chinese\":\"哭哭面具\",\"french\":\"Tutafeh\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":38,\"Attack\":30,\"Defense\":85,\"Sp. Attack\":55,\"Sp. Defense\":65,\"Speed\":30}},{\"id\":563,\"name\":{\"english\":\"Cofagrigus\",\"japanese\":\"デスカーン\",\"chinese\":\"死神棺\",\"french\":\"Tutankafer\"},\"type\":[\"Ghost\"],\"base\":{\"HP\":58,\"Attack\":50,\"Defense\":145,\"Sp. Attack\":95,\"Sp. Defense\":105,\"Speed\":30}},{\"id\":564,\"name\":{\"english\":\"Tirtouga\",\"japanese\":\"プロトーガ\",\"chinese\":\"原盖海龟\",\"french\":\"Carapagos\"},\"type\":[\"Water\",\"Rock\"],\"base\":{\"HP\":54,\"Attack\":78,\"Defense\":103,\"Sp. Attack\":53,\"Sp. Defense\":45,\"Speed\":22}},{\"id\":565,\"name\":{\"english\":\"Carracosta\",\"japanese\":\"アバゴーラ\",\"chinese\":\"肋骨海龟\",\"french\":\"Mégapagos\"},\"type\":[\"Water\",\"Rock\"],\"base\":{\"HP\":74,\"Attack\":108,\"Defense\":133,\"Sp. Attack\":83,\"Sp. Defense\":65,\"Speed\":32}},{\"id\":566,\"name\":{\"english\":\"Archen\",\"japanese\":\"アーケン\",\"chinese\":\"始祖小鸟\",\"french\":\"Arkéapti\"},\"type\":[\"Rock\",\"Flying\"],\"base\":{\"HP\":55,\"Attack\":112,\"Defense\":45,\"Sp. Attack\":74,\"Sp. Defense\":45,\"Speed\":70}},{\"id\":567,\"name\":{\"english\":\"Archeops\",\"japanese\":\"アーケオス\",\"chinese\":\"始祖大鸟\",\"french\":\"Aéroptéryx\"},\"type\":[\"Rock\",\"Flying\"],\"base\":{\"HP\":75,\"Attack\":140,\"Defense\":65,\"Sp. Attack\":112,\"Sp. Defense\":65,\"Speed\":110}},{\"id\":568,\"name\":{\"english\":\"Trubbish\",\"japanese\":\"ヤブクロン\",\"chinese\":\"破破袋\",\"french\":\"Miamiasme\"},\"type\":[\"Poison\"],\"base\":{\"HP\":50,\"Attack\":50,\"Defense\":62,\"Sp. Attack\":40,\"Sp. Defense\":62,\"Speed\":65}},{\"id\":569,\"name\":{\"english\":\"Garbodor\",\"japanese\":\"ダストダス\",\"chinese\":\"灰尘山\",\"french\":\"Miasmax\"},\"type\":[\"Poison\"],\"base\":{\"HP\":80,\"Attack\":95,\"Defense\":82,\"Sp. Attack\":60,\"Sp. Defense\":82,\"Speed\":75}},{\"id\":570,\"name\":{\"english\":\"Zorua\",\"japanese\":\"ゾロア\",\"chinese\":\"索罗亚\",\"french\":\"Zorua\"},\"type\":[\"Dark\"],\"base\":{\"HP\":40,\"Attack\":65,\"Defense\":40,\"Sp. Attack\":80,\"Sp. Defense\":40,\"Speed\":65}},{\"id\":571,\"name\":{\"english\":\"Zoroark\",\"japanese\":\"ゾロアーク\",\"chinese\":\"索罗亚克\",\"french\":\"Zoroark\"},\"type\":[\"Dark\"],\"base\":{\"HP\":60,\"Attack\":105,\"Defense\":60,\"Sp. Attack\":120,\"Sp. Defense\":60,\"Speed\":105}},{\"id\":572,\"name\":{\"english\":\"Minccino\",\"japanese\":\"チラーミィ\",\"chinese\":\"泡沫栗鼠\",\"french\":\"Chinchidou\"},\"type\":[\"Normal\"],\"base\":{\"HP\":55,\"Attack\":50,\"Defense\":40,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":75}},{\"id\":573,\"name\":{\"english\":\"Cinccino\",\"japanese\":\"チラチーノ\",\"chinese\":\"奇诺栗鼠\",\"french\":\"Pashmilla\"},\"type\":[\"Normal\"],\"base\":{\"HP\":75,\"Attack\":95,\"Defense\":60,\"Sp. Attack\":65,\"Sp. Defense\":60,\"Speed\":115}},{\"id\":574,\"name\":{\"english\":\"Gothita\",\"japanese\":\"ゴチム\",\"chinese\":\"哥德宝宝\",\"french\":\"Scrutella\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":45,\"Attack\":30,\"Defense\":50,\"Sp. Attack\":55,\"Sp. Defense\":65,\"Speed\":45}},{\"id\":575,\"name\":{\"english\":\"Gothorita\",\"japanese\":\"ゴチミル\",\"chinese\":\"哥德小童\",\"french\":\"Mesmérella\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":60,\"Attack\":45,\"Defense\":70,\"Sp. Attack\":75,\"Sp. Defense\":85,\"Speed\":55}},{\"id\":576,\"name\":{\"english\":\"Gothitelle\",\"japanese\":\"ゴチルゼル\",\"chinese\":\"哥德小姐\",\"french\":\"Sidérella\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":70,\"Attack\":55,\"Defense\":95,\"Sp. Attack\":95,\"Sp. Defense\":110,\"Speed\":65}},{\"id\":577,\"name\":{\"english\":\"Solosis\",\"japanese\":\"ユニラン\",\"chinese\":\"单卵细胞球\",\"french\":\"Nucléos\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":45,\"Attack\":30,\"Defense\":40,\"Sp. Attack\":105,\"Sp. Defense\":50,\"Speed\":20}},{\"id\":578,\"name\":{\"english\":\"Duosion\",\"japanese\":\"ダブラン\",\"chinese\":\"双卵细胞球\",\"french\":\"Méios\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":65,\"Attack\":40,\"Defense\":50,\"Sp. Attack\":125,\"Sp. Defense\":60,\"Speed\":30}},{\"id\":579,\"name\":{\"english\":\"Reuniclus\",\"japanese\":\"ランクルス\",\"chinese\":\"人造细胞卵\",\"french\":\"Symbios\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":110,\"Attack\":65,\"Defense\":75,\"Sp. Attack\":125,\"Sp. Defense\":85,\"Speed\":30}},{\"id\":580,\"name\":{\"english\":\"Ducklett\",\"japanese\":\"コアルヒー\",\"chinese\":\"鸭宝宝\",\"french\":\"Couaneton\"},\"type\":[\"Water\",\"Flying\"],\"base\":{\"HP\":62,\"Attack\":44,\"Defense\":50,\"Sp. Attack\":44,\"Sp. Defense\":50,\"Speed\":55}},{\"id\":581,\"name\":{\"english\":\"Swanna\",\"japanese\":\"スワンナ\",\"chinese\":\"舞天鹅\",\"french\":\"Lakmécygne\"},\"type\":[\"Water\",\"Flying\"],\"base\":{\"HP\":75,\"Attack\":87,\"Defense\":63,\"Sp. Attack\":87,\"Sp. Defense\":63,\"Speed\":98}},{\"id\":582,\"name\":{\"english\":\"Vanillite\",\"japanese\":\"バニプッチ\",\"chinese\":\"迷你冰\",\"french\":\"Sorbébé\"},\"type\":[\"Ice\"],\"base\":{\"HP\":36,\"Attack\":50,\"Defense\":50,\"Sp. Attack\":65,\"Sp. Defense\":60,\"Speed\":44}},{\"id\":583,\"name\":{\"english\":\"Vanillish\",\"japanese\":\"バニリッチ\",\"chinese\":\"多多冰\",\"french\":\"Sorboul\"},\"type\":[\"Ice\"],\"base\":{\"HP\":51,\"Attack\":65,\"Defense\":65,\"Sp. Attack\":80,\"Sp. Defense\":75,\"Speed\":59}},{\"id\":584,\"name\":{\"english\":\"Vanilluxe\",\"japanese\":\"バイバニラ\",\"chinese\":\"双倍多多冰\",\"french\":\"Sorbouboul\"},\"type\":[\"Ice\"],\"base\":{\"HP\":71,\"Attack\":95,\"Defense\":85,\"Sp. Attack\":110,\"Sp. Defense\":95,\"Speed\":79}},{\"id\":585,\"name\":{\"english\":\"Deerling\",\"japanese\":\"シキジカ\",\"chinese\":\"四季鹿\",\"french\":\"Vivaldaim\"},\"type\":[\"Normal\",\"Grass\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":50,\"Sp. Attack\":40,\"Sp. Defense\":50,\"Speed\":75}},{\"id\":586,\"name\":{\"english\":\"Sawsbuck\",\"japanese\":\"メブキジカ\",\"chinese\":\"萌芽鹿\",\"french\":\"Haydaim\"},\"type\":[\"Normal\",\"Grass\"],\"base\":{\"HP\":80,\"Attack\":100,\"Defense\":70,\"Sp. Attack\":60,\"Sp. Defense\":70,\"Speed\":95}},{\"id\":587,\"name\":{\"english\":\"Emolga\",\"japanese\":\"エモンガ\",\"chinese\":\"电飞鼠\",\"french\":\"Emolga\"},\"type\":[\"Electric\",\"Flying\"],\"base\":{\"HP\":55,\"Attack\":75,\"Defense\":60,\"Sp. Attack\":75,\"Sp. Defense\":60,\"Speed\":103}},{\"id\":588,\"name\":{\"english\":\"Karrablast\",\"japanese\":\"カブルモ\",\"chinese\":\"盖盖虫\",\"french\":\"Carabing\"},\"type\":[\"Bug\"],\"base\":{\"HP\":50,\"Attack\":75,\"Defense\":45,\"Sp. Attack\":40,\"Sp. Defense\":45,\"Speed\":60}},{\"id\":589,\"name\":{\"english\":\"Escavalier\",\"japanese\":\"シュバルゴ\",\"chinese\":\"骑士蜗牛\",\"french\":\"Lançargot\"},\"type\":[\"Bug\",\"Steel\"],\"base\":{\"HP\":70,\"Attack\":135,\"Defense\":105,\"Sp. Attack\":60,\"Sp. Defense\":105,\"Speed\":20}},{\"id\":590,\"name\":{\"english\":\"Foongus\",\"japanese\":\"タマゲタケ\",\"chinese\":\"哎呀球菇\",\"french\":\"Trompignon\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":69,\"Attack\":55,\"Defense\":45,\"Sp. Attack\":55,\"Sp. Defense\":55,\"Speed\":15}},{\"id\":591,\"name\":{\"english\":\"Amoonguss\",\"japanese\":\"モロバレル\",\"chinese\":\"败露球菇\",\"french\":\"Gaulet\"},\"type\":[\"Grass\",\"Poison\"],\"base\":{\"HP\":114,\"Attack\":85,\"Defense\":70,\"Sp. Attack\":85,\"Sp. Defense\":80,\"Speed\":30}},{\"id\":592,\"name\":{\"english\":\"Frillish\",\"japanese\":\"プルリル\",\"chinese\":\"轻飘飘\",\"french\":\"Viskuse\"},\"type\":[\"Water\",\"Ghost\"],\"base\":{\"HP\":55,\"Attack\":40,\"Defense\":50,\"Sp. Attack\":65,\"Sp. Defense\":85,\"Speed\":40}},{\"id\":593,\"name\":{\"english\":\"Jellicent\",\"japanese\":\"ブルンゲル\",\"chinese\":\"胖嘟嘟\",\"french\":\"Moyade\"},\"type\":[\"Water\",\"Ghost\"],\"base\":{\"HP\":100,\"Attack\":60,\"Defense\":70,\"Sp. Attack\":85,\"Sp. Defense\":105,\"Speed\":60}},{\"id\":594,\"name\":{\"english\":\"Alomomola\",\"japanese\":\"ママンボウ\",\"chinese\":\"保姆曼波\",\"french\":\"Mamanbo\"},\"type\":[\"Water\"],\"base\":{\"HP\":165,\"Attack\":75,\"Defense\":80,\"Sp. Attack\":40,\"Sp. Defense\":45,\"Speed\":65}},{\"id\":595,\"name\":{\"english\":\"Joltik\",\"japanese\":\"バチュル\",\"chinese\":\"电电虫\",\"french\":\"Statitik\"},\"type\":[\"Bug\",\"Electric\"],\"base\":{\"HP\":50,\"Attack\":47,\"Defense\":50,\"Sp. Attack\":57,\"Sp. Defense\":50,\"Speed\":65}},{\"id\":596,\"name\":{\"english\":\"Galvantula\",\"japanese\":\"デンチュラ\",\"chinese\":\"电蜘蛛\",\"french\":\"Mygavolt\"},\"type\":[\"Bug\",\"Electric\"],\"base\":{\"HP\":70,\"Attack\":77,\"Defense\":60,\"Sp. Attack\":97,\"Sp. Defense\":60,\"Speed\":108}},{\"id\":597,\"name\":{\"english\":\"Ferroseed\",\"japanese\":\"テッシード\",\"chinese\":\"种子铁球\",\"french\":\"Grindur\"},\"type\":[\"Grass\",\"Steel\"],\"base\":{\"HP\":44,\"Attack\":50,\"Defense\":91,\"Sp. Attack\":24,\"Sp. Defense\":86,\"Speed\":10}},{\"id\":598,\"name\":{\"english\":\"Ferrothorn\",\"japanese\":\"ナットレイ\",\"chinese\":\"坚果哑铃\",\"french\":\"Noacier\"},\"type\":[\"Grass\",\"Steel\"],\"base\":{\"HP\":74,\"Attack\":94,\"Defense\":131,\"Sp. Attack\":54,\"Sp. Defense\":116,\"Speed\":20}},{\"id\":599,\"name\":{\"english\":\"Klink\",\"japanese\":\"ギアル\",\"chinese\":\"齿轮儿\",\"french\":\"Tic\"},\"type\":[\"Steel\"],\"base\":{\"HP\":40,\"Attack\":55,\"Defense\":70,\"Sp. Attack\":45,\"Sp. Defense\":60,\"Speed\":30}},{\"id\":600,\"name\":{\"english\":\"Klang\",\"japanese\":\"ギギアル\",\"chinese\":\"齿轮组\",\"french\":\"Clic\"},\"type\":[\"Steel\"],\"base\":{\"HP\":60,\"Attack\":80,\"Defense\":95,\"Sp. Attack\":70,\"Sp. Defense\":85,\"Speed\":50}},{\"id\":601,\"name\":{\"english\":\"Klinklang\",\"japanese\":\"ギギギアル\",\"chinese\":\"齿轮怪\",\"french\":\"Cliticlic\"},\"type\":[\"Steel\"],\"base\":{\"HP\":60,\"Attack\":100,\"Defense\":115,\"Sp. Attack\":70,\"Sp. Defense\":85,\"Speed\":90}},{\"id\":602,\"name\":{\"english\":\"Tynamo\",\"japanese\":\"シビシラス\",\"chinese\":\"麻麻小鱼\",\"french\":\"Anchwatt\"},\"type\":[\"Electric\"],\"base\":{\"HP\":35,\"Attack\":55,\"Defense\":40,\"Sp. Attack\":45,\"Sp. Defense\":40,\"Speed\":60}},{\"id\":603,\"name\":{\"english\":\"Eelektrik\",\"japanese\":\"シビビール\",\"chinese\":\"麻麻鳗\",\"french\":\"Lampéroie\"},\"type\":[\"Electric\"],\"base\":{\"HP\":65,\"Attack\":85,\"Defense\":70,\"Sp. Attack\":75,\"Sp. Defense\":70,\"Speed\":40}},{\"id\":604,\"name\":{\"english\":\"Eelektross\",\"japanese\":\"シビルドン\",\"chinese\":\"麻麻鳗鱼王\",\"french\":\"Ohmassacre\"},\"type\":[\"Electric\"],\"base\":{\"HP\":85,\"Attack\":115,\"Defense\":80,\"Sp. Attack\":105,\"Sp. Defense\":80,\"Speed\":50}},{\"id\":605,\"name\":{\"english\":\"Elgyem\",\"japanese\":\"リグレー\",\"chinese\":\"小灰怪\",\"french\":\"Lewsor\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":55,\"Attack\":55,\"Defense\":55,\"Sp. Attack\":85,\"Sp. Defense\":55,\"Speed\":30}},{\"id\":606,\"name\":{\"english\":\"Beheeyem\",\"japanese\":\"オーベム\",\"chinese\":\"大宇怪\",\"french\":\"Neitram\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":75,\"Attack\":75,\"Defense\":75,\"Sp. Attack\":125,\"Sp. Defense\":95,\"Speed\":40}},{\"id\":607,\"name\":{\"english\":\"Litwick\",\"japanese\":\"ヒトモシ\",\"chinese\":\"烛光灵\",\"french\":\"Funécire\"},\"type\":[\"Ghost\",\"Fire\"],\"base\":{\"HP\":50,\"Attack\":30,\"Defense\":55,\"Sp. Attack\":65,\"Sp. Defense\":55,\"Speed\":20}},{\"id\":608,\"name\":{\"english\":\"Lampent\",\"japanese\":\"ランプラー\",\"chinese\":\"灯火幽灵\",\"french\":\"Mélancolux\"},\"type\":[\"Ghost\",\"Fire\"],\"base\":{\"HP\":60,\"Attack\":40,\"Defense\":60,\"Sp. Attack\":95,\"Sp. Defense\":60,\"Speed\":55}},{\"id\":609,\"name\":{\"english\":\"Chandelure\",\"japanese\":\"シャンデラ\",\"chinese\":\"水晶灯火灵\",\"french\":\"Lugulabre\"},\"type\":[\"Ghost\",\"Fire\"],\"base\":{\"HP\":60,\"Attack\":55,\"Defense\":90,\"Sp. Attack\":145,\"Sp. Defense\":90,\"Speed\":80}},{\"id\":610,\"name\":{\"english\":\"Axew\",\"japanese\":\"キバゴ\",\"chinese\":\"牙牙\",\"french\":\"Coupenotte\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":46,\"Attack\":87,\"Defense\":60,\"Sp. Attack\":30,\"Sp. Defense\":40,\"Speed\":57}},{\"id\":611,\"name\":{\"english\":\"Fraxure\",\"japanese\":\"オノンド\",\"chinese\":\"斧牙龙\",\"french\":\"Incisache\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":66,\"Attack\":117,\"Defense\":70,\"Sp. Attack\":40,\"Sp. Defense\":50,\"Speed\":67}},{\"id\":612,\"name\":{\"english\":\"Haxorus\",\"japanese\":\"オノノクス\",\"chinese\":\"双斧战龙\",\"french\":\"Tranchodon\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":76,\"Attack\":147,\"Defense\":90,\"Sp. Attack\":60,\"Sp. Defense\":70,\"Speed\":97}},{\"id\":613,\"name\":{\"english\":\"Cubchoo\",\"japanese\":\"クマシュン\",\"chinese\":\"喷嚏熊\",\"french\":\"Polarhume\"},\"type\":[\"Ice\"],\"base\":{\"HP\":55,\"Attack\":70,\"Defense\":40,\"Sp. Attack\":60,\"Sp. Defense\":40,\"Speed\":40}},{\"id\":614,\"name\":{\"english\":\"Beartic\",\"japanese\":\"ツンベアー\",\"chinese\":\"冻原熊\",\"french\":\"Polagriffe\"},\"type\":[\"Ice\"],\"base\":{\"HP\":95,\"Attack\":130,\"Defense\":80,\"Sp. Attack\":70,\"Sp. Defense\":80,\"Speed\":50}},{\"id\":615,\"name\":{\"english\":\"Cryogonal\",\"japanese\":\"フリージオ\",\"chinese\":\"几何雪花\",\"french\":\"Hexagel\"},\"type\":[\"Ice\"],\"base\":{\"HP\":80,\"Attack\":50,\"Defense\":50,\"Sp. Attack\":95,\"Sp. Defense\":135,\"Speed\":105}},{\"id\":616,\"name\":{\"english\":\"Shelmet\",\"japanese\":\"チョボマキ\",\"chinese\":\"小嘴蜗\",\"french\":\"Escargaume\"},\"type\":[\"Bug\"],\"base\":{\"HP\":50,\"Attack\":40,\"Defense\":85,\"Sp. Attack\":40,\"Sp. Defense\":65,\"Speed\":25}},{\"id\":617,\"name\":{\"english\":\"Accelgor\",\"japanese\":\"アギルダー\",\"chinese\":\"敏捷虫\",\"french\":\"Limaspeed\"},\"type\":[\"Bug\"],\"base\":{\"HP\":80,\"Attack\":70,\"Defense\":40,\"Sp. Attack\":100,\"Sp. Defense\":60,\"Speed\":145}},{\"id\":618,\"name\":{\"english\":\"Stunfisk\",\"japanese\":\"マッギョ\",\"chinese\":\"泥巴鱼\",\"french\":\"Limonde\"},\"type\":[\"Ground\",\"Electric\"],\"base\":{\"HP\":109,\"Attack\":66,\"Defense\":84,\"Sp. Attack\":81,\"Sp. Defense\":99,\"Speed\":32}},{\"id\":619,\"name\":{\"english\":\"Mienfoo\",\"japanese\":\"コジョフー\",\"chinese\":\"功夫鼬\",\"french\":\"Kungfouine\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":45,\"Attack\":85,\"Defense\":50,\"Sp. Attack\":55,\"Sp. Defense\":50,\"Speed\":65}},{\"id\":620,\"name\":{\"english\":\"Mienshao\",\"japanese\":\"コジョンド\",\"chinese\":\"师父鼬\",\"french\":\"Shaofouine\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":65,\"Attack\":125,\"Defense\":60,\"Sp. Attack\":95,\"Sp. Defense\":60,\"Speed\":105}},{\"id\":621,\"name\":{\"english\":\"Druddigon\",\"japanese\":\"クリムガン\",\"chinese\":\"赤面龙\",\"french\":\"Drakkarmin\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":77,\"Attack\":120,\"Defense\":90,\"Sp. Attack\":60,\"Sp. Defense\":90,\"Speed\":48}},{\"id\":622,\"name\":{\"english\":\"Golett\",\"japanese\":\"ゴビット\",\"chinese\":\"泥偶小人\",\"french\":\"Gringolem\"},\"type\":[\"Ground\",\"Ghost\"],\"base\":{\"HP\":59,\"Attack\":74,\"Defense\":50,\"Sp. Attack\":35,\"Sp. Defense\":50,\"Speed\":35}},{\"id\":623,\"name\":{\"english\":\"Golurk\",\"japanese\":\"ゴルーグ\",\"chinese\":\"泥偶巨人\",\"french\":\"Golemastoc\"},\"type\":[\"Ground\",\"Ghost\"],\"base\":{\"HP\":89,\"Attack\":124,\"Defense\":80,\"Sp. Attack\":55,\"Sp. Defense\":80,\"Speed\":55}},{\"id\":624,\"name\":{\"english\":\"Pawniard\",\"japanese\":\"コマタナ\",\"chinese\":\"驹刀小兵\",\"french\":\"Scalpion\"},\"type\":[\"Dark\",\"Steel\"],\"base\":{\"HP\":45,\"Attack\":85,\"Defense\":70,\"Sp. Attack\":40,\"Sp. Defense\":40,\"Speed\":60}},{\"id\":625,\"name\":{\"english\":\"Bisharp\",\"japanese\":\"キリキザン\",\"chinese\":\"劈斩司令\",\"french\":\"Scalproie\"},\"type\":[\"Dark\",\"Steel\"],\"base\":{\"HP\":65,\"Attack\":125,\"Defense\":100,\"Sp. Attack\":60,\"Sp. Defense\":70,\"Speed\":70}},{\"id\":626,\"name\":{\"english\":\"Bouffalant\",\"japanese\":\"バッフロン\",\"chinese\":\"爆炸头水牛\",\"french\":\"Frison\"},\"type\":[\"Normal\"],\"base\":{\"HP\":95,\"Attack\":110,\"Defense\":95,\"Sp. Attack\":40,\"Sp. Defense\":95,\"Speed\":55}},{\"id\":627,\"name\":{\"english\":\"Rufflet\",\"japanese\":\"ワシボン\",\"chinese\":\"毛头小鹰\",\"french\":\"Furaiglon\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":70,\"Attack\":83,\"Defense\":50,\"Sp. Attack\":37,\"Sp. Defense\":50,\"Speed\":60}},{\"id\":628,\"name\":{\"english\":\"Braviary\",\"japanese\":\"ウォーグル\",\"chinese\":\"勇士雄鹰\",\"french\":\"Gueriaigle\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":100,\"Attack\":123,\"Defense\":75,\"Sp. Attack\":57,\"Sp. Defense\":75,\"Speed\":80}},{\"id\":629,\"name\":{\"english\":\"Vullaby\",\"japanese\":\"バルチャイ\",\"chinese\":\"秃鹰丫头\",\"french\":\"Vostourno\"},\"type\":[\"Dark\",\"Flying\"],\"base\":{\"HP\":70,\"Attack\":55,\"Defense\":75,\"Sp. Attack\":45,\"Sp. Defense\":65,\"Speed\":60}},{\"id\":630,\"name\":{\"english\":\"Mandibuzz\",\"japanese\":\"バルジーナ\",\"chinese\":\"秃鹰娜\",\"french\":\"Vaututrice\"},\"type\":[\"Dark\",\"Flying\"],\"base\":{\"HP\":110,\"Attack\":65,\"Defense\":105,\"Sp. Attack\":55,\"Sp. Defense\":95,\"Speed\":80}},{\"id\":631,\"name\":{\"english\":\"Heatmor\",\"japanese\":\"クイタラン\",\"chinese\":\"熔蚁兽\",\"french\":\"Aflamanoir\"},\"type\":[\"Fire\"],\"base\":{\"HP\":85,\"Attack\":97,\"Defense\":66,\"Sp. Attack\":105,\"Sp. Defense\":66,\"Speed\":65}},{\"id\":632,\"name\":{\"english\":\"Durant\",\"japanese\":\"アイアント\",\"chinese\":\"铁蚁\",\"french\":\"Fermite\"},\"type\":[\"Bug\",\"Steel\"],\"base\":{\"HP\":58,\"Attack\":109,\"Defense\":112,\"Sp. Attack\":48,\"Sp. Defense\":48,\"Speed\":109}},{\"id\":633,\"name\":{\"english\":\"Deino\",\"japanese\":\"モノズ\",\"chinese\":\"单首龙\",\"french\":\"Solochi\"},\"type\":[\"Dark\",\"Dragon\"],\"base\":{\"HP\":52,\"Attack\":65,\"Defense\":50,\"Sp. Attack\":45,\"Sp. Defense\":50,\"Speed\":38}},{\"id\":634,\"name\":{\"english\":\"Zweilous\",\"japanese\":\"ジヘッド\",\"chinese\":\"双首暴龙\",\"french\":\"Diamat\"},\"type\":[\"Dark\",\"Dragon\"],\"base\":{\"HP\":72,\"Attack\":85,\"Defense\":70,\"Sp. Attack\":65,\"Sp. Defense\":70,\"Speed\":58}},{\"id\":635,\"name\":{\"english\":\"Hydreigon\",\"japanese\":\"サザンドラ\",\"chinese\":\"三首恶龙\",\"french\":\"Trioxhydre\"},\"type\":[\"Dark\",\"Dragon\"],\"base\":{\"HP\":92,\"Attack\":105,\"Defense\":90,\"Sp. Attack\":125,\"Sp. Defense\":90,\"Speed\":98}},{\"id\":636,\"name\":{\"english\":\"Larvesta\",\"japanese\":\"メラルバ\",\"chinese\":\"燃烧虫\",\"french\":\"Pyronille\"},\"type\":[\"Bug\",\"Fire\"],\"base\":{\"HP\":55,\"Attack\":85,\"Defense\":55,\"Sp. Attack\":50,\"Sp. Defense\":55,\"Speed\":60}},{\"id\":637,\"name\":{\"english\":\"Volcarona\",\"japanese\":\"ウルガモス\",\"chinese\":\"火神蛾\",\"french\":\"Pyrax\"},\"type\":[\"Bug\",\"Fire\"],\"base\":{\"HP\":85,\"Attack\":60,\"Defense\":65,\"Sp. Attack\":135,\"Sp. Defense\":105,\"Speed\":100}},{\"id\":638,\"name\":{\"english\":\"Cobalion\",\"japanese\":\"コバルオン\",\"chinese\":\"勾帕路翁\",\"french\":\"Cobaltium\"},\"type\":[\"Steel\",\"Fighting\"],\"base\":{\"HP\":91,\"Attack\":90,\"Defense\":129,\"Sp. Attack\":90,\"Sp. Defense\":72,\"Speed\":108}},{\"id\":639,\"name\":{\"english\":\"Terrakion\",\"japanese\":\"テラキオン\",\"chinese\":\"代拉基翁\",\"french\":\"Terrakium\"},\"type\":[\"Rock\",\"Fighting\"],\"base\":{\"HP\":91,\"Attack\":129,\"Defense\":90,\"Sp. Attack\":72,\"Sp. Defense\":90,\"Speed\":108}},{\"id\":640,\"name\":{\"english\":\"Virizion\",\"japanese\":\"ビリジオン\",\"chinese\":\"毕力吉翁\",\"french\":\"Viridium\"},\"type\":[\"Grass\",\"Fighting\"],\"base\":{\"HP\":91,\"Attack\":90,\"Defense\":72,\"Sp. Attack\":90,\"Sp. Defense\":129,\"Speed\":108}},{\"id\":641,\"name\":{\"english\":\"Tornadus\",\"japanese\":\"トルネロス\",\"chinese\":\"龙卷云\",\"french\":\"Boréas\"},\"type\":[\"Flying\"],\"base\":{\"HP\":79,\"Attack\":115,\"Defense\":70,\"Sp. Attack\":125,\"Sp. Defense\":80,\"Speed\":111}},{\"id\":642,\"name\":{\"english\":\"Thundurus\",\"japanese\":\"ボルトロス\",\"chinese\":\"雷电云\",\"french\":\"Fulguris\"},\"type\":[\"Electric\",\"Flying\"],\"base\":{\"HP\":79,\"Attack\":115,\"Defense\":70,\"Sp. Attack\":125,\"Sp. Defense\":80,\"Speed\":111}},{\"id\":643,\"name\":{\"english\":\"Reshiram\",\"japanese\":\"レシラム\",\"chinese\":\"莱希拉姆\",\"french\":\"Reshiram\"},\"type\":[\"Dragon\",\"Fire\"],\"base\":{\"HP\":100,\"Attack\":120,\"Defense\":100,\"Sp. Attack\":150,\"Sp. Defense\":120,\"Speed\":90}},{\"id\":644,\"name\":{\"english\":\"Zekrom\",\"japanese\":\"ゼクロム\",\"chinese\":\"捷克罗姆\",\"french\":\"Zekrom\"},\"type\":[\"Dragon\",\"Electric\"],\"base\":{\"HP\":100,\"Attack\":150,\"Defense\":120,\"Sp. Attack\":120,\"Sp. Defense\":100,\"Speed\":90}},{\"id\":645,\"name\":{\"english\":\"Landorus\",\"japanese\":\"ランドロス\",\"chinese\":\"土地云\",\"french\":\"Démétéros\"},\"type\":[\"Ground\",\"Flying\"],\"base\":{\"HP\":89,\"Attack\":125,\"Defense\":90,\"Sp. Attack\":115,\"Sp. Defense\":80,\"Speed\":101}},{\"id\":646,\"name\":{\"english\":\"Kyurem\",\"japanese\":\"キュレム\",\"chinese\":\"酋雷姆\",\"french\":\"Kyurem\"},\"type\":[\"Dragon\",\"Ice\"],\"base\":{\"HP\":125,\"Attack\":130,\"Defense\":90,\"Sp. Attack\":130,\"Sp. Defense\":90,\"Speed\":95}},{\"id\":647,\"name\":{\"english\":\"Keldeo\",\"japanese\":\"ケルディオ\",\"chinese\":\"凯路迪欧\",\"french\":\"Keldeo\"},\"type\":[\"Water\",\"Fighting\"],\"base\":{\"HP\":91,\"Attack\":72,\"Defense\":90,\"Sp. Attack\":129,\"Sp. Defense\":90,\"Speed\":108}},{\"id\":648,\"name\":{\"english\":\"Meloetta\",\"japanese\":\"メロエッタ\",\"chinese\":\"美洛耶塔\",\"french\":\"Meloetta\"},\"type\":[\"Normal\",\"Psychic\"],\"base\":{\"HP\":100,\"Attack\":77,\"Defense\":77,\"Sp. Attack\":128,\"Sp. Defense\":128,\"Speed\":90}},{\"id\":649,\"name\":{\"english\":\"Genesect\",\"japanese\":\"ゲノセクト\",\"chinese\":\"盖诺赛克特\",\"french\":\"Genesect\"},\"type\":[\"Bug\",\"Steel\"],\"base\":{\"HP\":71,\"Attack\":120,\"Defense\":95,\"Sp. Attack\":120,\"Sp. Defense\":95,\"Speed\":99}},{\"id\":650,\"name\":{\"english\":\"Chespin\",\"japanese\":\"ハリマロン\",\"chinese\":\"哈力栗\",\"french\":\"Marisson\"},\"type\":[\"Grass\"],\"base\":{\"HP\":56,\"Attack\":61,\"Defense\":65,\"Sp. Attack\":48,\"Sp. Defense\":45,\"Speed\":38}},{\"id\":651,\"name\":{\"english\":\"Quilladin\",\"japanese\":\"ハリボーグ\",\"chinese\":\"胖胖哈力\",\"french\":\"Boguérisse\"},\"type\":[\"Grass\"],\"base\":{\"HP\":61,\"Attack\":78,\"Defense\":95,\"Sp. Attack\":56,\"Sp. Defense\":58,\"Speed\":57}},{\"id\":652,\"name\":{\"english\":\"Chesnaught\",\"japanese\":\"ブリガロン\",\"chinese\":\"布里卡隆\",\"french\":\"Blindépique\"},\"type\":[\"Grass\",\"Fighting\"],\"base\":{\"HP\":88,\"Attack\":107,\"Defense\":122,\"Sp. Attack\":74,\"Sp. Defense\":75,\"Speed\":64}},{\"id\":653,\"name\":{\"english\":\"Fennekin\",\"japanese\":\"フォッコ\",\"chinese\":\"火狐狸\",\"french\":\"Feunnec\"},\"type\":[\"Fire\"],\"base\":{\"HP\":40,\"Attack\":45,\"Defense\":40,\"Sp. Attack\":62,\"Sp. Defense\":60,\"Speed\":60}},{\"id\":654,\"name\":{\"english\":\"Braixen\",\"japanese\":\"テールナー\",\"chinese\":\"长尾火狐\",\"french\":\"Roussil\"},\"type\":[\"Fire\"],\"base\":{\"HP\":59,\"Attack\":59,\"Defense\":58,\"Sp. Attack\":90,\"Sp. Defense\":70,\"Speed\":73}},{\"id\":655,\"name\":{\"english\":\"Delphox\",\"japanese\":\"マフォクシー\",\"chinese\":\"妖火红狐\",\"french\":\"Goupelin\"},\"type\":[\"Fire\",\"Psychic\"],\"base\":{\"HP\":75,\"Attack\":69,\"Defense\":72,\"Sp. Attack\":114,\"Sp. Defense\":100,\"Speed\":104}},{\"id\":656,\"name\":{\"english\":\"Froakie\",\"japanese\":\"ケロマツ\",\"chinese\":\"呱呱泡蛙\",\"french\":\"Grenousse\"},\"type\":[\"Water\"],\"base\":{\"HP\":41,\"Attack\":56,\"Defense\":40,\"Sp. Attack\":62,\"Sp. Defense\":44,\"Speed\":71}},{\"id\":657,\"name\":{\"english\":\"Frogadier\",\"japanese\":\"ゲコガシラ\",\"chinese\":\"呱头蛙\",\"french\":\"Croâporal\"},\"type\":[\"Water\"],\"base\":{\"HP\":54,\"Attack\":63,\"Defense\":52,\"Sp. Attack\":83,\"Sp. Defense\":56,\"Speed\":97}},{\"id\":658,\"name\":{\"english\":\"Greninja\",\"japanese\":\"ゲッコウガ\",\"chinese\":\"甲贺忍蛙\",\"french\":\"Amphinobi\"},\"type\":[\"Water\",\"Dark\"],\"base\":{\"HP\":72,\"Attack\":95,\"Defense\":67,\"Sp. Attack\":103,\"Sp. Defense\":71,\"Speed\":122}},{\"id\":659,\"name\":{\"english\":\"Bunnelby\",\"japanese\":\"ホルビー\",\"chinese\":\"掘掘兔\",\"french\":\"Sapereau\"},\"type\":[\"Normal\"],\"base\":{\"HP\":38,\"Attack\":36,\"Defense\":38,\"Sp. Attack\":32,\"Sp. Defense\":36,\"Speed\":57}},{\"id\":660,\"name\":{\"english\":\"Diggersby\",\"japanese\":\"ホルード\",\"chinese\":\"掘地兔\",\"french\":\"Excavarenne\"},\"type\":[\"Normal\",\"Ground\"],\"base\":{\"HP\":85,\"Attack\":56,\"Defense\":77,\"Sp. Attack\":50,\"Sp. Defense\":77,\"Speed\":78}},{\"id\":661,\"name\":{\"english\":\"Fletchling\",\"japanese\":\"ヤヤコマ\",\"chinese\":\"小箭雀\",\"french\":\"Passerouge\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":45,\"Attack\":50,\"Defense\":43,\"Sp. Attack\":40,\"Sp. Defense\":38,\"Speed\":62}},{\"id\":662,\"name\":{\"english\":\"Fletchinder\",\"japanese\":\"ヒノヤコマ\",\"chinese\":\"火箭雀\",\"french\":\"Braisillon\"},\"type\":[\"Fire\",\"Flying\"],\"base\":{\"HP\":62,\"Attack\":73,\"Defense\":55,\"Sp. Attack\":56,\"Sp. Defense\":52,\"Speed\":84}},{\"id\":663,\"name\":{\"english\":\"Talonflame\",\"japanese\":\"ファイアロー\",\"chinese\":\"烈箭鹰\",\"french\":\"Flambusard\"},\"type\":[\"Fire\",\"Flying\"],\"base\":{\"HP\":78,\"Attack\":81,\"Defense\":71,\"Sp. Attack\":74,\"Sp. Defense\":69,\"Speed\":126}},{\"id\":664,\"name\":{\"english\":\"Scatterbug\",\"japanese\":\"コフキムシ\",\"chinese\":\"粉蝶虫\",\"french\":\"Lépidonille\"},\"type\":[\"Bug\"],\"base\":{\"HP\":38,\"Attack\":35,\"Defense\":40,\"Sp. Attack\":27,\"Sp. Defense\":25,\"Speed\":35}},{\"id\":665,\"name\":{\"english\":\"Spewpa\",\"japanese\":\"コフーライ\",\"chinese\":\"粉蝶蛹\",\"french\":\"Pérégrain\"},\"type\":[\"Bug\"],\"base\":{\"HP\":45,\"Attack\":22,\"Defense\":60,\"Sp. Attack\":27,\"Sp. Defense\":30,\"Speed\":29}},{\"id\":666,\"name\":{\"english\":\"Vivillon\",\"japanese\":\"ビビヨン\",\"chinese\":\"彩粉蝶\",\"french\":\"Prismillon\"},\"type\":[\"Bug\",\"Flying\"],\"base\":{\"HP\":80,\"Attack\":52,\"Defense\":50,\"Sp. Attack\":90,\"Sp. Defense\":50,\"Speed\":89}},{\"id\":667,\"name\":{\"english\":\"Litleo\",\"japanese\":\"シシコ\",\"chinese\":\"小狮狮\",\"french\":\"Hélionceau\"},\"type\":[\"Fire\",\"Normal\"],\"base\":{\"HP\":62,\"Attack\":50,\"Defense\":58,\"Sp. Attack\":73,\"Sp. Defense\":54,\"Speed\":72}},{\"id\":668,\"name\":{\"english\":\"Pyroar\",\"japanese\":\"カエンジシ\",\"chinese\":\"火炎狮\",\"french\":\"Némélios\"},\"type\":[\"Fire\",\"Normal\"],\"base\":{\"HP\":86,\"Attack\":68,\"Defense\":72,\"Sp. Attack\":109,\"Sp. Defense\":66,\"Speed\":106}},{\"id\":669,\"name\":{\"english\":\"Flabébé\",\"japanese\":\"フラベベ\",\"chinese\":\"花蓓蓓\",\"french\":\"Flabébé\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":44,\"Attack\":38,\"Defense\":39,\"Sp. Attack\":61,\"Sp. Defense\":79,\"Speed\":42}},{\"id\":670,\"name\":{\"english\":\"Floette\",\"japanese\":\"フラエッテ\",\"chinese\":\"花叶蒂\",\"french\":\"FLOETTE\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":54,\"Attack\":45,\"Defense\":47,\"Sp. Attack\":75,\"Sp. Defense\":98,\"Speed\":52}},{\"id\":671,\"name\":{\"english\":\"Florges\",\"japanese\":\"フラージェス\",\"chinese\":\"花洁夫人\",\"french\":\"Florges\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":78,\"Attack\":65,\"Defense\":68,\"Sp. Attack\":112,\"Sp. Defense\":154,\"Speed\":75}},{\"id\":672,\"name\":{\"english\":\"Skiddo\",\"japanese\":\"メェークル\",\"chinese\":\"坐骑小羊\",\"french\":\"Cabriolaine\"},\"type\":[\"Grass\"],\"base\":{\"HP\":66,\"Attack\":65,\"Defense\":48,\"Sp. Attack\":62,\"Sp. Defense\":57,\"Speed\":52}},{\"id\":673,\"name\":{\"english\":\"Gogoat\",\"japanese\":\"ゴーゴート\",\"chinese\":\"坐骑山羊\",\"french\":\"Chevroum\"},\"type\":[\"Grass\"],\"base\":{\"HP\":123,\"Attack\":100,\"Defense\":62,\"Sp. Attack\":97,\"Sp. Defense\":81,\"Speed\":68}},{\"id\":674,\"name\":{\"english\":\"Pancham\",\"japanese\":\"ヤンチャム\",\"chinese\":\"顽皮熊猫\",\"french\":\"Pandespiègle\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":67,\"Attack\":82,\"Defense\":62,\"Sp. Attack\":46,\"Sp. Defense\":48,\"Speed\":43}},{\"id\":675,\"name\":{\"english\":\"Pangoro\",\"japanese\":\"ゴロンダ\",\"chinese\":\"流氓熊猫\",\"french\":\"Pandarbare\"},\"type\":[\"Fighting\",\"Dark\"],\"base\":{\"HP\":95,\"Attack\":124,\"Defense\":78,\"Sp. Attack\":69,\"Sp. Defense\":71,\"Speed\":58}},{\"id\":676,\"name\":{\"english\":\"Furfrou\",\"japanese\":\"トリミアン\",\"chinese\":\"多丽米亚\",\"french\":\"Couafarel\"},\"type\":[\"Normal\"],\"base\":{\"HP\":75,\"Attack\":80,\"Defense\":60,\"Sp. Attack\":65,\"Sp. Defense\":90,\"Speed\":102}},{\"id\":677,\"name\":{\"english\":\"Espurr\",\"japanese\":\"ニャスパー\",\"chinese\":\"妙喵\",\"french\":\"Psystigri\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":62,\"Attack\":48,\"Defense\":54,\"Sp. Attack\":63,\"Sp. Defense\":60,\"Speed\":68}},{\"id\":678,\"name\":{\"english\":\"Meowstic\",\"japanese\":\"ニャオニクス\",\"chinese\":\"超能妙喵\",\"french\":\"Mistigrix\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":74,\"Attack\":48,\"Defense\":76,\"Sp. Attack\":83,\"Sp. Defense\":81,\"Speed\":104}},{\"id\":679,\"name\":{\"english\":\"Honedge\",\"japanese\":\"ヒトツキ\",\"chinese\":\"独剑鞘\",\"french\":\"Monorpale\"},\"type\":[\"Steel\",\"Ghost\"],\"base\":{\"HP\":45,\"Attack\":80,\"Defense\":100,\"Sp. Attack\":35,\"Sp. Defense\":37,\"Speed\":28}},{\"id\":680,\"name\":{\"english\":\"Doublade\",\"japanese\":\"ニダンギル\",\"chinese\":\"双剑鞘\",\"french\":\"Dimoclès\"},\"type\":[\"Steel\",\"Ghost\"],\"base\":{\"HP\":59,\"Attack\":110,\"Defense\":150,\"Sp. Attack\":45,\"Sp. Defense\":49,\"Speed\":35}},{\"id\":681,\"name\":{\"english\":\"Aegislash\",\"japanese\":\"ギルガルド\",\"chinese\":\"坚盾剑怪\",\"french\":\"Exagide\"},\"type\":[\"Steel\",\"Ghost\"],\"base\":{\"HP\":60,\"Attack\":50,\"Defense\":150,\"Sp. Attack\":50,\"Sp. Defense\":150,\"Speed\":60}},{\"id\":682,\"name\":{\"english\":\"Spritzee\",\"japanese\":\"シュシュプ\",\"chinese\":\"粉香香\",\"french\":\"Fluvetin\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":78,\"Attack\":52,\"Defense\":60,\"Sp. Attack\":63,\"Sp. Defense\":65,\"Speed\":23}},{\"id\":683,\"name\":{\"english\":\"Aromatisse\",\"japanese\":\"フレフワン\",\"chinese\":\"芳香精\",\"french\":\"Cocotine\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":101,\"Attack\":72,\"Defense\":72,\"Sp. Attack\":99,\"Sp. Defense\":89,\"Speed\":29}},{\"id\":684,\"name\":{\"english\":\"Swirlix\",\"japanese\":\"ペロッパフ\",\"chinese\":\"绵绵泡芙\",\"french\":\"Sucroquin\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":62,\"Attack\":48,\"Defense\":66,\"Sp. Attack\":59,\"Sp. Defense\":57,\"Speed\":49}},{\"id\":685,\"name\":{\"english\":\"Slurpuff\",\"japanese\":\"ペロリーム\",\"chinese\":\"胖甜妮\",\"french\":\"Cupcanaille\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":82,\"Attack\":80,\"Defense\":86,\"Sp. Attack\":85,\"Sp. Defense\":75,\"Speed\":72}},{\"id\":686,\"name\":{\"english\":\"Inkay\",\"japanese\":\"マーイーカ\",\"chinese\":\"好啦鱿\",\"french\":\"Sepiatop\"},\"type\":[\"Dark\",\"Psychic\"],\"base\":{\"HP\":53,\"Attack\":54,\"Defense\":53,\"Sp. Attack\":37,\"Sp. Defense\":46,\"Speed\":45}},{\"id\":687,\"name\":{\"english\":\"Malamar\",\"japanese\":\"カラマネロ\",\"chinese\":\"乌贼王\",\"french\":\"Sepiatroce\"},\"type\":[\"Dark\",\"Psychic\"],\"base\":{\"HP\":86,\"Attack\":92,\"Defense\":88,\"Sp. Attack\":68,\"Sp. Defense\":75,\"Speed\":73}},{\"id\":688,\"name\":{\"english\":\"Binacle\",\"japanese\":\"カメテテ\",\"chinese\":\"龟脚脚\",\"french\":\"Opermine\"},\"type\":[\"Rock\",\"Water\"],\"base\":{\"HP\":42,\"Attack\":52,\"Defense\":67,\"Sp. Attack\":39,\"Sp. Defense\":56,\"Speed\":50}},{\"id\":689,\"name\":{\"english\":\"Barbaracle\",\"japanese\":\"ガメノデス\",\"chinese\":\"龟足巨铠\",\"french\":\"Golgopathe\"},\"type\":[\"Rock\",\"Water\"],\"base\":{\"HP\":72,\"Attack\":105,\"Defense\":115,\"Sp. Attack\":54,\"Sp. Defense\":86,\"Speed\":68}},{\"id\":690,\"name\":{\"english\":\"Skrelp\",\"japanese\":\"クズモー\",\"chinese\":\"垃垃藻\",\"french\":\"Venalgue\"},\"type\":[\"Poison\",\"Water\"],\"base\":{\"HP\":50,\"Attack\":60,\"Defense\":60,\"Sp. Attack\":60,\"Sp. Defense\":60,\"Speed\":30}},{\"id\":691,\"name\":{\"english\":\"Dragalge\",\"japanese\":\"ドラミドロ\",\"chinese\":\"毒藻龙\",\"french\":\"Kravarech\"},\"type\":[\"Poison\",\"Dragon\"],\"base\":{\"HP\":65,\"Attack\":75,\"Defense\":90,\"Sp. Attack\":97,\"Sp. Defense\":123,\"Speed\":44}},{\"id\":692,\"name\":{\"english\":\"Clauncher\",\"japanese\":\"ウデッポウ\",\"chinese\":\"铁臂枪虾\",\"french\":\"Flingouste\"},\"type\":[\"Water\"],\"base\":{\"HP\":50,\"Attack\":53,\"Defense\":62,\"Sp. Attack\":58,\"Sp. Defense\":63,\"Speed\":44}},{\"id\":693,\"name\":{\"english\":\"Clawitzer\",\"japanese\":\"ブロスター\",\"chinese\":\"钢炮臂虾\",\"french\":\"Gamblast\"},\"type\":[\"Water\"],\"base\":{\"HP\":71,\"Attack\":73,\"Defense\":88,\"Sp. Attack\":120,\"Sp. Defense\":89,\"Speed\":59}},{\"id\":694,\"name\":{\"english\":\"Helioptile\",\"japanese\":\"エリキテル\",\"chinese\":\"伞电蜥\",\"french\":\"Galvaran\"},\"type\":[\"Electric\",\"Normal\"],\"base\":{\"HP\":44,\"Attack\":38,\"Defense\":33,\"Sp. Attack\":61,\"Sp. Defense\":43,\"Speed\":70}},{\"id\":695,\"name\":{\"english\":\"Heliolisk\",\"japanese\":\"エレザード\",\"chinese\":\"光电伞蜥\",\"french\":\"Iguolta\"},\"type\":[\"Electric\",\"Normal\"],\"base\":{\"HP\":62,\"Attack\":55,\"Defense\":52,\"Sp. Attack\":109,\"Sp. Defense\":94,\"Speed\":109}},{\"id\":696,\"name\":{\"english\":\"Tyrunt\",\"japanese\":\"チゴラス\",\"chinese\":\"宝宝暴龙\",\"french\":\"Ptyranidur\"},\"type\":[\"Rock\",\"Dragon\"],\"base\":{\"HP\":58,\"Attack\":89,\"Defense\":77,\"Sp. Attack\":45,\"Sp. Defense\":45,\"Speed\":48}},{\"id\":697,\"name\":{\"english\":\"Tyrantrum\",\"japanese\":\"ガチゴラス\",\"chinese\":\"怪颚龙\",\"french\":\"Rexillius\"},\"type\":[\"Rock\",\"Dragon\"],\"base\":{\"HP\":82,\"Attack\":121,\"Defense\":119,\"Sp. Attack\":69,\"Sp. Defense\":59,\"Speed\":71}},{\"id\":698,\"name\":{\"english\":\"Amaura\",\"japanese\":\"アマルス\",\"chinese\":\"冰雪龙\",\"french\":\"Amagara\"},\"type\":[\"Rock\",\"Ice\"],\"base\":{\"HP\":77,\"Attack\":59,\"Defense\":50,\"Sp. Attack\":67,\"Sp. Defense\":63,\"Speed\":46}},{\"id\":699,\"name\":{\"english\":\"Aurorus\",\"japanese\":\"アマルルガ\",\"chinese\":\"冰雪巨龙\",\"french\":\"Dragmara\"},\"type\":[\"Rock\",\"Ice\"],\"base\":{\"HP\":123,\"Attack\":77,\"Defense\":72,\"Sp. Attack\":99,\"Sp. Defense\":92,\"Speed\":58}},{\"id\":700,\"name\":{\"english\":\"Sylveon\",\"japanese\":\"ニンフィア\",\"chinese\":\"仙子伊布\",\"french\":\"Nymphali\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":95,\"Attack\":65,\"Defense\":65,\"Sp. Attack\":110,\"Sp. Defense\":130,\"Speed\":60}},{\"id\":701,\"name\":{\"english\":\"Hawlucha\",\"japanese\":\"ルチャブル\",\"chinese\":\"摔角鹰人\",\"french\":\"Brutalibré\"},\"type\":[\"Fighting\",\"Flying\"],\"base\":{\"HP\":78,\"Attack\":92,\"Defense\":75,\"Sp. Attack\":74,\"Sp. Defense\":63,\"Speed\":118}},{\"id\":702,\"name\":{\"english\":\"Dedenne\",\"japanese\":\"デデンネ\",\"chinese\":\"咚咚鼠\",\"french\":\"DEDENNE\"},\"type\":[\"Electric\",\"Fairy\"],\"base\":{\"HP\":67,\"Attack\":58,\"Defense\":57,\"Sp. Attack\":81,\"Sp. Defense\":67,\"Speed\":101}},{\"id\":703,\"name\":{\"english\":\"Carbink\",\"japanese\":\"メレシー\",\"chinese\":\"小碎钻\",\"french\":\"Strassie\"},\"type\":[\"Rock\",\"Fairy\"],\"base\":{\"HP\":50,\"Attack\":50,\"Defense\":150,\"Sp. Attack\":50,\"Sp. Defense\":150,\"Speed\":50}},{\"id\":704,\"name\":{\"english\":\"Goomy\",\"japanese\":\"ヌメラ\",\"chinese\":\"黏黏宝\",\"french\":\"Mucuscule\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":45,\"Attack\":50,\"Defense\":35,\"Sp. Attack\":55,\"Sp. Defense\":75,\"Speed\":40}},{\"id\":705,\"name\":{\"english\":\"Sliggoo\",\"japanese\":\"ヌメイル\",\"chinese\":\"黏美儿\",\"french\":\"Colimucus\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":68,\"Attack\":75,\"Defense\":53,\"Sp. Attack\":83,\"Sp. Defense\":113,\"Speed\":60}},{\"id\":706,\"name\":{\"english\":\"Goodra\",\"japanese\":\"ヌメルゴン\",\"chinese\":\"黏美龙\",\"french\":\"Muplodocus\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":90,\"Attack\":100,\"Defense\":70,\"Sp. Attack\":110,\"Sp. Defense\":150,\"Speed\":80}},{\"id\":707,\"name\":{\"english\":\"Klefki\",\"japanese\":\"クレッフィ\",\"chinese\":\"钥圈儿\",\"french\":\"Trousselin\"},\"type\":[\"Steel\",\"Fairy\"],\"base\":{\"HP\":57,\"Attack\":80,\"Defense\":91,\"Sp. Attack\":80,\"Sp. Defense\":87,\"Speed\":75}},{\"id\":708,\"name\":{\"english\":\"Phantump\",\"japanese\":\"ボクレー\",\"chinese\":\"小木灵\",\"french\":\"Brocélôme\"},\"type\":[\"Ghost\",\"Grass\"],\"base\":{\"HP\":43,\"Attack\":70,\"Defense\":48,\"Sp. Attack\":50,\"Sp. Defense\":60,\"Speed\":38}},{\"id\":709,\"name\":{\"english\":\"Trevenant\",\"japanese\":\"オーロット\",\"chinese\":\"朽木妖\",\"french\":\"Desséliande\"},\"type\":[\"Ghost\",\"Grass\"],\"base\":{\"HP\":85,\"Attack\":110,\"Defense\":76,\"Sp. Attack\":65,\"Sp. Defense\":82,\"Speed\":56}},{\"id\":710,\"name\":{\"english\":\"Pumpkaboo\",\"japanese\":\"バケッチャ\",\"chinese\":\"南瓜精\",\"french\":\"Pitrouille\"},\"type\":[\"Ghost\",\"Grass\"],\"base\":{\"HP\":59,\"Attack\":66,\"Defense\":70,\"Sp. Attack\":44,\"Sp. Defense\":55,\"Speed\":41}},{\"id\":711,\"name\":{\"english\":\"Gourgeist\",\"japanese\":\"パンプジン\",\"chinese\":\"南瓜怪人\",\"french\":\"Banshitrouye\"},\"type\":[\"Ghost\",\"Grass\"],\"base\":{\"HP\":85,\"Attack\":100,\"Defense\":122,\"Sp. Attack\":58,\"Sp. Defense\":75,\"Speed\":54}},{\"id\":712,\"name\":{\"english\":\"Bergmite\",\"japanese\":\"カチコール\",\"chinese\":\"冰宝\",\"french\":\"Grelaçon\"},\"type\":[\"Ice\"],\"base\":{\"HP\":55,\"Attack\":69,\"Defense\":85,\"Sp. Attack\":32,\"Sp. Defense\":35,\"Speed\":28}},{\"id\":713,\"name\":{\"english\":\"Avalugg\",\"japanese\":\"クレベース\",\"chinese\":\"冰岩怪\",\"french\":\"Séracrawl\"},\"type\":[\"Ice\"],\"base\":{\"HP\":95,\"Attack\":117,\"Defense\":184,\"Sp. Attack\":44,\"Sp. Defense\":46,\"Speed\":28}},{\"id\":714,\"name\":{\"english\":\"Noibat\",\"japanese\":\"オンバット\",\"chinese\":\"嗡蝠\",\"french\":\"Sonistrelle\"},\"type\":[\"Flying\",\"Dragon\"],\"base\":{\"HP\":40,\"Attack\":30,\"Defense\":35,\"Sp. Attack\":45,\"Sp. Defense\":40,\"Speed\":55}},{\"id\":715,\"name\":{\"english\":\"Noivern\",\"japanese\":\"オンバーン\",\"chinese\":\"音波龙\",\"french\":\"Bruyverne\"},\"type\":[\"Flying\",\"Dragon\"],\"base\":{\"HP\":85,\"Attack\":70,\"Defense\":80,\"Sp. Attack\":97,\"Sp. Defense\":80,\"Speed\":123}},{\"id\":716,\"name\":{\"english\":\"Xerneas\",\"japanese\":\"ゼルネアス\",\"chinese\":\"哲尔尼亚斯\",\"french\":\"Xerneas\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":126,\"Attack\":131,\"Defense\":95,\"Sp. Attack\":131,\"Sp. Defense\":98,\"Speed\":99}},{\"id\":717,\"name\":{\"english\":\"Yveltal\",\"japanese\":\"イベルタル\",\"chinese\":\"伊裴尔塔尔\",\"french\":\"Yveltal\"},\"type\":[\"Dark\",\"Flying\"],\"base\":{\"HP\":126,\"Attack\":131,\"Defense\":95,\"Sp. Attack\":131,\"Sp. Defense\":98,\"Speed\":99}},{\"id\":718,\"name\":{\"english\":\"Zygarde\",\"japanese\":\"ジガルデ\",\"chinese\":\"基格尔德\",\"french\":\"Zygarde\"},\"type\":[\"Dragon\",\"Ground\"],\"base\":{\"HP\":108,\"Attack\":100,\"Defense\":121,\"Sp. Attack\":81,\"Sp. Defense\":95,\"Speed\":95}},{\"id\":719,\"name\":{\"english\":\"Diancie\",\"japanese\":\"ディアンシー\",\"chinese\":\"蒂安希\",\"french\":\"Diancie\"},\"type\":[\"Rock\",\"Fairy\"],\"base\":{\"HP\":50,\"Attack\":100,\"Defense\":150,\"Sp. Attack\":100,\"Sp. Defense\":150,\"Speed\":50}},{\"id\":720,\"name\":{\"english\":\"Hoopa\",\"japanese\":\"フーパ\",\"chinese\":\"胡帕\",\"french\":\"Hoopa\"},\"type\":[\"Psychic\",\"Ghost\"],\"base\":{\"HP\":80,\"Attack\":110,\"Defense\":60,\"Sp. Attack\":150,\"Sp. Defense\":130,\"Speed\":70}},{\"id\":721,\"name\":{\"english\":\"Volcanion\",\"japanese\":\"ボルケニオン\",\"chinese\":\"波尔凯尼恩\",\"french\":\"Volcanion\"},\"type\":[\"Fire\",\"Water\"],\"base\":{\"HP\":80,\"Attack\":110,\"Defense\":120,\"Sp. Attack\":130,\"Sp. Defense\":90,\"Speed\":70}},{\"id\":722,\"name\":{\"english\":\"Rowlet\",\"japanese\":\"モクロー\",\"chinese\":\"木木枭\",\"french\":\"Brindibou\"},\"type\":[\"Grass\",\"Flying\"],\"base\":{\"HP\":68,\"Attack\":55,\"Defense\":55,\"Sp. Attack\":50,\"Sp. Defense\":50,\"Speed\":42}},{\"id\":723,\"name\":{\"english\":\"Dartrix\",\"japanese\":\"フクスロー\",\"chinese\":\"投羽枭\",\"french\":\"Efflèche\"},\"type\":[\"Grass\",\"Flying\"],\"base\":{\"HP\":78,\"Attack\":75,\"Defense\":75,\"Sp. Attack\":70,\"Sp. Defense\":70,\"Speed\":52}},{\"id\":724,\"name\":{\"english\":\"Decidueye\",\"japanese\":\"ジュナイパー\",\"chinese\":\"狙射树枭\",\"french\":\"Archéduc\"},\"type\":[\"Grass\",\"Ghost\"],\"base\":{\"HP\":78,\"Attack\":107,\"Defense\":75,\"Sp. Attack\":100,\"Sp. Defense\":100,\"Speed\":70}},{\"id\":725,\"name\":{\"english\":\"Litten\",\"japanese\":\"ニャビー\",\"chinese\":\"火斑喵\",\"french\":\"Flamiaou\"},\"type\":[\"Fire\"],\"base\":{\"HP\":45,\"Attack\":65,\"Defense\":40,\"Sp. Attack\":60,\"Sp. Defense\":40,\"Speed\":70}},{\"id\":726,\"name\":{\"english\":\"Torracat\",\"japanese\":\"ニャヒート\",\"chinese\":\"炎热喵\",\"french\":\"Matoufeu\"},\"type\":[\"Fire\"],\"base\":{\"HP\":65,\"Attack\":85,\"Defense\":50,\"Sp. Attack\":80,\"Sp. Defense\":50,\"Speed\":90}},{\"id\":727,\"name\":{\"english\":\"Incineroar\",\"japanese\":\"ガオガエン\",\"chinese\":\"炽焰咆哮虎\",\"french\":\"Félinferno\"},\"type\":[\"Fire\",\"Dark\"],\"base\":{\"HP\":95,\"Attack\":115,\"Defense\":90,\"Sp. Attack\":80,\"Sp. Defense\":90,\"Speed\":60}},{\"id\":728,\"name\":{\"english\":\"Popplio\",\"japanese\":\"アシマリ\",\"chinese\":\"球球海狮\",\"french\":\"Otaquin\"},\"type\":[\"Water\"],\"base\":{\"HP\":50,\"Attack\":54,\"Defense\":54,\"Sp. Attack\":66,\"Sp. Defense\":56,\"Speed\":40}},{\"id\":729,\"name\":{\"english\":\"Brionne\",\"japanese\":\"オシャマリ\",\"chinese\":\"花漾海狮\",\"french\":\"Otarlette\"},\"type\":[\"Water\"],\"base\":{\"HP\":60,\"Attack\":69,\"Defense\":69,\"Sp. Attack\":91,\"Sp. Defense\":81,\"Speed\":50}},{\"id\":730,\"name\":{\"english\":\"Primarina\",\"japanese\":\"アシレーヌ\",\"chinese\":\"西狮海壬\",\"french\":\"Oratoria\"},\"type\":[\"Water\",\"Fairy\"],\"base\":{\"HP\":80,\"Attack\":74,\"Defense\":74,\"Sp. Attack\":126,\"Sp. Defense\":116,\"Speed\":60}},{\"id\":731,\"name\":{\"english\":\"Pikipek\",\"japanese\":\"ツツケラ\",\"chinese\":\"小笃儿\",\"french\":\"Picassaut\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":35,\"Attack\":75,\"Defense\":30,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":65}},{\"id\":732,\"name\":{\"english\":\"Trumbeak\",\"japanese\":\"ケララッパ\",\"chinese\":\"喇叭啄鸟\",\"french\":\"Piclairon\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":55,\"Attack\":85,\"Defense\":50,\"Sp. Attack\":40,\"Sp. Defense\":50,\"Speed\":75}},{\"id\":733,\"name\":{\"english\":\"Toucannon\",\"japanese\":\"ドデカバシ\",\"chinese\":\"铳嘴大鸟\",\"french\":\"Bazoucan\"},\"type\":[\"Normal\",\"Flying\"],\"base\":{\"HP\":80,\"Attack\":120,\"Defense\":75,\"Sp. Attack\":75,\"Sp. Defense\":75,\"Speed\":60}},{\"id\":734,\"name\":{\"english\":\"Yungoos\",\"japanese\":\"ヤングース\",\"chinese\":\"猫鼬少\",\"french\":\"Manglouton\"},\"type\":[\"Normal\"],\"base\":{\"HP\":48,\"Attack\":70,\"Defense\":30,\"Sp. Attack\":30,\"Sp. Defense\":30,\"Speed\":45}},{\"id\":735,\"name\":{\"english\":\"Gumshoos\",\"japanese\":\"デカグース\",\"chinese\":\"猫鼬探长\",\"french\":\"Argouste\"},\"type\":[\"Normal\"],\"base\":{\"HP\":88,\"Attack\":110,\"Defense\":60,\"Sp. Attack\":55,\"Sp. Defense\":60,\"Speed\":45}},{\"id\":736,\"name\":{\"english\":\"Grubbin\",\"japanese\":\"アゴジムシ\",\"chinese\":\"强颚鸡母虫\",\"french\":\"Larvibule\"},\"type\":[\"Bug\"],\"base\":{\"HP\":47,\"Attack\":62,\"Defense\":45,\"Sp. Attack\":55,\"Sp. Defense\":45,\"Speed\":46}},{\"id\":737,\"name\":{\"english\":\"Charjabug\",\"japanese\":\"デンヂムシ\",\"chinese\":\"虫电宝\",\"french\":\"Chrysapile\"},\"type\":[\"Bug\",\"Electric\"],\"base\":{\"HP\":57,\"Attack\":82,\"Defense\":95,\"Sp. Attack\":55,\"Sp. Defense\":75,\"Speed\":36}},{\"id\":738,\"name\":{\"english\":\"Vikavolt\",\"japanese\":\"クワガノン\",\"chinese\":\"锹农炮虫\",\"french\":\"Lucanon\"},\"type\":[\"Bug\",\"Electric\"],\"base\":{\"HP\":77,\"Attack\":70,\"Defense\":90,\"Sp. Attack\":145,\"Sp. Defense\":75,\"Speed\":43}},{\"id\":739,\"name\":{\"english\":\"Crabrawler\",\"japanese\":\"マケンカニ\",\"chinese\":\"好胜蟹\",\"french\":\"Crabagarre\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":47,\"Attack\":82,\"Defense\":57,\"Sp. Attack\":42,\"Sp. Defense\":47,\"Speed\":63}},{\"id\":740,\"name\":{\"english\":\"Crabominable\",\"japanese\":\"ケケンカニ\",\"chinese\":\"好胜毛蟹\",\"french\":\"Crabominable\"},\"type\":[\"Fighting\",\"Ice\"],\"base\":{\"HP\":97,\"Attack\":132,\"Defense\":77,\"Sp. Attack\":62,\"Sp. Defense\":67,\"Speed\":43}},{\"id\":741,\"name\":{\"english\":\"Oricorio\",\"japanese\":\"オドリドリ\",\"chinese\":\"花舞鸟\",\"french\":\"Plumeline\"},\"type\":[\"Fire\",\"Flying\"],\"base\":{\"HP\":75,\"Attack\":70,\"Defense\":70,\"Sp. Attack\":98,\"Sp. Defense\":70,\"Speed\":93}},{\"id\":742,\"name\":{\"english\":\"Cutiefly\",\"japanese\":\"アブリー\",\"chinese\":\"萌虻\",\"french\":\"Bombydou\"},\"type\":[\"Bug\",\"Fairy\"],\"base\":{\"HP\":40,\"Attack\":45,\"Defense\":40,\"Sp. Attack\":55,\"Sp. Defense\":40,\"Speed\":84}},{\"id\":743,\"name\":{\"english\":\"Ribombee\",\"japanese\":\"アブリボン\",\"chinese\":\"蝶结萌虻\",\"french\":\"Rubombelle\"},\"type\":[\"Bug\",\"Fairy\"],\"base\":{\"HP\":60,\"Attack\":55,\"Defense\":60,\"Sp. Attack\":95,\"Sp. Defense\":70,\"Speed\":124}},{\"id\":744,\"name\":{\"english\":\"Rockruff\",\"japanese\":\"イワンコ\",\"chinese\":\"岩狗狗\",\"french\":\"Rocabot\"},\"type\":[\"Rock\"],\"base\":{\"HP\":45,\"Attack\":65,\"Defense\":40,\"Sp. Attack\":30,\"Sp. Defense\":40,\"Speed\":60}},{\"id\":745,\"name\":{\"english\":\"Lycanroc\",\"japanese\":\"ルガルガン\",\"chinese\":\"鬃岩狼人\",\"french\":\"Lougaroc\"},\"type\":[\"Rock\"],\"base\":{\"HP\":75,\"Attack\":115,\"Defense\":65,\"Sp. Attack\":55,\"Sp. Defense\":65,\"Speed\":112}},{\"id\":746,\"name\":{\"english\":\"Wishiwashi\",\"japanese\":\"ヨワシ\",\"chinese\":\"弱丁鱼\",\"french\":\"Froussardine\"},\"type\":[\"Water\"],\"base\":{\"HP\":45,\"Attack\":20,\"Defense\":20,\"Sp. Attack\":25,\"Sp. Defense\":25,\"Speed\":40}},{\"id\":747,\"name\":{\"english\":\"Mareanie\",\"japanese\":\"ヒドイデ\",\"chinese\":\"好坏星\",\"french\":\"Vorastérie\"},\"type\":[\"Poison\",\"Water\"],\"base\":{\"HP\":50,\"Attack\":53,\"Defense\":62,\"Sp. Attack\":43,\"Sp. Defense\":52,\"Speed\":45}},{\"id\":748,\"name\":{\"english\":\"Toxapex\",\"japanese\":\"ドヒドイデ\",\"chinese\":\"超坏星\",\"french\":\"Prédastérie\"},\"type\":[\"Poison\",\"Water\"],\"base\":{\"HP\":50,\"Attack\":63,\"Defense\":152,\"Sp. Attack\":53,\"Sp. Defense\":142,\"Speed\":35}},{\"id\":749,\"name\":{\"english\":\"Mudbray\",\"japanese\":\"ドロバンコ\",\"chinese\":\"泥驴仔\",\"french\":\"Tiboudet\"},\"type\":[\"Ground\"],\"base\":{\"HP\":70,\"Attack\":100,\"Defense\":70,\"Sp. Attack\":45,\"Sp. Defense\":55,\"Speed\":45}},{\"id\":750,\"name\":{\"english\":\"Mudsdale\",\"japanese\":\"バンバドロ\",\"chinese\":\"重泥挽马\",\"french\":\"Bourrinos\"},\"type\":[\"Ground\"],\"base\":{\"HP\":100,\"Attack\":125,\"Defense\":100,\"Sp. Attack\":55,\"Sp. Defense\":85,\"Speed\":35}},{\"id\":751,\"name\":{\"english\":\"Dewpider\",\"japanese\":\"シズクモ\",\"chinese\":\"滴蛛\",\"french\":\"Araqua\"},\"type\":[\"Water\",\"Bug\"],\"base\":{\"HP\":38,\"Attack\":40,\"Defense\":52,\"Sp. Attack\":40,\"Sp. Defense\":72,\"Speed\":27}},{\"id\":752,\"name\":{\"english\":\"Araquanid\",\"japanese\":\"オニシズクモ\",\"chinese\":\"滴蛛霸\",\"french\":\"Tarenbulle\"},\"type\":[\"Water\",\"Bug\"],\"base\":{\"HP\":68,\"Attack\":70,\"Defense\":92,\"Sp. Attack\":50,\"Sp. Defense\":132,\"Speed\":42}},{\"id\":753,\"name\":{\"english\":\"Fomantis\",\"japanese\":\"カリキリ\",\"chinese\":\"伪螳草\",\"french\":\"Mimantis\"},\"type\":[\"Grass\"],\"base\":{\"HP\":40,\"Attack\":55,\"Defense\":35,\"Sp. Attack\":50,\"Sp. Defense\":35,\"Speed\":35}},{\"id\":754,\"name\":{\"english\":\"Lurantis\",\"japanese\":\"ラランテス\",\"chinese\":\"兰螳花\",\"french\":\"Floramantis\"},\"type\":[\"Grass\"],\"base\":{\"HP\":70,\"Attack\":105,\"Defense\":90,\"Sp. Attack\":80,\"Sp. Defense\":90,\"Speed\":45}},{\"id\":755,\"name\":{\"english\":\"Morelull\",\"japanese\":\"ネマシュ\",\"chinese\":\"睡睡菇\",\"french\":\"Spododo\"},\"type\":[\"Grass\",\"Fairy\"],\"base\":{\"HP\":40,\"Attack\":35,\"Defense\":55,\"Sp. Attack\":65,\"Sp. Defense\":75,\"Speed\":15}},{\"id\":756,\"name\":{\"english\":\"Shiinotic\",\"japanese\":\"マシェード\",\"chinese\":\"灯罩夜菇\",\"french\":\"Lampignon\"},\"type\":[\"Grass\",\"Fairy\"],\"base\":{\"HP\":60,\"Attack\":45,\"Defense\":80,\"Sp. Attack\":90,\"Sp. Defense\":100,\"Speed\":30}},{\"id\":757,\"name\":{\"english\":\"Salandit\",\"japanese\":\"ヤトウモリ\",\"chinese\":\"夜盗火蜥\",\"french\":\"Tritox\"},\"type\":[\"Poison\",\"Fire\"],\"base\":{\"HP\":48,\"Attack\":44,\"Defense\":40,\"Sp. Attack\":71,\"Sp. Defense\":40,\"Speed\":77}},{\"id\":758,\"name\":{\"english\":\"Salazzle\",\"japanese\":\"エンニュート\",\"chinese\":\"焰后蜥\",\"french\":\"Malamandre\"},\"type\":[\"Poison\",\"Fire\"],\"base\":{\"HP\":68,\"Attack\":64,\"Defense\":60,\"Sp. Attack\":111,\"Sp. Defense\":60,\"Speed\":117}},{\"id\":759,\"name\":{\"english\":\"Stufful\",\"japanese\":\"ヌイコグマ\",\"chinese\":\"童偶熊\",\"french\":\"Nounourson\"},\"type\":[\"Normal\",\"Fighting\"],\"base\":{\"HP\":70,\"Attack\":75,\"Defense\":50,\"Sp. Attack\":45,\"Sp. Defense\":50,\"Speed\":50}},{\"id\":760,\"name\":{\"english\":\"Bewear\",\"japanese\":\"キテルグマ\",\"chinese\":\"穿着熊\",\"french\":\"Chelours\"},\"type\":[\"Normal\",\"Fighting\"],\"base\":{\"HP\":120,\"Attack\":125,\"Defense\":80,\"Sp. Attack\":55,\"Sp. Defense\":60,\"Speed\":60}},{\"id\":761,\"name\":{\"english\":\"Bounsweet\",\"japanese\":\"アマカジ\",\"chinese\":\"甜竹竹\",\"french\":\"Croquine\"},\"type\":[\"Grass\"],\"base\":{\"HP\":42,\"Attack\":30,\"Defense\":38,\"Sp. Attack\":30,\"Sp. Defense\":38,\"Speed\":32}},{\"id\":762,\"name\":{\"english\":\"Steenee\",\"japanese\":\"アママイコ\",\"chinese\":\"甜舞妮\",\"french\":\"Candine\"},\"type\":[\"Grass\"],\"base\":{\"HP\":52,\"Attack\":40,\"Defense\":48,\"Sp. Attack\":40,\"Sp. Defense\":48,\"Speed\":62}},{\"id\":763,\"name\":{\"english\":\"Tsareena\",\"japanese\":\"アマージョ\",\"chinese\":\"甜冷美后\",\"french\":\"Sucreine\"},\"type\":[\"Grass\"],\"base\":{\"HP\":72,\"Attack\":120,\"Defense\":98,\"Sp. Attack\":50,\"Sp. Defense\":98,\"Speed\":72}},{\"id\":764,\"name\":{\"english\":\"Comfey\",\"japanese\":\"キュワワー\",\"chinese\":\"花疗环环\",\"french\":\"Guérilande\"},\"type\":[\"Fairy\"],\"base\":{\"HP\":51,\"Attack\":52,\"Defense\":90,\"Sp. Attack\":82,\"Sp. Defense\":110,\"Speed\":100}},{\"id\":765,\"name\":{\"english\":\"Oranguru\",\"japanese\":\"ヤレユータン\",\"chinese\":\"智挥猩\",\"french\":\"Gouroutan\"},\"type\":[\"Normal\",\"Psychic\"],\"base\":{\"HP\":90,\"Attack\":60,\"Defense\":80,\"Sp. Attack\":90,\"Sp. Defense\":110,\"Speed\":60}},{\"id\":766,\"name\":{\"english\":\"Passimian\",\"japanese\":\"ナゲツケサル\",\"chinese\":\"投掷猴\",\"french\":\"Quartermac\"},\"type\":[\"Fighting\"],\"base\":{\"HP\":100,\"Attack\":120,\"Defense\":90,\"Sp. Attack\":40,\"Sp. Defense\":60,\"Speed\":80}},{\"id\":767,\"name\":{\"english\":\"Wimpod\",\"japanese\":\"コソクムシ\",\"chinese\":\"胆小虫\",\"french\":\"Sovkipou\"},\"type\":[\"Bug\",\"Water\"],\"base\":{\"HP\":25,\"Attack\":35,\"Defense\":40,\"Sp. Attack\":20,\"Sp. Defense\":30,\"Speed\":80}},{\"id\":768,\"name\":{\"english\":\"Golisopod\",\"japanese\":\"グソクムシャ\",\"chinese\":\"具甲武者\",\"french\":\"Sarmuraï\"},\"type\":[\"Bug\",\"Water\"],\"base\":{\"HP\":75,\"Attack\":125,\"Defense\":140,\"Sp. Attack\":60,\"Sp. Defense\":90,\"Speed\":40}},{\"id\":769,\"name\":{\"english\":\"Sandygast\",\"japanese\":\"スナバァ\",\"chinese\":\"沙丘娃\",\"french\":\"Bacabouh\"},\"type\":[\"Ghost\",\"Ground\"],\"base\":{\"HP\":55,\"Attack\":55,\"Defense\":80,\"Sp. Attack\":70,\"Sp. Defense\":45,\"Speed\":15}},{\"id\":770,\"name\":{\"english\":\"Palossand\",\"japanese\":\"シロデスナ\",\"chinese\":\"噬沙堡爷\",\"french\":\"Trépassable\"},\"type\":[\"Ghost\",\"Ground\"],\"base\":{\"HP\":85,\"Attack\":75,\"Defense\":110,\"Sp. Attack\":100,\"Sp. Defense\":75,\"Speed\":35}},{\"id\":771,\"name\":{\"english\":\"Pyukumuku\",\"japanese\":\"ナマコブシ\",\"chinese\":\"拳海参\",\"french\":\"Concombaffe\"},\"type\":[\"Water\"],\"base\":{\"HP\":55,\"Attack\":60,\"Defense\":130,\"Sp. Attack\":30,\"Sp. Defense\":130,\"Speed\":5}},{\"id\":772,\"name\":{\"english\":\"Type: Null\",\"japanese\":\"タイプ：ヌル\",\"chinese\":\"属性：空\",\"french\":\"Silvallié\"},\"type\":[\"Normal\"],\"base\":{\"HP\":95,\"Attack\":95,\"Defense\":95,\"Sp. Attack\":95,\"Sp. Defense\":95,\"Speed\":59}},{\"id\":773,\"name\":{\"english\":\"Silvally\",\"japanese\":\"シルヴァディ\",\"chinese\":\"银伴战兽\",\"french\":\"Météno\"},\"type\":[\"Normal\"],\"base\":{\"HP\":95,\"Attack\":95,\"Defense\":95,\"Sp. Attack\":95,\"Sp. Defense\":95,\"Speed\":95}},{\"id\":774,\"name\":{\"english\":\"Minior\",\"japanese\":\"メテノ\",\"chinese\":\"小陨星\",\"french\":\"Dodoala\"},\"type\":[\"Rock\",\"Flying\"],\"base\":{\"HP\":60,\"Attack\":60,\"Defense\":100,\"Sp. Attack\":60,\"Sp. Defense\":100,\"Speed\":60}},{\"id\":775,\"name\":{\"english\":\"Komala\",\"japanese\":\"ネッコアラ\",\"chinese\":\"树枕尾熊\",\"french\":\"Boumata\"},\"type\":[\"Normal\"],\"base\":{\"HP\":65,\"Attack\":115,\"Defense\":65,\"Sp. Attack\":75,\"Sp. Defense\":95,\"Speed\":65}},{\"id\":776,\"name\":{\"english\":\"Turtonator\",\"japanese\":\"バクガメス\",\"chinese\":\"爆焰龟兽\",\"french\":\"Togedemaru\"},\"type\":[\"Fire\",\"Dragon\"],\"base\":{\"HP\":60,\"Attack\":78,\"Defense\":135,\"Sp. Attack\":91,\"Sp. Defense\":85,\"Speed\":36}},{\"id\":777,\"name\":{\"english\":\"Togedemaru\",\"japanese\":\"トゲデマル\",\"chinese\":\"托戈德玛尔\",\"french\":\"Mimiqui\"},\"type\":[\"Electric\",\"Steel\"],\"base\":{\"HP\":65,\"Attack\":98,\"Defense\":63,\"Sp. Attack\":40,\"Sp. Defense\":73,\"Speed\":96}},{\"id\":778,\"name\":{\"english\":\"Mimikyu\",\"japanese\":\"ミミッキュ\",\"chinese\":\"谜拟Ｑ\",\"french\":\"Denticrisse\"},\"type\":[\"Ghost\",\"Fairy\"],\"base\":{\"HP\":55,\"Attack\":90,\"Defense\":80,\"Sp. Attack\":50,\"Sp. Defense\":105,\"Speed\":96}},{\"id\":779,\"name\":{\"english\":\"Bruxish\",\"japanese\":\"ハギギシリ\",\"chinese\":\"磨牙彩皮鱼\",\"french\":\"Draïeul\"},\"type\":[\"Water\",\"Psychic\"],\"base\":{\"HP\":68,\"Attack\":105,\"Defense\":70,\"Sp. Attack\":70,\"Sp. Defense\":70,\"Speed\":92}},{\"id\":780,\"name\":{\"english\":\"Drampa\",\"japanese\":\"ジジーロン\",\"chinese\":\"老翁龙\",\"french\":\"Sinistrail\"},\"type\":[\"Normal\",\"Dragon\"],\"base\":{\"HP\":78,\"Attack\":60,\"Defense\":85,\"Sp. Attack\":135,\"Sp. Defense\":91,\"Speed\":36}},{\"id\":781,\"name\":{\"english\":\"Dhelmise\",\"japanese\":\"ダダリン\",\"chinese\":\"破破舵轮\",\"french\":\"Bébécaille\"},\"type\":[\"Ghost\",\"Grass\"],\"base\":{\"HP\":70,\"Attack\":131,\"Defense\":100,\"Sp. Attack\":86,\"Sp. Defense\":90,\"Speed\":40}},{\"id\":782,\"name\":{\"english\":\"Jangmo-o\",\"japanese\":\"ジャラコ\",\"chinese\":\"心鳞宝\",\"french\":\"Écaïd\"},\"type\":[\"Dragon\"],\"base\":{\"HP\":45,\"Attack\":55,\"Defense\":65,\"Sp. Attack\":45,\"Sp. Defense\":45,\"Speed\":45}},{\"id\":783,\"name\":{\"english\":\"Hakamo-o\",\"japanese\":\"ジャランゴ\",\"chinese\":\"鳞甲龙\",\"french\":\"Ékaïser\"},\"type\":[\"Dragon\",\"Fighting\"],\"base\":{\"HP\":55,\"Attack\":75,\"Defense\":90,\"Sp. Attack\":65,\"Sp. Defense\":70,\"Speed\":65}},{\"id\":784,\"name\":{\"english\":\"Kommo-o\",\"japanese\":\"ジャラランガ\",\"chinese\":\"杖尾鳞甲龙\",\"french\":\"Tokorico\"},\"type\":[\"Dragon\",\"Fighting\"],\"base\":{\"HP\":75,\"Attack\":110,\"Defense\":125,\"Sp. Attack\":100,\"Sp. Defense\":105,\"Speed\":85}},{\"id\":785,\"name\":{\"english\":\"Tapu Koko\",\"japanese\":\"カプ・コケコ\",\"chinese\":\"卡璞・鸣鸣\",\"french\":\"Tokopiyon\"},\"type\":[\"Electric\",\"Fairy\"],\"base\":{\"HP\":70,\"Attack\":115,\"Defense\":85,\"Sp. Attack\":95,\"Sp. Defense\":75,\"Speed\":130}},{\"id\":786,\"name\":{\"english\":\"Tapu Lele\",\"japanese\":\"カプ・テテフ\",\"chinese\":\"卡璞・蝶蝶\",\"french\":\"Tokotoro\"},\"type\":[\"Psychic\",\"Fairy\"],\"base\":{\"HP\":70,\"Attack\":85,\"Defense\":75,\"Sp. Attack\":130,\"Sp. Defense\":115,\"Speed\":95}},{\"id\":787,\"name\":{\"english\":\"Tapu Bulu\",\"japanese\":\"カプ・ブルル\",\"chinese\":\"卡璞・哞哞\",\"french\":\"Tokopisco\"},\"type\":[\"Grass\",\"Fairy\"],\"base\":{\"HP\":70,\"Attack\":130,\"Defense\":115,\"Sp. Attack\":85,\"Sp. Defense\":95,\"Speed\":75}},{\"id\":788,\"name\":{\"english\":\"Tapu Fini\",\"japanese\":\"カプ・レヒレ\",\"chinese\":\"卡璞・鳍鳍\",\"french\":\"Cosmog\"},\"type\":[\"Water\",\"Fairy\"],\"base\":{\"HP\":70,\"Attack\":75,\"Defense\":115,\"Sp. Attack\":95,\"Sp. Defense\":130,\"Speed\":85}},{\"id\":789,\"name\":{\"english\":\"Cosmog\",\"japanese\":\"コスモッグ\",\"chinese\":\"科斯莫古\",\"french\":\"Cosmovum\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":43,\"Attack\":29,\"Defense\":31,\"Sp. Attack\":29,\"Sp. Defense\":31,\"Speed\":37}},{\"id\":790,\"name\":{\"english\":\"Cosmoem\",\"japanese\":\"コスモウム\",\"chinese\":\"科斯莫姆\",\"french\":\"Solgaleo\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":43,\"Attack\":29,\"Defense\":131,\"Sp. Attack\":29,\"Sp. Defense\":131,\"Speed\":37}},{\"id\":791,\"name\":{\"english\":\"Solgaleo\",\"japanese\":\"ソルガレオ\",\"chinese\":\"索尔迦雷欧\",\"french\":\"Lunala\"},\"type\":[\"Psychic\",\"Steel\"],\"base\":{\"HP\":137,\"Attack\":137,\"Defense\":107,\"Sp. Attack\":113,\"Sp. Defense\":89,\"Speed\":97}},{\"id\":792,\"name\":{\"english\":\"Lunala\",\"japanese\":\"ルナアーラ\",\"chinese\":\"露奈雅拉\",\"french\":\"Zéroïd\"},\"type\":[\"Psychic\",\"Ghost\"],\"base\":{\"HP\":137,\"Attack\":113,\"Defense\":89,\"Sp. Attack\":137,\"Sp. Defense\":107,\"Speed\":97}},{\"id\":793,\"name\":{\"english\":\"Nihilego\",\"japanese\":\"ウツロイド\",\"chinese\":\"虚吾伊德\",\"french\":\"Mouscoto\"},\"type\":[\"Rock\",\"Poison\"],\"base\":{\"HP\":109,\"Attack\":53,\"Defense\":47,\"Sp. Attack\":127,\"Sp. Defense\":131,\"Speed\":103}},{\"id\":794,\"name\":{\"english\":\"Buzzwole\",\"japanese\":\"マッシブーン\",\"chinese\":\"爆肌蚊\",\"french\":\"Cancrelove\"},\"type\":[\"Bug\",\"Fighting\"],\"base\":{\"HP\":107,\"Attack\":139,\"Defense\":139,\"Sp. Attack\":53,\"Sp. Defense\":53,\"Speed\":79}},{\"id\":795,\"name\":{\"english\":\"Pheromosa\",\"japanese\":\"フェローチェ\",\"chinese\":\"费洛美螂\",\"french\":\"Câblifère\"},\"type\":[\"Bug\",\"Fighting\"],\"base\":{\"HP\":71,\"Attack\":137,\"Defense\":37,\"Sp. Attack\":137,\"Sp. Defense\":37,\"Speed\":151}},{\"id\":796,\"name\":{\"english\":\"Xurkitree\",\"japanese\":\"デンジュモク\",\"chinese\":\"电束木\",\"french\":\"Bamboiselle\"},\"type\":[\"Electric\"],\"base\":{\"HP\":83,\"Attack\":89,\"Defense\":71,\"Sp. Attack\":173,\"Sp. Defense\":71,\"Speed\":83}},{\"id\":797,\"name\":{\"english\":\"Celesteela\",\"japanese\":\"テッカグヤ\",\"chinese\":\"铁火辉夜\",\"french\":\"Katagami\"},\"type\":[\"Steel\",\"Flying\"],\"base\":{\"HP\":97,\"Attack\":101,\"Defense\":103,\"Sp. Attack\":107,\"Sp. Defense\":101,\"Speed\":61}},{\"id\":798,\"name\":{\"english\":\"Kartana\",\"japanese\":\"カミツルギ\",\"chinese\":\"纸御剑\",\"french\":\"Engloutyran\"},\"type\":[\"Grass\",\"Steel\"],\"base\":{\"HP\":59,\"Attack\":181,\"Defense\":131,\"Sp. Attack\":59,\"Sp. Defense\":31,\"Speed\":109}},{\"id\":799,\"name\":{\"english\":\"Guzzlord\",\"japanese\":\"アクジキング\",\"chinese\":\"恶食大王\",\"french\":\"Necrozma\"},\"type\":[\"Dark\",\"Dragon\"],\"base\":{\"HP\":223,\"Attack\":101,\"Defense\":53,\"Sp. Attack\":97,\"Sp. Defense\":53,\"Speed\":43}},{\"id\":800,\"name\":{\"english\":\"Necrozma\",\"japanese\":\"ネクロズマ\",\"chinese\":\"奈克洛兹玛\",\"french\":\"Magearna\"},\"type\":[\"Psychic\"],\"base\":{\"HP\":97,\"Attack\":107,\"Defense\":101,\"Sp. Attack\":127,\"Sp. Defense\":89,\"Speed\":79}},{\"id\":801,\"name\":{\"english\":\"Magearna\",\"japanese\":\"マギアナ\",\"chinese\":\"玛机雅娜\",\"french\":\"Marshadow\"},\"type\":[\"Steel\",\"Fairy\"],\"base\":{\"HP\":80,\"Attack\":95,\"Defense\":115,\"Sp. Attack\":130,\"Sp. Defense\":115,\"Speed\":65}},{\"id\":802,\"name\":{\"english\":\"Marshadow\",\"japanese\":\"マーシャドー\",\"chinese\":\"玛夏多\",\"french\":\"Vémini\"},\"type\":[\"Fighting\",\"Ghost\"],\"base\":{\"HP\":90,\"Attack\":125,\"Defense\":80,\"Sp. Attack\":90,\"Sp. Defense\":90,\"Speed\":125}},{\"id\":803,\"name\":{\"english\":\"Poipole\",\"japanese\":\"ベベノム\",\"chinese\":\"毒贝比\",\"french\":\"Mandrillon\"},\"type\":[\"Poison\"],\"base\":{\"HP\":67,\"Attack\":73,\"Defense\":67,\"Sp. Attack\":73,\"Sp. Defense\":67,\"Speed\":73}},{\"id\":804,\"name\":{\"english\":\"Naganadel\",\"japanese\":\"アーゴヨン\",\"chinese\":\"四颚针龙\",\"french\":\"Ama-Ama\"},\"type\":[\"Poison\",\"Dragon\"],\"base\":{\"HP\":73,\"Attack\":73,\"Defense\":73,\"Sp. Attack\":127,\"Sp. Defense\":73,\"Speed\":121}},{\"id\":805,\"name\":{\"english\":\"Stakataka\",\"japanese\":\"ツンデツンデ\",\"chinese\":\"垒磊石\",\"french\":\"Pierroteknik\"},\"type\":[\"Rock\",\"Steel\"],\"base\":{\"HP\":61,\"Attack\":131,\"Defense\":211,\"Sp. Attack\":53,\"Sp. Defense\":101,\"Speed\":13}},{\"id\":806,\"name\":{\"english\":\"Blacephalon\",\"japanese\":\"ズガドーン\",\"chinese\":\"砰头小丑\",\"french\":\"Zeraora\"},\"type\":[\"Fire\",\"Ghost\"],\"base\":{\"HP\":53,\"Attack\":127,\"Defense\":53,\"Sp. Attack\":151,\"Sp. Defense\":79,\"Speed\":107}},{\"id\":807,\"name\":{\"english\":\"Zeraora\",\"japanese\":\"ゼラオラ\",\"chinese\":\"捷拉奥拉\",\"french\":\"Meltan\"},\"type\":[\"Electric\"],\"base\":{\"HP\":88,\"Attack\":112,\"Defense\":75,\"Sp. Attack\":102,\"Sp. Defense\":80,\"Speed\":143}},{\"id\":808,\"name\":{\"english\":\"Meltan\",\"japanese\":\"メルタン\",\"chinese\":\"美录坦\",\"french\":\"Melmetal\"},\"type\":[\"Steel\"],\"base\":{\"HP\":46,\"Attack\":65,\"Defense\":65,\"Sp. Attack\":55,\"Sp. Defense\":35,\"Speed\":34}},{\"id\":809,\"name\":{\"english\":\"Melmetal\",\"japanese\":\"メルメタル\",\"chinese\":\"美录梅塔\",\"french\":\"\"},\"type\":[\"Steel\"],\"base\":{\"HP\":135,\"Attack\":143,\"Defense\":143,\"Sp. Attack\":80,\"Sp. Defense\":65,\"Speed\":34}}]");

/***/ }),

/***/ "./src/pokemonType.js":
/*!****************************!*\
  !*** ./src/pokemonType.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);

const PokemonType = prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
  id: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number.isRequired,
  name: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    english: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    japanese: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    chinese: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired,
    french: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired
  }),
  type: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string.isRequired),
  base: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    HP: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number.isRequired,
    Attack: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number.isRequired,
    Defense: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number.isRequired,
    "Sp. Attack": prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number.isRequired,
    "Sp. Defense": prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number.isRequired,
    Speed: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number.isRequired
  })
});
/* harmony default export */ __webpack_exports__["default"] = (PokemonType);

/***/ }),

/***/ "./src/store.js":
/*!**********************!*\
  !*** ./src/store.js ***!
  \**********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mobx */ "mobx");
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_0__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



class Store {
  constructor() {
    _defineProperty(this, "pokemon", __webpack_require__(/*! ../src/pokemon.json */ "./src/pokemon.json"));

    _defineProperty(this, "filter", "");

    _defineProperty(this, "selectedPokemon", null);

    Object(mobx__WEBPACK_IMPORTED_MODULE_0__["makeAutoObservable"])(this);
  }

  setFilter(filter) {
    this.filter = filter;
  }

  setSelectedPokemon(selectedPokemon) {
    this.selectedPokemon = selectedPokemon;
  }

}

const store = new Store();
/* harmony default export */ __webpack_exports__["default"] = (store);

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@emotion/styled");

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "mobx":
/*!***********************!*\
  !*** external "mobx" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("mobx");

/***/ }),

/***/ "mobx-react":
/*!*****************************!*\
  !*** external "mobx-react" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("mobx-react");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-is");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9yb3V0ZXItY29udGV4dC5qc1wiIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvUG9rZW1vbkZpbHRlci5qc3giLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9Qb2tlbW9uSW5mby5qc3giLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9Qb2tlbW9uUm93LmpzeCIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL1Bva2Vtb25UYWJsZS5qc3giLCJ3ZWJwYWNrOi8vLy4uLy4uL2NsaWVudC9saW5rLnRzeCIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L25vcm1hbGl6ZS10cmFpbGluZy1zbGFzaC50cyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3JvdXRlci50cyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3dpdGgtcm91dGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL3BhdGgtdG8tcmVnZXhwL2luZGV4LmpzIiwid2VicGFjazovLy8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvbWl0dC50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci9yb3V0ZXIudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvZXNjYXBlLXBhdGgtZGVsaW1pdGVycy50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci91dGlscy9mb3JtYXQtdXJsLnRzIiwid2VicGFjazovLy8uLi8uLi8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL2lzLWR5bmFtaWMudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcGFyc2UtcmVsYXRpdmUtdXJsLnRzIiwid2VicGFjazovLy8uLi8uLi8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL3BhdGgtbWF0Y2gudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcHJlcGFyZS1kZXN0aW5hdGlvbi50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci91dGlscy9xdWVyeXN0cmluZy50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci91dGlscy9yZXNvbHZlLXJld3JpdGVzLnRzIiwid2VicGFjazovLy8uLi8uLi8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL3JvdXRlLW1hdGNoZXIudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtcmVnZXgudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi91dGlscy50cyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL25leHQvbGluay5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvbmV4dC9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVXaWxkY2FyZC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvbmV4dC9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy90eXBlb2YuanMiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3Bva2Vtb25UeXBlLmpzIiwid2VicGFjazovLy8uL3NyYy9zdG9yZS5qcyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAZW1vdGlvbi9zdHlsZWRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm1vYnhcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJtb2J4LXJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicHJvcC10eXBlc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QtaXNcIiJdLCJuYW1lcyI6WyJJbnB1dCIsInN0eWxlZCIsImlucHV0IiwiUG9rZW1vbkZpbHRlciIsInN0b3JlIiwiZmlsdGVyIiwiZXZ0Iiwic2V0RmlsdGVyIiwidGFyZ2V0IiwidmFsdWUiLCJvYnNlcnZlciIsIlBva2Vtb25JbmZvIiwic2VsZWN0ZWRQb2tlbW9uIiwibmFtZSIsImVuZ2xpc2giLCJPYmplY3QiLCJrZXlzIiwiYmFzZSIsIm1hcCIsImtleSIsIlBva2Vtb25Sb3ciLCJwb2tlbW9uIiwib25DbGljayIsImlkIiwidHlwZSIsImpvaW4iLCJwcm9wVHlwZXMiLCJQb2tlbW9uVHlwZSIsIlBva2Vtb25UYWJsZSIsInRvTG9jYWxlTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJzbGljZSIsInNldFNlbGVjdGVkUG9rZW1vbiIsImxpc3RlbmVycyIsIkludGVyc2VjdGlvbk9ic2VydmVyIiwid2luZG93IiwicHJlZmV0Y2hlZCIsImNhY2hlZE9ic2VydmVyIiwiZW50cmllcyIsImVudHJ5IiwiY2IiLCJyb290TWFyZ2luIiwibGlzdGVuVG9JbnRlcnNlY3Rpb25zIiwiZ2V0T2JzZXJ2ZXIiLCJjb25zb2xlIiwicm91dGVyIiwiZXJyIiwiaHJlZiIsImV2ZW50IiwiZSIsIm5vZGVOYW1lIiwiaXNNb2RpZmllZEV2ZW50Iiwic2Nyb2xsIiwiYXMiLCJyZXBsYWNlIiwic3VjY2VzcyIsImRvY3VtZW50IiwiYXJncyIsImV4cGVjdGVkIiwiYWN0dWFsIiwicmVxdWlyZWRQcm9wc0d1YXJkIiwicmVxdWlyZWRQcm9wcyIsInByb3BzIiwiY3JlYXRlUHJvcEVycm9yIiwiXyIsIm9wdGlvbmFsUHJvcHNHdWFyZCIsInNoYWxsb3ciLCJwYXNzSHJlZiIsInByZWZldGNoIiwib3B0aW9uYWxQcm9wcyIsImhhc1dhcm5lZCIsIlJlYWN0IiwicCIsInBhdGhuYW1lIiwicmVzb2x2ZWRBcyIsImNoaWxkRWxtIiwiaXNQcmVmZXRjaGVkIiwiY2hpbGRyZW4iLCJjaGlsZCIsIkNoaWxkcmVuIiwiY2hpbGRQcm9wcyIsInJlZiIsImVsIiwic2V0Q2hpbGRFbG0iLCJsaW5rQ2xpY2tlZCIsInByaW9yaXR5IiwiTGluayIsInBhdGgiLCJub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaCIsInByb2Nlc3MiLCJzaW5nbGV0b25Sb3V0ZXIiLCJyZWFkeUNhbGxiYWNrcyIsInJlYWR5IiwidXJsUHJvcGVydHlGaWVsZHMiLCJyb3V0ZXJFdmVudHMiLCJjb3JlTWV0aG9kRmllbGRzIiwiZ2V0IiwiUm91dGVyIiwiZmllbGQiLCJnZXRSb3V0ZXIiLCJldmVudEZpZWxkIiwiX3NpbmdsZXRvblJvdXRlciIsIm1lc3NhZ2UiLCJzdGFjayIsIlJvdXRlckNvbnRleHQiLCJjcmVhdGVSb3V0ZXIiLCJfcm91dGVyIiwiaW5zdGFuY2UiLCJBcnJheSIsIkNvbXBvc2VkQ29tcG9uZW50IiwiZ2V0SW5pdGlhbFByb3BzIiwiV2l0aFJvdXRlcldyYXBwZXIiLCJhbGwiLCJvbiIsIm9mZiIsImVtaXQiLCJoYW5kbGVyIiwiYmFzZVBhdGgiLCJjYW5jZWxsZWQiLCJwcmVmaXgiLCJhZGRQYXRoUHJlZml4IiwidXJsIiwibG9jYXRpb25PcmlnaW4iLCJyZXNvbHZlZCIsImhhc0Jhc2VQYXRoIiwiaW50ZXJwb2xhdGVkUm91dGUiLCJkeW5hbWljUmVnZXgiLCJkeW5hbWljR3JvdXBzIiwiZHluYW1pY01hdGNoZXMiLCJhc1BhdGhuYW1lIiwicGFyYW1zIiwicGFyYW0iLCJyZXBsYWNlZCIsInJlcGVhdCIsIm9wdGlvbmFsIiwiZXNjYXBlUGF0aERlbGltaXRlcnMiLCJyZXN1bHQiLCJmaWx0ZXJlZFF1ZXJ5IiwicXVlcnkiLCJ1cmxBc1N0cmluZyIsImZpbmFsVXJsIiwiaW50ZXJwb2xhdGVkQXMiLCJpbnRlcnBvbGF0ZUFzIiwiaGFzaCIsIm9taXRQYXJtc0Zyb21RdWVyeSIsInJlc29sdmVkSHJlZiIsInJlc29sdmVBcyIsIlBBR0VfTE9BRF9FUlJPUiIsIlN5bWJvbCIsImFkZEJhc2VQYXRoIiwicmVzb2x2ZUhyZWYiLCJtYW51YWxTY3JvbGxSZXN0b3JhdGlvbiIsImNyZWRlbnRpYWxzIiwicmVzIiwiYXR0ZW1wdHMiLCJmZXRjaFJldHJ5IiwiaXNTZXJ2ZXJSZW5kZXIiLCJtYXJrTG9hZGluZ0Vycm9yIiwiY29uc3RydWN0b3IiLCJyb3V0ZSIsImFzUGF0aCIsImNvbXBvbmVudHMiLCJzZGMiLCJzdWIiLCJjbGMiLCJwYWdlTG9hZGVyIiwiX2JwcyIsImV2ZW50cyIsIl93cmFwQXBwIiwiaXNTc3IiLCJpc0ZhbGxiYWNrIiwiX2luRmxpZ2h0Um91dGUiLCJfc2hhbGxvdyIsImxvY2FsZSIsImxvY2FsZXMiLCJkZWZhdWx0TG9jYWxlIiwic3RhdGUiLCJvcHRpb25zIiwic3R5bGVTaGVldHMiLCJfX05fU1NHIiwiaW5pdGlhbFByb3BzIiwiX19OX1NTUCIsIkNvbXBvbmVudCIsIl9fTkVYVF9EQVRBX18iLCJyZWxvYWQiLCJiYWNrIiwicHVzaCIsInByZXBhcmVVcmxBcyIsImlzTG9jYWxVUkwiLCJTVCIsInBlcmZvcm1hbmNlIiwiYWRkTG9jYWxlIiwiY2xlYW5lZEFzIiwiZGVsTG9jYWxlIiwiZGVsQmFzZVBhdGgiLCJwYWdlcyIsIl9fcmV3cml0ZXMiLCJwYXJzZWQiLCJtZXRob2QiLCJwb3RlbnRpYWxIcmVmIiwicGFyc2VkQXMiLCJyb3V0ZVJlZ2V4Iiwicm91dGVNYXRjaCIsInNob3VsZEludGVycG9sYXRlIiwibWlzc2luZ1BhcmFtcyIsInJvdXRlSW5mbyIsImRlc3RpbmF0aW9uIiwicGFyc2VkSHJlZiIsImFwcENvbXAiLCJlcnJvciIsImNoYW5nZVN0YXRlIiwiX19OIiwiYnVpbGRDYW5jZWxsYXRpb25FcnJvciIsInBhZ2UiLCJjYWNoZWRSb3V0ZUluZm8iLCJyZXF1aXJlIiwiaXNWYWxpZEVsZW1lbnRUeXBlIiwiZGF0YUhyZWYiLCJzZXQiLCJiZWZvcmVQb3BTdGF0ZSIsIm9ubHlBSGFzaENoYW5nZSIsIm5ld0hhc2giLCJvbGRVcmxOb0hhc2giLCJvbGRIYXNoIiwic2Nyb2xsVG9IYXNoIiwiaWRFbCIsIm5hbWVFbCIsInVybElzTmV3IiwiX3Jlc29sdmVIcmVmIiwiYXBwbHlCYXNlUGF0aCIsImNsZWFuUGF0aG5hbWUiLCJQcm9taXNlIiwiY2FuY2VsIiwiY29tcG9uZW50UmVzdWx0IiwiX2dldERhdGEiLCJmbiIsImRhdGEiLCJfZ2V0U3RhdGljRGF0YSIsImZldGNoTmV4dERhdGEiLCJfZ2V0U2VydmVyRGF0YSIsIkFwcFRyZWUiLCJjdHgiLCJhYm9ydENvbXBvbmVudExvYWQiLCJub3RpZnkiLCJzZWdtZW50IiwiY2hhciIsImVuY29kZVVSSUNvbXBvbmVudCIsInNsYXNoZWRQcm90b2NvbHMiLCJwcm90b2NvbCIsInVybE9iaiIsImhvc3QiLCJhdXRoIiwiaG9zdG5hbWUiLCJTdHJpbmciLCJxdWVyeXN0cmluZyIsInNlYXJjaCIsIlRFU1RfUk9VVEUiLCJEVU1NWV9CQVNFIiwicmVzb2x2ZWRCYXNlIiwib3JpZ2luIiwibWF0Y2hlck9wdGlvbnMiLCJzZW5zaXRpdmUiLCJkZWxpbWl0ZXIiLCJjdXN0b21Sb3V0ZU1hdGNoZXJPcHRpb25zIiwic3RyaWN0IiwiY3VzdG9tUm91dGUiLCJtYXRjaGVyUmVnZXgiLCJwYXRoVG9SZWdleHAiLCJtYXRjaGVyIiwicGFyc2VkRGVzdGluYXRpb24iLCJkZXN0UXVlcnkiLCJkZXN0UGF0aCIsImRlc3RQYXRoUGFyYW1LZXlzIiwiZGVzdFBhdGhQYXJhbXMiLCJkZXN0aW5hdGlvbkNvbXBpbGVyIiwidmFsaWRhdGUiLCJzdHJPckFycmF5IiwicXVlcnlDb21waWxlciIsInBhcmFtS2V5cyIsImFwcGVuZFBhcmFtc1RvUXVlcnkiLCJzaG91bGRBZGRCYXNlUGF0aCIsIm5ld1VybCIsInNlYXJjaFBhcmFtcyIsImlzTmFOIiwiaXRlbSIsInN0cmluZ2lmeVVybFF1ZXJ5UGFyYW0iLCJzZWFyY2hQYXJhbXNMaXN0IiwiY3VzdG9tUm91dGVNYXRjaGVyIiwicmV3cml0ZSIsImRlc3RSZXMiLCJyZSIsImRlY29kZSIsImRlY29kZVVSSUNvbXBvbmVudCIsInNsdWdOYW1lIiwiZyIsImdyb3VwcyIsIm0iLCJzdHIiLCJzZWdtZW50cyIsIm5vcm1hbGl6ZWRSb3V0ZSIsImdyb3VwSW5kZXgiLCJwYXJhbWV0ZXJpemVkUm91dGUiLCJwYXJzZVBhcmFtZXRlciIsInBvcyIsImVzY2FwZVJlZ2V4Iiwicm91dGVLZXlDaGFyQ29kZSIsInJvdXRlS2V5Q2hhckxlbmd0aCIsImdldFNhZmVSb3V0ZUtleSIsInJvdXRlS2V5IiwiaSIsInJvdXRlS2V5cyIsIm5hbWVkUGFyYW1ldGVyaXplZFJvdXRlIiwiY2xlYW5lZEtleSIsImludmFsaWRLZXkiLCJwYXJzZUludCIsIm5hbWVkUmVnZXgiLCJ1c2VkIiwicG9ydCIsImdldExvY2F0aW9uT3JpZ2luIiwiQXBwIiwiZ2V0RGlzcGxheU5hbWUiLCJwYWdlUHJvcHMiLCJsb2FkR2V0SW5pdGlhbFByb3BzIiwiaXNSZXNTZW50IiwidXJsT2JqZWN0S2V5cyIsIlNQIiwiVGl0bGUiLCJoMSIsIlBhZ2VDb250YWluZXIiLCJkaXYiLCJUd29Db2x1bW5MYXlvdXQiLCJIb21lIiwiUHJvcFR5cGVzIiwic2hhcGUiLCJudW1iZXIiLCJpc1JlcXVpcmVkIiwic3RyaW5nIiwiamFwYW5lc2UiLCJjaGluZXNlIiwiZnJlbmNoIiwiYXJyYXlPZiIsIkhQIiwiQXR0YWNrIiwiRGVmZW5zZSIsIlNwZWVkIiwiU3RvcmUiLCJtYWtlQXV0b09ic2VydmFibGUiXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJO1FBQ0o7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7OztBQ3hGQSx3RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsTUFBTUEsS0FBSyxHQUFHQyxzREFBTSxDQUFDQyxLQUFNO0FBQzNCO0FBQ0E7QUFDQTtBQUNBLENBSkE7O0FBTUEsTUFBTUMsYUFBYSxHQUFHLE1BQU07QUFDMUIsU0FDRSxNQUFDLEtBQUQ7QUFDRSxRQUFJLEVBQUMsTUFEUDtBQUVFLFNBQUssRUFBRUMsa0RBQUssQ0FBQ0MsTUFGZjtBQUdFLFlBQVEsRUFBR0MsR0FBRCxJQUFTRixrREFBSyxDQUFDRyxTQUFOLENBQWdCRCxHQUFHLENBQUNFLE1BQUosQ0FBV0MsS0FBM0IsQ0FIckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGO0FBT0QsQ0FSRDs7QUFVZUMsMEhBQVEsQ0FBQ1AsYUFBRCxDQUF2QixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RCQTtBQUNBO0FBRUE7O0FBRUEsTUFBTVEsV0FBVyxHQUFHLE1BQU07QUFDeEIsU0FBT1Asa0RBQUssQ0FBQ1EsZUFBTixHQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUtSLGtEQUFLLENBQUNRLGVBQU4sQ0FBc0JDLElBQXRCLENBQTJCQyxPQUFoQyxDQURGLEVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR0MsTUFBTSxDQUFDQyxJQUFQLENBQVlaLGtEQUFLLENBQUNRLGVBQU4sQ0FBc0JLLElBQWxDLEVBQXdDQyxHQUF4QyxDQUE2Q0MsR0FBRCxJQUMzQztBQUFJLE9BQUcsRUFBRUEsR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFLQSxHQUFMLENBREYsRUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUtmLGtEQUFLLENBQUNRLGVBQU4sQ0FBc0JLLElBQXRCLENBQTJCRSxHQUEzQixDQUFMLENBRkYsQ0FERCxDQURILENBREYsQ0FGRixDQURLLEdBY0gsSUFkSjtBQWVELENBaEJEOztBQWtCZVQsMEhBQVEsQ0FBQ0MsV0FBRCxDQUF2QixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7QUFFQSxNQUFNUyxVQUFVLEdBQUcsQ0FBQztBQUFFQyxTQUFGO0FBQVdDO0FBQVgsQ0FBRCxLQUNqQixtRUFDRTtBQUFJLEtBQUcsRUFBRUQsT0FBTyxDQUFDRSxFQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEdBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHQUNFLE1BQUMsZ0RBQUQ7QUFBTSxNQUFJLEVBQUcsWUFBV0YsT0FBTyxDQUFDRSxFQUFHLEVBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEdBQUlGLE9BQU8sQ0FBQ1IsSUFBUixDQUFhQyxPQUFqQixDQURGLENBREYsQ0FERixFQU1FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBS08sT0FBTyxDQUFDRyxJQUFSLENBQWFDLElBQWIsQ0FBa0IsSUFBbEIsQ0FBTCxDQU5GLEVBT0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHQUNFLE1BQUMsd0RBQUQ7QUFDRSxTQUFPLEVBQUMsV0FEVjtBQUVFLE9BQUssRUFBQyxTQUZSO0FBR0UsU0FBTyxFQUFFLE1BQU1ILE9BQU8sQ0FBQ0QsT0FBRCxDQUh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLENBUEYsQ0FERixDQURGOztBQXNCQUQsVUFBVSxDQUFDTSxTQUFYLEdBQXVCO0FBQ3JCTCxTQUFPLEVBQUVNLHdEQUFXQTtBQURDLENBQXZCO0FBSWVQLHlFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQSxTQUFTUSxZQUFULEdBQXdCO0FBQ3RCLFNBQ0U7QUFBTyxTQUFLLEVBQUMsTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNHeEIsa0RBQUssQ0FBQ2lCLE9BQU4sQ0FDRWhCLE1BREYsQ0FDUyxDQUFDO0FBQUVRLFFBQUksRUFBRTtBQUFFQztBQUFGO0FBQVIsR0FBRCxLQUNOQSxPQUFPLENBQ0plLGlCQURILEdBRUdDLFFBRkgsQ0FFWTFCLGtEQUFLLENBQUNDLE1BQU4sQ0FBYXdCLGlCQUFiLEVBRlosQ0FGSCxFQU1FRSxLQU5GLENBTVEsQ0FOUixFQU1XLEVBTlgsRUFPRWIsR0FQRixDQU9PRyxPQUFELElBQ0gsTUFBQyxtREFBRDtBQUNFLE9BQUcsRUFBRUEsT0FBTyxDQUFDRSxFQURmO0FBRUUsV0FBTyxFQUFFRixPQUZYO0FBR0UsV0FBTyxFQUFHQSxPQUFELElBQWFqQixrREFBSyxDQUFDNEIsa0JBQU4sQ0FBeUJYLE9BQXpCLENBSHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFSSCxDQURILENBREYsQ0FERjtBQW9CRDs7QUFFY1gsMEhBQVEsQ0FBQ2tCLFlBQUQsQ0FBdkIsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdCQTs7QUFFQTs7QUFRQTs7QUFzQkE7QUFDQSxNQUFNSyxTQUFTLEdBQUcsSUFBbEIsR0FBa0IsRUFBbEI7QUFDQSxNQUFNQyxvQkFBb0IsR0FDeEIsUUFBZ0NDLFNBQWhDLEdBREY7QUFFQSxNQUFNQyxVQUEyQyxHQUFqRDs7QUFFQSx1QkFBeUQ7QUFDdkQ7QUFDQSxzQkFBb0I7QUFDbEI7QUFHRixHQU51RCxDQU12RDs7O0FBQ0EsTUFBSSxDQUFKLHNCQUEyQjtBQUN6QjtBQUdGOztBQUFBLFNBQVFDLGNBQWMsR0FBRyx5QkFDdEJDLE9BQUQsSUFBYTtBQUNYQSxXQUFPLENBQVBBLFFBQWlCQyxLQUFELElBQVc7QUFDekIsVUFBSSxDQUFDTixTQUFTLENBQVRBLElBQWNNLEtBQUssQ0FBeEIsTUFBS04sQ0FBTCxFQUFrQztBQUNoQztBQUdGOztBQUFBLFlBQU1PLEVBQUUsR0FBR1AsU0FBUyxDQUFUQSxJQUFjTSxLQUFLLENBQTlCLE1BQVdOLENBQVg7O0FBQ0EsVUFBSU0sS0FBSyxDQUFMQSxrQkFBd0JBLEtBQUssQ0FBTEEsb0JBQTVCLEdBQXlEO0FBQ3ZERixzQkFBYyxDQUFkQSxVQUF5QkUsS0FBSyxDQUE5QkY7QUFDQUosaUJBQVMsQ0FBVEEsT0FBaUJNLEtBQUssQ0FBdEJOO0FBQ0FPLFVBQUU7QUFFTDtBQVhERjtBQUZxQixLQWV2QjtBQUFFRyxjQUFVLEVBZmQ7QUFlRSxHQWZ1QixDQUF6QjtBQW1CRjs7QUFBQSxNQUFNQyxxQkFBcUIsR0FBRyxZQUFpQztBQUM3RCxRQUFNaEMsUUFBUSxHQUFHaUMsV0FBakI7O0FBQ0EsTUFBSSxDQUFKLFVBQWU7QUFDYixXQUFPLE1BQU0sQ0FBYjtBQUdGakM7O0FBQUFBLFVBQVEsQ0FBUkE7QUFDQXVCLFdBQVMsQ0FBVEE7QUFDQSxTQUFPLE1BQU07QUFDWCxRQUFJO0FBQ0Z2QixjQUFRLENBQVJBO0FBQ0EsS0FGRixDQUVFLFlBQVk7QUFDWmtDLGFBQU8sQ0FBUEE7QUFFRlg7O0FBQUFBLGFBQVMsQ0FBVEE7QUFORjtBQVJGOztBQWtCQSw2Q0FLUTtBQUNOLFlBQW1DO0FBQ25DLE1BQUksQ0FBQyx3QkFBTCxJQUFLLENBQUwsRUFBdUIsT0FGakIsQ0FHTjtBQUNBO0FBQ0E7QUFDQTs7QUFDQVksUUFBTSxDQUFOQSxrQ0FBMENDLEdBQUQsSUFBUztBQUNoRCxjQUEyQztBQUN6QztBQUNBO0FBRUg7QUFMREQsS0FQTSxDQWFOOztBQUNBVCxZQUFVLENBQUNXLElBQUksR0FBSkEsTUFBWFgsRUFBVSxDQUFWQTtBQUdGOztBQUFBLGdDQUFrRDtBQUNoRCxRQUFNO0FBQUE7QUFBQSxNQUFhWSxLQUFLLENBQXhCO0FBQ0EsU0FDR3hDLE1BQU0sSUFBSUEsTUFBTSxLQUFqQixPQUFDQSxJQUNEd0MsS0FBSyxDQURMLE9BQUN4QyxJQUVEd0MsS0FBSyxDQUZMLE9BQUN4QyxJQUdEd0MsS0FBSyxDQUhMLFFBQUN4QyxJQUlEd0MsS0FBSyxDQUpMLE1BQUN4QyxJQUllO0FBQ2Z3QyxPQUFLLENBQUxBLGVBQXFCQSxLQUFLLENBQUxBLHNCQU54QjtBQVVGOztBQUFBLG9FQVFRO0FBQ04sUUFBTTtBQUFBO0FBQUEsTUFBZUMsQ0FBQyxDQUF0Qjs7QUFFQSxNQUFJQyxRQUFRLEtBQVJBLFFBQXFCQyxlQUFlLENBQWZBLENBQWUsQ0FBZkEsSUFBc0IsQ0FBQyx3QkFBaEQsSUFBZ0QsQ0FBNUNELENBQUosRUFBbUU7QUFDakU7QUFDQTtBQUdGRDs7QUFBQUEsR0FBQyxDQUFEQSxpQkFSTSxDQVVOOztBQUNBLE1BQUlHLE1BQU0sSUFBVixNQUFvQjtBQUNsQkEsVUFBTSxHQUFHQyxFQUFFLENBQUZBLGVBQVREO0FBR0YsR0FmTSxDQWVOOzs7QUFDQVAsUUFBTSxDQUFDUyxPQUFPLGVBQWRULE1BQU0sQ0FBTkEsV0FBK0M7QUFBL0NBO0FBQStDLEdBQS9DQSxPQUNHVSxPQUFELElBQXNCO0FBQ3BCLFFBQUksQ0FBSixTQUFjOztBQUNkLGdCQUFZO0FBQ1ZwQixZQUFNLENBQU5BO0FBQ0FxQixjQUFRLENBQVJBO0FBRUg7QUFQSFg7QUFXRjs7QUFBQSxxQkFBeUQ7QUFDdkQsWUFBMkM7QUFDekMsbUNBSUc7QUFDRCxhQUFPLFVBQ0osZ0NBQStCWSxJQUFJLENBQUN0QyxHQUFJLGdCQUFlc0MsSUFBSSxDQUFDQyxRQUFTLDZCQUE0QkQsSUFBSSxDQUFDRSxNQUF2RyxhQUFDLElBQ0Usb0JBRkwsRUFDRyxDQURJLENBQVA7QUFRRixLQWR5QyxDQWN6Qzs7O0FBQ0EsVUFBTUMsa0JBQW1ELEdBQUc7QUFDMURiLFVBQUksRUFETjtBQUE0RCxLQUE1RDtBQUdBLFVBQU1jLGFBQWtDLEdBQUc5QyxNQUFNLENBQU5BLEtBQTNDLGtCQUEyQ0EsQ0FBM0M7QUFHQSxpQkFBYSxDQUFiLFFBQXVCSSxHQUFELElBQTRCO0FBQ2hELFVBQUlBLEdBQUcsS0FBUCxRQUFvQjtBQUNsQixZQUNFMkMsS0FBSyxDQUFMQSxHQUFLLENBQUxBLFlBQ0MsT0FBT0EsS0FBSyxDQUFaLEdBQVksQ0FBWixpQkFBa0MsT0FBT0EsS0FBSyxDQUFaLEdBQVksQ0FBWixLQUZyQyxVQUdFO0FBQ0EsZ0JBQU1DLGVBQWUsQ0FBQztBQUFBO0FBRXBCTCxvQkFBUSxFQUZZO0FBR3BCQyxrQkFBTSxFQUFFRyxLQUFLLENBQUxBLEdBQUssQ0FBTEEscUJBQStCLE9BQU9BLEtBQUssQ0FIckQsR0FHcUQ7QUFIL0IsV0FBRCxDQUFyQjtBQU1IO0FBWEQsYUFXTztBQUNMO0FBQ0E7QUFDQSxjQUFNRSxDQUFRLEdBQWQ7QUFFSDtBQWpCRCxPQXJCeUMsQ0F3Q3pDOztBQUNBLFVBQU1DLGtCQUFtRCxHQUFHO0FBQzFEWixRQUFFLEVBRHdEO0FBRTFEQyxhQUFPLEVBRm1EO0FBRzFERixZQUFNLEVBSG9EO0FBSTFEYyxhQUFPLEVBSm1EO0FBSzFEQyxjQUFRLEVBTGtEO0FBTTFEQyxjQUFRLEVBTlY7QUFBNEQsS0FBNUQ7QUFRQSxVQUFNQyxhQUFrQyxHQUFHdEQsTUFBTSxDQUFOQSxLQUEzQyxrQkFBMkNBLENBQTNDO0FBR0EsaUJBQWEsQ0FBYixRQUF1QkksR0FBRCxJQUE0QjtBQUNoRCxVQUFJQSxHQUFHLEtBQVAsTUFBa0I7QUFDaEIsWUFDRTJDLEtBQUssQ0FBTEEsR0FBSyxDQUFMQSxJQUNBLE9BQU9BLEtBQUssQ0FBWixHQUFZLENBQVosS0FEQUEsWUFFQSxPQUFPQSxLQUFLLENBQVosR0FBWSxDQUFaLEtBSEYsVUFJRTtBQUNBLGdCQUFNQyxlQUFlLENBQUM7QUFBQTtBQUVwQkwsb0JBQVEsRUFGWTtBQUdwQkMsa0JBQU0sRUFBRSxPQUFPRyxLQUFLLENBSHRCLEdBR3NCO0FBSEEsV0FBRCxDQUFyQjtBQU1IO0FBWkQsYUFZTyxJQUNMM0MsR0FBRyxLQUFIQSxhQUNBQSxHQUFHLEtBREhBLFlBRUFBLEdBQUcsS0FGSEEsYUFHQUEsR0FBRyxLQUhIQSxjQUlBQSxHQUFHLEtBTEUsWUFNTDtBQUNBLFlBQUkyQyxLQUFLLENBQUxBLEdBQUssQ0FBTEEsWUFBc0IsT0FBT0EsS0FBSyxDQUFaLEdBQVksQ0FBWixLQUExQixXQUEyRDtBQUN6RCxnQkFBTUMsZUFBZSxDQUFDO0FBQUE7QUFFcEJMLG9CQUFRLEVBRlk7QUFHcEJDLGtCQUFNLEVBQUUsT0FBT0csS0FBSyxDQUh0QixHQUdzQjtBQUhBLFdBQUQsQ0FBckI7QUFNSDtBQWRNLGFBY0E7QUFDTDtBQUNBO0FBQ0EsY0FBTUUsQ0FBUSxHQUFkO0FBRUg7QUFoQ0QsT0FwRHlDLENBc0Z6QztBQUNBOztBQUNBLFVBQU1NLFNBQVMsR0FBR0Msc0JBQWxCLEtBQWtCQSxDQUFsQjs7QUFDQSxRQUFJVCxLQUFLLENBQUxBLFlBQWtCLENBQUNRLFNBQVMsQ0FBaEMsU0FBMEM7QUFDeENBLGVBQVMsQ0FBVEE7QUFDQTFCLGFBQU8sQ0FBUEE7QUFJSDtBQUNEOztBQUFBLFFBQU00QixDQUFDLEdBQUdWLEtBQUssQ0FBTEEsYUFBVjs7QUFFQSxRQUFNLDBCQUEwQlMsZUFBaEMsUUFBZ0NBLEVBQWhDOztBQUVBLFFBQU0xQixNQUFNLEdBQUcsYUFBZixTQUFlLEdBQWY7QUFDQSxRQUFNNEIsUUFBUSxHQUFJNUIsTUFBTSxJQUFJQSxNQUFNLENBQWpCLFFBQUNBLElBQWxCOztBQUVBLFFBQU07QUFBQTtBQUFBO0FBQUEsTUFBZTBCLHVCQUFjLE1BQU07QUFDdkMsVUFBTSw2QkFBNkIsbUNBQXNCVCxLQUFLLENBQTNCLE1BQW5DLElBQW1DLENBQW5DO0FBQ0EsV0FBTztBQUNMZixVQUFJLEVBREM7QUFFTE0sUUFBRSxFQUFFUyxLQUFLLENBQUxBLEtBQ0EsbUNBQXNCQSxLQUFLLENBRDNCQSxFQUNBLENBREFBLEdBRUFZLFVBQVUsSUFKaEI7QUFBTyxLQUFQO0FBRm1CSCxLQVFsQixXQUFXVCxLQUFLLENBQWhCLE1BQXVCQSxLQUFLLENBUi9CLEVBUUcsQ0FSa0JTLENBQXJCOztBQVVBLDJCQUFnQixNQUFNO0FBQ3BCLFFBQ0VDLENBQUMsSUFBREEsb0NBR0FHLFFBQVEsQ0FIUkgsV0FJQSx3QkFMRixJQUtFLENBTEYsRUFNRTtBQUNBO0FBQ0EsWUFBTUksWUFBWSxHQUFHeEMsVUFBVSxDQUFDVyxJQUFJLEdBQUpBLE1BQWhDLEVBQStCLENBQS9COztBQUNBLFVBQUksQ0FBSixjQUFtQjtBQUNqQixlQUFPTCxxQkFBcUIsV0FBVyxNQUFNO0FBQzNDMEIsa0JBQVEsZUFBUkEsRUFBUSxDQUFSQTtBQURGLFNBQTRCLENBQTVCO0FBSUg7QUFDRjtBQWhCRCxLQWdCRyx3QkFoQkgsTUFnQkcsQ0FoQkg7O0FBa0JBLE1BQUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQUosTUFwSXVELENBcUl2RDs7QUFDQSxNQUFJLG9CQUFKLFVBQWtDO0FBQ2hDUyxZQUFRLGdCQUFHLHdDQUFYQSxRQUFXLENBQVhBO0FBR0YsR0ExSXVELENBMEl2RDs7O0FBQ0EsUUFBTUMsS0FBVSxHQUFHQyxxQkFBbkIsUUFBbUJBLENBQW5COztBQUNBLFFBQU1DLFVBS0wsR0FBRztBQUNGQyxPQUFHLEVBQUdDLEVBQUQsSUFBYTtBQUNoQixjQUFRQyxXQUFXLENBQVhBLEVBQVcsQ0FBWEE7O0FBRVIsVUFBSUwsS0FBSyxJQUFJLGlCQUFUQSxZQUFzQ0EsS0FBSyxDQUEvQyxLQUFxRDtBQUNuRCxZQUFJLE9BQU9BLEtBQUssQ0FBWixRQUFKLFlBQXFDQSxLQUFLLENBQUxBLElBQXJDLEVBQXFDQSxFQUFyQyxLQUNLLElBQUksT0FBT0EsS0FBSyxDQUFaLFFBQUosVUFBbUM7QUFDdENBLGVBQUssQ0FBTEE7QUFFSDtBQUNGO0FBVkM7QUFXRnhELFdBQU8sRUFBRzJCLENBQUQsSUFBeUI7QUFDaEMsVUFBSTZCLEtBQUssQ0FBTEEsU0FBZSxPQUFPQSxLQUFLLENBQUxBLE1BQVAsWUFBbkIsWUFBOEQ7QUFDNURBLGFBQUssQ0FBTEE7QUFFRjs7QUFBQSxVQUFJLENBQUM3QixDQUFDLENBQU4sa0JBQXlCO0FBQ3ZCbUMsbUJBQVcsd0NBQVhBLE1BQVcsQ0FBWEE7QUFFSDtBQXZCSDtBQUtJLEdBTEo7O0FBMEJBLFNBQU87QUFDTEosY0FBVSxDQUFWQSxlQUEyQi9CLENBQUQsSUFBeUI7QUFDakQsVUFBSSxDQUFDLHdCQUFMLElBQUssQ0FBTCxFQUF1Qjs7QUFDdkIsVUFBSTZCLEtBQUssQ0FBTEEsU0FBZSxPQUFPQSxLQUFLLENBQUxBLE1BQVAsaUJBQW5CLFlBQW1FO0FBQ2pFQSxhQUFLLENBQUxBO0FBRUZWOztBQUFBQSxjQUFRLG1CQUFtQjtBQUFFaUIsZ0JBQVEsRUFBckNqQjtBQUEyQixPQUFuQixDQUFSQTtBQUxGWTtBQVNGLEdBaEx1RCxDQWdMdkQ7QUFDQTs7O0FBQ0EsTUFBSWxCLEtBQUssQ0FBTEEsWUFBbUJnQixLQUFLLENBQUxBLGdCQUFzQixFQUFFLFVBQVVBLEtBQUssQ0FBOUQsS0FBNkMsQ0FBN0MsRUFBd0U7QUFDdEVFLGNBQVUsQ0FBVkEsT0FBa0IseUJBQ2hCLDJCQUFjbkMsTUFBTSxJQUFJQSxNQUFNLENBQTlCLFFBQXVDQSxNQUFNLElBQUlBLE1BQU0sQ0FEekRtQyxhQUNFLENBRGdCLENBQWxCQTtBQUtGOztBQUFBLHNCQUFPVCxtQ0FBUCxVQUFPQSxDQUFQOzs7ZUFHYWUsSTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdFZmOzs7O0FBR08sdUNBQXVEO0FBQzVELFNBQU9DLElBQUksQ0FBSkEsaUJBQXNCQSxJQUFJLEtBQTFCQSxNQUFxQ0EsSUFBSSxDQUFKQSxTQUFjLENBQW5EQSxDQUFxQ0EsQ0FBckNBLEdBQVA7QUFHRjtBQUFBOzs7Ozs7QUFJTyxNQUFNQywwQkFBMEIsR0FBR0MsU0FDckNGLFNBRHFDRSxHQUFuQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVlA7O0FBQ0E7Ozs7O0FBQ0E7O0FBc0hBOzs7QUF6SEE7O0FBbUJBLE1BQU1DLGVBQW9DLEdBQUc7QUFDM0M3QyxRQUFNLEVBRHFDO0FBQzdCO0FBQ2Q4QyxnQkFBYyxFQUY2Qjs7QUFHM0NDLE9BQUssS0FBaUI7QUFDcEIsUUFBSSxLQUFKLFFBQWlCLE9BQU9wRCxFQUFQOztBQUNqQixlQUFtQyxFQUdwQztBQVJIOztBQUE2QyxDQUE3QyxDLENBV0E7O0FBQ0EsTUFBTXFELGlCQUFpQixHQUFHLHNHQUExQixlQUEwQixDQUExQjtBQVlBLE1BQU1DLFlBQVksR0FBRywwR0FBckIsb0JBQXFCLENBQXJCO0FBUUEsTUFBTUMsZ0JBQWdCLEdBQUcsa0RBQXpCLGdCQUF5QixDQUF6QixDLENBU0E7O0FBQ0FoRixNQUFNLENBQU5BLDBDQUFpRDtBQUMvQ2lGLEtBQUcsR0FBRztBQUNKLFdBQU9DLGlCQUFQO0FBRkpsRjs7QUFBaUQsQ0FBakRBO0FBTUE4RSxpQkFBaUIsQ0FBakJBLFFBQTJCSyxLQUFELElBQVc7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQW5GLFFBQU0sQ0FBTkEsdUNBQThDO0FBQzVDaUYsT0FBRyxHQUFHO0FBQ0osWUFBTW5ELE1BQU0sR0FBR3NELFNBQWY7QUFDQSxhQUFPdEQsTUFBTSxDQUFiLEtBQWEsQ0FBYjtBQUhKOUI7O0FBQThDLEdBQTlDQTtBQUxGOEU7QUFhQSxnQkFBZ0IsQ0FBaEIsUUFBMEJLLEtBQUQsSUFBVztBQUNsQztBQUNBOztBQUFFUixpQkFBRCxPQUFDQSxHQUFpQyxDQUFDLEdBQUQsU0FBb0I7QUFDckQsVUFBTTdDLE1BQU0sR0FBR3NELFNBQWY7QUFDQSxXQUFPdEQsTUFBTSxDQUFOQSxLQUFNLENBQU5BLENBQWMsR0FBckIsSUFBT0EsQ0FBUDtBQUZELEdBQUM2QztBQUZKO0FBUUFJLFlBQVksQ0FBWkEsUUFBc0I5QyxLQUFELElBQVc7QUFDOUIwQyxpQkFBZSxDQUFmQSxNQUFzQixNQUFNO0FBQzFCTyxzQ0FBd0IsQ0FBQyxHQUFELFNBQWE7QUFDbkMsWUFBTUcsVUFBVSxHQUFJLEtBQUlwRCxLQUFLLENBQUxBLHVCQUE4QixHQUFFQSxLQUFLLENBQUxBLFlBQXhEO0FBR0EsWUFBTXFELGdCQUFnQixHQUF0Qjs7QUFDQSxVQUFJQSxnQkFBZ0IsQ0FBcEIsVUFBb0IsQ0FBcEIsRUFBa0M7QUFDaEMsWUFBSTtBQUNGQSwwQkFBZ0IsQ0FBaEJBLFVBQWdCLENBQWhCQSxDQUE2QixHQUE3QkE7QUFDQSxTQUZGLENBRUUsWUFBWTtBQUNaekQsaUJBQU8sQ0FBUEEsTUFBZSx3Q0FBdUN3RCxVQUF0RHhEO0FBQ0FBLGlCQUFPLENBQVBBLE1BQWUsR0FBRUUsR0FBRyxDQUFDd0QsT0FBUSxLQUFJeEQsR0FBRyxDQUFDeUQsS0FBckMzRDtBQUVIO0FBQ0Y7QUFiRHFEO0FBREZQO0FBREZJOztBQW1CQSxxQkFBNkI7QUFDM0IsTUFBSSxDQUFDSixlQUFlLENBQXBCLFFBQTZCO0FBQzNCLFVBQU1ZLE9BQU8sR0FDWCxnQ0FERjtBQUdBLFVBQU0sVUFBTixPQUFNLENBQU47QUFFRjs7QUFBQSxTQUFPWixlQUFlLENBQXRCO0FBR0YsQyxDQUFBOzs7ZUFDZUEsZSxFQUVmOzs7O0FBR08scUJBQWlDO0FBQ3RDLFNBQU9uQiwwQkFBaUJpQyxlQUF4QixhQUFPakMsQ0FBUDtBQUdGLEMsQ0FBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7OztBQUNPLE1BQU1rQyxZQUFZLEdBQUcsQ0FBQyxHQUFELFNBQWlDO0FBQzNEZixpQkFBZSxDQUFmQSxTQUF5QixJQUFJTyxTQUFKLFFBQVcsR0FBcENQLElBQXlCLENBQXpCQTtBQUNBQSxpQkFBZSxDQUFmQSx1QkFBd0NsRCxFQUFELElBQVFBLEVBQS9Da0Q7QUFDQUEsaUJBQWUsQ0FBZkE7QUFFQSxTQUFPQSxlQUFlLENBQXRCO0FBTEssRSxDQVFQOzs7OztBQUNPLDBDQUE4RDtBQUNuRSxRQUFNZ0IsT0FBTyxHQUFiO0FBQ0EsUUFBTUMsUUFBUSxHQUFkOztBQUVBLE9BQUssTUFBTCwrQkFBMEM7QUFDeEMsUUFBSSxPQUFPRCxPQUFPLENBQWQsUUFBYyxDQUFkLEtBQUosVUFBMkM7QUFDekNDLGNBQVEsQ0FBUkEsUUFBUSxDQUFSQSxHQUFxQjVGLE1BQU0sQ0FBTkEsT0FDbkI2RixLQUFLLENBQUxBLFFBQWNGLE9BQU8sQ0FBckJFLFFBQXFCLENBQXJCQSxTQURtQjdGLElBRW5CMkYsT0FBTyxDQUZUQyxRQUVTLENBRlk1RixDQUFyQjRGLENBRHlDLENBSXZDOztBQUNGO0FBR0ZBOztBQUFBQSxZQUFRLENBQVJBLFFBQVEsQ0FBUkEsR0FBcUJELE9BQU8sQ0FBNUJDLFFBQTRCLENBQTVCQTtBQUdGLEdBaEJtRSxDQWdCbkU7OztBQUNBQSxVQUFRLENBQVJBLFNBQWtCVixpQkFBbEJVO0FBRUFaLGtCQUFnQixDQUFoQkEsUUFBMEJHLEtBQUQsSUFBVztBQUNsQ1MsWUFBUSxDQUFSQSxLQUFRLENBQVJBLEdBQWtCLENBQUMsR0FBRCxTQUFvQjtBQUNwQyxhQUFPRCxPQUFPLENBQVBBLEtBQU8sQ0FBUEEsQ0FBZSxHQUF0QixJQUFPQSxDQUFQO0FBREZDO0FBREZaO0FBTUE7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDektEOztBQUVBOztBQVdlLHVDQUsrQjtBQUM1QyxvQ0FBdUM7QUFDckMsd0JBQU87QUFBbUIsWUFBTSxFQUFFLFlBQTNCLFNBQTJCO0FBQTNCLE9BQVAsS0FBTyxFQUFQO0FBR0Y7O0FBQUEsbUJBQWlCLENBQWpCLGtCQUFvQ2MsaUJBQWlCLENBQUNDLGVBQXRELENBQ0E7QUFEQTtBQUVFQyxtQkFBRCxvQkFBQ0EsR0FBaURGLGlCQUFELENBQWpELG1CQUFDRTs7QUFDRixZQUEyQztBQUN6QyxVQUFNbEcsSUFBSSxHQUNSZ0csaUJBQWlCLENBQWpCQSxlQUFpQ0EsaUJBQWlCLENBQWxEQSxRQURGO0FBRUFFLHFCQUFpQixDQUFqQkEsY0FBaUMsY0FBYWxHLElBQTlDa0c7QUFHRjs7QUFBQTtBQUNELEM7Ozs7Ozs7Ozs7OztBQ2pDWTtBQUNiLDhDQUE4QyxjQUFjO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5Qiw4Q0FBOEM7QUFDdkU7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLG9EQUFvRDtBQUM3RTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCLHlCQUF5QiwwQ0FBMEM7QUFDbkU7QUFDQTtBQUNBLHVCQUF1QjtBQUN2Qix5QkFBeUIsMkNBQTJDO0FBQ3BFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsc0NBQXNDO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLDRDQUE0QztBQUNyRTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsMENBQTBDO0FBQy9EO0FBQ0EsaUJBQWlCLG1DQUFtQztBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsY0FBYztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsY0FBYztBQUMzQztBQUNBLG9FQUFvRSxVQUFVLEVBQUU7QUFDaEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsdUJBQXVCLG1CQUFtQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLGtCQUFrQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLGNBQWM7QUFDM0Msb0VBQW9FLFVBQVUsRUFBRTtBQUNoRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsY0FBYztBQUNyQztBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLG1CQUFtQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJDQUEyQyxpREFBaUQsRUFBRTtBQUM5RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsY0FBYztBQUMzQyx3T0FBd08sVUFBVSxFQUFFO0FBQ3BQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLHNCQUFzQjtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjLDZEQUE2RDtBQUMzRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQzs7Ozs7Ozs7Ozs7Ozs7OztBQ3JaQTs7Ozs7OztBQVlBO0FBQ0E7QUFDQTs7QUFVZSxnQkFBNkI7QUFDMUMsUUFBTUMsR0FBK0IsR0FBR2pHLE1BQU0sQ0FBTkEsT0FBeEMsSUFBd0NBLENBQXhDO0FBRUEsU0FBTztBQUNMa0csTUFBRSxnQkFBaUM7QUFDakM7QUFBQyxPQUFDRCxHQUFHLENBQUhBLElBQUcsQ0FBSEEsS0FBY0EsR0FBRyxDQUFIQSxJQUFHLENBQUhBLEdBQWYsRUFBQ0EsQ0FBRDtBQUZFOztBQUtMRSxPQUFHLGdCQUFpQztBQUNsQyxVQUFJRixHQUFHLENBQVAsSUFBTyxDQUFQLEVBQWU7QUFDYkEsV0FBRyxDQUFIQSxJQUFHLENBQUhBLFFBQWlCQSxHQUFHLENBQUhBLElBQUcsQ0FBSEEsc0JBQWpCQTtBQUVIO0FBVEk7O0FBV0xHLFFBQUksT0FBZSxHQUFmLE1BQStCO0FBQ2pDO0FBQ0E7QUFBQyxPQUFDSCxHQUFHLENBQUhBLElBQUcsQ0FBSEEsSUFBRCxnQkFBK0JJLE9BQUQsSUFBc0I7QUFDbkRBLGVBQU8sQ0FBQyxHQUFSQSxJQUFPLENBQVBBO0FBREQ7QUFiTDs7QUFBTyxHQUFQO0FBa0JELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeENEOztBQUtBOztBQUNBOztBQUNBOztBQVNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOzs7Ozs7QUEzQkE7QUFBQTtBQUNBOzs7QUF3Q0EsTUFBTUMsUUFBUSxHQUFJNUIsMkJBQWxCOztBQUVBLGtDQUFrQztBQUNoQyxTQUFPMUUsTUFBTSxDQUFOQSxPQUFjLFVBQWRBLGlCQUFjLENBQWRBLEVBQTRDO0FBQ2pEdUcsYUFBUyxFQURYO0FBQW1ELEdBQTVDdkcsQ0FBUDtBQUtGOztBQUFBLHFDQUFzRDtBQUNwRCxTQUFPd0csTUFBTSxJQUFJaEMsSUFBSSxDQUFKQSxXQUFWZ0MsR0FBVWhDLENBQVZnQyxHQUNIaEMsSUFBSSxLQUFKQSxNQUNFLHdEQURGQSxNQUNFLENBREZBLEdBRUcsR0FBRWdDLE1BQU8sR0FBRWhDLElBSFhnQyxLQUFQO0FBT0s7O0FBQUEsZ0RBSUw7QUFDQSxNQUFJOUIsS0FBSixFQUFxQyxFQUtyQzs7QUFBQTtBQUdLOztBQUFBLGlDQUFrRDtBQUN2RCxNQUFJQSxLQUFKLEVBQXFDLEVBS3JDOztBQUFBO0FBR0s7O0FBQUEsMkJBQTRDO0FBQ2pELFNBQU9GLElBQUksS0FBSkEsWUFBcUJBLElBQUksQ0FBSkEsV0FBZ0I4QixRQUFRLEdBQXBELEdBQTRCOUIsQ0FBNUI7QUFHSzs7QUFBQSwyQkFBMkM7QUFDaEQ7QUFDQSxTQUFPaUMsYUFBYSxPQUFwQixRQUFvQixDQUFwQjtBQUdLOztBQUFBLDJCQUEyQztBQUNoRCxTQUFPakMsSUFBSSxDQUFKQSxNQUFXOEIsUUFBUSxDQUFuQjlCLFdBQVA7QUFHRjtBQUFBOzs7OztBQUdPLHlCQUEwQztBQUMvQyxNQUFJa0MsR0FBRyxDQUFIQSxXQUFKLEdBQUlBLENBQUosRUFBeUI7O0FBQ3pCLE1BQUk7QUFDRjtBQUNBLFVBQU1DLGNBQWMsR0FBRyxXQUF2QixpQkFBdUIsR0FBdkI7QUFDQSxVQUFNQyxRQUFRLEdBQUcsYUFBakIsY0FBaUIsQ0FBakI7QUFDQSxXQUFPQSxRQUFRLENBQVJBLDZCQUFzQ0MsV0FBVyxDQUFDRCxRQUFRLENBQWpFLFFBQXdELENBQXhEO0FBQ0EsR0FMRixDQUtFLFVBQVU7QUFDVjtBQUVIO0FBSU07O0FBQUEsaURBSUw7QUFDQSxNQUFJRSxpQkFBaUIsR0FBckI7QUFFQSxRQUFNQyxZQUFZLEdBQUcsK0JBQXJCLEtBQXFCLENBQXJCO0FBQ0EsUUFBTUMsYUFBYSxHQUFHRCxZQUFZLENBQWxDO0FBQ0EsUUFBTUUsY0FBYyxHQUNsQjtBQUNBLEdBQUNDLFVBQVUsS0FBVkEsUUFBdUIsaURBQXZCQSxVQUF1QixDQUF2QkEsR0FBRCxPQUNBO0FBQ0E7QUFKRjtBQU9BSixtQkFBaUIsR0FBakJBO0FBQ0EsUUFBTUssTUFBTSxHQUFHbkgsTUFBTSxDQUFOQSxLQUFmLGFBQWVBLENBQWY7O0FBRUEsTUFDRSxDQUFDbUgsTUFBTSxDQUFOQSxNQUFjQyxLQUFELElBQVc7QUFDdkIsUUFBSTFILEtBQUssR0FBR3VILGNBQWMsQ0FBZEEsS0FBYyxDQUFkQSxJQUFaO0FBQ0EsVUFBTTtBQUFBO0FBQUE7QUFBQSxRQUF1QkQsYUFBYSxDQUExQyxLQUEwQyxDQUExQyxDQUZ1QixDQUl2QjtBQUNBOztBQUNBLFFBQUlLLFFBQVEsR0FBSSxJQUFHQyxNQUFNLFdBQVcsRUFBRyxHQUFFRixLQUF6Qzs7QUFDQSxrQkFBYztBQUNaQyxjQUFRLEdBQUksR0FBRSxlQUFlLEVBQUcsSUFBR0EsUUFBbkNBO0FBRUY7O0FBQUEsUUFBSUMsTUFBTSxJQUFJLENBQUN6QixLQUFLLENBQUxBLFFBQWYsS0FBZUEsQ0FBZixFQUFxQ25HLEtBQUssR0FBRyxDQUFSQSxLQUFRLENBQVJBO0FBRXJDLFdBQ0UsQ0FBQzZILFFBQVEsSUFBSUgsS0FBSyxJQUFsQixxQkFDQTtBQUNDTixxQkFBaUIsR0FDaEJBLGlCQUFpQixDQUFqQkEsa0JBRUVRLE1BQU0sR0FDRDVILEtBQUQsSUFBQ0EsQ0FBdUI4SCxzQkFBeEIsT0FBQzlILEVBQUQsSUFBQ0EsQ0FEQyxHQUNEQSxDQURDLEdBRUYsbUNBSk5vSCxLQUlNLENBSk5BLEtBSkosR0FDRSxDQURGO0FBYkosR0FDR0ssQ0FESCxFQXlCRTtBQUNBTCxxQkFBaUIsR0FBakJBLEdBREEsQ0FDdUI7QUFFdkI7QUFDQTtBQUVGOztBQUFBLFNBQU87QUFBQTtBQUVMVyxVQUFNLEVBRlI7QUFBTyxHQUFQO0FBTUY7O0FBQUEsMkNBQXFFO0FBQ25FLFFBQU1DLGFBQTZCLEdBQW5DO0FBRUExSCxRQUFNLENBQU5BLG9CQUE0QkksR0FBRCxJQUFTO0FBQ2xDLFFBQUksQ0FBQytHLE1BQU0sQ0FBTkEsU0FBTCxHQUFLQSxDQUFMLEVBQTJCO0FBQ3pCTyxtQkFBYSxDQUFiQSxHQUFhLENBQWJBLEdBQXFCQyxLQUFLLENBQTFCRCxHQUEwQixDQUExQkE7QUFFSDtBQUpEMUg7QUFLQTtBQUdGO0FBQUE7Ozs7OztBQUlPLG1EQUlHO0FBQ1I7QUFDQSxRQUFNRSxJQUFJLEdBQUcscUJBQWIsVUFBYSxDQUFiO0FBQ0EsUUFBTTBILFdBQVcsR0FDZixrQ0FBa0MsaUNBRHBDLElBQ29DLENBRHBDOztBQUVBLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcscUJBQWpCLElBQWlCLENBQWpCO0FBQ0FBLFlBQVEsQ0FBUkEsV0FBb0Isd0RBQTJCQSxRQUFRLENBQXZEQSxRQUFvQixDQUFwQkE7QUFDQSxRQUFJQyxjQUFjLEdBQWxCOztBQUVBLFFBQ0UsK0JBQWVELFFBQVEsQ0FBdkIsYUFDQUEsUUFBUSxDQURSLGdCQURGLFdBSUU7QUFDQSxZQUFNRixLQUFLLEdBQUcseUNBQXVCRSxRQUFRLENBQTdDLFlBQWMsQ0FBZDtBQUVBLFlBQU07QUFBQTtBQUFBO0FBQUEsVUFBcUJFLGFBQWEsQ0FDdENGLFFBQVEsQ0FEOEIsVUFFdENBLFFBQVEsQ0FGOEIsVUFBeEMsS0FBd0MsQ0FBeEM7O0FBTUEsa0JBQVk7QUFDVkMsc0JBQWMsR0FBRyxpQ0FBcUI7QUFDcENwRSxrQkFBUSxFQUQ0QjtBQUVwQ3NFLGNBQUksRUFBRUgsUUFBUSxDQUZzQjtBQUdwQ0YsZUFBSyxFQUFFTSxrQkFBa0IsUUFIM0JILE1BRzJCO0FBSFcsU0FBckIsQ0FBakJBO0FBTUg7QUFFRCxLQTNCRSxDQTJCRjs7O0FBQ0EsVUFBTUksWUFBWSxHQUNoQkwsUUFBUSxDQUFSQSxXQUFvQjNILElBQUksQ0FBeEIySCxTQUNJQSxRQUFRLENBQVJBLFdBQW9CQSxRQUFRLENBQVJBLE9BRHhCQSxNQUNJQSxDQURKQSxHQUVJQSxRQUFRLENBSGQ7QUFLQSxXQUFRTSxTQUFTLEdBQ2IsZUFBZUwsY0FBYyxJQURoQixZQUNiLENBRGEsR0FBakI7QUFHQSxHQXBDRixDQW9DRSxVQUFVO0FBQ1YsV0FBUUssU0FBUyxHQUFHLENBQUgsV0FBRyxDQUFILEdBQWpCO0FBRUg7QUFFRDs7QUFBQSxNQUFNQyxlQUFlLEdBQUdDLE1BQU0sQ0FBOUIsaUJBQThCLENBQTlCOztBQUNPLCtCQUE2QztBQUNsRCxTQUFPckksTUFBTSxDQUFOQSxxQ0FBUCxFQUFPQSxDQUFQO0FBR0Y7O0FBQUEsdUNBQTZEO0FBQzNEO0FBQ0E7QUFDQSxTQUFPO0FBQ0wwRyxPQUFHLEVBQUU0QixXQUFXLENBQUNDLFdBQVcsQ0FBQ3pHLE1BQU0sQ0FBUCxVQUR2QixHQUN1QixDQUFaLENBRFg7QUFFTFEsTUFBRSxFQUFFQSxFQUFFLEdBQUdnRyxXQUFXLENBQUNDLFdBQVcsQ0FBQ3pHLE1BQU0sQ0FBUCxVQUExQixFQUEwQixDQUFaLENBQWQsR0FGUjtBQUFPLEdBQVA7QUF5REY7O0FBQUEsTUFBTTBHLHVCQUF1QixHQUMzQjlELFVBRUEsS0FIRjs7QUFLQSxtQ0FBaUU7QUFDL0QsU0FBTyxLQUFLLE1BQU07QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBK0QsZUFBVyxFQVpOO0FBQVcsR0FBTixDQUFMLE1BYUVDLEdBQUQsSUFBUztBQUNmLFFBQUksQ0FBQ0EsR0FBRyxDQUFSLElBQWE7QUFDWCxVQUFJQyxRQUFRLEdBQVJBLEtBQWdCRCxHQUFHLENBQUhBLFVBQXBCLEtBQXVDO0FBQ3JDLGVBQU9FLFVBQVUsTUFBTUQsUUFBUSxHQUEvQixDQUFpQixDQUFqQjtBQUVGOztBQUFBLFlBQU0sVUFBTiw2QkFBTSxDQUFOO0FBR0Y7O0FBQUEsV0FBT0QsR0FBRyxDQUFWLElBQU9BLEVBQVA7QUFyQkYsR0FBTyxDQUFQO0FBeUJGOztBQUFBLGlEQUFrRTtBQUNoRSxTQUFPLFVBQVUsV0FBV0csY0FBYyxPQUFuQyxDQUFVLENBQVYsT0FBb0Q5RyxHQUFELElBQWdCO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBLFFBQUksQ0FBSixnQkFBcUI7QUFDbkIrRyxzQkFBZ0IsQ0FBaEJBLEdBQWdCLENBQWhCQTtBQUVGOztBQUFBO0FBUEYsR0FBTyxDQUFQO0FBV2E7O0FBQUEsTUFBTTVELE1BQU4sQ0FBbUM7QUFPaEQ7O0FBUGdEO0FBV2hEO0FBa0JBNkQsYUFBVyx5QkFJVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKUztBQUlULEdBSlMsRUErQlQ7QUFBQSxTQTNERkMsS0EyREU7QUFBQSxTQTFERnRGLFFBMERFO0FBQUEsU0F6REZpRSxLQXlERTtBQUFBLFNBeERGc0IsTUF3REU7QUFBQSxTQXZERjNDLFFBdURFO0FBQUEsU0FsREY0QyxVQWtERTtBQUFBLFNBaERGQyxHQWdERSxHQWhEa0MsRUFnRGxDO0FBQUEsU0EvQ0ZDLEdBK0NFO0FBQUEsU0E5Q0ZDLEdBOENFO0FBQUEsU0E3Q0ZDLFVBNkNFO0FBQUEsU0E1Q0ZDLElBNENFO0FBQUEsU0EzQ0ZDLE1BMkNFO0FBQUEsU0ExQ0ZDLFFBMENFO0FBQUEsU0F6Q0ZDLEtBeUNFO0FBQUEsU0F4Q0ZDLFVBd0NFO0FBQUEsU0F2Q0ZDLGNBdUNFO0FBQUEsU0F0Q0ZDLFFBc0NFO0FBQUEsU0FyQ0ZDLE1BcUNFO0FBQUEsU0FwQ0ZDLE9Bb0NFO0FBQUEsU0FuQ0ZDLGFBbUNFOztBQUFBLHNCQXFHWTlILENBQUQsSUFBNEI7QUFDdkMsWUFBTStILEtBQUssR0FBRy9ILENBQUMsQ0FBZjs7QUFFQSxVQUFJLENBQUosT0FBWTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQU07QUFBQTtBQUFBO0FBQUEsWUFBTjtBQUNBLHlDQUVFLGlDQUFxQjtBQUFFd0Isa0JBQVEsRUFBRTRFLFdBQVcsQ0FBdkIsUUFBdUIsQ0FBdkI7QUFGdkI7QUFFdUIsU0FBckIsQ0FGRixFQUdFLFdBSEYsTUFHRSxHQUhGO0FBS0E7QUFHRjs7QUFBQSxVQUFJLENBQUMyQixLQUFLLENBQVYsS0FBZ0I7QUFDZDtBQUdGOztBQUFBLFlBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFOO0FBRUEsWUFBTTtBQUFBO0FBQUEsVUFBZSx3Q0FBckIsR0FBcUIsQ0FBckIsQ0E1QnVDLENBOEJ2QztBQUNBOztBQUNBLFVBQUksY0FBYzNILEVBQUUsS0FBSyxLQUFyQixVQUFvQ29CLFFBQVEsS0FBSyxLQUFyRCxVQUFvRTtBQUNsRTtBQUdGLE9BcEN1QyxDQW9DdkM7QUFDQTs7O0FBQ0EsVUFBSSxhQUFhLENBQUMsVUFBbEIsS0FBa0IsQ0FBbEIsRUFBb0M7QUFDbEM7QUFHRjs7QUFBQSwyQ0FJRTFELE1BQU0sQ0FBTkEsb0JBQTJCO0FBQ3pCbUQsZUFBTyxFQUFFK0csT0FBTyxDQUFQQSxXQUFtQixLQUxoQztBQUk2QixPQUEzQmxLLENBSkY7QUEvSUEsT0FDQTs7O0FBQ0EsaUJBQWEscURBQWIsU0FBYSxDQUFiLENBRkEsQ0FJQTs7QUFDQSx5QkFMQSxDQU1BO0FBQ0E7QUFDQTs7QUFDQSxRQUFJMEQsU0FBUSxLQUFaLFdBQTRCO0FBQzFCLHNCQUFnQixLQUFoQixTQUE4QjtBQUFBO0FBRTVCeUcsbUJBQVcsRUFGaUI7QUFHNUJwSCxhQUFLLEVBSHVCO0FBQUE7QUFLNUJxSCxlQUFPLEVBQUVDLFlBQVksSUFBSUEsWUFBWSxDQUxUO0FBTTVCQyxlQUFPLEVBQUVELFlBQVksSUFBSUEsWUFBWSxDQU52QztBQUE4QixPQUE5QjtBQVVGOztBQUFBLCtCQUEyQjtBQUN6QkUsZUFBUyxFQURnQjtBQUV6QkosaUJBQVcsRUFBRTtBQUZmO0FBRWU7QUFGWSxLQUEzQixDQXBCQSxDQTJCQTtBQUNBOztBQUNBLGtCQUFjakYsTUFBTSxDQUFwQjtBQUVBO0FBQ0E7QUFDQSx3QkFqQ0EsQ0FrQ0E7QUFDQTs7QUFDQSxrQkFDRTtBQUNBLGlEQUE0QnNGLGFBQWEsQ0FBekMseUJBRkY7QUFHQTtBQUNBO0FBQ0E7QUFDQSw0QkExQ0EsQ0EyQ0E7QUFDQTs7QUFDQTtBQUVBOztBQUVBLFFBQUk5RixLQUFKLEVBQXFDLEVBTXJDOztBQUFBLGVBQW1DLEVBNENwQztBQXNERCtGOztBQUFBQSxRQUFNLEdBQVM7QUFDYnJKLFVBQU0sQ0FBTkE7QUFHRjtBQUFBOzs7OztBQUdBc0osTUFBSSxHQUFHO0FBQ0x0SixVQUFNLENBQU5BO0FBR0Y7QUFBQTs7Ozs7Ozs7QUFNQXVKLE1BQUksTUFBV3JJLEVBQU8sR0FBbEIsS0FBMEI0SCxPQUEwQixHQUFwRCxJQUEyRDtBQUM3RDtBQUFDLEtBQUM7QUFBQTtBQUFBO0FBQUEsUUFBY1UsWUFBWSxZQUEzQixFQUEyQixDQUEzQjtBQUNELFdBQU8sa0NBQVAsT0FBTyxDQUFQO0FBR0Y7QUFBQTs7Ozs7Ozs7QUFNQXJJLFNBQU8sTUFBV0QsRUFBTyxHQUFsQixLQUEwQjRILE9BQTBCLEdBQXBELElBQTJEO0FBQ2hFO0FBQUMsS0FBQztBQUFBO0FBQUE7QUFBQSxRQUFjVSxZQUFZLFlBQTNCLEVBQTJCLENBQTNCO0FBQ0QsV0FBTyxxQ0FBUCxPQUFPLENBQVA7QUFHRjs7QUFBQSx5Q0FLb0I7QUFDbEIsUUFBSSxDQUFDQyxVQUFVLENBQWYsR0FBZSxDQUFmLEVBQXNCO0FBQ3BCekosWUFBTSxDQUFOQTtBQUNBO0FBR0Y7O0FBQUEsUUFBSSxDQUFFOEksT0FBRCxDQUFMLElBQTBCO0FBQ3hCO0FBRUYsS0FUa0IsQ0FTbEI7OztBQUNBLFFBQUlZLE9BQUosSUFBUTtBQUNOQyxpQkFBVyxDQUFYQTtBQUdGOztBQUFBLFFBQUksS0FBSixnQkFBeUI7QUFDdkIsOEJBQXdCLEtBQXhCO0FBR0Z6STs7QUFBQUEsTUFBRSxHQUFHMEksU0FBUyxLQUFLLEtBQUwsUUFBa0IsS0FBaEMxSSxhQUFjLENBQWRBO0FBQ0EsVUFBTTJJLFNBQVMsR0FBR0MsU0FBUyxDQUN6QnJFLFdBQVcsQ0FBWEEsRUFBVyxDQUFYQSxHQUFrQnNFLFdBQVcsQ0FBN0J0RSxFQUE2QixDQUE3QkEsR0FEeUIsSUFFekIsS0FGRixNQUEyQixDQUEzQjtBQUlBLDZCQXZCa0IsQ0F5QmxCO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsUUFBSSxDQUFFcUQsT0FBRCxDQUFELE1BQXdCLHFCQUE1QixTQUE0QixDQUE1QixFQUE2RDtBQUMzRDtBQUNBaEYsWUFBTSxDQUFOQSxtQ0FGMkQsQ0FHM0Q7O0FBQ0E7QUFDQTtBQUNBLGtCQUFZLGdCQUFnQixLQUE1QixLQUFZLENBQVo7QUFDQUEsWUFBTSxDQUFOQTtBQUNBO0FBR0YsS0ExQ2tCLENBMENsQjtBQUNBO0FBQ0E7OztBQUNBLFVBQU1rRyxLQUFLLEdBQUcsTUFBTSxnQkFBcEIsV0FBb0IsRUFBcEI7QUFDQSxVQUFNO0FBQUVDLGdCQUFVLEVBQVo7QUFBQSxRQUEyQixNQUFNLGdCQUF2QztBQUVBLFFBQUlDLE1BQU0sR0FBRyx3Q0FBYixHQUFhLENBQWI7QUFFQSxRQUFJO0FBQUE7QUFBQTtBQUFBLFFBQUo7QUFFQUEsVUFBTSxHQUFHLDBCQUFUQSxLQUFTLENBQVRBOztBQUVBLFFBQUlBLE1BQU0sQ0FBTkEsYUFBSixVQUFrQztBQUNoQzVILGNBQVEsR0FBRzRILE1BQU0sQ0FBakI1SDtBQUNBZ0QsU0FBRyxHQUFHLGlDQUFOQSxNQUFNLENBQU5BO0FBR0YsS0EzRGtCLENBMkRsQjtBQUNBO0FBQ0E7OztBQUNBaEQsWUFBUSxHQUFHQSxRQUFRLEdBQ2YscURBQXdCeUgsV0FBVyxDQURwQixRQUNvQixDQUFuQyxDQURlLEdBQW5CekgsU0E5RGtCLENBa0VsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUksQ0FBQyxjQUFMLFNBQUssQ0FBTCxFQUErQjtBQUM3QjZILFlBQU0sR0FBTkE7QUFHRjs7QUFBQSxRQUFJdkMsS0FBSyxHQUFHLHFEQUFaLFFBQVksQ0FBWjtBQUNBLFVBQU07QUFBRTdGLGFBQU8sR0FBVDtBQUFBLFFBQU4sUUE1RWtCLENBOEVsQjtBQUNBOztBQUNBLFFBQUlRLFVBQVUsR0FBZDs7QUFFQSxRQUFJZSxJQUFKLEVBQXFDO0FBQ25DZixnQkFBVSxHQUFHLDhCQUNYLDRDQURXLDRDQU1WRixDQUFELElBQWUsa0JBQWtCO0FBQUVDLGdCQUFRLEVBQTVCO0FBQWtCLE9BQWxCLFNBTmpCQyxRQUFhLENBQWJBOztBQVNBLFVBQUlBLFVBQVUsS0FBZCxJQUF1QjtBQUNyQixjQUFNNkgsYUFBYSxHQUFHLHFEQUNwQixrQkFDRXhMLE1BQU0sQ0FBTkEsbUJBQTBCO0FBQUUwRCxrQkFBUSxFQUR0QztBQUM0QixTQUExQjFELENBREYsZ0JBREYsUUFBc0IsQ0FBdEIsQ0FEcUIsQ0FTckI7QUFDQTs7QUFDQSxZQUFJb0wsS0FBSyxDQUFMQSxTQUFKLGFBQUlBLENBQUosRUFBbUM7QUFDakNwQyxlQUFLLEdBQUxBO0FBQ0F0RixrQkFBUSxHQUFSQTtBQUNBNEgsZ0JBQU0sQ0FBTkE7QUFDQTVFLGFBQUcsR0FBRyxpQ0FBTkEsTUFBTSxDQUFOQTtBQUVIO0FBQ0Y7QUFDRC9DOztBQUFBQSxjQUFVLEdBQUd1SCxTQUFTLENBQUNDLFdBQVcsQ0FBWixVQUFZLENBQVosRUFBMEIsS0FBaER4SCxNQUFzQixDQUF0QkE7O0FBRUEsUUFBSSwrQkFBSixLQUFJLENBQUosRUFBMkI7QUFDekIsWUFBTThILFFBQVEsR0FBRyx3Q0FBakIsVUFBaUIsQ0FBakI7QUFDQSxZQUFNdkUsVUFBVSxHQUFHdUUsUUFBUSxDQUEzQjtBQUVBLFlBQU1DLFVBQVUsR0FBRywrQkFBbkIsS0FBbUIsQ0FBbkI7QUFDQSxZQUFNQyxVQUFVLEdBQUcsK0NBQW5CLFVBQW1CLENBQW5CO0FBQ0EsWUFBTUMsaUJBQWlCLEdBQUc1QyxLQUFLLEtBQS9CO0FBQ0EsWUFBTWxCLGNBQWMsR0FBRzhELGlCQUFpQixHQUNwQzdELGFBQWEsb0JBRHVCLEtBQ3ZCLENBRHVCLEdBQXhDOztBQUlBLFVBQUksZUFBZ0I2RCxpQkFBaUIsSUFBSSxDQUFDOUQsY0FBYyxDQUF4RCxRQUFrRTtBQUNoRSxjQUFNK0QsYUFBYSxHQUFHN0wsTUFBTSxDQUFOQSxLQUFZMEwsVUFBVSxDQUF0QjFMLGVBQ25Cb0gsS0FBRCxJQUFXLENBQUNPLEtBQUssQ0FEbkIsS0FDbUIsQ0FERzNILENBQXRCOztBQUlBLFlBQUk2TCxhQUFhLENBQWJBLFNBQUosR0FBOEI7QUFDNUIsb0JBQTJDO0FBQ3pDaEssbUJBQU8sQ0FBUEEsS0FDRyxHQUNDK0osaUJBQWlCLDBCQUVaLGlDQUhQLDhCQUFDLEdBS0UsZUFBY0MsYUFBYSxDQUFiQSxVQU5uQmhLO0FBWUY7O0FBQUEsZ0JBQU0sVUFDSixDQUFDK0osaUJBQWlCLEdBQ2IsMEJBQXlCbEYsR0FBSSxvQ0FBbUNtRixhQUFhLENBQWJBLFVBRG5ELG9DQUliLDhCQUE2QjNFLFVBQVcsOENBQTZDOEIsS0FKMUYsU0FLRyw0Q0FDQzRDLGlCQUFpQixpQ0FFYixzQkFUVixFQUFNLENBQU47QUFhSDtBQWhDRCxhQWdDTyx1QkFBdUI7QUFDNUJ0SixVQUFFLEdBQUcsaUNBQ0h0QyxNQUFNLENBQU5BLHFCQUE0QjtBQUMxQjBELGtCQUFRLEVBQUVvRSxjQUFjLENBREU7QUFFMUJILGVBQUssRUFBRU0sa0JBQWtCLFFBQVFILGNBQWMsQ0FIbkR4RixNQUc2QjtBQUZDLFNBQTVCdEMsQ0FERyxDQUFMc0M7QUFESyxhQU9BO0FBQ0w7QUFDQXRDLGNBQU0sQ0FBTkE7QUFFSDtBQUVEa0Y7O0FBQUFBLFVBQU0sQ0FBTkE7O0FBRUEsUUFBSTtBQUNGLFlBQU00RyxTQUFTLEdBQUcsTUFBTSw4Q0FBeEIsT0FBd0IsQ0FBeEI7QUFPQSxVQUFJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFKLFVBUkUsQ0FVRjs7QUFDQSxVQUNFLENBQUMxQixPQUFPLElBQVIscUJBRUNySCxLQUFELENBRkEsYUFHQ0EsS0FBRCxVQUFDQSxDQUpILGNBS0U7QUFDQSxjQUFNZ0osV0FBVyxHQUFJaEosS0FBRCxVQUFDQSxDQUFyQixhQURBLENBR0E7QUFDQTtBQUNBOztBQUNBLFlBQUlnSixXQUFXLENBQVhBLFdBQUosR0FBSUEsQ0FBSixFQUFpQztBQUMvQixnQkFBTUMsVUFBVSxHQUFHLHdDQUFuQixXQUFtQixDQUFuQjs7QUFDQTs7QUFFQSxjQUFJWixLQUFLLENBQUxBLFNBQWVZLFVBQVUsQ0FBN0IsUUFBSVosQ0FBSixFQUF5QztBQUN2QyxtQkFBTyxzREFBUCxPQUFPLENBQVA7QUFPSDtBQUVEaEs7O0FBQUFBLGNBQU0sQ0FBTkE7QUFDQSxlQUFPLFlBQVksTUFBTSxDQUF6QixDQUFPLENBQVA7QUFHRjhEOztBQUFBQSxZQUFNLENBQU5BO0FBQ0Esb0NBR0U4RixTQUFTLEtBQUssS0FBTCxRQUFrQixLQUg3QixhQUdXLENBSFg7O0FBT0EsZ0JBQTJDO0FBQ3pDLGNBQU1pQixPQUFZLEdBQUcseUJBQXJCO0FBQ0U3SyxjQUFELEtBQUNBLENBQUQsYUFBQ0EsR0FDQTZLLE9BQU8sQ0FBUEEsb0JBQTRCQSxPQUFPLENBQW5DQSx1QkFDQSxDQUFFSCxTQUFTLENBQVYsU0FBQ0EsQ0FGSCxlQUFDMUs7QUFLSjs7QUFBQSxZQUFNLDZEQUNIYyxDQUFELElBQU87QUFDTCxZQUFJQSxDQUFDLENBQUwsV0FBaUJnSyxLQUFLLEdBQUdBLEtBQUssSUFBOUIsQ0FBaUJBLENBQWpCLEtBQ0s7QUFIVCxPQUFNLENBQU47O0FBT0EsaUJBQVc7QUFDVGhILGNBQU0sQ0FBTkE7QUFDQTtBQUdGOztBQUFBLFVBQUlSLEtBQUosRUFBMkMsRUFLM0NROztBQUFBQSxZQUFNLENBQU5BO0FBRUE7QUFDQSxLQTNFRixDQTJFRSxZQUFZO0FBQ1osVUFBSW5ELEdBQUcsQ0FBUCxXQUFtQjtBQUNqQjtBQUVGOztBQUFBO0FBRUg7QUFFRG9LOztBQUFBQSxhQUFXLGtCQUlUakMsT0FBMEIsR0FKakIsSUFLSDtBQUNOLGNBQTJDO0FBQ3pDLFVBQUksT0FBTzlJLE1BQU0sQ0FBYixZQUFKLGFBQTJDO0FBQ3pDUyxlQUFPLENBQVBBO0FBQ0E7QUFHRjs7QUFBQSxVQUFJLE9BQU9ULE1BQU0sQ0FBTkEsUUFBUCxNQUFPQSxDQUFQLEtBQUosYUFBbUQ7QUFDakRTLGVBQU8sQ0FBUEEsTUFBZSwyQkFBMEIwSixNQUF6QzFKO0FBQ0E7QUFFSDtBQUVEOztBQUFBLFFBQUkwSixNQUFNLEtBQU5BLGVBQTBCLHlCQUE5QixJQUErQztBQUM3QyxzQkFBZ0JyQixPQUFPLENBQXZCO0FBQ0EsWUFBTSxDQUFOLGdCQUNFO0FBQUE7QUFBQTtBQUFBO0FBSUVrQyxXQUFHLEVBTFA7QUFDRSxPQURGLEVBT0U7QUFDQTtBQUNBO0FBVEY7QUFjSDtBQUVEOztBQUFBLHNFQU02QjtBQUMzQixRQUFJckssR0FBRyxDQUFQLFdBQW1CO0FBQ2pCO0FBQ0E7QUFHRjs7QUFBQSxRQUFJcUcsZUFBZSxJQUFmQSxPQUFKLGVBQTZDO0FBQzNDbEQsWUFBTSxDQUFOQSx5Q0FEMkMsQ0FHM0M7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7QUFDQTlELFlBQU0sQ0FBTkEsbUJBVDJDLENBVzNDO0FBQ0E7O0FBQ0EsWUFBTWlMLHNCQUFOO0FBR0Y7O0FBQUEsUUFBSTtBQUNGLFlBQU07QUFBRUMsWUFBSSxFQUFOO0FBQUE7QUFBQSxVQUFtQyxNQUFNLG9CQUEvQyxTQUErQyxDQUEvQztBQUdBLFlBQU1SLFNBQTJCLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFJbENJLGFBQUssRUFKUDtBQUFvQyxPQUFwQzs7QUFPQSxVQUFJO0FBQ0ZKLGlCQUFTLENBQVRBLFFBQWtCLE1BQU0sZ0NBQWdDO0FBQUE7QUFBQTtBQUF4REE7QUFBd0QsU0FBaEMsQ0FBeEJBO0FBS0EsT0FORixDQU1FLGVBQWU7QUFDZmpLLGVBQU8sQ0FBUEE7QUFDQWlLLGlCQUFTLENBQVRBO0FBR0Y7O0FBQUE7QUFDQSxLQXZCRixDQXVCRSxxQkFBcUI7QUFDckIsYUFBTyw2REFBUCxJQUFPLENBQVA7QUFFSDtBQUVEOztBQUFBLGlEQUtFM0ksT0FBZ0IsR0FMbEIsT0FNNkI7QUFDM0IsUUFBSTtBQUNGLFlBQU1vSixlQUFlLEdBQUcsZ0JBQXhCLEtBQXdCLENBQXhCOztBQUVBLFVBQUlwSixPQUFPLElBQVBBLG1CQUE4QixlQUFsQyxPQUF3RDtBQUN0RDtBQUdGOztBQUFBLFlBQU0ySSxTQUEyQixHQUFHUyxlQUFlLHFCQUUvQyxNQUFNLGdDQUFpQzdELEdBQUQsS0FBVTtBQUM5QzZCLGlCQUFTLEVBQUU3QixHQUFHLENBRGdDO0FBRTlDeUIsbUJBQVcsRUFBRXpCLEdBQUcsQ0FGOEI7QUFHOUMwQixlQUFPLEVBQUUxQixHQUFHLENBQUhBLElBSHFDO0FBSTlDNEIsZUFBTyxFQUFFNUIsR0FBRyxDQUFIQSxJQU5mO0FBRW9ELE9BQVYsQ0FBaEMsQ0FGVjtBQVNBLFlBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFOOztBQUVBLGdCQUEyQztBQUN6QyxjQUFNO0FBQUE7QUFBQSxZQUF5QjhELG1CQUFPLENBQXRDLDBCQUFzQyxDQUF0Qzs7QUFDQSxZQUFJLENBQUNDLGtCQUFrQixDQUF2QixTQUF1QixDQUF2QixFQUFvQztBQUNsQyxnQkFBTSxVQUNILHlEQUF3RC9JLFFBRDNELEdBQU0sQ0FBTjtBQUlIO0FBRUQ7O0FBQUE7O0FBRUEsVUFBSTBHLE9BQU8sSUFBWCxTQUF3QjtBQUN0QnNDLGdCQUFRLEdBQUcsNEJBQ1QsaUNBQXFCO0FBQUE7QUFEWjtBQUNZLFNBQXJCLENBRFMsRUFFVHZCLFdBQVcsQ0FGRixFQUVFLENBRkYsV0FJVCxLQUpTLFFBS1QsS0FMRnVCLGFBQVcsQ0FBWEE7QUFTRjs7QUFBQSxZQUFNM0osS0FBSyxHQUFHLE1BQU0sY0FBZ0MsTUFDbERxSCxPQUFPLEdBQ0gsb0JBREcsUUFDSCxDQURHLEdBRUhFLE9BQU8sR0FDUCxvQkFETyxRQUNQLENBRE8sR0FFUCxnQ0FFRTtBQUNBO0FBQUE7QUFBQTtBQUdFckIsY0FBTSxFQVhoQjtBQVFRLE9BSEYsQ0FMYyxDQUFwQjtBQWdCQTZDLGVBQVMsQ0FBVEE7QUFDQTtBQUNBO0FBQ0EsS0ExREYsQ0EwREUsWUFBWTtBQUNaLGFBQU8sZ0RBQVAsRUFBTyxDQUFQO0FBRUg7QUFFRGE7O0FBQUFBLEtBQUcsbUNBTWM7QUFDZjtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBTyxZQUFQLElBQU8sQ0FBUDtBQUdGO0FBQUE7Ozs7OztBQUlBQyxnQkFBYyxLQUE2QjtBQUN6QztBQUdGQzs7QUFBQUEsaUJBQWUsS0FBc0I7QUFDbkMsUUFBSSxDQUFDLEtBQUwsUUFBa0I7QUFDbEIsVUFBTSwwQkFBMEIsa0JBQWhDLEdBQWdDLENBQWhDO0FBQ0EsVUFBTSwwQkFBMEJ2SyxFQUFFLENBQUZBLE1BQWhDLEdBQWdDQSxDQUFoQyxDQUhtQyxDQUtuQzs7QUFDQSxRQUFJd0ssT0FBTyxJQUFJQyxZQUFZLEtBQXZCRCxnQkFBNENFLE9BQU8sS0FBdkQsU0FBcUU7QUFDbkU7QUFHRixLQVZtQyxDQVVuQzs7O0FBQ0EsUUFBSUQsWUFBWSxLQUFoQixjQUFtQztBQUNqQztBQUdGLEtBZm1DLENBZW5DO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxXQUFPQyxPQUFPLEtBQWQ7QUFHRkM7O0FBQUFBLGNBQVksS0FBbUI7QUFDN0IsVUFBTSxXQUFXM0ssRUFBRSxDQUFGQSxNQUFqQixHQUFpQkEsQ0FBakIsQ0FENkIsQ0FFN0I7O0FBQ0EsUUFBSTBGLElBQUksS0FBUixJQUFpQjtBQUNmNUcsWUFBTSxDQUFOQTtBQUNBO0FBR0YsS0FSNkIsQ0FRN0I7OztBQUNBLFVBQU04TCxJQUFJLEdBQUd6SyxRQUFRLENBQVJBLGVBQWIsSUFBYUEsQ0FBYjs7QUFDQSxjQUFVO0FBQ1J5SyxVQUFJLENBQUpBO0FBQ0E7QUFFRixLQWQ2QixDQWM3QjtBQUNBOzs7QUFDQSxVQUFNQyxNQUFNLEdBQUcxSyxRQUFRLENBQVJBLHdCQUFmLENBQWVBLENBQWY7O0FBQ0EsZ0JBQVk7QUFDVjBLLFlBQU0sQ0FBTkE7QUFFSDtBQUVEQzs7QUFBQUEsVUFBUSxTQUEwQjtBQUNoQyxXQUFPLGdCQUFQO0FBR0ZDOztBQUFBQSxjQUFZLG9CQUF5Q0MsYUFBYSxHQUF0RCxNQUErRDtBQUN6RSxVQUFNO0FBQUE7QUFBQSxRQUFOO0FBQ0EsVUFBTUMsYUFBYSxHQUFHLHFEQUNwQiw4Q0FBb0JELGFBQWEsR0FBR25DLFdBQVcsQ0FBZCxRQUFjLENBQWQsR0FEbkMsUUFDRSxDQURvQixDQUF0Qjs7QUFJQSxRQUFJb0MsYUFBYSxLQUFiQSxVQUE0QkEsYUFBYSxLQUE3QyxXQUE2RDtBQUMzRDtBQUdGLEtBVnlFLENBVXpFOzs7QUFDQSxRQUFJLENBQUNuQyxLQUFLLENBQUxBLFNBQUwsYUFBS0EsQ0FBTCxFQUFxQztBQUNuQztBQUNBQSxXQUFLLENBQUxBLEtBQVlrQixJQUFELElBQVU7QUFDbkIsWUFDRSx3Q0FDQSw2Q0FGRixhQUVFLENBRkYsRUFHRTtBQUNBTixvQkFBVSxDQUFWQSxXQUFzQnNCLGFBQWEsR0FBR2hGLFdBQVcsQ0FBZCxJQUFjLENBQWQsR0FBbkMwRDtBQUNBO0FBRUg7QUFSRFo7QUFVRjs7QUFBQTtBQUdGO0FBQUE7Ozs7Ozs7O0FBTUEsc0JBRUVuQyxNQUFjLEdBRmhCLEtBR0VpQixPQUF3QixHQUgxQixJQUlpQjtBQUNmLFFBQUlvQixNQUFNLEdBQUcsd0NBQWIsR0FBYSxDQUFiO0FBRUEsUUFBSTtBQUFBO0FBQUEsUUFBSjtBQUVBLFVBQU1GLEtBQUssR0FBRyxNQUFNLGdCQUFwQixXQUFvQixFQUFwQjtBQUVBRSxVQUFNLEdBQUcsMEJBQVRBLEtBQVMsQ0FBVEE7O0FBRUEsUUFBSUEsTUFBTSxDQUFOQSxhQUFKLFVBQWtDO0FBQ2hDNUgsY0FBUSxHQUFHNEgsTUFBTSxDQUFqQjVIO0FBQ0FnRCxTQUFHLEdBQUcsaUNBQU5BLE1BQU0sQ0FBTkE7QUFHRixLQWRlLENBY2Y7OztBQUNBLGNBQTJDO0FBQ3pDO0FBR0Y7O0FBQUEsVUFBTXNDLEtBQUssR0FBRyxxREFBZCxRQUFjLENBQWQ7QUFDQSxVQUFNd0UsT0FBTyxDQUFQQSxJQUFZLENBQ2hCLDBDQUdFLEtBSEYsUUFJRSxLQUxjLGFBQ2hCLENBRGdCLEVBT2hCLGdCQUFnQnRELE9BQU8sQ0FBUEEsd0JBQWhCLFlBUEYsS0FPRSxDQVBnQixDQUFac0QsQ0FBTjtBQVdGOztBQUFBLDhCQUE0RDtBQUMxRCxRQUFJakgsU0FBUyxHQUFiOztBQUNBLFVBQU1rSCxNQUFNLEdBQUksV0FBVyxNQUFNO0FBQy9CbEgsZUFBUyxHQUFUQTtBQURGOztBQUlBLFVBQU1tSCxlQUFlLEdBQUcsTUFBTSx5QkFBOUIsS0FBOEIsQ0FBOUI7O0FBRUEsbUJBQWU7QUFDYixZQUFNeEIsS0FBVSxHQUFHLFVBQ2hCLHdDQUF1Q2xELEtBRDFDLEdBQW1CLENBQW5CO0FBR0FrRCxXQUFLLENBQUxBO0FBQ0E7QUFHRjs7QUFBQSxRQUFJdUIsTUFBTSxLQUFLLEtBQWYsS0FBeUI7QUFDdkI7QUFHRjs7QUFBQTtBQUdGRTs7QUFBQUEsVUFBUSxLQUFzQztBQUM1QyxRQUFJcEgsU0FBUyxHQUFiOztBQUNBLFVBQU1rSCxNQUFNLEdBQUcsTUFBTTtBQUNuQmxILGVBQVMsR0FBVEE7QUFERjs7QUFHQTtBQUNBLFdBQU9xSCxFQUFFLEdBQUZBLEtBQVdDLElBQUQsSUFBVTtBQUN6QixVQUFJSixNQUFNLEtBQUssS0FBZixLQUF5QjtBQUN2QjtBQUdGOztBQUFBLHFCQUFlO0FBQ2IsY0FBTTFMLEdBQVEsR0FBRyxVQUFqQixpQ0FBaUIsQ0FBakI7QUFDQUEsV0FBRyxDQUFIQTtBQUNBO0FBR0Y7O0FBQUE7QUFYRixLQUFPNkwsQ0FBUDtBQWVGRTs7QUFBQUEsZ0JBQWMsV0FBb0M7QUFDaEQsVUFBTTtBQUFFOUwsVUFBSSxFQUFOO0FBQUEsUUFBcUIsa0JBQWtCWixNQUFNLENBQU5BLFNBQTdDLElBQTJCLENBQTNCOztBQUNBLFFBQUlzRCxLQUFKLEVBQWlFLEVBR2pFOztBQUFBLFdBQU9xSixhQUFhLFdBQVcsS0FBeEJBLEtBQWEsQ0FBYkEsTUFBMENGLElBQUQsSUFBVTtBQUN4RDtBQUNBO0FBRkYsS0FBT0UsQ0FBUDtBQU1GQzs7QUFBQUEsZ0JBQWMsV0FBb0M7QUFDaEQsV0FBT0QsYUFBYSxXQUFXLEtBQS9CLEtBQW9CLENBQXBCO0FBR0ZoSTs7QUFBQUEsaUJBQWUsaUJBR0M7QUFDZCxVQUFNO0FBQUV3RSxlQUFTLEVBQVg7QUFBQSxRQUFxQixnQkFBM0IsT0FBMkIsQ0FBM0I7O0FBQ0EsVUFBTTBELE9BQU8sR0FBRyxjQUFoQixHQUFnQixDQUFoQjs7QUFDQUMsT0FBRyxDQUFIQTtBQUNBLFdBQU8scUNBQWlEO0FBQUE7QUFBQTtBQUd0RHBNLFlBQU0sRUFIZ0Q7QUFBeEQ7QUFBd0QsS0FBakQsQ0FBUDtBQVFGcU07O0FBQUFBLG9CQUFrQixLQUFtQjtBQUNuQyxRQUFJLEtBQUosS0FBYztBQUNaakosWUFBTSxDQUFOQSxnQ0FBdUNtSCxzQkFBdkNuSDtBQUNBO0FBQ0E7QUFFSDtBQUVEa0o7O0FBQUFBLFFBQU0sT0FBd0M7QUFDNUMsV0FBTyxlQUFlLHlCQUF0QixTQUFPLENBQVA7QUF6M0I4Qzs7QUFBQTs7O0FBQTdCbEosTSxDQTJCWnNFLE1BM0JZdEUsR0EyQlUsb0JBM0JWQSxDOzs7Ozs7Ozs7Ozs7Ozs7d0NDbFZyQjs7QUFDZSx1Q0FBdUQ7QUFDcEUsU0FBT21KLE9BQU8sQ0FBUEEsa0JBQTJCQyxJQUFELElBQWtCQyxrQkFBa0IsQ0FBckUsSUFBcUUsQ0FBOURGLENBQVA7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3FCRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXhCQSxDLENBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFNQSxNQUFNRyxnQkFBZ0IsR0FBdEI7O0FBRU8sMkJBQXNDO0FBQzNDLE1BQUk7QUFBQTtBQUFBO0FBQUEsTUFBSjtBQUNBLE1BQUlDLFFBQVEsR0FBR0MsTUFBTSxDQUFOQSxZQUFmO0FBQ0EsTUFBSWhMLFFBQVEsR0FBR2dMLE1BQU0sQ0FBTkEsWUFBZjtBQUNBLE1BQUkxRyxJQUFJLEdBQUcwRyxNQUFNLENBQU5BLFFBQVg7QUFDQSxNQUFJL0csS0FBSyxHQUFHK0csTUFBTSxDQUFOQSxTQUFaO0FBQ0EsTUFBSUMsSUFBb0IsR0FBeEI7QUFFQUMsTUFBSSxHQUFHQSxJQUFJLEdBQUdMLGtCQUFrQixDQUFsQkEsSUFBa0IsQ0FBbEJBLHdCQUFILE1BQVhLOztBQUVBLE1BQUlGLE1BQU0sQ0FBVixNQUFpQjtBQUNmQyxRQUFJLEdBQUdDLElBQUksR0FBR0YsTUFBTSxDQUFwQkM7QUFERixTQUVPLGNBQWM7QUFDbkJBLFFBQUksR0FBR0MsSUFBSSxJQUFJLENBQUNDLFFBQVEsQ0FBUkEsUUFBRCxHQUFDQSxDQUFELEdBQTBCLElBQUdBLFFBQTdCLE1BQWZGLFFBQVcsQ0FBWEE7O0FBQ0EsUUFBSUQsTUFBTSxDQUFWLE1BQWlCO0FBQ2ZDLFVBQUksSUFBSSxNQUFNRCxNQUFNLENBQXBCQztBQUVIO0FBRUQ7O0FBQUEsTUFBSWhILEtBQUssSUFBSSxpQkFBYixVQUF3QztBQUN0Q0EsU0FBSyxHQUFHbUgsTUFBTSxDQUFDQyxXQUFXLENBQVhBLHVCQUFmcEgsS0FBZW9ILENBQUQsQ0FBZHBIO0FBR0Y7O0FBQUEsTUFBSXFILE1BQU0sR0FBR04sTUFBTSxDQUFOQSxVQUFrQi9HLEtBQUssSUFBSyxJQUFHQSxLQUEvQitHLE1BQWI7QUFFQSxNQUFJRCxRQUFRLElBQUlBLFFBQVEsQ0FBUkEsT0FBZ0IsQ0FBaEJBLE9BQWhCLEtBQTZDQSxRQUFRLElBQVJBOztBQUU3QyxNQUNFQyxNQUFNLENBQU5BLFdBQ0MsQ0FBQyxhQUFhRixnQkFBZ0IsQ0FBaEJBLEtBQWQsUUFBY0EsQ0FBZCxLQUFrREcsSUFBSSxLQUZ6RCxPQUdFO0FBQ0FBLFFBQUksR0FBRyxRQUFRQSxJQUFJLElBQW5CQSxFQUFPLENBQVBBO0FBQ0EsUUFBSWpMLFFBQVEsSUFBSUEsUUFBUSxDQUFSQSxDQUFRLENBQVJBLEtBQWhCLEtBQXFDQSxRQUFRLEdBQUcsTUFBWEE7QUFMdkMsU0FNTyxJQUFJLENBQUosTUFBVztBQUNoQmlMLFFBQUksR0FBSkE7QUFHRjs7QUFBQSxNQUFJM0csSUFBSSxJQUFJQSxJQUFJLENBQUpBLENBQUksQ0FBSkEsS0FBWixLQUE2QkEsSUFBSSxHQUFHLE1BQVBBO0FBQzdCLE1BQUlnSCxNQUFNLElBQUlBLE1BQU0sQ0FBTkEsQ0FBTSxDQUFOQSxLQUFkLEtBQWlDQSxNQUFNLEdBQUcsTUFBVEE7QUFFakN0TCxVQUFRLEdBQUdBLFFBQVEsQ0FBUkEsaUJBQVhBLGtCQUFXQSxDQUFYQTtBQUNBc0wsUUFBTSxHQUFHQSxNQUFNLENBQU5BLGFBQVRBLEtBQVNBLENBQVRBO0FBRUEsU0FBUSxHQUFFUCxRQUFTLEdBQUVFLElBQUssR0FBRWpMLFFBQVMsR0FBRXNMLE1BQU8sR0FBRWhILElBQWhEO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7O3lDQ3hFRDs7QUFDQSxNQUFNaUgsVUFBVSxHQUFoQjs7QUFFTywrQkFBZ0Q7QUFDckQsU0FBT0EsVUFBVSxDQUFWQSxLQUFQLEtBQU9BLENBQVA7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0xEOztBQUNBOztBQUVBLE1BQU1DLFVBQVUsR0FBRyxRQUNqQixvQkFBNkMsU0FENUIsQ0FBbkI7QUFJQTs7Ozs7OztBQU1PLHFDQUFzRDtBQUMzRCxRQUFNQyxZQUFZLEdBQUdqUCxJQUFJLEdBQUcsY0FBSCxVQUFHLENBQUgsR0FBekI7QUFDQSxRQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFGLGFBUkosWUFRSSxDQVJKOztBQVNBLE1BQ0VrUCxNQUFNLEtBQUtGLFVBQVUsQ0FBckJFLFVBQ0NYLFFBQVEsS0FBUkEsV0FBd0JBLFFBQVEsS0FGbkMsVUFHRTtBQUNBLFVBQU0sVUFBTixpQ0FBTSxDQUFOO0FBRUY7O0FBQUEsU0FBTztBQUFBO0FBRUw5RyxTQUFLLEVBQUUseUNBRkYsWUFFRSxDQUZGO0FBQUE7QUFBQTtBQUtMM0YsUUFBSSxFQUFFQSxJQUFJLENBQUpBLE1BQVdrTixVQUFVLENBQVZBLE9BTG5CLE1BS1FsTjtBQUxELEdBQVA7QUFPRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSU87O0FBQUEsTUFBTXFOLGNBQ2MsR0FBRztBQUM1QkMsV0FBUyxFQURtQjtBQUU1QkMsV0FBUyxFQUhKO0FBQ3VCLENBRHZCOzs7QUFNQSxNQUFNQyx5QkFDYyxtQ0FBRyxjQUFIO0FBRXpCQyxRQUFNLEVBSEQ7QUFDb0IsRUFEcEI7Ozs7ZUFNUSxDQUFDQyxXQUFXLEdBQVosVUFBeUI7QUFDdEMsU0FBUWxMLElBQUQsSUFBa0I7QUFDdkIsVUFBTXZFLElBQXdCLEdBQTlCO0FBQ0EsVUFBTTBQLFlBQVksR0FBR0MsWUFBWSxDQUFaQSx5QkFHbkJGLFdBQVcsK0JBSGIsY0FBcUJFLENBQXJCO0FBS0EsVUFBTUMsT0FBTyxHQUFHRCxZQUFZLENBQVpBLCtCQUFoQixJQUFnQkEsQ0FBaEI7QUFFQSxXQUFPLHNCQUF1RDtBQUM1RCxZQUFNbEgsR0FBRyxHQUFHaEYsUUFBUSxJQUFSQSxlQUEyQm1NLE9BQU8sQ0FBOUMsUUFBOEMsQ0FBOUM7O0FBQ0EsVUFBSSxDQUFKLEtBQVU7QUFDUjtBQUdGOztBQUFBLHVCQUFpQjtBQUNmLGFBQUssTUFBTCxhQUF3QjtBQUN0QjtBQUNBO0FBQ0EsY0FBSSxPQUFPelAsR0FBRyxDQUFWLFNBQUosVUFBa0M7QUFDaEMsbUJBQVFzSSxHQUFHLENBQUosTUFBQ0EsQ0FBbUJ0SSxHQUFHLENBQTlCLElBQVFzSSxDQUFSO0FBRUg7QUFDRjtBQUVEOztBQUFBLDZDQUFPLE1BQVAsR0FBdUJBLEdBQUcsQ0FBMUI7QUFoQkY7QUFURjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQkY7O0FBQ0E7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJZTs7QUFBQSx1RkFNYjtBQUNBLE1BQUlvSCxpQkFLbUMsR0FMdkM7O0FBT0EsTUFBSS9ELFdBQVcsQ0FBWEEsV0FBSixHQUFJQSxDQUFKLEVBQWlDO0FBQy9CK0QscUJBQWlCLEdBQUcsd0NBQXBCQSxXQUFvQixDQUFwQkE7QUFERixTQUVPO0FBQ0wsVUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNGLFFBVEosV0FTSSxDQVRKO0FBV0FBLHFCQUFpQixHQUFHO0FBQUE7QUFFbEJuSSxXQUFLLEVBQUUseUNBRlcsWUFFWCxDQUZXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFwQm1JO0FBQW9CLEtBQXBCQTtBQVlGOztBQUFBLFFBQU1DLFNBQVMsR0FBR0QsaUJBQWlCLENBQW5DO0FBQ0EsUUFBTUUsUUFBUSxHQUFJLEdBQUVGLGlCQUFpQixDQUFDcE0sUUFBVSxHQUM5Q29NLGlCQUFpQixDQUFqQkEsUUFBMEIsRUFENUI7QUFHQSxRQUFNRyxpQkFBcUMsR0FBM0M7QUFDQUwsY0FBWSxDQUFaQTtBQUVBLFFBQU1NLGNBQWMsR0FBR0QsaUJBQWlCLENBQWpCQSxJQUF1QjdQLEdBQUQsSUFBU0EsR0FBRyxDQUF6RCxJQUF1QjZQLENBQXZCO0FBRUEsTUFBSUUsbUJBQW1CLEdBQUcsWUFBWSxDQUFaLGtCQUV4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFFQyxZQUFRLEVBUlo7QUFRRSxHQVJ3QixDQUExQjtBQVVBLGFBckRBLENBdURBOztBQUNBLE9BQUssTUFBTSxNQUFYLFVBQVcsQ0FBWCxJQUFnQ3BRLE1BQU0sQ0FBTkEsUUFBaEMsU0FBZ0NBLENBQWhDLEVBQTJEO0FBQ3pELFFBQUlOLEtBQUssR0FBR21HLEtBQUssQ0FBTEEsc0JBQTRCd0ssVUFBVSxDQUF0Q3hLLENBQXNDLENBQXRDQSxHQUFaOztBQUNBLGVBQVc7QUFDVDtBQUNBO0FBQ0FuRyxXQUFLLEdBQUksSUFBR0EsS0FBWkE7QUFDQSxZQUFNNFEsYUFBYSxHQUFHVixZQUFZLENBQVpBLGVBQTRCO0FBQUVRLGdCQUFRLEVBQTVEO0FBQWtELE9BQTVCUixDQUF0QjtBQUNBbFEsV0FBSyxHQUFHNFEsYUFBYSxDQUFiQSxNQUFhLENBQWJBLFFBQVI1USxDQUFRNFEsQ0FBUjVRO0FBRUZxUTs7QUFBQUEsYUFBUyxDQUFUQSxHQUFTLENBQVRBO0FBR0YsR0FwRUEsQ0FvRUE7QUFDQTs7O0FBQ0EsUUFBTVEsU0FBUyxHQUFHdlEsTUFBTSxDQUFOQSxLQUFsQixNQUFrQkEsQ0FBbEI7O0FBRUEsTUFDRXdRLG1CQUFtQixJQUNuQixDQUFDRCxTQUFTLENBQVRBLEtBQWdCblEsR0FBRCxJQUFTOFAsY0FBYyxDQUFkQSxTQUYzQixHQUUyQkEsQ0FBeEJLLENBRkgsRUFHRTtBQUNBLFNBQUssTUFBTCxrQkFBNkI7QUFDM0IsVUFBSSxFQUFFblEsR0FBRyxJQUFULFNBQUksQ0FBSixFQUF5QjtBQUN2QjJQLGlCQUFTLENBQVRBLEdBQVMsQ0FBVEEsR0FBaUI1SSxNQUFNLENBQXZCNEksR0FBdUIsQ0FBdkJBO0FBRUg7QUFDRjtBQUVEOztBQUFBLFFBQU1VLGlCQUFpQixHQUFHMUUsV0FBVyxDQUFYQSxtQkFBMUI7O0FBRUEsTUFBSTtBQUNGMkUsVUFBTSxHQUFJLEdBQUVELGlCQUFpQixjQUFjLEVBQUcsR0FBRU4sbUJBQW1CLFFBQW5FTztBQUlBLFVBQU0sbUJBQW1CQSxNQUFNLENBQU5BLE1BQXpCLEdBQXlCQSxDQUF6QjtBQUNBWixxQkFBaUIsQ0FBakJBO0FBQ0FBLHFCQUFpQixDQUFqQkEsT0FBMEIsR0FBRTlILElBQUksU0FBUyxFQUFHLEdBQUVBLElBQUksSUFBSSxFQUF0RDhIO0FBQ0EsV0FBT0EsaUJBQWlCLENBQXhCO0FBQ0EsR0FURixDQVNFLFlBQVk7QUFDWixRQUFJL04sR0FBRyxDQUFIQSxjQUFKLDhDQUFJQSxDQUFKLEVBQXVFO0FBQ3JFLFlBQU0sVUFBTix3S0FBTSxDQUFOO0FBSUY7O0FBQUE7QUFHRixHQXZHQSxDQXVHQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ErTixtQkFBaUIsQ0FBakJBLHdDQUEwQixLQUExQkEsR0FFS0EsaUJBQWlCLENBRnRCQTtBQUtBLFNBQU87QUFBQTtBQUFQO0FBQU8sR0FBUDtBQUlELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvSE0sOENBRVc7QUFDaEIsUUFBTW5JLEtBQXFCLEdBQTNCO0FBQ0FnSixjQUFZLENBQVpBLFFBQXFCLGdCQUFnQjtBQUNuQyxRQUFJLE9BQU9oSixLQUFLLENBQVosR0FBWSxDQUFaLEtBQUosYUFBdUM7QUFDckNBLFdBQUssQ0FBTEEsR0FBSyxDQUFMQTtBQURGLFdBRU8sSUFBSTlCLEtBQUssQ0FBTEEsUUFBYzhCLEtBQUssQ0FBdkIsR0FBdUIsQ0FBbkI5QixDQUFKLEVBQStCO0FBQ3BDO0FBQUU4QixXQUFLLENBQU4sR0FBTSxDQUFMQSxDQUFELElBQUNBLENBQUQsS0FBQ0E7QUFERyxXQUVBO0FBQ0xBLFdBQUssQ0FBTEEsR0FBSyxDQUFMQSxHQUFhLENBQUNBLEtBQUssQ0FBTixHQUFNLENBQU4sRUFBYkEsS0FBYSxDQUFiQTtBQUVIO0FBUkRnSjtBQVNBO0FBR0Y7O0FBQUEsdUNBQXVEO0FBQ3JELE1BQ0UsNkJBQ0MsNkJBQTZCLENBQUNDLEtBQUssQ0FEcEMsS0FDb0MsQ0FEcEMsSUFFQSxpQkFIRixXQUlFO0FBQ0EsV0FBTzlCLE1BQU0sQ0FBYixLQUFhLENBQWI7QUFMRixTQU1PO0FBQ0w7QUFFSDtBQUVNOztBQUFBLDBDQUVZO0FBQ2pCLFFBQU1ySCxNQUFNLEdBQUcsSUFBZixlQUFlLEVBQWY7QUFDQXpILFFBQU0sQ0FBTkEsMEJBQWlDLENBQUMsTUFBRCxLQUFDLENBQUQsS0FBa0I7QUFDakQsUUFBSTZGLEtBQUssQ0FBTEEsUUFBSixLQUFJQSxDQUFKLEVBQTBCO0FBQ3hCbkcsV0FBSyxDQUFMQSxRQUFlbVIsSUFBRCxJQUFVcEosTUFBTSxDQUFOQSxZQUFtQnFKLHNCQUFzQixDQUFqRXBSLElBQWlFLENBQXpDK0gsQ0FBeEIvSDtBQURGLFdBRU87QUFDTCtILFlBQU0sQ0FBTkEsU0FBZ0JxSixzQkFBc0IsQ0FBdENySixLQUFzQyxDQUF0Q0E7QUFFSDtBQU5Eekg7QUFPQTtBQUdLOztBQUFBLHdCQUVMLEdBRkssa0JBR1k7QUFDakIrUSxrQkFBZ0IsQ0FBaEJBLFFBQTBCSixZQUFELElBQWtCO0FBQ3pDOUssU0FBSyxDQUFMQSxLQUFXOEssWUFBWSxDQUF2QjlLLElBQVc4SyxFQUFYOUssVUFBeUN6RixHQUFELElBQVNYLE1BQU0sQ0FBTkEsT0FBakRvRyxHQUFpRHBHLENBQWpEb0c7QUFDQThLLGdCQUFZLENBQVpBLFFBQXFCLGdCQUFnQmxSLE1BQU0sQ0FBTkEsWUFBckNrUixLQUFxQ2xSLENBQXJDa1I7QUFGRkk7QUFJQTtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEREOztBQUNBOztBQUVBOzs7Ozs7QUFFQTs7QUFBQSxNQUFNQyxrQkFBa0IsR0FBRyx3QkFBM0IsSUFBMkIsQ0FBM0I7O0FBRWUsZ0ZBT2I7QUFDQSxNQUFJLENBQUM1RixLQUFLLENBQUxBLFNBQUwsTUFBS0EsQ0FBTCxFQUE2QjtBQUMzQixTQUFLLE1BQUwscUJBQWdDO0FBQzlCLFlBQU15RSxPQUFPLEdBQUdtQixrQkFBa0IsQ0FBQ0MsT0FBTyxDQUExQyxNQUFrQyxDQUFsQztBQUNBLFlBQU05SixNQUFNLEdBQUcwSSxPQUFPLENBQXRCLE1BQXNCLENBQXRCOztBQUVBLGtCQUFZO0FBQ1YsWUFBSSxDQUFDb0IsT0FBTyxDQUFaLGFBQTBCO0FBQ3hCO0FBQ0E7QUFFRjs7QUFBQSxjQUFNQyxPQUFPLEdBQUcsaUNBQ2RELE9BQU8sQ0FETyxrQ0FLZEEsT0FBTyxDQUFQQSwwQkFMRixRQUFnQixDQUFoQjtBQU9BaEksY0FBTSxHQUFHaUksT0FBTyxDQUFQQSxrQkFBVGpJO0FBQ0FqSixjQUFNLENBQU5BLGNBQXFCa1IsT0FBTyxDQUFQQSxrQkFBckJsUjs7QUFFQSxZQUFJb0wsS0FBSyxDQUFMQSxTQUFlLHFEQUFuQixNQUFtQixDQUFmQSxDQUFKLEVBQXFEO0FBQ25EO0FBQ0E7QUFDQTtBQUdGLFNBckJVLENBcUJWOzs7QUFDQSxjQUFNbEQsWUFBWSxHQUFHSyxXQUFXLENBQWhDLE1BQWdDLENBQWhDOztBQUVBLFlBQUlMLFlBQVksS0FBWkEsVUFBMkJrRCxLQUFLLENBQUxBLFNBQS9CLFlBQStCQSxDQUEvQixFQUE2RDtBQUMzRDtBQUVIO0FBQ0Y7QUFDRjtBQUNEOztBQUFBO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRE0scUNBQXVFO0FBQzVFLFFBQU07QUFBQTtBQUFBO0FBQUEsTUFBTjtBQUNBLFNBQVExSCxRQUFELElBQXlDO0FBQzlDLFVBQU1pSSxVQUFVLEdBQUd3RixFQUFFLENBQUZBLEtBQW5CLFFBQW1CQSxDQUFuQjs7QUFDQSxRQUFJLENBQUosWUFBaUI7QUFDZjtBQUdGOztBQUFBLFVBQU1DLE1BQU0sR0FBSWhLLEtBQUQsSUFBbUI7QUFDaEMsVUFBSTtBQUNGLGVBQU9pSyxrQkFBa0IsQ0FBekIsS0FBeUIsQ0FBekI7QUFDQSxPQUZGLENBRUUsVUFBVTtBQUNWLGNBQU10UCxHQUE4QixHQUFHLFVBQXZDLHdCQUF1QyxDQUF2QztBQUdBQSxXQUFHLENBQUhBO0FBQ0E7QUFFSDtBQVZEOztBQVdBLFVBQU1vRixNQUFrRCxHQUF4RDtBQUVBbkgsVUFBTSxDQUFOQSxxQkFBNkJzUixRQUFELElBQXNCO0FBQ2hELFlBQU1DLENBQUMsR0FBR0MsTUFBTSxDQUFoQixRQUFnQixDQUFoQjtBQUNBLFlBQU1DLENBQUMsR0FBRzlGLFVBQVUsQ0FBQzRGLENBQUMsQ0FBdEIsR0FBb0IsQ0FBcEI7O0FBQ0EsVUFBSUUsQ0FBQyxLQUFMLFdBQXFCO0FBQ25CdEssY0FBTSxDQUFOQSxRQUFNLENBQU5BLEdBQW1CLENBQUNzSyxDQUFDLENBQURBLFFBQUQsR0FBQ0EsQ0FBRCxHQUNmQSxDQUFDLENBQURBLGVBQWtCalEsS0FBRCxJQUFXNFAsTUFBTSxDQURuQixLQUNtQixDQUFsQ0ssQ0FEZSxHQUVmRixDQUFDLENBQURBLFNBQ0EsQ0FBQ0gsTUFBTSxDQURQRyxDQUNPLENBQVAsQ0FEQUEsR0FFQUgsTUFBTSxDQUpWakssQ0FJVSxDQUpWQTtBQU1IO0FBVkRuSDtBQVdBO0FBOUJGO0FBZ0NELEM7Ozs7Ozs7Ozs7Ozs7Ozt1Q0M5QkQ7QUFDQTs7QUFDQSwwQkFBa0M7QUFDaEMsU0FBTzBSLEdBQUcsQ0FBSEEsZ0NBQVAsTUFBT0EsQ0FBUDtBQUdGOztBQUFBLCtCQUF1QztBQUNyQyxRQUFNbkssUUFBUSxHQUFHSCxLQUFLLENBQUxBLG1CQUF5QkEsS0FBSyxDQUFMQSxTQUExQyxHQUEwQ0EsQ0FBMUM7O0FBQ0EsZ0JBQWM7QUFDWkEsU0FBSyxHQUFHQSxLQUFLLENBQUxBLFNBQWUsQ0FBdkJBLENBQVFBLENBQVJBO0FBRUY7O0FBQUEsUUFBTUUsTUFBTSxHQUFHRixLQUFLLENBQUxBLFdBQWYsS0FBZUEsQ0FBZjs7QUFDQSxjQUFZO0FBQ1ZBLFNBQUssR0FBR0EsS0FBSyxDQUFMQSxNQUFSQSxDQUFRQSxDQUFSQTtBQUVGOztBQUFBLFNBQU87QUFBRWhILE9BQUcsRUFBTDtBQUFBO0FBQVA7QUFBTyxHQUFQO0FBR0s7O0FBQUEsd0NBT0w7QUFDQSxRQUFNdVIsUUFBUSxHQUFHLENBQUNDLGVBQWUsQ0FBZkEsc0JBQUQsb0JBQWpCLEdBQWlCLENBQWpCO0FBSUEsUUFBTUosTUFBc0MsR0FBNUM7QUFDQSxNQUFJSyxVQUFVLEdBQWQ7QUFDQSxRQUFNQyxrQkFBa0IsR0FBR0gsUUFBUSxDQUFSQSxJQUNuQnRELE9BQUQsSUFBYTtBQUNoQixRQUFJQSxPQUFPLENBQVBBLG1CQUEyQkEsT0FBTyxDQUFQQSxTQUEvQixHQUErQkEsQ0FBL0IsRUFBc0Q7QUFDcEQsWUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQTRCMEQsY0FBYyxDQUFDMUQsT0FBTyxDQUFQQSxTQUFpQixDQUFsRSxDQUFpREEsQ0FBRCxDQUFoRDtBQUNBbUQsWUFBTSxDQUFOQSxHQUFNLENBQU5BLEdBQWM7QUFBRVEsV0FBRyxFQUFFSCxVQUFQO0FBQUE7QUFBZEw7QUFBYyxPQUFkQTtBQUNBLGFBQU9sSyxNQUFNLEdBQUlDLFFBQVEsbUJBQVosV0FBYjtBQUhGLFdBSU87QUFDTCxhQUFRLElBQUcwSyxXQUFXLFNBQXRCO0FBRUg7QUFUd0JOLFVBQTNCLEVBQTJCQSxDQUEzQixDQVBBLENBbUJBO0FBQ0E7O0FBQ0EsWUFBbUM7QUFDakMsUUFBSU8sZ0JBQWdCLEdBQXBCO0FBQ0EsUUFBSUMsa0JBQWtCLEdBQXRCLEVBRmlDLENBSWpDOztBQUNBLFVBQU1DLGVBQWUsR0FBRyxNQUFNO0FBQzVCLFVBQUlDLFFBQVEsR0FBWjs7QUFFQSxXQUFLLElBQUlDLENBQUMsR0FBVixHQUFnQkEsQ0FBQyxHQUFqQixvQkFBd0NBLENBQXhDLElBQTZDO0FBQzNDRCxnQkFBUSxJQUFJdkQsTUFBTSxDQUFOQSxhQUFadUQsZ0JBQVl2RCxDQUFadUQ7QUFDQUgsd0JBQWdCOztBQUVoQixZQUFJQSxnQkFBZ0IsR0FBcEIsS0FBNEI7QUFDMUJDLDRCQUFrQjtBQUNsQkQsMEJBQWdCLEdBQWhCQTtBQUVIO0FBQ0Q7O0FBQUE7QUFaRjs7QUFlQSxVQUFNSyxTQUFzQyxHQUE1QztBQUVBLFFBQUlDLHVCQUF1QixHQUFHYixRQUFRLENBQVJBLElBQ3RCdEQsT0FBRCxJQUFhO0FBQ2hCLFVBQUlBLE9BQU8sQ0FBUEEsbUJBQTJCQSxPQUFPLENBQVBBLFNBQS9CLEdBQStCQSxDQUEvQixFQUFzRDtBQUNwRCxjQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFBNEIwRCxjQUFjLENBQUMxRCxPQUFPLENBQVBBLFNBQWlCLENBQWxFLENBQWlEQSxDQUFELENBQWhELENBRG9ELENBRXBEO0FBQ0E7O0FBQ0EsWUFBSW9FLFVBQVUsR0FBR3JTLEdBQUcsQ0FBSEEsZUFBakIsRUFBaUJBLENBQWpCO0FBQ0EsWUFBSXNTLFVBQVUsR0FBZCxNQUxvRCxDQU9wRDtBQUNBOztBQUNBLFlBQUlELFVBQVUsQ0FBVkEsZ0JBQTJCQSxVQUFVLENBQVZBLFNBQS9CLElBQXVEO0FBQ3JEQyxvQkFBVSxHQUFWQTtBQUVGOztBQUFBLFlBQUksQ0FBQzlCLEtBQUssQ0FBQytCLFFBQVEsQ0FBQ0YsVUFBVSxDQUFWQSxVQUFwQixDQUFvQkEsQ0FBRCxDQUFULENBQVYsRUFBK0M7QUFDN0NDLG9CQUFVLEdBQVZBO0FBR0Y7O0FBQUEsd0JBQWdCO0FBQ2RELG9CQUFVLEdBQUdMLGVBQWJLO0FBR0ZGOztBQUFBQSxpQkFBUyxDQUFUQSxVQUFTLENBQVRBO0FBQ0EsZUFBT2pMLE1BQU0sR0FDVEMsUUFBUSxHQUNMLFVBQVNrTCxVQURKLFlBRUwsT0FBTUEsVUFIQSxVQUlSLE9BQU1BLFVBSlg7QUFyQkYsYUEwQk87QUFDTCxlQUFRLElBQUdSLFdBQVcsU0FBdEI7QUFFSDtBQS9CMkJOLFlBQTlCLEVBQThCQSxDQUE5QjtBQWtDQSxXQUFPO0FBQ0xSLFFBQUUsRUFBRSxXQUFZLElBQUdXLGtCQURkLFNBQ0QsQ0FEQztBQUFBO0FBQUE7QUFJTGMsZ0JBQVUsRUFBRyxJQUFHSix1QkFKbEI7QUFBTyxLQUFQO0FBUUY7O0FBQUEsU0FBTztBQUNMckIsTUFBRSxFQUFFLFdBQVksSUFBR1csa0JBRGQsU0FDRCxDQURDO0FBQVA7QUFBTyxHQUFQO0FBSUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEhEO0FBeVFBOzs7OztBQUdPLHNCQUVGO0FBQ0gsTUFBSWUsSUFBSSxHQUFSO0FBQ0E7QUFFQSxTQUFRLENBQUMsR0FBRCxTQUFvQjtBQUMxQixRQUFJLENBQUosTUFBVztBQUNUQSxVQUFJLEdBQUpBO0FBQ0FwTCxZQUFNLEdBQUdtRyxFQUFFLENBQUMsR0FBWm5HLElBQVcsQ0FBWEE7QUFFRjs7QUFBQTtBQUxGO0FBU0s7O0FBQUEsNkJBQTZCO0FBQ2xDLFFBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUErQnJHLE1BQU0sQ0FBM0M7QUFDQSxTQUFRLEdBQUVxTixRQUFTLEtBQUlJLFFBQVMsR0FBRWlFLElBQUksR0FBRyxNQUFILE9BQWdCLEVBQXREO0FBR0s7O0FBQUEsa0JBQWtCO0FBQ3ZCLFFBQU07QUFBQTtBQUFBLE1BQVcxUixNQUFNLENBQXZCO0FBQ0EsUUFBTWdPLE1BQU0sR0FBRzJELGlCQUFmO0FBQ0EsU0FBTy9RLElBQUksQ0FBSkEsVUFBZW9OLE1BQU0sQ0FBNUIsTUFBT3BOLENBQVA7QUFHSzs7QUFBQSxtQ0FBd0Q7QUFDN0QsU0FBTyw0Q0FFSHVJLFNBQVMsQ0FBVEEsZUFBeUJBLFNBQVMsQ0FBbENBLFFBRko7QUFLSzs7QUFBQSx3QkFBd0M7QUFDN0MsU0FBTzdCLEdBQUcsQ0FBSEEsWUFBZ0JBLEdBQUcsQ0FBMUI7QUFHSzs7QUFBQSw2Q0FJa0Q7QUFDdkQsWUFBMkM7QUFBQTs7QUFDekMsMEJBQUlzSyxHQUFHLENBQVAsOEJBQUlBLGVBQUosaUJBQW9DO0FBQ2xDLFlBQU16TixPQUFPLEdBQUksSUFBRzBOLGNBQWMsS0FBbEM7QUFHQSxZQUFNLFVBQU4sT0FBTSxDQUFOO0FBRUg7QUFDRCxHQVR1RCxDQVN2RDs7O0FBQ0EsUUFBTXZLLEdBQUcsR0FBR3dGLEdBQUcsQ0FBSEEsT0FBWUEsR0FBRyxDQUFIQSxPQUFXQSxHQUFHLENBQUhBLElBQW5DOztBQUVBLE1BQUksQ0FBQzhFLEdBQUcsQ0FBUixpQkFBMEI7QUFDeEIsUUFBSTlFLEdBQUcsQ0FBSEEsT0FBV0EsR0FBRyxDQUFsQixXQUE4QjtBQUM1QjtBQUNBLGFBQU87QUFDTGdGLGlCQUFTLEVBQUUsTUFBTUMsbUJBQW1CLENBQUNqRixHQUFHLENBQUosV0FBZ0JBLEdBQUcsQ0FEekQsR0FDc0M7QUFEL0IsT0FBUDtBQUlGOztBQUFBO0FBR0Y7O0FBQUEsUUFBTW5MLEtBQUssR0FBRyxNQUFNaVEsR0FBRyxDQUFIQSxnQkFBcEIsR0FBb0JBLENBQXBCOztBQUVBLE1BQUl0SyxHQUFHLElBQUkwSyxTQUFTLENBQXBCLEdBQW9CLENBQXBCLEVBQTJCO0FBQ3pCO0FBR0Y7O0FBQUEsTUFBSSxDQUFKLE9BQVk7QUFDVixVQUFNN04sT0FBTyxHQUFJLElBQUcwTixjQUFjLEtBRWhDLCtEQUE4RGxRLEtBRmhFO0FBR0EsVUFBTSxVQUFOLE9BQU0sQ0FBTjtBQUdGOztBQUFBLFlBQTJDO0FBQ3pDLFFBQUkvQyxNQUFNLENBQU5BLDRCQUFtQyxDQUFDa08sR0FBRyxDQUEzQyxLQUFpRDtBQUMvQ3JNLGFBQU8sQ0FBUEEsS0FDRyxHQUFFb1IsY0FBYyxLQURuQnBSO0FBTUg7QUFFRDs7QUFBQTtBQUdLOztBQUFBLE1BQU13UixhQUFhLEdBQUcsd0dBQXRCLFNBQXNCLENBQXRCOzs7QUFlQSxtQ0FBc0Q7QUFDM0QsWUFBNEM7QUFDMUMsUUFBSTNNLEdBQUcsS0FBSEEsUUFBZ0IsZUFBcEIsVUFBNkM7QUFDM0MxRyxZQUFNLENBQU5BLGtCQUEwQkksR0FBRCxJQUFTO0FBQ2hDLFlBQUlpVCxhQUFhLENBQWJBLGlCQUErQixDQUFuQyxHQUF1QztBQUNyQ3hSLGlCQUFPLENBQVBBLEtBQ0cscURBQW9EekIsR0FEdkR5QjtBQUlIO0FBTkQ3QjtBQVFIO0FBRUQ7O0FBQUEsU0FBTywwQkFBUCxHQUFPLENBQVA7QUFHSzs7QUFBQSxNQUFNc1QsRUFBRSxHQUFHLHVCQUFYOztBQUNBLE1BQU14SSxFQUFFLEdBQ2J3SSxFQUFFLElBQ0YsT0FBT3ZJLFdBQVcsQ0FBbEIsU0FEQXVJLGNBRUEsT0FBT3ZJLFdBQVcsQ0FBbEIsWUFISzs7Ozs7Ozs7Ozs7OztBQ3hZTSx3QkFBd0IsMENBQTBDLGdEQUFnRCxnQ0FBZ0MsZ0NBQWdDLG1DQUFtQyw0QkFBNEIsK0JBQStCLG9CQUFvQix5QkFBeUIsVUFBVTtBQUNwVixpRDs7Ozs7Ozs7Ozs7QUNEQSxpQkFBaUIsbUJBQU8sQ0FBQyxtRUFBb0I7Ozs7Ozs7Ozs7OztBQ0E3QztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHdDOzs7Ozs7Ozs7OztBQ05BLGNBQWMsbUJBQU8sQ0FBQyw0RkFBbUI7O0FBRXpDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBLHlDOzs7Ozs7Ozs7OztBQ3REQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEseUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEJBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLE1BQU13SSxLQUFLLEdBQUdyVSxzREFBTSxDQUFDc1UsRUFBRztBQUN4QjtBQUNBLENBRkE7QUFHQSxNQUFNQyxhQUFhLEdBQUd2VSxzREFBTSxDQUFDd1UsR0FBSTtBQUNqQztBQUNBO0FBQ0E7QUFDQSxDQUpBO0FBS0EsTUFBTUMsZUFBZSxHQUFHelUsc0RBQU0sQ0FBQ3dVLEdBQUk7QUFDbkM7QUFDQTtBQUNBO0FBQ0EsQ0FKQTs7QUFNQSxNQUFNRSxJQUFJLEdBQUcsTUFBTTtBQUNqQixTQUNFLE1BQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyw2REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREYsRUFFRSxNQUFDLEtBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFGRixFQUdFLE1BQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMsaUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBRUUsTUFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRkYsQ0FERixFQUtFLE1BQUMsK0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUxGLENBSEYsQ0FERjtBQWFELENBZEQ7O0FBZ0JlQSxtRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZDQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU1oVCxXQUFXLEdBQUdpVCxpREFBUyxDQUFDQyxLQUFWLENBQWdCO0FBQ2xDdFQsSUFBRSxFQUFFcVQsaURBQVMsQ0FBQ0UsTUFBVixDQUFpQkMsVUFEYTtBQUVsQ2xVLE1BQUksRUFBRStULGlEQUFTLENBQUNDLEtBQVYsQ0FBZ0I7QUFDcEIvVCxXQUFPLEVBQUU4VCxpREFBUyxDQUFDSSxNQUFWLENBQWlCRCxVQUROO0FBRXBCRSxZQUFRLEVBQUVMLGlEQUFTLENBQUNJLE1BQVYsQ0FBaUJELFVBRlA7QUFHcEJHLFdBQU8sRUFBRU4saURBQVMsQ0FBQ0ksTUFBVixDQUFpQkQsVUFITjtBQUlwQkksVUFBTSxFQUFFUCxpREFBUyxDQUFDSSxNQUFWLENBQWlCRDtBQUpMLEdBQWhCLENBRjRCO0FBUWxDdlQsTUFBSSxFQUFFb1QsaURBQVMsQ0FBQ1EsT0FBVixDQUFrQlIsaURBQVMsQ0FBQ0ksTUFBVixDQUFpQkQsVUFBbkMsQ0FSNEI7QUFTbEM5VCxNQUFJLEVBQUUyVCxpREFBUyxDQUFDQyxLQUFWLENBQWdCO0FBQ3BCUSxNQUFFLEVBQUVULGlEQUFTLENBQUNFLE1BQVYsQ0FBaUJDLFVBREQ7QUFFcEJPLFVBQU0sRUFBRVYsaURBQVMsQ0FBQ0UsTUFBVixDQUFpQkMsVUFGTDtBQUdwQlEsV0FBTyxFQUFFWCxpREFBUyxDQUFDRSxNQUFWLENBQWlCQyxVQUhOO0FBSXBCLGtCQUFjSCxpREFBUyxDQUFDRSxNQUFWLENBQWlCQyxVQUpYO0FBS3BCLG1CQUFlSCxpREFBUyxDQUFDRSxNQUFWLENBQWlCQyxVQUxaO0FBTXBCUyxTQUFLLEVBQUVaLGlEQUFTLENBQUNFLE1BQVYsQ0FBaUJDO0FBTkosR0FBaEI7QUFUNEIsQ0FBaEIsQ0FBcEI7QUFtQmVwVCwwRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3JCQTs7QUFFQSxNQUFNOFQsS0FBTixDQUFZO0FBS1YzTCxhQUFXLEdBQUc7QUFBQSxxQ0FKSnlELG1CQUFPLENBQUMsK0NBQUQsQ0FJSDs7QUFBQSxvQ0FITCxFQUdLOztBQUFBLDZDQUZJLElBRUo7O0FBQ1ptSSxtRUFBa0IsQ0FBQyxJQUFELENBQWxCO0FBQ0Q7O0FBRURuVixXQUFTLENBQUNGLE1BQUQsRUFBUztBQUNoQixTQUFLQSxNQUFMLEdBQWNBLE1BQWQ7QUFDRDs7QUFDRDJCLG9CQUFrQixDQUFDcEIsZUFBRCxFQUFrQjtBQUNsQyxTQUFLQSxlQUFMLEdBQXVCQSxlQUF2QjtBQUNEOztBQWRTOztBQWlCWixNQUFNUixLQUFLLEdBQUcsSUFBSXFWLEtBQUosRUFBZDtBQUVlclYsb0VBQWYsRTs7Ozs7Ozs7Ozs7QUNyQkEsNEM7Ozs7Ozs7Ozs7O0FDQUEsOEM7Ozs7Ozs7Ozs7O0FDQUEsaUM7Ozs7Ozs7Ozs7O0FDQUEsdUM7Ozs7Ozs7Ozs7O0FDQUEsdUM7Ozs7Ozs7Ozs7O0FDQUEsa0M7Ozs7Ozs7Ozs7O0FDQUEscUMiLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3BhZ2VzL2luZGV4LmpzXCIpO1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9yb3V0ZXItY29udGV4dC5qc1wiKTsiLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcbmltcG9ydCB7IG9ic2VydmVyIH0gZnJvbSBcIm1vYngtcmVhY3RcIjtcblxuaW1wb3J0IHN0b3JlIGZyb20gXCIuLi9zcmMvc3RvcmVcIjtcblxuY29uc3QgSW5wdXQgPSBzdHlsZWQuaW5wdXRgXG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nOiAwLjJyZW07XG4gIGZvbnQtc2l6ZTogbGFyZ2U7XG5gO1xuXG5jb25zdCBQb2tlbW9uRmlsdGVyID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxJbnB1dFxuICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgdmFsdWU9e3N0b3JlLmZpbHRlcn1cbiAgICAgIG9uQ2hhbmdlPXsoZXZ0KSA9PiBzdG9yZS5zZXRGaWx0ZXIoZXZ0LnRhcmdldC52YWx1ZSl9XG4gICAgLz5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IG9ic2VydmVyKFBva2Vtb25GaWx0ZXIpO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgb2JzZXJ2ZXIgfSBmcm9tIFwibW9ieC1yZWFjdFwiO1xuXG5pbXBvcnQgc3RvcmUgZnJvbSBcIi4uL3NyYy9zdG9yZVwiO1xuXG5jb25zdCBQb2tlbW9uSW5mbyA9ICgpID0+IHtcbiAgcmV0dXJuIHN0b3JlLnNlbGVjdGVkUG9rZW1vbiA/IChcbiAgICA8ZGl2PlxuICAgICAgPGgyPntzdG9yZS5zZWxlY3RlZFBva2Vtb24ubmFtZS5lbmdsaXNofTwvaDI+XG4gICAgICA8dGFibGU+XG4gICAgICAgIDx0Ym9keT5cbiAgICAgICAgICB7T2JqZWN0LmtleXMoc3RvcmUuc2VsZWN0ZWRQb2tlbW9uLmJhc2UpLm1hcCgoa2V5KSA9PiAoXG4gICAgICAgICAgICA8dHIga2V5PXtrZXl9PlxuICAgICAgICAgICAgICA8dGQ+e2tleX08L3RkPlxuICAgICAgICAgICAgICA8dGQ+e3N0b3JlLnNlbGVjdGVkUG9rZW1vbi5iYXNlW2tleV19PC90ZD5cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvdGJvZHk+XG4gICAgICA8L3RhYmxlPlxuICAgIDwvZGl2PlxuICApIDogbnVsbDtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IG9ic2VydmVyKFBva2Vtb25JbmZvKTtcbiIsImltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSBcInByb3AtdHlwZXNcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xuXG5pbXBvcnQgUG9rZW1vblR5cGUgZnJvbSBcIi4uL3NyYy9wb2tlbW9uVHlwZVwiO1xuXG5jb25zdCBQb2tlbW9uUm93ID0gKHsgcG9rZW1vbiwgb25DbGljayB9KSA9PiAoXG4gIDw+XG4gICAgPHRyIGtleT17cG9rZW1vbi5pZH0+XG4gICAgICA8dGQ+XG4gICAgICAgIDxMaW5rIGhyZWY9e2AvcG9rZW1vbi8ke3Bva2Vtb24uaWR9YH0+XG4gICAgICAgICAgPGE+e3Bva2Vtb24ubmFtZS5lbmdsaXNofTwvYT5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgPC90ZD5cbiAgICAgIDx0ZD57cG9rZW1vbi50eXBlLmpvaW4oXCIsIFwiKX08L3RkPlxuICAgICAgPHRkPlxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXG4gICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNsaWNrKHBva2Vtb24pfVxuICAgICAgICA+XG4gICAgICAgICAgTW9yZSBJbmZvcm1hdGlvblxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvdGQ+XG4gICAgPC90cj5cbiAgPC8+XG4pO1xuXG5Qb2tlbW9uUm93LnByb3BUeXBlcyA9IHtcbiAgcG9rZW1vbjogUG9rZW1vblR5cGUsXG59O1xuXG5leHBvcnQgZGVmYXVsdCBQb2tlbW9uUm93O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgb2JzZXJ2ZXIgfSBmcm9tIFwibW9ieC1yZWFjdFwiO1xuXG5pbXBvcnQgUG9rZW1vblJvdyBmcm9tIFwiLi9Qb2tlbW9uUm93XCI7XG5pbXBvcnQgc3RvcmUgZnJvbSBcIi4uL3NyYy9zdG9yZVwiO1xuXG5mdW5jdGlvbiBQb2tlbW9uVGFibGUoKSB7XG4gIHJldHVybiAoXG4gICAgPHRhYmxlIHdpZHRoPVwiMTAwJVwiPlxuICAgICAgPHRib2R5PlxuICAgICAgICB7c3RvcmUucG9rZW1vblxuICAgICAgICAgIC5maWx0ZXIoKHsgbmFtZTogeyBlbmdsaXNoIH0gfSkgPT5cbiAgICAgICAgICAgIGVuZ2xpc2hcbiAgICAgICAgICAgICAgLnRvTG9jYWxlTG93ZXJDYXNlKClcbiAgICAgICAgICAgICAgLmluY2x1ZGVzKHN0b3JlLmZpbHRlci50b0xvY2FsZUxvd2VyQ2FzZSgpKVxuICAgICAgICAgIClcbiAgICAgICAgICAuc2xpY2UoMCwgMjApXG4gICAgICAgICAgLm1hcCgocG9rZW1vbikgPT4gKFxuICAgICAgICAgICAgPFBva2Vtb25Sb3dcbiAgICAgICAgICAgICAga2V5PXtwb2tlbW9uLmlkfVxuICAgICAgICAgICAgICBwb2tlbW9uPXtwb2tlbW9ufVxuICAgICAgICAgICAgICBvbkNsaWNrPXsocG9rZW1vbikgPT4gc3RvcmUuc2V0U2VsZWN0ZWRQb2tlbW9uKHBva2Vtb24pfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgIDwvdGJvZHk+XG4gICAgPC90YWJsZT5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgb2JzZXJ2ZXIoUG9rZW1vblRhYmxlKTtcbiIsImltcG9ydCBSZWFjdCwgeyBDaGlsZHJlbiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgVXJsT2JqZWN0IH0gZnJvbSAndXJsJ1xuaW1wb3J0IHtcbiAgYWRkQmFzZVBhdGgsXG4gIGFkZExvY2FsZSxcbiAgaXNMb2NhbFVSTCxcbiAgTmV4dFJvdXRlcixcbiAgUHJlZmV0Y2hPcHRpb25zLFxuICByZXNvbHZlSHJlZixcbn0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci9yb3V0ZXInXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICcuL3JvdXRlcidcblxudHlwZSBVcmwgPSBzdHJpbmcgfCBVcmxPYmplY3RcbnR5cGUgUmVxdWlyZWRLZXlzPFQ+ID0ge1xuICBbSyBpbiBrZXlvZiBUXS0/OiB7fSBleHRlbmRzIFBpY2s8VCwgSz4gPyBuZXZlciA6IEtcbn1ba2V5b2YgVF1cbnR5cGUgT3B0aW9uYWxLZXlzPFQ+ID0ge1xuICBbSyBpbiBrZXlvZiBUXS0/OiB7fSBleHRlbmRzIFBpY2s8VCwgSz4gPyBLIDogbmV2ZXJcbn1ba2V5b2YgVF1cblxuZXhwb3J0IHR5cGUgTGlua1Byb3BzID0ge1xuICBocmVmOiBVcmxcbiAgYXM/OiBVcmxcbiAgcmVwbGFjZT86IGJvb2xlYW5cbiAgc2Nyb2xsPzogYm9vbGVhblxuICBzaGFsbG93PzogYm9vbGVhblxuICBwYXNzSHJlZj86IGJvb2xlYW5cbiAgcHJlZmV0Y2g/OiBib29sZWFuXG59XG50eXBlIExpbmtQcm9wc1JlcXVpcmVkID0gUmVxdWlyZWRLZXlzPExpbmtQcm9wcz5cbnR5cGUgTGlua1Byb3BzT3B0aW9uYWwgPSBPcHRpb25hbEtleXM8TGlua1Byb3BzPlxuXG5sZXQgY2FjaGVkT2JzZXJ2ZXI6IEludGVyc2VjdGlvbk9ic2VydmVyXG5jb25zdCBsaXN0ZW5lcnMgPSBuZXcgTWFwPEVsZW1lbnQsICgpID0+IHZvaWQ+KClcbmNvbnN0IEludGVyc2VjdGlvbk9ic2VydmVyID1cbiAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cuSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgOiBudWxsXG5jb25zdCBwcmVmZXRjaGVkOiB7IFtjYWNoZUtleTogc3RyaW5nXTogYm9vbGVhbiB9ID0ge31cblxuZnVuY3Rpb24gZ2V0T2JzZXJ2ZXIoKTogSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgfCB1bmRlZmluZWQge1xuICAvLyBSZXR1cm4gc2hhcmVkIGluc3RhbmNlIG9mIEludGVyc2VjdGlvbk9ic2VydmVyIGlmIGFscmVhZHkgY3JlYXRlZFxuICBpZiAoY2FjaGVkT2JzZXJ2ZXIpIHtcbiAgICByZXR1cm4gY2FjaGVkT2JzZXJ2ZXJcbiAgfVxuXG4gIC8vIE9ubHkgY3JlYXRlIHNoYXJlZCBJbnRlcnNlY3Rpb25PYnNlcnZlciBpZiBzdXBwb3J0ZWQgaW4gYnJvd3NlclxuICBpZiAoIUludGVyc2VjdGlvbk9ic2VydmVyKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZFxuICB9XG5cbiAgcmV0dXJuIChjYWNoZWRPYnNlcnZlciA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihcbiAgICAoZW50cmllcykgPT4ge1xuICAgICAgZW50cmllcy5mb3JFYWNoKChlbnRyeSkgPT4ge1xuICAgICAgICBpZiAoIWxpc3RlbmVycy5oYXMoZW50cnkudGFyZ2V0KSkge1xuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgY2IgPSBsaXN0ZW5lcnMuZ2V0KGVudHJ5LnRhcmdldCkhXG4gICAgICAgIGlmIChlbnRyeS5pc0ludGVyc2VjdGluZyB8fCBlbnRyeS5pbnRlcnNlY3Rpb25SYXRpbyA+IDApIHtcbiAgICAgICAgICBjYWNoZWRPYnNlcnZlci51bm9ic2VydmUoZW50cnkudGFyZ2V0KVxuICAgICAgICAgIGxpc3RlbmVycy5kZWxldGUoZW50cnkudGFyZ2V0KVxuICAgICAgICAgIGNiKClcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9LFxuICAgIHsgcm9vdE1hcmdpbjogJzIwMHB4JyB9XG4gICkpXG59XG5cbmNvbnN0IGxpc3RlblRvSW50ZXJzZWN0aW9ucyA9IChlbDogRWxlbWVudCwgY2I6ICgpID0+IHZvaWQpID0+IHtcbiAgY29uc3Qgb2JzZXJ2ZXIgPSBnZXRPYnNlcnZlcigpXG4gIGlmICghb2JzZXJ2ZXIpIHtcbiAgICByZXR1cm4gKCkgPT4ge31cbiAgfVxuXG4gIG9ic2VydmVyLm9ic2VydmUoZWwpXG4gIGxpc3RlbmVycy5zZXQoZWwsIGNiKVxuICByZXR1cm4gKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBvYnNlcnZlci51bm9ic2VydmUoZWwpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycilcbiAgICB9XG4gICAgbGlzdGVuZXJzLmRlbGV0ZShlbClcbiAgfVxufVxuXG5mdW5jdGlvbiBwcmVmZXRjaChcbiAgcm91dGVyOiBOZXh0Um91dGVyLFxuICBocmVmOiBzdHJpbmcsXG4gIGFzOiBzdHJpbmcsXG4gIG9wdGlvbnM/OiBQcmVmZXRjaE9wdGlvbnNcbik6IHZvaWQge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHJldHVyblxuICBpZiAoIWlzTG9jYWxVUkwoaHJlZikpIHJldHVyblxuICAvLyBQcmVmZXRjaCB0aGUgSlNPTiBwYWdlIGlmIGFza2VkIChvbmx5IGluIHRoZSBjbGllbnQpXG4gIC8vIFdlIG5lZWQgdG8gaGFuZGxlIGEgcHJlZmV0Y2ggZXJyb3IgaGVyZSBzaW5jZSB3ZSBtYXkgYmVcbiAgLy8gbG9hZGluZyB3aXRoIHByaW9yaXR5IHdoaWNoIGNhbiByZWplY3QgYnV0IHdlIGRvbid0XG4gIC8vIHdhbnQgdG8gZm9yY2UgbmF2aWdhdGlvbiBzaW5jZSB0aGlzIGlzIG9ubHkgYSBwcmVmZXRjaFxuICByb3V0ZXIucHJlZmV0Y2goaHJlZiwgYXMsIG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgLy8gcmV0aHJvdyB0byBzaG93IGludmFsaWQgVVJMIGVycm9yc1xuICAgICAgdGhyb3cgZXJyXG4gICAgfVxuICB9KVxuICAvLyBKb2luIG9uIGFuIGludmFsaWQgVVJJIGNoYXJhY3RlclxuICBwcmVmZXRjaGVkW2hyZWYgKyAnJScgKyBhc10gPSB0cnVlXG59XG5cbmZ1bmN0aW9uIGlzTW9kaWZpZWRFdmVudChldmVudDogUmVhY3QuTW91c2VFdmVudCkge1xuICBjb25zdCB7IHRhcmdldCB9ID0gZXZlbnQuY3VycmVudFRhcmdldCBhcyBIVE1MQW5jaG9yRWxlbWVudFxuICByZXR1cm4gKFxuICAgICh0YXJnZXQgJiYgdGFyZ2V0ICE9PSAnX3NlbGYnKSB8fFxuICAgIGV2ZW50Lm1ldGFLZXkgfHxcbiAgICBldmVudC5jdHJsS2V5IHx8XG4gICAgZXZlbnQuc2hpZnRLZXkgfHxcbiAgICBldmVudC5hbHRLZXkgfHwgLy8gdHJpZ2dlcnMgcmVzb3VyY2UgZG93bmxvYWRcbiAgICAoZXZlbnQubmF0aXZlRXZlbnQgJiYgZXZlbnQubmF0aXZlRXZlbnQud2hpY2ggPT09IDIpXG4gIClcbn1cblxuZnVuY3Rpb24gbGlua0NsaWNrZWQoXG4gIGU6IFJlYWN0Lk1vdXNlRXZlbnQsXG4gIHJvdXRlcjogTmV4dFJvdXRlcixcbiAgaHJlZjogc3RyaW5nLFxuICBhczogc3RyaW5nLFxuICByZXBsYWNlPzogYm9vbGVhbixcbiAgc2hhbGxvdz86IGJvb2xlYW4sXG4gIHNjcm9sbD86IGJvb2xlYW5cbik6IHZvaWQge1xuICBjb25zdCB7IG5vZGVOYW1lIH0gPSBlLmN1cnJlbnRUYXJnZXRcblxuICBpZiAobm9kZU5hbWUgPT09ICdBJyAmJiAoaXNNb2RpZmllZEV2ZW50KGUpIHx8ICFpc0xvY2FsVVJMKGhyZWYpKSkge1xuICAgIC8vIGlnbm9yZSBjbGljayBmb3IgYnJvd3NlcuKAmXMgZGVmYXVsdCBiZWhhdmlvclxuICAgIHJldHVyblxuICB9XG5cbiAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgLy8gIGF2b2lkIHNjcm9sbCBmb3IgdXJscyB3aXRoIGFuY2hvciByZWZzXG4gIGlmIChzY3JvbGwgPT0gbnVsbCkge1xuICAgIHNjcm9sbCA9IGFzLmluZGV4T2YoJyMnKSA8IDBcbiAgfVxuXG4gIC8vIHJlcGxhY2Ugc3RhdGUgaW5zdGVhZCBvZiBwdXNoIGlmIHByb3AgaXMgcHJlc2VudFxuICByb3V0ZXJbcmVwbGFjZSA/ICdyZXBsYWNlJyA6ICdwdXNoJ10oaHJlZiwgYXMsIHsgc2hhbGxvdyB9KS50aGVuKFxuICAgIChzdWNjZXNzOiBib29sZWFuKSA9PiB7XG4gICAgICBpZiAoIXN1Y2Nlc3MpIHJldHVyblxuICAgICAgaWYgKHNjcm9sbCkge1xuICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMClcbiAgICAgICAgZG9jdW1lbnQuYm9keS5mb2N1cygpXG4gICAgICB9XG4gICAgfVxuICApXG59XG5cbmZ1bmN0aW9uIExpbmsocHJvcHM6IFJlYWN0LlByb3BzV2l0aENoaWxkcmVuPExpbmtQcm9wcz4pIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBmdW5jdGlvbiBjcmVhdGVQcm9wRXJyb3IoYXJnczoge1xuICAgICAga2V5OiBzdHJpbmdcbiAgICAgIGV4cGVjdGVkOiBzdHJpbmdcbiAgICAgIGFjdHVhbDogc3RyaW5nXG4gICAgfSkge1xuICAgICAgcmV0dXJuIG5ldyBFcnJvcihcbiAgICAgICAgYEZhaWxlZCBwcm9wIHR5cGU6IFRoZSBwcm9wIFxcYCR7YXJncy5rZXl9XFxgIGV4cGVjdHMgYSAke2FyZ3MuZXhwZWN0ZWR9IGluIFxcYDxMaW5rPlxcYCwgYnV0IGdvdCBcXGAke2FyZ3MuYWN0dWFsfVxcYCBpbnN0ZWFkLmAgK1xuICAgICAgICAgICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgICAgICAgICAgPyBcIlxcbk9wZW4geW91ciBicm93c2VyJ3MgY29uc29sZSB0byB2aWV3IHRoZSBDb21wb25lbnQgc3RhY2sgdHJhY2UuXCJcbiAgICAgICAgICAgIDogJycpXG4gICAgICApXG4gICAgfVxuXG4gICAgLy8gVHlwZVNjcmlwdCB0cmljayBmb3IgdHlwZS1ndWFyZGluZzpcbiAgICBjb25zdCByZXF1aXJlZFByb3BzR3VhcmQ6IFJlY29yZDxMaW5rUHJvcHNSZXF1aXJlZCwgdHJ1ZT4gPSB7XG4gICAgICBocmVmOiB0cnVlLFxuICAgIH0gYXMgY29uc3RcbiAgICBjb25zdCByZXF1aXJlZFByb3BzOiBMaW5rUHJvcHNSZXF1aXJlZFtdID0gT2JqZWN0LmtleXMoXG4gICAgICByZXF1aXJlZFByb3BzR3VhcmRcbiAgICApIGFzIExpbmtQcm9wc1JlcXVpcmVkW11cbiAgICByZXF1aXJlZFByb3BzLmZvckVhY2goKGtleTogTGlua1Byb3BzUmVxdWlyZWQpID0+IHtcbiAgICAgIGlmIChrZXkgPT09ICdocmVmJykge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgcHJvcHNba2V5XSA9PSBudWxsIHx8XG4gICAgICAgICAgKHR5cGVvZiBwcm9wc1trZXldICE9PSAnc3RyaW5nJyAmJiB0eXBlb2YgcHJvcHNba2V5XSAhPT0gJ29iamVjdCcpXG4gICAgICAgICkge1xuICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICBrZXksXG4gICAgICAgICAgICBleHBlY3RlZDogJ2BzdHJpbmdgIG9yIGBvYmplY3RgJyxcbiAgICAgICAgICAgIGFjdHVhbDogcHJvcHNba2V5XSA9PT0gbnVsbCA/ICdudWxsJyA6IHR5cGVvZiBwcm9wc1trZXldLFxuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICAgICAgY29uc3QgXzogbmV2ZXIgPSBrZXlcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gVHlwZVNjcmlwdCB0cmljayBmb3IgdHlwZS1ndWFyZGluZzpcbiAgICBjb25zdCBvcHRpb25hbFByb3BzR3VhcmQ6IFJlY29yZDxMaW5rUHJvcHNPcHRpb25hbCwgdHJ1ZT4gPSB7XG4gICAgICBhczogdHJ1ZSxcbiAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICBzY3JvbGw6IHRydWUsXG4gICAgICBzaGFsbG93OiB0cnVlLFxuICAgICAgcGFzc0hyZWY6IHRydWUsXG4gICAgICBwcmVmZXRjaDogdHJ1ZSxcbiAgICB9IGFzIGNvbnN0XG4gICAgY29uc3Qgb3B0aW9uYWxQcm9wczogTGlua1Byb3BzT3B0aW9uYWxbXSA9IE9iamVjdC5rZXlzKFxuICAgICAgb3B0aW9uYWxQcm9wc0d1YXJkXG4gICAgKSBhcyBMaW5rUHJvcHNPcHRpb25hbFtdXG4gICAgb3B0aW9uYWxQcm9wcy5mb3JFYWNoKChrZXk6IExpbmtQcm9wc09wdGlvbmFsKSA9PiB7XG4gICAgICBpZiAoa2V5ID09PSAnYXMnKSB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICBwcm9wc1trZXldICYmXG4gICAgICAgICAgdHlwZW9mIHByb3BzW2tleV0gIT09ICdzdHJpbmcnICYmXG4gICAgICAgICAgdHlwZW9mIHByb3BzW2tleV0gIT09ICdvYmplY3QnXG4gICAgICAgICkge1xuICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICBrZXksXG4gICAgICAgICAgICBleHBlY3RlZDogJ2BzdHJpbmdgIG9yIGBvYmplY3RgJyxcbiAgICAgICAgICAgIGFjdHVhbDogdHlwZW9mIHByb3BzW2tleV0sXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAga2V5ID09PSAncmVwbGFjZScgfHxcbiAgICAgICAga2V5ID09PSAnc2Nyb2xsJyB8fFxuICAgICAgICBrZXkgPT09ICdzaGFsbG93JyB8fFxuICAgICAgICBrZXkgPT09ICdwYXNzSHJlZicgfHxcbiAgICAgICAga2V5ID09PSAncHJlZmV0Y2gnXG4gICAgICApIHtcbiAgICAgICAgaWYgKHByb3BzW2tleV0gIT0gbnVsbCAmJiB0eXBlb2YgcHJvcHNba2V5XSAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgdGhyb3cgY3JlYXRlUHJvcEVycm9yKHtcbiAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgIGV4cGVjdGVkOiAnYGJvb2xlYW5gJyxcbiAgICAgICAgICAgIGFjdHVhbDogdHlwZW9mIHByb3BzW2tleV0sXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gVHlwZVNjcmlwdCB0cmljayBmb3IgdHlwZS1ndWFyZGluZzpcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgICAgICBjb25zdCBfOiBuZXZlciA9IGtleVxuICAgICAgfVxuICAgIH0pXG5cbiAgICAvLyBUaGlzIGhvb2sgaXMgaW4gYSBjb25kaXRpb25hbCBidXQgdGhhdCBpcyBvayBiZWNhdXNlIGBwcm9jZXNzLmVudi5OT0RFX0VOVmAgbmV2ZXIgY2hhbmdlc1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9ydWxlcy1vZi1ob29rc1xuICAgIGNvbnN0IGhhc1dhcm5lZCA9IFJlYWN0LnVzZVJlZihmYWxzZSlcbiAgICBpZiAocHJvcHMucHJlZmV0Y2ggJiYgIWhhc1dhcm5lZC5jdXJyZW50KSB7XG4gICAgICBoYXNXYXJuZWQuY3VycmVudCA9IHRydWVcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgJ05leHQuanMgYXV0by1wcmVmZXRjaGVzIGF1dG9tYXRpY2FsbHkgYmFzZWQgb24gdmlld3BvcnQuIFRoZSBwcmVmZXRjaCBhdHRyaWJ1dGUgaXMgbm8gbG9uZ2VyIG5lZWRlZC4gTW9yZTogaHR0cHM6Ly9lcnIuc2gvdmVyY2VsL25leHQuanMvcHJlZmV0Y2gtdHJ1ZS1kZXByZWNhdGVkJ1xuICAgICAgKVxuICAgIH1cbiAgfVxuICBjb25zdCBwID0gcHJvcHMucHJlZmV0Y2ggIT09IGZhbHNlXG5cbiAgY29uc3QgW2NoaWxkRWxtLCBzZXRDaGlsZEVsbV0gPSBSZWFjdC51c2VTdGF0ZTxFbGVtZW50PigpXG5cbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgY29uc3QgcGF0aG5hbWUgPSAocm91dGVyICYmIHJvdXRlci5wYXRobmFtZSkgfHwgJy8nXG5cbiAgY29uc3QgeyBocmVmLCBhcyB9ID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgW3Jlc29sdmVkSHJlZiwgcmVzb2x2ZWRBc10gPSByZXNvbHZlSHJlZihwYXRobmFtZSwgcHJvcHMuaHJlZiwgdHJ1ZSlcbiAgICByZXR1cm4ge1xuICAgICAgaHJlZjogcmVzb2x2ZWRIcmVmLFxuICAgICAgYXM6IHByb3BzLmFzXG4gICAgICAgID8gcmVzb2x2ZUhyZWYocGF0aG5hbWUsIHByb3BzLmFzKVxuICAgICAgICA6IHJlc29sdmVkQXMgfHwgcmVzb2x2ZWRIcmVmLFxuICAgIH1cbiAgfSwgW3BhdGhuYW1lLCBwcm9wcy5ocmVmLCBwcm9wcy5hc10pXG5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoXG4gICAgICBwICYmXG4gICAgICBJbnRlcnNlY3Rpb25PYnNlcnZlciAmJlxuICAgICAgY2hpbGRFbG0gJiZcbiAgICAgIGNoaWxkRWxtLnRhZ05hbWUgJiZcbiAgICAgIGlzTG9jYWxVUkwoaHJlZilcbiAgICApIHtcbiAgICAgIC8vIEpvaW4gb24gYW4gaW52YWxpZCBVUkkgY2hhcmFjdGVyXG4gICAgICBjb25zdCBpc1ByZWZldGNoZWQgPSBwcmVmZXRjaGVkW2hyZWYgKyAnJScgKyBhc11cbiAgICAgIGlmICghaXNQcmVmZXRjaGVkKSB7XG4gICAgICAgIHJldHVybiBsaXN0ZW5Ub0ludGVyc2VjdGlvbnMoY2hpbGRFbG0sICgpID0+IHtcbiAgICAgICAgICBwcmVmZXRjaChyb3V0ZXIsIGhyZWYsIGFzKVxuICAgICAgICB9KVxuICAgICAgfVxuICAgIH1cbiAgfSwgW3AsIGNoaWxkRWxtLCBocmVmLCBhcywgcm91dGVyXSlcblxuICBsZXQgeyBjaGlsZHJlbiwgcmVwbGFjZSwgc2hhbGxvdywgc2Nyb2xsIH0gPSBwcm9wc1xuICAvLyBEZXByZWNhdGVkLiBXYXJuaW5nIHNob3duIGJ5IHByb3BUeXBlIGNoZWNrLiBJZiB0aGUgY2hpbGRyZW4gcHJvdmlkZWQgaXMgYSBzdHJpbmcgKDxMaW5rPmV4YW1wbGU8L0xpbms+KSB3ZSB3cmFwIGl0IGluIGFuIDxhPiB0YWdcbiAgaWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gJ3N0cmluZycpIHtcbiAgICBjaGlsZHJlbiA9IDxhPntjaGlsZHJlbn08L2E+XG4gIH1cblxuICAvLyBUaGlzIHdpbGwgcmV0dXJuIHRoZSBmaXJzdCBjaGlsZCwgaWYgbXVsdGlwbGUgYXJlIHByb3ZpZGVkIGl0IHdpbGwgdGhyb3cgYW4gZXJyb3JcbiAgY29uc3QgY2hpbGQ6IGFueSA9IENoaWxkcmVuLm9ubHkoY2hpbGRyZW4pXG4gIGNvbnN0IGNoaWxkUHJvcHM6IHtcbiAgICBvbk1vdXNlRW50ZXI/OiBSZWFjdC5Nb3VzZUV2ZW50SGFuZGxlclxuICAgIG9uQ2xpY2s6IFJlYWN0Lk1vdXNlRXZlbnRIYW5kbGVyXG4gICAgaHJlZj86IHN0cmluZ1xuICAgIHJlZj86IGFueVxuICB9ID0ge1xuICAgIHJlZjogKGVsOiBhbnkpID0+IHtcbiAgICAgIGlmIChlbCkgc2V0Q2hpbGRFbG0oZWwpXG5cbiAgICAgIGlmIChjaGlsZCAmJiB0eXBlb2YgY2hpbGQgPT09ICdvYmplY3QnICYmIGNoaWxkLnJlZikge1xuICAgICAgICBpZiAodHlwZW9mIGNoaWxkLnJlZiA9PT0gJ2Z1bmN0aW9uJykgY2hpbGQucmVmKGVsKVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgY2hpbGQucmVmID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgIGNoaWxkLnJlZi5jdXJyZW50ID0gZWxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgb25DbGljazogKGU6IFJlYWN0Lk1vdXNlRXZlbnQpID0+IHtcbiAgICAgIGlmIChjaGlsZC5wcm9wcyAmJiB0eXBlb2YgY2hpbGQucHJvcHMub25DbGljayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBjaGlsZC5wcm9wcy5vbkNsaWNrKGUpXG4gICAgICB9XG4gICAgICBpZiAoIWUuZGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgICBsaW5rQ2xpY2tlZChlLCByb3V0ZXIsIGhyZWYsIGFzLCByZXBsYWNlLCBzaGFsbG93LCBzY3JvbGwpXG4gICAgICB9XG4gICAgfSxcbiAgfVxuXG4gIGlmIChwKSB7XG4gICAgY2hpbGRQcm9wcy5vbk1vdXNlRW50ZXIgPSAoZTogUmVhY3QuTW91c2VFdmVudCkgPT4ge1xuICAgICAgaWYgKCFpc0xvY2FsVVJMKGhyZWYpKSByZXR1cm5cbiAgICAgIGlmIChjaGlsZC5wcm9wcyAmJiB0eXBlb2YgY2hpbGQucHJvcHMub25Nb3VzZUVudGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNoaWxkLnByb3BzLm9uTW91c2VFbnRlcihlKVxuICAgICAgfVxuICAgICAgcHJlZmV0Y2gocm91dGVyLCBocmVmLCBhcywgeyBwcmlvcml0eTogdHJ1ZSB9KVxuICAgIH1cbiAgfVxuXG4gIC8vIElmIGNoaWxkIGlzIGFuIDxhPiB0YWcgYW5kIGRvZXNuJ3QgaGF2ZSBhIGhyZWYgYXR0cmlidXRlLCBvciBpZiB0aGUgJ3Bhc3NIcmVmJyBwcm9wZXJ0eSBpc1xuICAvLyBkZWZpbmVkLCB3ZSBzcGVjaWZ5IHRoZSBjdXJyZW50ICdocmVmJywgc28gdGhhdCByZXBldGl0aW9uIGlzIG5vdCBuZWVkZWQgYnkgdGhlIHVzZXJcbiAgaWYgKHByb3BzLnBhc3NIcmVmIHx8IChjaGlsZC50eXBlID09PSAnYScgJiYgISgnaHJlZicgaW4gY2hpbGQucHJvcHMpKSkge1xuICAgIGNoaWxkUHJvcHMuaHJlZiA9IGFkZEJhc2VQYXRoKFxuICAgICAgYWRkTG9jYWxlKGFzLCByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZSwgcm91dGVyICYmIHJvdXRlci5kZWZhdWx0TG9jYWxlKVxuICAgIClcbiAgfVxuXG4gIHJldHVybiBSZWFjdC5jbG9uZUVsZW1lbnQoY2hpbGQsIGNoaWxkUHJvcHMpXG59XG5cbmV4cG9ydCBkZWZhdWx0IExpbmtcbiIsIi8qKlxuICogUmVtb3ZlcyB0aGUgdHJhaWxpbmcgc2xhc2ggb2YgYSBwYXRoIGlmIHRoZXJlIGlzIG9uZS4gUHJlc2VydmVzIHRoZSByb290IHBhdGggYC9gLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHBhdGguZW5kc1dpdGgoJy8nKSAmJiBwYXRoICE9PSAnLycgPyBwYXRoLnNsaWNlKDAsIC0xKSA6IHBhdGhcbn1cblxuLyoqXG4gKiBOb3JtYWxpemVzIHRoZSB0cmFpbGluZyBzbGFzaCBvZiBhIHBhdGggYWNjb3JkaW5nIHRvIHRoZSBgdHJhaWxpbmdTbGFzaGAgb3B0aW9uXG4gKiBpbiBgbmV4dC5jb25maWcuanNgLlxuICovXG5leHBvcnQgY29uc3Qgbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2ggPSBwcm9jZXNzLmVudi5fX05FWFRfVFJBSUxJTkdfU0xBU0hcbiAgPyAocGF0aDogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgICAgIGlmICgvXFwuW14vXStcXC8/JC8udGVzdChwYXRoKSkge1xuICAgICAgICByZXR1cm4gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aClcbiAgICAgIH0gZWxzZSBpZiAocGF0aC5lbmRzV2l0aCgnLycpKSB7XG4gICAgICAgIHJldHVybiBwYXRoXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gcGF0aCArICcvJ1xuICAgICAgfVxuICAgIH1cbiAgOiByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaFxuIiwiLyogZ2xvYmFsIHdpbmRvdyAqL1xuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFJvdXRlciwgeyBOZXh0Um91dGVyIH0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci9yb3V0ZXInXG5pbXBvcnQgeyBSb3V0ZXJDb250ZXh0IH0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci1jb250ZXh0J1xuXG50eXBlIENsYXNzQXJndW1lbnRzPFQ+ID0gVCBleHRlbmRzIG5ldyAoLi4uYXJnczogaW5mZXIgVSkgPT4gYW55ID8gVSA6IGFueVxuXG50eXBlIFJvdXRlckFyZ3MgPSBDbGFzc0FyZ3VtZW50czx0eXBlb2YgUm91dGVyPlxuXG50eXBlIFNpbmdsZXRvblJvdXRlckJhc2UgPSB7XG4gIHJvdXRlcjogUm91dGVyIHwgbnVsbFxuICByZWFkeUNhbGxiYWNrczogQXJyYXk8KCkgPT4gYW55PlxuICByZWFkeShjYjogKCkgPT4gYW55KTogdm9pZFxufVxuXG5leHBvcnQgeyBSb3V0ZXIsIE5leHRSb3V0ZXIgfVxuXG5leHBvcnQgdHlwZSBTaW5nbGV0b25Sb3V0ZXIgPSBTaW5nbGV0b25Sb3V0ZXJCYXNlICYgTmV4dFJvdXRlclxuXG5jb25zdCBzaW5nbGV0b25Sb3V0ZXI6IFNpbmdsZXRvblJvdXRlckJhc2UgPSB7XG4gIHJvdXRlcjogbnVsbCwgLy8gaG9sZHMgdGhlIGFjdHVhbCByb3V0ZXIgaW5zdGFuY2VcbiAgcmVhZHlDYWxsYmFja3M6IFtdLFxuICByZWFkeShjYjogKCkgPT4gdm9pZCkge1xuICAgIGlmICh0aGlzLnJvdXRlcikgcmV0dXJuIGNiKClcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHRoaXMucmVhZHlDYWxsYmFja3MucHVzaChjYilcbiAgICB9XG4gIH0sXG59XG5cbi8vIENyZWF0ZSBwdWJsaWMgcHJvcGVydGllcyBhbmQgbWV0aG9kcyBvZiB0aGUgcm91dGVyIGluIHRoZSBzaW5nbGV0b25Sb3V0ZXJcbmNvbnN0IHVybFByb3BlcnR5RmllbGRzID0gW1xuICAncGF0aG5hbWUnLFxuICAncm91dGUnLFxuICAncXVlcnknLFxuICAnYXNQYXRoJyxcbiAgJ2NvbXBvbmVudHMnLFxuICAnaXNGYWxsYmFjaycsXG4gICdiYXNlUGF0aCcsXG4gICdsb2NhbGUnLFxuICAnbG9jYWxlcycsXG4gICdkZWZhdWx0TG9jYWxlJyxcbl1cbmNvbnN0IHJvdXRlckV2ZW50cyA9IFtcbiAgJ3JvdXRlQ2hhbmdlU3RhcnQnLFxuICAnYmVmb3JlSGlzdG9yeUNoYW5nZScsXG4gICdyb3V0ZUNoYW5nZUNvbXBsZXRlJyxcbiAgJ3JvdXRlQ2hhbmdlRXJyb3InLFxuICAnaGFzaENoYW5nZVN0YXJ0JyxcbiAgJ2hhc2hDaGFuZ2VDb21wbGV0ZScsXG5dXG5jb25zdCBjb3JlTWV0aG9kRmllbGRzID0gW1xuICAncHVzaCcsXG4gICdyZXBsYWNlJyxcbiAgJ3JlbG9hZCcsXG4gICdiYWNrJyxcbiAgJ3ByZWZldGNoJyxcbiAgJ2JlZm9yZVBvcFN0YXRlJyxcbl1cblxuLy8gRXZlbnRzIGlzIGEgc3RhdGljIHByb3BlcnR5IG9uIHRoZSByb3V0ZXIsIHRoZSByb3V0ZXIgZG9lc24ndCBoYXZlIHRvIGJlIGluaXRpYWxpemVkIHRvIHVzZSBpdFxuT2JqZWN0LmRlZmluZVByb3BlcnR5KHNpbmdsZXRvblJvdXRlciwgJ2V2ZW50cycsIHtcbiAgZ2V0KCkge1xuICAgIHJldHVybiBSb3V0ZXIuZXZlbnRzXG4gIH0sXG59KVxuXG51cmxQcm9wZXJ0eUZpZWxkcy5mb3JFYWNoKChmaWVsZCkgPT4ge1xuICAvLyBIZXJlIHdlIG5lZWQgdG8gdXNlIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSBiZWNhdXNlLCB3ZSBuZWVkIHRvIHJldHVyblxuICAvLyB0aGUgcHJvcGVydHkgYXNzaWduZWQgdG8gdGhlIGFjdHVhbCByb3V0ZXJcbiAgLy8gVGhlIHZhbHVlIG1pZ2h0IGdldCBjaGFuZ2VkIGFzIHdlIGNoYW5nZSByb3V0ZXMgYW5kIHRoaXMgaXMgdGhlXG4gIC8vIHByb3BlciB3YXkgdG8gYWNjZXNzIGl0XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShzaW5nbGV0b25Sb3V0ZXIsIGZpZWxkLCB7XG4gICAgZ2V0KCkge1xuICAgICAgY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCkgYXMgYW55XG4gICAgICByZXR1cm4gcm91dGVyW2ZpZWxkXSBhcyBzdHJpbmdcbiAgICB9LFxuICB9KVxufSlcblxuY29yZU1ldGhvZEZpZWxkcy5mb3JFYWNoKChmaWVsZCkgPT4ge1xuICAvLyBXZSBkb24ndCByZWFsbHkga25vdyB0aGUgdHlwZXMgaGVyZSwgc28gd2UgYWRkIHRoZW0gbGF0ZXIgaW5zdGVhZFxuICA7KHNpbmdsZXRvblJvdXRlciBhcyBhbnkpW2ZpZWxkXSA9ICguLi5hcmdzOiBhbnlbXSkgPT4ge1xuICAgIGNvbnN0IHJvdXRlciA9IGdldFJvdXRlcigpIGFzIGFueVxuICAgIHJldHVybiByb3V0ZXJbZmllbGRdKC4uLmFyZ3MpXG4gIH1cbn0pXG5cbnJvdXRlckV2ZW50cy5mb3JFYWNoKChldmVudCkgPT4ge1xuICBzaW5nbGV0b25Sb3V0ZXIucmVhZHkoKCkgPT4ge1xuICAgIFJvdXRlci5ldmVudHMub24oZXZlbnQsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zdCBldmVudEZpZWxkID0gYG9uJHtldmVudC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX0ke2V2ZW50LnN1YnN0cmluZyhcbiAgICAgICAgMVxuICAgICAgKX1gXG4gICAgICBjb25zdCBfc2luZ2xldG9uUm91dGVyID0gc2luZ2xldG9uUm91dGVyIGFzIGFueVxuICAgICAgaWYgKF9zaW5nbGV0b25Sb3V0ZXJbZXZlbnRGaWVsZF0pIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBfc2luZ2xldG9uUm91dGVyW2V2ZW50RmllbGRdKC4uLmFyZ3MpXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHdoZW4gcnVubmluZyB0aGUgUm91dGVyIGV2ZW50OiAke2V2ZW50RmllbGR9YClcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGAke2Vyci5tZXNzYWdlfVxcbiR7ZXJyLnN0YWNrfWApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuICB9KVxufSlcblxuZnVuY3Rpb24gZ2V0Um91dGVyKCk6IFJvdXRlciB7XG4gIGlmICghc2luZ2xldG9uUm91dGVyLnJvdXRlcikge1xuICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgJ05vIHJvdXRlciBpbnN0YW5jZSBmb3VuZC5cXG4nICtcbiAgICAgICdZb3Ugc2hvdWxkIG9ubHkgdXNlIFwibmV4dC9yb3V0ZXJcIiBpbnNpZGUgdGhlIGNsaWVudCBzaWRlIG9mIHlvdXIgYXBwLlxcbidcbiAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSlcbiAgfVxuICByZXR1cm4gc2luZ2xldG9uUm91dGVyLnJvdXRlclxufVxuXG4vLyBFeHBvcnQgdGhlIHNpbmdsZXRvblJvdXRlciBhbmQgdGhpcyBpcyB0aGUgcHVibGljIEFQSS5cbmV4cG9ydCBkZWZhdWx0IHNpbmdsZXRvblJvdXRlciBhcyBTaW5nbGV0b25Sb3V0ZXJcblxuLy8gUmVleHBvcnQgdGhlIHdpdGhSb3V0ZSBIT0NcbmV4cG9ydCB7IGRlZmF1bHQgYXMgd2l0aFJvdXRlciB9IGZyb20gJy4vd2l0aC1yb3V0ZXInXG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VSb3V0ZXIoKTogTmV4dFJvdXRlciB7XG4gIHJldHVybiBSZWFjdC51c2VDb250ZXh0KFJvdXRlckNvbnRleHQpXG59XG5cbi8vIElOVEVSTkFMIEFQSVNcbi8vIC0tLS0tLS0tLS0tLS1cbi8vIChkbyBub3QgdXNlIGZvbGxvd2luZyBleHBvcnRzIGluc2lkZSB0aGUgYXBwKVxuXG4vLyBDcmVhdGUgYSByb3V0ZXIgYW5kIGFzc2lnbiBpdCBhcyB0aGUgc2luZ2xldG9uIGluc3RhbmNlLlxuLy8gVGhpcyBpcyB1c2VkIGluIGNsaWVudCBzaWRlIHdoZW4gd2UgYXJlIGluaXRpbGl6aW5nIHRoZSBhcHAuXG4vLyBUaGlzIHNob3VsZCAqKm5vdCoqIHVzZSBpbnNpZGUgdGhlIHNlcnZlci5cbmV4cG9ydCBjb25zdCBjcmVhdGVSb3V0ZXIgPSAoLi4uYXJnczogUm91dGVyQXJncyk6IFJvdXRlciA9PiB7XG4gIHNpbmdsZXRvblJvdXRlci5yb3V0ZXIgPSBuZXcgUm91dGVyKC4uLmFyZ3MpXG4gIHNpbmdsZXRvblJvdXRlci5yZWFkeUNhbGxiYWNrcy5mb3JFYWNoKChjYikgPT4gY2IoKSlcbiAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzID0gW11cblxuICByZXR1cm4gc2luZ2xldG9uUm91dGVyLnJvdXRlclxufVxuXG4vLyBUaGlzIGZ1bmN0aW9uIGlzIHVzZWQgdG8gY3JlYXRlIHRoZSBgd2l0aFJvdXRlcmAgcm91dGVyIGluc3RhbmNlXG5leHBvcnQgZnVuY3Rpb24gbWFrZVB1YmxpY1JvdXRlckluc3RhbmNlKHJvdXRlcjogUm91dGVyKTogTmV4dFJvdXRlciB7XG4gIGNvbnN0IF9yb3V0ZXIgPSByb3V0ZXIgYXMgYW55XG4gIGNvbnN0IGluc3RhbmNlID0ge30gYXMgYW55XG5cbiAgZm9yIChjb25zdCBwcm9wZXJ0eSBvZiB1cmxQcm9wZXJ0eUZpZWxkcykge1xuICAgIGlmICh0eXBlb2YgX3JvdXRlcltwcm9wZXJ0eV0gPT09ICdvYmplY3QnKSB7XG4gICAgICBpbnN0YW5jZVtwcm9wZXJ0eV0gPSBPYmplY3QuYXNzaWduKFxuICAgICAgICBBcnJheS5pc0FycmF5KF9yb3V0ZXJbcHJvcGVydHldKSA/IFtdIDoge30sXG4gICAgICAgIF9yb3V0ZXJbcHJvcGVydHldXG4gICAgICApIC8vIG1ha2VzIHN1cmUgcXVlcnkgaXMgbm90IHN0YXRlZnVsXG4gICAgICBjb250aW51ZVxuICAgIH1cblxuICAgIGluc3RhbmNlW3Byb3BlcnR5XSA9IF9yb3V0ZXJbcHJvcGVydHldXG4gIH1cblxuICAvLyBFdmVudHMgaXMgYSBzdGF0aWMgcHJvcGVydHkgb24gdGhlIHJvdXRlciwgdGhlIHJvdXRlciBkb2Vzbid0IGhhdmUgdG8gYmUgaW5pdGlhbGl6ZWQgdG8gdXNlIGl0XG4gIGluc3RhbmNlLmV2ZW50cyA9IFJvdXRlci5ldmVudHNcblxuICBjb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKSA9PiB7XG4gICAgaW5zdGFuY2VbZmllbGRdID0gKC4uLmFyZ3M6IGFueVtdKSA9PiB7XG4gICAgICByZXR1cm4gX3JvdXRlcltmaWVsZF0oLi4uYXJncylcbiAgICB9XG4gIH0pXG5cbiAgcmV0dXJuIGluc3RhbmNlXG59XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBOZXh0Q29tcG9uZW50VHlwZSwgTmV4dFBhZ2VDb250ZXh0IH0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3V0aWxzJ1xuaW1wb3J0IHsgTmV4dFJvdXRlciwgdXNlUm91dGVyIH0gZnJvbSAnLi9yb3V0ZXInXG5cbmV4cG9ydCB0eXBlIFdpdGhSb3V0ZXJQcm9wcyA9IHtcbiAgcm91dGVyOiBOZXh0Um91dGVyXG59XG5cbmV4cG9ydCB0eXBlIEV4Y2x1ZGVSb3V0ZXJQcm9wczxQPiA9IFBpY2s8XG4gIFAsXG4gIEV4Y2x1ZGU8a2V5b2YgUCwga2V5b2YgV2l0aFJvdXRlclByb3BzPlxuPlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB3aXRoUm91dGVyPFxuICBQIGV4dGVuZHMgV2l0aFJvdXRlclByb3BzLFxuICBDID0gTmV4dFBhZ2VDb250ZXh0XG4+KFxuICBDb21wb3NlZENvbXBvbmVudDogTmV4dENvbXBvbmVudFR5cGU8QywgYW55LCBQPlxuKTogUmVhY3QuQ29tcG9uZW50VHlwZTxFeGNsdWRlUm91dGVyUHJvcHM8UD4+IHtcbiAgZnVuY3Rpb24gV2l0aFJvdXRlcldyYXBwZXIocHJvcHM6IGFueSkge1xuICAgIHJldHVybiA8Q29tcG9zZWRDb21wb25lbnQgcm91dGVyPXt1c2VSb3V0ZXIoKX0gey4uLnByb3BzfSAvPlxuICB9XG5cbiAgV2l0aFJvdXRlcldyYXBwZXIuZ2V0SW5pdGlhbFByb3BzID0gQ29tcG9zZWRDb21wb25lbnQuZ2V0SW5pdGlhbFByb3BzXG4gIC8vIFRoaXMgaXMgbmVlZGVkIHRvIGFsbG93IGNoZWNraW5nIGZvciBjdXN0b20gZ2V0SW5pdGlhbFByb3BzIGluIF9hcHBcbiAgOyhXaXRoUm91dGVyV3JhcHBlciBhcyBhbnkpLm9yaWdHZXRJbml0aWFsUHJvcHMgPSAoQ29tcG9zZWRDb21wb25lbnQgYXMgYW55KS5vcmlnR2V0SW5pdGlhbFByb3BzXG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgY29uc3QgbmFtZSA9XG4gICAgICBDb21wb3NlZENvbXBvbmVudC5kaXNwbGF5TmFtZSB8fCBDb21wb3NlZENvbXBvbmVudC5uYW1lIHx8ICdVbmtub3duJ1xuICAgIFdpdGhSb3V0ZXJXcmFwcGVyLmRpc3BsYXlOYW1lID0gYHdpdGhSb3V0ZXIoJHtuYW1lfSlgXG4gIH1cblxuICByZXR1cm4gV2l0aFJvdXRlcldyYXBwZXJcbn1cbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuLyoqXG4gKiBUb2tlbml6ZSBpbnB1dCBzdHJpbmcuXG4gKi9cbmZ1bmN0aW9uIGxleGVyKHN0cikge1xuICAgIHZhciB0b2tlbnMgPSBbXTtcbiAgICB2YXIgaSA9IDA7XG4gICAgd2hpbGUgKGkgPCBzdHIubGVuZ3RoKSB7XG4gICAgICAgIHZhciBjaGFyID0gc3RyW2ldO1xuICAgICAgICBpZiAoY2hhciA9PT0gXCIqXCIgfHwgY2hhciA9PT0gXCIrXCIgfHwgY2hhciA9PT0gXCI/XCIpIHtcbiAgICAgICAgICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJNT0RJRklFUlwiLCBpbmRleDogaSwgdmFsdWU6IHN0cltpKytdIH0pO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNoYXIgPT09IFwiXFxcXFwiKSB7XG4gICAgICAgICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiRVNDQVBFRF9DSEFSXCIsIGluZGV4OiBpKyssIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjaGFyID09PSBcIntcIikge1xuICAgICAgICAgICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIk9QRU5cIiwgaW5kZXg6IGksIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjaGFyID09PSBcIn1cIikge1xuICAgICAgICAgICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIkNMT1NFXCIsIGluZGV4OiBpLCB2YWx1ZTogc3RyW2krK10gfSk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2hhciA9PT0gXCI6XCIpIHtcbiAgICAgICAgICAgIHZhciBuYW1lID0gXCJcIjtcbiAgICAgICAgICAgIHZhciBqID0gaSArIDE7XG4gICAgICAgICAgICB3aGlsZSAoaiA8IHN0ci5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB2YXIgY29kZSA9IHN0ci5jaGFyQ29kZUF0KGopO1xuICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAvLyBgMC05YFxuICAgICAgICAgICAgICAgIChjb2RlID49IDQ4ICYmIGNvZGUgPD0gNTcpIHx8XG4gICAgICAgICAgICAgICAgICAgIC8vIGBBLVpgXG4gICAgICAgICAgICAgICAgICAgIChjb2RlID49IDY1ICYmIGNvZGUgPD0gOTApIHx8XG4gICAgICAgICAgICAgICAgICAgIC8vIGBhLXpgXG4gICAgICAgICAgICAgICAgICAgIChjb2RlID49IDk3ICYmIGNvZGUgPD0gMTIyKSB8fFxuICAgICAgICAgICAgICAgICAgICAvLyBgX2BcbiAgICAgICAgICAgICAgICAgICAgY29kZSA9PT0gOTUpIHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZSArPSBzdHJbaisrXTtcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFuYW1lKVxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJNaXNzaW5nIHBhcmFtZXRlciBuYW1lIGF0IFwiICsgaSk7XG4gICAgICAgICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiTkFNRVwiLCBpbmRleDogaSwgdmFsdWU6IG5hbWUgfSk7XG4gICAgICAgICAgICBpID0gajtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjaGFyID09PSBcIihcIikge1xuICAgICAgICAgICAgdmFyIGNvdW50ID0gMTtcbiAgICAgICAgICAgIHZhciBwYXR0ZXJuID0gXCJcIjtcbiAgICAgICAgICAgIHZhciBqID0gaSArIDE7XG4gICAgICAgICAgICBpZiAoc3RyW2pdID09PSBcIj9cIikge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQYXR0ZXJuIGNhbm5vdCBzdGFydCB3aXRoIFxcXCI/XFxcIiBhdCBcIiArIGopO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgd2hpbGUgKGogPCBzdHIubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgaWYgKHN0cltqXSA9PT0gXCJcXFxcXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0dGVybiArPSBzdHJbaisrXSArIHN0cltqKytdO1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHN0cltqXSA9PT0gXCIpXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgY291bnQtLTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvdW50ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBqKys7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChzdHJbal0gPT09IFwiKFwiKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvdW50Kys7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzdHJbaiArIDFdICE9PSBcIj9cIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhcHR1cmluZyBncm91cHMgYXJlIG5vdCBhbGxvd2VkIGF0IFwiICsgaik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcGF0dGVybiArPSBzdHJbaisrXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjb3VudClcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiVW5iYWxhbmNlZCBwYXR0ZXJuIGF0IFwiICsgaSk7XG4gICAgICAgICAgICBpZiAoIXBhdHRlcm4pXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk1pc3NpbmcgcGF0dGVybiBhdCBcIiArIGkpO1xuICAgICAgICAgICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIlBBVFRFUk5cIiwgaW5kZXg6IGksIHZhbHVlOiBwYXR0ZXJuIH0pO1xuICAgICAgICAgICAgaSA9IGo7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiQ0hBUlwiLCBpbmRleDogaSwgdmFsdWU6IHN0cltpKytdIH0pO1xuICAgIH1cbiAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiRU5EXCIsIGluZGV4OiBpLCB2YWx1ZTogXCJcIiB9KTtcbiAgICByZXR1cm4gdG9rZW5zO1xufVxuLyoqXG4gKiBQYXJzZSBhIHN0cmluZyBmb3IgdGhlIHJhdyB0b2tlbnMuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlKHN0ciwgb3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zID09PSB2b2lkIDApIHsgb3B0aW9ucyA9IHt9OyB9XG4gICAgdmFyIHRva2VucyA9IGxleGVyKHN0cik7XG4gICAgdmFyIF9hID0gb3B0aW9ucy5wcmVmaXhlcywgcHJlZml4ZXMgPSBfYSA9PT0gdm9pZCAwID8gXCIuL1wiIDogX2E7XG4gICAgdmFyIGRlZmF1bHRQYXR0ZXJuID0gXCJbXlwiICsgZXNjYXBlU3RyaW5nKG9wdGlvbnMuZGVsaW1pdGVyIHx8IFwiLyM/XCIpICsgXCJdKz9cIjtcbiAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgdmFyIGtleSA9IDA7XG4gICAgdmFyIGkgPSAwO1xuICAgIHZhciBwYXRoID0gXCJcIjtcbiAgICB2YXIgdHJ5Q29uc3VtZSA9IGZ1bmN0aW9uICh0eXBlKSB7XG4gICAgICAgIGlmIChpIDwgdG9rZW5zLmxlbmd0aCAmJiB0b2tlbnNbaV0udHlwZSA9PT0gdHlwZSlcbiAgICAgICAgICAgIHJldHVybiB0b2tlbnNbaSsrXS52YWx1ZTtcbiAgICB9O1xuICAgIHZhciBtdXN0Q29uc3VtZSA9IGZ1bmN0aW9uICh0eXBlKSB7XG4gICAgICAgIHZhciB2YWx1ZSA9IHRyeUNvbnN1bWUodHlwZSk7XG4gICAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB2YXIgX2EgPSB0b2tlbnNbaV0sIG5leHRUeXBlID0gX2EudHlwZSwgaW5kZXggPSBfYS5pbmRleDtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlVuZXhwZWN0ZWQgXCIgKyBuZXh0VHlwZSArIFwiIGF0IFwiICsgaW5kZXggKyBcIiwgZXhwZWN0ZWQgXCIgKyB0eXBlKTtcbiAgICB9O1xuICAgIHZhciBjb25zdW1lVGV4dCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IFwiXCI7XG4gICAgICAgIHZhciB2YWx1ZTtcbiAgICAgICAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lXG4gICAgICAgIHdoaWxlICgodmFsdWUgPSB0cnlDb25zdW1lKFwiQ0hBUlwiKSB8fCB0cnlDb25zdW1lKFwiRVNDQVBFRF9DSEFSXCIpKSkge1xuICAgICAgICAgICAgcmVzdWx0ICs9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcbiAgICB3aGlsZSAoaSA8IHRva2Vucy5sZW5ndGgpIHtcbiAgICAgICAgdmFyIGNoYXIgPSB0cnlDb25zdW1lKFwiQ0hBUlwiKTtcbiAgICAgICAgdmFyIG5hbWUgPSB0cnlDb25zdW1lKFwiTkFNRVwiKTtcbiAgICAgICAgdmFyIHBhdHRlcm4gPSB0cnlDb25zdW1lKFwiUEFUVEVSTlwiKTtcbiAgICAgICAgaWYgKG5hbWUgfHwgcGF0dGVybikge1xuICAgICAgICAgICAgdmFyIHByZWZpeCA9IGNoYXIgfHwgXCJcIjtcbiAgICAgICAgICAgIGlmIChwcmVmaXhlcy5pbmRleE9mKHByZWZpeCkgPT09IC0xKSB7XG4gICAgICAgICAgICAgICAgcGF0aCArPSBwcmVmaXg7XG4gICAgICAgICAgICAgICAgcHJlZml4ID0gXCJcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXRoKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2gocGF0aCk7XG4gICAgICAgICAgICAgICAgcGF0aCA9IFwiXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgbmFtZTogbmFtZSB8fCBrZXkrKyxcbiAgICAgICAgICAgICAgICBwcmVmaXg6IHByZWZpeCxcbiAgICAgICAgICAgICAgICBzdWZmaXg6IFwiXCIsXG4gICAgICAgICAgICAgICAgcGF0dGVybjogcGF0dGVybiB8fCBkZWZhdWx0UGF0dGVybixcbiAgICAgICAgICAgICAgICBtb2RpZmllcjogdHJ5Q29uc3VtZShcIk1PRElGSUVSXCIpIHx8IFwiXCJcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHZhbHVlID0gY2hhciB8fCB0cnlDb25zdW1lKFwiRVNDQVBFRF9DSEFSXCIpO1xuICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgIHBhdGggKz0gdmFsdWU7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocGF0aCkge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2gocGF0aCk7XG4gICAgICAgICAgICBwYXRoID0gXCJcIjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgb3BlbiA9IHRyeUNvbnN1bWUoXCJPUEVOXCIpO1xuICAgICAgICBpZiAob3Blbikge1xuICAgICAgICAgICAgdmFyIHByZWZpeCA9IGNvbnN1bWVUZXh0KCk7XG4gICAgICAgICAgICB2YXIgbmFtZV8xID0gdHJ5Q29uc3VtZShcIk5BTUVcIikgfHwgXCJcIjtcbiAgICAgICAgICAgIHZhciBwYXR0ZXJuXzEgPSB0cnlDb25zdW1lKFwiUEFUVEVSTlwiKSB8fCBcIlwiO1xuICAgICAgICAgICAgdmFyIHN1ZmZpeCA9IGNvbnN1bWVUZXh0KCk7XG4gICAgICAgICAgICBtdXN0Q29uc3VtZShcIkNMT1NFXCIpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgIG5hbWU6IG5hbWVfMSB8fCAocGF0dGVybl8xID8ga2V5KysgOiBcIlwiKSxcbiAgICAgICAgICAgICAgICBwYXR0ZXJuOiBuYW1lXzEgJiYgIXBhdHRlcm5fMSA/IGRlZmF1bHRQYXR0ZXJuIDogcGF0dGVybl8xLFxuICAgICAgICAgICAgICAgIHByZWZpeDogcHJlZml4LFxuICAgICAgICAgICAgICAgIHN1ZmZpeDogc3VmZml4LFxuICAgICAgICAgICAgICAgIG1vZGlmaWVyOiB0cnlDb25zdW1lKFwiTU9ESUZJRVJcIikgfHwgXCJcIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBtdXN0Q29uc3VtZShcIkVORFwiKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbmV4cG9ydHMucGFyc2UgPSBwYXJzZTtcbi8qKlxuICogQ29tcGlsZSBhIHN0cmluZyB0byBhIHRlbXBsYXRlIGZ1bmN0aW9uIGZvciB0aGUgcGF0aC5cbiAqL1xuZnVuY3Rpb24gY29tcGlsZShzdHIsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdG9rZW5zVG9GdW5jdGlvbihwYXJzZShzdHIsIG9wdGlvbnMpLCBvcHRpb25zKTtcbn1cbmV4cG9ydHMuY29tcGlsZSA9IGNvbXBpbGU7XG4vKipcbiAqIEV4cG9zZSBhIG1ldGhvZCBmb3IgdHJhbnNmb3JtaW5nIHRva2VucyBpbnRvIHRoZSBwYXRoIGZ1bmN0aW9uLlxuICovXG5mdW5jdGlvbiB0b2tlbnNUb0Z1bmN0aW9uKHRva2Vucywgb3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zID09PSB2b2lkIDApIHsgb3B0aW9ucyA9IHt9OyB9XG4gICAgdmFyIHJlRmxhZ3MgPSBmbGFncyhvcHRpb25zKTtcbiAgICB2YXIgX2EgPSBvcHRpb25zLmVuY29kZSwgZW5jb2RlID0gX2EgPT09IHZvaWQgMCA/IGZ1bmN0aW9uICh4KSB7IHJldHVybiB4OyB9IDogX2EsIF9iID0gb3B0aW9ucy52YWxpZGF0ZSwgdmFsaWRhdGUgPSBfYiA9PT0gdm9pZCAwID8gdHJ1ZSA6IF9iO1xuICAgIC8vIENvbXBpbGUgYWxsIHRoZSB0b2tlbnMgaW50byByZWdleHBzLlxuICAgIHZhciBtYXRjaGVzID0gdG9rZW5zLm1hcChmdW5jdGlvbiAodG9rZW4pIHtcbiAgICAgICAgaWYgKHR5cGVvZiB0b2tlbiA9PT0gXCJvYmplY3RcIikge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBSZWdFeHAoXCJeKD86XCIgKyB0b2tlbi5wYXR0ZXJuICsgXCIpJFwiLCByZUZsYWdzKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICB2YXIgcGF0aCA9IFwiXCI7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdG9rZW5zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgdG9rZW4gPSB0b2tlbnNbaV07XG4gICAgICAgICAgICBpZiAodHlwZW9mIHRva2VuID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICAgICAgcGF0aCArPSB0b2tlbjtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciB2YWx1ZSA9IGRhdGEgPyBkYXRhW3Rva2VuLm5hbWVdIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgdmFyIG9wdGlvbmFsID0gdG9rZW4ubW9kaWZpZXIgPT09IFwiP1wiIHx8IHRva2VuLm1vZGlmaWVyID09PSBcIipcIjtcbiAgICAgICAgICAgIHZhciByZXBlYXQgPSB0b2tlbi5tb2RpZmllciA9PT0gXCIqXCIgfHwgdG9rZW4ubW9kaWZpZXIgPT09IFwiK1wiO1xuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFyZXBlYXQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkV4cGVjdGVkIFxcXCJcIiArIHRva2VuLm5hbWUgKyBcIlxcXCIgdG8gbm90IHJlcGVhdCwgYnV0IGdvdCBhbiBhcnJheVwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAob3B0aW9uYWwpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkV4cGVjdGVkIFxcXCJcIiArIHRva2VuLm5hbWUgKyBcIlxcXCIgdG8gbm90IGJlIGVtcHR5XCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHZhbHVlLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzZWdtZW50ID0gZW5jb2RlKHZhbHVlW2pdLCB0b2tlbik7XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0ZSAmJiAhbWF0Y2hlc1tpXS50ZXN0KHNlZ21lbnQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiRXhwZWN0ZWQgYWxsIFxcXCJcIiArIHRva2VuLm5hbWUgKyBcIlxcXCIgdG8gbWF0Y2ggXFxcIlwiICsgdG9rZW4ucGF0dGVybiArIFwiXFxcIiwgYnV0IGdvdCBcXFwiXCIgKyBzZWdtZW50ICsgXCJcXFwiXCIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHBhdGggKz0gdG9rZW4ucHJlZml4ICsgc2VnbWVudCArIHRva2VuLnN1ZmZpeDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIikge1xuICAgICAgICAgICAgICAgIHZhciBzZWdtZW50ID0gZW5jb2RlKFN0cmluZyh2YWx1ZSksIHRva2VuKTtcbiAgICAgICAgICAgICAgICBpZiAodmFsaWRhdGUgJiYgIW1hdGNoZXNbaV0udGVzdChzZWdtZW50KSkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiRXhwZWN0ZWQgXFxcIlwiICsgdG9rZW4ubmFtZSArIFwiXFxcIiB0byBtYXRjaCBcXFwiXCIgKyB0b2tlbi5wYXR0ZXJuICsgXCJcXFwiLCBidXQgZ290IFxcXCJcIiArIHNlZ21lbnQgKyBcIlxcXCJcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHBhdGggKz0gdG9rZW4ucHJlZml4ICsgc2VnbWVudCArIHRva2VuLnN1ZmZpeDtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChvcHRpb25hbClcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIHZhciB0eXBlT2ZNZXNzYWdlID0gcmVwZWF0ID8gXCJhbiBhcnJheVwiIDogXCJhIHN0cmluZ1wiO1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkV4cGVjdGVkIFxcXCJcIiArIHRva2VuLm5hbWUgKyBcIlxcXCIgdG8gYmUgXCIgKyB0eXBlT2ZNZXNzYWdlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcGF0aDtcbiAgICB9O1xufVxuZXhwb3J0cy50b2tlbnNUb0Z1bmN0aW9uID0gdG9rZW5zVG9GdW5jdGlvbjtcbi8qKlxuICogQ3JlYXRlIHBhdGggbWF0Y2ggZnVuY3Rpb24gZnJvbSBgcGF0aC10by1yZWdleHBgIHNwZWMuXG4gKi9cbmZ1bmN0aW9uIG1hdGNoKHN0ciwgb3B0aW9ucykge1xuICAgIHZhciBrZXlzID0gW107XG4gICAgdmFyIHJlID0gcGF0aFRvUmVnZXhwKHN0ciwga2V5cywgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHJlZ2V4cFRvRnVuY3Rpb24ocmUsIGtleXMsIG9wdGlvbnMpO1xufVxuZXhwb3J0cy5tYXRjaCA9IG1hdGNoO1xuLyoqXG4gKiBDcmVhdGUgYSBwYXRoIG1hdGNoIGZ1bmN0aW9uIGZyb20gYHBhdGgtdG8tcmVnZXhwYCBvdXRwdXQuXG4gKi9cbmZ1bmN0aW9uIHJlZ2V4cFRvRnVuY3Rpb24ocmUsIGtleXMsIG9wdGlvbnMpIHtcbiAgICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7IG9wdGlvbnMgPSB7fTsgfVxuICAgIHZhciBfYSA9IG9wdGlvbnMuZGVjb2RlLCBkZWNvZGUgPSBfYSA9PT0gdm9pZCAwID8gZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHg7IH0gOiBfYTtcbiAgICByZXR1cm4gZnVuY3Rpb24gKHBhdGhuYW1lKSB7XG4gICAgICAgIHZhciBtID0gcmUuZXhlYyhwYXRobmFtZSk7XG4gICAgICAgIGlmICghbSlcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgdmFyIHBhdGggPSBtWzBdLCBpbmRleCA9IG0uaW5kZXg7XG4gICAgICAgIHZhciBwYXJhbXMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgICB2YXIgX2xvb3BfMSA9IGZ1bmN0aW9uIChpKSB7XG4gICAgICAgICAgICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmVcbiAgICAgICAgICAgIGlmIChtW2ldID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiY29udGludWVcIjtcbiAgICAgICAgICAgIHZhciBrZXkgPSBrZXlzW2kgLSAxXTtcbiAgICAgICAgICAgIGlmIChrZXkubW9kaWZpZXIgPT09IFwiKlwiIHx8IGtleS5tb2RpZmllciA9PT0gXCIrXCIpIHtcbiAgICAgICAgICAgICAgICBwYXJhbXNba2V5Lm5hbWVdID0gbVtpXS5zcGxpdChrZXkucHJlZml4ICsga2V5LnN1ZmZpeCkubWFwKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZGVjb2RlKHZhbHVlLCBrZXkpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcGFyYW1zW2tleS5uYW1lXSA9IGRlY29kZShtW2ldLCBrZXkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IG0ubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIF9sb29wXzEoaSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgcGF0aDogcGF0aCwgaW5kZXg6IGluZGV4LCBwYXJhbXM6IHBhcmFtcyB9O1xuICAgIH07XG59XG5leHBvcnRzLnJlZ2V4cFRvRnVuY3Rpb24gPSByZWdleHBUb0Z1bmN0aW9uO1xuLyoqXG4gKiBFc2NhcGUgYSByZWd1bGFyIGV4cHJlc3Npb24gc3RyaW5nLlxuICovXG5mdW5jdGlvbiBlc2NhcGVTdHJpbmcoc3RyKSB7XG4gICAgcmV0dXJuIHN0ci5yZXBsYWNlKC8oWy4rKj89XiE6JHt9KClbXFxdfC9cXFxcXSkvZywgXCJcXFxcJDFcIik7XG59XG4vKipcbiAqIEdldCB0aGUgZmxhZ3MgZm9yIGEgcmVnZXhwIGZyb20gdGhlIG9wdGlvbnMuXG4gKi9cbmZ1bmN0aW9uIGZsYWdzKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gb3B0aW9ucyAmJiBvcHRpb25zLnNlbnNpdGl2ZSA/IFwiXCIgOiBcImlcIjtcbn1cbi8qKlxuICogUHVsbCBvdXQga2V5cyBmcm9tIGEgcmVnZXhwLlxuICovXG5mdW5jdGlvbiByZWdleHBUb1JlZ2V4cChwYXRoLCBrZXlzKSB7XG4gICAgaWYgKCFrZXlzKVxuICAgICAgICByZXR1cm4gcGF0aDtcbiAgICAvLyBVc2UgYSBuZWdhdGl2ZSBsb29rYWhlYWQgdG8gbWF0Y2ggb25seSBjYXB0dXJpbmcgZ3JvdXBzLlxuICAgIHZhciBncm91cHMgPSBwYXRoLnNvdXJjZS5tYXRjaCgvXFwoKD8hXFw/KS9nKTtcbiAgICBpZiAoZ3JvdXBzKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZ3JvdXBzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBrZXlzLnB1c2goe1xuICAgICAgICAgICAgICAgIG5hbWU6IGksXG4gICAgICAgICAgICAgICAgcHJlZml4OiBcIlwiLFxuICAgICAgICAgICAgICAgIHN1ZmZpeDogXCJcIixcbiAgICAgICAgICAgICAgICBtb2RpZmllcjogXCJcIixcbiAgICAgICAgICAgICAgICBwYXR0ZXJuOiBcIlwiXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcGF0aDtcbn1cbi8qKlxuICogVHJhbnNmb3JtIGFuIGFycmF5IGludG8gYSByZWdleHAuXG4gKi9cbmZ1bmN0aW9uIGFycmF5VG9SZWdleHAocGF0aHMsIGtleXMsIG9wdGlvbnMpIHtcbiAgICB2YXIgcGFydHMgPSBwYXRocy5tYXAoZnVuY3Rpb24gKHBhdGgpIHsgcmV0dXJuIHBhdGhUb1JlZ2V4cChwYXRoLCBrZXlzLCBvcHRpb25zKS5zb3VyY2U7IH0pO1xuICAgIHJldHVybiBuZXcgUmVnRXhwKFwiKD86XCIgKyBwYXJ0cy5qb2luKFwifFwiKSArIFwiKVwiLCBmbGFncyhvcHRpb25zKSk7XG59XG4vKipcbiAqIENyZWF0ZSBhIHBhdGggcmVnZXhwIGZyb20gc3RyaW5nIGlucHV0LlxuICovXG5mdW5jdGlvbiBzdHJpbmdUb1JlZ2V4cChwYXRoLCBrZXlzLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRva2Vuc1RvUmVnZXhwKHBhcnNlKHBhdGgsIG9wdGlvbnMpLCBrZXlzLCBvcHRpb25zKTtcbn1cbi8qKlxuICogRXhwb3NlIGEgZnVuY3Rpb24gZm9yIHRha2luZyB0b2tlbnMgYW5kIHJldHVybmluZyBhIFJlZ0V4cC5cbiAqL1xuZnVuY3Rpb24gdG9rZW5zVG9SZWdleHAodG9rZW5zLCBrZXlzLCBvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkgeyBvcHRpb25zID0ge307IH1cbiAgICB2YXIgX2EgPSBvcHRpb25zLnN0cmljdCwgc3RyaWN0ID0gX2EgPT09IHZvaWQgMCA/IGZhbHNlIDogX2EsIF9iID0gb3B0aW9ucy5zdGFydCwgc3RhcnQgPSBfYiA9PT0gdm9pZCAwID8gdHJ1ZSA6IF9iLCBfYyA9IG9wdGlvbnMuZW5kLCBlbmQgPSBfYyA9PT0gdm9pZCAwID8gdHJ1ZSA6IF9jLCBfZCA9IG9wdGlvbnMuZW5jb2RlLCBlbmNvZGUgPSBfZCA9PT0gdm9pZCAwID8gZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHg7IH0gOiBfZDtcbiAgICB2YXIgZW5kc1dpdGggPSBcIltcIiArIGVzY2FwZVN0cmluZyhvcHRpb25zLmVuZHNXaXRoIHx8IFwiXCIpICsgXCJdfCRcIjtcbiAgICB2YXIgZGVsaW1pdGVyID0gXCJbXCIgKyBlc2NhcGVTdHJpbmcob3B0aW9ucy5kZWxpbWl0ZXIgfHwgXCIvIz9cIikgKyBcIl1cIjtcbiAgICB2YXIgcm91dGUgPSBzdGFydCA/IFwiXlwiIDogXCJcIjtcbiAgICAvLyBJdGVyYXRlIG92ZXIgdGhlIHRva2VucyBhbmQgY3JlYXRlIG91ciByZWdleHAgc3RyaW5nLlxuICAgIGZvciAodmFyIF9pID0gMCwgdG9rZW5zXzEgPSB0b2tlbnM7IF9pIDwgdG9rZW5zXzEubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIHZhciB0b2tlbiA9IHRva2Vuc18xW19pXTtcbiAgICAgICAgaWYgKHR5cGVvZiB0b2tlbiA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgcm91dGUgKz0gZXNjYXBlU3RyaW5nKGVuY29kZSh0b2tlbikpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdmFyIHByZWZpeCA9IGVzY2FwZVN0cmluZyhlbmNvZGUodG9rZW4ucHJlZml4KSk7XG4gICAgICAgICAgICB2YXIgc3VmZml4ID0gZXNjYXBlU3RyaW5nKGVuY29kZSh0b2tlbi5zdWZmaXgpKTtcbiAgICAgICAgICAgIGlmICh0b2tlbi5wYXR0ZXJuKSB7XG4gICAgICAgICAgICAgICAgaWYgKGtleXMpXG4gICAgICAgICAgICAgICAgICAgIGtleXMucHVzaCh0b2tlbik7XG4gICAgICAgICAgICAgICAgaWYgKHByZWZpeCB8fCBzdWZmaXgpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRva2VuLm1vZGlmaWVyID09PSBcIitcIiB8fCB0b2tlbi5tb2RpZmllciA9PT0gXCIqXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtb2QgPSB0b2tlbi5tb2RpZmllciA9PT0gXCIqXCIgPyBcIj9cIiA6IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICByb3V0ZSArPSBcIig/OlwiICsgcHJlZml4ICsgXCIoKD86XCIgKyB0b2tlbi5wYXR0ZXJuICsgXCIpKD86XCIgKyBzdWZmaXggKyBwcmVmaXggKyBcIig/OlwiICsgdG9rZW4ucGF0dGVybiArIFwiKSkqKVwiICsgc3VmZml4ICsgXCIpXCIgKyBtb2Q7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByb3V0ZSArPSBcIig/OlwiICsgcHJlZml4ICsgXCIoXCIgKyB0b2tlbi5wYXR0ZXJuICsgXCIpXCIgKyBzdWZmaXggKyBcIilcIiArIHRva2VuLm1vZGlmaWVyO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByb3V0ZSArPSBcIihcIiArIHRva2VuLnBhdHRlcm4gKyBcIilcIiArIHRva2VuLm1vZGlmaWVyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHJvdXRlICs9IFwiKD86XCIgKyBwcmVmaXggKyBzdWZmaXggKyBcIilcIiArIHRva2VuLm1vZGlmaWVyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChlbmQpIHtcbiAgICAgICAgaWYgKCFzdHJpY3QpXG4gICAgICAgICAgICByb3V0ZSArPSBkZWxpbWl0ZXIgKyBcIj9cIjtcbiAgICAgICAgcm91dGUgKz0gIW9wdGlvbnMuZW5kc1dpdGggPyBcIiRcIiA6IFwiKD89XCIgKyBlbmRzV2l0aCArIFwiKVwiO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgdmFyIGVuZFRva2VuID0gdG9rZW5zW3Rva2Vucy5sZW5ndGggLSAxXTtcbiAgICAgICAgdmFyIGlzRW5kRGVsaW1pdGVkID0gdHlwZW9mIGVuZFRva2VuID09PSBcInN0cmluZ1wiXG4gICAgICAgICAgICA/IGRlbGltaXRlci5pbmRleE9mKGVuZFRva2VuW2VuZFRva2VuLmxlbmd0aCAtIDFdKSA+IC0xXG4gICAgICAgICAgICA6IC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZVxuICAgICAgICAgICAgICAgIGVuZFRva2VuID09PSB1bmRlZmluZWQ7XG4gICAgICAgIGlmICghc3RyaWN0KSB7XG4gICAgICAgICAgICByb3V0ZSArPSBcIig/OlwiICsgZGVsaW1pdGVyICsgXCIoPz1cIiArIGVuZHNXaXRoICsgXCIpKT9cIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWlzRW5kRGVsaW1pdGVkKSB7XG4gICAgICAgICAgICByb3V0ZSArPSBcIig/PVwiICsgZGVsaW1pdGVyICsgXCJ8XCIgKyBlbmRzV2l0aCArIFwiKVwiO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBuZXcgUmVnRXhwKHJvdXRlLCBmbGFncyhvcHRpb25zKSk7XG59XG5leHBvcnRzLnRva2Vuc1RvUmVnZXhwID0gdG9rZW5zVG9SZWdleHA7XG4vKipcbiAqIE5vcm1hbGl6ZSB0aGUgZ2l2ZW4gcGF0aCBzdHJpbmcsIHJldHVybmluZyBhIHJlZ3VsYXIgZXhwcmVzc2lvbi5cbiAqXG4gKiBBbiBlbXB0eSBhcnJheSBjYW4gYmUgcGFzc2VkIGluIGZvciB0aGUga2V5cywgd2hpY2ggd2lsbCBob2xkIHRoZVxuICogcGxhY2Vob2xkZXIga2V5IGRlc2NyaXB0aW9ucy4gRm9yIGV4YW1wbGUsIHVzaW5nIGAvdXNlci86aWRgLCBga2V5c2Agd2lsbFxuICogY29udGFpbiBgW3sgbmFtZTogJ2lkJywgZGVsaW1pdGVyOiAnLycsIG9wdGlvbmFsOiBmYWxzZSwgcmVwZWF0OiBmYWxzZSB9XWAuXG4gKi9cbmZ1bmN0aW9uIHBhdGhUb1JlZ2V4cChwYXRoLCBrZXlzLCBvcHRpb25zKSB7XG4gICAgaWYgKHBhdGggaW5zdGFuY2VvZiBSZWdFeHApXG4gICAgICAgIHJldHVybiByZWdleHBUb1JlZ2V4cChwYXRoLCBrZXlzKTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShwYXRoKSlcbiAgICAgICAgcmV0dXJuIGFycmF5VG9SZWdleHAocGF0aCwga2V5cywgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHN0cmluZ1RvUmVnZXhwKHBhdGgsIGtleXMsIG9wdGlvbnMpO1xufVxuZXhwb3J0cy5wYXRoVG9SZWdleHAgPSBwYXRoVG9SZWdleHA7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCIvKlxuTUlUIExpY2Vuc2VcblxuQ29weXJpZ2h0IChjKSBKYXNvbiBNaWxsZXIgKGh0dHBzOi8vamFzb25mb3JtYXQuY29tLylcblxuUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGEgY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uczpcblxuVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG5cblRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLCBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuKi9cblxuLy8gVGhpcyBmaWxlIGlzIGJhc2VkIG9uIGh0dHBzOi8vZ2l0aHViLmNvbS9kZXZlbG9waXQvbWl0dC9ibG9iL3YxLjEuMy9zcmMvaW5kZXguanNcbi8vIEl0J3MgYmVlbiBlZGl0ZWQgZm9yIHRoZSBuZWVkcyBvZiB0aGlzIHNjcmlwdFxuLy8gU2VlIHRoZSBMSUNFTlNFIGF0IHRoZSB0b3Agb2YgdGhlIGZpbGVcblxudHlwZSBIYW5kbGVyID0gKC4uLmV2dHM6IGFueVtdKSA9PiB2b2lkXG5cbmV4cG9ydCB0eXBlIE1pdHRFbWl0dGVyID0ge1xuICBvbih0eXBlOiBzdHJpbmcsIGhhbmRsZXI6IEhhbmRsZXIpOiB2b2lkXG4gIG9mZih0eXBlOiBzdHJpbmcsIGhhbmRsZXI6IEhhbmRsZXIpOiB2b2lkXG4gIGVtaXQodHlwZTogc3RyaW5nLCAuLi5ldnRzOiBhbnlbXSk6IHZvaWRcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbWl0dCgpOiBNaXR0RW1pdHRlciB7XG4gIGNvbnN0IGFsbDogeyBbczogc3RyaW5nXTogSGFuZGxlcltdIH0gPSBPYmplY3QuY3JlYXRlKG51bGwpXG5cbiAgcmV0dXJuIHtcbiAgICBvbih0eXBlOiBzdHJpbmcsIGhhbmRsZXI6IEhhbmRsZXIpIHtcbiAgICAgIDsoYWxsW3R5cGVdIHx8IChhbGxbdHlwZV0gPSBbXSkpLnB1c2goaGFuZGxlcilcbiAgICB9LFxuXG4gICAgb2ZmKHR5cGU6IHN0cmluZywgaGFuZGxlcjogSGFuZGxlcikge1xuICAgICAgaWYgKGFsbFt0eXBlXSkge1xuICAgICAgICBhbGxbdHlwZV0uc3BsaWNlKGFsbFt0eXBlXS5pbmRleE9mKGhhbmRsZXIpID4+PiAwLCAxKVxuICAgICAgfVxuICAgIH0sXG5cbiAgICBlbWl0KHR5cGU6IHN0cmluZywgLi4uZXZ0czogYW55W10pIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBhcnJheS1jYWxsYmFjay1yZXR1cm5cbiAgICAgIDsoYWxsW3R5cGVdIHx8IFtdKS5zbGljZSgpLm1hcCgoaGFuZGxlcjogSGFuZGxlcikgPT4ge1xuICAgICAgICBoYW5kbGVyKC4uLmV2dHMpXG4gICAgICB9KVxuICAgIH0sXG4gIH1cbn1cbiIsIi8qIGdsb2JhbCBfX05FWFRfREFUQV9fICovXG4vLyB0c2xpbnQ6ZGlzYWJsZTpuby1jb25zb2xlXG5pbXBvcnQgeyBQYXJzZWRVcmxRdWVyeSB9IGZyb20gJ3F1ZXJ5c3RyaW5nJ1xuaW1wb3J0IHsgQ29tcG9uZW50VHlwZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgVXJsT2JqZWN0IH0gZnJvbSAndXJsJ1xuaW1wb3J0IHtcbiAgbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2gsXG4gIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoLFxufSBmcm9tICcuLi8uLi8uLi9jbGllbnQvbm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoJ1xuaW1wb3J0IHsgR29vZFBhZ2VDYWNoZSwgU3R5bGVTaGVldFR1cGxlIH0gZnJvbSAnLi4vLi4vLi4vY2xpZW50L3BhZ2UtbG9hZGVyJ1xuaW1wb3J0IHsgZGVub3JtYWxpemVQYWdlUGF0aCB9IGZyb20gJy4uLy4uL3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGgnXG5pbXBvcnQgbWl0dCwgeyBNaXR0RW1pdHRlciB9IGZyb20gJy4uL21pdHQnXG5pbXBvcnQge1xuICBBcHBDb250ZXh0VHlwZSxcbiAgZm9ybWF0V2l0aFZhbGlkYXRpb24sXG4gIGdldExvY2F0aW9uT3JpZ2luLFxuICBnZXRVUkwsXG4gIGxvYWRHZXRJbml0aWFsUHJvcHMsXG4gIE5leHRQYWdlQ29udGV4dCxcbiAgU1QsXG59IGZyb20gJy4uL3V0aWxzJ1xuaW1wb3J0IHsgaXNEeW5hbWljUm91dGUgfSBmcm9tICcuL3V0aWxzL2lzLWR5bmFtaWMnXG5pbXBvcnQgeyBwYXJzZVJlbGF0aXZlVXJsIH0gZnJvbSAnLi91dGlscy9wYXJzZS1yZWxhdGl2ZS11cmwnXG5pbXBvcnQgeyBzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5IH0gZnJvbSAnLi91dGlscy9xdWVyeXN0cmluZydcbmltcG9ydCByZXNvbHZlUmV3cml0ZXMgZnJvbSAnLi91dGlscy9yZXNvbHZlLXJld3JpdGVzJ1xuaW1wb3J0IHsgZ2V0Um91dGVNYXRjaGVyIH0gZnJvbSAnLi91dGlscy9yb3V0ZS1tYXRjaGVyJ1xuaW1wb3J0IHsgZ2V0Um91dGVSZWdleCB9IGZyb20gJy4vdXRpbHMvcm91dGUtcmVnZXgnXG5pbXBvcnQgZXNjYXBlUGF0aERlbGltaXRlcnMgZnJvbSAnLi91dGlscy9lc2NhcGUtcGF0aC1kZWxpbWl0ZXJzJ1xuXG5pbnRlcmZhY2UgVHJhbnNpdGlvbk9wdGlvbnMge1xuICBzaGFsbG93PzogYm9vbGVhblxufVxuXG5pbnRlcmZhY2UgTmV4dEhpc3RvcnlTdGF0ZSB7XG4gIHVybDogc3RyaW5nXG4gIGFzOiBzdHJpbmdcbiAgb3B0aW9uczogVHJhbnNpdGlvbk9wdGlvbnNcbn1cblxudHlwZSBIaXN0b3J5U3RhdGUgPSBudWxsIHwgeyBfX046IGZhbHNlIH0gfCAoeyBfX046IHRydWUgfSAmIE5leHRIaXN0b3J5U3RhdGUpXG5cbmNvbnN0IGJhc2VQYXRoID0gKHByb2Nlc3MuZW52Ll9fTkVYVF9ST1VURVJfQkFTRVBBVEggYXMgc3RyaW5nKSB8fCAnJ1xuXG5mdW5jdGlvbiBidWlsZENhbmNlbGxhdGlvbkVycm9yKCkge1xuICByZXR1cm4gT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoJ1JvdXRlIENhbmNlbGxlZCcpLCB7XG4gICAgY2FuY2VsbGVkOiB0cnVlLFxuICB9KVxufVxuXG5mdW5jdGlvbiBhZGRQYXRoUHJlZml4KHBhdGg6IHN0cmluZywgcHJlZml4Pzogc3RyaW5nKSB7XG4gIHJldHVybiBwcmVmaXggJiYgcGF0aC5zdGFydHNXaXRoKCcvJylcbiAgICA/IHBhdGggPT09ICcvJ1xuICAgICAgPyBub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaChwcmVmaXgpXG4gICAgICA6IGAke3ByZWZpeH0ke3BhdGh9YFxuICAgIDogcGF0aFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkTG9jYWxlKFxuICBwYXRoOiBzdHJpbmcsXG4gIGxvY2FsZT86IHN0cmluZyxcbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZ1xuKSB7XG4gIGlmIChwcm9jZXNzLmVudi5fX05FWFRfaTE4bl9TVVBQT1JUKSB7XG4gICAgcmV0dXJuIGxvY2FsZSAmJiBsb2NhbGUgIT09IGRlZmF1bHRMb2NhbGUgJiYgIXBhdGguc3RhcnRzV2l0aCgnLycgKyBsb2NhbGUpXG4gICAgICA/IGFkZFBhdGhQcmVmaXgocGF0aCwgJy8nICsgbG9jYWxlKVxuICAgICAgOiBwYXRoXG4gIH1cbiAgcmV0dXJuIHBhdGhcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlbExvY2FsZShwYXRoOiBzdHJpbmcsIGxvY2FsZT86IHN0cmluZykge1xuICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX2kxOG5fU1VQUE9SVCkge1xuICAgIHJldHVybiBsb2NhbGUgJiYgcGF0aC5zdGFydHNXaXRoKCcvJyArIGxvY2FsZSlcbiAgICAgID8gcGF0aC5zdWJzdHIobG9jYWxlLmxlbmd0aCArIDEpIHx8ICcvJ1xuICAgICAgOiBwYXRoXG4gIH1cbiAgcmV0dXJuIHBhdGhcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGhhc0Jhc2VQYXRoKHBhdGg6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gcGF0aCA9PT0gYmFzZVBhdGggfHwgcGF0aC5zdGFydHNXaXRoKGJhc2VQYXRoICsgJy8nKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkQmFzZVBhdGgocGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gd2Ugb25seSBhZGQgdGhlIGJhc2VwYXRoIG9uIHJlbGF0aXZlIHVybHNcbiAgcmV0dXJuIGFkZFBhdGhQcmVmaXgocGF0aCwgYmFzZVBhdGgpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWxCYXNlUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gcGF0aC5zbGljZShiYXNlUGF0aC5sZW5ndGgpIHx8ICcvJ1xufVxuXG4vKipcbiAqIERldGVjdHMgd2hldGhlciBhIGdpdmVuIHVybCBpcyByb3V0YWJsZSBieSB0aGUgTmV4dC5qcyByb3V0ZXIgKGJyb3dzZXIgb25seSkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0xvY2FsVVJMKHVybDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGlmICh1cmwuc3RhcnRzV2l0aCgnLycpKSByZXR1cm4gdHJ1ZVxuICB0cnkge1xuICAgIC8vIGFic29sdXRlIHVybHMgY2FuIGJlIGxvY2FsIGlmIHRoZXkgYXJlIG9uIHRoZSBzYW1lIG9yaWdpblxuICAgIGNvbnN0IGxvY2F0aW9uT3JpZ2luID0gZ2V0TG9jYXRpb25PcmlnaW4oKVxuICAgIGNvbnN0IHJlc29sdmVkID0gbmV3IFVSTCh1cmwsIGxvY2F0aW9uT3JpZ2luKVxuICAgIHJldHVybiByZXNvbHZlZC5vcmlnaW4gPT09IGxvY2F0aW9uT3JpZ2luICYmIGhhc0Jhc2VQYXRoKHJlc29sdmVkLnBhdGhuYW1lKVxuICB9IGNhdGNoIChfKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cbn1cblxudHlwZSBVcmwgPSBVcmxPYmplY3QgfCBzdHJpbmdcblxuZXhwb3J0IGZ1bmN0aW9uIGludGVycG9sYXRlQXMoXG4gIHJvdXRlOiBzdHJpbmcsXG4gIGFzUGF0aG5hbWU6IHN0cmluZyxcbiAgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5XG4pIHtcbiAgbGV0IGludGVycG9sYXRlZFJvdXRlID0gJydcblxuICBjb25zdCBkeW5hbWljUmVnZXggPSBnZXRSb3V0ZVJlZ2V4KHJvdXRlKVxuICBjb25zdCBkeW5hbWljR3JvdXBzID0gZHluYW1pY1JlZ2V4Lmdyb3Vwc1xuICBjb25zdCBkeW5hbWljTWF0Y2hlcyA9XG4gICAgLy8gVHJ5IHRvIG1hdGNoIHRoZSBkeW5hbWljIHJvdXRlIGFnYWluc3QgdGhlIGFzUGF0aFxuICAgIChhc1BhdGhuYW1lICE9PSByb3V0ZSA/IGdldFJvdXRlTWF0Y2hlcihkeW5hbWljUmVnZXgpKGFzUGF0aG5hbWUpIDogJycpIHx8XG4gICAgLy8gRmFsbCBiYWNrIHRvIHJlYWRpbmcgdGhlIHZhbHVlcyBmcm9tIHRoZSBocmVmXG4gICAgLy8gVE9ETzogc2hvdWxkIHRoaXMgdGFrZSBwcmlvcml0eTsgYWxzbyBuZWVkIHRvIGNoYW5nZSBpbiB0aGUgcm91dGVyLlxuICAgIHF1ZXJ5XG5cbiAgaW50ZXJwb2xhdGVkUm91dGUgPSByb3V0ZVxuICBjb25zdCBwYXJhbXMgPSBPYmplY3Qua2V5cyhkeW5hbWljR3JvdXBzKVxuXG4gIGlmIChcbiAgICAhcGFyYW1zLmV2ZXJ5KChwYXJhbSkgPT4ge1xuICAgICAgbGV0IHZhbHVlID0gZHluYW1pY01hdGNoZXNbcGFyYW1dIHx8ICcnXG4gICAgICBjb25zdCB7IHJlcGVhdCwgb3B0aW9uYWwgfSA9IGR5bmFtaWNHcm91cHNbcGFyYW1dXG5cbiAgICAgIC8vIHN1cHBvcnQgc2luZ2xlLWxldmVsIGNhdGNoLWFsbFxuICAgICAgLy8gVE9ETzogbW9yZSByb2J1c3QgaGFuZGxpbmcgZm9yIHVzZXItZXJyb3IgKHBhc3NpbmcgYC9gKVxuICAgICAgbGV0IHJlcGxhY2VkID0gYFske3JlcGVhdCA/ICcuLi4nIDogJyd9JHtwYXJhbX1dYFxuICAgICAgaWYgKG9wdGlvbmFsKSB7XG4gICAgICAgIHJlcGxhY2VkID0gYCR7IXZhbHVlID8gJy8nIDogJyd9WyR7cmVwbGFjZWR9XWBcbiAgICAgIH1cbiAgICAgIGlmIChyZXBlYXQgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpKSB2YWx1ZSA9IFt2YWx1ZV1cblxuICAgICAgcmV0dXJuIChcbiAgICAgICAgKG9wdGlvbmFsIHx8IHBhcmFtIGluIGR5bmFtaWNNYXRjaGVzKSAmJlxuICAgICAgICAvLyBJbnRlcnBvbGF0ZSBncm91cCBpbnRvIGRhdGEgVVJMIGlmIHByZXNlbnRcbiAgICAgICAgKGludGVycG9sYXRlZFJvdXRlID1cbiAgICAgICAgICBpbnRlcnBvbGF0ZWRSb3V0ZSEucmVwbGFjZShcbiAgICAgICAgICAgIHJlcGxhY2VkLFxuICAgICAgICAgICAgcmVwZWF0XG4gICAgICAgICAgICAgID8gKHZhbHVlIGFzIHN0cmluZ1tdKS5tYXAoZXNjYXBlUGF0aERlbGltaXRlcnMpLmpvaW4oJy8nKVxuICAgICAgICAgICAgICA6IGVzY2FwZVBhdGhEZWxpbWl0ZXJzKHZhbHVlIGFzIHN0cmluZylcbiAgICAgICAgICApIHx8ICcvJylcbiAgICAgIClcbiAgICB9KVxuICApIHtcbiAgICBpbnRlcnBvbGF0ZWRSb3V0ZSA9ICcnIC8vIGRpZCBub3Qgc2F0aXNmeSBhbGwgcmVxdWlyZW1lbnRzXG5cbiAgICAvLyBuLmIuIFdlIGlnbm9yZSB0aGlzIGVycm9yIGJlY2F1c2Ugd2UgaGFuZGxlIHdhcm5pbmcgZm9yIHRoaXMgY2FzZSBpblxuICAgIC8vIGRldmVsb3BtZW50IGluIHRoZSBgPExpbms+YCBjb21wb25lbnQgZGlyZWN0bHkuXG4gIH1cbiAgcmV0dXJuIHtcbiAgICBwYXJhbXMsXG4gICAgcmVzdWx0OiBpbnRlcnBvbGF0ZWRSb3V0ZSxcbiAgfVxufVxuXG5mdW5jdGlvbiBvbWl0UGFybXNGcm9tUXVlcnkocXVlcnk6IFBhcnNlZFVybFF1ZXJ5LCBwYXJhbXM6IHN0cmluZ1tdKSB7XG4gIGNvbnN0IGZpbHRlcmVkUXVlcnk6IFBhcnNlZFVybFF1ZXJ5ID0ge31cblxuICBPYmplY3Qua2V5cyhxdWVyeSkuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgaWYgKCFwYXJhbXMuaW5jbHVkZXMoa2V5KSkge1xuICAgICAgZmlsdGVyZWRRdWVyeVtrZXldID0gcXVlcnlba2V5XVxuICAgIH1cbiAgfSlcbiAgcmV0dXJuIGZpbHRlcmVkUXVlcnlcbn1cblxuLyoqXG4gKiBSZXNvbHZlcyBhIGdpdmVuIGh5cGVybGluayB3aXRoIGEgY2VydGFpbiByb3V0ZXIgc3RhdGUgKGJhc2VQYXRoIG5vdCBpbmNsdWRlZCkuXG4gKiBQcmVzZXJ2ZXMgYWJzb2x1dGUgdXJscy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIcmVmKFxuICBjdXJyZW50UGF0aDogc3RyaW5nLFxuICBocmVmOiBVcmwsXG4gIHJlc29sdmVBcz86IGJvb2xlYW5cbik6IHN0cmluZyB7XG4gIC8vIHdlIHVzZSBhIGR1bW15IGJhc2UgdXJsIGZvciByZWxhdGl2ZSB1cmxzXG4gIGNvbnN0IGJhc2UgPSBuZXcgVVJMKGN1cnJlbnRQYXRoLCAnaHR0cDovL24nKVxuICBjb25zdCB1cmxBc1N0cmluZyA9XG4gICAgdHlwZW9mIGhyZWYgPT09ICdzdHJpbmcnID8gaHJlZiA6IGZvcm1hdFdpdGhWYWxpZGF0aW9uKGhyZWYpXG4gIHRyeSB7XG4gICAgY29uc3QgZmluYWxVcmwgPSBuZXcgVVJMKHVybEFzU3RyaW5nLCBiYXNlKVxuICAgIGZpbmFsVXJsLnBhdGhuYW1lID0gbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2goZmluYWxVcmwucGF0aG5hbWUpXG4gICAgbGV0IGludGVycG9sYXRlZEFzID0gJydcblxuICAgIGlmIChcbiAgICAgIGlzRHluYW1pY1JvdXRlKGZpbmFsVXJsLnBhdGhuYW1lKSAmJlxuICAgICAgZmluYWxVcmwuc2VhcmNoUGFyYW1zICYmXG4gICAgICByZXNvbHZlQXNcbiAgICApIHtcbiAgICAgIGNvbnN0IHF1ZXJ5ID0gc2VhcmNoUGFyYW1zVG9VcmxRdWVyeShmaW5hbFVybC5zZWFyY2hQYXJhbXMpXG5cbiAgICAgIGNvbnN0IHsgcmVzdWx0LCBwYXJhbXMgfSA9IGludGVycG9sYXRlQXMoXG4gICAgICAgIGZpbmFsVXJsLnBhdGhuYW1lLFxuICAgICAgICBmaW5hbFVybC5wYXRobmFtZSxcbiAgICAgICAgcXVlcnlcbiAgICAgIClcblxuICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICBpbnRlcnBvbGF0ZWRBcyA9IGZvcm1hdFdpdGhWYWxpZGF0aW9uKHtcbiAgICAgICAgICBwYXRobmFtZTogcmVzdWx0LFxuICAgICAgICAgIGhhc2g6IGZpbmFsVXJsLmhhc2gsXG4gICAgICAgICAgcXVlcnk6IG9taXRQYXJtc0Zyb21RdWVyeShxdWVyeSwgcGFyYW1zKSxcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBpZiB0aGUgb3JpZ2luIGRpZG4ndCBjaGFuZ2UsIGl0IG1lYW5zIHdlIHJlY2VpdmVkIGEgcmVsYXRpdmUgaHJlZlxuICAgIGNvbnN0IHJlc29sdmVkSHJlZiA9XG4gICAgICBmaW5hbFVybC5vcmlnaW4gPT09IGJhc2Uub3JpZ2luXG4gICAgICAgID8gZmluYWxVcmwuaHJlZi5zbGljZShmaW5hbFVybC5vcmlnaW4ubGVuZ3RoKVxuICAgICAgICA6IGZpbmFsVXJsLmhyZWZcblxuICAgIHJldHVybiAocmVzb2x2ZUFzXG4gICAgICA/IFtyZXNvbHZlZEhyZWYsIGludGVycG9sYXRlZEFzIHx8IHJlc29sdmVkSHJlZl1cbiAgICAgIDogcmVzb2x2ZWRIcmVmKSBhcyBzdHJpbmdcbiAgfSBjYXRjaCAoXykge1xuICAgIHJldHVybiAocmVzb2x2ZUFzID8gW3VybEFzU3RyaW5nXSA6IHVybEFzU3RyaW5nKSBhcyBzdHJpbmdcbiAgfVxufVxuXG5jb25zdCBQQUdFX0xPQURfRVJST1IgPSBTeW1ib2woJ1BBR0VfTE9BRF9FUlJPUicpXG5leHBvcnQgZnVuY3Rpb24gbWFya0xvYWRpbmdFcnJvcihlcnI6IEVycm9yKTogRXJyb3Ige1xuICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGVyciwgUEFHRV9MT0FEX0VSUk9SLCB7fSlcbn1cblxuZnVuY3Rpb24gcHJlcGFyZVVybEFzKHJvdXRlcjogTmV4dFJvdXRlciwgdXJsOiBVcmwsIGFzOiBVcmwpIHtcbiAgLy8gSWYgdXJsIGFuZCBhcyBwcm92aWRlZCBhcyBhbiBvYmplY3QgcmVwcmVzZW50YXRpb24sXG4gIC8vIHdlJ2xsIGZvcm1hdCB0aGVtIGludG8gdGhlIHN0cmluZyB2ZXJzaW9uIGhlcmUuXG4gIHJldHVybiB7XG4gICAgdXJsOiBhZGRCYXNlUGF0aChyZXNvbHZlSHJlZihyb3V0ZXIucGF0aG5hbWUsIHVybCkpLFxuICAgIGFzOiBhcyA/IGFkZEJhc2VQYXRoKHJlc29sdmVIcmVmKHJvdXRlci5wYXRobmFtZSwgYXMpKSA6IGFzLFxuICB9XG59XG5cbmV4cG9ydCB0eXBlIEJhc2VSb3V0ZXIgPSB7XG4gIHJvdXRlOiBzdHJpbmdcbiAgcGF0aG5hbWU6IHN0cmluZ1xuICBxdWVyeTogUGFyc2VkVXJsUXVlcnlcbiAgYXNQYXRoOiBzdHJpbmdcbiAgYmFzZVBhdGg6IHN0cmluZ1xuICBsb2NhbGU/OiBzdHJpbmdcbiAgbG9jYWxlcz86IHN0cmluZ1tdXG4gIGRlZmF1bHRMb2NhbGU/OiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgTmV4dFJvdXRlciA9IEJhc2VSb3V0ZXIgJlxuICBQaWNrPFxuICAgIFJvdXRlcixcbiAgICB8ICdwdXNoJ1xuICAgIHwgJ3JlcGxhY2UnXG4gICAgfCAncmVsb2FkJ1xuICAgIHwgJ2JhY2snXG4gICAgfCAncHJlZmV0Y2gnXG4gICAgfCAnYmVmb3JlUG9wU3RhdGUnXG4gICAgfCAnZXZlbnRzJ1xuICAgIHwgJ2lzRmFsbGJhY2snXG4gID5cblxuZXhwb3J0IHR5cGUgUHJlZmV0Y2hPcHRpb25zID0ge1xuICBwcmlvcml0eT86IGJvb2xlYW5cbn1cblxuZXhwb3J0IHR5cGUgUHJpdmF0ZVJvdXRlSW5mbyA9IHtcbiAgQ29tcG9uZW50OiBDb21wb25lbnRUeXBlXG4gIHN0eWxlU2hlZXRzOiBTdHlsZVNoZWV0VHVwbGVbXVxuICBfX05fU1NHPzogYm9vbGVhblxuICBfX05fU1NQPzogYm9vbGVhblxuICBwcm9wcz86IFJlY29yZDxzdHJpbmcsIGFueT5cbiAgZXJyPzogRXJyb3JcbiAgZXJyb3I/OiBhbnlcbn1cblxuZXhwb3J0IHR5cGUgQXBwUHJvcHMgPSBQaWNrPFByaXZhdGVSb3V0ZUluZm8sICdDb21wb25lbnQnIHwgJ2Vycic+ICYge1xuICByb3V0ZXI6IFJvdXRlclxufSAmIFJlY29yZDxzdHJpbmcsIGFueT5cbmV4cG9ydCB0eXBlIEFwcENvbXBvbmVudCA9IENvbXBvbmVudFR5cGU8QXBwUHJvcHM+XG5cbnR5cGUgU3Vic2NyaXB0aW9uID0gKGRhdGE6IFByaXZhdGVSb3V0ZUluZm8sIEFwcDogQXBwQ29tcG9uZW50KSA9PiBQcm9taXNlPHZvaWQ+XG5cbnR5cGUgQmVmb3JlUG9wU3RhdGVDYWxsYmFjayA9IChzdGF0ZTogTmV4dEhpc3RvcnlTdGF0ZSkgPT4gYm9vbGVhblxuXG50eXBlIENvbXBvbmVudExvYWRDYW5jZWwgPSAoKCkgPT4gdm9pZCkgfCBudWxsXG5cbnR5cGUgSGlzdG9yeU1ldGhvZCA9ICdyZXBsYWNlU3RhdGUnIHwgJ3B1c2hTdGF0ZSdcblxuY29uc3QgbWFudWFsU2Nyb2xsUmVzdG9yYXRpb24gPVxuICBwcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OICYmXG4gIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gICdzY3JvbGxSZXN0b3JhdGlvbicgaW4gd2luZG93Lmhpc3RvcnlcblxuZnVuY3Rpb24gZmV0Y2hSZXRyeSh1cmw6IHN0cmluZywgYXR0ZW1wdHM6IG51bWJlcik6IFByb21pc2U8YW55PiB7XG4gIHJldHVybiBmZXRjaCh1cmwsIHtcbiAgICAvLyBDb29raWVzIGFyZSByZXF1aXJlZCB0byBiZSBwcmVzZW50IGZvciBOZXh0LmpzJyBTU0cgXCJQcmV2aWV3IE1vZGVcIi5cbiAgICAvLyBDb29raWVzIG1heSBhbHNvIGJlIHJlcXVpcmVkIGZvciBgZ2V0U2VydmVyU2lkZVByb3BzYC5cbiAgICAvL1xuICAgIC8vID4gYGZldGNoYCB3b27igJl0IHNlbmQgY29va2llcywgdW5sZXNzIHlvdSBzZXQgdGhlIGNyZWRlbnRpYWxzIGluaXRcbiAgICAvLyA+IG9wdGlvbi5cbiAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvRmV0Y2hfQVBJL1VzaW5nX0ZldGNoXG4gICAgLy9cbiAgICAvLyA+IEZvciBtYXhpbXVtIGJyb3dzZXIgY29tcGF0aWJpbGl0eSB3aGVuIGl0IGNvbWVzIHRvIHNlbmRpbmcgJlxuICAgIC8vID4gcmVjZWl2aW5nIGNvb2tpZXMsIGFsd2F5cyBzdXBwbHkgdGhlIGBjcmVkZW50aWFsczogJ3NhbWUtb3JpZ2luJ2BcbiAgICAvLyA+IG9wdGlvbiBpbnN0ZWFkIG9mIHJlbHlpbmcgb24gdGhlIGRlZmF1bHQuXG4gICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9mZXRjaCNjYXZlYXRzXG4gICAgY3JlZGVudGlhbHM6ICdzYW1lLW9yaWdpbicsXG4gIH0pLnRoZW4oKHJlcykgPT4ge1xuICAgIGlmICghcmVzLm9rKSB7XG4gICAgICBpZiAoYXR0ZW1wdHMgPiAxICYmIHJlcy5zdGF0dXMgPj0gNTAwKSB7XG4gICAgICAgIHJldHVybiBmZXRjaFJldHJ5KHVybCwgYXR0ZW1wdHMgLSAxKVxuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gbG9hZCBzdGF0aWMgcHJvcHNgKVxuICAgIH1cblxuICAgIHJldHVybiByZXMuanNvbigpXG4gIH0pXG59XG5cbmZ1bmN0aW9uIGZldGNoTmV4dERhdGEoZGF0YUhyZWY6IHN0cmluZywgaXNTZXJ2ZXJSZW5kZXI6IGJvb2xlYW4pIHtcbiAgcmV0dXJuIGZldGNoUmV0cnkoZGF0YUhyZWYsIGlzU2VydmVyUmVuZGVyID8gMyA6IDEpLmNhdGNoKChlcnI6IEVycm9yKSA9PiB7XG4gICAgLy8gV2Ugc2hvdWxkIG9ubHkgdHJpZ2dlciBhIHNlcnZlci1zaWRlIHRyYW5zaXRpb24gaWYgdGhpcyB3YXMgY2F1c2VkXG4gICAgLy8gb24gYSBjbGllbnQtc2lkZSB0cmFuc2l0aW9uLiBPdGhlcndpc2UsIHdlJ2QgZ2V0IGludG8gYW4gaW5maW5pdGVcbiAgICAvLyBsb29wLlxuICAgIGlmICghaXNTZXJ2ZXJSZW5kZXIpIHtcbiAgICAgIG1hcmtMb2FkaW5nRXJyb3IoZXJyKVxuICAgIH1cbiAgICB0aHJvdyBlcnJcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUm91dGVyIGltcGxlbWVudHMgQmFzZVJvdXRlciB7XG4gIHJvdXRlOiBzdHJpbmdcbiAgcGF0aG5hbWU6IHN0cmluZ1xuICBxdWVyeTogUGFyc2VkVXJsUXVlcnlcbiAgYXNQYXRoOiBzdHJpbmdcbiAgYmFzZVBhdGg6IHN0cmluZ1xuXG4gIC8qKlxuICAgKiBNYXAgb2YgYWxsIGNvbXBvbmVudHMgbG9hZGVkIGluIGBSb3V0ZXJgXG4gICAqL1xuICBjb21wb25lbnRzOiB7IFtwYXRobmFtZTogc3RyaW5nXTogUHJpdmF0ZVJvdXRlSW5mbyB9XG4gIC8vIFN0YXRpYyBEYXRhIENhY2hlXG4gIHNkYzogeyBbYXNQYXRoOiBzdHJpbmddOiBvYmplY3QgfSA9IHt9XG4gIHN1YjogU3Vic2NyaXB0aW9uXG4gIGNsYzogQ29tcG9uZW50TG9hZENhbmNlbFxuICBwYWdlTG9hZGVyOiBhbnlcbiAgX2JwczogQmVmb3JlUG9wU3RhdGVDYWxsYmFjayB8IHVuZGVmaW5lZFxuICBldmVudHM6IE1pdHRFbWl0dGVyXG4gIF93cmFwQXBwOiAoQXBwOiBBcHBDb21wb25lbnQpID0+IGFueVxuICBpc1NzcjogYm9vbGVhblxuICBpc0ZhbGxiYWNrOiBib29sZWFuXG4gIF9pbkZsaWdodFJvdXRlPzogc3RyaW5nXG4gIF9zaGFsbG93PzogYm9vbGVhblxuICBsb2NhbGU/OiBzdHJpbmdcbiAgbG9jYWxlcz86IHN0cmluZ1tdXG4gIGRlZmF1bHRMb2NhbGU/OiBzdHJpbmdcblxuICBzdGF0aWMgZXZlbnRzOiBNaXR0RW1pdHRlciA9IG1pdHQoKVxuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHBhdGhuYW1lOiBzdHJpbmcsXG4gICAgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5LFxuICAgIGFzOiBzdHJpbmcsXG4gICAge1xuICAgICAgaW5pdGlhbFByb3BzLFxuICAgICAgcGFnZUxvYWRlcixcbiAgICAgIEFwcCxcbiAgICAgIHdyYXBBcHAsXG4gICAgICBDb21wb25lbnQsXG4gICAgICBpbml0aWFsU3R5bGVTaGVldHMsXG4gICAgICBlcnIsXG4gICAgICBzdWJzY3JpcHRpb24sXG4gICAgICBpc0ZhbGxiYWNrLFxuICAgICAgbG9jYWxlLFxuICAgICAgbG9jYWxlcyxcbiAgICAgIGRlZmF1bHRMb2NhbGUsXG4gICAgfToge1xuICAgICAgc3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb25cbiAgICAgIGluaXRpYWxQcm9wczogYW55XG4gICAgICBwYWdlTG9hZGVyOiBhbnlcbiAgICAgIENvbXBvbmVudDogQ29tcG9uZW50VHlwZVxuICAgICAgaW5pdGlhbFN0eWxlU2hlZXRzOiBTdHlsZVNoZWV0VHVwbGVbXVxuICAgICAgQXBwOiBBcHBDb21wb25lbnRcbiAgICAgIHdyYXBBcHA6IChBcHA6IEFwcENvbXBvbmVudCkgPT4gYW55XG4gICAgICBlcnI/OiBFcnJvclxuICAgICAgaXNGYWxsYmFjazogYm9vbGVhblxuICAgICAgbG9jYWxlPzogc3RyaW5nXG4gICAgICBsb2NhbGVzPzogc3RyaW5nW11cbiAgICAgIGRlZmF1bHRMb2NhbGU/OiBzdHJpbmdcbiAgICB9XG4gICkge1xuICAgIC8vIHJlcHJlc2VudHMgdGhlIGN1cnJlbnQgY29tcG9uZW50IGtleVxuICAgIHRoaXMucm91dGUgPSByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZSlcblxuICAgIC8vIHNldCB1cCB0aGUgY29tcG9uZW50IGNhY2hlIChieSByb3V0ZSBrZXlzKVxuICAgIHRoaXMuY29tcG9uZW50cyA9IHt9XG4gICAgLy8gV2Ugc2hvdWxkIG5vdCBrZWVwIHRoZSBjYWNoZSwgaWYgdGhlcmUncyBhbiBlcnJvclxuICAgIC8vIE90aGVyd2lzZSwgdGhpcyBjYXVzZSBpc3N1ZXMgd2hlbiB3aGVuIGdvaW5nIGJhY2sgYW5kXG4gICAgLy8gY29tZSBhZ2FpbiB0byB0aGUgZXJyb3JlZCBwYWdlLlxuICAgIGlmIChwYXRobmFtZSAhPT0gJy9fZXJyb3InKSB7XG4gICAgICB0aGlzLmNvbXBvbmVudHNbdGhpcy5yb3V0ZV0gPSB7XG4gICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgc3R5bGVTaGVldHM6IGluaXRpYWxTdHlsZVNoZWV0cyxcbiAgICAgICAgcHJvcHM6IGluaXRpYWxQcm9wcyxcbiAgICAgICAgZXJyLFxuICAgICAgICBfX05fU1NHOiBpbml0aWFsUHJvcHMgJiYgaW5pdGlhbFByb3BzLl9fTl9TU0csXG4gICAgICAgIF9fTl9TU1A6IGluaXRpYWxQcm9wcyAmJiBpbml0aWFsUHJvcHMuX19OX1NTUCxcbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10gPSB7XG4gICAgICBDb21wb25lbnQ6IEFwcCBhcyBDb21wb25lbnRUeXBlLFxuICAgICAgc3R5bGVTaGVldHM6IFtcbiAgICAgICAgLyogL19hcHAgZG9lcyBub3QgbmVlZCBpdHMgc3R5bGVzaGVldHMgbWFuYWdlZCAqL1xuICAgICAgXSxcbiAgICB9XG5cbiAgICAvLyBCYWNrd2FyZHMgY29tcGF0IGZvciBSb3V0ZXIucm91dGVyLmV2ZW50c1xuICAgIC8vIFRPRE86IFNob3VsZCBiZSByZW1vdmUgdGhlIGZvbGxvd2luZyBtYWpvciB2ZXJzaW9uIGFzIGl0IHdhcyBuZXZlciBkb2N1bWVudGVkXG4gICAgdGhpcy5ldmVudHMgPSBSb3V0ZXIuZXZlbnRzXG5cbiAgICB0aGlzLnBhZ2VMb2FkZXIgPSBwYWdlTG9hZGVyXG4gICAgdGhpcy5wYXRobmFtZSA9IHBhdGhuYW1lXG4gICAgdGhpcy5xdWVyeSA9IHF1ZXJ5XG4gICAgLy8gaWYgYXV0byBwcmVyZW5kZXJlZCBhbmQgZHluYW1pYyByb3V0ZSB3YWl0IHRvIHVwZGF0ZSBhc1BhdGhcbiAgICAvLyB1bnRpbCBhZnRlciBtb3VudCB0byBwcmV2ZW50IGh5ZHJhdGlvbiBtaXNtYXRjaFxuICAgIHRoaXMuYXNQYXRoID1cbiAgICAgIC8vIEB0cy1pZ25vcmUgdGhpcyBpcyB0ZW1wb3JhcmlseSBnbG9iYWwgKGF0dGFjaGVkIHRvIHdpbmRvdylcbiAgICAgIGlzRHluYW1pY1JvdXRlKHBhdGhuYW1lKSAmJiBfX05FWFRfREFUQV9fLmF1dG9FeHBvcnQgPyBwYXRobmFtZSA6IGFzXG4gICAgdGhpcy5iYXNlUGF0aCA9IGJhc2VQYXRoXG4gICAgdGhpcy5zdWIgPSBzdWJzY3JpcHRpb25cbiAgICB0aGlzLmNsYyA9IG51bGxcbiAgICB0aGlzLl93cmFwQXBwID0gd3JhcEFwcFxuICAgIC8vIG1ha2Ugc3VyZSB0byBpZ25vcmUgZXh0cmEgcG9wU3RhdGUgaW4gc2FmYXJpIG9uIG5hdmlnYXRpbmdcbiAgICAvLyBiYWNrIGZyb20gZXh0ZXJuYWwgc2l0ZVxuICAgIHRoaXMuaXNTc3IgPSB0cnVlXG5cbiAgICB0aGlzLmlzRmFsbGJhY2sgPSBpc0ZhbGxiYWNrXG5cbiAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX2kxOG5fU1VQUE9SVCkge1xuICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGVcbiAgICAgIHRoaXMubG9jYWxlcyA9IGxvY2FsZXNcbiAgICAgIHRoaXMuZGVmYXVsdExvY2FsZSA9IGRlZmF1bHRMb2NhbGVcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIC8vIG1ha2Ugc3VyZSBcImFzXCIgZG9lc24ndCBzdGFydCB3aXRoIGRvdWJsZSBzbGFzaGVzIG9yIGVsc2UgaXQgY2FuXG4gICAgICAvLyB0aHJvdyBhbiBlcnJvciBhcyBpdCdzIGNvbnNpZGVyZWQgaW52YWxpZFxuICAgICAgaWYgKGFzLnN1YnN0cigwLCAyKSAhPT0gJy8vJykge1xuICAgICAgICAvLyBpbiBvcmRlciBmb3IgYGUuc3RhdGVgIHRvIHdvcmsgb24gdGhlIGBvbnBvcHN0YXRlYCBldmVudFxuICAgICAgICAvLyB3ZSBoYXZlIHRvIHJlZ2lzdGVyIHRoZSBpbml0aWFsIHJvdXRlIHVwb24gaW5pdGlhbGl6YXRpb25cbiAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZShcbiAgICAgICAgICAncmVwbGFjZVN0YXRlJyxcbiAgICAgICAgICBmb3JtYXRXaXRoVmFsaWRhdGlvbih7IHBhdGhuYW1lOiBhZGRCYXNlUGF0aChwYXRobmFtZSksIHF1ZXJ5IH0pLFxuICAgICAgICAgIGdldFVSTCgpXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3BvcHN0YXRlJywgdGhpcy5vblBvcFN0YXRlKVxuXG4gICAgICAvLyBlbmFibGUgY3VzdG9tIHNjcm9sbCByZXN0b3JhdGlvbiBoYW5kbGluZyB3aGVuIGF2YWlsYWJsZVxuICAgICAgLy8gb3RoZXJ3aXNlIGZhbGxiYWNrIHRvIGJyb3dzZXIncyBkZWZhdWx0IGhhbmRsaW5nXG4gICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTikge1xuICAgICAgICBpZiAobWFudWFsU2Nyb2xsUmVzdG9yYXRpb24pIHtcbiAgICAgICAgICB3aW5kb3cuaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9ICdtYW51YWwnXG5cbiAgICAgICAgICBsZXQgc2Nyb2xsRGVib3VuY2VUaW1lb3V0OiB1bmRlZmluZWQgfCBOb2RlSlMuVGltZW91dFxuXG4gICAgICAgICAgY29uc3QgZGVib3VuY2VkU2Nyb2xsU2F2ZSA9ICgpID0+IHtcbiAgICAgICAgICAgIGlmIChzY3JvbGxEZWJvdW5jZVRpbWVvdXQpIGNsZWFyVGltZW91dChzY3JvbGxEZWJvdW5jZVRpbWVvdXQpXG5cbiAgICAgICAgICAgIHNjcm9sbERlYm91bmNlVGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCB7IHVybCwgYXM6IGN1ckFzLCBvcHRpb25zIH0gPSBoaXN0b3J5LnN0YXRlXG4gICAgICAgICAgICAgIHRoaXMuY2hhbmdlU3RhdGUoXG4gICAgICAgICAgICAgICAgJ3JlcGxhY2VTdGF0ZScsXG4gICAgICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgICAgIGN1ckFzLFxuICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oe30sIG9wdGlvbnMsIHtcbiAgICAgICAgICAgICAgICAgIF9OX1g6IHdpbmRvdy5zY3JvbGxYLFxuICAgICAgICAgICAgICAgICAgX05fWTogd2luZG93LnNjcm9sbFksXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfSwgMTApXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGRlYm91bmNlZFNjcm9sbFNhdmUpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBvblBvcFN0YXRlID0gKGU6IFBvcFN0YXRlRXZlbnQpOiB2b2lkID0+IHtcbiAgICBjb25zdCBzdGF0ZSA9IGUuc3RhdGUgYXMgSGlzdG9yeVN0YXRlXG5cbiAgICBpZiAoIXN0YXRlKSB7XG4gICAgICAvLyBXZSBnZXQgc3RhdGUgYXMgdW5kZWZpbmVkIGZvciB0d28gcmVhc29ucy5cbiAgICAgIC8vICAxLiBXaXRoIG9sZGVyIHNhZmFyaSAoPCA4KSBhbmQgb2xkZXIgY2hyb21lICg8IDM0KVxuICAgICAgLy8gIDIuIFdoZW4gdGhlIFVSTCBjaGFuZ2VkIHdpdGggI1xuICAgICAgLy9cbiAgICAgIC8vIEluIHRoZSBib3RoIGNhc2VzLCB3ZSBkb24ndCBuZWVkIHRvIHByb2NlZWQgYW5kIGNoYW5nZSB0aGUgcm91dGUuXG4gICAgICAvLyAoYXMgaXQncyBhbHJlYWR5IGNoYW5nZWQpXG4gICAgICAvLyBCdXQgd2UgY2FuIHNpbXBseSByZXBsYWNlIHRoZSBzdGF0ZSB3aXRoIHRoZSBuZXcgY2hhbmdlcy5cbiAgICAgIC8vIEFjdHVhbGx5LCBmb3IgKDEpIHdlIGRvbid0IG5lZWQgdG8gbm90aGluZy4gQnV0IGl0J3MgaGFyZCB0byBkZXRlY3QgdGhhdCBldmVudC5cbiAgICAgIC8vIFNvLCBkb2luZyB0aGUgZm9sbG93aW5nIGZvciAoMSkgZG9lcyBubyBoYXJtLlxuICAgICAgY29uc3QgeyBwYXRobmFtZSwgcXVlcnkgfSA9IHRoaXNcbiAgICAgIHRoaXMuY2hhbmdlU3RhdGUoXG4gICAgICAgICdyZXBsYWNlU3RhdGUnLFxuICAgICAgICBmb3JtYXRXaXRoVmFsaWRhdGlvbih7IHBhdGhuYW1lOiBhZGRCYXNlUGF0aChwYXRobmFtZSksIHF1ZXJ5IH0pLFxuICAgICAgICBnZXRVUkwoKVxuICAgICAgKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgaWYgKCFzdGF0ZS5fX04pIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGNvbnN0IHsgdXJsLCBhcywgb3B0aW9ucyB9ID0gc3RhdGVcblxuICAgIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHBhcnNlUmVsYXRpdmVVcmwodXJsKVxuXG4gICAgLy8gTWFrZSBzdXJlIHdlIGRvbid0IHJlLXJlbmRlciBvbiBpbml0aWFsIGxvYWQsXG4gICAgLy8gY2FuIGJlIGNhdXNlZCBieSBuYXZpZ2F0aW5nIGJhY2sgZnJvbSBhbiBleHRlcm5hbCBzaXRlXG4gICAgaWYgKHRoaXMuaXNTc3IgJiYgYXMgPT09IHRoaXMuYXNQYXRoICYmIHBhdGhuYW1lID09PSB0aGlzLnBhdGhuYW1lKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICAvLyBJZiB0aGUgZG93bnN0cmVhbSBhcHBsaWNhdGlvbiByZXR1cm5zIGZhbHN5LCByZXR1cm4uXG4gICAgLy8gVGhleSB3aWxsIHRoZW4gYmUgcmVzcG9uc2libGUgZm9yIGhhbmRsaW5nIHRoZSBldmVudC5cbiAgICBpZiAodGhpcy5fYnBzICYmICF0aGlzLl9icHMoc3RhdGUpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICB0aGlzLmNoYW5nZShcbiAgICAgICdyZXBsYWNlU3RhdGUnLFxuICAgICAgdXJsLFxuICAgICAgYXMsXG4gICAgICBPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zLCB7XG4gICAgICAgIHNoYWxsb3c6IG9wdGlvbnMuc2hhbGxvdyAmJiB0aGlzLl9zaGFsbG93LFxuICAgICAgfSlcbiAgICApXG4gIH1cblxuICByZWxvYWQoKTogdm9pZCB7XG4gICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpXG4gIH1cblxuICAvKipcbiAgICogR28gYmFjayBpbiBoaXN0b3J5XG4gICAqL1xuICBiYWNrKCkge1xuICAgIHdpbmRvdy5oaXN0b3J5LmJhY2soKVxuICB9XG5cbiAgLyoqXG4gICAqIFBlcmZvcm1zIGEgYHB1c2hTdGF0ZWAgd2l0aCBhcmd1bWVudHNcbiAgICogQHBhcmFtIHVybCBvZiB0aGUgcm91dGVcbiAgICogQHBhcmFtIGFzIG1hc2tzIGB1cmxgIGZvciB0aGUgYnJvd3NlclxuICAgKiBAcGFyYW0gb3B0aW9ucyBvYmplY3QgeW91IGNhbiBkZWZpbmUgYHNoYWxsb3dgIGFuZCBvdGhlciBvcHRpb25zXG4gICAqL1xuICBwdXNoKHVybDogVXJsLCBhczogVXJsID0gdXJsLCBvcHRpb25zOiBUcmFuc2l0aW9uT3B0aW9ucyA9IHt9KSB7XG4gICAgOyh7IHVybCwgYXMgfSA9IHByZXBhcmVVcmxBcyh0aGlzLCB1cmwsIGFzKSlcbiAgICByZXR1cm4gdGhpcy5jaGFuZ2UoJ3B1c2hTdGF0ZScsIHVybCwgYXMsIG9wdGlvbnMpXG4gIH1cblxuICAvKipcbiAgICogUGVyZm9ybXMgYSBgcmVwbGFjZVN0YXRlYCB3aXRoIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gdXJsIG9mIHRoZSByb3V0ZVxuICAgKiBAcGFyYW0gYXMgbWFza3MgYHVybGAgZm9yIHRoZSBicm93c2VyXG4gICAqIEBwYXJhbSBvcHRpb25zIG9iamVjdCB5b3UgY2FuIGRlZmluZSBgc2hhbGxvd2AgYW5kIG90aGVyIG9wdGlvbnNcbiAgICovXG4gIHJlcGxhY2UodXJsOiBVcmwsIGFzOiBVcmwgPSB1cmwsIG9wdGlvbnM6IFRyYW5zaXRpb25PcHRpb25zID0ge30pIHtcbiAgICA7KHsgdXJsLCBhcyB9ID0gcHJlcGFyZVVybEFzKHRoaXMsIHVybCwgYXMpKVxuICAgIHJldHVybiB0aGlzLmNoYW5nZSgncmVwbGFjZVN0YXRlJywgdXJsLCBhcywgb3B0aW9ucylcbiAgfVxuXG4gIGFzeW5jIGNoYW5nZShcbiAgICBtZXRob2Q6IEhpc3RvcnlNZXRob2QsXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgYXM6IHN0cmluZyxcbiAgICBvcHRpb25zOiBUcmFuc2l0aW9uT3B0aW9uc1xuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICBpZiAoIWlzTG9jYWxVUkwodXJsKSkge1xuICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSB1cmxcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIGlmICghKG9wdGlvbnMgYXMgYW55KS5faCkge1xuICAgICAgdGhpcy5pc1NzciA9IGZhbHNlXG4gICAgfVxuICAgIC8vIG1hcmtpbmcgcm91dGUgY2hhbmdlcyBhcyBhIG5hdmlnYXRpb24gc3RhcnQgZW50cnlcbiAgICBpZiAoU1QpIHtcbiAgICAgIHBlcmZvcm1hbmNlLm1hcmsoJ3JvdXRlQ2hhbmdlJylcbiAgICB9XG5cbiAgICBpZiAodGhpcy5faW5GbGlnaHRSb3V0ZSkge1xuICAgICAgdGhpcy5hYm9ydENvbXBvbmVudExvYWQodGhpcy5faW5GbGlnaHRSb3V0ZSlcbiAgICB9XG5cbiAgICBhcyA9IGFkZExvY2FsZShhcywgdGhpcy5sb2NhbGUsIHRoaXMuZGVmYXVsdExvY2FsZSlcbiAgICBjb25zdCBjbGVhbmVkQXMgPSBkZWxMb2NhbGUoXG4gICAgICBoYXNCYXNlUGF0aChhcykgPyBkZWxCYXNlUGF0aChhcykgOiBhcyxcbiAgICAgIHRoaXMubG9jYWxlXG4gICAgKVxuICAgIHRoaXMuX2luRmxpZ2h0Um91dGUgPSBhc1xuXG4gICAgLy8gSWYgdGhlIHVybCBjaGFuZ2UgaXMgb25seSByZWxhdGVkIHRvIGEgaGFzaCBjaGFuZ2VcbiAgICAvLyBXZSBzaG91bGQgbm90IHByb2NlZWQuIFdlIHNob3VsZCBvbmx5IGNoYW5nZSB0aGUgc3RhdGUuXG5cbiAgICAvLyBXQVJOSU5HOiBgX2hgIGlzIGFuIGludGVybmFsIG9wdGlvbiBmb3IgaGFuZGluZyBOZXh0LmpzIGNsaWVudC1zaWRlXG4gICAgLy8gaHlkcmF0aW9uLiBZb3VyIGFwcCBzaG91bGQgX25ldmVyXyB1c2UgdGhpcyBwcm9wZXJ0eS4gSXQgbWF5IGNoYW5nZSBhdFxuICAgIC8vIGFueSB0aW1lIHdpdGhvdXQgbm90aWNlLlxuICAgIGlmICghKG9wdGlvbnMgYXMgYW55KS5faCAmJiB0aGlzLm9ubHlBSGFzaENoYW5nZShjbGVhbmVkQXMpKSB7XG4gICAgICB0aGlzLmFzUGF0aCA9IGNsZWFuZWRBc1xuICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdoYXNoQ2hhbmdlU3RhcnQnLCBhcylcbiAgICAgIC8vIFRPRE86IGRvIHdlIG5lZWQgdGhlIHJlc29sdmVkIGhyZWYgd2hlbiBvbmx5IGEgaGFzaCBjaGFuZ2U/XG4gICAgICB0aGlzLmNoYW5nZVN0YXRlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucylcbiAgICAgIHRoaXMuc2Nyb2xsVG9IYXNoKGNsZWFuZWRBcylcbiAgICAgIHRoaXMubm90aWZ5KHRoaXMuY29tcG9uZW50c1t0aGlzLnJvdXRlXSlcbiAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgnaGFzaENoYW5nZUNvbXBsZXRlJywgYXMpXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cblxuICAgIC8vIFRoZSBidWlsZCBtYW5pZmVzdCBuZWVkcyB0byBiZSBsb2FkZWQgYmVmb3JlIGF1dG8tc3RhdGljIGR5bmFtaWMgcGFnZXNcbiAgICAvLyBnZXQgdGhlaXIgcXVlcnkgcGFyYW1ldGVycyB0byBhbGxvdyBlbnN1cmluZyB0aGV5IGNhbiBiZSBwYXJzZWQgcHJvcGVybHlcbiAgICAvLyB3aGVuIHJld3JpdHRlbiB0b1xuICAgIGNvbnN0IHBhZ2VzID0gYXdhaXQgdGhpcy5wYWdlTG9hZGVyLmdldFBhZ2VMaXN0KClcbiAgICBjb25zdCB7IF9fcmV3cml0ZXM6IHJld3JpdGVzIH0gPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIucHJvbWlzZWRCdWlsZE1hbmlmZXN0XG5cbiAgICBsZXQgcGFyc2VkID0gcGFyc2VSZWxhdGl2ZVVybCh1cmwpXG5cbiAgICBsZXQgeyBwYXRobmFtZSwgcXVlcnkgfSA9IHBhcnNlZFxuXG4gICAgcGFyc2VkID0gdGhpcy5fcmVzb2x2ZUhyZWYocGFyc2VkLCBwYWdlcykgYXMgdHlwZW9mIHBhcnNlZFxuXG4gICAgaWYgKHBhcnNlZC5wYXRobmFtZSAhPT0gcGF0aG5hbWUpIHtcbiAgICAgIHBhdGhuYW1lID0gcGFyc2VkLnBhdGhuYW1lXG4gICAgICB1cmwgPSBmb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpXG4gICAgfVxuXG4gICAgLy8gdXJsIGFuZCBhcyBzaG91bGQgYWx3YXlzIGJlIHByZWZpeGVkIHdpdGggYmFzZVBhdGggYnkgdGhpc1xuICAgIC8vIHBvaW50IGJ5IGVpdGhlciBuZXh0L2xpbmsgb3Igcm91dGVyLnB1c2gvcmVwbGFjZSBzbyBzdHJpcCB0aGVcbiAgICAvLyBiYXNlUGF0aCBmcm9tIHRoZSBwYXRobmFtZSB0byBtYXRjaCB0aGUgcGFnZXMgZGlyIDEtdG8tMVxuICAgIHBhdGhuYW1lID0gcGF0aG5hbWVcbiAgICAgID8gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2goZGVsQmFzZVBhdGgocGF0aG5hbWUpKVxuICAgICAgOiBwYXRobmFtZVxuXG4gICAgLy8gSWYgYXNrZWQgdG8gY2hhbmdlIHRoZSBjdXJyZW50IFVSTCB3ZSBzaG91bGQgcmVsb2FkIHRoZSBjdXJyZW50IHBhZ2VcbiAgICAvLyAobm90IGxvY2F0aW9uLnJlbG9hZCgpIGJ1dCByZWxvYWQgZ2V0SW5pdGlhbFByb3BzIGFuZCBvdGhlciBOZXh0LmpzIHN0dWZmcylcbiAgICAvLyBXZSBhbHNvIG5lZWQgdG8gc2V0IHRoZSBtZXRob2QgPSByZXBsYWNlU3RhdGUgYWx3YXlzXG4gICAgLy8gYXMgdGhpcyBzaG91bGQgbm90IGdvIGludG8gdGhlIGhpc3RvcnkgKFRoYXQncyBob3cgYnJvd3NlcnMgd29yaylcbiAgICAvLyBXZSBzaG91bGQgY29tcGFyZSB0aGUgbmV3IGFzUGF0aCB0byB0aGUgY3VycmVudCBhc1BhdGgsIG5vdCB0aGUgdXJsXG4gICAgaWYgKCF0aGlzLnVybElzTmV3KGNsZWFuZWRBcykpIHtcbiAgICAgIG1ldGhvZCA9ICdyZXBsYWNlU3RhdGUnXG4gICAgfVxuXG4gICAgbGV0IHJvdXRlID0gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aG5hbWUpXG4gICAgY29uc3QgeyBzaGFsbG93ID0gZmFsc2UgfSA9IG9wdGlvbnNcblxuICAgIC8vIHdlIG5lZWQgdG8gcmVzb2x2ZSB0aGUgYXMgdmFsdWUgdXNpbmcgcmV3cml0ZXMgZm9yIGR5bmFtaWMgU1NHXG4gICAgLy8gcGFnZXMgdG8gYWxsb3cgYnVpbGRpbmcgdGhlIGRhdGEgVVJMIGNvcnJlY3RseVxuICAgIGxldCByZXNvbHZlZEFzID0gYXNcblxuICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSEFTX1JFV1JJVEVTKSB7XG4gICAgICByZXNvbHZlZEFzID0gcmVzb2x2ZVJld3JpdGVzKFxuICAgICAgICBwYXJzZVJlbGF0aXZlVXJsKGFzKS5wYXRobmFtZSxcbiAgICAgICAgcGFnZXMsXG4gICAgICAgIGJhc2VQYXRoLFxuICAgICAgICByZXdyaXRlcyxcbiAgICAgICAgcXVlcnksXG4gICAgICAgIChwOiBzdHJpbmcpID0+IHRoaXMuX3Jlc29sdmVIcmVmKHsgcGF0aG5hbWU6IHAgfSwgcGFnZXMpLnBhdGhuYW1lIVxuICAgICAgKVxuXG4gICAgICBpZiAocmVzb2x2ZWRBcyAhPT0gYXMpIHtcbiAgICAgICAgY29uc3QgcG90ZW50aWFsSHJlZiA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKFxuICAgICAgICAgIHRoaXMuX3Jlc29sdmVIcmVmKFxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbih7fSwgcGFyc2VkLCB7IHBhdGhuYW1lOiByZXNvbHZlZEFzIH0pLFxuICAgICAgICAgICAgcGFnZXMsXG4gICAgICAgICAgICBmYWxzZVxuICAgICAgICAgICkucGF0aG5hbWUhXG4gICAgICAgIClcblxuICAgICAgICAvLyBpZiB0aGlzIGRpcmVjdGx5IG1hdGNoZXMgYSBwYWdlIHdlIG5lZWQgdG8gdXBkYXRlIHRoZSBocmVmIHRvXG4gICAgICAgIC8vIGFsbG93IHRoZSBjb3JyZWN0IHBhZ2UgY2h1bmsgdG8gYmUgbG9hZGVkXG4gICAgICAgIGlmIChwYWdlcy5pbmNsdWRlcyhwb3RlbnRpYWxIcmVmKSkge1xuICAgICAgICAgIHJvdXRlID0gcG90ZW50aWFsSHJlZlxuICAgICAgICAgIHBhdGhuYW1lID0gcG90ZW50aWFsSHJlZlxuICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHBhdGhuYW1lXG4gICAgICAgICAgdXJsID0gZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJlc29sdmVkQXMgPSBkZWxMb2NhbGUoZGVsQmFzZVBhdGgocmVzb2x2ZWRBcyksIHRoaXMubG9jYWxlKVxuXG4gICAgaWYgKGlzRHluYW1pY1JvdXRlKHJvdXRlKSkge1xuICAgICAgY29uc3QgcGFyc2VkQXMgPSBwYXJzZVJlbGF0aXZlVXJsKHJlc29sdmVkQXMpXG4gICAgICBjb25zdCBhc1BhdGhuYW1lID0gcGFyc2VkQXMucGF0aG5hbWVcblxuICAgICAgY29uc3Qgcm91dGVSZWdleCA9IGdldFJvdXRlUmVnZXgocm91dGUpXG4gICAgICBjb25zdCByb3V0ZU1hdGNoID0gZ2V0Um91dGVNYXRjaGVyKHJvdXRlUmVnZXgpKGFzUGF0aG5hbWUpXG4gICAgICBjb25zdCBzaG91bGRJbnRlcnBvbGF0ZSA9IHJvdXRlID09PSBhc1BhdGhuYW1lXG4gICAgICBjb25zdCBpbnRlcnBvbGF0ZWRBcyA9IHNob3VsZEludGVycG9sYXRlXG4gICAgICAgID8gaW50ZXJwb2xhdGVBcyhyb3V0ZSwgYXNQYXRobmFtZSwgcXVlcnkpXG4gICAgICAgIDogKHt9IGFzIHsgcmVzdWx0OiB1bmRlZmluZWQ7IHBhcmFtczogdW5kZWZpbmVkIH0pXG5cbiAgICAgIGlmICghcm91dGVNYXRjaCB8fCAoc2hvdWxkSW50ZXJwb2xhdGUgJiYgIWludGVycG9sYXRlZEFzLnJlc3VsdCkpIHtcbiAgICAgICAgY29uc3QgbWlzc2luZ1BhcmFtcyA9IE9iamVjdC5rZXlzKHJvdXRlUmVnZXguZ3JvdXBzKS5maWx0ZXIoXG4gICAgICAgICAgKHBhcmFtKSA9PiAhcXVlcnlbcGFyYW1dXG4gICAgICAgIClcblxuICAgICAgICBpZiAobWlzc2luZ1BhcmFtcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgYCR7XG4gICAgICAgICAgICAgICAgc2hvdWxkSW50ZXJwb2xhdGVcbiAgICAgICAgICAgICAgICAgID8gYEludGVycG9sYXRpbmcgaHJlZmBcbiAgICAgICAgICAgICAgICAgIDogYE1pc21hdGNoaW5nIFxcYGFzXFxgIGFuZCBcXGBocmVmXFxgYFxuICAgICAgICAgICAgICB9IGZhaWxlZCB0byBtYW51YWxseSBwcm92aWRlIGAgK1xuICAgICAgICAgICAgICAgIGB0aGUgcGFyYW1zOiAke21pc3NpbmdQYXJhbXMuam9pbihcbiAgICAgICAgICAgICAgICAgICcsICdcbiAgICAgICAgICAgICAgICApfSBpbiB0aGUgXFxgaHJlZlxcYCdzIFxcYHF1ZXJ5XFxgYFxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIChzaG91bGRJbnRlcnBvbGF0ZVxuICAgICAgICAgICAgICA/IGBUaGUgcHJvdmlkZWQgXFxgaHJlZlxcYCAoJHt1cmx9KSB2YWx1ZSBpcyBtaXNzaW5nIHF1ZXJ5IHZhbHVlcyAoJHttaXNzaW5nUGFyYW1zLmpvaW4oXG4gICAgICAgICAgICAgICAgICAnLCAnXG4gICAgICAgICAgICAgICAgKX0pIHRvIGJlIGludGVycG9sYXRlZCBwcm9wZXJseS4gYFxuICAgICAgICAgICAgICA6IGBUaGUgcHJvdmlkZWQgXFxgYXNcXGAgdmFsdWUgKCR7YXNQYXRobmFtZX0pIGlzIGluY29tcGF0aWJsZSB3aXRoIHRoZSBcXGBocmVmXFxgIHZhbHVlICgke3JvdXRlfSkuIGApICtcbiAgICAgICAgICAgICAgYFJlYWQgbW9yZTogaHR0cHM6Ly9lcnIuc2gvdmVyY2VsL25leHQuanMvJHtcbiAgICAgICAgICAgICAgICBzaG91bGRJbnRlcnBvbGF0ZVxuICAgICAgICAgICAgICAgICAgPyAnaHJlZi1pbnRlcnBvbGF0aW9uLWZhaWxlZCdcbiAgICAgICAgICAgICAgICAgIDogJ2luY29tcGF0aWJsZS1ocmVmLWFzJ1xuICAgICAgICAgICAgICB9YFxuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChzaG91bGRJbnRlcnBvbGF0ZSkge1xuICAgICAgICBhcyA9IGZvcm1hdFdpdGhWYWxpZGF0aW9uKFxuICAgICAgICAgIE9iamVjdC5hc3NpZ24oe30sIHBhcnNlZEFzLCB7XG4gICAgICAgICAgICBwYXRobmFtZTogaW50ZXJwb2xhdGVkQXMucmVzdWx0LFxuICAgICAgICAgICAgcXVlcnk6IG9taXRQYXJtc0Zyb21RdWVyeShxdWVyeSwgaW50ZXJwb2xhdGVkQXMucGFyYW1zISksXG4gICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gTWVyZ2UgcGFyYW1zIGludG8gYHF1ZXJ5YCwgb3ZlcndyaXRpbmcgYW55IHNwZWNpZmllZCBpbiBzZWFyY2hcbiAgICAgICAgT2JqZWN0LmFzc2lnbihxdWVyeSwgcm91dGVNYXRjaClcbiAgICAgIH1cbiAgICB9XG5cbiAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlU3RhcnQnLCBhcylcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByb3V0ZUluZm8gPSBhd2FpdCB0aGlzLmdldFJvdXRlSW5mbyhcbiAgICAgICAgcm91dGUsXG4gICAgICAgIHBhdGhuYW1lLFxuICAgICAgICBxdWVyeSxcbiAgICAgICAgYXMsXG4gICAgICAgIHNoYWxsb3dcbiAgICAgIClcbiAgICAgIGxldCB7IGVycm9yLCBwcm9wcywgX19OX1NTRywgX19OX1NTUCB9ID0gcm91dGVJbmZvXG5cbiAgICAgIC8vIGhhbmRsZSByZWRpcmVjdCBvbiBjbGllbnQtdHJhbnNpdGlvblxuICAgICAgaWYgKFxuICAgICAgICAoX19OX1NTRyB8fCBfX05fU1NQKSAmJlxuICAgICAgICBwcm9wcyAmJlxuICAgICAgICAocHJvcHMgYXMgYW55KS5wYWdlUHJvcHMgJiZcbiAgICAgICAgKHByb3BzIGFzIGFueSkucGFnZVByb3BzLl9fTl9SRURJUkVDVFxuICAgICAgKSB7XG4gICAgICAgIGNvbnN0IGRlc3RpbmF0aW9uID0gKHByb3BzIGFzIGFueSkucGFnZVByb3BzLl9fTl9SRURJUkVDVFxuXG4gICAgICAgIC8vIGNoZWNrIGlmIGRlc3RpbmF0aW9uIGlzIGludGVybmFsIChyZXNvbHZlcyB0byBhIHBhZ2UpIGFuZCBhdHRlbXB0XG4gICAgICAgIC8vIGNsaWVudC1uYXZpZ2F0aW9uIGlmIGl0IGlzIGZhbGxpbmcgYmFjayB0byBoYXJkIG5hdmlnYXRpb24gaWZcbiAgICAgICAgLy8gaXQncyBub3RcbiAgICAgICAgaWYgKGRlc3RpbmF0aW9uLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgICAgICAgIGNvbnN0IHBhcnNlZEhyZWYgPSBwYXJzZVJlbGF0aXZlVXJsKGRlc3RpbmF0aW9uKVxuICAgICAgICAgIHRoaXMuX3Jlc29sdmVIcmVmKHBhcnNlZEhyZWYsIHBhZ2VzKVxuXG4gICAgICAgICAgaWYgKHBhZ2VzLmluY2x1ZGVzKHBhcnNlZEhyZWYucGF0aG5hbWUpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jaGFuZ2UoXG4gICAgICAgICAgICAgICdyZXBsYWNlU3RhdGUnLFxuICAgICAgICAgICAgICBkZXN0aW5hdGlvbixcbiAgICAgICAgICAgICAgZGVzdGluYXRpb24sXG4gICAgICAgICAgICAgIG9wdGlvbnNcbiAgICAgICAgICAgIClcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGRlc3RpbmF0aW9uXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgoKSA9PiB7fSlcbiAgICAgIH1cblxuICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdiZWZvcmVIaXN0b3J5Q2hhbmdlJywgYXMpXG4gICAgICB0aGlzLmNoYW5nZVN0YXRlKFxuICAgICAgICBtZXRob2QsXG4gICAgICAgIHVybCxcbiAgICAgICAgYWRkTG9jYWxlKGFzLCB0aGlzLmxvY2FsZSwgdGhpcy5kZWZhdWx0TG9jYWxlKSxcbiAgICAgICAgb3B0aW9uc1xuICAgICAgKVxuXG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBjb25zdCBhcHBDb21wOiBhbnkgPSB0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10uQ29tcG9uZW50XG4gICAgICAgIDsod2luZG93IGFzIGFueSkubmV4dC5pc1ByZXJlbmRlcmVkID1cbiAgICAgICAgICBhcHBDb21wLmdldEluaXRpYWxQcm9wcyA9PT0gYXBwQ29tcC5vcmlnR2V0SW5pdGlhbFByb3BzICYmXG4gICAgICAgICAgIShyb3V0ZUluZm8uQ29tcG9uZW50IGFzIGFueSkuZ2V0SW5pdGlhbFByb3BzXG4gICAgICB9XG5cbiAgICAgIGF3YWl0IHRoaXMuc2V0KHJvdXRlLCBwYXRobmFtZSEsIHF1ZXJ5LCBjbGVhbmVkQXMsIHJvdXRlSW5mbykuY2F0Y2goXG4gICAgICAgIChlKSA9PiB7XG4gICAgICAgICAgaWYgKGUuY2FuY2VsbGVkKSBlcnJvciA9IGVycm9yIHx8IGVcbiAgICAgICAgICBlbHNlIHRocm93IGVcbiAgICAgICAgfVxuICAgICAgKVxuXG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgZXJyb3IsIGNsZWFuZWRBcylcbiAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgIH1cblxuICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04pIHtcbiAgICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uICYmICdfTl9YJyBpbiBvcHRpb25zKSB7XG4gICAgICAgICAgd2luZG93LnNjcm9sbFRvKChvcHRpb25zIGFzIGFueSkuX05fWCwgKG9wdGlvbnMgYXMgYW55KS5fTl9ZKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlQ29tcGxldGUnLCBhcylcblxuICAgICAgcmV0dXJuIHRydWVcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIuY2FuY2VsbGVkKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgdGhyb3cgZXJyXG4gICAgfVxuICB9XG5cbiAgY2hhbmdlU3RhdGUoXG4gICAgbWV0aG9kOiBIaXN0b3J5TWV0aG9kLFxuICAgIHVybDogc3RyaW5nLFxuICAgIGFzOiBzdHJpbmcsXG4gICAgb3B0aW9uczogVHJhbnNpdGlvbk9wdGlvbnMgPSB7fVxuICApOiB2b2lkIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgaWYgKHR5cGVvZiB3aW5kb3cuaGlzdG9yeSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgV2FybmluZzogd2luZG93Lmhpc3RvcnkgaXMgbm90IGF2YWlsYWJsZS5gKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgaWYgKHR5cGVvZiB3aW5kb3cuaGlzdG9yeVttZXRob2RdID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBXYXJuaW5nOiB3aW5kb3cuaGlzdG9yeS4ke21ldGhvZH0gaXMgbm90IGF2YWlsYWJsZWApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChtZXRob2QgIT09ICdwdXNoU3RhdGUnIHx8IGdldFVSTCgpICE9PSBhcykge1xuICAgICAgdGhpcy5fc2hhbGxvdyA9IG9wdGlvbnMuc2hhbGxvd1xuICAgICAgd2luZG93Lmhpc3RvcnlbbWV0aG9kXShcbiAgICAgICAge1xuICAgICAgICAgIHVybCxcbiAgICAgICAgICBhcyxcbiAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgIF9fTjogdHJ1ZSxcbiAgICAgICAgfSBhcyBIaXN0b3J5U3RhdGUsXG4gICAgICAgIC8vIE1vc3QgYnJvd3NlcnMgY3VycmVudGx5IGlnbm9yZXMgdGhpcyBwYXJhbWV0ZXIsIGFsdGhvdWdoIHRoZXkgbWF5IHVzZSBpdCBpbiB0aGUgZnV0dXJlLlxuICAgICAgICAvLyBQYXNzaW5nIHRoZSBlbXB0eSBzdHJpbmcgaGVyZSBzaG91bGQgYmUgc2FmZSBhZ2FpbnN0IGZ1dHVyZSBjaGFuZ2VzIHRvIHRoZSBtZXRob2QuXG4gICAgICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IaXN0b3J5L3JlcGxhY2VTdGF0ZVxuICAgICAgICAnJyxcbiAgICAgICAgYXNcbiAgICAgIClcbiAgICB9XG4gIH1cblxuICBhc3luYyBoYW5kbGVSb3V0ZUluZm9FcnJvcihcbiAgICBlcnI6IEVycm9yICYgeyBjb2RlOiBhbnk7IGNhbmNlbGxlZDogYm9vbGVhbiB9LFxuICAgIHBhdGhuYW1lOiBzdHJpbmcsXG4gICAgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5LFxuICAgIGFzOiBzdHJpbmcsXG4gICAgbG9hZEVycm9yRmFpbD86IGJvb2xlYW5cbiAgKTogUHJvbWlzZTxQcml2YXRlUm91dGVJbmZvPiB7XG4gICAgaWYgKGVyci5jYW5jZWxsZWQpIHtcbiAgICAgIC8vIGJ1YmJsZSB1cCBjYW5jZWxsYXRpb24gZXJyb3JzXG4gICAgICB0aHJvdyBlcnJcbiAgICB9XG5cbiAgICBpZiAoUEFHRV9MT0FEX0VSUk9SIGluIGVyciB8fCBsb2FkRXJyb3JGYWlsKSB7XG4gICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlRXJyb3InLCBlcnIsIGFzKVxuXG4gICAgICAvLyBJZiB3ZSBjYW4ndCBsb2FkIHRoZSBwYWdlIGl0IGNvdWxkIGJlIG9uZSBvZiBmb2xsb3dpbmcgcmVhc29uc1xuICAgICAgLy8gIDEuIFBhZ2UgZG9lc24ndCBleGlzdHNcbiAgICAgIC8vICAyLiBQYWdlIGRvZXMgZXhpc3QgaW4gYSBkaWZmZXJlbnQgem9uZVxuICAgICAgLy8gIDMuIEludGVybmFsIGVycm9yIHdoaWxlIGxvYWRpbmcgdGhlIHBhZ2VcblxuICAgICAgLy8gU28sIGRvaW5nIGEgaGFyZCByZWxvYWQgaXMgdGhlIHByb3BlciB3YXkgdG8gZGVhbCB3aXRoIHRoaXMuXG4gICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGFzXG5cbiAgICAgIC8vIENoYW5naW5nIHRoZSBVUkwgZG9lc24ndCBibG9jayBleGVjdXRpbmcgdGhlIGN1cnJlbnQgY29kZSBwYXRoLlxuICAgICAgLy8gU28gbGV0J3MgdGhyb3cgYSBjYW5jZWxsYXRpb24gZXJyb3Igc3RvcCB0aGUgcm91dGluZyBsb2dpYy5cbiAgICAgIHRocm93IGJ1aWxkQ2FuY2VsbGF0aW9uRXJyb3IoKVxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IHBhZ2U6IENvbXBvbmVudCwgc3R5bGVTaGVldHMgfSA9IGF3YWl0IHRoaXMuZmV0Y2hDb21wb25lbnQoXG4gICAgICAgICcvX2Vycm9yJ1xuICAgICAgKVxuICAgICAgY29uc3Qgcm91dGVJbmZvOiBQcml2YXRlUm91dGVJbmZvID0ge1xuICAgICAgICBDb21wb25lbnQsXG4gICAgICAgIHN0eWxlU2hlZXRzLFxuICAgICAgICBlcnIsXG4gICAgICAgIGVycm9yOiBlcnIsXG4gICAgICB9XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IGF3YWl0IHRoaXMuZ2V0SW5pdGlhbFByb3BzKENvbXBvbmVudCwge1xuICAgICAgICAgIGVycixcbiAgICAgICAgICBwYXRobmFtZSxcbiAgICAgICAgICBxdWVyeSxcbiAgICAgICAgfSBhcyBhbnkpXG4gICAgICB9IGNhdGNoIChnaXBFcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgaW4gZXJyb3IgcGFnZSBgZ2V0SW5pdGlhbFByb3BzYDogJywgZ2lwRXJyKVxuICAgICAgICByb3V0ZUluZm8ucHJvcHMgPSB7fVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gcm91dGVJbmZvXG4gICAgfSBjYXRjaCAocm91dGVJbmZvRXJyKSB7XG4gICAgICByZXR1cm4gdGhpcy5oYW5kbGVSb3V0ZUluZm9FcnJvcihyb3V0ZUluZm9FcnIsIHBhdGhuYW1lLCBxdWVyeSwgYXMsIHRydWUpXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2V0Um91dGVJbmZvKFxuICAgIHJvdXRlOiBzdHJpbmcsXG4gICAgcGF0aG5hbWU6IHN0cmluZyxcbiAgICBxdWVyeTogYW55LFxuICAgIGFzOiBzdHJpbmcsXG4gICAgc2hhbGxvdzogYm9vbGVhbiA9IGZhbHNlXG4gICk6IFByb21pc2U8UHJpdmF0ZVJvdXRlSW5mbz4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjYWNoZWRSb3V0ZUluZm8gPSB0aGlzLmNvbXBvbmVudHNbcm91dGVdXG5cbiAgICAgIGlmIChzaGFsbG93ICYmIGNhY2hlZFJvdXRlSW5mbyAmJiB0aGlzLnJvdXRlID09PSByb3V0ZSkge1xuICAgICAgICByZXR1cm4gY2FjaGVkUm91dGVJbmZvXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJvdXRlSW5mbzogUHJpdmF0ZVJvdXRlSW5mbyA9IGNhY2hlZFJvdXRlSW5mb1xuICAgICAgICA/IGNhY2hlZFJvdXRlSW5mb1xuICAgICAgICA6IGF3YWl0IHRoaXMuZmV0Y2hDb21wb25lbnQocm91dGUpLnRoZW4oKHJlcykgPT4gKHtcbiAgICAgICAgICAgIENvbXBvbmVudDogcmVzLnBhZ2UsXG4gICAgICAgICAgICBzdHlsZVNoZWV0czogcmVzLnN0eWxlU2hlZXRzLFxuICAgICAgICAgICAgX19OX1NTRzogcmVzLm1vZC5fX05fU1NHLFxuICAgICAgICAgICAgX19OX1NTUDogcmVzLm1vZC5fX05fU1NQLFxuICAgICAgICAgIH0pKVxuXG4gICAgICBjb25zdCB7IENvbXBvbmVudCwgX19OX1NTRywgX19OX1NTUCB9ID0gcm91dGVJbmZvXG5cbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnN0IHsgaXNWYWxpZEVsZW1lbnRUeXBlIH0gPSByZXF1aXJlKCdyZWFjdC1pcycpXG4gICAgICAgIGlmICghaXNWYWxpZEVsZW1lbnRUeXBlKENvbXBvbmVudCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICBgVGhlIGRlZmF1bHQgZXhwb3J0IGlzIG5vdCBhIFJlYWN0IENvbXBvbmVudCBpbiBwYWdlOiBcIiR7cGF0aG5hbWV9XCJgXG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGxldCBkYXRhSHJlZjogc3RyaW5nIHwgdW5kZWZpbmVkXG5cbiAgICAgIGlmIChfX05fU1NHIHx8IF9fTl9TU1ApIHtcbiAgICAgICAgZGF0YUhyZWYgPSB0aGlzLnBhZ2VMb2FkZXIuZ2V0RGF0YUhyZWYoXG4gICAgICAgICAgZm9ybWF0V2l0aFZhbGlkYXRpb24oeyBwYXRobmFtZSwgcXVlcnkgfSksXG4gICAgICAgICAgZGVsQmFzZVBhdGgoYXMpLFxuICAgICAgICAgIF9fTl9TU0csXG4gICAgICAgICAgdGhpcy5sb2NhbGUsXG4gICAgICAgICAgdGhpcy5kZWZhdWx0TG9jYWxlXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgY29uc3QgcHJvcHMgPSBhd2FpdCB0aGlzLl9nZXREYXRhPFByaXZhdGVSb3V0ZUluZm8+KCgpID0+XG4gICAgICAgIF9fTl9TU0dcbiAgICAgICAgICA/IHRoaXMuX2dldFN0YXRpY0RhdGEoZGF0YUhyZWYhKVxuICAgICAgICAgIDogX19OX1NTUFxuICAgICAgICAgID8gdGhpcy5fZ2V0U2VydmVyRGF0YShkYXRhSHJlZiEpXG4gICAgICAgICAgOiB0aGlzLmdldEluaXRpYWxQcm9wcyhcbiAgICAgICAgICAgICAgQ29tcG9uZW50LFxuICAgICAgICAgICAgICAvLyB3ZSBwcm92aWRlIEFwcFRyZWUgbGF0ZXIgc28gdGhpcyBuZWVkcyB0byBiZSBgYW55YFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICAgICAgcXVlcnksXG4gICAgICAgICAgICAgICAgYXNQYXRoOiBhcyxcbiAgICAgICAgICAgICAgfSBhcyBhbnlcbiAgICAgICAgICAgIClcbiAgICAgIClcblxuICAgICAgcm91dGVJbmZvLnByb3BzID0gcHJvcHNcbiAgICAgIHRoaXMuY29tcG9uZW50c1tyb3V0ZV0gPSByb3V0ZUluZm9cbiAgICAgIHJldHVybiByb3V0ZUluZm9cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHJldHVybiB0aGlzLmhhbmRsZVJvdXRlSW5mb0Vycm9yKGVyciwgcGF0aG5hbWUsIHF1ZXJ5LCBhcylcbiAgICB9XG4gIH1cblxuICBzZXQoXG4gICAgcm91dGU6IHN0cmluZyxcbiAgICBwYXRobmFtZTogc3RyaW5nLFxuICAgIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeSxcbiAgICBhczogc3RyaW5nLFxuICAgIGRhdGE6IFByaXZhdGVSb3V0ZUluZm9cbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy5pc0ZhbGxiYWNrID0gZmFsc2VcblxuICAgIHRoaXMucm91dGUgPSByb3V0ZVxuICAgIHRoaXMucGF0aG5hbWUgPSBwYXRobmFtZVxuICAgIHRoaXMucXVlcnkgPSBxdWVyeVxuICAgIHRoaXMuYXNQYXRoID0gYXNcbiAgICByZXR1cm4gdGhpcy5ub3RpZnkoZGF0YSlcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsYmFjayB0byBleGVjdXRlIGJlZm9yZSByZXBsYWNpbmcgcm91dGVyIHN0YXRlXG4gICAqIEBwYXJhbSBjYiBjYWxsYmFjayB0byBiZSBleGVjdXRlZFxuICAgKi9cbiAgYmVmb3JlUG9wU3RhdGUoY2I6IEJlZm9yZVBvcFN0YXRlQ2FsbGJhY2spIHtcbiAgICB0aGlzLl9icHMgPSBjYlxuICB9XG5cbiAgb25seUFIYXNoQ2hhbmdlKGFzOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICBpZiAoIXRoaXMuYXNQYXRoKSByZXR1cm4gZmFsc2VcbiAgICBjb25zdCBbb2xkVXJsTm9IYXNoLCBvbGRIYXNoXSA9IHRoaXMuYXNQYXRoLnNwbGl0KCcjJylcbiAgICBjb25zdCBbbmV3VXJsTm9IYXNoLCBuZXdIYXNoXSA9IGFzLnNwbGl0KCcjJylcblxuICAgIC8vIE1ha2VzIHN1cmUgd2Ugc2Nyb2xsIHRvIHRoZSBwcm92aWRlZCBoYXNoIGlmIHRoZSB1cmwvaGFzaCBhcmUgdGhlIHNhbWVcbiAgICBpZiAobmV3SGFzaCAmJiBvbGRVcmxOb0hhc2ggPT09IG5ld1VybE5vSGFzaCAmJiBvbGRIYXNoID09PSBuZXdIYXNoKSB7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cblxuICAgIC8vIElmIHRoZSB1cmxzIGFyZSBjaGFuZ2UsIHRoZXJlJ3MgbW9yZSB0aGFuIGEgaGFzaCBjaGFuZ2VcbiAgICBpZiAob2xkVXJsTm9IYXNoICE9PSBuZXdVcmxOb0hhc2gpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIC8vIElmIHRoZSBoYXNoIGhhcyBjaGFuZ2VkLCB0aGVuIGl0J3MgYSBoYXNoIG9ubHkgY2hhbmdlLlxuICAgIC8vIFRoaXMgY2hlY2sgaXMgbmVjZXNzYXJ5IHRvIGhhbmRsZSBib3RoIHRoZSBlbnRlciBhbmRcbiAgICAvLyBsZWF2ZSBoYXNoID09PSAnJyBjYXNlcy4gVGhlIGlkZW50aXR5IGNhc2UgZmFsbHMgdGhyb3VnaFxuICAgIC8vIGFuZCBpcyB0cmVhdGVkIGFzIGEgbmV4dCByZWxvYWQuXG4gICAgcmV0dXJuIG9sZEhhc2ggIT09IG5ld0hhc2hcbiAgfVxuXG4gIHNjcm9sbFRvSGFzaChhczogc3RyaW5nKTogdm9pZCB7XG4gICAgY29uc3QgWywgaGFzaF0gPSBhcy5zcGxpdCgnIycpXG4gICAgLy8gU2Nyb2xsIHRvIHRvcCBpZiB0aGUgaGFzaCBpcyBqdXN0IGAjYCB3aXRoIG5vIHZhbHVlXG4gICAgaWYgKGhhc2ggPT09ICcnKSB7XG4gICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMClcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIC8vIEZpcnN0IHdlIGNoZWNrIGlmIHRoZSBlbGVtZW50IGJ5IGlkIGlzIGZvdW5kXG4gICAgY29uc3QgaWRFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGhhc2gpXG4gICAgaWYgKGlkRWwpIHtcbiAgICAgIGlkRWwuc2Nyb2xsSW50b1ZpZXcoKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIC8vIElmIHRoZXJlJ3Mgbm8gZWxlbWVudCB3aXRoIHRoZSBpZCwgd2UgY2hlY2sgdGhlIGBuYW1lYCBwcm9wZXJ0eVxuICAgIC8vIFRvIG1pcnJvciBicm93c2Vyc1xuICAgIGNvbnN0IG5hbWVFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlOYW1lKGhhc2gpWzBdXG4gICAgaWYgKG5hbWVFbCkge1xuICAgICAgbmFtZUVsLnNjcm9sbEludG9WaWV3KClcbiAgICB9XG4gIH1cblxuICB1cmxJc05ldyhhc1BhdGg6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLmFzUGF0aCAhPT0gYXNQYXRoXG4gIH1cblxuICBfcmVzb2x2ZUhyZWYocGFyc2VkSHJlZjogVXJsT2JqZWN0LCBwYWdlczogc3RyaW5nW10sIGFwcGx5QmFzZVBhdGggPSB0cnVlKSB7XG4gICAgY29uc3QgeyBwYXRobmFtZSB9ID0gcGFyc2VkSHJlZlxuICAgIGNvbnN0IGNsZWFuUGF0aG5hbWUgPSByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChcbiAgICAgIGRlbm9ybWFsaXplUGFnZVBhdGgoYXBwbHlCYXNlUGF0aCA/IGRlbEJhc2VQYXRoKHBhdGhuYW1lISkgOiBwYXRobmFtZSEpXG4gICAgKVxuXG4gICAgaWYgKGNsZWFuUGF0aG5hbWUgPT09ICcvNDA0JyB8fCBjbGVhblBhdGhuYW1lID09PSAnL19lcnJvcicpIHtcbiAgICAgIHJldHVybiBwYXJzZWRIcmVmXG4gICAgfVxuXG4gICAgLy8gaGFuZGxlIHJlc29sdmluZyBocmVmIGZvciBkeW5hbWljIHJvdXRlc1xuICAgIGlmICghcGFnZXMuaW5jbHVkZXMoY2xlYW5QYXRobmFtZSEpKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgYXJyYXktY2FsbGJhY2stcmV0dXJuXG4gICAgICBwYWdlcy5zb21lKChwYWdlKSA9PiB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICBpc0R5bmFtaWNSb3V0ZShwYWdlKSAmJlxuICAgICAgICAgIGdldFJvdXRlUmVnZXgocGFnZSkucmUudGVzdChjbGVhblBhdGhuYW1lISlcbiAgICAgICAgKSB7XG4gICAgICAgICAgcGFyc2VkSHJlZi5wYXRobmFtZSA9IGFwcGx5QmFzZVBhdGggPyBhZGRCYXNlUGF0aChwYWdlKSA6IHBhZ2VcbiAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH1cbiAgICByZXR1cm4gcGFyc2VkSHJlZlxuICB9XG5cbiAgLyoqXG4gICAqIFByZWZldGNoIHBhZ2UgY29kZSwgeW91IG1heSB3YWl0IGZvciB0aGUgZGF0YSBkdXJpbmcgcGFnZSByZW5kZXJpbmcuXG4gICAqIFRoaXMgZmVhdHVyZSBvbmx5IHdvcmtzIGluIHByb2R1Y3Rpb24hXG4gICAqIEBwYXJhbSB1cmwgdGhlIGhyZWYgb2YgcHJlZmV0Y2hlZCBwYWdlXG4gICAqIEBwYXJhbSBhc1BhdGggdGhlIGFzIHBhdGggb2YgdGhlIHByZWZldGNoZWQgcGFnZVxuICAgKi9cbiAgYXN5bmMgcHJlZmV0Y2goXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgYXNQYXRoOiBzdHJpbmcgPSB1cmwsXG4gICAgb3B0aW9uczogUHJlZmV0Y2hPcHRpb25zID0ge31cbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgbGV0IHBhcnNlZCA9IHBhcnNlUmVsYXRpdmVVcmwodXJsKVxuXG4gICAgbGV0IHsgcGF0aG5hbWUgfSA9IHBhcnNlZFxuXG4gICAgY29uc3QgcGFnZXMgPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIuZ2V0UGFnZUxpc3QoKVxuXG4gICAgcGFyc2VkID0gdGhpcy5fcmVzb2x2ZUhyZWYocGFyc2VkLCBwYWdlcykgYXMgdHlwZW9mIHBhcnNlZFxuXG4gICAgaWYgKHBhcnNlZC5wYXRobmFtZSAhPT0gcGF0aG5hbWUpIHtcbiAgICAgIHBhdGhuYW1lID0gcGFyc2VkLnBhdGhuYW1lXG4gICAgICB1cmwgPSBmb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpXG4gICAgfVxuXG4gICAgLy8gUHJlZmV0Y2ggaXMgbm90IHN1cHBvcnRlZCBpbiBkZXZlbG9wbWVudCBtb2RlIGJlY2F1c2UgaXQgd291bGQgdHJpZ2dlciBvbi1kZW1hbmQtZW50cmllc1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCByb3V0ZSA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGhuYW1lKVxuICAgIGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIHRoaXMucGFnZUxvYWRlci5wcmVmZXRjaERhdGEoXG4gICAgICAgIHVybCxcbiAgICAgICAgYXNQYXRoLFxuICAgICAgICB0aGlzLmxvY2FsZSxcbiAgICAgICAgdGhpcy5kZWZhdWx0TG9jYWxlXG4gICAgICApLFxuICAgICAgdGhpcy5wYWdlTG9hZGVyW29wdGlvbnMucHJpb3JpdHkgPyAnbG9hZFBhZ2UnIDogJ3ByZWZldGNoJ10ocm91dGUpLFxuICAgIF0pXG4gIH1cblxuICBhc3luYyBmZXRjaENvbXBvbmVudChyb3V0ZTogc3RyaW5nKTogUHJvbWlzZTxHb29kUGFnZUNhY2hlPiB7XG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlXG4gICAgY29uc3QgY2FuY2VsID0gKHRoaXMuY2xjID0gKCkgPT4ge1xuICAgICAgY2FuY2VsbGVkID0gdHJ1ZVxuICAgIH0pXG5cbiAgICBjb25zdCBjb21wb25lbnRSZXN1bHQgPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIubG9hZFBhZ2Uocm91dGUpXG5cbiAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICBjb25zdCBlcnJvcjogYW55ID0gbmV3IEVycm9yKFxuICAgICAgICBgQWJvcnQgZmV0Y2hpbmcgY29tcG9uZW50IGZvciByb3V0ZTogXCIke3JvdXRlfVwiYFxuICAgICAgKVxuICAgICAgZXJyb3IuY2FuY2VsbGVkID0gdHJ1ZVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG5cbiAgICBpZiAoY2FuY2VsID09PSB0aGlzLmNsYykge1xuICAgICAgdGhpcy5jbGMgPSBudWxsXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbXBvbmVudFJlc3VsdFxuICB9XG5cbiAgX2dldERhdGE8VD4oZm46ICgpID0+IFByb21pc2U8VD4pOiBQcm9taXNlPFQ+IHtcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2VcbiAgICBjb25zdCBjYW5jZWwgPSAoKSA9PiB7XG4gICAgICBjYW5jZWxsZWQgPSB0cnVlXG4gICAgfVxuICAgIHRoaXMuY2xjID0gY2FuY2VsXG4gICAgcmV0dXJuIGZuKCkudGhlbigoZGF0YSkgPT4ge1xuICAgICAgaWYgKGNhbmNlbCA9PT0gdGhpcy5jbGMpIHtcbiAgICAgICAgdGhpcy5jbGMgPSBudWxsXG4gICAgICB9XG5cbiAgICAgIGlmIChjYW5jZWxsZWQpIHtcbiAgICAgICAgY29uc3QgZXJyOiBhbnkgPSBuZXcgRXJyb3IoJ0xvYWRpbmcgaW5pdGlhbCBwcm9wcyBjYW5jZWxsZWQnKVxuICAgICAgICBlcnIuY2FuY2VsbGVkID0gdHJ1ZVxuICAgICAgICB0aHJvdyBlcnJcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGRhdGFcbiAgICB9KVxuICB9XG5cbiAgX2dldFN0YXRpY0RhdGEoZGF0YUhyZWY6IHN0cmluZyk6IFByb21pc2U8b2JqZWN0PiB7XG4gICAgY29uc3QgeyBocmVmOiBjYWNoZUtleSB9ID0gbmV3IFVSTChkYXRhSHJlZiwgd2luZG93LmxvY2F0aW9uLmhyZWYpXG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicgJiYgdGhpcy5zZGNbY2FjaGVLZXldKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMuc2RjW2NhY2hlS2V5XSlcbiAgICB9XG4gICAgcmV0dXJuIGZldGNoTmV4dERhdGEoZGF0YUhyZWYsIHRoaXMuaXNTc3IpLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgIHRoaXMuc2RjW2NhY2hlS2V5XSA9IGRhdGFcbiAgICAgIHJldHVybiBkYXRhXG4gICAgfSlcbiAgfVxuXG4gIF9nZXRTZXJ2ZXJEYXRhKGRhdGFIcmVmOiBzdHJpbmcpOiBQcm9taXNlPG9iamVjdD4ge1xuICAgIHJldHVybiBmZXRjaE5leHREYXRhKGRhdGFIcmVmLCB0aGlzLmlzU3NyKVxuICB9XG5cbiAgZ2V0SW5pdGlhbFByb3BzKFxuICAgIENvbXBvbmVudDogQ29tcG9uZW50VHlwZSxcbiAgICBjdHg6IE5leHRQYWdlQ29udGV4dFxuICApOiBQcm9taXNlPGFueT4ge1xuICAgIGNvbnN0IHsgQ29tcG9uZW50OiBBcHAgfSA9IHRoaXMuY29tcG9uZW50c1snL19hcHAnXVxuICAgIGNvbnN0IEFwcFRyZWUgPSB0aGlzLl93cmFwQXBwKEFwcCBhcyBBcHBDb21wb25lbnQpXG4gICAgY3R4LkFwcFRyZWUgPSBBcHBUcmVlXG4gICAgcmV0dXJuIGxvYWRHZXRJbml0aWFsUHJvcHM8QXBwQ29udGV4dFR5cGU8Um91dGVyPj4oQXBwLCB7XG4gICAgICBBcHBUcmVlLFxuICAgICAgQ29tcG9uZW50LFxuICAgICAgcm91dGVyOiB0aGlzLFxuICAgICAgY3R4LFxuICAgIH0pXG4gIH1cblxuICBhYm9ydENvbXBvbmVudExvYWQoYXM6IHN0cmluZyk6IHZvaWQge1xuICAgIGlmICh0aGlzLmNsYykge1xuICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgYnVpbGRDYW5jZWxsYXRpb25FcnJvcigpLCBhcylcbiAgICAgIHRoaXMuY2xjKClcbiAgICAgIHRoaXMuY2xjID0gbnVsbFxuICAgIH1cbiAgfVxuXG4gIG5vdGlmeShkYXRhOiBQcml2YXRlUm91dGVJbmZvKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMuc3ViKGRhdGEsIHRoaXMuY29tcG9uZW50c1snL19hcHAnXS5Db21wb25lbnQgYXMgQXBwQ29tcG9uZW50KVxuICB9XG59XG4iLCIvLyBlc2NhcGUgZGVsaW1pdGVycyB1c2VkIGJ5IHBhdGgtdG8tcmVnZXhwXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBlc2NhcGVQYXRoRGVsaW1pdGVycyhzZWdtZW50OiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gc2VnbWVudC5yZXBsYWNlKC9bLyM/XS9nLCAoY2hhcjogc3RyaW5nKSA9PiBlbmNvZGVVUklDb21wb25lbnQoY2hhcikpXG59XG4iLCIvLyBGb3JtYXQgZnVuY3Rpb24gbW9kaWZpZWQgZnJvbSBub2RlanNcbi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuXG5pbXBvcnQgeyBVcmxPYmplY3QgfSBmcm9tICd1cmwnXG5pbXBvcnQgeyBQYXJzZWRVcmxRdWVyeSB9IGZyb20gJ3F1ZXJ5c3RyaW5nJ1xuaW1wb3J0ICogYXMgcXVlcnlzdHJpbmcgZnJvbSAnLi9xdWVyeXN0cmluZydcblxuY29uc3Qgc2xhc2hlZFByb3RvY29scyA9IC9odHRwcz98ZnRwfGdvcGhlcnxmaWxlL1xuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0VXJsKHVybE9iajogVXJsT2JqZWN0KSB7XG4gIGxldCB7IGF1dGgsIGhvc3RuYW1lIH0gPSB1cmxPYmpcbiAgbGV0IHByb3RvY29sID0gdXJsT2JqLnByb3RvY29sIHx8ICcnXG4gIGxldCBwYXRobmFtZSA9IHVybE9iai5wYXRobmFtZSB8fCAnJ1xuICBsZXQgaGFzaCA9IHVybE9iai5oYXNoIHx8ICcnXG4gIGxldCBxdWVyeSA9IHVybE9iai5xdWVyeSB8fCAnJ1xuICBsZXQgaG9zdDogc3RyaW5nIHwgZmFsc2UgPSBmYWxzZVxuXG4gIGF1dGggPSBhdXRoID8gZW5jb2RlVVJJQ29tcG9uZW50KGF1dGgpLnJlcGxhY2UoLyUzQS9pLCAnOicpICsgJ0AnIDogJydcblxuICBpZiAodXJsT2JqLmhvc3QpIHtcbiAgICBob3N0ID0gYXV0aCArIHVybE9iai5ob3N0XG4gIH0gZWxzZSBpZiAoaG9zdG5hbWUpIHtcbiAgICBob3N0ID0gYXV0aCArICh+aG9zdG5hbWUuaW5kZXhPZignOicpID8gYFske2hvc3RuYW1lfV1gIDogaG9zdG5hbWUpXG4gICAgaWYgKHVybE9iai5wb3J0KSB7XG4gICAgICBob3N0ICs9ICc6JyArIHVybE9iai5wb3J0XG4gICAgfVxuICB9XG5cbiAgaWYgKHF1ZXJ5ICYmIHR5cGVvZiBxdWVyeSA9PT0gJ29iamVjdCcpIHtcbiAgICBxdWVyeSA9IFN0cmluZyhxdWVyeXN0cmluZy51cmxRdWVyeVRvU2VhcmNoUGFyYW1zKHF1ZXJ5IGFzIFBhcnNlZFVybFF1ZXJ5KSlcbiAgfVxuXG4gIGxldCBzZWFyY2ggPSB1cmxPYmouc2VhcmNoIHx8IChxdWVyeSAmJiBgPyR7cXVlcnl9YCkgfHwgJydcblxuICBpZiAocHJvdG9jb2wgJiYgcHJvdG9jb2wuc3Vic3RyKC0xKSAhPT0gJzonKSBwcm90b2NvbCArPSAnOidcblxuICBpZiAoXG4gICAgdXJsT2JqLnNsYXNoZXMgfHxcbiAgICAoKCFwcm90b2NvbCB8fCBzbGFzaGVkUHJvdG9jb2xzLnRlc3QocHJvdG9jb2wpKSAmJiBob3N0ICE9PSBmYWxzZSlcbiAgKSB7XG4gICAgaG9zdCA9ICcvLycgKyAoaG9zdCB8fCAnJylcbiAgICBpZiAocGF0aG5hbWUgJiYgcGF0aG5hbWVbMF0gIT09ICcvJykgcGF0aG5hbWUgPSAnLycgKyBwYXRobmFtZVxuICB9IGVsc2UgaWYgKCFob3N0KSB7XG4gICAgaG9zdCA9ICcnXG4gIH1cblxuICBpZiAoaGFzaCAmJiBoYXNoWzBdICE9PSAnIycpIGhhc2ggPSAnIycgKyBoYXNoXG4gIGlmIChzZWFyY2ggJiYgc2VhcmNoWzBdICE9PSAnPycpIHNlYXJjaCA9ICc/JyArIHNlYXJjaFxuXG4gIHBhdGhuYW1lID0gcGF0aG5hbWUucmVwbGFjZSgvWz8jXS9nLCBlbmNvZGVVUklDb21wb25lbnQpXG4gIHNlYXJjaCA9IHNlYXJjaC5yZXBsYWNlKCcjJywgJyUyMycpXG5cbiAgcmV0dXJuIGAke3Byb3RvY29sfSR7aG9zdH0ke3BhdGhuYW1lfSR7c2VhcmNofSR7aGFzaH1gXG59XG4iLCIvLyBJZGVudGlmeSAvW3BhcmFtXS8gaW4gcm91dGUgc3RyaW5nXG5jb25zdCBURVNUX1JPVVRFID0gL1xcL1xcW1teL10rP1xcXSg/PVxcL3wkKS9cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRHluYW1pY1JvdXRlKHJvdXRlOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgcmV0dXJuIFRFU1RfUk9VVEUudGVzdChyb3V0ZSlcbn1cbiIsImltcG9ydCB7IGdldExvY2F0aW9uT3JpZ2luIH0gZnJvbSAnLi4vLi4vdXRpbHMnXG5pbXBvcnQgeyBzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5IH0gZnJvbSAnLi9xdWVyeXN0cmluZydcblxuY29uc3QgRFVNTVlfQkFTRSA9IG5ldyBVUkwoXG4gIHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnID8gJ2h0dHA6Ly9uJyA6IGdldExvY2F0aW9uT3JpZ2luKClcbilcblxuLyoqXG4gKiBQYXJzZXMgcGF0aC1yZWxhdGl2ZSB1cmxzIChlLmcuIGAvaGVsbG8vd29ybGQ/Zm9vPWJhcmApLiBJZiB1cmwgaXNuJ3QgcGF0aC1yZWxhdGl2ZVxuICogKGUuZy4gYC4vaGVsbG9gKSB0aGVuIGF0IGxlYXN0IGJhc2UgbXVzdCBiZS5cbiAqIEFic29sdXRlIHVybHMgYXJlIHJlamVjdGVkIHdpdGggb25lIGV4Y2VwdGlvbiwgaW4gdGhlIGJyb3dzZXIsIGFic29sdXRlIHVybHMgdGhhdCBhcmUgb25cbiAqIHRoZSBjdXJyZW50IG9yaWdpbiB3aWxsIGJlIHBhcnNlZCBhcyByZWxhdGl2ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VSZWxhdGl2ZVVybCh1cmw6IHN0cmluZywgYmFzZT86IHN0cmluZykge1xuICBjb25zdCByZXNvbHZlZEJhc2UgPSBiYXNlID8gbmV3IFVSTChiYXNlLCBEVU1NWV9CQVNFKSA6IERVTU1ZX0JBU0VcbiAgY29uc3Qge1xuICAgIHBhdGhuYW1lLFxuICAgIHNlYXJjaFBhcmFtcyxcbiAgICBzZWFyY2gsXG4gICAgaGFzaCxcbiAgICBocmVmLFxuICAgIG9yaWdpbixcbiAgICBwcm90b2NvbCxcbiAgfSA9IG5ldyBVUkwodXJsLCByZXNvbHZlZEJhc2UpXG4gIGlmIChcbiAgICBvcmlnaW4gIT09IERVTU1ZX0JBU0Uub3JpZ2luIHx8XG4gICAgKHByb3RvY29sICE9PSAnaHR0cDonICYmIHByb3RvY29sICE9PSAnaHR0cHM6JylcbiAgKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhcmlhbnQ6IGludmFsaWQgcmVsYXRpdmUgVVJMJylcbiAgfVxuICByZXR1cm4ge1xuICAgIHBhdGhuYW1lLFxuICAgIHF1ZXJ5OiBzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5KHNlYXJjaFBhcmFtcyksXG4gICAgc2VhcmNoLFxuICAgIGhhc2gsXG4gICAgaHJlZjogaHJlZi5zbGljZShEVU1NWV9CQVNFLm9yaWdpbi5sZW5ndGgpLFxuICB9XG59XG4iLCJpbXBvcnQgKiBhcyBwYXRoVG9SZWdleHAgZnJvbSAnbmV4dC9kaXN0L2NvbXBpbGVkL3BhdGgtdG8tcmVnZXhwJ1xuXG5leHBvcnQgeyBwYXRoVG9SZWdleHAgfVxuXG5leHBvcnQgY29uc3QgbWF0Y2hlck9wdGlvbnM6IHBhdGhUb1JlZ2V4cC5Ub2tlbnNUb1JlZ2V4cE9wdGlvbnMgJlxuICBwYXRoVG9SZWdleHAuUGFyc2VPcHRpb25zID0ge1xuICBzZW5zaXRpdmU6IGZhbHNlLFxuICBkZWxpbWl0ZXI6ICcvJyxcbn1cblxuZXhwb3J0IGNvbnN0IGN1c3RvbVJvdXRlTWF0Y2hlck9wdGlvbnM6IHBhdGhUb1JlZ2V4cC5Ub2tlbnNUb1JlZ2V4cE9wdGlvbnMgJlxuICBwYXRoVG9SZWdleHAuUGFyc2VPcHRpb25zID0ge1xuICAuLi5tYXRjaGVyT3B0aW9ucyxcbiAgc3RyaWN0OiB0cnVlLFxufVxuXG5leHBvcnQgZGVmYXVsdCAoY3VzdG9tUm91dGUgPSBmYWxzZSkgPT4ge1xuICByZXR1cm4gKHBhdGg6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IGtleXM6IHBhdGhUb1JlZ2V4cC5LZXlbXSA9IFtdXG4gICAgY29uc3QgbWF0Y2hlclJlZ2V4ID0gcGF0aFRvUmVnZXhwLnBhdGhUb1JlZ2V4cChcbiAgICAgIHBhdGgsXG4gICAgICBrZXlzLFxuICAgICAgY3VzdG9tUm91dGUgPyBjdXN0b21Sb3V0ZU1hdGNoZXJPcHRpb25zIDogbWF0Y2hlck9wdGlvbnNcbiAgICApXG4gICAgY29uc3QgbWF0Y2hlciA9IHBhdGhUb1JlZ2V4cC5yZWdleHBUb0Z1bmN0aW9uKG1hdGNoZXJSZWdleCwga2V5cylcblxuICAgIHJldHVybiAocGF0aG5hbWU6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQsIHBhcmFtcz86IGFueSkgPT4ge1xuICAgICAgY29uc3QgcmVzID0gcGF0aG5hbWUgPT0gbnVsbCA/IGZhbHNlIDogbWF0Y2hlcihwYXRobmFtZSlcbiAgICAgIGlmICghcmVzKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICBpZiAoY3VzdG9tUm91dGUpIHtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgb2Yga2V5cykge1xuICAgICAgICAgIC8vIHVubmFtZWQgcGFyYW1zIHNob3VsZCBiZSByZW1vdmVkIGFzIHRoZXlcbiAgICAgICAgICAvLyBhcmUgbm90IGFsbG93ZWQgdG8gYmUgdXNlZCBpbiB0aGUgZGVzdGluYXRpb25cbiAgICAgICAgICBpZiAodHlwZW9mIGtleS5uYW1lID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgZGVsZXRlIChyZXMucGFyYW1zIGFzIGFueSlba2V5Lm5hbWVdXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB7IC4uLnBhcmFtcywgLi4ucmVzLnBhcmFtcyB9XG4gICAgfVxuICB9XG59XG4iLCJpbXBvcnQgeyBQYXJzZWRVcmxRdWVyeSB9IGZyb20gJ3F1ZXJ5c3RyaW5nJ1xuaW1wb3J0IHsgc2VhcmNoUGFyYW1zVG9VcmxRdWVyeSB9IGZyb20gJy4vcXVlcnlzdHJpbmcnXG5pbXBvcnQgeyBwYXJzZVJlbGF0aXZlVXJsIH0gZnJvbSAnLi9wYXJzZS1yZWxhdGl2ZS11cmwnXG5pbXBvcnQgKiBhcyBwYXRoVG9SZWdleHAgZnJvbSAnbmV4dC9kaXN0L2NvbXBpbGVkL3BhdGgtdG8tcmVnZXhwJ1xuXG50eXBlIFBhcmFtcyA9IHsgW3BhcmFtOiBzdHJpbmddOiBhbnkgfVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBwcmVwYXJlRGVzdGluYXRpb24oXG4gIGRlc3RpbmF0aW9uOiBzdHJpbmcsXG4gIHBhcmFtczogUGFyYW1zLFxuICBxdWVyeTogUGFyc2VkVXJsUXVlcnksXG4gIGFwcGVuZFBhcmFtc1RvUXVlcnk6IGJvb2xlYW4sXG4gIGJhc2VQYXRoOiBzdHJpbmdcbikge1xuICBsZXQgcGFyc2VkRGVzdGluYXRpb246IHtcbiAgICBxdWVyeT86IFBhcnNlZFVybFF1ZXJ5XG4gICAgcHJvdG9jb2w/OiBzdHJpbmdcbiAgICBob3N0bmFtZT86IHN0cmluZ1xuICAgIHBvcnQ/OiBzdHJpbmdcbiAgfSAmIFJldHVyblR5cGU8dHlwZW9mIHBhcnNlUmVsYXRpdmVVcmw+ID0ge30gYXMgYW55XG5cbiAgaWYgKGRlc3RpbmF0aW9uLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgIHBhcnNlZERlc3RpbmF0aW9uID0gcGFyc2VSZWxhdGl2ZVVybChkZXN0aW5hdGlvbilcbiAgfSBlbHNlIHtcbiAgICBjb25zdCB7XG4gICAgICBwYXRobmFtZSxcbiAgICAgIHNlYXJjaFBhcmFtcyxcbiAgICAgIGhhc2gsXG4gICAgICBob3N0bmFtZSxcbiAgICAgIHBvcnQsXG4gICAgICBwcm90b2NvbCxcbiAgICAgIHNlYXJjaCxcbiAgICAgIGhyZWYsXG4gICAgfSA9IG5ldyBVUkwoZGVzdGluYXRpb24pXG5cbiAgICBwYXJzZWREZXN0aW5hdGlvbiA9IHtcbiAgICAgIHBhdGhuYW1lLFxuICAgICAgcXVlcnk6IHNlYXJjaFBhcmFtc1RvVXJsUXVlcnkoc2VhcmNoUGFyYW1zKSxcbiAgICAgIGhhc2gsXG4gICAgICBwcm90b2NvbCxcbiAgICAgIGhvc3RuYW1lLFxuICAgICAgcG9ydCxcbiAgICAgIHNlYXJjaCxcbiAgICAgIGhyZWYsXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZGVzdFF1ZXJ5ID0gcGFyc2VkRGVzdGluYXRpb24ucXVlcnlcbiAgY29uc3QgZGVzdFBhdGggPSBgJHtwYXJzZWREZXN0aW5hdGlvbi5wYXRobmFtZSF9JHtcbiAgICBwYXJzZWREZXN0aW5hdGlvbi5oYXNoIHx8ICcnXG4gIH1gXG4gIGNvbnN0IGRlc3RQYXRoUGFyYW1LZXlzOiBwYXRoVG9SZWdleHAuS2V5W10gPSBbXVxuICBwYXRoVG9SZWdleHAucGF0aFRvUmVnZXhwKGRlc3RQYXRoLCBkZXN0UGF0aFBhcmFtS2V5cylcblxuICBjb25zdCBkZXN0UGF0aFBhcmFtcyA9IGRlc3RQYXRoUGFyYW1LZXlzLm1hcCgoa2V5KSA9PiBrZXkubmFtZSlcblxuICBsZXQgZGVzdGluYXRpb25Db21waWxlciA9IHBhdGhUb1JlZ2V4cC5jb21waWxlKFxuICAgIGRlc3RQYXRoLFxuICAgIC8vIHdlIGRvbid0IHZhbGlkYXRlIHdoaWxlIGNvbXBpbGluZyB0aGUgZGVzdGluYXRpb24gc2luY2Ugd2Ugc2hvdWxkXG4gICAgLy8gaGF2ZSBhbHJlYWR5IHZhbGlkYXRlZCBiZWZvcmUgd2UgZ290IHRvIHRoaXMgcG9pbnQgYW5kIHZhbGlkYXRpbmdcbiAgICAvLyBicmVha3MgY29tcGlsaW5nIGRlc3RpbmF0aW9ucyB3aXRoIG5hbWVkIHBhdHRlcm4gcGFyYW1zIGZyb20gdGhlIHNvdXJjZVxuICAgIC8vIGUuZy4gL3NvbWV0aGluZzpoZWxsbyguKikgLT4gL2Fub3RoZXIvOmhlbGxvIGlzIGJyb2tlbiB3aXRoIHZhbGlkYXRpb25cbiAgICAvLyBzaW5jZSBjb21waWxlIHZhbGlkYXRpb24gaXMgbWVhbnQgZm9yIHJldmVyc2luZyBhbmQgbm90IGZvciBpbnNlcnRpbmdcbiAgICAvLyBwYXJhbXMgZnJvbSBhIHNlcGFyYXRlIHBhdGgtcmVnZXggaW50byBhbm90aGVyXG4gICAgeyB2YWxpZGF0ZTogZmFsc2UgfVxuICApXG4gIGxldCBuZXdVcmxcblxuICAvLyB1cGRhdGUgYW55IHBhcmFtcyBpbiBxdWVyeSB2YWx1ZXNcbiAgZm9yIChjb25zdCBba2V5LCBzdHJPckFycmF5XSBvZiBPYmplY3QuZW50cmllcyhkZXN0UXVlcnkpKSB7XG4gICAgbGV0IHZhbHVlID0gQXJyYXkuaXNBcnJheShzdHJPckFycmF5KSA/IHN0ck9yQXJyYXlbMF0gOiBzdHJPckFycmF5XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICAvLyB0aGUgdmFsdWUgbmVlZHMgdG8gc3RhcnQgd2l0aCBhIGZvcndhcmQtc2xhc2ggdG8gYmUgY29tcGlsZWRcbiAgICAgIC8vIGNvcnJlY3RseVxuICAgICAgdmFsdWUgPSBgLyR7dmFsdWV9YFxuICAgICAgY29uc3QgcXVlcnlDb21waWxlciA9IHBhdGhUb1JlZ2V4cC5jb21waWxlKHZhbHVlLCB7IHZhbGlkYXRlOiBmYWxzZSB9KVxuICAgICAgdmFsdWUgPSBxdWVyeUNvbXBpbGVyKHBhcmFtcykuc3Vic3RyKDEpXG4gICAgfVxuICAgIGRlc3RRdWVyeVtrZXldID0gdmFsdWVcbiAgfVxuXG4gIC8vIGFkZCBwYXRoIHBhcmFtcyB0byBxdWVyeSBpZiBpdCdzIG5vdCBhIHJlZGlyZWN0IGFuZCBub3RcbiAgLy8gYWxyZWFkeSBkZWZpbmVkIGluIGRlc3RpbmF0aW9uIHF1ZXJ5IG9yIHBhdGhcbiAgY29uc3QgcGFyYW1LZXlzID0gT2JqZWN0LmtleXMocGFyYW1zKVxuXG4gIGlmIChcbiAgICBhcHBlbmRQYXJhbXNUb1F1ZXJ5ICYmXG4gICAgIXBhcmFtS2V5cy5zb21lKChrZXkpID0+IGRlc3RQYXRoUGFyYW1zLmluY2x1ZGVzKGtleSkpXG4gICkge1xuICAgIGZvciAoY29uc3Qga2V5IG9mIHBhcmFtS2V5cykge1xuICAgICAgaWYgKCEoa2V5IGluIGRlc3RRdWVyeSkpIHtcbiAgICAgICAgZGVzdFF1ZXJ5W2tleV0gPSBwYXJhbXNba2V5XVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHNob3VsZEFkZEJhc2VQYXRoID0gZGVzdGluYXRpb24uc3RhcnRzV2l0aCgnLycpICYmIGJhc2VQYXRoXG5cbiAgdHJ5IHtcbiAgICBuZXdVcmwgPSBgJHtzaG91bGRBZGRCYXNlUGF0aCA/IGJhc2VQYXRoIDogJyd9JHtkZXN0aW5hdGlvbkNvbXBpbGVyKFxuICAgICAgcGFyYW1zXG4gICAgKX1gXG5cbiAgICBjb25zdCBbcGF0aG5hbWUsIGhhc2hdID0gbmV3VXJsLnNwbGl0KCcjJylcbiAgICBwYXJzZWREZXN0aW5hdGlvbi5wYXRobmFtZSA9IHBhdGhuYW1lXG4gICAgcGFyc2VkRGVzdGluYXRpb24uaGFzaCA9IGAke2hhc2ggPyAnIycgOiAnJ30ke2hhc2ggfHwgJyd9YFxuICAgIGRlbGV0ZSBwYXJzZWREZXN0aW5hdGlvbi5zZWFyY2hcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKGVyci5tZXNzYWdlLm1hdGNoKC9FeHBlY3RlZCAuKj8gdG8gbm90IHJlcGVhdCwgYnV0IGdvdCBhbiBhcnJheS8pKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBUbyB1c2UgYSBtdWx0aS1tYXRjaCBpbiB0aGUgZGVzdGluYXRpb24geW91IG11c3QgYWRkIFxcYCpcXGAgYXQgdGhlIGVuZCBvZiB0aGUgcGFyYW0gbmFtZSB0byBzaWduaWZ5IGl0IHNob3VsZCByZXBlYXQuIGh0dHBzOi8vZXJyLnNoL3ZlcmNlbC9uZXh0LmpzL2ludmFsaWQtbXVsdGktbWF0Y2hgXG4gICAgICApXG4gICAgfVxuICAgIHRocm93IGVyclxuICB9XG5cbiAgLy8gUXVlcnkgbWVyZ2Ugb3JkZXIgbG93ZXN0IHByaW9yaXR5IHRvIGhpZ2hlc3RcbiAgLy8gMS4gaW5pdGlhbCBVUkwgcXVlcnkgdmFsdWVzXG4gIC8vIDIuIHBhdGggc2VnbWVudCB2YWx1ZXNcbiAgLy8gMy4gZGVzdGluYXRpb24gc3BlY2lmaWVkIHF1ZXJ5IHZhbHVlc1xuICBwYXJzZWREZXN0aW5hdGlvbi5xdWVyeSA9IHtcbiAgICAuLi5xdWVyeSxcbiAgICAuLi5wYXJzZWREZXN0aW5hdGlvbi5xdWVyeSxcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgbmV3VXJsLFxuICAgIHBhcnNlZERlc3RpbmF0aW9uLFxuICB9XG59XG4iLCJpbXBvcnQgeyBQYXJzZWRVcmxRdWVyeSB9IGZyb20gJ3F1ZXJ5c3RyaW5nJ1xuXG5leHBvcnQgZnVuY3Rpb24gc2VhcmNoUGFyYW1zVG9VcmxRdWVyeShcbiAgc2VhcmNoUGFyYW1zOiBVUkxTZWFyY2hQYXJhbXNcbik6IFBhcnNlZFVybFF1ZXJ5IHtcbiAgY29uc3QgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5ID0ge31cbiAgc2VhcmNoUGFyYW1zLmZvckVhY2goKHZhbHVlLCBrZXkpID0+IHtcbiAgICBpZiAodHlwZW9mIHF1ZXJ5W2tleV0gPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBxdWVyeVtrZXldID0gdmFsdWVcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocXVlcnlba2V5XSkpIHtcbiAgICAgIDsocXVlcnlba2V5XSBhcyBzdHJpbmdbXSkucHVzaCh2YWx1ZSlcbiAgICB9IGVsc2Uge1xuICAgICAgcXVlcnlba2V5XSA9IFtxdWVyeVtrZXldIGFzIHN0cmluZywgdmFsdWVdXG4gICAgfVxuICB9KVxuICByZXR1cm4gcXVlcnlcbn1cblxuZnVuY3Rpb24gc3RyaW5naWZ5VXJsUXVlcnlQYXJhbShwYXJhbTogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKFxuICAgIHR5cGVvZiBwYXJhbSA9PT0gJ3N0cmluZycgfHxcbiAgICAodHlwZW9mIHBhcmFtID09PSAnbnVtYmVyJyAmJiAhaXNOYU4ocGFyYW0pKSB8fFxuICAgIHR5cGVvZiBwYXJhbSA9PT0gJ2Jvb2xlYW4nXG4gICkge1xuICAgIHJldHVybiBTdHJpbmcocGFyYW0pXG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuICcnXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVybFF1ZXJ5VG9TZWFyY2hQYXJhbXMoXG4gIHVybFF1ZXJ5OiBQYXJzZWRVcmxRdWVyeVxuKTogVVJMU2VhcmNoUGFyYW1zIHtcbiAgY29uc3QgcmVzdWx0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpXG4gIE9iamVjdC5lbnRyaWVzKHVybFF1ZXJ5KS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIHZhbHVlLmZvckVhY2goKGl0ZW0pID0+IHJlc3VsdC5hcHBlbmQoa2V5LCBzdHJpbmdpZnlVcmxRdWVyeVBhcmFtKGl0ZW0pKSlcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzdWx0LnNldChrZXksIHN0cmluZ2lmeVVybFF1ZXJ5UGFyYW0odmFsdWUpKVxuICAgIH1cbiAgfSlcbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYXNzaWduKFxuICB0YXJnZXQ6IFVSTFNlYXJjaFBhcmFtcyxcbiAgLi4uc2VhcmNoUGFyYW1zTGlzdDogVVJMU2VhcmNoUGFyYW1zW11cbik6IFVSTFNlYXJjaFBhcmFtcyB7XG4gIHNlYXJjaFBhcmFtc0xpc3QuZm9yRWFjaCgoc2VhcmNoUGFyYW1zKSA9PiB7XG4gICAgQXJyYXkuZnJvbShzZWFyY2hQYXJhbXMua2V5cygpKS5mb3JFYWNoKChrZXkpID0+IHRhcmdldC5kZWxldGUoa2V5KSlcbiAgICBzZWFyY2hQYXJhbXMuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4gdGFyZ2V0LmFwcGVuZChrZXksIHZhbHVlKSlcbiAgfSlcbiAgcmV0dXJuIHRhcmdldFxufVxuIiwiaW1wb3J0IHsgUGFyc2VkVXJsUXVlcnkgfSBmcm9tICdxdWVyeXN0cmluZydcbmltcG9ydCBwYXRoTWF0Y2ggZnJvbSAnLi9wYXRoLW1hdGNoJ1xuaW1wb3J0IHByZXBhcmVEZXN0aW5hdGlvbiBmcm9tICcuL3ByZXBhcmUtZGVzdGluYXRpb24nXG5pbXBvcnQgeyBSZXdyaXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vbGliL2xvYWQtY3VzdG9tLXJvdXRlcydcbmltcG9ydCB7IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoIH0gZnJvbSAnLi4vLi4vLi4vLi4vY2xpZW50L25vcm1hbGl6ZS10cmFpbGluZy1zbGFzaCdcblxuY29uc3QgY3VzdG9tUm91dGVNYXRjaGVyID0gcGF0aE1hdGNoKHRydWUpXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHJlc29sdmVSZXdyaXRlcyhcbiAgYXNQYXRoOiBzdHJpbmcsXG4gIHBhZ2VzOiBzdHJpbmdbXSxcbiAgYmFzZVBhdGg6IHN0cmluZyxcbiAgcmV3cml0ZXM6IFJld3JpdGVbXSxcbiAgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5LFxuICByZXNvbHZlSHJlZjogKHBhdGg6IHN0cmluZykgPT4gc3RyaW5nXG4pIHtcbiAgaWYgKCFwYWdlcy5pbmNsdWRlcyhhc1BhdGgpKSB7XG4gICAgZm9yIChjb25zdCByZXdyaXRlIG9mIHJld3JpdGVzKSB7XG4gICAgICBjb25zdCBtYXRjaGVyID0gY3VzdG9tUm91dGVNYXRjaGVyKHJld3JpdGUuc291cmNlKVxuICAgICAgY29uc3QgcGFyYW1zID0gbWF0Y2hlcihhc1BhdGgpXG5cbiAgICAgIGlmIChwYXJhbXMpIHtcbiAgICAgICAgaWYgKCFyZXdyaXRlLmRlc3RpbmF0aW9uKSB7XG4gICAgICAgICAgLy8gdGhpcyBpcyBhIHByb3hpZWQgcmV3cml0ZSB3aGljaCBpc24ndCBoYW5kbGVkIG9uIHRoZSBjbGllbnRcbiAgICAgICAgICBicmVha1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGRlc3RSZXMgPSBwcmVwYXJlRGVzdGluYXRpb24oXG4gICAgICAgICAgcmV3cml0ZS5kZXN0aW5hdGlvbixcbiAgICAgICAgICBwYXJhbXMsXG4gICAgICAgICAgcXVlcnksXG4gICAgICAgICAgdHJ1ZSxcbiAgICAgICAgICByZXdyaXRlLmJhc2VQYXRoID09PSBmYWxzZSA/ICcnIDogYmFzZVBhdGhcbiAgICAgICAgKVxuICAgICAgICBhc1BhdGggPSBkZXN0UmVzLnBhcnNlZERlc3RpbmF0aW9uLnBhdGhuYW1lIVxuICAgICAgICBPYmplY3QuYXNzaWduKHF1ZXJ5LCBkZXN0UmVzLnBhcnNlZERlc3RpbmF0aW9uLnF1ZXJ5KVxuXG4gICAgICAgIGlmIChwYWdlcy5pbmNsdWRlcyhyZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChhc1BhdGgpKSkge1xuICAgICAgICAgIC8vIGNoZWNrIGlmIHdlIG5vdyBtYXRjaCBhIHBhZ2UgYXMgdGhpcyBtZWFucyB3ZSBhcmUgZG9uZVxuICAgICAgICAgIC8vIHJlc29sdmluZyB0aGUgcmV3cml0ZXNcbiAgICAgICAgICBicmVha1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gY2hlY2sgaWYgd2UgbWF0Y2ggYSBkeW5hbWljLXJvdXRlLCBpZiBzbyB3ZSBicmVhayB0aGUgcmV3cml0ZXMgY2hhaW5cbiAgICAgICAgY29uc3QgcmVzb2x2ZWRIcmVmID0gcmVzb2x2ZUhyZWYoYXNQYXRoKVxuXG4gICAgICAgIGlmIChyZXNvbHZlZEhyZWYgIT09IGFzUGF0aCAmJiBwYWdlcy5pbmNsdWRlcyhyZXNvbHZlZEhyZWYpKSB7XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gYXNQYXRoXG59XG4iLCJpbXBvcnQgeyBnZXRSb3V0ZVJlZ2V4IH0gZnJvbSAnLi9yb3V0ZS1yZWdleCdcblxuZXhwb3J0IGZ1bmN0aW9uIGdldFJvdXRlTWF0Y2hlcihyb3V0ZVJlZ2V4OiBSZXR1cm5UeXBlPHR5cGVvZiBnZXRSb3V0ZVJlZ2V4Pikge1xuICBjb25zdCB7IHJlLCBncm91cHMgfSA9IHJvdXRlUmVnZXhcbiAgcmV0dXJuIChwYXRobmFtZTogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCkgPT4ge1xuICAgIGNvbnN0IHJvdXRlTWF0Y2ggPSByZS5leGVjKHBhdGhuYW1lISlcbiAgICBpZiAoIXJvdXRlTWF0Y2gpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIGNvbnN0IGRlY29kZSA9IChwYXJhbTogc3RyaW5nKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KHBhcmFtKVxuICAgICAgfSBjYXRjaCAoXykge1xuICAgICAgICBjb25zdCBlcnI6IEVycm9yICYgeyBjb2RlPzogc3RyaW5nIH0gPSBuZXcgRXJyb3IoXG4gICAgICAgICAgJ2ZhaWxlZCB0byBkZWNvZGUgcGFyYW0nXG4gICAgICAgIClcbiAgICAgICAgZXJyLmNvZGUgPSAnREVDT0RFX0ZBSUxFRCdcbiAgICAgICAgdGhyb3cgZXJyXG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHBhcmFtczogeyBbcGFyYW1OYW1lOiBzdHJpbmddOiBzdHJpbmcgfCBzdHJpbmdbXSB9ID0ge31cblxuICAgIE9iamVjdC5rZXlzKGdyb3VwcykuZm9yRWFjaCgoc2x1Z05hbWU6IHN0cmluZykgPT4ge1xuICAgICAgY29uc3QgZyA9IGdyb3Vwc1tzbHVnTmFtZV1cbiAgICAgIGNvbnN0IG0gPSByb3V0ZU1hdGNoW2cucG9zXVxuICAgICAgaWYgKG0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBwYXJhbXNbc2x1Z05hbWVdID0gfm0uaW5kZXhPZignLycpXG4gICAgICAgICAgPyBtLnNwbGl0KCcvJykubWFwKChlbnRyeSkgPT4gZGVjb2RlKGVudHJ5KSlcbiAgICAgICAgICA6IGcucmVwZWF0XG4gICAgICAgICAgPyBbZGVjb2RlKG0pXVxuICAgICAgICAgIDogZGVjb2RlKG0pXG4gICAgICB9XG4gICAgfSlcbiAgICByZXR1cm4gcGFyYW1zXG4gIH1cbn1cbiIsImludGVyZmFjZSBHcm91cCB7XG4gIHBvczogbnVtYmVyXG4gIHJlcGVhdDogYm9vbGVhblxuICBvcHRpb25hbDogYm9vbGVhblxufVxuXG4vLyB0aGlzIGlzbid0IGltcG9ydGluZyB0aGUgZXNjYXBlLXN0cmluZy1yZWdleCBtb2R1bGVcbi8vIHRvIHJlZHVjZSBieXRlc1xuZnVuY3Rpb24gZXNjYXBlUmVnZXgoc3RyOiBzdHJpbmcpIHtcbiAgcmV0dXJuIHN0ci5yZXBsYWNlKC9bfFxcXFx7fSgpW1xcXV4kKyo/Li1dL2csICdcXFxcJCYnKVxufVxuXG5mdW5jdGlvbiBwYXJzZVBhcmFtZXRlcihwYXJhbTogc3RyaW5nKSB7XG4gIGNvbnN0IG9wdGlvbmFsID0gcGFyYW0uc3RhcnRzV2l0aCgnWycpICYmIHBhcmFtLmVuZHNXaXRoKCddJylcbiAgaWYgKG9wdGlvbmFsKSB7XG4gICAgcGFyYW0gPSBwYXJhbS5zbGljZSgxLCAtMSlcbiAgfVxuICBjb25zdCByZXBlYXQgPSBwYXJhbS5zdGFydHNXaXRoKCcuLi4nKVxuICBpZiAocmVwZWF0KSB7XG4gICAgcGFyYW0gPSBwYXJhbS5zbGljZSgzKVxuICB9XG4gIHJldHVybiB7IGtleTogcGFyYW0sIHJlcGVhdCwgb3B0aW9uYWwgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0Um91dGVSZWdleChcbiAgbm9ybWFsaXplZFJvdXRlOiBzdHJpbmdcbik6IHtcbiAgcmU6IFJlZ0V4cFxuICBuYW1lZFJlZ2V4Pzogc3RyaW5nXG4gIHJvdXRlS2V5cz86IHsgW25hbWVkOiBzdHJpbmddOiBzdHJpbmcgfVxuICBncm91cHM6IHsgW2dyb3VwTmFtZTogc3RyaW5nXTogR3JvdXAgfVxufSB7XG4gIGNvbnN0IHNlZ21lbnRzID0gKG5vcm1hbGl6ZWRSb3V0ZS5yZXBsYWNlKC9cXC8kLywgJycpIHx8ICcvJylcbiAgICAuc2xpY2UoMSlcbiAgICAuc3BsaXQoJy8nKVxuXG4gIGNvbnN0IGdyb3VwczogeyBbZ3JvdXBOYW1lOiBzdHJpbmddOiBHcm91cCB9ID0ge31cbiAgbGV0IGdyb3VwSW5kZXggPSAxXG4gIGNvbnN0IHBhcmFtZXRlcml6ZWRSb3V0ZSA9IHNlZ21lbnRzXG4gICAgLm1hcCgoc2VnbWVudCkgPT4ge1xuICAgICAgaWYgKHNlZ21lbnQuc3RhcnRzV2l0aCgnWycpICYmIHNlZ21lbnQuZW5kc1dpdGgoJ10nKSkge1xuICAgICAgICBjb25zdCB7IGtleSwgb3B0aW9uYWwsIHJlcGVhdCB9ID0gcGFyc2VQYXJhbWV0ZXIoc2VnbWVudC5zbGljZSgxLCAtMSkpXG4gICAgICAgIGdyb3Vwc1trZXldID0geyBwb3M6IGdyb3VwSW5kZXgrKywgcmVwZWF0LCBvcHRpb25hbCB9XG4gICAgICAgIHJldHVybiByZXBlYXQgPyAob3B0aW9uYWwgPyAnKD86LyguKz8pKT8nIDogJy8oLis/KScpIDogJy8oW14vXSs/KSdcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBgLyR7ZXNjYXBlUmVnZXgoc2VnbWVudCl9YFxuICAgICAgfVxuICAgIH0pXG4gICAgLmpvaW4oJycpXG5cbiAgLy8gZGVhZCBjb2RlIGVsaW1pbmF0ZSBmb3IgYnJvd3NlciBzaW5jZSBpdCdzIG9ubHkgbmVlZGVkXG4gIC8vIHdoaWxlIGdlbmVyYXRpbmcgcm91dGVzLW1hbmlmZXN0XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICAgIGxldCByb3V0ZUtleUNoYXJDb2RlID0gOTdcbiAgICBsZXQgcm91dGVLZXlDaGFyTGVuZ3RoID0gMVxuXG4gICAgLy8gYnVpbGRzIGEgbWluaW1hbCByb3V0ZUtleSB1c2luZyBvbmx5IGEteiBhbmQgbWluaW1hbCBudW1iZXIgb2YgY2hhcmFjdGVyc1xuICAgIGNvbnN0IGdldFNhZmVSb3V0ZUtleSA9ICgpID0+IHtcbiAgICAgIGxldCByb3V0ZUtleSA9ICcnXG5cbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcm91dGVLZXlDaGFyTGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcm91dGVLZXkgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShyb3V0ZUtleUNoYXJDb2RlKVxuICAgICAgICByb3V0ZUtleUNoYXJDb2RlKytcblxuICAgICAgICBpZiAocm91dGVLZXlDaGFyQ29kZSA+IDEyMikge1xuICAgICAgICAgIHJvdXRlS2V5Q2hhckxlbmd0aCsrXG4gICAgICAgICAgcm91dGVLZXlDaGFyQ29kZSA9IDk3XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiByb3V0ZUtleVxuICAgIH1cblxuICAgIGNvbnN0IHJvdXRlS2V5czogeyBbbmFtZWQ6IHN0cmluZ106IHN0cmluZyB9ID0ge31cblxuICAgIGxldCBuYW1lZFBhcmFtZXRlcml6ZWRSb3V0ZSA9IHNlZ21lbnRzXG4gICAgICAubWFwKChzZWdtZW50KSA9PiB7XG4gICAgICAgIGlmIChzZWdtZW50LnN0YXJ0c1dpdGgoJ1snKSAmJiBzZWdtZW50LmVuZHNXaXRoKCddJykpIHtcbiAgICAgICAgICBjb25zdCB7IGtleSwgb3B0aW9uYWwsIHJlcGVhdCB9ID0gcGFyc2VQYXJhbWV0ZXIoc2VnbWVudC5zbGljZSgxLCAtMSkpXG4gICAgICAgICAgLy8gcmVwbGFjZSBhbnkgbm9uLXdvcmQgY2hhcmFjdGVycyBzaW5jZSB0aGV5IGNhbiBicmVha1xuICAgICAgICAgIC8vIHRoZSBuYW1lZCByZWdleFxuICAgICAgICAgIGxldCBjbGVhbmVkS2V5ID0ga2V5LnJlcGxhY2UoL1xcVy9nLCAnJylcbiAgICAgICAgICBsZXQgaW52YWxpZEtleSA9IGZhbHNlXG5cbiAgICAgICAgICAvLyBjaGVjayBpZiB0aGUga2V5IGlzIHN0aWxsIGludmFsaWQgYW5kIGZhbGxiYWNrIHRvIHVzaW5nIGEga25vd25cbiAgICAgICAgICAvLyBzYWZlIGtleVxuICAgICAgICAgIGlmIChjbGVhbmVkS2V5Lmxlbmd0aCA9PT0gMCB8fCBjbGVhbmVkS2V5Lmxlbmd0aCA+IDMwKSB7XG4gICAgICAgICAgICBpbnZhbGlkS2V5ID0gdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIWlzTmFOKHBhcnNlSW50KGNsZWFuZWRLZXkuc3Vic3RyKDAsIDEpKSkpIHtcbiAgICAgICAgICAgIGludmFsaWRLZXkgPSB0cnVlXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGludmFsaWRLZXkpIHtcbiAgICAgICAgICAgIGNsZWFuZWRLZXkgPSBnZXRTYWZlUm91dGVLZXkoKVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHJvdXRlS2V5c1tjbGVhbmVkS2V5XSA9IGtleVxuICAgICAgICAgIHJldHVybiByZXBlYXRcbiAgICAgICAgICAgID8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgPyBgKD86Lyg/PCR7Y2xlYW5lZEtleX0+Lis/KSk/YFxuICAgICAgICAgICAgICA6IGAvKD88JHtjbGVhbmVkS2V5fT4uKz8pYFxuICAgICAgICAgICAgOiBgLyg/PCR7Y2xlYW5lZEtleX0+W14vXSs/KWBcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gYC8ke2VzY2FwZVJlZ2V4KHNlZ21lbnQpfWBcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIC5qb2luKCcnKVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHJlOiBuZXcgUmVnRXhwKGBeJHtwYXJhbWV0ZXJpemVkUm91dGV9KD86Lyk/JGApLFxuICAgICAgZ3JvdXBzLFxuICAgICAgcm91dGVLZXlzLFxuICAgICAgbmFtZWRSZWdleDogYF4ke25hbWVkUGFyYW1ldGVyaXplZFJvdXRlfSg/Oi8pPyRgLFxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB7XG4gICAgcmU6IG5ldyBSZWdFeHAoYF4ke3BhcmFtZXRlcml6ZWRSb3V0ZX0oPzovKT8kYCksXG4gICAgZ3JvdXBzLFxuICB9XG59XG4iLCJpbXBvcnQgeyBJbmNvbWluZ01lc3NhZ2UsIFNlcnZlclJlc3BvbnNlIH0gZnJvbSAnaHR0cCdcbmltcG9ydCB7IFBhcnNlZFVybFF1ZXJ5IH0gZnJvbSAncXVlcnlzdHJpbmcnXG5pbXBvcnQgeyBDb21wb25lbnRUeXBlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBVcmxPYmplY3QgfSBmcm9tICd1cmwnXG5pbXBvcnQgeyBmb3JtYXRVcmwgfSBmcm9tICcuL3JvdXRlci91dGlscy9mb3JtYXQtdXJsJ1xuaW1wb3J0IHsgTWFuaWZlc3RJdGVtIH0gZnJvbSAnLi4vc2VydmVyL2xvYWQtY29tcG9uZW50cydcbmltcG9ydCB7IE5leHRSb3V0ZXIgfSBmcm9tICcuL3JvdXRlci9yb3V0ZXInXG5pbXBvcnQgeyBFbnYgfSBmcm9tICdAbmV4dC9lbnYnXG5pbXBvcnQgeyBCdWlsZE1hbmlmZXN0IH0gZnJvbSAnLi4vc2VydmVyL2dldC1wYWdlLWZpbGVzJ1xuXG4vKipcbiAqIFR5cGVzIHVzZWQgYnkgYm90aCBuZXh0IGFuZCBuZXh0LXNlcnZlclxuICovXG5cbmV4cG9ydCB0eXBlIE5leHRDb21wb25lbnRUeXBlPFxuICBDIGV4dGVuZHMgQmFzZUNvbnRleHQgPSBOZXh0UGFnZUNvbnRleHQsXG4gIElQID0ge30sXG4gIFAgPSB7fVxuPiA9IENvbXBvbmVudFR5cGU8UD4gJiB7XG4gIC8qKlxuICAgKiBVc2VkIGZvciBpbml0aWFsIHBhZ2UgbG9hZCBkYXRhIHBvcHVsYXRpb24uIERhdGEgcmV0dXJuZWQgZnJvbSBgZ2V0SW5pdGlhbFByb3BzYCBpcyBzZXJpYWxpemVkIHdoZW4gc2VydmVyIHJlbmRlcmVkLlxuICAgKiBNYWtlIHN1cmUgdG8gcmV0dXJuIHBsYWluIGBPYmplY3RgIHdpdGhvdXQgdXNpbmcgYERhdGVgLCBgTWFwYCwgYFNldGAuXG4gICAqIEBwYXJhbSBjdHggQ29udGV4dCBvZiBgcGFnZWBcbiAgICovXG4gIGdldEluaXRpYWxQcm9wcz8oY29udGV4dDogQyk6IElQIHwgUHJvbWlzZTxJUD5cbn1cblxuZXhwb3J0IHR5cGUgRG9jdW1lbnRUeXBlID0gTmV4dENvbXBvbmVudFR5cGU8XG4gIERvY3VtZW50Q29udGV4dCxcbiAgRG9jdW1lbnRJbml0aWFsUHJvcHMsXG4gIERvY3VtZW50UHJvcHNcbj4gJiB7XG4gIHJlbmRlckRvY3VtZW50KFxuICAgIERvY3VtZW50OiBEb2N1bWVudFR5cGUsXG4gICAgcHJvcHM6IERvY3VtZW50UHJvcHNcbiAgKTogUmVhY3QuUmVhY3RFbGVtZW50XG59XG5cbmV4cG9ydCB0eXBlIEFwcFR5cGUgPSBOZXh0Q29tcG9uZW50VHlwZTxcbiAgQXBwQ29udGV4dFR5cGUsXG4gIEFwcEluaXRpYWxQcm9wcyxcbiAgQXBwUHJvcHNUeXBlXG4+XG5cbmV4cG9ydCB0eXBlIEFwcFRyZWVUeXBlID0gQ29tcG9uZW50VHlwZTxcbiAgQXBwSW5pdGlhbFByb3BzICYgeyBbbmFtZTogc3RyaW5nXTogYW55IH1cbj5cblxuLyoqXG4gKiBXZWIgdml0YWxzIHByb3ZpZGVkIHRvIF9hcHAucmVwb3J0V2ViVml0YWxzIGJ5IENvcmUgV2ViIFZpdGFscyBwbHVnaW4gZGV2ZWxvcGVkIGJ5IEdvb2dsZSBDaHJvbWUgdGVhbS5cbiAqIGh0dHBzOi8vbmV4dGpzLm9yZy9ibG9nL25leHQtOS00I2ludGVncmF0ZWQtd2ViLXZpdGFscy1yZXBvcnRpbmdcbiAqL1xuZXhwb3J0IHR5cGUgTmV4dFdlYlZpdGFsc01ldHJpYyA9IHtcbiAgaWQ6IHN0cmluZ1xuICBsYWJlbDogc3RyaW5nXG4gIG5hbWU6IHN0cmluZ1xuICBzdGFydFRpbWU6IG51bWJlclxuICB2YWx1ZTogbnVtYmVyXG59XG5cbmV4cG9ydCB0eXBlIEVuaGFuY2VyPEM+ID0gKENvbXBvbmVudDogQykgPT4gQ1xuXG5leHBvcnQgdHlwZSBDb21wb25lbnRzRW5oYW5jZXIgPVxuICB8IHtcbiAgICAgIGVuaGFuY2VBcHA/OiBFbmhhbmNlcjxBcHBUeXBlPlxuICAgICAgZW5oYW5jZUNvbXBvbmVudD86IEVuaGFuY2VyPE5leHRDb21wb25lbnRUeXBlPlxuICAgIH1cbiAgfCBFbmhhbmNlcjxOZXh0Q29tcG9uZW50VHlwZT5cblxuZXhwb3J0IHR5cGUgUmVuZGVyUGFnZVJlc3VsdCA9IHtcbiAgaHRtbDogc3RyaW5nXG4gIGhlYWQ/OiBBcnJheTxKU1guRWxlbWVudCB8IG51bGw+XG59XG5cbmV4cG9ydCB0eXBlIFJlbmRlclBhZ2UgPSAoXG4gIG9wdGlvbnM/OiBDb21wb25lbnRzRW5oYW5jZXJcbikgPT4gUmVuZGVyUGFnZVJlc3VsdCB8IFByb21pc2U8UmVuZGVyUGFnZVJlc3VsdD5cblxuZXhwb3J0IHR5cGUgQmFzZUNvbnRleHQgPSB7XG4gIHJlcz86IFNlcnZlclJlc3BvbnNlXG4gIFtrOiBzdHJpbmddOiBhbnlcbn1cblxuZXhwb3J0IHR5cGUgSGVhZEVudHJ5ID0gW3N0cmluZywgeyBba2V5OiBzdHJpbmddOiBhbnkgfV1cblxuZXhwb3J0IHR5cGUgTkVYVF9EQVRBID0ge1xuICBwcm9wczogUmVjb3JkPHN0cmluZywgYW55PlxuICBwYWdlOiBzdHJpbmdcbiAgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5XG4gIGJ1aWxkSWQ6IHN0cmluZ1xuICBhc3NldFByZWZpeD86IHN0cmluZ1xuICBydW50aW1lQ29uZmlnPzogeyBba2V5OiBzdHJpbmddOiBhbnkgfVxuICBuZXh0RXhwb3J0PzogYm9vbGVhblxuICBhdXRvRXhwb3J0PzogYm9vbGVhblxuICBpc0ZhbGxiYWNrPzogYm9vbGVhblxuICBkeW5hbWljSWRzPzogc3RyaW5nW11cbiAgZXJyPzogRXJyb3IgJiB7IHN0YXR1c0NvZGU/OiBudW1iZXIgfVxuICBnc3A/OiBib29sZWFuXG4gIGdzc3A/OiBib29sZWFuXG4gIGN1c3RvbVNlcnZlcj86IGJvb2xlYW5cbiAgZ2lwPzogYm9vbGVhblxuICBhcHBHaXA/OiBib29sZWFuXG4gIGhlYWQ6IEhlYWRFbnRyeVtdXG4gIGxvY2FsZT86IHN0cmluZ1xuICBsb2NhbGVzPzogc3RyaW5nW11cbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZ1xufVxuXG4vKipcbiAqIGBOZXh0YCBjb250ZXh0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTmV4dFBhZ2VDb250ZXh0IHtcbiAgLyoqXG4gICAqIEVycm9yIG9iamVjdCBpZiBlbmNvdW50ZXJlZCBkdXJpbmcgcmVuZGVyaW5nXG4gICAqL1xuICBlcnI/OiAoRXJyb3IgJiB7IHN0YXR1c0NvZGU/OiBudW1iZXIgfSkgfCBudWxsXG4gIC8qKlxuICAgKiBgSFRUUGAgcmVxdWVzdCBvYmplY3QuXG4gICAqL1xuICByZXE/OiBJbmNvbWluZ01lc3NhZ2VcbiAgLyoqXG4gICAqIGBIVFRQYCByZXNwb25zZSBvYmplY3QuXG4gICAqL1xuICByZXM/OiBTZXJ2ZXJSZXNwb25zZVxuICAvKipcbiAgICogUGF0aCBzZWN0aW9uIG9mIGBVUkxgLlxuICAgKi9cbiAgcGF0aG5hbWU6IHN0cmluZ1xuICAvKipcbiAgICogUXVlcnkgc3RyaW5nIHNlY3Rpb24gb2YgYFVSTGAgcGFyc2VkIGFzIGFuIG9iamVjdC5cbiAgICovXG4gIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeVxuICAvKipcbiAgICogYFN0cmluZ2Agb2YgdGhlIGFjdHVhbCBwYXRoIGluY2x1ZGluZyBxdWVyeS5cbiAgICovXG4gIGFzUGF0aD86IHN0cmluZ1xuICAvKipcbiAgICogYENvbXBvbmVudGAgdGhlIHRyZWUgb2YgdGhlIEFwcCB0byB1c2UgaWYgbmVlZGluZyB0byByZW5kZXIgc2VwYXJhdGVseVxuICAgKi9cbiAgQXBwVHJlZTogQXBwVHJlZVR5cGVcbn1cblxuZXhwb3J0IHR5cGUgQXBwQ29udGV4dFR5cGU8UiBleHRlbmRzIE5leHRSb3V0ZXIgPSBOZXh0Um91dGVyPiA9IHtcbiAgQ29tcG9uZW50OiBOZXh0Q29tcG9uZW50VHlwZTxOZXh0UGFnZUNvbnRleHQ+XG4gIEFwcFRyZWU6IEFwcFRyZWVUeXBlXG4gIGN0eDogTmV4dFBhZ2VDb250ZXh0XG4gIHJvdXRlcjogUlxufVxuXG5leHBvcnQgdHlwZSBBcHBJbml0aWFsUHJvcHMgPSB7XG4gIHBhZ2VQcm9wczogYW55XG59XG5cbmV4cG9ydCB0eXBlIEFwcFByb3BzVHlwZTxcbiAgUiBleHRlbmRzIE5leHRSb3V0ZXIgPSBOZXh0Um91dGVyLFxuICBQID0ge31cbj4gPSBBcHBJbml0aWFsUHJvcHMgJiB7XG4gIENvbXBvbmVudDogTmV4dENvbXBvbmVudFR5cGU8TmV4dFBhZ2VDb250ZXh0LCBhbnksIFA+XG4gIHJvdXRlcjogUlxuICBfX05fU1NHPzogYm9vbGVhblxuICBfX05fU1NQPzogYm9vbGVhblxufVxuXG5leHBvcnQgdHlwZSBEb2N1bWVudENvbnRleHQgPSBOZXh0UGFnZUNvbnRleHQgJiB7XG4gIHJlbmRlclBhZ2U6IFJlbmRlclBhZ2Vcbn1cblxuZXhwb3J0IHR5cGUgRG9jdW1lbnRJbml0aWFsUHJvcHMgPSBSZW5kZXJQYWdlUmVzdWx0ICYge1xuICBzdHlsZXM/OiBSZWFjdC5SZWFjdEVsZW1lbnRbXSB8IFJlYWN0LlJlYWN0RnJhZ21lbnRcbn1cblxuZXhwb3J0IHR5cGUgRG9jdW1lbnRQcm9wcyA9IERvY3VtZW50SW5pdGlhbFByb3BzICYge1xuICBfX05FWFRfREFUQV9fOiBORVhUX0RBVEFcbiAgZGFuZ2Vyb3VzQXNQYXRoOiBzdHJpbmdcbiAgZG9jQ29tcG9uZW50c1JlbmRlcmVkOiB7XG4gICAgSHRtbD86IGJvb2xlYW5cbiAgICBNYWluPzogYm9vbGVhblxuICAgIEhlYWQ/OiBib29sZWFuXG4gICAgTmV4dFNjcmlwdD86IGJvb2xlYW5cbiAgfVxuICBidWlsZE1hbmlmZXN0OiBCdWlsZE1hbmlmZXN0XG4gIGFtcFBhdGg6IHN0cmluZ1xuICBpbkFtcE1vZGU6IGJvb2xlYW5cbiAgaHlicmlkQW1wOiBib29sZWFuXG4gIGlzRGV2ZWxvcG1lbnQ6IGJvb2xlYW5cbiAgZHluYW1pY0ltcG9ydHM6IE1hbmlmZXN0SXRlbVtdXG4gIGFzc2V0UHJlZml4Pzogc3RyaW5nXG4gIGNhbm9uaWNhbEJhc2U6IHN0cmluZ1xuICBoZWFkVGFnczogYW55W11cbiAgdW5zdGFibGVfcnVudGltZUpTPzogZmFsc2VcbiAgZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmc6IHN0cmluZ1xuICBsb2NhbGU/OiBzdHJpbmdcbn1cblxuLyoqXG4gKiBOZXh0IGBBUElgIHJvdXRlIHJlcXVlc3RcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBOZXh0QXBpUmVxdWVzdCBleHRlbmRzIEluY29taW5nTWVzc2FnZSB7XG4gIC8qKlxuICAgKiBPYmplY3Qgb2YgYHF1ZXJ5YCB2YWx1ZXMgZnJvbSB1cmxcbiAgICovXG4gIHF1ZXJ5OiB7XG4gICAgW2tleTogc3RyaW5nXTogc3RyaW5nIHwgc3RyaW5nW11cbiAgfVxuICAvKipcbiAgICogT2JqZWN0IG9mIGBjb29raWVzYCBmcm9tIGhlYWRlclxuICAgKi9cbiAgY29va2llczoge1xuICAgIFtrZXk6IHN0cmluZ106IHN0cmluZ1xuICB9XG5cbiAgYm9keTogYW55XG5cbiAgZW52OiBFbnZcblxuICBwcmV2aWV3PzogYm9vbGVhblxuICAvKipcbiAgICogUHJldmlldyBkYXRhIHNldCBvbiB0aGUgcmVxdWVzdCwgaWYgYW55XG4gICAqICovXG4gIHByZXZpZXdEYXRhPzogYW55XG59XG5cbi8qKlxuICogU2VuZCBib2R5IG9mIHJlc3BvbnNlXG4gKi9cbnR5cGUgU2VuZDxUPiA9IChib2R5OiBUKSA9PiB2b2lkXG5cbi8qKlxuICogTmV4dCBgQVBJYCByb3V0ZSByZXNwb25zZVxuICovXG5leHBvcnQgdHlwZSBOZXh0QXBpUmVzcG9uc2U8VCA9IGFueT4gPSBTZXJ2ZXJSZXNwb25zZSAmIHtcbiAgLyoqXG4gICAqIFNlbmQgZGF0YSBgYW55YCBkYXRhIGluIHJlc3BvbnNlXG4gICAqL1xuICBzZW5kOiBTZW5kPFQ+XG4gIC8qKlxuICAgKiBTZW5kIGRhdGEgYGpzb25gIGRhdGEgaW4gcmVzcG9uc2VcbiAgICovXG4gIGpzb246IFNlbmQ8VD5cbiAgc3RhdHVzOiAoc3RhdHVzQ29kZTogbnVtYmVyKSA9PiBOZXh0QXBpUmVzcG9uc2U8VD5cbiAgcmVkaXJlY3QodXJsOiBzdHJpbmcpOiBOZXh0QXBpUmVzcG9uc2U8VD5cbiAgcmVkaXJlY3Qoc3RhdHVzOiBudW1iZXIsIHVybDogc3RyaW5nKTogTmV4dEFwaVJlc3BvbnNlPFQ+XG5cbiAgLyoqXG4gICAqIFNldCBwcmV2aWV3IGRhdGEgZm9yIE5leHQuanMnIHByZXJlbmRlciBtb2RlXG4gICAqL1xuICBzZXRQcmV2aWV3RGF0YTogKFxuICAgIGRhdGE6IG9iamVjdCB8IHN0cmluZyxcbiAgICBvcHRpb25zPzoge1xuICAgICAgLyoqXG4gICAgICAgKiBTcGVjaWZpZXMgdGhlIG51bWJlciAoaW4gc2Vjb25kcykgZm9yIHRoZSBwcmV2aWV3IHNlc3Npb24gdG8gbGFzdCBmb3IuXG4gICAgICAgKiBUaGUgZ2l2ZW4gbnVtYmVyIHdpbGwgYmUgY29udmVydGVkIHRvIGFuIGludGVnZXIgYnkgcm91bmRpbmcgZG93bi5cbiAgICAgICAqIEJ5IGRlZmF1bHQsIG5vIG1heGltdW0gYWdlIGlzIHNldCBhbmQgdGhlIHByZXZpZXcgc2Vzc2lvbiBmaW5pc2hlc1xuICAgICAgICogd2hlbiB0aGUgY2xpZW50IHNodXRzIGRvd24gKGJyb3dzZXIgaXMgY2xvc2VkKS5cbiAgICAgICAqL1xuICAgICAgbWF4QWdlPzogbnVtYmVyXG4gICAgfVxuICApID0+IE5leHRBcGlSZXNwb25zZTxUPlxuICBjbGVhclByZXZpZXdEYXRhOiAoKSA9PiBOZXh0QXBpUmVzcG9uc2U8VD5cbn1cblxuLyoqXG4gKiBOZXh0IGBBUElgIHJvdXRlIGhhbmRsZXJcbiAqL1xuZXhwb3J0IHR5cGUgTmV4dEFwaUhhbmRsZXI8VCA9IGFueT4gPSAoXG4gIHJlcTogTmV4dEFwaVJlcXVlc3QsXG4gIHJlczogTmV4dEFwaVJlc3BvbnNlPFQ+XG4pID0+IHZvaWQgfCBQcm9taXNlPHZvaWQ+XG5cbi8qKlxuICogVXRpbHNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV4ZWNPbmNlPFQgZXh0ZW5kcyAoLi4uYXJnczogYW55W10pID0+IFJldHVyblR5cGU8VD4+KFxuICBmbjogVFxuKTogVCB7XG4gIGxldCB1c2VkID0gZmFsc2VcbiAgbGV0IHJlc3VsdDogUmV0dXJuVHlwZTxUPlxuXG4gIHJldHVybiAoKC4uLmFyZ3M6IGFueVtdKSA9PiB7XG4gICAgaWYgKCF1c2VkKSB7XG4gICAgICB1c2VkID0gdHJ1ZVxuICAgICAgcmVzdWx0ID0gZm4oLi4uYXJncylcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdFxuICB9KSBhcyBUXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRMb2NhdGlvbk9yaWdpbigpIHtcbiAgY29uc3QgeyBwcm90b2NvbCwgaG9zdG5hbWUsIHBvcnQgfSA9IHdpbmRvdy5sb2NhdGlvblxuICByZXR1cm4gYCR7cHJvdG9jb2x9Ly8ke2hvc3RuYW1lfSR7cG9ydCA/ICc6JyArIHBvcnQgOiAnJ31gXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRVUkwoKSB7XG4gIGNvbnN0IHsgaHJlZiB9ID0gd2luZG93LmxvY2F0aW9uXG4gIGNvbnN0IG9yaWdpbiA9IGdldExvY2F0aW9uT3JpZ2luKClcbiAgcmV0dXJuIGhyZWYuc3Vic3RyaW5nKG9yaWdpbi5sZW5ndGgpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXREaXNwbGF5TmFtZTxQPihDb21wb25lbnQ6IENvbXBvbmVudFR5cGU8UD4pIHtcbiAgcmV0dXJuIHR5cGVvZiBDb21wb25lbnQgPT09ICdzdHJpbmcnXG4gICAgPyBDb21wb25lbnRcbiAgICA6IENvbXBvbmVudC5kaXNwbGF5TmFtZSB8fCBDb21wb25lbnQubmFtZSB8fCAnVW5rbm93bidcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzUmVzU2VudChyZXM6IFNlcnZlclJlc3BvbnNlKSB7XG4gIHJldHVybiByZXMuZmluaXNoZWQgfHwgcmVzLmhlYWRlcnNTZW50XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBsb2FkR2V0SW5pdGlhbFByb3BzPFxuICBDIGV4dGVuZHMgQmFzZUNvbnRleHQsXG4gIElQID0ge30sXG4gIFAgPSB7fVxuPihBcHA6IE5leHRDb21wb25lbnRUeXBlPEMsIElQLCBQPiwgY3R4OiBDKTogUHJvbWlzZTxJUD4ge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGlmIChBcHAucHJvdG90eXBlPy5nZXRJbml0aWFsUHJvcHMpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSBgXCIke2dldERpc3BsYXlOYW1lKFxuICAgICAgICBBcHBcbiAgICAgICl9LmdldEluaXRpYWxQcm9wcygpXCIgaXMgZGVmaW5lZCBhcyBhbiBpbnN0YW5jZSBtZXRob2QgLSB2aXNpdCBodHRwczovL2Vyci5zaC92ZXJjZWwvbmV4dC5qcy9nZXQtaW5pdGlhbC1wcm9wcy1hcy1hbi1pbnN0YW5jZS1tZXRob2QgZm9yIG1vcmUgaW5mb3JtYXRpb24uYFxuICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpXG4gICAgfVxuICB9XG4gIC8vIHdoZW4gY2FsbGVkIGZyb20gX2FwcCBgY3R4YCBpcyBuZXN0ZWQgaW4gYGN0eGBcbiAgY29uc3QgcmVzID0gY3R4LnJlcyB8fCAoY3R4LmN0eCAmJiBjdHguY3R4LnJlcylcblxuICBpZiAoIUFwcC5nZXRJbml0aWFsUHJvcHMpIHtcbiAgICBpZiAoY3R4LmN0eCAmJiBjdHguQ29tcG9uZW50KSB7XG4gICAgICAvLyBAdHMtaWdub3JlIHBhZ2VQcm9wcyBkZWZhdWx0XG4gICAgICByZXR1cm4ge1xuICAgICAgICBwYWdlUHJvcHM6IGF3YWl0IGxvYWRHZXRJbml0aWFsUHJvcHMoY3R4LkNvbXBvbmVudCwgY3R4LmN0eCksXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7fSBhcyBJUFxuICB9XG5cbiAgY29uc3QgcHJvcHMgPSBhd2FpdCBBcHAuZ2V0SW5pdGlhbFByb3BzKGN0eClcblxuICBpZiAocmVzICYmIGlzUmVzU2VudChyZXMpKSB7XG4gICAgcmV0dXJuIHByb3BzXG4gIH1cblxuICBpZiAoIXByb3BzKSB7XG4gICAgY29uc3QgbWVzc2FnZSA9IGBcIiR7Z2V0RGlzcGxheU5hbWUoXG4gICAgICBBcHBcbiAgICApfS5nZXRJbml0aWFsUHJvcHMoKVwiIHNob3VsZCByZXNvbHZlIHRvIGFuIG9iamVjdC4gQnV0IGZvdW5kIFwiJHtwcm9wc31cIiBpbnN0ZWFkLmBcbiAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSlcbiAgfVxuXG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgaWYgKE9iamVjdC5rZXlzKHByb3BzKS5sZW5ndGggPT09IDAgJiYgIWN0eC5jdHgpIHtcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgYCR7Z2V0RGlzcGxheU5hbWUoXG4gICAgICAgICAgQXBwXG4gICAgICAgICl9IHJldHVybmVkIGFuIGVtcHR5IG9iamVjdCBmcm9tIFxcYGdldEluaXRpYWxQcm9wc1xcYC4gVGhpcyBkZS1vcHRpbWl6ZXMgYW5kIHByZXZlbnRzIGF1dG9tYXRpYyBzdGF0aWMgb3B0aW1pemF0aW9uLiBodHRwczovL2Vyci5zaC92ZXJjZWwvbmV4dC5qcy9lbXB0eS1vYmplY3QtZ2V0SW5pdGlhbFByb3BzYFxuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBwcm9wc1xufVxuXG5leHBvcnQgY29uc3QgdXJsT2JqZWN0S2V5cyA9IFtcbiAgJ2F1dGgnLFxuICAnaGFzaCcsXG4gICdob3N0JyxcbiAgJ2hvc3RuYW1lJyxcbiAgJ2hyZWYnLFxuICAncGF0aCcsXG4gICdwYXRobmFtZScsXG4gICdwb3J0JyxcbiAgJ3Byb3RvY29sJyxcbiAgJ3F1ZXJ5JyxcbiAgJ3NlYXJjaCcsXG4gICdzbGFzaGVzJyxcbl1cblxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFdpdGhWYWxpZGF0aW9uKHVybDogVXJsT2JqZWN0KTogc3RyaW5nIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgaWYgKHVybCAhPT0gbnVsbCAmJiB0eXBlb2YgdXJsID09PSAnb2JqZWN0Jykge1xuICAgICAgT2JqZWN0LmtleXModXJsKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgaWYgKHVybE9iamVjdEtleXMuaW5kZXhPZihrZXkpID09PSAtMSkge1xuICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgIGBVbmtub3duIGtleSBwYXNzZWQgdmlhIHVybE9iamVjdCBpbnRvIHVybC5mb3JtYXQ6ICR7a2V5fWBcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGZvcm1hdFVybCh1cmwpXG59XG5cbmV4cG9ydCBjb25zdCBTUCA9IHR5cGVvZiBwZXJmb3JtYW5jZSAhPT0gJ3VuZGVmaW5lZCdcbmV4cG9ydCBjb25zdCBTVCA9XG4gIFNQICYmXG4gIHR5cGVvZiBwZXJmb3JtYW5jZS5tYXJrID09PSAnZnVuY3Rpb24nICYmXG4gIHR5cGVvZiBwZXJmb3JtYW5jZS5tZWFzdXJlID09PSAnZnVuY3Rpb24nXG4iLCJcInVzZSBzdHJpY3RcIjtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLm5vcm1hbGl6ZVBhdGhTZXA9bm9ybWFsaXplUGF0aFNlcDtleHBvcnRzLmRlbm9ybWFsaXplUGFnZVBhdGg9ZGVub3JtYWxpemVQYWdlUGF0aDtmdW5jdGlvbiBub3JtYWxpemVQYXRoU2VwKHBhdGgpe3JldHVybiBwYXRoLnJlcGxhY2UoL1xcXFwvZywnLycpO31mdW5jdGlvbiBkZW5vcm1hbGl6ZVBhZ2VQYXRoKHBhZ2Upe3BhZ2U9bm9ybWFsaXplUGF0aFNlcChwYWdlKTtpZihwYWdlLnN0YXJ0c1dpdGgoJy9pbmRleC8nKSl7cGFnZT1wYWdlLnNsaWNlKDYpO31lbHNlIGlmKHBhZ2U9PT0nL2luZGV4Jyl7cGFnZT0nLyc7fXJldHVybiBwYWdlO31cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRlbm9ybWFsaXplLXBhZ2UtcGF0aC5qcy5tYXAiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZGlzdC9jbGllbnQvbGluaycpXG4iLCJmdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgIFwiZGVmYXVsdFwiOiBvYmpcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0OyIsInZhciBfdHlwZW9mID0gcmVxdWlyZShcIi4uL2hlbHBlcnMvdHlwZW9mXCIpO1xuXG5mdW5jdGlvbiBfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUoKSB7XG4gIGlmICh0eXBlb2YgV2Vha01hcCAhPT0gXCJmdW5jdGlvblwiKSByZXR1cm4gbnVsbDtcbiAgdmFyIGNhY2hlID0gbmV3IFdlYWtNYXAoKTtcblxuICBfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUgPSBmdW5jdGlvbiBfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUoKSB7XG4gICAgcmV0dXJuIGNhY2hlO1xuICB9O1xuXG4gIHJldHVybiBjYWNoZTtcbn1cblxuZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQob2JqKSB7XG4gIGlmIChvYmogJiYgb2JqLl9fZXNNb2R1bGUpIHtcbiAgICByZXR1cm4gb2JqO1xuICB9XG5cbiAgaWYgKG9iaiA9PT0gbnVsbCB8fCBfdHlwZW9mKG9iaikgIT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIG9iaiAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIFwiZGVmYXVsdFwiOiBvYmpcbiAgICB9O1xuICB9XG5cbiAgdmFyIGNhY2hlID0gX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlKCk7XG5cbiAgaWYgKGNhY2hlICYmIGNhY2hlLmhhcyhvYmopKSB7XG4gICAgcmV0dXJuIGNhY2hlLmdldChvYmopO1xuICB9XG5cbiAgdmFyIG5ld09iaiA9IHt9O1xuICB2YXIgaGFzUHJvcGVydHlEZXNjcmlwdG9yID0gT2JqZWN0LmRlZmluZVByb3BlcnR5ICYmIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG5cbiAgZm9yICh2YXIga2V5IGluIG9iaikge1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrZXkpKSB7XG4gICAgICB2YXIgZGVzYyA9IGhhc1Byb3BlcnR5RGVzY3JpcHRvciA/IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Iob2JqLCBrZXkpIDogbnVsbDtcblxuICAgICAgaWYgKGRlc2MgJiYgKGRlc2MuZ2V0IHx8IGRlc2Muc2V0KSkge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobmV3T2JqLCBrZXksIGRlc2MpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmV3T2JqW2tleV0gPSBvYmpba2V5XTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBuZXdPYmpbXCJkZWZhdWx0XCJdID0gb2JqO1xuXG4gIGlmIChjYWNoZSkge1xuICAgIGNhY2hlLnNldChvYmosIG5ld09iaik7XG4gIH1cblxuICByZXR1cm4gbmV3T2JqO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkOyIsImZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7XG4gIFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjtcblxuICBpZiAodHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPT09IFwic3ltYm9sXCIpIHtcbiAgICBtb2R1bGUuZXhwb3J0cyA9IF90eXBlb2YgPSBmdW5jdGlvbiBfdHlwZW9mKG9iaikge1xuICAgICAgcmV0dXJuIHR5cGVvZiBvYmo7XG4gICAgfTtcbiAgfSBlbHNlIHtcbiAgICBtb2R1bGUuZXhwb3J0cyA9IF90eXBlb2YgPSBmdW5jdGlvbiBfdHlwZW9mKG9iaikge1xuICAgICAgcmV0dXJuIG9iaiAmJiB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgb2JqLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgb2JqICE9PSBTeW1ib2wucHJvdG90eXBlID8gXCJzeW1ib2xcIiA6IHR5cGVvZiBvYmo7XG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiBfdHlwZW9mKG9iaik7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX3R5cGVvZjsiLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcbmltcG9ydCB7IENzc0Jhc2VsaW5lIH0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XG5cbmltcG9ydCBQb2tlbW9uSW5mbyBmcm9tIFwiLi4vY29tcG9uZW50cy9Qb2tlbW9uSW5mb1wiO1xuaW1wb3J0IFBva2Vtb25GaWx0ZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvUG9rZW1vbkZpbHRlclwiO1xuaW1wb3J0IFBva2Vtb25UYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9Qb2tlbW9uVGFibGVcIjtcblxuaW1wb3J0IHN0b3JlIGZyb20gXCIuLi9zcmMvc3RvcmVcIjtcblxuY29uc3QgVGl0bGUgPSBzdHlsZWQuaDFgXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbmA7XG5jb25zdCBQYWdlQ29udGFpbmVyID0gc3R5bGVkLmRpdmBcbiAgbWFyZ2luOiBhdXRvO1xuICB3aWR0aDogODAwcHg7XG4gIHBhZGRpbmctdG9wOiAxZW07XG5gO1xuY29uc3QgVHdvQ29sdW1uTGF5b3V0ID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiA4MCUgMjAlO1xuICBncmlkLWNvbHVtbi1nYXA6IDFyZW07XG5gO1xuXG5jb25zdCBIb21lID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxQYWdlQ29udGFpbmVyPlxuICAgICAgPENzc0Jhc2VsaW5lIC8+XG4gICAgICA8VGl0bGU+UG9rZW1vbiBTZWFyY2g8L1RpdGxlPlxuICAgICAgPFR3b0NvbHVtbkxheW91dD5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8UG9rZW1vbkZpbHRlciAvPlxuICAgICAgICAgIDxQb2tlbW9uVGFibGUgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxQb2tlbW9uSW5mbyAvPlxuICAgICAgPC9Ud29Db2x1bW5MYXlvdXQ+XG4gICAgPC9QYWdlQ29udGFpbmVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgSG9tZTtcbiIsImltcG9ydCBQcm9wVHlwZXMgZnJvbSBcInByb3AtdHlwZXNcIjtcblxuY29uc3QgUG9rZW1vblR5cGUgPSBQcm9wVHlwZXMuc2hhcGUoe1xuICBpZDogUHJvcFR5cGVzLm51bWJlci5pc1JlcXVpcmVkLFxuICBuYW1lOiBQcm9wVHlwZXMuc2hhcGUoe1xuICAgIGVuZ2xpc2g6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgICBqYXBhbmVzZTogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICAgIGNoaW5lc2U6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgICBmcmVuY2g6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgfSksXG4gIHR5cGU6IFByb3BUeXBlcy5hcnJheU9mKFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCksXG4gIGJhc2U6IFByb3BUeXBlcy5zaGFwZSh7XG4gICAgSFA6IFByb3BUeXBlcy5udW1iZXIuaXNSZXF1aXJlZCxcbiAgICBBdHRhY2s6IFByb3BUeXBlcy5udW1iZXIuaXNSZXF1aXJlZCxcbiAgICBEZWZlbnNlOiBQcm9wVHlwZXMubnVtYmVyLmlzUmVxdWlyZWQsXG4gICAgXCJTcC4gQXR0YWNrXCI6IFByb3BUeXBlcy5udW1iZXIuaXNSZXF1aXJlZCxcbiAgICBcIlNwLiBEZWZlbnNlXCI6IFByb3BUeXBlcy5udW1iZXIuaXNSZXF1aXJlZCxcbiAgICBTcGVlZDogUHJvcFR5cGVzLm51bWJlci5pc1JlcXVpcmVkLFxuICB9KSxcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBQb2tlbW9uVHlwZTtcbiIsImltcG9ydCB7IG1ha2VBdXRvT2JzZXJ2YWJsZSB9IGZyb20gXCJtb2J4XCI7XG5cbmNsYXNzIFN0b3JlIHtcbiAgcG9rZW1vbiA9IHJlcXVpcmUoXCIuLi9zcmMvcG9rZW1vbi5qc29uXCIpO1xuICBmaWx0ZXIgPSBcIlwiO1xuICBzZWxlY3RlZFBva2Vtb24gPSBudWxsO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIG1ha2VBdXRvT2JzZXJ2YWJsZSh0aGlzKTtcbiAgfVxuXG4gIHNldEZpbHRlcihmaWx0ZXIpIHtcbiAgICB0aGlzLmZpbHRlciA9IGZpbHRlcjtcbiAgfVxuICBzZXRTZWxlY3RlZFBva2Vtb24oc2VsZWN0ZWRQb2tlbW9uKSB7XG4gICAgdGhpcy5zZWxlY3RlZFBva2Vtb24gPSBzZWxlY3RlZFBva2Vtb247XG4gIH1cbn1cblxuY29uc3Qgc3RvcmUgPSBuZXcgU3RvcmUoKTtcblxuZXhwb3J0IGRlZmF1bHQgc3RvcmU7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAZW1vdGlvbi9zdHlsZWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibW9ieFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJtb2J4LXJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInByb3AtdHlwZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtaXNcIik7Il0sInNvdXJjZVJvb3QiOiIifQ==