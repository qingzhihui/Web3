import React, { useCallback, useRef } from "react";
import { useState, useEffect } from "react";


//  1.了解了清理函数及如何使用计算器捕获陷阱
//  2.使用事件侦查器

let timerID = 0;
const Timer = () => {
  const [count, setCount] = useState<any>(0);
  const [tooltipShown, setTooltipShown] = useState(false);

  useEffect(() => {
    timerID++;
    const timer = setInterval(() => {
      setCount((currentCount: any) => {
        console.log(`Timer ${timerID} starts ${currentCount}`);
        return currentCount + 1;
      });
    }, 1000);
    return () => {
      clearInterval(timer);
    };
  }, []);

  const tooltipProperRef = useRef<HTMLDivElement>(null);
  const onMouseOver = useCallback(() => {
    setTooltipShown(true);
  }, [tooltipShown]);
  const onMouseOut = useCallback(() => {
    setTooltipShown(false);
  }, [tooltipShown]);
  useEffect(() => {
    console.log("Add event listeners");
    tooltipProperRef.current?.addEventListener("mouseover", onMouseOver);
    tooltipProperRef.current?.addEventListener("mouseout", onMouseOut);
    const ref = tooltipProperRef.current;
    return () => {
      console.log("Remove event listeners");
      ref?.removeEventListener("mouseover", onMouseOver);
      ref?.removeEventListener("mouseout", onMouseOut);
    };
  }, [onMouseOver, onMouseOut]);

  return (
    <div>
      <div>Timer: {count}</div>
      <div ref={tooltipProperRef}>Toopltip popper</div>
      {tooltipShown && <div>Toopltip Timer: {count}</div>}
    </div>
  );
};

const Index = () => {
  const [index, setIndex] = useState(0);
  const updataIndex = useCallback(() => setIndex(index + 1), [index]);
  return (
    <div>
      <Timer key={index} />
      <div>
        <button onClick={updataIndex}>Update Index</button>
      </div>
    </div>
  );
};

export default Index;
