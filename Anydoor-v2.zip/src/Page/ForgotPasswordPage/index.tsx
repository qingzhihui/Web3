import { Button, Form, Input, Steps } from "antd";
import { useEffect, useState } from "react";
import "./index.css";

// 忘记密码界面
const ForgotPasswordPage = () => {
  let timer: number; //验证码定时器
  const [second, setSecond] = useState(59); //倒计时秒数
  const [btnDisabled, setBtnDisabled] = useState(false); //按钮是否可点击，false可点击

  const [current, setCurrent] = useState(0); //用户判断在第几步骤

  // 初始化时清除定时器
  useEffect(() => {
    clearInterval(timer);
    return () => clearInterval(timer);
  }, []);

  // 监听秒数的变动
  useEffect(() => {
    if (second > 0 && second < 60) {
    } else {
      // 定时器超过时间后，可以重新发送验证码
      clearInterval(timer);
      // 可点击
      setBtnDisabled(false);
      setSecond(60);
    }
  }, [second]);

  // 发送验证码，开启倒计时
  const sendCode = () => {
    // 倒计时递减
    timer = setInterval(() => setSecond((pre) => pre - 1), 1000);
    // 不可点击
    setBtnDisabled(true);
  };

  // 提交手机与密码
  const onFinish = (values: any) => {
    console.log("手机与密码值:", values);
    setCurrent(current + 1); // (验证码成功)后在开启下一步
  };

  // 提交确认密码
  const onFinish1 = (values: any) => {
    console.log("确认密码值:", values);
    setCurrent(current + 1); // (验证码成功)后在开启下一步
  };

  const steps = [
    {
      title: "验证手机号",
      content: (
        <div>
          <Form
            name="basic"
            labelCol={{ span: 6 }}
            wrapperCol={{ span: 14 }}
            // style={{ maxWidth: 600 }}
            initialValues={{ remember: true }}
            onFinish={onFinish}
            autoComplete="off"
          >
            <Form.Item label="手机号" name="phone">
              <Input />
            </Form.Item>

            <Form.Item label="验证码" name="yzm">
              <div className="PhoneyzmBox">
                <div>
                  <Input />
                </div>
                <div>
                  <Button
                    type="primary"
                    disabled={btnDisabled}
                    onClick={() => {
                      sendCode();
                    }}
                  >
                    {!btnDisabled ? "获取验证码" : `${second}s后重发`}
                  </Button>
                </div>
              </div>
            </Form.Item>

            <Form.Item wrapperCol={{ offset: 11, span: 12 }}>
              <Button type="primary" htmlType="submit">
                下一步
              </Button>
            </Form.Item>
          </Form>
        </div>
      ),
    },
    {
      title: "设置新密码",
      content: (
        <div>
          <Form
            name="basic"
            labelCol={{ span: 6 }}
            wrapperCol={{ span: 14 }}
            // style={{ maxWidth: 600 }}
            initialValues={{ remember: true }}
            onFinish={onFinish1}
            autoComplete="off"
          >
            <Form.Item label="新密码" name="newpassword">
              <Input />
            </Form.Item>
            <Form.Item label="确认密码" name="confirmPassword">
              <Input />
            </Form.Item>

            <Form.Item wrapperCol={{ offset: 11, span: 12 }}>
              <Button type="primary" htmlType="submit">
                下一步
              </Button>
            </Form.Item>
          </Form>
        </div>
      ),
    },
    {
      title: "完成",
      content: <div className="reviseAccomplish">密码修改成功</div>,
    },
  ];

  const items = steps.map((item) => ({ key: item.title, title: item.title }));

  const contentStyle: React.CSSProperties = {
    marginTop: 30,
  };

  const tijiao = () => {
    console.log("点击了提交，跳转登录界面");
  };

  return (
    <div className="PassBox">
      <div className="headerBox">
        <div className="headerxiantiao"></div>
        <div className="headertitle">&nbsp;&nbsp;&nbsp;找回密码</div>
      </div>
      <div className="centerContBox">
        <Steps current={current} items={items} />
        <div style={contentStyle}>{steps[current].content}</div>
        <div className="xiayibuBtn" style={{ marginTop: 24 }}>
          {current === steps.length - 1 && (
            <Button type="primary" onClick={tijiao}>
              去登录
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;
