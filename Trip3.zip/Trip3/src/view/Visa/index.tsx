import React, { useState } from 'react';
import type { RadioChangeEvent } from 'antd';
import './index.scss'
import { Input, Radio, Select } from 'antd';

export default function Index() {
  const [value1, setValue1] = useState(1);
  const [value2, setValue2] = useState(1);
  const [value3, setValue3] = useState(1);
  const [value4, setValue4] = useState(1);
  const [value5, setValue5] = useState(1);

  const onChange1 = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue1(e.target.value);
  };
  const onChange2 = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue2(e.target.value);
  };
  const onChange3 = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue3(e.target.value);
  };
  const onChange4 = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue4(e.target.value);
  };
  const onChange5 = (e: RadioChangeEvent) => {
    console.log('radio checked', e.target.value);
    setValue5(e.target.value);
  };
  const handleChange1 = (value: string) => {
    console.log(`selected ${value}`);
  };
  const handleChange2 = (value: string) => {
    console.log(`selected ${value}`);
  };
  const handleChange3 = (value: string) => {
    console.log(`selected ${value}`);
  };
  const handleChange4 = (value: string) => {
    console.log(`selected ${value}`);
  };
  const handleChange5 = (value: string) => {
    console.log(`selected ${value}`);
  };
  return (
    <div className='visa'>
      <div className='visaname'>Visa Online Application</div>
      <div className='application'>
        <div>Application number: 2022122033120318260</div>
        <span>The application number is an important basis for you to retrieve the data and make an appointment, please keep it in mind.</span>
      </div>
      <div className='basicinformation'>
        <div className='basic'>Basic Information</div>
        <div className='basicinput'>
          <div className='baceinput'>
            <Input placeholder="Last name" bordered={false} />
          </div>
          <div className='baceinput'>
            <Input placeholder="First & middle name" bordered={false} />
          </div>
          <div className='baceinput'>
            <Input placeholder="alias or former name" bordered={false} />

          </div>
          <div className='baceinput'><Input placeholder="Date of birth" bordered={false} /><img src={require('@/assets/image/inputsdate.png')} alt="" /></div>
          <div className='baceinput'>
            <Radio.Group onChange={onChange1} value={value1}>
              <Radio value={1}>Male</Radio>
              <Radio value={2}>Female</Radio>
            </Radio.Group>
          </div>
        </div>
      </div>
      <div className='birthplace'>
        <div className='birth'>Birth place</div>
        <div className='birthseled'>
          <Select
            defaultValue="lucy"
            style={{ width: 250 }}
            onChange={handleChange1}
            options={[
              {
                value: 'jack',
                label: 'Jack',
              }
            ]}
          />
          <Select
            defaultValue="lucy"
            style={{ width: 250 }}
            onChange={handleChange2}
            options={[
              {
                value: 'jack',
                label: 'Jack',
              }
            ]}
          />
          <Select
            defaultValue="lucy"
            style={{ width: 250 }}
            onChange={handleChange3}
            options={[
              {
                value: 'jack',
                label: 'Jack',
              }
            ]}
          />
        </div>
      </div>
      <div className='status'>
        <div className='statustitle'>Marital status</div>
        <div className='statusseled'>
          <Radio.Group onChange={onChange2} value={value2}>
            <Radio value={1}>married</Radio>
            <Radio value={2}>single</Radio>
            <Radio value={3}>divorce</Radio>
            <Radio value={4}>Widow</Radio>
          </Radio.Group>
        </div>
      </div>
      <div className='assistance'>
        <div className='assistancetitle'>Nationality and permanent residence assistance</div>
        <div className='seleinput'>
          <Select
            defaultValue="lucy"
            style={{ width: 120 }}
            onChange={handleChange4}
            options={[
              {
                value: 'jack',
                label: 'Jack',
              },
            ]}
          />
          <Input placeholder="Borderless" bordered={false} />
        </div>
        <div className='sametime'>
          <div className='timetitle'>Whether they have the nationality or resident status of other countries at the same time</div>
          <Radio.Group onChange={onChange3} value={value3}>
            <Radio value={1}>Yes</Radio>
            <Radio value={2}>Not</Radio>
          </Radio.Group>
        </div>
        <div className='resident'>
          <div className='residenttitle'>Have you ever held any other nationality or resident status</div>
          <Radio.Group onChange={onChange4} value={value4}>
            <Radio value={1}>Yes</Radio>
            <Radio value={2}>Not</Radio>
          </Radio.Group>
        </div>
      </div>
      <div className='passport'>
        <div className='passporttitle'>Passport Information</div>
        <div className='type'>Type of passport/travel document</div>
        <div className='sleled'>
          <Radio.Group onChange={onChange5} value={value5}>
            <Radio value={1}>International Relations</Radio>
            <Radio value={2}>official business</Radio>
            <Radio value={3}>official</Radio>
            <Radio value={4}>especially</Radio>
            <Radio value={5}>ordinary</Radio>
            <Radio value={6}>Other certificates</Radio>
          </Radio.Group>
        </div>
        <div className='passportinput'>
          <Input placeholder="Borderless" bordered={false} />
          <Select
            defaultValue="lucy"
            style={{ width: 120 }}
            onChange={handleChange5}
            options={[
              {
                value: 'jack',
                label: 'Jack',
              },
            ]}
          />
          <Input placeholder="Borderless" bordered={false} />
          <Input placeholder="Borderless" bordered={false} />
          <div><Input placeholder="Borderless" bordered={false} /></div>
          <div><Input placeholder="Borderless" bordered={false} /></div>
        </div>
      </div>
      <button>Submit</button>
    </div>
  )
}
