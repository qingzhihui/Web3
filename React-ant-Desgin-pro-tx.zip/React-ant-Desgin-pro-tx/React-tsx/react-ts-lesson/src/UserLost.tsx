import React, { Fragment } from "react";
interface IUser {
  id: number;
  name: string;
}
function UserLost() {
  let userList: IUser[] = [
    {
      id: 1,
      name: "user",
    },
  ];
  return (
    <div>
      {userList.map((item) => (
        <Fragment key={item.id}>{item.name}</Fragment>
      ))}
    </div>
  );
}

export default UserLost;
