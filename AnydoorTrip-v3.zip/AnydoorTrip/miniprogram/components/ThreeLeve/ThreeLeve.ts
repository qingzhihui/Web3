import api from '../../config/axios'
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    actonve: 1,
    ListCount: [],
    ListAreas: [],
    ListArovi: [],
    Numer: 0,
    show: false,
    country: {
      key: 0,
      value: "请选择"
    },
    areaName: {
      key: 0,
      value: "请选择"
    },
    aroviName: {
      key: 0,
      value: "请选择"
    },
    valueRervn: "",
  },

  /**
   * 组件的方法列表
   */
  methods: {
    tbtliArd(e: any) {
      this.setData({
        actonve: Number(e.target.dataset.id)
      })
    },
    VancellBind(event: any) {
      var that = this;
      this.data.ListCount.map((item: any) => {
        if (item.id === event.currentTarget.dataset.id) {
          that.setData({
            country: {
              key: item.id,
              value: item.text,
            },
            areaName: {
              key: 0,
              value: "请选择",
            },
            aroviName: {
              key: 0,
              value: "请选择",
            },
            actonve: 2,
            ListAreas: [],
            ListArovi: [],
          })
          that.RovinceData(item.id)
        }
      })
    },
    AreasBind(event: any) {
      var that = this;
      this.data.ListAreas.map((item: any) => {
        if (item.id === event.currentTarget.dataset.id) {
          that.setData({
            areaName: {
              key: item.id,
              value: item.text,
            },
            actonve: 3
          })
          that.AroviData(item.id)
        }
      })
    },
    AroviBind(event: any) {
      var that = this;
      this.data.ListArovi.map((item: any) => {
        if (item.id === event.currentTarget.dataset.id) {
          that.setData({
            aroviName: {
              key: item.id,
              value: item.text,
            },
          })
        }
      })
    },
    RovinceData(id: any) {
      api._get(`https://apis-01.anydoortrip.com/area/province_list?country_id=${id}`).then(res => {
        this.setData({
          ListAreas: res.data
        })
      }).catch(event => {
        console.log(event);
      })
    },
    AroviData(id: any) {
      api._get(`https://apis-01.anydoortrip.com/area/city_list?province_id=${id}`).then(res => {
        this.setData({
          ListArovi: res.data
        })
      }).catch(event => {
        console.log(event);
      })
    },
    showPopup() {
      this.setData({ show: true });
    },
    onClose() {
      this.setData({ show: false });
    },
    showPoClick() {
      var dateBuser = ''
      if (this.data.areaName.value === "请选择" && this.data.aroviName.value === "请选择") {
        dateBuser = `${this.data.country.value}`
      } else {
        dateBuser = `${this.data.country.value}/${this.data.areaName.value}/${this.data.aroviName.value}`
      }
      this.setData({
        show: false,
        valueRervn: dateBuser
      });
      this.triggerEvent('Three', dateBuser)
    }
  },
  attached: function () {
    api._get('https://apis-01.anydoortrip.com/area/country_list').then(res => {
      this.setData({
        ListCount: res.data
      })
    }).catch(event => {
      console.log(event);
    })
  }
})
