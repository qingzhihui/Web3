import { Button, Form, Input, Modal, Radio, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import "./index.css";

import { DeleteOutlined, FormOutlined } from "@ant-design/icons";
import { useState } from "react";

// 角色管理界面
const RoleManagement = () => {
  const [isaddRole, setAddRole] = useState(false);
  interface DataType {
    key: string;
    roleName: string;
    permissionCharacter: string;
    whetherOrNotAdmin: number;
    status: string;
    sort: string;
  }
  const data: DataType[] = [
    {
      key: "1",
      roleName: "管理员",
      permissionCharacter: "admin",
      whetherOrNotAdmin: 0,
      status: "点击禁用",
      sort: "1",
    },
    {
      key: "2",
      roleName: "普通用户",
      permissionCharacter: "public",
      whetherOrNotAdmin: 1,
      status: "点击禁用",
      sort: "2",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "序号",
      dataIndex: "name",
      key: "name",
      render: (_, record, i) => (
        <Space size="middle">
          <div>{i + 1}</div>
        </Space>
      ),
    },
    {
      title: "角色名",
      dataIndex: "roleName",
      key: "roleName",
    },
    {
      title: "权限字符",
      dataIndex: "permissionCharacter",
      key: "permissionCharacter",
    },
    {
      title: "是否管理员",
      // dataIndex: 'whetherOrNotAdmin',
      key: "whetherOrNotAdmin",
      render: (_, record) => (
        <Space size="middle">
          <div
            className={
              record.whetherOrNotAdmin == 0
                ? "role_whetherOrNot"
                : "role_whetherOrNot1"
            }
          >
            {record.whetherOrNotAdmin == 0 ? "是" : "否"}
          </div>
        </Space>
      ),
    },
    {
      title: "状态",
      key: "status",
      render: (_, record) => (
        <Space size="middle">
          <div className="role_tagsStyle">{record.status}</div>
        </Space>
      ),
    },
    {
      title: "排序",
      dataIndex: "sort",
      key: "sort",
    },
    {
      title: "操作",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <a onClick={uploadus(record)} className="publicStyleA" href="#">
            <span>
              <FormOutlined />
            </span>
          </a>
          <a onClick={deleteus(record)} className="publicStyleA" href="#">
            <span>
              <DeleteOutlined />
            </span>
          </a>
        </Space>
      ),
    },
  ];
  //   新增角色--提交按钮
  const addRoleBtn = (values: any) => {
    console.log("提交的数据:", values);
  };

  // 修改
  const uploadus = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };
  // 点击X关闭
  const handleCancel = () => {
    setAddRole(false);
  };

  // 点击新增管理员
  const roleAdd = () => {
    console.log("点击了新增管理员");
    setAddRole(true);
  };
  return (
    <div className="role_Box">
      <div className="role_headerBox">
        <div className="role_headerBox_thread"></div>
        <div className="role_headerBox_Tit">&nbsp;&nbsp;&nbsp; 角色管理</div>
        <div className="role_Add_moban">
          <div className="role_addAdminBtn" onClick={roleAdd}>
            新增角色
          </div>
          {/* 新增角色 */}
          <Modal
            className="us_addAdmin"
            footer={[null]}
            open={isaddRole}
            onCancel={handleCancel}
          >
            <div className="us_headerBox">
              <div className="us_headerBox_thread"></div>
              <div className="us_headerBox_Tit">&nbsp;&nbsp;&nbsp;新增角色</div>
            </div>
            <div className="us_addAdmin_Box">
              <Form
                name="basic"
                labelCol={{ span: 6 }}
                wrapperCol={{ span: 18 }}
                style={{ maxWidth: 600 }}
                initialValues={{ remember: true }}
                onFinish={addRoleBtn}
                autoComplete="off"
              >
                <Form.Item label="角色名称" name="roleName">
                  <Input placeholder="请输入角色名称" />
                </Form.Item>
                <Form.Item label="权限字符" name="permissionCharacter">
                  <Input placeholder="请输入权限字符" />
                </Form.Item>
                <Form.Item label="是否管理员" name="isAdminPerson">
                  <Radio.Group>
                    <Radio value="是"> 是 </Radio>
                    <Radio value="否"> 否 </Radio>
                  </Radio.Group>
                </Form.Item>
                <Form.Item label="状态" name="status">
                  <Radio.Group>
                    <Radio value="启用"> 启用 </Radio>
                    <Radio value="禁用"> 禁用 </Radio>
                  </Radio.Group>
                </Form.Item>

                <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                  <Button
                    className="us_btn"
                    size="middle"
                    type="primary"
                    htmlType="submit"
                  >
                    提交
                  </Button>
                </Form.Item>
              </Form>
            </div>
          </Modal>
        </div>
      </div>

      <div className="role_tableBox">
        <Table
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 550 }}
        />
      </div>
    </div>
  );
};

export default RoleManagement;
