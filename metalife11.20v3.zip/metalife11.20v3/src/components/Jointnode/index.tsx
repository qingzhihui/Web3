import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { Progress, Modal } from "antd";
import { useTranslation } from "react-i18next";
import Jointnode from "../../redux/PondJson/Jointnode.json";
import { PAIR_ABI } from "../../redux/Contract/pancakepair";
import more from "../../assets/image/more.png";
import { wben_ABI } from "../../redux/Contract/wbenjson";
import uparrow from "../../assets/image/UpArrow.png";
import downarrow from "../../assets/image/DownArrow.png";
import {
  CheckCircleOutlined,
  CloseCircleOutlined,
  RedoOutlined,
  QuestionCircleOutlined,
} from "@ant-design/icons";
import { Meta_ADDRESS, Meta_ABI } from "../../redux/Contract/MetaContract";
import toolNumber from "../../constants/sluine.js";

import "./index.css";
import gife from "../../assets/image/pro.gif";
import Psders from "../Psders";
const MINUTE_MS = 2000;
declare const window: Window & { ethereum: any };

const Index = () => {
  const [Jointn, setJointn] = useState(Jointnode);
  const [WalletAccount, setWalletAccount] = useState("");
  const [inputshe, setInputshe] = useState("");
  const [unShow, setunShow] = useState(false);
  const { t } = useTranslation();
  const [percent, setPercent] = useState(0);
  const [isTimese, setisTimese] = useState(false);
  const [isModalOpen4, setisModalOpen4] = useState(false);
  const [PId, setPId] = useState("");
  const [oreTime, setoreTime] = useState({
    gontime: "",
    oreTime: 1,
  });
  const [prnNum, setprnNum] = useState("");
  const [prnCode, setprnCode] = useState("");
  const [proShow, setproShow] = useState(false);
  const [USDTValue, setUSDTValue] = useState(0);

  // 展开面板
  const showOrhideDetailData = (pid: any) => {
    let arr: any = [];
    Jointn.map((item) => {
      if (item.pid === pid) {
        item.isDeatilopen = !item.isDeatilopen;
      }
      arr.push(item);
    });
    let _Listusn = JSON.parse(JSON.stringify(arr));
    setJointn(_Listusn);
  };
  const pioserShow = () => {
    const addr = localStorage.getItem("Meat_addr");
    if (addr !== null && addr !== undefined) {
      setWalletAccount(addr);
      PondgetData();
    } else {
      setWalletAccount("");
    }
  };
  const PondgetData = async () => {
    const Onderdata: any = Jointn;
    Jointn.map(async (item: any, index: any) => {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const pairContract = new ethers.Contract(item.code, PAIR_ABI, signer);
      const MetaContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const address = await signer.getAddress();
      const allowance = await pairContract.allowance(address, Meta_ADDRESS);
      const decimal = await pairContract.decimals();
      const pairBalance = await pairContract.balanceOf(address);
      const realBalance = pairBalance / 10 ** decimal;
      const token0 = await pairContract.token0();
      const token1 = await pairContract.token1();
      const token0Contract = new ethers.Contract(token0, wben_ABI, signer);
      const token1Contract = new ethers.Contract(token1, wben_ABI, signer);
      const depositAmount = await MetaContract.depositAmount(item.pid, address);
      const totalSupply = await pairContract.totalSupply();
      const token0Total = await token0Contract.balanceOf(item.code);
      const decimals0 = await token0Contract.decimals();
      const token1Total = await token1Contract.balanceOf(item.code);
      const decimals1 = await token1Contract.decimals();
      const pldate = ethers.utils.formatUnits(depositAmount.toString(), 18);
      let holdRatio =
        Number(depositAmount.toString()) / (Number(totalSupply) - 1000);
      let userToken0 = Number(token0Total) * holdRatio;
      let userToken0show = userToken0 / 10 ** decimals0;
      let userToken1 = Number(token1Total) * holdRatio;
      let userToken1show = userToken1 / 10 ** decimals1;
      const token0toolNumber = toolNumber(userToken0show);
      const token1toolNumber = toolNumber(userToken1show);
      Onderdata[index].allowa = allowance.toString();
      Onderdata[index].Maxnu = pairBalance.toString();
      Onderdata[index].balance = realBalance.toString();
      Onderdata[index].Luerbse = pairBalance.toString();
      Onderdata[index].lPdata = pldate.toString();
      Onderdata[index].meatdate = token0toolNumber.substring(0, 13);
      Onderdata[index].usdtdate = token1toolNumber.substring(0, 13);
    });
    setJointn(Onderdata);
  };
  const onCInput = (e: any, pid: any) => {
    const buList: any = [];
    Jointn.map((item: any) => {
      if (item.pid == pid) {
        item.inputValue = e.target.value;
        const realValuew = ethers.utils.parseEther(item.inputValue);
        setInputshe(realValuew.toString());
        const Shui = e.target.value || 0;
        if (Shui === 0) {
          setunShow(false);
        } else if (item.inputValue === 0) {
          setunShow(false);
        } else {
          setunShow(true);
        }
      }
      buList.push(item);
    });
    let _Listusn = JSON.parse(JSON.stringify(buList));
    setJointn(_Listusn);
  };
  const MaxClick = (pid: any) => {
    const buList: any = [];
    Jointn.map((item: any) => {
      if (item.pid == pid) {
        setInputshe(item.Luerbse);
        item.inputValue = item.balance;
      }
      buList.push(item);
    });
    let _Listusn = JSON.parse(JSON.stringify(buList));
    setJointn(_Listusn);
    setunShow(true);
  };
  const approveonClick = async (code: string) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const PAIRContract = new ethers.Contract(code, PAIR_ABI, signer);
      const approve = await PAIRContract.approve(
        Meta_ADDRESS,
        ethers.constants.MaxUint256
      );
      setoreTime({ gontime: `${t("Authorizing")}`, oreTime: 1 });
      setisTimese(true);
      await approve.wait();
      setoreTime({ gontime: `${t("Authorization succeeded")}`, oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setoreTime({ gontime: `${t("privilege grant failed")}`, oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const depositClick = async (pid: number) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const MetaContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const deposit = await MetaContract.deposit(pid, inputshe);
      setoreTime({ gontime: `${t("Pledging")}`, oreTime: 1 });
      setisTimese(true);
      await deposit.wait();
      setoreTime({ gontime: `${t("Pledge succeeded")}`, oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
      const buList: any = [];
      Jointn.map((item: any) => {
        if (item.pid == pid) {
          setInputshe("");
          item.inputValue = "";
        }
        buList.push(item);
      });
      let _Listusn = JSON.parse(JSON.stringify(buList));
      setJointn(_Listusn);
    } catch (error) {
      const BugLoader = JSON.parse(JSON.stringify(error)).error.data.message;
      setoreTime({ gontime: `${t(BugLoader)}`, oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const showHide2 = () => {
    setisTimese(false);
  };
  const setPercentage = async (pid: any, code: any, percentage: any) => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const pairContract = new ethers.Contract(code, PAIR_ABI, signer);
    const pairBalance = await pairContract.balanceOf(address);
    const t = pairBalance.mul(percentage).div(100);
    console.log(t.toString());
    const k = ethers.utils.formatUnits(t, 18);
    const buList: any = [];
    Jointn.map((item: any) => {
      if (item.pid == pid) {
        setInputshe(t);
        item.inputValue = k;
      }
      buList.push(item);
    });
    setPercent(percentage);
    let _Listusn = JSON.parse(JSON.stringify(buList));
    setJointn(_Listusn);
    setunShow(true);
  };
  const ModalOpenonClick = (pid: any) => {
    setisModalOpen4(true);
    setPId(pid);
  };
  const withdrawClick = async (PId: string) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const MetaContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const withdraw = await MetaContract.withdraw(PId);
      setoreTime({ gontime: `${t("Redemption in progress...")}`, oreTime: 1 });
      setisTimese(true);
      await withdraw.wait();
      setoreTime({ gontime: `${t("Redemption succeeded")}`, oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      const BugLoader = JSON.parse(JSON.stringify(error)).error.data.message;
      setoreTime({ gontime: `${t(BugLoader)}`, oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };

  const claimClick = async (PId: string) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const MetaContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const claim = await MetaContract.claim(PId);
      setisModalOpen4(false);
      setisModalOpen4(false);
      setoreTime({ gontime: `${t("Is Receiving...")}`, oreTime: 1 });
      setisTimese(true);
      await claim.wait();
      setoreTime({ gontime: `${t("Successfully received")}`, oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    } catch (error) {
      setisModalOpen4(false);
      const BugLoader = JSON.parse(JSON.stringify(error)).error.data.message;
      setoreTime({ gontime: `${t(BugLoader)}`, oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const prionshow = (pid: any, code: any) => {
    setprnNum(pid);
    setprnCode(code);
    setproShow(true);
  };
  const onHIde = () => {
    setproShow(false);
  };

  useEffect(() => {
    pioserShow();
    const addr = localStorage.getItem("Meat_addr");

    if (addr !== null && addr !== undefined) {
      const interval = setInterval(async () => {
        const Onderdata: any = Jointn;
        Jointn.map(async (item: any, index: any) => {
          const provider = new ethers.providers.Web3Provider(window.ethereum);
          const signer = provider.getSigner();
          const pairContract = new ethers.Contract(item.code, PAIR_ABI, signer);
          const MetaContract = new ethers.Contract(
            Meta_ADDRESS,
            Meta_ABI,
            signer
          );
          const address = await signer.getAddress();
          const allowance = await pairContract.allowance(address, Meta_ADDRESS);
          const decimal = await pairContract.decimals();
          const pairBalance = await pairContract.balanceOf(address);
          const realBalance = pairBalance / 10 ** decimal;
          const token0 = await pairContract.token0();
          const token1 = await pairContract.token1();
          const token0Contract = new ethers.Contract(token0, wben_ABI, signer);
          const token1Contract = new ethers.Contract(token1, wben_ABI, signer);
          const depositAmount = await MetaContract.depositAmount(
            item.pid,
            address
          );
          const totalSupply = await pairContract.totalSupply();
          const token0Total = await token0Contract.balanceOf(item.code);
          const decimals0 = await token0Contract.decimals();
          const token1Total = await token1Contract.balanceOf(item.code);
          const decimals1 = await token1Contract.decimals();
          const pldate = ethers.utils.formatUnits(depositAmount.toString(), 18);
          let holdRatio =
            Number(depositAmount.toString()) / (Number(totalSupply) - 1000);
          let userToken0 = Number(token0Total) * holdRatio;
          let userToken0show = userToken0 / 10 ** decimals0;
          let userToken1 = Number(token1Total) * holdRatio;
          let userToken1show = userToken1 / 10 ** decimals1;
          const token0toolNumber = toolNumber(userToken0show);
          const token1toolNumber = toolNumber(userToken1show);
          Onderdata[index].allowa = allowance.toString();
          Onderdata[index].Maxnu = pairBalance.toString();
          Onderdata[index].balance = realBalance.toString();
          Onderdata[index].Luerbse = pairBalance.toString();
          Onderdata[index].lPdata = pldate.toString();
          Onderdata[index].meatdate = token0toolNumber.substring(0, 13);
          Onderdata[index].usdtdate = token1toolNumber.substring(0, 13);
        });
        setTimeout(() => {
          let _Listusn = JSON.parse(JSON.stringify(Onderdata));
          setJointn(_Listusn);
        }, 500);
      }, MINUTE_MS);
      return () => clearInterval(interval);
    } else {
      setWalletAccount("");
    }
  }, [WalletAccount, Jointn, prnNum, prnCode]);
  return (
    <>
      {(Jointn[0] as any).lPdata === "" ? (
        <div className="loding">
          <div className="seuniser">
            <div className="proouise">
              <RedoOutlined spin style={{ fontSize: "28px", color: "#fff" }} />
            </div>
            {`${t("Loading...")}`}
          </div>
        </div>
      ) : (
        <>
          {Jointn.map((item: any, index: any) => {
            return (
              <div className="DataAreaItem" key={index}>
                <div className="DataItemTopArea">
                  <div className="DataItemColumnOne">
                    <div className="itemimg">
                      <img src={item.icons} alt="" />
                      <div className="utopm">
                        <img src={item.icon} alt="" />
                      </div>
                    </div>
                    <div className="DataItemColumnOneRight">
                      <div className="dreamDaoText">{item.name}</div>
                    </div>
                  </div>
                  <div className="DataItemColumnTwo">
                    <div className="APRTitle">{`${t("Balance")}`}:</div>
                    <div className="APRRightArea">
                      <span className="APRNumberOne">{item.balance || 0}</span>
                    </div>
                  </div>
                  <div className="DataItemColumnTwo2">
                    <div className="APRTitle">{`${t("LP（USDT）Cost")}`}:</div>
                    <div className="APRRightArea">
                      <span className="APRNumberOne">{USDTValue}</span>
                    </div>
                  </div>
                  <div className="DataItemColumnTwo2">
                    <div className="APRTitle">{`${t("LP value")}`}:</div>
                    <div className="APRRightArea">
                      <span className="APRNumberOne">{item.lPdata || 0}</span>
                    </div>
                  </div>
                  <div className="DataItemColumnTwo2">
                    <div className="APRTitle">{`${t("Pooled Meta")}`}:</div>
                    <div className="APRRightArea">
                      <span className="APRNumberOne">{item.meatdate || 0}</span>
                    </div>
                  </div>
                  <div className="DataItemColumnTwo2">
                    <div className="APRTitle">{`${t("Pooled USDT")}`}:</div>
                    <div className="APRRightArea">
                      <span className="APRNumberOne">{item.usdtdate || 0}</span>
                    </div>
                  </div>
                  <div className="DataItemColumnTwo5">
                    <div className="jduti">
                      <Progress
                        percent={percent}
                        strokeColor={{ "0%": "#410cf0", "100%": "#bd3afb" }}
                        format={(percent) => (
                          <div className="pruiole">{`${percent} %`}</div>
                        )}
                      />
                    </div>
                    <div className="pdruinsbutton">
                      <button
                        onClick={() => {
                          setPercentage(item.pid, item.code, 25);
                        }}
                      >
                        25%
                      </button>
                      <button
                        onClick={() => {
                          setPercentage(item.pid, item.code, 50);
                        }}
                      >
                        50%
                      </button>
                      <button
                        onClick={() => {
                          setPercentage(item.pid, item.code, 75);
                        }}
                      >
                        75%
                      </button>
                      <button
                        onClick={() => {
                          setPercentage(item.pid, item.code, 100);
                        }}
                      >
                        100%
                      </button>
                    </div>
                  </div>
                  <div className="ebueirt">
                    <input
                      type="text"
                      value={item.inputValue}
                      placeholder={`${t("Please enter the quantity")}`}
                      onChange={(e) => {
                        onCInput(e, item.pid);
                      }}
                    />
                    <button
                      onClick={() => {
                        MaxClick(item.pid);
                      }}
                    >
                      MAX
                    </button>
                  </div>
                  <>
                    {item.allowa === "0" || item.allowa === "" ? (
                      <button
                        className="DataConnectbtn"
                        onClick={() => {
                          approveonClick(item.code);
                        }}
                      >{`${t("Approve")}`}</button>
                    ) : (
                      <>
                        {item.inputValue !== "" && unShow ? (
                          <div className="pieosn">
                            <button
                              className="DataConnectbtn"
                              onClick={() => {
                                prionshow(item.pid, item.code);
                              }}
                            >
                              详情
                            </button>
                            <button
                              className="DataConnectbtn"
                              onClick={() => {
                                depositClick(item.pid);
                              }}
                            >
                              {`${t("Pledge")}`}
                            </button>
                            {item.pendingMining === "0.0" ? (
                              <button
                                className="DataConneposer"
                                disabled={true}
                              >
                                {`${t("receive")}`}
                              </button>
                            ) : (
                              <button
                                className="DataConnectbtn"
                                onClick={() => {
                                  ModalOpenonClick(item.pid);
                                }}
                              >
                                {`${t("receive")}`}
                              </button>
                            )}
                            {item.redeemableLPAmount === "0.0" ? (
                              <button
                                className="DataConneposer"
                                disabled={true}
                              >
                                {`${t("Redemption")}`}
                              </button>
                            ) : (
                              <button
                                className="DataConnectbtn"
                                onClick={() => {
                                  withdrawClick(item.pid);
                                }}
                              >
                                {`${t("Redemption")}`}
                              </button>
                            )}
                          </div>
                        ) : (
                          <div className="pieosn">
                            <button
                              className="DataConnectbtn"
                              onClick={() => {
                                prionshow(item.pid, item.code);
                              }}
                            >
                              {`${t("details")}`}
                            </button>
                            <button className="DataConneposer" disabled={true}>
                              {`${t("Pledge")}`}
                            </button>
                            {item.pendingMining === "0.0" ? (
                              <button
                                className="DataConneposer"
                                disabled={true}
                              >
                                {`${t("receive")}`}
                              </button>
                            ) : (
                              <button
                                className="DataConnectbtn"
                                onClick={() => {
                                  ModalOpenonClick(item.pid);
                                }}
                              >
                                {`${t("receive")}`}
                              </button>
                            )}
                            {item.redeemableLPAmount === "0.0" ? (
                              <button
                                className="DataConneposer"
                                disabled={true}
                              >
                                {`${t("Redemption")}`}
                              </button>
                            ) : (
                              <button
                                className="DataConnectbtn"
                                onClick={() => {
                                  withdrawClick(item.pid);
                                }}
                              >
                                {`${t("Redemption")}`}
                              </button>
                            )}
                          </div>
                        )}
                      </>
                    )}
                  </>
                </div>
                <div
                  className="DataItemBottomArea"
                  style={{
                    height: item.isDeatilopen ? "170px" : "65px",
                  }}
                >
                  {!item.isDeatilopen && (
                    <div
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        showOrhideDetailData(item.pid);
                      }}
                    >
                      <span>{`${t("Details")}`}</span>
                      <img src={uparrow} alt="" />
                    </div>
                  )}
                  {item.isDeatilopen && (
                    <div className="HideContent">
                      <div
                        className="HideTitle"
                        onClick={() => {
                          showOrhideDetailData(item.pid);
                        }}
                      >
                        {`${t("Hide")}`}
                        <img src={downarrow} alt="" />
                      </div>
                      {/* Get CAKE-BNB LP */}
                      <div className="HideGetLPArea">
                        <a
                          target="_blank"
                          href={
                            "https://pancakeswap.finance/add/" +
                            item.token1 +
                            "/" +
                            item.token2
                          }
                        >
                          {`${t("Get CAKE-BNB LP")}`}
                          <img src={more} alt="" />
                        </a>
                      </div>
                      {/* View Contract */}
                      <div className="HideViewArea">
                        <a
                          target="_blank"
                          href={"https://bscscan.com/address/" + item.code}
                        >
                          {" "}
                          {`${t("View Contract")}`}
                          <img src={more} alt="" />
                        </a>
                      </div>

                      {/* See Pair Info */}
                      <div className="HideSeeArea">
                        <a
                          target="_blank"
                          href={
                            "https://pancakeswap.finance/info/pools/" +
                            item.code
                          }
                        >
                          {`${t("See Pair Info")}`}
                          <img src={more} alt="" />
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </>
      )}
      {/* 提示 */}
      {isTimese ? (
        <div className="pserExbuse">
          <div className="pserzhes"></div>
          <div className="pserTise">
            <div className="pserExchange_nro">
              <div className="nriopsr">
                <div className="logding">
                  {(oreTime as any).oreTime === 1 ? (
                    <div className="xgirm">
                      <img src={gife} alt="" />
                    </div>
                  ) : (oreTime as any).oreTime === 2 ? (
                    <CheckCircleOutlined className="Luiisnr" />
                  ) : (
                    <CloseCircleOutlined className="Luiisnr" />
                  )}
                </div>
                <div className="Ptimeb">{(oreTime as any).gontime}</div>
              </div>
              <div
                className="gbuiengkum"
                onClick={() => {
                  showHide2();
                }}
              >
                <CloseCircleOutlined
                  style={{
                    color: "#ffff",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      <Modal
        title=" "
        centered
        bodyStyle={{
          height: "230px",
          padding: 20,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        open={isModalOpen4}
        footer={null}
        width={400}
      >
        <div className="Dnueir">
          <div className="xgirm3">
            <QuestionCircleOutlined
              style={{ color: "#ffff", fontSize: "40px" }}
            />
          </div>
          {/* <div className="Dnueir_titiel">系统提示</div> */}
          <div className="Dnueir_nr">
            {`${t(
              "Whether to receive all mining rewards and dividend rewards under the current pledge form?"
            )}`}
          </div>
          <div className="Dnueir_buto">
            <button
              onClick={() => {
                setisModalOpen4(false);
              }}
            >
              No
            </button>
            <button
              onClick={() => {
                claimClick(PId);
              }}
            >
              Yes
            </button>
          </div>
        </div>
      </Modal>

      {proShow ? <Psders pid={prnNum} code={prnCode} onHIde={onHIde} /> : ""}
    </>
  );
};

export default Index;
