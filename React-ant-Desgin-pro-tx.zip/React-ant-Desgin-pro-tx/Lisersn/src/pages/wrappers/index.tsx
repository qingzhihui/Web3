import React from 'react';
import { useHistory, useModel } from 'umi';

function index() {
  const history = useHistory();
  return (
    <div>
      <button
        onClick={() => {
          history.push('/user');
        }}
      >
        ches
      </button>
    </div>
  );
}

export default index;
