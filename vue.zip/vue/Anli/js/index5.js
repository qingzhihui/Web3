// 一道高水准的面试题

//可迭代协议

// 知名符号
// {
//     [Symbol.iterator]：function(){
//      retun 迭代器
// }

// var [a, b] = {a: 1, b: 2}; 的解决方案
Object.prototype[Symbol.iterator] = function () {
    return Object.values(this)[Symbol.iterator]();
}
var [a, b] = {a: 1, b: 2};

console.log(a)

var arr = [1, 2, 3]  //可迭代
console.log(arr[Symbol.iterator])
//调用这个可迭代函数会返回iter
console.log(arr[Symbol.iterator]())

console.log(arr[Symbol.iterator]().next());
console.log(arr[Symbol.iterator]().next());
console.log(arr[Symbol.iterator]().next());