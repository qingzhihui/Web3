import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import { Button, Dropdown, Menu, Space } from "antd";
import { DownOutlined, SmileOutlined } from "@ant-design/icons";
import type { MenuProps } from "antd";
import "./index.scss";
const ches = {
  key: "1",
  name: "V1 币安链",
};

const Network = (props: any) => {
  const [network, setNetwork] = useState(ches);

  const Buseir: any = [
    {
      key: "1",
      label: <div className="wereiku">V1 币安链</div>,
    },
    {
      key: "2",
      label: <div className="wereiku">V2 以太坊</div>,
    },
  ];
  const handleClick = (value: any) => {
    props.click(value);
  };
  const onClick: MenuProps["onClick"] = ({ key }) => {
    Buseir.map((item: any) => {
      if (item.key == key) {
        setNetwork({
          key: key,
          name: item.label.props.children,
        });
        localStorage.setItem("Network", key);
        handleClick(key);
      }
    });
  };

  const menu = <Menu onClick={onClick} items={Buseir} />;
  useEffect(() => {
    const buiser = localStorage.getItem("Network");
    if (props.ches !== "") {
      if (props.ches == "1") {
        setNetwork({
          key: "1",
          name: "V1 币安链",
        });
      } else {
        setNetwork({
          key: "2",
          name: "V2 以太坊",
        });
      }
    }
    if (buiser !== null && buiser !== undefined) {
      if (buiser !== "1") {
        setNetwork({
          key: "2",
          name: "V2 以太坊",
        });
      } else {
        setNetwork({
          key: "1",
          name: "V1 币安链",
        });
      }
    }
  }, [props]);
  return (
    <div className="poseNetwork">
      <div className="Bsyeuine">
        <Dropdown overlay={menu}>
          <Button onClick={(e) => e.preventDefault()}>
            <Space>
              <div className="slueipoi">
                <div className="slueipoimge">
                  <img
                    src={require(`../../assets/${
                      (network as any).key == "1" ? "0x56.png" : "0x1.png"
                    }`)}
                    alt=""
                  />
                </div>
                {(network as any).key == "1" ? (
                  <div className="werei">{(network as any).name}</div>
                ) : (
                  <div className="werei2">{(network as any).name}</div>
                )}
              </div>
              <DownOutlined />
            </Space>
          </Button>
        </Dropdown>
      </div>
    </div>
  );
};

export default Network;
