import "./index.scss"
import {Swiper, SwiperSlide} from "swiper/react";
import "swiper/css"
import { Navigation} from "swiper";
import 'swiper/css/effect-fade'
import "swiper/css"
import {useEffect, useRef, useState} from "react";

export default function DailyMining() {
  const preRef = useRef(null)
  const nextRef = useRef(null)
  const [pre, setPre] = useState(null)
  const [next, setNext] = useState(null)
  useEffect(() => {
    setTimeout(() => {
      if (preRef.current) {
        setPre(preRef.current)
        setNext(nextRef.current)
      }
    }, 500)
  }, [])
  return (
    <>
      <div style={{
        marginTop: "25px",
        display: "flex",
        justifyContent: "center"
      }}>
        <button className="common-btn">COMMING SOON</button>
      </div>
      <div id="DailyMining">
        <div className="d-hd" style={{display: "none"}}>
          <img className="pre" ref={preRef} src="/img/pre.png" alt=""/>
          <img className="next" ref={nextRef} src="/img/next.png" alt=""/>
          <Swiper
            modules={[Navigation]}
            slidesPerView={1}
            slidesPerGroup={1}
            spaceBetween={15}
            navigation={{
              prevEl: pre,
              nextEl: next
            }}
            breakpoints={{
              1450: {
                slidesPerView: 3
              },
              900: {
                slidesPerView: 2
              }
            }}
          >
            <SwiperSlide className="d-item">
              <div className="title">
                <h1>Milk Station</h1>
                <div className="right">
                  <img src="/img/milk_light.webp" alt=""/>
                  <img src="/img/milk_light.webp" alt=""/>
                </div>
              </div>
              <img src="/img/MilkStation.png"/>
              <div className="flex-box">
                <div className="fill-box">
                  <div className="div1">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                  <div className="div2">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                </div>
                <div className="fill-box">
                  <div className="div1">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                  <div className="div2">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                </div>
              </div>
              <button>No Player Available</button>
            </SwiperSlide>
            <SwiperSlide className="d-item">
              <div className="title">
                <h1>Milk Station</h1>
                <div className="right">
                  <img src="/img/milk_light.webp" alt=""/>
                  <img src="/img/milk_light.webp" alt=""/>
                </div>
              </div>
              <img src="/img/MilkStation.png"/>
              <div className="flex-box">
                <div className="fill-box">
                  <div className="div1">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                  <div className="div2">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                </div>
                <div className="fill-box">
                  <div className="div1">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                  <div className="div2">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                </div>
              </div>
              <button>No Player Available</button>
            </SwiperSlide>
            <SwiperSlide className="d-item">
              <div className="title">
                <h1>Milk Station</h1>
                <div className="right">
                  <img src="/img/milk_light.webp" alt=""/>
                  <img src="/img/milk_light.webp" alt=""/>
                </div>
              </div>
              <img src="/img/MilkStation.png"/>
              <div className="flex-box">
                <div className="fill-box">
                  <div className="div1">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                  <div className="div2">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                </div>
                <div className="fill-box">
                  <div className="div1">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                  <div className="div2">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                </div>
              </div>
              <button>No Player Available</button>
            </SwiperSlide>
            <SwiperSlide className="d-item">
              <div className="title">
                <h1>Milk Station</h1>
                <div className="right">
                  <img src="/img/milk_light.webp" alt=""/>
                  <img src="/img/milk_light.webp" alt=""/>
                </div>
              </div>
              <img src="/img/MilkStation.png"/>
              <div className="flex-box">
                <div className="fill-box">
                  <div className="div1">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                  <div className="div2">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                </div>
                <div className="fill-box">
                  <div className="div1">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                  <div className="div2">
                    <h2>Recommended Characters</h2>
                    <h1>Any Player</h1>
                  </div>
                </div>
              </div>
              <button>No Player Available</button>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </>
  )
}