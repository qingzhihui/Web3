import React, { Component, Suspense } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Farm from "../view/Farm";
import Loading from "../components/Loading";

class IndexRouter extends Component {
  render() {
    return (
      <Suspense fallback={<Loading />}>
        <Router>
          <Switch>
            <Route path="/Deposit" component={Farm} />
            <Redirect from="/" to="/Deposit" />
          </Switch>
        </Router>
      </Suspense>
    );
  }
}

export default IndexRouter;
