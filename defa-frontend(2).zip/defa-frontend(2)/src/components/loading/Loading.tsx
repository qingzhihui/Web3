import React, { useEffect, useCallback, useState, useMemo, useRef } from 'react'
import { useTranslation } from 'contexts/Localization'

const Loading = (props: any) => {
  const { t } = useTranslation()
  return (
    <div className="logding">
      <div className="lsubevlog"></div>
      <div className="losdingtile">{t(props.name)}</div>
    </div>
  )
}
export default Loading
