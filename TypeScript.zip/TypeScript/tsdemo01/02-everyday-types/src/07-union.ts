function printId(id: number | string) {
  //   console.log("Your ID is" + id);

  // 错误
  // console.log(id.toUpperCase());
  // 正确
  if (typeof id == "string") {
    console.log(id.toUpperCase());
  } else {
    console.log(id);
  }
}
printId(101);
printId("202");

// 错误
// printId({
//     myId:12345
// })

function welcomePeople(x: string[] | string) {
  if (Array.isArray(x)) {
    console.log("Hello," + x.join(" and "));
  } else {
    console.log("welcome lone traveler" + x);
  }
}

welcomePeople("A");
welcomePeople(["a", "b"]);

function getForstThree(x: number[] | string): number[] | string {
  return x.slice(0, 3);
}
console.log(getForstThree("abcdefg"));
console.log(getForstThree([2, 3, 4, 5, 6]));
