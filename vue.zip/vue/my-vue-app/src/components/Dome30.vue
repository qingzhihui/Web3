<template>

  <div>
    <button>排序</button>
  </div>
  <div>
    <div class="itle">hTMel+CSS</div>
    <div class="itle">javaScript</div>
    <div class="itle">网络</div>
    <div class="itle">工程化</div>
    <div class="itle">框架</div>
    <div class="itle">科技</div>
    <div class="itle">数据库</div>
  </div>
</template>

<script setup>


//Flip 动画解决方案

// F:First,记录起始位置
// L:Last，记录结束位置
// I:Invert,反转元素到起始位置
// P:Play，播放动画回到结束位置

</script>

<style>
.itle{
  background-color: #333333;
  width: 130px;
  margin-top: 10px;
  margin-bottom: 10px;
  color: #ffffff;
}
</style>
