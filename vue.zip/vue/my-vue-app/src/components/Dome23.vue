<template>
</template>

<script setup>
// 手写 bind
//这样写 所有的函数都有这个方法
Function.prototype.myBind = function (ctx) {
  var fn = this;
  return function () {
    return fn.apply(ctx, arguments)
  }
}


function fn(a, b) {
  console.log(this, a, b)
}

var newFn = fn.myBind({})
newFn(2, 3)

</script>

<style>
</style>
