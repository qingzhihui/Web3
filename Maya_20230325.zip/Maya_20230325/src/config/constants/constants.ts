import standardToken from "../abi/standardToken.json";
import LiquidityGeneratorToken from "../abi/LiquidityGeneratorToken.json";
import BabyToken from "../abi/BabyToken.json";
import BuybackBabyToken from "../abi/BuybackBabyToken.json";

import AntiBotstandardFactoryABI from "../abi/AntiBotstandardTokenABI.json";
import AntiBotLGFactoryABI from "../abi/AntiBotLiquidityGeneratorTokenFactory.json";
import AntiBotBabyTokenFactoryABI from "../abi/AntiBotBabyTokenFactory.json";
import AntiBotBuybackBabyFactoryABI from "../abi/AntiBotBuybackBabyTokenFactory.json";

const AntiBotstandardTokenFactory =
  "0x8E7264957d7Bd68a5BFb25949112AC20cdD2cFEe";
const AntiBotLGFactory = "0xf43941cA11b8D43ddA93371f4D8eE9F870838a98";
const AntiBotBabyTokenFactory = "0x589c7D3bCBc5677C647f1b74F75Cd50BA9aa9564";
const AntiBotBuybackBabyFactory = "0x723587b1A74B7867BadA3c32307C714091F0207e";

const AntiBotContract = "0x207E9e4f3F8bBc79b20B2FEF586267cEB0a676D2";

const Constan = [
  {
    Address: "0x2b5f92bdc92dc7fa989c228ff3311424d4002710",
    Condebi: standardToken,
  },
  {
    Address: "0x4194cf08aff43d1e05c6aef0f5832683beb73647",
    Condebi: LiquidityGeneratorToken,
  },
  {
    Address: "0xe9acdb08bfb21cd7081f13e997998a519065103d",
    Condebi: BabyToken,
  },
  {
    Address: "0x8a35a1dfc1c60ee7b0ce5aee7c4140013d42cd1e",
    Condebi: BuybackBabyToken,
  },
];

export {
  Constan,
  AntiBotstandardTokenFactory,
  AntiBotstandardFactoryABI,
  AntiBotContract,
  AntiBotLGFactoryABI,
  AntiBotBabyTokenFactoryABI,
  AntiBotBuybackBabyFactoryABI,
  AntiBotLGFactory,
  AntiBotBabyTokenFactory,
  AntiBotBuybackBabyFactory,
};
