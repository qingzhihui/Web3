import styled from "styled-components";
const ParentComponent = styled.div`
  width: 100%;
  height: 100%;
  position: absolute;
`;
const HeaderComponent = styled.div`
  width: 100%;
  position: fixed;
  width: 100%;
  top: 0px;
  left: 0px;
  z-index: 99999;
  @media only screen and (min-width: 300px) and (max-width: 640px) {
    /* position: static;
    width: 100%; */
  }
`;
const ContentItem = styled.div`
  height: 100%;
  width: 100%;
`;
const FooterComponent = styled.div`
  width: 100%;
  height: 300px;
  background: #010d26;
  display: flex;
  align-items: center;
  justify-content: center;
  @media only screen and (min-width: 300px) and (max-width: 640px) {
    height: auto !important;
  }
`;

export { ParentComponent, HeaderComponent, ContentItem, FooterComponent };
