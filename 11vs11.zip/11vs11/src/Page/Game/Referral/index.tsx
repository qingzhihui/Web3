import axios from "axios";
import { useEffect, useState } from "react";
import { CopyToClipboard } from "react-copy-to-clipboard";

//import { getGeneratorLink } from "../../../constant";
import { useGetWeb3 } from "../../../hooks/useGetWeb3";
import "./index.scss";

export default function Referral() {
  const [referralLink, setReferralLink] = useState("");
  const { account } = useGetWeb3();

  const [routName, setrouterName] = useState("");

  const [uoutName, setuoutName] = useState("");
  const [propdata, setpropdata] = useState([]);

  // useEffect(() => {

  //   const scodeAnt = sessionStorage.getItem("keyRral") || "";
  //   setrouterName(scodeAnt);

  //   const ucodeAnt = sessionStorage.getItem("keyUcode") || "";
  //   setuoutName(ucodeAnt);
  //   let flag = false;
  // //   if (account) {
  // //     const generateLink = async () => {
  // //       const { data } = await axios.get(getGeneratorLink(account));
  // //       setReferralLink(
  // //         `${window.location.origin}/#/game/get-your-player?referralLink=${data.creator}`
  // //       );
  // //       await axios({
  // //         method: "get",
  // //         url: "http://23.226.65.83:8080/getLiAsmsUcode",
  // //         params: {
  // //           ucode: data.creator,
  // //         },
  // //       }).then(function (response) {
  // //         setpropdata(response.data);
  // //         console.log(propdata);
  // //       });
  // //     };
  // //     generateLink();
  // //   }
  // //   return () => {
  // //     flag = true;
  // //   };
  // // }, [account]);

  return (
    <div id="Referral">
      <div className="common-box top-box">
        <div className="title">
          <h1>Referral program</h1>
        </div>
        <div className="content">
          Each wallet address can generate an exclusive invitation link. After
          the user successfully purchases the blind box through the promotion
          link, the user with the invitation code will get a 5% rebate, and the
          top 3 users who invite users to buy the blind box will share the
          reward of 100,000 US dollars, and the promotion reward will be issued
          after the blind box is sold out.
          <br />
          1st place 50000 BUSD
          <br />
          2nd place 30000 BUSD
          <br />
          3rd place 20000 BUSD
        </div>
      </div>
      <div className="center-box">
        <div className="common-box left">
          <div className="title">
            <h1>My Referrer</h1>
          </div>
          <div className="content">
            <div className="input-box">
              <input type="text" value={routName} readOnly={true} />
              <div className="btn">Band</div>
            </div>
            <p>
              * Please mint right after you bond to ensure referral is
              succecssul.
            </p>
          </div>
        </div>
        <div className="common-box right">
          <div className="title">
            <h1>My Referral Link</h1>
            <div className="right">
              <div className="item"></div>
            </div>
          </div>
          <div className="content">
            <div className="input-box">
              <input type="text" readOnly value={referralLink} />
              <CopyToClipboard text={referralLink}>
                <div className="btn">
                  <img src="/img/copy.png" alt="" />
                </div>
              </CopyToClipboard>
            </div>
          </div>
        </div>
      </div>
      <div className="tips">
        * The on-chain data might be congested, so you may encounter delays in
        displaying the right data.
      </div>
      <div className="last-box common-box">
        <div className="titles">
          <h1>Referral program</h1>
          <h1 className="lines">Total: {propdata.length}</h1>
        </div>
        <div className="content">
          <div className="th">
            <div style={{ color: "rgb(104, 110, 124)" }}>User</div>
          </div>
          {propdata.map((item) => (
            <div className="th" key={item["lid"]}>
              <div>{item["scode"]}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
