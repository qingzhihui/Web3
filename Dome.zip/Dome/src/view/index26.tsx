import React from 'react'

function Index() {
  return (
    <div>Index</div>
  )
}

export default Index