import React, { useEffect, useState } from "react";
import "./index.scss";
import { ethers } from "ethers";
import { Button, Modal, notification, Input } from "antd";
import Header from "../../components/Header";
import img1 from "../../assets/1s.png";
import img2 from "../../assets/2s.png";
import img3 from "../../assets/3s.png";
import b1 from "../../assets/b1.png";
import b2 from "../../assets/b2.png";
import b3 from "../../assets/b3.png";
import ito from "../../assets/lto.png";
import xuais from "../../assets/xusng.png";
import Heues from "../../components/Heues";
import { CheckCircleOutlined, LoadingOutlined } from "@ant-design/icons";
import { Mint_ADDRESS, Mint_ABI } from "../../redux/Contract/mintContract";
import { VOTE_ADDRESS, VOTE_ABI } from "../../redux/Contract/voteContract";
declare const window: Window & { ethereum: any };
const key = "updatable";

const openNotification = (bindValue: any, durn: any, icon: any) => {
  notification.open({
    key,
    message: "提示",
    description: bindValue,
    duration: durn,
    icon: icon,
  });
};

function Index() {
  const [voteList, setVoteList] = useState([]);
  const [cham, setCham] = useState([]);
  const [vedata, setVedata] = useState("");
  const [wore1, setwore1]: any = useState([]);
  const [wore2, setwore2]: any = useState([]);
  const [wore3, setwore3]: any = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isModalVisible2, setIsModalVisible2] = useState(false);
  const [byseu, setByseu] = useState([]);
  const [promser, setPromser] = useState("");

  const handleOk = async (address: any) => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const voteContract = new ethers.Contract(VOTE_ADDRESS, VOTE_ABI, signer);
      const ntract = await voteContract.vote(address);
      openNotification(
        "投票中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setIsModalVisible(false);
      await ntract.wait();
      openNotification(
        "投票成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error: any) {
      if (JSON.parse(JSON.stringify(error)).error.code == -32603) {
        openNotification(
          "你没有多余的票数来投票.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
      }
    }
  };
  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const onPlone = () => {
    setIsModalVisible(true);
  };

  const handleOk2 = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const voteContract = new ethers.Contract(VOTE_ADDRESS, VOTE_ABI, signer);
      const wfee = await voteContract.transferFee();
      const votubnr = await voteContract.withdrawVote({
        value: wfee.toString(),
      });
      openNotification(
        "撤票中...",
        0,
        <LoadingOutlined style={{ color: "#ffc400" }} />
      );
      setIsModalVisible2(false);
      await votubnr.wait();
      openNotification(
        "撤票成功.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
      TingList();
    } catch (error) {
      if (JSON.parse(JSON.stringify(error)).error.code == -32603) {
        openNotification(
          "你还没有投票,无法撤票.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
      }
    }
  };
  const handleCancel2 = () => {
    setIsModalVisible2(false);
  };
  const onChesn = async () => {
    setIsModalVisible2(true);
  };

  const findMin = (ca: any) => {
    var t = ca[0];
    var v: any = "";
    for (var i = 0; i < ca.length; i++) {
      if (ca[i] < t) {
        t = ca[i];
      }
    }
    for (var j = 0; j < ca.length; j++) {
      if (t == ca[j]) {
        v = j;
      }
    }
    return [t, v];
  };
  const TingList = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    const mintContract = new ethers.Contract(Mint_ADDRESS, Mint_ABI, signer);
    const cleader = await mintContract.getCommunityLeaderArray();
    const voteContract = new ethers.Contract(VOTE_ADDRESS, VOTE_ABI, signer);
    const vetipin = await voteContract.getTotalClaimedVotes(addr);
    const sbuein = await voteContract.getTotalVotedVotes(addr);
    const wyhrej = vetipin - sbuein;

    const poeti = parseFloat(ethers.utils.formatEther(wyhrej.toString()));
    setVedata(poeti.toString());

    const voten: any = [];
    cleader.map(async (item: any, index: any) => {
      const voteLis = await voteContract.getCLeaderVotes(item);
      const nfturi = await mintContract.getCommunityLeaderImage(item);
      const votedv = await voteContract.userData(addr);
      const suwie = parseFloat(ethers.utils.formatEther(voteLis.toString()));
      const url =
        "https://ipfs.youwant.io/ipfs/" + nfturi.toString().substr(7, 70);
      voten.push({
        id: index,
        arrdes: item,
        vote: suwie.toFixed(3),
        img: url,
        suol: votedv.totalVotedVotes.toString(),
      });
    });
    setTimeout(() => {
      const beuin = voten.sort((a: any, b: any) => {
        return b.vote - a.vote;
      });
      var tempArr: any = [voten[0], voten[1], voten[2]];
      for (var i = 0; i < voten.length; i++) {
        var min = findMin(tempArr);
        if (voten[i] > min[0]) {
          tempArr[min[1]] = voten[i];
        }
      }
      const data = voten.filter((item: any, index: any) => {
        return item !== tempArr[index];
      });
      if (voten.length !== 0) {
        setCham(tempArr);
        if (tempArr[0] !== undefined) {
          setwore1([tempArr[0]]);
        }
        if (tempArr[1] !== undefined) {
          setwore2([tempArr[1]]);
        }
        if (tempArr[2] !== undefined) {
          setwore3([tempArr[2]]);
        }
        const datacs = data.slice(0, 5);
        setByseu(data);
        // console.log(data);
        
        setVoteList(datacs);
      }
    }, 1000);
  };

  const promChange = (e: any) => {
    setPromser(e.target.value);
    if (e.target.value == "") {
      TingList();
    }
  };
  const prlisClick = () => {
    if (promser !== "") {
      const leng = promser.length;
      if (leng !== 42) {
        openNotification(
          "请输入正确社区长钱包地址.",
          2,
          <CheckCircleOutlined style={{ color: "#ffc400" }} />
        );
      } else {
        const Busiel = voteList.filter((item: any) => {
          return item.arrdes == promser;
        });
        setVoteList(Busiel);
      }
    } else {
      openNotification(
        "请输入社区长钱包.",
        2,
        <CheckCircleOutlined style={{ color: "#ffc400" }} />
      );
    }
  };
  const ByuList = () => {
    setVoteList(byseu);
  };

  useEffect(() => {
    const ahsdr = localStorage.getItem("addr");
    if (ahsdr !== null && ahsdr !== undefined) {
      TingList();
    }
    // voteList, wore1, wore2, wore3
  }, []);

  return (
    <div className="Rank">
      <Header />
      <div className="Rankdbi">
        <div className="ranbui">
          <div className="ranbList">
            <div className="clistiem">
              <div className="busimg">
                {wore2.length !== 0 ? (
                  <>
                    {wore2.map((item: any) => (
                      <div key={item.id} className="Busienr">
                        <div className="buisfsie">
                          <img src={item.img || ""} alt="" />
                        </div>
                        <div className="bsueran">
                          <div className="bsudmgi">
                            <img src={b2} alt="" />
                            <div className="Nuderixs2">2</div>
                          </div>
                          <div className="nsue1">待命名</div>
                          <div className="nsudetim">
                            <img src={ito} alt="" />
                            <div className="zhiyti">
                              {item.arrdes.substring(0, 4) +
                                "..." +
                                item.arrdes.substring(38, 42)}
                            </div>
                          </div>
                          <div className="nsuetitei">票数：{item.vote}</div>
                          <div className="nsuebeon">
                            <Button onClick={() => onPlone()}>
                              {item.suol !== "0" ? "加票" : "投票"}
                            </Button>
                            <Button onClick={() => onChesn()}>撤票</Button>
                          </div>
                        </div>
                        <Modal
                          title="提示"
                          width={400}
                          visible={isModalVisible}
                          okText="确认"
                          cancelText="取消"
                          centered
                          onOk={() => {
                            handleOk(item.arrdes);
                          }}
                          onCancel={handleCancel}
                        >
                          <p>注意：请确认是否将您所有的选票投给该社区长？</p>
                        </Modal>
                        <Modal
                          title="提示"
                          width={400}
                          visible={isModalVisible2}
                          okText="确认"
                          cancelText="取消"
                          centered
                          onOk={() => {
                            handleOk2();
                          }}
                          onCancel={handleCancel2}
                        >
                          <p>
                            注意：请确认是否撤销对该社区长的投票,此操作会收取
                            0.001 BNB的数据处理费用.
                          </p>
                        </Modal>
                      </div>
                    ))}
                  </>
                ) : (
                  <div className="bsueri">虚位以待</div>
                )}
              </div>
            </div>
            <div className="clistiem">
              <div className="busimg2">
                {wore1.length !== 0 ? (
                  <>
                    {wore1.map((item: any) => (
                      <div key={item.id} className="Busienr">
                        <div className="buisfsie">
                          <img src={item.img || ""} alt="" />
                        </div>
                        <div className="bsueran">
                          <div className="bsudmgi">
                            <img src={b1} alt="" />
                            <div className="Nuderixs">1</div>
                          </div>
                          <div className="nsue2">待命名</div>
                          <div className="nsudetim">
                            <img src={ito} alt="" />
                            <div className="zhiyti">
                              {" "}
                              {item.arrdes.substring(0, 4) +
                                "..." +
                                item.arrdes.substring(38, 42)}
                            </div>
                          </div>
                          <div className="nsuetitei">票数：{item.vote}</div>
                          <div className="nsuebeon">
                            <Button onClick={() => onPlone()}>
                              {item.suol !== "0" ? "加票" : "投票"}
                            </Button>
                            <Button onClick={() => onChesn()}>撤票</Button>
                          </div>
                        </div>
                        <Modal
                          title="提示"
                          width={400}
                          visible={isModalVisible}
                          okText="确认"
                          cancelText="取消"
                          centered
                          onOk={() => {
                            handleOk(item.arrdes);
                          }}
                          onCancel={handleCancel}
                        >
                          <p>注意：请确认是否将您所有的选票投给该社区长？</p>
                        </Modal>
                        <Modal
                          title="提示"
                          width={400}
                          visible={isModalVisible2}
                          okText="确认"
                          cancelText="取消"
                          centered
                          onOk={() => {
                            handleOk2();
                          }}
                          onCancel={handleCancel2}
                        >
                          <p>
                            注意：请确认是否撤销对该社区长的投票,此操作会收取
                            0.001 BNB的数据处理费用.
                          </p>
                        </Modal>
                      </div>
                    ))}
                  </>
                ) : (
                  <div className="bsueri">虚位以待</div>
                )}
              </div>
            </div>
            <div className="clistiem">
              <div className="busimg3">
                {wore3.length !== 0 ? (
                  <>
                    {wore3.map((item: any) => (
                      <div key={item.id || ""} className="Busienr">
                        <div className="buisfsie">
                          <img src={item.img || ""} alt="" />
                        </div>
                        <div className="bsueran">
                          <div className="bsudmgi">
                            <img src={b3} alt="" />
                            <div className="Nuderixs3">3</div>
                          </div>
                          <div className="nsue3">待命名</div>
                          <div className="nsudetim">
                            <img src={ito} alt="" />
                            <div className="zhiyti">
                              {" "}
                              {item.arrdes.substring(0, 4) +
                                "..." +
                                item.arrdes.substring(38, 42)}
                            </div>
                          </div>
                          <div className="nsuetitei">票数：{item.vote}</div>
                          <div className="nsuebeon">
                            <Button onClick={() => onPlone()}>
                              {item.suol !== "0" ? "加票" : "投票"}
                            </Button>
                            <Button onClick={() => onChesn()}>撤票</Button>
                          </div>
                        </div>
                        <Modal
                          title="提示"
                          width={400}
                          visible={isModalVisible}
                          okText="确认"
                          cancelText="取消"
                          centered
                          onOk={() => {
                            handleOk(item.arrdes);
                          }}
                          onCancel={handleCancel}
                        >
                          <p>注意：请确认是否将您所有的选票投给该社区长？</p>
                        </Modal>
                        <Modal
                          title="提示"
                          width={400}
                          visible={isModalVisible2}
                          okText="确认"
                          cancelText="取消"
                          centered
                          onOk={() => {
                            handleOk2();
                          }}
                          onCancel={handleCancel2}
                        >
                          <p>
                            注意：请确认是否撤销对该社区长的投票,此操作会收取
                            0.001 BNB的数据处理费用.
                          </p>
                        </Modal>
                      </div>
                    ))}
                  </>
                ) : (
                  <div className="bsueri">虚位以待</div>
                )}
              </div>
            </div>
          </div>
          {/* <div className="bsyuenr">排行榜将在社区长身份标识开放购买1个小时后开放，敬请期待...</div> */}
        </div>
        <div className="bienPeing">
          <div className="ssberi">排行榜</div>
          <div className="spidbrus">
            <div className="shiwou">
              <div className="Buiertitle">搜索地址：</div>
              <div className="snbueri">
                <Input
                  value={promser}
                  onChange={(e) => promChange(e)}
                  placeholder="请输入钱包地址"
                />
              </div>
              <div className="snbuit">
                <Button
                  onClick={() => {
                    prlisClick();
                  }}
                >
                  搜索
                </Button>
              </div>
            </div>
            <div className="sueubsi">
              我的票数：
              <span>{vedata}</span>
            </div>
          </div>
        </div>
        <div className="pohUsb">
          <div className="nsoJis">
            {voteList.length !== 0 ? (
              <>
                {voteList.map((item: any, index: any) => (
                  <div className="pohusItme" key={item.id}>
                    <div className="usite_left">
                      <div
                        // className={
                        //   index + 1 < 3 ? `Nusdtpaim${index + 1}` : "Nusdtpaim4"
                        // }
                        className="Nusdtpaim4"
                      >
                        {index + 4}
                      </div>
                      <div className="peiungkep">
                        <img src={item.img || ""} alt="" />
                      </div>
                      <div className="nsue1">待命名</div>
                    </div>
                    <div className="usite_count">
                      <div className="lcount">
                        <img src={ito} alt="" />
                        <div className="lcount_tutle">
                          {item.arrdes.substring(0, 4) +
                            "..." +
                            item.arrdes.substring(38, 42)}
                        </div>
                      </div>
                    </div>
                    <div className="usite_reft">
                      <div className="reft_use">
                        <span>票数</span> {item.vote}
                      </div>
                      <div className="reft_btn">
                        <Button onClick={() => onPlone()}>
                          {item.suol !== "0" ? "加票" : "投票"}
                        </Button>
                        <Button onClick={() => onChesn()}>撤票</Button>
                      </div>
                    </div>
                    <Modal
                      title="Tips"
                      width={400}
                      visible={isModalVisible}
                      okText="确认"
                      cancelText="取消"
                      centered
                      onOk={() => {
                        handleOk(item.arrdes);
                      }}
                      onCancel={handleCancel}
                    >
                      <p>注意：请确认是否将您所有的选票投给该社区长？</p>
                    </Modal>
                    <Modal
                      title="提示"
                      width={400}
                      visible={isModalVisible2}
                      okText="确认"
                      cancelText="取消"
                      centered
                      onOk={() => {
                        handleOk2();
                      }}
                      onCancel={handleCancel2}
                    >
                      <p>
                        注意：请确认是否撤销对该社区长的投票,此操作会收取 0.001
                        BNB的数据处理费用.
                      </p>
                    </Modal>
                  </div>
                ))}
              </>
            ) : (
              ""
            )}
          </div>
          <div className="Busfonte">
            <div
              onClick={() => {
                ByuList();
              }}
            >
              More
              <img src={xuais} alt="" />
            </div>
          </div>
        </div>
      </div>
      <Heues />
    </div>
  );
}

export default Index;
