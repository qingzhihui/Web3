const MeReseItem: any = [
  {
    key: 1,
    name: "All",
    image_arr: "Whitebar_arr.png",
    image_box: "Whitebar_box.png",
  },
  {
    key: 2,
    name: "Flights",
    image_arr: "aircraft_arr.png",
    image_box: "aircraft_box.png",
  },
  {
    key: 3,
    name: "Hotel",
    image_arr: "house_arr.png",
    image_box: "house_box.png",
  },
  {
    key: 4,
    name: "Tickets",
    image_arr: "block_arr.png",
    image_box: "block_box.png",
  },
];
export { MeReseItem };
