<template>
  <div>
    <!--   当行文本溢出-->
    <p class="single-line">
      Lorem ipsum doloer siotamet consecytertur
    </p>
    <!--   多行文本溢出-->
    <p class="multi-line">
      Lorem ipsum doloer siotamet consecyterturLorem ipsum doloer siotamet consecyterturLorem ipsum doloer siotamet
      consecyterturLorem ipsum doloer siotamet consecytertur
    </p>
  </div>
</template>

<script setup>

</script>

<style>
.single-line {
  border: 2px solid #ccc;
  width: 200px;
  height: 30px;
  line-height: 30px;
  margin-bottom: 90px;
  color: #f40;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.multi-line {
  border: 2px solid #ccc;
  width: 200px;
  height: 150px;
  line-height: 30px;
  overflow: hidden;
  /*多行显示省略号*/
  display: -webkit-box;
  -webkit-line-clamp: 5;
  -webkit-box-orient: vertical;
}
/* 不要css 处理多行文本框的省略号 使用js怎么处理*/
</style>
