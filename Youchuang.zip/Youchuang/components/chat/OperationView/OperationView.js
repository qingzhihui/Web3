// components/chat/OperationView/OperationView.ts
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    value: {
      type: String,
      value: ""
    },
    flag: {
      type: Boolean,
      value: false
    }
  },

  /**
   * 监听器
   */
  observers: {},

  /**
   * 组件的初始数据
   */
  data: {
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /* 提交 */
    submit: function () {
      if (this.data.flag) {
        wx.showToast({
          title: "请稍等",
          icon: "loading",
          duration: 1000
        });
        return;
      };
      let value = this.data.value;
      if (value.trim() == "") {
        return;
      };
      this.setData({
        value: ""
      })
      let myEventDetail = {
        value: value
      }; // detail对象，提供给事件监听函数
      let myEventOption = {}; // 触发事件的选项
      this.triggerEvent('submit', myEventDetail, myEventOption);
    },
    /* 键盘抬起 */
    inpFocus: function (e) {
      var that = this;
      console.log(e.detail.height);
      // console.log( `${e.detail.height}px`);
      let myEventDetail = {
        height: e.detail.height
      }; // detail对象，提供给事件监听函数
      let myEventOption = {}; // 触发事件的选项
      that.triggerEvent('inpFocus', myEventDetail, myEventOption);
    },
    /* 键盘收起 */
    inpBlur: function (e) {
      let myEventDetail = {
        height: e.detail.height
      }; // detail对象，提供给事件监听函数
      let myEventOption = {}; // 触发事件的选项
      this.triggerEvent('inpBlur', myEventDetail, myEventOption);
    },
    /* 点击回车 */
    inpConfirm: function (e) {
      this.submit();
    }
  }
})