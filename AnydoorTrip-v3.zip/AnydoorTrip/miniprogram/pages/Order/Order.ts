import { TabItem } from '../../config/orderhooke';
import { TParisStatePerve } from '../../config/config'
import api from '../../config/axios'
Page({
  data: {
    active: 0,
    TabList: TabItem,
    paramAtoB: "我是A向B传值",
    Hotel: [],
    Plane: [],
    Admis: [],
    state: true,
    userId: '1'
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.orderShowBeing();
  },
  orderShowBeing() {
    const list = wx.getStorageSync('admin');
    if (list !== "") {
      api._get('user/user-order').then(res => {
        this.setData({
          Hotel: res.data,
        })
        if (res.data.length !== 0) {
          this.setData({
            state: false,
          })
        }
      }).catch(event => {
        console.log(event);
      })
    }

  },
  TabItemBindta(e: any) {
    const prlData = TParisStatePerve(TabItem, Number(e.currentTarget.id))
    this.setData({
      active: Number(e.currentTarget.id),
      TabList: prlData
    })
  },
  OrderDataSgholebe() {
    api._get('user/user-order').then(res => {
      this.setData({
        Hotel: res.data,
      })
      const canvas = this.selectComponent("#canvas");
      canvas.orderSheng(res.data)
    }).catch(event => {
      console.log(event);
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})