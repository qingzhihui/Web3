import {
    DeleteOutlined, FormOutlined, PlusOutlined
} from '@ant-design/icons';
import { Button, Form, Image, Input, Modal, Upload, UploadFile, UploadProps } from 'antd';
import { RcFile } from "antd/es/upload";
import { useState } from "react";
import "./index.css";


// 酒店类型界面
const HotelType = () => {

    const [isAddEssayClass, setAddEssayClass] = useState(false);

    const getBase64 = (file: RcFile): Promise<string> =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });


    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [fileList, setFileList] = useState<UploadFile[]>([

    ]);

    const handleCancel1 = () => setPreviewOpen(false);

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }

        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };

    const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>
        setFileList(newFileList);

    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );

    // 酒店列表测试数据
    const contLsit: any = [
        {
            key: 1,
            HotelTitle: "六扇养生酒店",
            HotelImg: 'https://img2.baidu.com/it/u=355673106,1614830790&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1679590800&t=3abbc6c0f32f549d4b3be4fb4da01b34',
        },
        {
            key: 2,
            HotelTitle: "六扇养生酒店2",
            HotelImg: 'https://img2.baidu.com/it/u=2361676761,992841863&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1679590800&t=cbf000785465e0b53c4ded4b257f6d1b'
        },
        {
            key: 3,
            HotelTitle: "六扇养生酒店3",
            HotelImg: 'https://img1.baidu.com/it/u=1088787692,1934871725&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500',
        },
        {
            key: 4,
            HotelTitle: "六扇养生酒店4",
            HotelImg: 'https://img1.baidu.com/it/u=855914239,2362166124&fm=253&fmt=auto&app=120&f=JPEG?w=1280&h=800',
        },
        {
            key: 5,
            HotelTitle: "六扇养生酒店5",
            HotelImg: 'https://img2.baidu.com/it/u=3891416005,1267729903&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500',
        },
        {
            key: 6,
            HotelTitle: "六扇养生酒店7",
            HotelImg: 'https://img2.baidu.com/it/u=3634820956,3748865840&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500',
        },
        {
            key: 7,
            HotelTitle: "六扇养生酒店7",
            HotelImg: 'https://img0.baidu.com/it/u=791401199,4060462796&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500',
        },
        {
            key: 8,
            HotelTitle: "六扇养生酒店9",
            HotelImg: 'https://img2.baidu.com/it/u=865044619,621565753&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500'
        },
    ]

    // 新增--提交按钮
    const AddHotelType = (values: any) => {
        console.log('提交的数据:', values);
    };
    // 修改
    const uploadus = (item: any) => {
        return () => {
            console.log("点击了修改");
            console.log(item.key);
        }
    }
    // 删除
    const deleteus = (item: any) => {
        return () => {
            console.log("点击了删除");
            console.log(item.key);
        }
    }
    // 点击X关闭
    const handleCancel = () => {
        setAddEssayClass(false);
    };

    // 点击新增分类
    const usAddUser = () => {
        console.log("点击了新增分类");
        setAddEssayClass(true);
    }

    return (
        <div className='HotelType_Box'>
            <div className='HotelType_headerBox'>
                <div className='HotelType_headerBox_thread'></div>
                <div className='HotelType_headerBox_Tit'>&nbsp;&nbsp;&nbsp; 酒店类型</div>
                <div className="HotelType_addBox">
                    <div className="HotelType_addTit" onClick={usAddUser}>新增</div>
                    {/* 新增用户 */}
                    <Modal footer={[null]} open={isAddEssayClass} onCancel={handleCancel}>
                        <div className="HotelType_headerBox">
                            <div className="HotelType_headerBox_thread"></div>
                            <div className='HotelType_headerBox_Tit'>&nbsp;&nbsp;&nbsp;添加酒店集团品牌</div>
                        </div>
                        <div className='HotelType_inputBox'>
                            <Form
                                name="basic"
                                labelCol={{ span: 6 }}
                                wrapperCol={{ span: 18 }}
                                style={{ maxWidth: 600 }}
                                initialValues={{ remember: true }}
                                onFinish={AddHotelType}
                                autoComplete="off"
                            >
                                <Form.Item label="品牌名称" name="ppname">
                                    <Input placeholder="酒店集团品牌名称" />
                                </Form.Item>
                                <Form.Item label="酒店logo" name="logo">
                                    <Upload
                                        action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                                        listType="picture-card"
                                        fileList={fileList}
                                        onPreview={handlePreview}
                                        onChange={handleChange}
                                    >
                                        {fileList.length >= 1 ? null : uploadButton}
                                    </Upload>
                                    <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel1}>
                                        <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                    </Modal>
                                </Form.Item>

                                <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                                    <Button className='HotelType_addBtn' size="middle" type="primary" htmlType="submit">提交</Button>
                                </Form.Item>
                            </Form>
                        </div>
                    </Modal>
                </div>
            </div>
            <div className="HotelType_contBox">
                {contLsit.map((item: any) => {
                    return (
                        <div className="HotelType_singleBox" key={item.key}>
                            <div className="HotelType_contImgBox">
                                <Image width={115} height={100} src={item.HotelImg} />
                            </div>
                            <div className="HotelType_title">{item.HotelTitle}</div>
                            <div className="HotelType_icon">
                                <span onClick={uploadus(item)}><FormOutlined /></span>
                                <span onClick={deleteus(item)}><DeleteOutlined /></span>
                            </div>
                        </div>
                    )
                })}
            </div>
        </div>
    )
}

export default HotelType;