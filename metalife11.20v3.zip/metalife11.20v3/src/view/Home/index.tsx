/*
 * @Author: 'Salah' '2236291956@qq.com'
 * @Date: 2022-11-09 17:33:50
 * @LastEditors: 'Salah' '2236291956@qq.com'
 * @LastEditTime: 2022-11-09 17:52:28
 * @FilePath: \Metalife-fei1.1\src\view\Home\index.tsx
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import React, { useEffect, useState } from "react";
import "./index.css";
import { useTranslation } from "react-i18next";
import Header from "../../components/Header/index";
import Heues from "../../components/Heues";
import Ellipse01 from "../../assets/image/Ellipse01.png";
import Ellipse02 from "../../assets/image/Ellipse02.png";
import Ellipse03 from "../../assets/image/Ellipse03.png";
import Addrer from "../../assets/image/Add.png";
import Document from "../../assets/image/Document.png";
import Buy from "../../assets/image/Buy.png";
import Loading from "../../components/Loading";
import graphicsOne from "../../assets/image/graphicsOne.png";
import graphicsTwo from "../../assets/image/graphicsTwo.png";
import graphicsThree from "../../assets/image/graphicsThree.png";
export default function Home() {
  const { t } = useTranslation();
  const [WalletAccount, setWalletAccount] = useState("");
  const [isTimese1, setisTimese1] = useState(false);
  const [isTimese2, setisTimese2] = useState(false);
  useEffect(() => {
    const addr = localStorage.getItem("Meat_addr");
    if (addr !== null && addr !== undefined) {
      setWalletAccount(addr);
    }
  }, []);
  return (
    <div className="homeIndex">
      <Header MsgIndex="1" />
      <div className="HomeContent">
        <div className="HomeContentRightLogoArea">
          <img className="HomeContentLogoOne" src={graphicsOne} alt="" />
          <img className="HomeContentLogoTwo" src={graphicsTwo} alt="" />
          <img className="HomeContentLogoThree" src={graphicsThree} alt="" />
        </div>
        <div className="HomeAreaOne">
          {`${t("Build a virtual city space parallel to reality")}`}
        </div>
        <div className="HomeAreaTwo">
          {`${t(
            "Build a diversified meta universe ecological platform parallel to reality, integrate games, social networking, NFT, shopping, and digital economy in the meta universe of Mete Life, and seamlessly connect the real world consumer economies such as food, clothing, transportation, food, drink, and play in Meta Life, opening a wonderful meta universe life!"
          )}`}
        </div>
        <div className="sperisier">
          <div
            className="JoinInbutton"
            onClick={() => {
              setisTimese1(true);
            }}
          >
            <img src={require("../../assets/image/tbi.png")} alt="" />{" "}
            {`${t("Meta Life intro")}`}
          </div>
          <div
            className="JoinInbutton"
            onClick={() => {
              setisTimese2(true);
            }}
          >
            <img src={require("../../assets/image/tbi.png")} alt="" />{" "}
            {`${t("Dream Dai Idea")}`}
          </div>
        </div>
        <div className="Psieroi">
          <div className="poitem">
            <img src={Addrer} alt="" />
            <div className="poitemtile">{`${t("Referral")}`}</div>
          </div>
          <div className="poitem">
            <img src={Document} alt="" />
            <div className="poitemtile">{`${t("Announcement")}`}</div>
          </div>
          <div className="poitem">
            <img src={Buy} alt="" />
            <div className="poitemtile">{`${t("Market")}`}</div>
          </div>
        </div>
        <div className="HomeContentLogoArea">
          <img
            className="HomeContentLogoThreePhone"
            src={graphicsThree}
            alt=""
          />
        </div>
        <div className="HomeAreaThree">
          <div className="homeBottomImageArea">
            <div className="firstHomeImageAvatar">
              <img src={Ellipse01} alt="" />
            </div>
            <div className="secondHomeImageAvatar">
              <img src={Ellipse02} alt="" />
            </div>
            <div className="thridHomeImageAvatar">
              <img src={Ellipse03} alt="" />
            </div>
          </div>
          <div className="HomeBolttomRightTextArea">
            <div style={{ fontSize: "24px" }}>47K+</div>
            <div style={{ fontSize: "16px" }}>
              {`${t("Community members")}`}
            </div>
          </div>
        </div>
      </div>
      {/* 提示 */}
      {isTimese1 ? (
        <div className="pserExbuse">
          <div className="pserzhes"></div>
          <div className="pserTisepibeyse">
            <div className="nirptitle">
              <img src={require('../../assets/image/tbi.png')} alt="" />
              {`${t("Meta Life intro")}`}
              <div
                className="pisouenr"
                onClick={() => {
                  setisTimese1(false);
                }}
              >
                X
              </div>
            </div>
            <div className="videopoe">
              <iframe
                width="100%"
                height="100%"
                src="https://www.youtube.com/embed/8VvfMv9mLjo"
                title="4K Maldives Summer Mix 2021 🍓 Best Of Tropical Deep House Music Chill Out Mix By Deep Mix #2"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
      {isTimese2 ? (
        <div className="pserExbuse">
        <div className="pserzhes"></div>
        <div className="pserTisepibeyse">
          <div className="nirptitle">
            <img src={require('../../assets/image/tbi.png')} alt="" />
            {`${t("Dream Dai Idea")}`}
            <div
              className="pisouenr"
              onClick={() => {
                setisTimese2(false);
              }}
            >
              X
            </div>
          </div>
          <div className="videopoe">
            <iframe
              width="100%"
              height="100%"
              src="https://www.youtube.com/embed/JXGd7PB4UYY"
              title="4K Maldives Summer Mix 2021 🍓 Best Of Tropical Deep House Music Chill Out Mix By Deep Mix #2"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>
      ) : (
        ""
      )}
      <Heues burl="/HOME" />
    </div>
  );
}
