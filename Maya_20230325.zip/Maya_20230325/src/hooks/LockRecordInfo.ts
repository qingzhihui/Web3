import { ServerStreamFileResponseOptionsWithError } from "http2";

export interface RecordDataInterface {
  key: React.Key;
  Wallet: string;
  TokenID: string;
  Amount: string;
  UnlockTime: string;
  Cycle: number;
  Cycle_Release: number;
  TGE: number;
  unlockt?:string
}
export interface LockInfoProps {
  TokenList?: any;
  amount?: string;
}


export interface getAlloDataProps {
  address?: string;
  amount?: string;
}
export interface StartProps {
  start?: number;
  amount?: string;
  unlockedAmount?: string;
}
export interface ContributorsProps {
  key?: number;
  No?: number;
  Address?: string;
  Amount?: string;
}
export interface StatusProps {
  Status?: string;
  SaleType?: string;
  MinimumBuy?: string;
  MaximumBuy?: string;
  Totalibutors?: string;
  Youpurchased?: string;
  tokenReleaseEachCycle?: string;
  vestingPeriodEachCycle?: string;
}
export interface vluesProps {
  Address?: string;
  Amount?: string;
}
export interface CurrentPropsType {
  PresaleAddress?: string;
  TokenName?: string;
  TokenSymbol?: string;
  TokenDecimal?: string;
  TokenAddress?: string;
  TotalSupply?: string;
  FeeTokenSymbol?: string;
  TokensForPresale?: string;
  TokensForLiquidity?: string;
  PresaleRate?: string;
  FirstReleaseForPresale?: string;
  ListingRate?: string;
  SoftCap?: string;
  HardCap?: string;
  UnsoldTokens?: string;
  PresaleStartTime?: string;
  PresaleEndTime?: string;
  ListingOn?: string;
  LiquidityPercent?: string;
  LiquidityLockupTime?: string;
  start?:string,
  end?:string,
  raisedAmount?:string,
}

const CycleConversion = (parameter: any) => {
  const MinutesValue = Number(parameter) / 60;
  return MinutesValue;
};
const CycleBpsConversion = (parameter: any) => {
  const PercentValue = Number(parameter) / 100;
  return PercentValue;
};

export { CycleConversion, CycleBpsConversion };
