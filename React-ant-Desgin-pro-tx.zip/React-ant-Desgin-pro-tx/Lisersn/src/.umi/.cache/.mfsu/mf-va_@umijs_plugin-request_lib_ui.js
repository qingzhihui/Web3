export * from 'C:/Users/AnyDoorTrip-05/Desktop/Lisersn/node_modules/@umijs/plugin-request/lib/ui/index.js';
