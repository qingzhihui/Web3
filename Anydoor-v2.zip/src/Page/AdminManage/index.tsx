import { DeleteOutlined, FormOutlined } from "@ant-design/icons";
import { Button, Form, Input, Modal, Radio, Select, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useState } from "react";
import "./index.css";

// 管理员管理界面
const AdminManage = () => {
  const [isaddAdmin, setUpdajx] = useState(false);

  interface DataType {
    key: number;
    manageName: string; // 管理员名称
    manageAccount: string; // 管理员账号
    permissionCharacter: string; //权限字符
    status: string; // 状态
    createTime: string; // 创建时间
  }

  const data: DataType[] = [
    {
      key: 1,
      manageName: "管理员",
      manageAccount: "admin",
      permissionCharacter: "admin",
      status: "正常",
      createTime: "2023-01-01",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "序号",
      render: (_, _record, i) => (
        <Space size="middle">
          <span>{i + 1}</span>
        </Space>
      ),
    },
    {
      title: "管理员名称",
      dataIndex: "manageName",
    },
    {
      title: "管理员账号",
      dataIndex: "manageAccount",
    },
    {
      title: "权限字符",
      dataIndex: "permissionCharacter",
    },
    {
      title: "状态",
      dataIndex: "status",
    },
    {
      title: "创建时间",
      dataIndex: "createTime",
    },
    {
      title: "操作",
      render: (_, record) => (
        <Space size="middle">
          <span className="ad_publicStyleA" onClick={adminReviseBtn(record)}>
            <FormOutlined />
          </span>
          <span className="ad_publicStyleA" onClick={adminDeleteBtn(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 下拉选择框-状态-内容
  const options1 = [
    {
      value: "1",
      label: "正常",
    },
    {
      value: "2",
      label: "不正常",
    },
  ];

  // 下拉选择-状态---选中内容
  const handleChange1 = (value: { value: string; label: React.ReactNode }) => {
    console.log("选中内容", value);
  };

  // 表格修改按钮
  const adminReviseBtn = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record);
    };
  };
  // 表格删除按钮
  const adminDeleteBtn = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record);
    };
  };

  // 新增管理员
  const addAdminbtn = (values: any) => {
    console.log("提交的内容:", values);
  };

  // 点击了搜索
  const adminSearch = () => {
    console.log("点击了搜索");
  };

  // 点击X关闭
  const handleCancel = () => {
    setUpdajx(false);
  };

  // 点击新增管理员
  const addAdmin = () => {
    console.log("点击了新增管理员");
    setUpdajx(true);
  };

  return (
    <div className="ad_Box">
      <div className="ad_headerBox">
        <div className="ad_headerBox_thread"></div>
        <div className="ad_headerBox_Tit">&nbsp;&nbsp;&nbsp; 管理员管理</div>
        <div className="ad_Add_moban">
          <div className="ad_usernameInpuit">
            <div className="ad_publicStyleTit">管理员名称：</div>
            <div className="ad_publicStyleIpt">
              <Input placeholder="请输入管理员名称" />
            </div>
          </div>
          <div className="ad_adminUsernameInpuit">
            <div className="ad_publicStyleTit">管理员账户：</div>
            <div className="ad_publicStyleIpt">
              <Input placeholder="请输入管理员账户" />
            </div>
          </div>
          <div className="ad_statusInpuit">
            <div className="ad_publicStyleTit">状态：</div>
            <div className="ad_publicStyleIpt">
              <Select
                className="ad_xialaxz"
                labelInValue
                style={{ width: 120 }}
                onChange={handleChange1}
                options={options1}
              />
            </div>
          </div>
          <div className="ad_seekBtn" onClick={adminSearch}>
            查找
          </div>
          <div className="ad_addAdminBtn" onClick={addAdmin}>
            新增管理员
          </div>
          {/* 新增管理员 */}
          <Modal
            className="ad_addAdmin"
            footer={[null]}
            open={isaddAdmin}
            onCancel={handleCancel}
          >
            <div className="ad_headerBox">
              <div className="ad_headerBox_thread"></div>
              <div className="ad_headerBox_Tit">
                &nbsp;&nbsp;&nbsp;新增加管理员
              </div>
            </div>
            <div className="ad_addAdmin_Box">
              <Form
                name="basic"
                labelCol={{ span: 6 }}
                wrapperCol={{ span: 18 }}
                style={{ maxWidth: 600 }}
                initialValues={{ remember: true }}
                onFinish={addAdminbtn}
                autoComplete="off"
              >
                <Form.Item label="管理员名称" name="manageName">
                  <Input placeholder="请输入管理员名称" />
                </Form.Item>

                <Form.Item label="登录账号" name="manageAccount">
                  <Input placeholder="请输入登录账户" />
                </Form.Item>
                <Form.Item label="密码" name="password">
                  <Input placeholder="请输入密码" />
                </Form.Item>

                <Form.Item label="是否启用" name="disabledOrNot">
                  <Radio.Group>
                    <Radio value="启用"> 启用 </Radio>
                    <Radio value="禁用"> 禁用 </Radio>
                  </Radio.Group>
                </Form.Item>

                <Form.Item wrapperCol={{ offset: 10, span: 12 }}>
                  <Button
                    className="ad_btn"
                    size="middle"
                    type="primary"
                    htmlType="submit"
                  >
                    提交
                  </Button>
                </Form.Item>
              </Form>
            </div>
          </Modal>
        </div>
      </div>

      <div className="ad_tableBox">
        <Table columns={columns} dataSource={data} />
      </div>
    </div>
  );
};

export default AdminManage;
