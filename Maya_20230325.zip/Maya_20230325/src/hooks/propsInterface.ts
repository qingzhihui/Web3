export interface CurrencyContainerPropsType {
  name?: string;
  totalToken?: number;
  Participants?: number;
  status?: string;
  isCollect?: boolean;
  address?: string;
  AirDropArray?: string;
}

export interface TokenContainerPropsType {
  name?: string;
  progress?: number;
  Liquidity?: number;
  lockupTime?: number;
  status?: string;
}

export interface CurrencyContainerProps {
  currencylist: CurrencyContainerPropsType[];
}
