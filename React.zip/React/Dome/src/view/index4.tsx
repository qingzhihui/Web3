import React, { useState, useEffect, useCallback, useMemo } from "react";

/*
Rules
* 始终使用useState的setter
* 始终将依赖数组置于useEffect,useCallback, 和 useMemo
* 对空数组只运行一次useEffect
* 不依赖于您设置的数据
* 始终将读取的所有状态添加到依赖项数组
*/

// 根据用户交互来处理设置状态

function MyComponent() {
  const [numbers, setNumbers] = useState<any>([]);
  useEffect(() => {
    // if (numbers.length === 0) {
    fetch("/numbers.json")
      .then((resp) => resp.json())
      .then((data) => {
        setNumbers(data);
      });
    // }
  }, []);

  const addOne = useCallback(() => {
    // setNumbers([...numbers, numbers.length + 1]);
    setNumbers((currentNumbers: any) => [
      ...currentNumbers,
      currentNumbers.length + 1,
    ]);
  }, [numbers]);

  const sum = useMemo(() => numbers.reduce((a: any, v: any) => a + v, 0), [numbers]);
  return (
    <div>
      <div>Numbers：{JSON.stringify(numbers)}</div>
      <div>Sum: {sum}</div>
      <button onClick={addOne}>Add One</button>
    </div>
  );
}

const Index = () => {
  return (
    <div>
      <MyComponent />
    </div>
  );
};

export default Index;
