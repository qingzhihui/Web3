import PrivateSaleFactoryABI from "../config/abi/SomebodyAirdrop.json";
const PrivateSaleFactoryAddress = "0x3C50a0B7C7f0A82803e44414145680F1E176a35c";

const SpaceItem = [
  {
    kye: 0,
    label: "BNB",
    value: "0x0000000000000000000000000000000000000000",
  },
  {
    kye: 1,
    label: "BUSD",
    value: "0xF03E0Fc04757184ff64A58385d5553F661878f1A",
  },
  {
    kye: 2,
    label: "USDT",
    value: "0xF03E0Fc04757184ff64A58385d5553F661878f1B",
  },
  {
    kye: 3,
    label: "USDC",
    value: "0xF03E0Fc04757184ff64A58385d5553F661878f1C",
  },
];


export { PrivateSaleFactoryAddress, PrivateSaleFactoryABI, SpaceItem };
