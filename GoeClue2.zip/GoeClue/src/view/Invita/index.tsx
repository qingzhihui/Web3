import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import "./index.scss";
import { ethers } from "ethers";
import home from "../../assets/image/bx_home.png";
import game from "../../assets/image/game.png";
import { CopyOutlined } from "@ant-design/icons";
import { message } from "antd";
import copy from "copy-to-clipboard";
import {
  invite_ADDRESS,
  invite_ABI,
} from "../../redux/Contract/inviteContract.js";
declare const window: Window & { ethereum: any };

export default function Index() {
  const [superiorAddr, setSuperiorAddr] = useState("");
  const [address, setWalletAccount] = useState("");
  const [Huiele, setHuiele] = useState("");
  const [unclaimed, setUnclaimed] = useState("");
  const [sutBint,setSutBint] = useState([]);

  const history = useHistory();

  const routerToPage = (url: string) => {
    history.push(`/${url}`);
  };

  const copyAddr = (addr: string) => {
    copy(addr);
    info();
  };

  const info = () => {
    message.success({
      content: "复制地址成功",
    });
  };
  const superiorShow = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const adres = await signer.getAddress();
    const inviteContract = new ethers.Contract(
      invite_ADDRESS,
      invite_ABI,
      signer
    );
    const getInviter = await inviteContract.getInviter(adres);
    setSuperiorAddr(getInviter.toString());
    const receivedRefferalReward = await inviteContract.receivedRefferalReward(
      adres
    );
    setHuiele(receivedRefferalReward.toString());
    const getPendingRefferalReward =
      await inviteContract.getPendingRefferalReward(adres);
    setUnclaimed(getPendingRefferalReward.toString());
    const getInvitees = await inviteContract.getInvitees(adres);
    setSutBint(getInvitees)
  };
  const receivedRe = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const adres = await signer.getAddress();
    const inviteContract = new ethers.Contract(
      invite_ADDRESS,
      invite_ABI,
      signer
    );
    const claimMyRefferalReward = await inviteContract.claimMyRefferalReward();
  };
  useEffect(() => {
    const address = localStorage.getItem("Cone_addr");
    if (address !== null && address !== undefined) {
      setWalletAccount(address);
      superiorShow();
    } else {
      setWalletAccount("");
    }
  }, [superiorAddr]);

  return (
    <div className="invitations">
      <div className="invitation">
        <div className="middle">
          {/* 上面显示的数据框 */}
          <div className="middleTop">
            <div className="title">Invitation information</div>
            <div className="titleLine" />
            <div className="superior-wallet">My superior wallet</div>
            <div className="superior-wallet-input">
              <span className="superior-wallet-addr">
                {superiorAddr.substring(0, 13) + "......"}
              </span>
              <CopyOutlined
                onClick={() => {
                  copyAddr(superiorAddr);
                }}
                style={{
                  fontSize: "24px",
                  color: "rgb(255,255,255)",
                  cursor: "pointer",
                }}
              />
            </div>
            <div className="rebate-received">Rebate received : {Huiele}</div>
            <div className="rebate-received-input">
              <span className="rebate-received-addr">
                To receive : {unclaimed}
              </span>
              <button onClick={()=>{
                receivedRe()
              }}>Claim</button>
            </div>
            <div className="subordinate-wallet">My subordinate wallet</div>
            <div className="subordinate-walletArea">
              {sutBint.map((item: any, index: number) => (
                <div className="subWalletItem" key={index}>
                  <span className="subWalletAddr">{item.substring(0, 13) + "......"}</span>
                  <CopyOutlined
                    onClick={() => {
                      copyAddr(item);
                    }}
                    style={{
                      fontSize: "24px",
                      color: "rgb(255,255,255)",
                      cursor: "pointer",
                    }}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* 下方的按钮区域 */}
          <div className="middleBottom">
            <div
              className="bottombtnItem"
              onClick={() => {
                routerToPage("Home");
              }}
            >
              <img src={home} alt="" />
              <span>Home</span>
            </div>
            <div
              className="bottombtnItem"
              onClick={() => {
                routerToPage("Court");
              }}
            >
              <img src={game} alt="" />
              <span>Game</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
