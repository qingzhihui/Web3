import React, { useEffect, useState } from "react";
import "./index.css";
import { ethers } from "ethers";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import Header from "../../components/Header/index";
import Heues from "../../components/Heues";
import Jointno from "../../components/Jointnode";
import {
  CloseCircleOutlined,
  RedoOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";
import gife from "../../assets/image/pro.gif";
import { Orderrecord } from "../../hooks/useDate";
import {
  Invitation_ADDRESS,
  Invitation_ABI,
} from "../../redux/Contract/InvitationContract";
import { Meta_ADDRESS, Meta_ABI } from "../../redux/Contract/MetaContract";
declare const window: Window & { ethereum: any };
const MINUTE_MS = 2000;

export default function Farm() {
  const [WalletAccount, setWalletAccount] = useState("");
  // 联合节点
  const [JointShow, setJointShow] = useState(false);
  const [bindproShow, setbindproShow] = useState(true);
  const [invalue, setInvalue] = useState("");
  const [BtnShow, setBtnShow] = useState(true);
  const [dateres, setDateres] = useState("");
  const [dateres2, setDateres2] = useState("");
  const [isTimese, setisTimese] = useState(false);
  const [oreTime, setoreTime] = useState({
    gontime: "",
    oreTime: 1,
  });
  const showHide2 = () => {
    setisTimese(false);
  };
  const { t } = useTranslation();
  const historyurl = useHistory();
  const pioserShow = async () => {
    const addr = localStorage.getItem("Meat_addr");
    if (addr !== null && addr !== undefined) {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      setWalletAccount(addr);
      const FarmContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const nodeReward = await FarmContract.getAllPendingReferralReward(addr);
      const nodeReward2 = await FarmContract.getAllPendingNodeReward(addr);
      setDateres(nodeReward.toString());
      setDateres2(nodeReward2.toString());
      bindShier(signer);
    } else {
      setWalletAccount("");
    }
  };
  const JointShowOnClick = () => {
    if (JointShow === true) {
      setJointShow(false);
    } else {
      setJointShow(true);
    }
  };
  const BindeClick = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const InvitationContract = new ethers.Contract(
        Invitation_ADDRESS,
        Invitation_ABI,
        signer
      );
      const Bined = await InvitationContract.bind(invalue);
      setoreTime({ gontime: `${t("Is Binding...")}`, oreTime: 1 });
      setisTimese(true);
      await Bined.wait();
      setoreTime({ gontime: `${t("Binding succeeded")}`, oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
      bindShier(signer);
    } catch (error) {
      setoreTime({ gontime: `${t("Binding failed")}`, oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const InputOnChen = (e: any) => {
    setInvalue(e.target.value);
    if (e.target.value.length === 42) {
      setBtnShow(true);
    } else {
      setBtnShow(false);
    }
  };
  const bindShier = async (signer: any) => {
    const InvitationContract = new ethers.Contract(
      Invitation_ADDRESS,
      Invitation_ABI,
      signer
    );
    const address = await signer.getAddress();
    const BingHideSHow = await InvitationContract.verifyBinding(address);
    if (BingHideSHow === true) {
      setbindproShow(false);
    } else {
      setbindproShow(true);
    }
  };
  const dateresClick = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const FarmContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const dateresPro = await FarmContract.claimAllNodeReward();
      setoreTime({ gontime: `${t("Is Receiving...")}`, oreTime: 1 });
      setisTimese(true);
      await dateresPro.wait();
      setoreTime({ gontime: `${t("Successfully received")}`, oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
      bindShier(signer);
    } catch (error) {
      const BugLoader = JSON.parse(JSON.stringify(error)).error.data.message;
      setoreTime({ gontime: `${t(BugLoader)}`, oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };
  const claimAllNodeReward = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const FarmContract = new ethers.Contract(Meta_ADDRESS, Meta_ABI, signer);
      const dateresPro = await FarmContract.claimAllReferralReward();
      setoreTime({ gontime: `${t("Is Receiving...")}`, oreTime: 1 });
      setisTimese(true);
      await dateresPro.wait();
      setoreTime({ gontime: `${t("Successfully received")}`, oreTime: 2 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
      bindShier(signer);
    } catch (error) {
      const BugLoader = JSON.parse(JSON.stringify(error)).error.data.message;
      setoreTime({ gontime: `${t(BugLoader)}`, oreTime: 3 });
      setisTimese(true);
      setTimeout(() => {
        setisTimese(false);
      }, 2000);
    }
  };

  useEffect(() => {
    pioserShow();
    (window as any).ethereum.on(
      "accountsChanged",
      async function (accounts: any) {
        localStorage.setItem("Meat_addr", accounts[0]);
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        bindShier(signer);
        setWalletAccount(accounts[0]);
      }
    );
  }, [WalletAccount, BtnShow, dateres]);
  useEffect(() => {
    const interval = setInterval(async () => {
      const addr = localStorage.getItem("Meat_addr");
      if (addr !== null && addr !== undefined) {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const InvitationContract = new ethers.Contract(
          Invitation_ADDRESS,
          Invitation_ABI,
          signer
        );
        const BingHideSHow = await InvitationContract.verifyBinding(addr);
        if (BingHideSHow === true) {
          setbindproShow(false);
        } else {
          setbindproShow(true);
        }
      } else {
        setWalletAccount("");
      }
    }, MINUTE_MS);
    return () => clearInterval(interval);
  }, []);
  return (
    <>
      <div className="farmPage">
        <Header MsgIndex="2" address={WalletAccount} />
        <div className="DataArea">
          <div className="DanHide">
            <div className="speriose">
              <div className="speriose_title">{`${t("Node reward")}`}：</div>
              <div className="cioserp">
                <div className="cioserp_nru">{dateres || 0}</div>|
                {dateres === "0" ? (
                  <div className="spoerusbe1">
                    <button disabled>{`${t("receive")}`}</button>
                  </div>
                ) : (
                  <div className="spoerusbe2">
                    <button
                      onClick={() => {
                        dateresClick();
                      }}
                    >
                      {`${t("receive")}`}
                    </button>
                  </div>
                )}
              </div>
              <div className="speriose_title">
                {`${t("Recommendation reward")}`}：
              </div>
              <div className="cioserp">
                <div className="cioserp_nru">{dateres2 || 0}</div>|
                {dateres2 === "0" ? (
                  <div className="spoerusbe1">
                    <button disabled>{`${t("receive")}`}</button>
                  </div>
                ) : (
                  <div className="spoerusbe2">
                    <button
                      onClick={() => {
                        claimAllNodeReward();
                      }}
                    >
                      {`${t("receive")}`}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
          {/* wbd */}
          <div className="DataBlock">
            <div className={`DataBlock_nroe ${JointShow ? "active" : ""}`}>
              <div className="DataBlock_nroe_title">
                {/* Joint node组件 */}
                <div>{`${t("META")}`}</div>
              </div>
              <div className="psierhs_button">
                <button
                  onClick={() => {
                    JointShowOnClick();
                  }}
                >
                  {JointShow ? <>{`${t("Stow")}`}</> : <>{`${t("open")}`}</>}
                </button>
              </div>
            </div>
            {JointShow ? (
              <div className="DataBlock_nroe_nudro">
                <div className="psierhs_nro">
                  <Jointno />
                </div>
              </div>
            ) : (
              ""
            )}
          </div>
          {bindproShow ? (
            <div className="spoeusib">
              <div className="nusierse">
                <div className="nusierse_title">{`${t("System prompt")}`}</div>
                <div className="nusierse_nuer">
                  {`${t("Inviter wallet")}`}：{" "}
                  <input
                    type="text"
                    value={invalue}
                    placeholder={t("Enter the bound person s wallet")}
                    onChange={(e) => InputOnChen(e)}
                  />
                  {BtnShow ? (
                    <button
                      onClick={() => {
                        BindeClick();
                      }}
                    >
                      {`${t("Binding")}`}
                    </button>
                  ) : (
                    <button className="posuBtn" disabled>
                      {`${t("Binding")}`}
                    </button>
                  )}
                </div>
                <div className="bsuerinr">
                  {`${t(
                    "Note: Please bind the inviters wallet before performing other operations"
                  )}`}
                </div>
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
        <Heues burl="/FARM" />
      </div>

      {/* 提示 */}
      {isTimese ? (
        <div className="pserExbuse">
          <div className="pserzhes"></div>
          <div className="pserTise">
            <div className="pserExchange_nro">
              <div className="nriopsr">
                <div className="logding">
                  {(oreTime as any).oreTime === 1 ? (
                    <div className="xgirm">
                      <img src={gife} alt="" />
                    </div>
                  ) : (oreTime as any).oreTime === 2 ? (
                    <CheckCircleOutlined className="Luiisnr" />
                  ) : (
                    <CloseCircleOutlined className="Luiisnr" />
                  )}
                </div>
                <div className="Ptimeb">{(oreTime as any).gontime}</div>
              </div>
              <div
                className="gbuiengkum"
                onClick={() => {
                  showHide2();
                }}
              >
                <CloseCircleOutlined
                  style={{
                    color: "#ffff",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  );
}
