import React, { useState, useEffect } from "react";
import { Menu, Button, Modal, Divider, Input } from "antd";
import { ArrowRightOutlined } from "@ant-design/icons";
import { useMoralis, useNewMoralisObject } from "react-moralis";
import { useHistory } from "react-router-dom";

import "./index.scss";
import { Link } from "react-router-dom";
import loge from "../../assets/kig.png";
import vlog1 from "../../assets/bumg/mack.png";
import vlog2 from "../../assets/bumg/lgs.png";
import vlog3 from "../../assets/bumg/emli.png";

var bise: any = ["/Home"];
function Header(props: any) {
  let history = useHistory();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isModemio, setisModemio] = useState(false);
  const [address, setAddress] = useState("");
  const {
    authenticate,
    isAuthenticated,
    logout,
    user,
    setUserData,
  } = useMoralis();
  const [username, setUsername] = useState("");
  const [emailIput, seremailIput] = useState("");

  const MenuList = [
    {
      key: "/Home",
      label: "HOME",
    },
    {
      key: "/About",
      label: "ABOUT",
    },
    {
      key: "/Mint",
      label: "MINT",
    },
    {
      key: "/Game",
      label: "GAME",
    },
    {
      key: "/Rank",
      label: "RANK",
    },
    {
      key: "/Market",
      label: "MARKET",
    },
  ];
  const BlseiSHow = () => {
    setIsModalVisible(true);
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const handleOkemiso = () => {
    setisModemio(false);
  };

  const handleCancelmiso = () => {
    setisModemio(false);
  };
  const onClickHeader = (MenuItem: any) => {
    bise = MenuItem.key;
    if (bise == MenuItem.key) {
      history.push(MenuItem.key);
    }
  };
  const MetaMaskShow = async () => {
    if (!isAuthenticated) {
      await authenticate({ signingMessage: "Log in using Moralis" })
        .then(function (user: any) {
          setAddress(user!.get("ethAddress"));
          setUsername(user.getUsername());
          setIsModalVisible(false);
        })
        .catch(function (error: any) {
          console.log(error);
        });
    } else {
      console.log("already logged");
    }
  };
  const BlseiHide = async () => {
    await logout();
    setAddress("");
  };
  const walletconnect = async () => {
    if (!isAuthenticated) {
      await authenticate({ provider: "walletconnect" })
        .then(function (user) {
          console.log(user!.get("ethAddress"));
          setIsModalVisible(false);
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  };

  const emailconnect = async () => {
    if (!isAuthenticated) {
      await authenticate({ signingMessage: "Log in using Moralis" })
        .then(function (user: any) {
          setAddress(user!.get("ethAddress"));
          setUsername(user.getUsername());
          setIsModalVisible(false);
          if(user.attributes.email === undefined){
            setisModemio(true);
          }else{
            setisModemio(false);
          }
        })
        .catch(function (error: any) {
          console.log(error);
        });
    } else {
      console.log("already logged");
    }
  };

  const emaiChange = (e: any) => {
    const { value } = e.target;
    seremailIput(value);
  };

  const emaiOnClike = () => {
    setUserData({
      email: emailIput,
    }).then(() => setisModemio(false));
  };
  useEffect(() => {
    if (isAuthenticated) {
      setAddress(user!.get("ethAddress"));
    }
  }, [isAuthenticated]);

  return (
    <div className="header">
      <div className="LeiusButton">
        <Button size="large">
          <img src={loge} alt="" />
        </Button>
      </div>
      <div className="header_nuer">
        <Menu
          mode="horizontal"
          defaultSelectedKeys={bise}
          onClick={onClickHeader}
          items={MenuList}
          theme="dark"
        ></Menu>
      </div>
      <div className="RealButton">
        {address !== "" ? (
          <div className="Realsibu">
            <div className="noelue">
              <span>
                {address.substring(0, 4) + "..." + address.substring(38, 42)}
              </span>
            </div>
            <div>
              <div
                className="bsuein"
                onClick={() => {
                  BlseiHide();
                }}
              >
                DISCONNECT
              </div>
            </div>
          </div>
        ) : (
          <Button
            onClick={() => {
              BlseiSHow();
            }}
          >
            CONNECT WALLET
          </Button>
        )}
      </div>
      <Modal
        title="Connect"
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={null}
        width={380}
        centered={true}
      >
        <div
          className="skuebitem"
          style={{ marginBottom: "20px" }}
          onClick={() => {
            MetaMaskShow();
          }}
        >
          <span>MetaMask</span>
          <div className="diubdlei">
            <img src={vlog3} alt="" />
            <ArrowRightOutlined />
          </div>
        </div>
        <div
          className="skuebitem"
          onClick={() => {
            walletconnect();
          }}
        >
          <span>WalletConnect</span>
          <div className="diubdlei">
            <img src={vlog1} alt="" />
            <ArrowRightOutlined />
          </div>
        </div>
        <Divider className="snuekl">or</Divider>
        <div
          className="skuebitem"
          onClick={() => {
            emailconnect();
          }}
        >
          <span>Contionue with email</span>
          <div className="diubdlei">
            <img src={vlog2} alt="" />
            <ArrowRightOutlined />
          </div>
        </div>
        <div className="dnbulei">
          <span>
            By continuing you agree to Ponzopoly Privacy Policy and Terms and
            Conditions
          </span>
        </div>
      </Modal>
      <Modal
        title="Connect"
        visible={isModemio}
        onOk={handleOkemiso}
        onCancel={handleCancelmiso}
        footer={null}
        width={380}
        centered={true}
      >
        <div className="bsennr">
          <div className="bsennr_input">
            <div className="bsennr_title">
              <span>Address : </span>
              <span className="skiebs">{address}</span>
            </div>
          </div>
          <div className="bsennr_input">
            <div className="bsennr_title">
              <span>Email</span>
            </div>
            <Input
              onChange={emaiChange}
              value={emailIput}
              placeholder="Email"
            />
          </div>
          <div className="beetin">
            <Button
              size="large"
              onClick={() => {
                emaiOnClike();
              }}
            >
              Binding Email
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

export default Header;
