const getTokenLogoURL = (address: string) =>
  `https://defa.finance/images/tokens/${address}.png`

export default getTokenLogoURL
