<template>
    <view :style="{ backgroundColor: num }">
        随机颜色
    </view>
    <button @click="randomColot()">ches</button>
    <button @click="randomColot2()">ches2</button>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const num = ref('');


// 两种写法
// 第一种 平平无奇非常正宗
function randomColot() {
    // Math.random()
    // Math.random()*256
    // Math.floor(Math.random()*256)
    var r = Math.floor(Math.random() * 256),
        g = Math.floor(Math.random() * 256),
        b = Math.floor(Math.random() * 256)
    num.value = `rgb(${r},${g},${b})`
    return `rgb(${r},${g},${b})`
}
// 第二种 剑走偏锋 非常惊艳
function randomColot2() {
    num.value = `#${Math.random().toString(18).substring(2, 8)}`
    return  `#${Math.random().toString(18).substring(2, 8)}`;
}
</script>

<style>

</style>