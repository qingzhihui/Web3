import UseStateComponent from "@/components/useStateComponent";
import UseEffectComponent from "@/components/useEffectComponent";
import UseContextComponent from "@/components/UseContextComponent";
import UseReducerComponent from "@/components/UseReducerComponent";
import UseRefComponent from "@/components/UseRefComponent";
import CustomHookComponent from "@/components/CustomHookComponent";
import EvenMoreReactComponent from "@/components/EvenMoreReactComponent";
import UseCallbackComponent from "@/components/UseCallbackComponent";

const Index = () => {
  return (
    <div>
      <h1>useState</h1>
      <UseStateComponent />
      <h1>useEffect</h1>
      <UseEffectComponent />
      <h1>useContext 上下文</h1>
      <UseContextComponent />
      <h1>useReducer</h1>
      <UseReducerComponent />
      <h1>useRef</h1>
      <UseRefComponent />
      <h1>Custom Hook</h1>
      <CustomHookComponent />
      <h1>Even more React component TS stuff</h1>
      <EvenMoreReactComponent />
      <h1>useCallback</h1>
      <UseCallbackComponent />
    </div>
  );
};

export default Index;
