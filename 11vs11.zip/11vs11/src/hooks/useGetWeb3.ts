import { useSelector } from "react-redux";
import { RootStateType } from "../redux/store";

export const useGetWeb3 = () => {
  return useSelector((state: RootStateType) => state.web3Slice);
};
