import React, { useState } from 'react'
import './index.scss'
import { Input } from 'antd';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

export default function Index() {
  const [date, setDate] = useState<any>(new Date());
  return (
    <div className='home'>
      <div className='countenet'>
        <div className='anydoor'>
          <div className='hometitle'>Anydoor Trip</div>
          <div className='anybut'>
            <button>JION US</button>
            <button>FIND</button>
          </div>
          <div className='anyinsted'>Instead of
            yearning,<br />
            it is better to start!</div>
          <div className='anysearch'>
            <div className='searchs'>
              <div>Hotel reservation</div>
              <Input placeholder="Please enter the city, hotel name" bordered={false} />
            </div>
            <div className='searchbut'>SEARCH</div>
          </div>
          <div className='calendar'>
            <div className='calendar-left'>
              <div className='tiile'>Anydoor Trip</div>
              <div className='booking'>Start booking your perfect trip</div>
              <div className='book'>
                <img src={require('@/assets/image/Frame.png')} alt="" />
                <div className='never'>Book me, never give up on you, Anydoor Trip will never let you down.</div>
              </div>
              <div className='positioning'>
                <img src={require('@/assets/image/tablermap.png')} alt="" />
                <div>London</div>
              </div>
              <div className='but'><button>RESERVATION</button></div>
            </div>
            <div className='calendar-right'>
              <div className='calendar-container'>
                <Calendar
                  onChange={setDate}
                  value={date}
                  selectRange={true}
                  locale='en'
                />
              </div>
              {date.length > 0 ? (
                <p className='text-center'>
                  <span className='bold'>Start:</span>{' '}
                  {date[0].toDateString()}
                  &nbsp;|&nbsp;
                  <span className='bold'>End:</span> {date[1].toDateString()}
                </p>
              ) : (
                <p className='text-center'>
                  <span className='bold'>Default selected date:</span>{' '}
                  {date.toDateString()}
                </p>
              )}
            </div>
          </div>
        </div>
        <div className='lifestyle'>
          <div className='lifetitle'>
            <div className='title1'>Anydoor Trip Lifestyle</div>
            <div className='title2'>Exceptional travel experiences and concierge services</div>
          </div>
          <div className='coutwen'>
            <div>
              Anydoor Trip is dedicated to providing the best luxury travel escapes
              such as worldwide sports event arrangements, flights concierge services,
              fashion  boutique events and exclusive celebrity parties.
            </div>
            <div>We believe that your time is invaluable －our online order system is
              availble 24/7. You can always rely on our world-class services whenever
              and wherever.</div>
          </div>
          <div className='imgs'>
            <div><img src={require('@/assets/image/IMAGE.png')} alt="" /></div>
            <div><img src={require('@/assets/image/IMAGE-2.png')} alt="" /></div>
            <div><img src={require('@/assets/image/IMAGE-3.png')} alt="" /></div>
          </div>
        </div>
        <div className='experience'>
          <div className='perience'>
            <div className='exceptional'>The exceptional experience</div>
            <div className='selection'>Our selection of lifestyle</div>
            <div className='imgscard'>
              <div><img src={require('@/assets/image/IMAGE-4..png')} alt="" /></div>
              <div><img src={require('@/assets/image/IMAGE-5..png')} alt="" /></div>
              <div><img src={require('@/assets/image/IMAGE-6..png')} alt="" /></div>
              <div><img src={require('@/assets/image/IMAGE-7..png')} alt="" /></div>
            </div>
          </div>
          <button>Explore</button>
        </div>
        <div className='membership'>
          <div className='tiitle'>
            <div className='trip'>Anydoor Trip  Membership</div>
            <div className='services'>Our services are trusted and praised by customers who have experienced the luxurious lifestyle.</div>
          </div>
          <div className='middle'>
            <div className='one'>
              <div>Anydoor Trip ’s mission is to deliver phenomenal travel experiences to our customers as we provide access to the luxury lifestyle.</div>
              <div>We are highly recognized by customers who are keen to enjoy the life they never imagined.</div>
            </div>
            <div className='two'>
              <img src={require('@/assets/image/Rectangle-13.png')} alt="" />
              <div>Exceptional, customized, travel experiences and luxury concierge services available at your fingertips.</div>
            </div>
            <div className='three'>
              <img src={require('@/assets/image/Rectangle-13-2.png')} alt="" />
              <div>We devote ourselves to satisfying your requests whenever you need and wherever you are.</div>
            </div>
          </div>
          <button>Anydoor Trip Member Benefits</button>
        </div>
      </div>
    </div>
  )
}
