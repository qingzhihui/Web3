import type { NextApiRequest, NextApiResponse } from "next";

type LoginRequestBody = {
  username: string;
  password: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method Not Allowed" });
    return;
  }
  const { username, password }: LoginRequestBody = req.body;
  if (username === "123" && password === "123") {
    res.status(200).json({ message: "登录成功", name: "王八蛋" });
  } else {
    res.status(401).json({ error: "用户名或密码错误" });
  }
}
