import {
  text_request
} from "../../../utils/request_backend/text_request";
import {
  portrait
} from "../../../utils/request_backend/config";

const app = getApp()
Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多 slot 支持
  },
  properties: {
    messageList: {
      type: Array,
      value: []
    }
  },
  data: {
    statsuBarHeight: app.globalData.statsuBarHeight,
    headHeight: 40,
    chatListHeight: 0,
    keyboardHeight: 0,
    inutPanelHeight: 50,
    toView: "item0",
    curMessage: "",
    flag: false
  },
  lifetimes: {
    attached() {
      console.log(123);
      this.setChatListHeight();
      wx.onKeyboardHeightChange(res => { //监听键盘高度变化
        this.setData({
          keyboardHeight: res.height
        });
        this.setChatListHeight();
        this.scroll2Bottom();
      });
    }
  },
  methods: {
    setChatListHeight() {
      this.setData({
        chatListHeight: app.globalData.sysHeight - app.globalData.statsuBarHeight - this.data.headHeight - this.data.keyboardHeight - this.data.inutPanelHeight
      })
    },
    hideKeyboard() {
      wx.hideKeyboard();
      this.hideMediaPanel();
    },
    getInput(e) {
      let value = e.detail.value;
      this.setData({
        curMessage: value
      });
    },
    submit: function () {
      if (this.data.flag) {
        wx.showToast({
          title: "请稍等",
          icon: "loading",
          duration: 1000
        });
        return;
      };
      let value = this.data.curMessage;
      if (value.trim() == "") {
        return;
      };
      this.setData({
        curMessage: ""
      })
      let myEventDetail = {
        value: value
      }; // detail对象，提供给事件监听函数
      let myEventOption = {}; // 触发事件的选项
      this.triggerEvent('submit', myEventDetail, myEventOption);
    },
    /* 点击回车 */
    inpConfirm: function (e) {
      this.submit();
    }
  }
})