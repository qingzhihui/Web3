import api from '../config/axios'

const burUrl = "https://travelport.leonardocontentcloud.com/imageRepo/7/0/132/560/122/ZUHZH_6670713001_M.jpg";
export interface ParisPage {
  key?: number;
  name?: string;
  date?: string;
  value?: string;
  state?: boolean;
}
export interface SheetProps {
  key?: number;
  title?: string;
  state?: boolean;
}

const ParisData: ParisPage[] = [
  {
    key: 1,
    name: "SUN",
    date: '11',
    value: "$4,623",
    state: true
  },
  {
    key: 2,
    name: "MON",
    date: '12',
    value: "$4,223",
    state: false
  },
  {
    key: 3,
    name: "TUE",
    date: '12-13',
    value: "$4,891",
    state: false
  },
  {
    key: 4,
    name: "WED",
    date: '14',
    value: "$5,343",
    state: false
  },
  {
    key: 5,
    name: "QEP",
    date: '18',
    value: "$3,343",
    state: false
  },
  {
    key: 6,
    name: "RUE",
    date: '12',
    value: "$2,343",
    state: false
  },
  {
    key: 7,
    name: "LIN",
    date: '12:13',
    value: "$2,343",
    state: false
  }
]

const SheetData: SheetProps[] = [
  {
    key: 1,
    title: "舱位",
    state: true,
  }, {
    key: 2,
    title: "中转",
    state: false,
  }, {
    key: 3,
    title: "航空公司偏好",
    state: false,
  },
  {
    key: 4,
    title: "时间",
    state: false,
  },
  {
    key: 5,
    title: "总航程",
    state: false,
  }
]

const TParisStatePerve = (data: any, id: number) => {
  const Data = data.map((item: any) => {
    if (item.key === id) {
      item.state = true;
    } else {
      item.state = false;
    }
    return item;
  })
  return Data
}

const getWeekByDate = (dates: any) => {
  let show_day = new Array('周日', '周一', '周二', '周三', '周四', '周五', '周六');
  let date = new Date(dates);
  date.setDate(date.getDate());
  let day = date.getDay();
  return show_day[day];
}
const Compare = (data: number[]) => {
  var minIndex = 0;
  var maxIndex = 0;
  for (var i = 0; i < data.length; i++) {
    if (data[i] < data[minIndex]) {
      minIndex = i;
    }
    if (data[i] > data[maxIndex]) {
      maxIndex = i;
    }
  }
  return {
    min: data[minIndex],
    max: data[maxIndex]
  }
}
// <view class="iconfont icon-fluent_food-24-regular"></view>


const LogeStateJudge = () => {
  const AdminData = wx.getStorageSync('admin');
  if (AdminData === "") {
    return true;
  } else {
    return false;
  }
}


const differenceInterval = (start: string, End: string) => {
  var difference = Math.abs(new Date(start).getTime() - new Date(End).getTime())
  return Math.ceil(difference / (1000 * 60 * 60 * 24))
}

const SecenInputeAwinet = async () => {
  const res = await api._get('hotel-type/list');
  return res;
}


const cityObjiesfilter = (data: any) => {
  var cityObjies: any = {};
  data.map((item: any) => {
    if (item.locationType === "city") {
      cityObjies = item;
    }
  })
  return cityObjies;
}
const MeaiDatefilter = (data: any) => {
  const MeaiDate: any = [];
  data.map((item: any) => {
    const BUisner: any = item.media[0];
    var mediaImage: any = ""
    if (BUisner !== undefined) {
      mediaImage = BUisner.urlFormat.replace('%s', 'M');
    } else {
      mediaImage = burUrl
    }
    MeaiDate.push({
      ...item, Img: mediaImage
    })
  })
  return MeaiDate;
}
const Suniserfilter = (dataOne: any, dataTwo: any) => {
  dataTwo.forEach((item: any) => {
    let index = dataOne.findIndex((e: any) =>
      e.id == item.id
    )
    if (index > -1) {
      dataOne[index].localCurrency = item.localCurrency;
      dataOne[index].localMinPrice = item.localMinPrice
    } else {
      dataOne.push({
        ...dataOne[index], localCurrency: item.localCurrency, localMinPrice: item.localMinPrice
      })
    }
  });
  return dataOne;
}

const transMoney = (value: any) => {
  if (value === 0) {
    return parseFloat(value).toFixed(2);
  }
  if (value != "") {
    var num = "";
    value += "";//转化成字符串
    value = parseFloat(value.replace(/,/g, '')).toFixed(2);//若需要其他小数精度，可将2改成变量
    if (value.indexOf(".") == -1) {
      num = value.replace(/\d{1,3}(?=(\d{3})+$)/g, function (s: any) {
        return s + ',';
      });
    } else {
      num = value.replace(/(\d)(?=(\d{3})+\.)/g, function (s: any) {
        return s + ',';
      });
    }
  } else {
    num = ""
  }
  return num;
}



export {
  ParisData,
  SheetData,
  TParisStatePerve,
  Compare,
  differenceInterval,
  LogeStateJudge,
  SecenInputeAwinet,
  Suniserfilter,
  MeaiDatefilter,
  cityObjiesfilter,
  transMoney,
  getWeekByDate
}

