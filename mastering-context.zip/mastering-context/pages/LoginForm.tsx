import { useState } from "react";
import Router from "next/router";

const LoginForm = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const response = await fetch("/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }),
    });
    if (response.status === 200) {
      // 登录成功，重定向到受保护的页面
      //   window.location.href = "/router-demo";
      const data = await response.json();
      Router.push({
        pathname: "/router-demo",
        query: { name: data.name, message: data.message },
      });
    } else {
      // 登录失败，显示错误消息
      const data = await response.json();
      alert(data.error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        用户名：
        <input
          type="text"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
        />
      </label>
      <label>
        密码：
        <input
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
        />
      </label>
      <button type="submit">登录</button>
    </form>
  );
};

export default LoginForm;
