<template>

</template>

<script setup>

</script>

<style>


/*逐帧动画*/
.che {
  animation: move 60s steps(60) forwards;
}

.che2 {
  /* linear */
  animation: move 1s steps(12) infinite;
}

@keyframes run {
  0% {
    background-position-x: 0;
  }
  100% {
    background-position-x: -2400px;
  }
}

/* 动画的暂停和恢复 */

.container {
  animation: rotate 20s linear infinite;
}

.container:hover {
  /* running*/
  animation-play-state: paused;
}

@keyframes rotate {
  0% {
    transform: rotateY(0deg);
  }
  100% {
    transform: rotateY(-360deg);
  }
}
</style>
