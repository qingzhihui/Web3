import React, { useState, useEffect, useCallback } from "react";
import "./index.scss";
import ButtonLoading from "../../components/ButtonLoading";
import {
  PrivateSaleFactoryABI,
  PrivateSaleFactoryAddress,
} from "../../hooks/Sale";
import { useHistory, useLocation } from "react-router-dom";
import {
  FormatUnitsConver,
  InstancedContract,
  TimestampToTime,
} from "../../hooks/config";
import {
  CycleBpsConversion,
  CycleConversion,
} from "../../hooks/LockRecordInfo";
import {
  LaunchPadFactoryABI,
  LaunchPadFactoryAddress,
  StdRouterABI,
} from "../../hooks/launchpad";
import { CreatelockAddress, SaleProps } from "../../hooks/Createlock";
import { useTranslation, Trans } from "react-i18next";
import LaunchpadRoadmapPC from "../../components/RoadmapPC/LaunchpadRoadmapPC"
import PrivateSaleRoadmapPC from "../../components/RoadmapPC/PrivateSaleRoadmapPC"
import LaunchpadRoadmapMobile from "../../components/RoadmapMobile/LaunchpadRoadmapMobile"
import PrivateSaleRoadmapMobile from "../../components/RoadmapMobile/PrivateSaleRoadmapMobile"
declare const window: Window & { ethereum: any };
const Burn: React.FC = (props: any) => {
  const [useDate, setUseDate] = useState<any>({});
  const [dataItem, setdataItem] = useState<SaleProps>({});
  const [useUrl, setUseUrl] = useState("");
  let history = useHistory();
  const [loading, setLoading] = useState<boolean>(false);
  const [warning, setWarning] = useState<boolean>(true);
  const { t } = useTranslation();
  const { state } = useLocation<any>();
  const submitOnCLick = async () => {
    try {
      setLoading(true);
      const Contract = InstancedContract(
        PrivateSaleFactoryAddress,
        PrivateSaleFactoryABI
      ) as any;
      const LaunchPadFactoryContract = InstancedContract(
        LaunchPadFactoryAddress,
        LaunchPadFactoryABI
      ) as any;
      const {
        PrivatData,
        PoleieData: {
          routeName,
          inputValue,
          Radiovalue,
          ListingOptions,
          FeeOptions,
        },
        prerateData,
        VestinData,
      } = useDate;
      if (routeName === "Lauchpad") {
        const DexInfoContract = InstancedContract(
          prerateData.Router,
          StdRouterABI
        ) as any;
        const factory = await DexInfoContract.factory();
        const Whitrelist = PrivatData[1] === "true" ? 1 : 0;
        const LaunchpadInfo = [
          inputValue,
          Radiovalue,
          PrivatData[2],
          PrivatData[3],
          prerateData.Presale,
          PrivatData[4],
          PrivatData[5],
          PrivatData[6],
          PrivatData[7],
          Whitrelist,
          prerateData.Refund,
        ];
        const ClaimInfo = [
          "0",
          "0",
          VestinData[0],
          VestinData[1],
          VestinData[2],
        ];
        const DexInfo = [
          ListingOptions,
          prerateData.Router,
          factory,
          prerateData.listingrate,
          prerateData.liquidity.toString(),
          prerateData.lockup.toString(),
        ];
        const flatFee = await LaunchPadFactoryContract.flatFee();
        const FeeSystem = [FeeOptions.split(",")[0], FeeOptions.split(",")[1]];

        const create = await LaunchPadFactoryContract.create(
          LaunchpadInfo,
          ClaimInfo,
          DexInfo,
          FeeSystem,
          CreatelockAddress,
          useUrl,
          {
            value: flatFee,
          }
        );
        await create.wait();
        props.history.replace();
        setLoading(false);
      } else if (routeName === "Fairlaunch") {
      } else if (routeName === "Dutchauction") {
      } else if (routeName === "SubscrIpool") {
      } else {
        const flatFee = await Contract.flatFee();
        const create = await Contract.create(
          useDate.memoryData,
          useDate.PrivatData,
          useDate.VestinData,
          useUrl,
          {
            value: flatFee,
          }
        );
        await create.wait();
        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
    }
  };
  const BackAreaOnCLick = () => {
    history.push({
      pathname: "/CreateAirdrop",
      state: state,
    });
  };

  useEffect(() => { }, [state, useDate]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          const {
            data: { PoleieData, memoryData, PrivatData, VestinData, prerateData, WhiteliData
            },
            libns,
          } = props.location.state;
          setUseDate((pristate: any) => {
            return (pristate = {
              PoleieData,
              memoryData,
              PrivatData,
              VestinData,
              prerateData,
              WhiteliData
            });
          });
          console.log(WhiteliData);
          const tmpList = libns.split(",");
          setdataItem((pristate: any) => {
            return (pristate = {
              title: PoleieData.inputValue,
              method: PoleieData.routeName,
              softcap: FormatUnitsConver(PrivatData[2], 18),
              hardcap: FormatUnitsConver(PrivatData[3], 18),
              minbuy: FormatUnitsConver(PrivatData[4], 18),
              maxbuy: FormatUnitsConver(PrivatData[5], 18),
              fundtge: CycleBpsConversion(VestinData[0]).toString(),
              fundcycle: CycleConversion(VestinData[1]).toString(),
              releasecycle: CycleBpsConversion(VestinData[2]).toString(),
              start: TimestampToTime(PrivatData[6]),
              end: TimestampToTime(PrivatData[7]),
              website: tmpList[2],
            });
          });
          setUseUrl((pristate: any) => {
            return (pristate = libns);
          });
        }
      }
    }

  }, []);

  return (
    <>
      <div className="burn">
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Total token")}`}</div>
          <div className="infoItem-name"> {dataItem.title as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Factory Address")}`}</div>
          <div className="infoItem-name"> {dataItem.title as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Token name")}`}</div>
          <div className="infoItem-name"> {dataItem.title as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Token symbol")}`}</div>
          <div className="infoItem-name"> {dataItem.title as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Token decimals")}`}</div>
          <div className="infoItem-name"> {dataItem.title as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Presale rate")}`}</div>
          <div className="infoItem-name"> {dataItem.title as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Listing rate")}`}</div>
          <div className="infoItem-name"> {dataItem.title as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Sale method")}`}</div>
          <div className="infoItem-name">{dataItem.method as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Softcap")}`}</div>
          <div className="infoItem-name">{dataItem.softcap as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Hardcap")}`}</div>
          <div className="infoItem-name">{dataItem.hardcap as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Unsold tokens")}`}</div>
          <div className="infoItem-name">{dataItem.hardcap as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Minimum buy")}`}</div>
          <div className="infoItem-name">{dataItem.minbuy as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Maximum buy")}`}</div>
          <div className="infoItem-name">{dataItem.maxbuy as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Maximum buy")}`}</div>
          <div className="infoItem-name">{dataItem.maxbuy as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Maximum buy")}`}</div>
          <div className="infoItem-name">{dataItem.maxbuy as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Liquidity")}`}</div>
          <div className="infoItem-name">{dataItem.maxbuy as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Fund TGE")}`}</div>
          <div className="infoItem-name">{dataItem.fundtge as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Fund Cycle")}`}</div>
          <div className="infoItem-name">{dataItem.fundcycle as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Fund Release Each Cycle")}`}</div>
          <div className="infoItem-name">{dataItem.releasecycle as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Start time")}`}</div>
          <div className="infoItem-name">{dataItem.start as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("End time")}`}</div>
          <div className="infoItem-name">{dataItem.end as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Liquidity lockup time")}`}</div>
          <div className="infoItem-name">{dataItem.end as string}</div>
        </div>
        <div className="infoItem">
          <div className="infoItem-title">{`${t("Website")}`}</div>
          <div className="infoItem-name ">
            <a
              href={dataItem.website as string}
              className="web pinktext"
              target="_blank"
            >
              {dataItem.website as string}
            </a>
          </div>
        </div>
        {warning ? (
          <div className="warning">
            <span className="warning-text">
              {`${t(
                "For tokens with burns, rebase or other special transfers please ensure that you have a way to whitelist multiple addresses or turn off the special transfer events (By setting fees to 0 for example for the duration of the presale)"
              )}`}
            </span>
            <div
              className="close"
              onClick={() => {
                setWarning(false);
              }}
            >
              X
            </div>
          </div>
        ) : (
          ""
        )}
        <div className="footer-btn-block">
          <div className="footer-area">
            <button
              className="back"
              onClick={() => {
                BackAreaOnCLick();
              }}
            >{`${t("Back")}`}</button>
            <button
              className="submit"
              onClick={() => {
                submitOnCLick();
              }}
            >
              {loading ? <ButtonLoading /> : ""} {`${t("Submit")}`}
            </button>
          </div>
        </div>
      </div>
      <div className="Burn-roadmapPC">
        {state && state.pagetitle === 'Sale' ? <PrivateSaleRoadmapPC step={4} /> : <LaunchpadRoadmapPC step={4} />}
      </div>
      <div className="Burn-roadmapMobile">
        {state && state.pagetitle === 'Sale' ? <PrivateSaleRoadmapMobile step={4} /> : <LaunchpadRoadmapMobile step={4} />}
      </div>
    </>
  );
};
export default Burn;
