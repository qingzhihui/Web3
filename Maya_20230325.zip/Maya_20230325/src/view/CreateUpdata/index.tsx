import React, { useState, useEffect } from "react";
import "./index.scss";
import { Input } from "antd";
import { CreateAidropeProps } from "../../hooks/Airprcopy";
import { PrivateSaleABI } from "../../hooks/PrivateSale";
import { InstancedContract } from "../../hooks/config";
import { useHistory, useLocation } from "react-router-dom";
import ButtonLoading from "../../components/ButtonLoading";
import { useTranslation } from "react-i18next";
import { LaunchPadABI } from "../../hooks/launchpad";
import { AirDropABI } from "../../hooks/SomebodyAirdrop";
const { TextArea } = Input;
declare const window: Window & { ethereum: any };
const CreateUpdata: React.FC = (props: any) => {
  let history = useHistory();
  const { state } = useLocation<any>();
  const [userData, setUserData] = useState<any>({});
  const [userInputValue, setUserInputValue] = useState<CreateAidropeProps>({});
  const [loading, setLoading] = useState<boolean>(false);
  const [ulsName, setulsName] = useState("");
  const { t } = useTranslation();

  const NextOnCLikc = async () => {
    try {
      setLoading(true);
      if (ulsName === "PrivateSaleCurrency") {
        const PrivateSaleConstaer = InstancedContract(
          userData.address,
          PrivateSaleABI
        ) as any;
        const updatePoolDetail =
          await PrivateSaleConstaer.updatePrivateSaleDetail(
            `${userInputValue.Title},${userInputValue.LogoURL},${userInputValue.Website},${userInputValue.Facebook},${userInputValue.Twitter},${userInputValue.Github},${userInputValue.Telegram},${userInputValue.Instagram},${userInputValue.Discord},${userInputValue.Reddit},${userInputValue.Description}`
          );
        await updatePoolDetail.wait();
        setLoading(false);
      } else if (ulsName === "CurrentPresales") {
        const LaunchPadContract = InstancedContract(
          userData.PresaleAddress,
          LaunchPadABI
        ) as any;
        const updatePoolDetail = await LaunchPadContract.updatePoolDetail(
          `${userInputValue.Title},${userInputValue.LogoURL},${userInputValue.Website},${userInputValue.Facebook},${userInputValue.Twitter},${userInputValue.Github},${userInputValue.Telegram},${userInputValue.Instagram},${userInputValue.Discord},${userInputValue.Reddit},${userInputValue.Description}`
        );
        await updatePoolDetail.wait();
        setLoading(false);
      } else {
        const AirDropConstaer = InstancedContract(
          userData.AirdropAddress,
          AirDropABI
        ) as any;
        const updatePoolDetails = await AirDropConstaer.updatePoolDetails(
          `${userInputValue.Title},${userInputValue.LogoURL},${userInputValue.Website},${userInputValue.Facebook},${userInputValue.Twitter},${userInputValue.Github},${userInputValue.Telegram},${userInputValue.Instagram},${userInputValue.Discord},${userInputValue.Reddit},${userInputValue.Description}`
        );
        await updatePoolDetails.wait();
        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
    }
  };
  const BackOnClick = () => {
    history.push({
      pathname: `/${ulsName}`,
      state,
    });
  };
  useEffect(() => { }, [userData]);
  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const addr = localStorage.getItem("MaYa_addr");
      if (addr !== null && addr !== undefined) {
        if (state != undefined) {
          setUserData((data: any) => {
            return (data = state.editUpdata);
          });
          setulsName((value: any) => {
            return (value = state.urlName);
          });
        }
      }
    }
  }, []);
  return (
    <div className="CreateAirdrop">
      <div className="CreateAirdrop_countent">
        <div className="title">{`${t("Create New Launchpad")}`}</div>
        <div className="CreateAirdrop_table">
          <div className="attention">(*) {`${t("is required field.")}`}</div>
          <div className="titleinput">
            <div className="titleipt">{`${t("Airdrop Title")}`}</div>
            <div className="inputs">
              <Input
                placeholder={`${t("Ex: Join my mayasale airdrop")}`}
                bordered={false}
                value={userInputValue.Title || ""}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  setUserInputValue((olddata: any) => {
                    return {
                      ...olddata,
                      Title: e.target.value,
                    };
                  });
                }}
              />
            </div>
          </div>
          <div className="logoweinput">
            <div className="urlinput">
              <div className="titlelo">
                {`${t("Logo URL")}`} <span>*</span>
              </div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://...")}`}
                  bordered={false}
                  value={userInputValue.LogoURL || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        LogoURL: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon99.png")}
                      alt=""
                    />
                  }
                />
              </div>
              <div className="lourl">
                {`${t(
                  "URL must end with a supported image extension png, jpg, jpeg or gif. You can upload your image at"
                )}`}{" "}
                <a href="">https://images.youwant.io/</a>
              </div>
            </div>
            <div className="weinput">
              <div className="titlewe">
                {`${t("Website")}`} <span>*</span>
              </div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://...")}`}
                  bordered={false}
                  value={userInputValue.Website || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Website: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon22.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Facebook</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://facebook.com/...")}`}
                  bordered={false}
                  value={userInputValue.Facebook || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Facebook: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon88.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Twitter</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://twitter.com/...")}`}
                  bordered={false}
                  value={userInputValue.Twitter || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Twitter: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon66.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Github</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://github.com/...")}`}
                  bordered={false}
                  value={userInputValue.Github || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Github: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon11.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Telegram</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://t.me/...")}`}
                  bordered={false}
                  value={userInputValue.Telegram || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Telegram: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon55.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
          </div>
          <div className="partnerinputs">
            <div className="leftinpts">
              <div className="titleinpts">Instagram</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://instagram.com/...")}`}
                  bordered={false}
                  value={userInputValue.Instagram || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Instagram: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon33.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
            <div className="rightinpts">
              <div className="titleinpts">Discord</div>
              <div className="inputs">
                <Input
                  placeholder={`${t("Ex: https://t.me/...")}`}
                  bordered={false}
                  value={userInputValue.Discord || ""}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUserInputValue((olddata: any) => {
                      return {
                        ...olddata,
                        Discord: e.target.value,
                      };
                    });
                  }}
                  prefix={
                    <img
                      src={require("../../assets/image/icon77.png")}
                      alt=""
                    />
                  }
                />
              </div>
            </div>
          </div>
          <div className="redditinputs">
            <div className="titlere">Reddit</div>
            <div className="inputs">
              <Input
                placeholder={`${t("Ex: https://reddit.com/...")}`}
                bordered={false}
                value={userInputValue.Reddit || ""}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  setUserInputValue((olddata: any) => {
                    return {
                      ...olddata,
                      Reddit: e.target.value,
                    };
                  });
                }}
                prefix={
                  <img src={require("../../assets/image/icon44.png")} alt="" />
                }
              />
            </div>
          </div>
          <div className="descriptiontext">
            <div className="titlede">{`${t("Description")}`}</div>
            <div className="inputstext">
              <TextArea
                placeholder={`${t("Ex: This is the best project...")}`}
                allowClear
                value={userInputValue.Description || ""}
                onChange={(e) => {
                  setUserInputValue((olddata: any) => {
                    return {
                      ...olddata,
                      Description: e.target.value,
                    };
                  });
                }}
              />
            </div>
          </div>
          <div className="buts">
            <button
              className="back"
              onClick={() => {
                BackOnClick();
              }}
            >{`${t("Back")}`}</button>
            <button
              className="createbut diancli"
              onClick={() => {
                NextOnCLikc();
              }}
            >
              {loading ? <ButtonLoading /> : ""}
              {`${t("Create New Airdrop")}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default CreateUpdata;
