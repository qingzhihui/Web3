import React, { useState } from "react";
import DeleteAdmin from "./DeleteAdmin";

export interface IAdmin {
  id: number;
  name: string;
}
let List: IAdmin[] = [];
for (let index = 0; index < 10; index++) {
  List.push({
    id: index,
    name: "admin" + index,
  });
}
function AdminList() {
  const [adminList, setAdminList] = useState(List);
  const deleteAdmin = (admin: IAdmin) => {
    setAdminList(adminList.filter((a) => a.id !== admin.id));
  };
  return (
    <div>
      <ul>
        {adminList.map((admin) => (
          <li onClick={()=>{
            deleteAdmin(admin)
          }} key={admin.id}>{admin.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default AdminList;
