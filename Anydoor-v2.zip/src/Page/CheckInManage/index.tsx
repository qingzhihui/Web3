import { FormOutlined, DeleteOutlined } from "@ant-design/icons";
import { Button, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useState } from "react";
import "./index.css";

// 入住管理界面
const hotelDataSinicization = () => {
  interface DataType {
    key: number;
    hotelName: string; // 酒店名称
    contacts: string; // 联系人
    contactNumber: number; // 联系电话
    hotelAddress: string; // 酒店地址
    explain: string; // 补充说明
    status: string; //状态
  }

  const data: DataType[] = [
    {
      key: 1,
      hotelName: "xxx酒店",
      contacts: "张三",
      contactNumber: 13546164887,
      hotelAddress: "珠海市香洲区吉大20路xxx栋xxx房",
      explain: "无",
      status: "待审核",
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "酒店名称",
      dataIndex: "hotelName",
      width: 200,
    },
    {
      title: "联系人",
      dataIndex: "contacts",
      width: 120,
    },
    {
      title: "联系电话",
      dataIndex: "contactNumber",
      width: 200,
    },
    {
      title: "酒店地址",
      dataIndex: "hotelAddress",
      width: 200,
    },
    {
      title: "补充说明",
      dataIndex: "explain",
      width: 80,
    },
    {
      title: "状态",
      dataIndex: "status",
      width: 120,
    },
    {
      title: "操作",
      key: "action",
      width: 200,
      render: (_, record) => (
        <Space size="middle">
          <span className="checkIn_publicCursor" onClick={uploadus(record)}>
            <FormOutlined />
          </span>
          <span className="checkIn_publicCursor" onClick={deleteus(record)}>
            <DeleteOutlined />
          </span>
        </Space>
      ),
    },
  ];

  // 修改
  const uploadus = (record: any) => {
    return () => {
      console.log("点击了修改");
      console.log(record.key);
    };
  };
  // 删除
  const deleteus = (record: any) => {
    return () => {
      console.log("点击了删除");
      console.log(record.key);
    };
  };
  const cehsi: any = [
    {
      id: 0,
      value: "全部",
    },
    {
      id: 1,
      value: "待审核",
    },
    {
      id: 2,
      value: "审核通过",
    },
    {
      id: 3,
      value: "审核拒绝",
    },
  ];
  //   用于判断点击变色
  const [isNum, setNum] = useState(0);

  //   各类审核按钮
  const handleClick = (index: any) => {
    return () => {
      setNum(index);
      if (index == 0) {
        console.log("点击了全部");
      } else if (index == 1) {
        console.log("点击了待审核");
      } else if (index == 2) {
        console.log("点击了审核通过");
      } else if (index == 3) {
        console.log("点击了审核未通过");
      } else {
        console.log("点击发送错误");
      }
    };
  };

  return (
    <div className="checkIn_Box">
      <div className="checkIn_headerBox">
        <div className="checkIn_headerBox_thread"></div>
        <div className="checkIn_headerBox_Tit">&nbsp;&nbsp;&nbsp; 入住管理</div>
        <div className="checkIn_headerbtnBox">
          {cehsi.map((item: any, index: any) => {
            return (
              <div
                style={{
                  backgroundColor: index == isNum ? "#3296FA" : "",
                  color: index == isNum ? "#FFF" : "",
                }}
                onClick={handleClick(index)}
              >
                {item.value}
              </div>
            );
          })}
        </div>
      </div>

      <div className="checkIn_tableBox">
        <Table columns={columns} dataSource={data} />
      </div>
    </div>
  );
};

export default hotelDataSinicization;
