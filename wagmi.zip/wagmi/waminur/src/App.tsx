import React, { useEffect } from "react";
import logo from "./logo.svg";
import "./App.css";
import { WagmiConfig, createClient, useAccount } from "wagmi";
import {
  ConnectKitProvider,
  ConnectKitButton,
  getDefaultClient,
} from "connectkit";

function App() {  
  const alchemyId = "k-eeUDkI1-EBmUu45lGdNAi3MzO35MOE";
  const client = createClient(
    getDefaultClient({
      appName: "Your App Name",
      alchemyId,
    })
  );
  const MyComponent = () => {
    const { address, isConnecting, isDisconnected } = useAccount();
    if (isConnecting) return <div>Connecting...</div>;
    if (isDisconnected) return <div>Disconnected</div>;
    return <div>Connected Wallet: {address}</div>;
  };
  return (
    <div className="App">
      <WagmiConfig client={client}>
        <ConnectKitProvider  customTheme={{
          "--ck-font-family": '"Comic Sans MS", "Comic Sans", cursive',
        }}>
          <ConnectKitButton />
          <div style={{ marginTop: "20px" }}>
            <MyComponent />
          </div>
        </ConnectKitProvider>
      </WagmiConfig>
    </div>
  );
}

export default App;
