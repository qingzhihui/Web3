import React, { useEffect } from "react";
import "./index.scss";
import { useHistory } from "react-router-dom";
import k1 from "../../assets/k1.png";
import k2 from "../../assets/k2.png";
import k3 from "../../assets/k3.png";
import k4 from "../../assets/k4.png";
import k5 from "../../assets/k5.png";
import k6 from '../../assets/zx.png'

function Heues(props: any) {
  let history = useHistory();
  const MenuList = [
    {
      key: "/Farm",
      label: "农场",
      image: k1,
    },
   
    {
      key: "/Vote",
      label: "领取选票",
      image: k2,
    },
    {
      key: "/Unity",
      label: "LP身份",
      image: k5,
    },
    
    {
      key: "/Rank",
      label: "LP排名",
      image: k3,
    },
    {
      key: "/Fista",
      label: "质押中心",
      image: k6,
    },
    {
      key: "/Othe",
      label: "其他",
      image: k4,
    },
  ];
  const Biens = (key: any) => {
    history.push(key);
  };
  // useEffect(() => {
  //   const delbe: HTMLCollectionOf<Element> = document.getElementsByClassName(
  //     "nritem"
  //   ) as HTMLCollectionOf<Element>;
  //   const BUskliu = Array.prototype.slice.call(delbe);
  //   const kulie = props.burl.slice(1, 7).toUpperCase();
  //   BUskliu.map((item: any) => {
  //     if (item.innerText == kulie) {
  //       item.className += " beis";
  //     }
  //   });
  // }, []);
  return (
    <div className="heues">
      <div className="nrolse">
        {MenuList.map((item, index) => (
          <div className="nritem" key={index} onClick={() => Biens(item.key)}>
            <img src={item.image} alt="" />
            <div>{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Heues;
