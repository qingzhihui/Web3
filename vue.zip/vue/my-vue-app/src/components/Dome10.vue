<template>
  <div class="poem">
    <h1>凌江行</h1>
    <div class="author">
      <span>样省</span>
      <span class="year">1488</span>
      <span class="to">样省</span>
      <span class="year">样省</span>
    </div>
    <p>1</p>
    <p>2</p>
    <p>3</p>
    <p>4</p>
    <p>5</p>
  </div>
</template>

<script setup lang="ts">


</script>

<style>
.poem {
  color: #333;
  font-size: 1.4rem;
  /*horizontal-tb*/
  writing-mode: vertical-rl;
  float: right;
}

.author {
  color: #333;
  font-size: 0.8rem;
  margin-right: -30px;
  text-align: end;
}
.author .year{
  text-orientation: upright;
  text-combine-upright: all;
}
</style>
