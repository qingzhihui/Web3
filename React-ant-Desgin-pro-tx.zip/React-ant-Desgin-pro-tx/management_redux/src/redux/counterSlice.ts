import { createSlice } from "@reduxjs/toolkit";
import { Todo } from "../hooks/types";

export const counterSlice = createSlice({
  name: "counter",
  initialState: {
    TodoStore: [],
  },
  reducers: {
    increment: (state, action) => {
      let newState = JSON.parse(JSON.stringify(state));
      let staDate = newState.TodoStore;
      if (newState.TodoStore.length === 0) {
        state.TodoStore = action.payload;
        return;
      } else {
        staDate.push(action.payload[0]);
      }
      state.TodoStore = staDate;
    },
    decrement: (state, action) => {
      let newState = JSON.parse(JSON.stringify(state));
      newState.TodoStore = newState.TodoStore.filter(
        (item: any) => item.id !== action.payload
      );
      state.TodoStore = newState.TodoStore;      
    }
  },
});

export const { increment, decrement } = counterSlice.actions;

export default counterSlice.reducer;
