import React, { useState, useEffect } from "react";
import loges from "../../assets/image/loge2.png";
import { useNavigate } from "react-router-dom";
import { Drawer } from "antd";
import { MenuList, RouterItem, RouterProps } from "../../hooks/config";
const LanguaGeswit = React.lazy(() => import("../LanguaGeswit"));
const ConnectWallet = React.lazy(() => import("../ConnectWallet"));

import icround from "../../assets/image/ic_round-menu-open2.png";
import icroundBox from "../../assets/image/ic_round-menu-open.png";
import "./index.scss";

let scrollTop = 0;
let topValue = 0;

// e: React.ChangeEvent<HTMLInputElement>
interface Props {
  url?: string;
}
const HotnaviGation: React.FC<Props> = ({ url }) => {
  const [HeaderState, setHeaderState] = useState<number | undefined>(0);
  const [open, setOpen] = useState(false);
  const [urler, setUrler] = useState("/");
  const navigate = useNavigate();
  const RouterUrlonCluck = (url: string | any, key: number | undefined) => {
    setHeaderState(key);
    navigate(url);
  };
  const WalletMemoer = React.memo(() => {
    return <ConnectWallet />;
  });
  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  };
  const Biens = (url: any) => {
    setUrler((stateValue: string) => {
      return (stateValue = url);
    });
    navigate(url);
    setOpen(false);
  };
  useEffect(() => {}, [HeaderState]);
  return (
    <div className="Headeer" id="demo">
      <div className="HeaderComponent">
        <div className="HeaderIcones">
          <img src={loges} alt="" className="logimg" />
        </div>
        <div className="HeaderIcoloe">
          <button onClick={() => [showDrawer()]}>
            <img src={icround} className="incimgel" />
          </button>
        </div>
        <div className="HeaderItelei">
          {RouterItem.map((item: RouterProps, index: number) => (
            <div
              key={index}
              className={`HeaderItem ${
                HeaderState === item.key ? "action" : ""
              }`}
              onClick={() => {
                RouterUrlonCluck(item.url, item.key);
              }}
            >
              {item.title}
            </div>
          ))}
        </div>
        <div className="HaderButtonGroup">
          <div className="HaderLoser">
            <LanguaGeswit />
          </div>
          <div className="HaderButton">
            <WalletMemoer />
          </div>
        </div>
      </div>
      <Drawer
        placement="left"
        onClose={onClose}
        open={open}
        closeIcon={<img src={icroundBox} className="incimgel" />}
        className="DrawerClass"
        zIndex={100000}
        maskClosable={true}
        width={200}
        extra={<div className="Headerplie">MY TOKEN</div>}
      >
        <div className="DrawerImtel">
          <div className="nrolse">
            {MenuList.map((item, index) => (
              <div
                className={`nritem ${urler === item.url ? "luser" : ""}`}
                key={index}
                onClick={() => Biens(item.url)}
              >
                <img
                  src={urler == item.url ? item.imgurl : item.image}
                  alt=""
                />
                <div>{item.title}</div>
              </div>
            ))}
          </div>
          <div className="fuoniens">
            <img src={loges} alt="" className="logimg" />
          </div>
        </div>
      </Drawer>
    </div>
  );
};

export default HotnaviGation;
