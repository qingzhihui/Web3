import React, { Component, ReactNode } from "react";

interface IProps {
  msg: string;
  children?: ReactNode;
}
interface IState {
  count: number;
}
class Hello extends Component<IProps, IState> {
  constructor(props: IProps) {
    super(props);
    // 只能初始化的时候这么做
    this.state = {
      count: 0,
    };
  }
  componentDidMount() {
    // setTimeout(() => {
    //   this.setState({
    //     count: this.state.count + 1,
    //   });
    // }, 1000);
    // setInterval(() => {
    //   this.setState({
    //     count: this.state.count + 1,
    //   });
    // }, 1);

    // 错误
    for (var i = 1; i <= 100; i++) {
      this.setState((state) => ({
        count: state.count + i,
      }));
    }
  }
  render() {
    return (
      <>
        <h1>{this.state.count}</h1>
        <h1>{this.props.msg}</h1>
        {this.props.children}
        <br />
      </>
    );
  }
}

export default Hello;
