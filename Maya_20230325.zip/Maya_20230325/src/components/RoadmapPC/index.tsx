import React from 'react'
import { useTranslation, Trans } from "react-i18next";
import './index.css'

interface stepInterface {
    step: number;
    titleOne?: string,
    descOne?: string,
    titleTwo?: string
}

const RoadmapPC: React.FC<stepInterface> = ({ step, titleOne, descOne, titleTwo }) => {
    const { t } = useTranslation();

    return (
        <div className="roadmapArea">
            {/* <div className="activePoint">1</div> */}
            <div className={`footerItem ${step === 1 ? "activePoint" : "roadPoint"}`}>1</div>
            <div className="point-desc">
                <span className={` ${step === 1 ? "point-desc-first" : "point-desc-one"}`}>{titleOne ? `${t(titleOne)}` : `${t("Before you start")}`}</span>
                <span className="point-desc-two">
                    {descOne ? `${t(descOne)}` : `${t("Input your awesome title and choose the currency")}`}
                </span>
            </div>
            <div className="point-link" />

            <div className={`footerItem ${step === 2 ? "activePoint" : "roadPoint"}`}>2</div>
            <div className="point-desc">
                <span className={` ${step === 2 ? "point-desc-first" : "point-desc-one"}`}>{titleTwo ? `${t(titleTwo)}` : `${t("Private Sale")}`}</span>
                <span className="point-desc-two">
                    {`${t("Enter the launchpad information that you want to raise , that should be enter all details about your presale")}`}
                </span>
            </div>
            <div className="point-link" />

            <div className={`footerItem ${step === 3 ? "activePoint" : "roadPoint"}`}>3</div>
            <div className="point-desc">
                <span className={` ${step === 3 ? "point-desc-first" : "point-desc-one"}`}>{`${t("Add Additional Info")}`}</span>
                <span className="point-desc-two">{`${t("Let people know who you are")}`}</span>
            </div>
            <div className="point-link" />

            <div className={`footerItem ${step === 4 ? "activePoint" : "roadPoint"}`}>4</div>
            <div className="point-desc">
                <span className={` ${step === 4 ? "point-desc-first" : "point-desc-one"}`}>{`${t("Finish")}`}</span>
                <span className="point-desc-two">{`${t("Review your information")}`}</span>
            </div>
        </div>
    )
}

export default RoadmapPC