export interface RouteParams {
    [key: string]: string | undefined;
  }