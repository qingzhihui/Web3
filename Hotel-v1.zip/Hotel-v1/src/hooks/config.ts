import { useMenu } from "./useConfig";

const MenuList: useMenu[] = [
  {
    key: "/Home",
    label: "HOME",
  },
  {
    key: "/Visa",
    label: "VISA",
  },
  {
    key: "/Flights",
    label: "FLIGHTS",
  },
  {
    key: "/Hotel",
    label: "HOTEL",
  },
  {
    key: "/Tickets",
    label: "TICKETS",
  },
  {
    key: "/Discovery",
    label: "DISCOVERY",
  },
];


export { MenuList };
