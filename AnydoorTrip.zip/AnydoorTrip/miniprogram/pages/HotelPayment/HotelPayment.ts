import api from '../../config/axios'
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    paymentlist: [
      {
        "name": "Group61",
        "id": 0
      }, {
        "name": "Group62",
        "id": 1
      }, {
        "name": "Amex",
        "id": 2
      }, {
        "name": "Group63",
        "id": 3
      }, {
        "name": "Group64",
        "id": 4
      }, {
        "name": "Group65",
        "id": 5
      }, {
        "name": "Group66",
        "id": 6
      }, {
        "name": "Group67",
        "id": 7
      }
    ],
    selectpaymethodId: 1,
    cardNumber: "",
    HeleItem: {},
    priceItem: {},
    winesItem: [],
    checked: false,
    discount: "",
    cardImage: "https://anydoortrip-cos01-saving-cc-1305484266.file.myqcloud.com/anydoor_trip/applets_images/pluse.png",
    CarItrm: {},
    speciaIteme: [],
    DuiserData: [],
    time: 180,
    countdown: '',
    SccessData: {}
  },
  /**
   * 生命周期函数--监听页面加载
   */

  onLoad(options: any) {
    this.countdown()
    console.log(JSON.parse(options.item));

    if (options.item !== undefined) {
      const PanMent: any = JSON.parse(options.item);
      const PanMentData = {
        displayName: PanMent.DetailsProps.plan_type,
        mealplan: PanMent.DetailsProps.mealplan,
        number_of_adults: PanMent.DetailsProps.number_of_adults,
        check_in: PanMent.DetailsProps.check_in,
        check_out: PanMent.DetailsProps.check_out,
        number_of_rooms: PanMent.DetailsProps.number_of_rooms,
        interval: PanMent.DetailsProps.interval,
        hotel_id: PanMent.DetailsProps.hotel_id,
        plantype: PanMent.DetailsProps.plantype,
        displayAddress: PanMent.DetailsProps.displayAddress,
        IMage: PanMent.DetailsProps.IMage,
        basePrice: PanMent.DetailsProps.basePrice,
        tax: PanMent.DetailsProps.tax,
        totalPrice: PanMent.DetailsProps.totalPrice,
        id: PanMent.DetailsProps.id
      }
      this.setData({
        HeleItem: PanMentData,
        winesItem: PanMent.winesData,
        speciaIteme: PanMent.special,
        DuiserData: PanMent.CialeData,
        SccessData: JSON.parse(PanMent.Sccess)
      })
    }
  },

  countdown() {
    var minute = Math.floor(this.data.time / 60);
    var second: any = this.data.time % 60
    second < 10 ? second = '0' + second : '';
    this.setData({
      countdown: minute + ':' + second,
      time: this.data.time - 1
    })
    if (this.data.time !== 0) {
      setTimeout(this.countdown, 1000);
    } else {
      Toast.fail('支付超时');
      setTimeout(() => {
        wx.switchTab({
          url: '../Order/Order',
        })
      }, 1000)
    }
  },
  orderCancell() {
    const data: any = this.data.HeleItem;
    api._put(`user/order/${data.id}`).then(res => {
      wx.switchTab({
        url: '../Order/Order',
      })
    }).catch(event => {
      console.log(event);
    })
  },

  CaerShow() {
    wx.navigateTo({
      url: '../CarEntry/CarEntry'
    })
  },
  CaerFeuineProps(event: any) {
    this.setData({
      CarItrm: event
    })
  },
  // 选择支付方式
  changePayMethod: function (e: any) {
    this.setData({
      selectpaymethodId: e.currentTarget.dataset.id
    })
  },
  HotelSucceeShow() {
    const hele: any = this.data.HeleItem;
    const Sccess: any = this.data.SccessData;
    console.log(Sccess);

    api._post('https://sas-myad-login2.anydoortrip.com/user/pay/order_pay', {
      orderNo: Sccess.orderId,
      price: Sccess.price,
      body: hele.displayName + Sccess.room.displayName
    }).then(res => {
      const data = res.data;
      wx.requestPayment({
        'timeStamp': String(data.timeStamp),
        'nonceStr': data.nonceStr,
        'package': data.package,
        'signType': data.signType,
        'paySign': data.paySign,
        'success': function (res) {
          Toast.fail('支付成功');
          api._get(`https://sas-myad-login2.anydoortrip.com/user/pay/notifyUrl/${Sccess.id}`).then((res) => {
            wx.navigateTo({
              url: `../HotelSuccee/HotelSuccee?item=${JSON.stringify(Sccess)}`
            })
          })
        }, 'fail': function (res) {
          console.log('pay fail', res)
          Toast.fail('支付失败');
          wx.switchTab({
            url: '../Order/Order',
          })
        },
        'complete': function (res) {
          console.log('pay complete', res)
        }
      })
    }).catch(e => {
      Toast.fail('支付失败');
    })
  },
  onClickLeft() {

    wx.switchTab({
      url: '../Order/Order',
    })
  },
  DiscountInput(event: any) {
    this.setData({
      discount: event.detail.value
    })

  },
  onChange(event: any) {
    this.setData({
      checked: event.detail,
    });
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})