import api from '../../config/api'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    radio: '',
    show2: false,
    message: "",
    title:"",
    twoTitles:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    api._get(`ums/umsQuestionnaireHistory/getSubmitDetails/${options.id}/${options.qusersid}/${options.tduid}`).then(res => {
      const {title,twoTitles} = res.data
      this.setData({
        title:title,
        twoTitles:twoTitles
      })
    }).catch(e => {
      console.log(e);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  onClickLeft() {
    wx.navigateBack({
      // url: '../History/History',
      delta: 1
    })
  },
  onChanges2(event) {
    this.setData({
      activeNames2: event.detail,
    });
  },
  onChangeMessage(event) {
    this.setData({
      message: event.detail
    })
  },
  onChange(event) {
    this.setData({
      radio: event.detail,
      show2: false
    });
  },
  Anlishow(e) {
    this.setData({
      show2: true
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: "分享",
      path: "/pages/Login/Login"
    }
  }
})