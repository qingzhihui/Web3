let str: string = 'hello typescript'
let num: number = 100
let bool: boolean = true