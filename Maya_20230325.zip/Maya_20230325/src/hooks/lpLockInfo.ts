import { FormatUnitsConver, TimestampToTime } from "./config";
import { CycleBpsConversion, CycleConversion } from "./LockRecordInfo";
import { toStringValue } from "./Token";

export interface LPCalculatorProps {
  key: React.Key;
  Unlock: number;
  Time: string;
  tokens: string;
}

export interface LpAggregateProps {
  Title?: string;
  amount?: string;
  amountShow?: string;
  Locked?: number;
  Owner?: string;
  lockDate?: string;
  lockDateShow?: string;
  token?: string;
  tgeDate?: string;
  tgeDateShow?: string;
  Percent?: string;
  PercentShow?: string;
  Cycle?: string;
  CycleShow?: string;
  CycleRelease?: string;
  CycleReleaseShow?: string;
  UnlockedAmount?: string;
}
export interface lockRecordProps {
  balanceOf?: string;
  decimals?: number;
  name?: string;
  symbol?: string;
}

export interface Token0Props {
  token0Name?: string;
  token0Address?: string;
  token0Symbol?: string;
}
export interface Token1Props {
  token1Name?: string;
  token1Address?: string;
  token1Symbol?: string;
}

const LPCalculator = (
  cycle: string,
  cycleBps: string,
  tgeBps: string,
  tgeDate: string,
  amount: string,
  decimals: number
) => {
  const TimeDate = (Number(tgeBps) / 10000) * Number(amount);
  const CalculatorData: LPCalculatorProps[] = [
    {
      key: 0,
      Unlock: 1,
      Time: TimestampToTime(tgeDate),
      tokens: FormatUnitsConver(TimeDate.toString(), decimals),
    },
  ];
  const rate = (10000 - Number(tgeBps)) / Number(cycleBps);
  for (let index = 0; index < Math.ceil(rate); index++) {
    const Timeitem = (Number(cycleBps) / 10000) * Number(amount);
    const tgeNumer = Number(tgeDate) + (index + 1) * Number(cycle);
    CalculatorData.push({
      key: CalculatorData.length + 1,
      Unlock: CalculatorData.length + 1,
      Time: TimestampToTime(tgeNumer),
      tokens: toStringValue(FormatUnitsConver(Timeitem.toString(), decimals)),
    });
  }
  return CalculatorData;
};

const LpLockInfoAggregate = (getItem: any, lockRecord: number) => {
  const LockRecordData: LpAggregateProps = {
    Title: getItem.description,
    amount: toStringValue(getItem.amount),
    amountShow: toStringValue(FormatUnitsConver(getItem.amount, lockRecord)),
    Locked: 0,
    Owner: getItem.owner,
    lockDate: toStringValue(getItem.lockDate),
    lockDateShow: TimestampToTime(getItem.lockDate),
    token: getItem.token,
    tgeDate: toStringValue(getItem.tgeDate),
    tgeDateShow: TimestampToTime(getItem.tgeDate),
    Percent: toStringValue(getItem.tgeBps),
    PercentShow: CycleBpsConversion(toStringValue(getItem.tgeBps)).toString(),
    Cycle: toStringValue(getItem.cycle),
    CycleShow: CycleConversion(toStringValue(getItem.cycle)).toString(),
    CycleRelease: toStringValue(getItem.cycleBps),
    CycleReleaseShow: CycleBpsConversion(
      toStringValue(getItem.cycleBps)
    ).toString(),
    UnlockedAmount: toStringValue(getItem.unlockedAmount),
  };
  var CalculatorInfo: LPCalculatorProps[] = [];
  if (Number(LockRecordData.Percent) > 0) {
    CalculatorInfo = LPCalculator(
      toStringValue(getItem.cycle),
      toStringValue(getItem.cycleBps),
      toStringValue(getItem.tgeBps),
      toStringValue(getItem.tgeDate),
      toStringValue(getItem.amount),
      lockRecord
    );
  }
  return {
    LockRecordData,
    CalculatorInfo,
  };
};

export { LPCalculator, LpLockInfoAggregate };
