import Line from "../Line";
import "./index.scss"
import {useEffect} from "react";
import $ from "jquery"

type Props = {
  className?: string
  title: string
}

export default function Title(props: Props) {
  useEffect(() => {
    $('.cmp-title .title-value').children('span').hover((function() {
      let $el, n;
      $el = $(this);
      n = $el.index() + 1;
      $el.addClass('flat');
      if (n % 2 === 0) {
        return $el.prev().addClass('flat');
      } else {
        if (!$el.hasClass('last')) {
          return $el.next().addClass('flat');
        }
      }
    }), function() {
      return $('.flat').removeClass('flat');
    });
  }, [])
  return (
    <div className={"cmp-title " + props.className ?? ""}>
      <div className="title-value">
        {props.title.split("").map((item, key) => {
          return (
            <span key={key}>{item}</span>
          )
        })}
      </div>
      <Line/>
    </div>
  )
}